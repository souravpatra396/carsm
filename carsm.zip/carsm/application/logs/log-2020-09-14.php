<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-14 14:19:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:19:42 --> Config Class Initialized
INFO - 2020-09-14 14:19:42 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:19:42 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:19:42 --> Utf8 Class Initialized
INFO - 2020-09-14 14:19:42 --> URI Class Initialized
DEBUG - 2020-09-14 14:19:42 --> No URI present. Default controller set.
INFO - 2020-09-14 14:19:42 --> Router Class Initialized
INFO - 2020-09-14 14:19:42 --> Output Class Initialized
INFO - 2020-09-14 14:19:42 --> Security Class Initialized
DEBUG - 2020-09-14 14:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:19:42 --> Input Class Initialized
INFO - 2020-09-14 14:19:42 --> Language Class Initialized
INFO - 2020-09-14 14:19:42 --> Loader Class Initialized
INFO - 2020-09-14 14:19:42 --> Helper loaded: url_helper
INFO - 2020-09-14 14:19:42 --> Database Driver Class Initialized
INFO - 2020-09-14 14:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:19:42 --> Email Class Initialized
INFO - 2020-09-14 14:19:42 --> Controller Class Initialized
INFO - 2020-09-14 14:19:42 --> Model Class Initialized
INFO - 2020-09-14 14:19:42 --> Model Class Initialized
DEBUG - 2020-09-14 14:19:42 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-14 14:19:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-14 14:19:42 --> Final output sent to browser
DEBUG - 2020-09-14 14:19:42 --> Total execution time: 0.1303
ERROR - 2020-09-14 14:19:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:19:45 --> Config Class Initialized
INFO - 2020-09-14 14:19:45 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:19:45 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:19:45 --> Utf8 Class Initialized
INFO - 2020-09-14 14:19:45 --> URI Class Initialized
INFO - 2020-09-14 14:19:45 --> Router Class Initialized
INFO - 2020-09-14 14:19:45 --> Output Class Initialized
INFO - 2020-09-14 14:19:45 --> Security Class Initialized
DEBUG - 2020-09-14 14:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:19:45 --> Input Class Initialized
INFO - 2020-09-14 14:19:45 --> Language Class Initialized
INFO - 2020-09-14 14:19:45 --> Loader Class Initialized
INFO - 2020-09-14 14:19:45 --> Helper loaded: url_helper
INFO - 2020-09-14 14:19:45 --> Database Driver Class Initialized
ERROR - 2020-09-14 14:19:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:19:45 --> Config Class Initialized
INFO - 2020-09-14 14:19:45 --> Hooks Class Initialized
INFO - 2020-09-14 14:19:45 --> Email Class Initialized
INFO - 2020-09-14 14:19:45 --> Controller Class Initialized
DEBUG - 2020-09-14 14:19:45 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:19:45 --> Utf8 Class Initialized
INFO - 2020-09-14 14:19:45 --> Model Class Initialized
INFO - 2020-09-14 14:19:45 --> Model Class Initialized
INFO - 2020-09-14 14:19:45 --> URI Class Initialized
DEBUG - 2020-09-14 14:19:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 14:19:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 14:19:45 --> Router Class Initialized
INFO - 2020-09-14 14:19:45 --> Output Class Initialized
INFO - 2020-09-14 14:19:45 --> Security Class Initialized
DEBUG - 2020-09-14 14:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:19:45 --> Input Class Initialized
INFO - 2020-09-14 14:19:45 --> Language Class Initialized
INFO - 2020-09-14 14:19:45 --> Loader Class Initialized
INFO - 2020-09-14 14:19:45 --> Helper loaded: url_helper
INFO - 2020-09-14 14:19:45 --> Database Driver Class Initialized
INFO - 2020-09-14 14:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:19:45 --> Email Class Initialized
INFO - 2020-09-14 14:19:45 --> Controller Class Initialized
INFO - 2020-09-14 14:19:45 --> Model Class Initialized
INFO - 2020-09-14 14:19:45 --> Model Class Initialized
DEBUG - 2020-09-14 14:19:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 14:19:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:19:45 --> Config Class Initialized
INFO - 2020-09-14 14:19:45 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:19:45 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:19:45 --> Utf8 Class Initialized
INFO - 2020-09-14 14:19:45 --> URI Class Initialized
DEBUG - 2020-09-14 14:19:45 --> No URI present. Default controller set.
INFO - 2020-09-14 14:19:45 --> Router Class Initialized
INFO - 2020-09-14 14:19:45 --> Output Class Initialized
INFO - 2020-09-14 14:19:45 --> Security Class Initialized
DEBUG - 2020-09-14 14:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:19:45 --> Input Class Initialized
INFO - 2020-09-14 14:19:45 --> Language Class Initialized
INFO - 2020-09-14 14:19:45 --> Loader Class Initialized
INFO - 2020-09-14 14:19:45 --> Helper loaded: url_helper
INFO - 2020-09-14 14:19:45 --> Database Driver Class Initialized
INFO - 2020-09-14 14:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:19:45 --> Email Class Initialized
INFO - 2020-09-14 14:19:45 --> Controller Class Initialized
INFO - 2020-09-14 14:19:45 --> Model Class Initialized
INFO - 2020-09-14 14:19:45 --> Model Class Initialized
DEBUG - 2020-09-14 14:19:45 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-14 14:19:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-14 14:19:45 --> Final output sent to browser
DEBUG - 2020-09-14 14:19:45 --> Total execution time: 0.0204
ERROR - 2020-09-14 14:19:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:19:46 --> Config Class Initialized
INFO - 2020-09-14 14:19:46 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:19:46 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:19:46 --> Utf8 Class Initialized
INFO - 2020-09-14 14:19:46 --> URI Class Initialized
INFO - 2020-09-14 14:19:46 --> Router Class Initialized
INFO - 2020-09-14 14:19:46 --> Output Class Initialized
INFO - 2020-09-14 14:19:46 --> Security Class Initialized
DEBUG - 2020-09-14 14:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:19:46 --> Input Class Initialized
INFO - 2020-09-14 14:19:46 --> Language Class Initialized
INFO - 2020-09-14 14:19:46 --> Loader Class Initialized
INFO - 2020-09-14 14:19:46 --> Helper loaded: url_helper
INFO - 2020-09-14 14:19:46 --> Database Driver Class Initialized
INFO - 2020-09-14 14:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:19:46 --> Email Class Initialized
INFO - 2020-09-14 14:19:46 --> Controller Class Initialized
DEBUG - 2020-09-14 14:19:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 14:19:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 14:19:46 --> Model Class Initialized
INFO - 2020-09-14 14:19:46 --> Model Class Initialized
INFO - 2020-09-14 14:19:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 14:19:46 --> Final output sent to browser
DEBUG - 2020-09-14 14:19:46 --> Total execution time: 0.0772
ERROR - 2020-09-14 14:26:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:26:33 --> Config Class Initialized
INFO - 2020-09-14 14:26:33 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:26:33 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:26:33 --> Utf8 Class Initialized
INFO - 2020-09-14 14:26:33 --> URI Class Initialized
DEBUG - 2020-09-14 14:26:33 --> No URI present. Default controller set.
INFO - 2020-09-14 14:26:33 --> Router Class Initialized
INFO - 2020-09-14 14:26:33 --> Output Class Initialized
INFO - 2020-09-14 14:26:33 --> Security Class Initialized
DEBUG - 2020-09-14 14:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:26:33 --> Input Class Initialized
INFO - 2020-09-14 14:26:33 --> Language Class Initialized
INFO - 2020-09-14 14:26:33 --> Loader Class Initialized
INFO - 2020-09-14 14:26:33 --> Helper loaded: url_helper
INFO - 2020-09-14 14:26:33 --> Database Driver Class Initialized
INFO - 2020-09-14 14:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:26:33 --> Email Class Initialized
INFO - 2020-09-14 14:26:33 --> Controller Class Initialized
INFO - 2020-09-14 14:26:33 --> Model Class Initialized
INFO - 2020-09-14 14:26:33 --> Model Class Initialized
DEBUG - 2020-09-14 14:26:33 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-14 14:26:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-14 14:26:33 --> Final output sent to browser
DEBUG - 2020-09-14 14:26:33 --> Total execution time: 0.0201
ERROR - 2020-09-14 14:28:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:28:15 --> Config Class Initialized
INFO - 2020-09-14 14:28:15 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:28:15 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:28:15 --> Utf8 Class Initialized
INFO - 2020-09-14 14:28:15 --> URI Class Initialized
INFO - 2020-09-14 14:28:15 --> Router Class Initialized
INFO - 2020-09-14 14:28:15 --> Output Class Initialized
INFO - 2020-09-14 14:28:15 --> Security Class Initialized
DEBUG - 2020-09-14 14:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:28:15 --> Input Class Initialized
INFO - 2020-09-14 14:28:15 --> Language Class Initialized
INFO - 2020-09-14 14:28:15 --> Loader Class Initialized
INFO - 2020-09-14 14:28:15 --> Helper loaded: url_helper
INFO - 2020-09-14 14:28:15 --> Database Driver Class Initialized
INFO - 2020-09-14 14:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:28:15 --> Email Class Initialized
INFO - 2020-09-14 14:28:15 --> Controller Class Initialized
INFO - 2020-09-14 14:28:15 --> Model Class Initialized
INFO - 2020-09-14 14:28:15 --> Model Class Initialized
DEBUG - 2020-09-14 14:28:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 14:28:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:28:15 --> Config Class Initialized
INFO - 2020-09-14 14:28:15 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:28:15 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:28:15 --> Utf8 Class Initialized
INFO - 2020-09-14 14:28:15 --> URI Class Initialized
INFO - 2020-09-14 14:28:15 --> Router Class Initialized
INFO - 2020-09-14 14:28:15 --> Output Class Initialized
INFO - 2020-09-14 14:28:15 --> Security Class Initialized
DEBUG - 2020-09-14 14:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:28:15 --> Input Class Initialized
INFO - 2020-09-14 14:28:15 --> Language Class Initialized
INFO - 2020-09-14 14:28:15 --> Loader Class Initialized
INFO - 2020-09-14 14:28:15 --> Helper loaded: url_helper
INFO - 2020-09-14 14:28:15 --> Database Driver Class Initialized
INFO - 2020-09-14 14:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:28:15 --> Email Class Initialized
INFO - 2020-09-14 14:28:15 --> Controller Class Initialized
INFO - 2020-09-14 14:28:15 --> Model Class Initialized
INFO - 2020-09-14 14:28:15 --> Model Class Initialized
DEBUG - 2020-09-14 14:28:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 14:28:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 14:28:15 --> Model Class Initialized
INFO - 2020-09-14 14:28:15 --> Final output sent to browser
DEBUG - 2020-09-14 14:28:15 --> Total execution time: 0.0249
ERROR - 2020-09-14 14:28:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:28:19 --> Config Class Initialized
INFO - 2020-09-14 14:28:19 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:28:19 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:28:19 --> Utf8 Class Initialized
INFO - 2020-09-14 14:28:19 --> URI Class Initialized
DEBUG - 2020-09-14 14:28:19 --> No URI present. Default controller set.
INFO - 2020-09-14 14:28:19 --> Router Class Initialized
INFO - 2020-09-14 14:28:19 --> Output Class Initialized
INFO - 2020-09-14 14:28:19 --> Security Class Initialized
DEBUG - 2020-09-14 14:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:28:19 --> Input Class Initialized
INFO - 2020-09-14 14:28:19 --> Language Class Initialized
INFO - 2020-09-14 14:28:19 --> Loader Class Initialized
INFO - 2020-09-14 14:28:19 --> Helper loaded: url_helper
INFO - 2020-09-14 14:28:19 --> Database Driver Class Initialized
INFO - 2020-09-14 14:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:28:19 --> Email Class Initialized
INFO - 2020-09-14 14:28:19 --> Controller Class Initialized
INFO - 2020-09-14 14:28:19 --> Model Class Initialized
INFO - 2020-09-14 14:28:19 --> Model Class Initialized
DEBUG - 2020-09-14 14:28:19 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-14 14:28:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-14 14:28:19 --> Final output sent to browser
DEBUG - 2020-09-14 14:28:19 --> Total execution time: 0.0190
ERROR - 2020-09-14 14:28:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:28:35 --> Config Class Initialized
INFO - 2020-09-14 14:28:35 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:28:35 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:28:35 --> Utf8 Class Initialized
INFO - 2020-09-14 14:28:35 --> URI Class Initialized
INFO - 2020-09-14 14:28:35 --> Router Class Initialized
INFO - 2020-09-14 14:28:35 --> Output Class Initialized
INFO - 2020-09-14 14:28:35 --> Security Class Initialized
DEBUG - 2020-09-14 14:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:28:35 --> Input Class Initialized
INFO - 2020-09-14 14:28:35 --> Language Class Initialized
INFO - 2020-09-14 14:28:35 --> Loader Class Initialized
INFO - 2020-09-14 14:28:35 --> Helper loaded: url_helper
INFO - 2020-09-14 14:28:35 --> Database Driver Class Initialized
INFO - 2020-09-14 14:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:28:35 --> Email Class Initialized
INFO - 2020-09-14 14:28:35 --> Controller Class Initialized
INFO - 2020-09-14 14:28:35 --> Model Class Initialized
INFO - 2020-09-14 14:28:35 --> Model Class Initialized
DEBUG - 2020-09-14 14:28:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 14:28:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 14:28:35 --> Model Class Initialized
INFO - 2020-09-14 14:28:35 --> Final output sent to browser
DEBUG - 2020-09-14 14:28:35 --> Total execution time: 0.0190
ERROR - 2020-09-14 14:28:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:28:35 --> Config Class Initialized
INFO - 2020-09-14 14:28:35 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:28:35 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:28:35 --> Utf8 Class Initialized
INFO - 2020-09-14 14:28:35 --> URI Class Initialized
INFO - 2020-09-14 14:28:35 --> Router Class Initialized
INFO - 2020-09-14 14:28:35 --> Output Class Initialized
INFO - 2020-09-14 14:28:35 --> Security Class Initialized
DEBUG - 2020-09-14 14:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:28:35 --> Input Class Initialized
INFO - 2020-09-14 14:28:35 --> Language Class Initialized
INFO - 2020-09-14 14:28:35 --> Loader Class Initialized
INFO - 2020-09-14 14:28:35 --> Helper loaded: url_helper
INFO - 2020-09-14 14:28:35 --> Database Driver Class Initialized
INFO - 2020-09-14 14:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:28:35 --> Email Class Initialized
INFO - 2020-09-14 14:28:35 --> Controller Class Initialized
INFO - 2020-09-14 14:28:35 --> Model Class Initialized
INFO - 2020-09-14 14:28:35 --> Model Class Initialized
DEBUG - 2020-09-14 14:28:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 14:28:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:28:36 --> Config Class Initialized
INFO - 2020-09-14 14:28:36 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:28:36 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:28:36 --> Utf8 Class Initialized
INFO - 2020-09-14 14:28:36 --> URI Class Initialized
INFO - 2020-09-14 14:28:36 --> Router Class Initialized
INFO - 2020-09-14 14:28:36 --> Output Class Initialized
INFO - 2020-09-14 14:28:36 --> Security Class Initialized
DEBUG - 2020-09-14 14:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:28:36 --> Input Class Initialized
INFO - 2020-09-14 14:28:36 --> Language Class Initialized
INFO - 2020-09-14 14:28:36 --> Loader Class Initialized
INFO - 2020-09-14 14:28:36 --> Helper loaded: url_helper
INFO - 2020-09-14 14:28:36 --> Database Driver Class Initialized
INFO - 2020-09-14 14:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:28:36 --> Email Class Initialized
INFO - 2020-09-14 14:28:36 --> Controller Class Initialized
DEBUG - 2020-09-14 14:28:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 14:28:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 14:28:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-14 14:28:36 --> Final output sent to browser
DEBUG - 2020-09-14 14:28:36 --> Total execution time: 0.0374
ERROR - 2020-09-14 14:28:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:28:50 --> Config Class Initialized
INFO - 2020-09-14 14:28:50 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:28:50 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:28:50 --> Utf8 Class Initialized
INFO - 2020-09-14 14:28:50 --> URI Class Initialized
INFO - 2020-09-14 14:28:50 --> Router Class Initialized
INFO - 2020-09-14 14:28:50 --> Output Class Initialized
INFO - 2020-09-14 14:28:50 --> Security Class Initialized
DEBUG - 2020-09-14 14:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:28:50 --> Input Class Initialized
INFO - 2020-09-14 14:28:50 --> Language Class Initialized
INFO - 2020-09-14 14:28:50 --> Loader Class Initialized
INFO - 2020-09-14 14:28:50 --> Helper loaded: url_helper
INFO - 2020-09-14 14:28:50 --> Database Driver Class Initialized
INFO - 2020-09-14 14:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:28:50 --> Email Class Initialized
INFO - 2020-09-14 14:28:50 --> Controller Class Initialized
INFO - 2020-09-14 14:28:50 --> Model Class Initialized
INFO - 2020-09-14 14:28:50 --> Model Class Initialized
DEBUG - 2020-09-14 14:28:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 14:28:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 14:28:50 --> Model Class Initialized
INFO - 2020-09-14 14:28:50 --> Final output sent to browser
DEBUG - 2020-09-14 14:28:50 --> Total execution time: 0.0210
ERROR - 2020-09-14 14:28:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:28:51 --> Config Class Initialized
INFO - 2020-09-14 14:28:51 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:28:51 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:28:51 --> Utf8 Class Initialized
INFO - 2020-09-14 14:28:51 --> URI Class Initialized
INFO - 2020-09-14 14:28:51 --> Router Class Initialized
INFO - 2020-09-14 14:28:51 --> Output Class Initialized
INFO - 2020-09-14 14:28:51 --> Security Class Initialized
DEBUG - 2020-09-14 14:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:28:51 --> Input Class Initialized
INFO - 2020-09-14 14:28:51 --> Language Class Initialized
INFO - 2020-09-14 14:28:51 --> Loader Class Initialized
INFO - 2020-09-14 14:28:51 --> Helper loaded: url_helper
INFO - 2020-09-14 14:28:51 --> Database Driver Class Initialized
INFO - 2020-09-14 14:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:28:51 --> Email Class Initialized
INFO - 2020-09-14 14:28:51 --> Controller Class Initialized
INFO - 2020-09-14 14:28:51 --> Model Class Initialized
INFO - 2020-09-14 14:28:51 --> Model Class Initialized
DEBUG - 2020-09-14 14:28:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 14:28:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:28:51 --> Config Class Initialized
INFO - 2020-09-14 14:28:51 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:28:51 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:28:51 --> Utf8 Class Initialized
INFO - 2020-09-14 14:28:51 --> URI Class Initialized
INFO - 2020-09-14 14:28:51 --> Router Class Initialized
INFO - 2020-09-14 14:28:51 --> Output Class Initialized
INFO - 2020-09-14 14:28:51 --> Security Class Initialized
DEBUG - 2020-09-14 14:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:28:51 --> Input Class Initialized
INFO - 2020-09-14 14:28:51 --> Language Class Initialized
INFO - 2020-09-14 14:28:51 --> Loader Class Initialized
INFO - 2020-09-14 14:28:51 --> Helper loaded: url_helper
INFO - 2020-09-14 14:28:51 --> Database Driver Class Initialized
INFO - 2020-09-14 14:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:28:51 --> Email Class Initialized
INFO - 2020-09-14 14:28:51 --> Controller Class Initialized
DEBUG - 2020-09-14 14:28:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 14:28:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 14:28:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-14 14:28:51 --> Final output sent to browser
DEBUG - 2020-09-14 14:28:51 --> Total execution time: 0.0201
ERROR - 2020-09-14 14:30:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:30:26 --> Config Class Initialized
INFO - 2020-09-14 14:30:26 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:30:26 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:30:26 --> Utf8 Class Initialized
INFO - 2020-09-14 14:30:26 --> URI Class Initialized
INFO - 2020-09-14 14:30:26 --> Router Class Initialized
INFO - 2020-09-14 14:30:26 --> Output Class Initialized
INFO - 2020-09-14 14:30:26 --> Security Class Initialized
DEBUG - 2020-09-14 14:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:30:26 --> Input Class Initialized
INFO - 2020-09-14 14:30:26 --> Language Class Initialized
INFO - 2020-09-14 14:30:26 --> Loader Class Initialized
INFO - 2020-09-14 14:30:26 --> Helper loaded: url_helper
INFO - 2020-09-14 14:30:26 --> Database Driver Class Initialized
INFO - 2020-09-14 14:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:30:26 --> Email Class Initialized
INFO - 2020-09-14 14:30:26 --> Controller Class Initialized
DEBUG - 2020-09-14 14:30:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 14:30:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 14:30:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-14 14:30:26 --> Final output sent to browser
DEBUG - 2020-09-14 14:30:26 --> Total execution time: 0.0174
ERROR - 2020-09-14 14:30:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:30:31 --> Config Class Initialized
INFO - 2020-09-14 14:30:31 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:30:31 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:30:31 --> Utf8 Class Initialized
INFO - 2020-09-14 14:30:31 --> URI Class Initialized
INFO - 2020-09-14 14:30:31 --> Router Class Initialized
INFO - 2020-09-14 14:30:31 --> Output Class Initialized
INFO - 2020-09-14 14:30:31 --> Security Class Initialized
DEBUG - 2020-09-14 14:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:30:31 --> Input Class Initialized
INFO - 2020-09-14 14:30:31 --> Language Class Initialized
INFO - 2020-09-14 14:30:31 --> Loader Class Initialized
INFO - 2020-09-14 14:30:31 --> Helper loaded: url_helper
INFO - 2020-09-14 14:30:31 --> Database Driver Class Initialized
INFO - 2020-09-14 14:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:30:31 --> Email Class Initialized
INFO - 2020-09-14 14:30:31 --> Controller Class Initialized
DEBUG - 2020-09-14 14:30:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 14:30:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 14:30:31 --> Model Class Initialized
INFO - 2020-09-14 14:30:31 --> Model Class Initialized
INFO - 2020-09-14 14:30:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-14 14:30:31 --> Final output sent to browser
DEBUG - 2020-09-14 14:30:31 --> Total execution time: 0.0345
ERROR - 2020-09-14 14:31:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:31:06 --> Config Class Initialized
INFO - 2020-09-14 14:31:06 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:31:06 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:31:06 --> Utf8 Class Initialized
INFO - 2020-09-14 14:31:06 --> URI Class Initialized
INFO - 2020-09-14 14:31:06 --> Router Class Initialized
INFO - 2020-09-14 14:31:06 --> Output Class Initialized
INFO - 2020-09-14 14:31:06 --> Security Class Initialized
DEBUG - 2020-09-14 14:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:31:06 --> Input Class Initialized
INFO - 2020-09-14 14:31:06 --> Language Class Initialized
INFO - 2020-09-14 14:31:06 --> Loader Class Initialized
INFO - 2020-09-14 14:31:06 --> Helper loaded: url_helper
INFO - 2020-09-14 14:31:06 --> Database Driver Class Initialized
INFO - 2020-09-14 14:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:31:06 --> Email Class Initialized
INFO - 2020-09-14 14:31:06 --> Controller Class Initialized
DEBUG - 2020-09-14 14:31:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 14:31:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 14:31:06 --> Model Class Initialized
INFO - 2020-09-14 14:31:06 --> Model Class Initialized
INFO - 2020-09-14 14:31:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-14 14:31:06 --> Final output sent to browser
DEBUG - 2020-09-14 14:31:06 --> Total execution time: 0.0203
ERROR - 2020-09-14 14:31:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:31:09 --> Config Class Initialized
INFO - 2020-09-14 14:31:09 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:31:09 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:31:09 --> Utf8 Class Initialized
INFO - 2020-09-14 14:31:09 --> URI Class Initialized
INFO - 2020-09-14 14:31:09 --> Router Class Initialized
INFO - 2020-09-14 14:31:09 --> Output Class Initialized
INFO - 2020-09-14 14:31:09 --> Security Class Initialized
DEBUG - 2020-09-14 14:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:31:09 --> Input Class Initialized
INFO - 2020-09-14 14:31:09 --> Language Class Initialized
INFO - 2020-09-14 14:31:09 --> Loader Class Initialized
INFO - 2020-09-14 14:31:09 --> Helper loaded: url_helper
INFO - 2020-09-14 14:31:09 --> Database Driver Class Initialized
INFO - 2020-09-14 14:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:31:09 --> Email Class Initialized
INFO - 2020-09-14 14:31:09 --> Controller Class Initialized
DEBUG - 2020-09-14 14:31:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 14:31:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 14:31:09 --> Model Class Initialized
INFO - 2020-09-14 14:31:09 --> Model Class Initialized
INFO - 2020-09-14 14:31:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-14 14:31:09 --> Final output sent to browser
DEBUG - 2020-09-14 14:31:09 --> Total execution time: 0.0214
ERROR - 2020-09-14 14:31:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:31:13 --> Config Class Initialized
INFO - 2020-09-14 14:31:13 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:31:13 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:31:13 --> Utf8 Class Initialized
INFO - 2020-09-14 14:31:13 --> URI Class Initialized
INFO - 2020-09-14 14:31:13 --> Router Class Initialized
INFO - 2020-09-14 14:31:13 --> Output Class Initialized
INFO - 2020-09-14 14:31:13 --> Security Class Initialized
DEBUG - 2020-09-14 14:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:31:13 --> Input Class Initialized
INFO - 2020-09-14 14:31:13 --> Language Class Initialized
INFO - 2020-09-14 14:31:13 --> Loader Class Initialized
INFO - 2020-09-14 14:31:13 --> Helper loaded: url_helper
INFO - 2020-09-14 14:31:13 --> Database Driver Class Initialized
INFO - 2020-09-14 14:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:31:13 --> Email Class Initialized
INFO - 2020-09-14 14:31:13 --> Controller Class Initialized
DEBUG - 2020-09-14 14:31:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 14:31:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 14:31:13 --> Model Class Initialized
INFO - 2020-09-14 14:31:13 --> Model Class Initialized
INFO - 2020-09-14 14:31:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-14 14:31:13 --> Final output sent to browser
DEBUG - 2020-09-14 14:31:13 --> Total execution time: 0.0229
ERROR - 2020-09-14 14:31:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:31:38 --> Config Class Initialized
INFO - 2020-09-14 14:31:38 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:31:38 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:31:38 --> Utf8 Class Initialized
INFO - 2020-09-14 14:31:38 --> URI Class Initialized
DEBUG - 2020-09-14 14:31:38 --> No URI present. Default controller set.
INFO - 2020-09-14 14:31:38 --> Router Class Initialized
INFO - 2020-09-14 14:31:38 --> Output Class Initialized
INFO - 2020-09-14 14:31:38 --> Security Class Initialized
DEBUG - 2020-09-14 14:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:31:38 --> Input Class Initialized
INFO - 2020-09-14 14:31:38 --> Language Class Initialized
INFO - 2020-09-14 14:31:38 --> Loader Class Initialized
INFO - 2020-09-14 14:31:38 --> Helper loaded: url_helper
INFO - 2020-09-14 14:31:38 --> Database Driver Class Initialized
INFO - 2020-09-14 14:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:31:38 --> Email Class Initialized
INFO - 2020-09-14 14:31:38 --> Controller Class Initialized
INFO - 2020-09-14 14:31:38 --> Model Class Initialized
INFO - 2020-09-14 14:31:38 --> Model Class Initialized
DEBUG - 2020-09-14 14:31:38 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-14 14:31:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-14 14:31:38 --> Final output sent to browser
DEBUG - 2020-09-14 14:31:38 --> Total execution time: 0.0234
ERROR - 2020-09-14 14:31:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:31:50 --> Config Class Initialized
INFO - 2020-09-14 14:31:50 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:31:50 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:31:50 --> Utf8 Class Initialized
INFO - 2020-09-14 14:31:50 --> URI Class Initialized
INFO - 2020-09-14 14:31:50 --> Router Class Initialized
INFO - 2020-09-14 14:31:50 --> Output Class Initialized
INFO - 2020-09-14 14:31:50 --> Security Class Initialized
DEBUG - 2020-09-14 14:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:31:50 --> Input Class Initialized
INFO - 2020-09-14 14:31:50 --> Language Class Initialized
INFO - 2020-09-14 14:31:50 --> Loader Class Initialized
INFO - 2020-09-14 14:31:50 --> Helper loaded: url_helper
INFO - 2020-09-14 14:31:50 --> Database Driver Class Initialized
INFO - 2020-09-14 14:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:31:50 --> Email Class Initialized
INFO - 2020-09-14 14:31:50 --> Controller Class Initialized
INFO - 2020-09-14 14:31:50 --> Model Class Initialized
INFO - 2020-09-14 14:31:50 --> Model Class Initialized
DEBUG - 2020-09-14 14:31:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 14:31:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 14:31:50 --> Model Class Initialized
INFO - 2020-09-14 14:31:50 --> Final output sent to browser
DEBUG - 2020-09-14 14:31:50 --> Total execution time: 0.0196
ERROR - 2020-09-14 14:31:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:31:50 --> Config Class Initialized
INFO - 2020-09-14 14:31:50 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:31:50 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:31:50 --> Utf8 Class Initialized
INFO - 2020-09-14 14:31:50 --> URI Class Initialized
INFO - 2020-09-14 14:31:50 --> Router Class Initialized
INFO - 2020-09-14 14:31:50 --> Output Class Initialized
INFO - 2020-09-14 14:31:50 --> Security Class Initialized
DEBUG - 2020-09-14 14:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:31:50 --> Input Class Initialized
INFO - 2020-09-14 14:31:50 --> Language Class Initialized
INFO - 2020-09-14 14:31:50 --> Loader Class Initialized
INFO - 2020-09-14 14:31:50 --> Helper loaded: url_helper
INFO - 2020-09-14 14:31:50 --> Database Driver Class Initialized
INFO - 2020-09-14 14:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:31:50 --> Email Class Initialized
INFO - 2020-09-14 14:31:50 --> Controller Class Initialized
INFO - 2020-09-14 14:31:50 --> Model Class Initialized
INFO - 2020-09-14 14:31:50 --> Model Class Initialized
DEBUG - 2020-09-14 14:31:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 14:31:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:31:51 --> Config Class Initialized
INFO - 2020-09-14 14:31:51 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:31:51 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:31:51 --> Utf8 Class Initialized
INFO - 2020-09-14 14:31:51 --> URI Class Initialized
INFO - 2020-09-14 14:31:51 --> Router Class Initialized
INFO - 2020-09-14 14:31:51 --> Output Class Initialized
INFO - 2020-09-14 14:31:51 --> Security Class Initialized
DEBUG - 2020-09-14 14:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:31:51 --> Input Class Initialized
INFO - 2020-09-14 14:31:51 --> Language Class Initialized
INFO - 2020-09-14 14:31:51 --> Loader Class Initialized
INFO - 2020-09-14 14:31:51 --> Helper loaded: url_helper
INFO - 2020-09-14 14:31:51 --> Database Driver Class Initialized
INFO - 2020-09-14 14:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:31:51 --> Email Class Initialized
INFO - 2020-09-14 14:31:51 --> Controller Class Initialized
DEBUG - 2020-09-14 14:31:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 14:31:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 14:31:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-14 14:31:51 --> Final output sent to browser
DEBUG - 2020-09-14 14:31:51 --> Total execution time: 0.0206
ERROR - 2020-09-14 14:31:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:31:57 --> Config Class Initialized
INFO - 2020-09-14 14:31:57 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:31:57 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:31:57 --> Utf8 Class Initialized
INFO - 2020-09-14 14:31:57 --> URI Class Initialized
INFO - 2020-09-14 14:31:57 --> Router Class Initialized
INFO - 2020-09-14 14:31:57 --> Output Class Initialized
INFO - 2020-09-14 14:31:57 --> Security Class Initialized
DEBUG - 2020-09-14 14:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:31:57 --> Input Class Initialized
INFO - 2020-09-14 14:31:57 --> Language Class Initialized
INFO - 2020-09-14 14:31:57 --> Loader Class Initialized
INFO - 2020-09-14 14:31:57 --> Helper loaded: url_helper
INFO - 2020-09-14 14:31:57 --> Database Driver Class Initialized
INFO - 2020-09-14 14:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:31:57 --> Email Class Initialized
INFO - 2020-09-14 14:31:57 --> Controller Class Initialized
DEBUG - 2020-09-14 14:31:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 14:31:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 14:31:57 --> Model Class Initialized
INFO - 2020-09-14 14:31:57 --> Model Class Initialized
INFO - 2020-09-14 14:31:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-14 14:31:57 --> Final output sent to browser
DEBUG - 2020-09-14 14:31:57 --> Total execution time: 0.0259
ERROR - 2020-09-14 14:32:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:32:02 --> Config Class Initialized
INFO - 2020-09-14 14:32:02 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:32:02 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:32:02 --> Utf8 Class Initialized
INFO - 2020-09-14 14:32:02 --> URI Class Initialized
INFO - 2020-09-14 14:32:02 --> Router Class Initialized
INFO - 2020-09-14 14:32:02 --> Output Class Initialized
INFO - 2020-09-14 14:32:02 --> Security Class Initialized
DEBUG - 2020-09-14 14:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:32:02 --> Input Class Initialized
INFO - 2020-09-14 14:32:02 --> Language Class Initialized
INFO - 2020-09-14 14:32:02 --> Loader Class Initialized
INFO - 2020-09-14 14:32:02 --> Helper loaded: url_helper
INFO - 2020-09-14 14:32:02 --> Database Driver Class Initialized
INFO - 2020-09-14 14:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:32:02 --> Email Class Initialized
INFO - 2020-09-14 14:32:02 --> Controller Class Initialized
DEBUG - 2020-09-14 14:32:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 14:32:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 14:32:02 --> Model Class Initialized
INFO - 2020-09-14 14:32:02 --> Model Class Initialized
INFO - 2020-09-14 14:32:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-14 14:32:02 --> Final output sent to browser
DEBUG - 2020-09-14 14:32:02 --> Total execution time: 0.0234
ERROR - 2020-09-14 14:32:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:32:04 --> Config Class Initialized
INFO - 2020-09-14 14:32:04 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:32:04 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:32:04 --> Utf8 Class Initialized
INFO - 2020-09-14 14:32:04 --> URI Class Initialized
INFO - 2020-09-14 14:32:04 --> Router Class Initialized
INFO - 2020-09-14 14:32:04 --> Output Class Initialized
INFO - 2020-09-14 14:32:04 --> Security Class Initialized
DEBUG - 2020-09-14 14:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:32:04 --> Input Class Initialized
INFO - 2020-09-14 14:32:04 --> Language Class Initialized
INFO - 2020-09-14 14:32:04 --> Loader Class Initialized
INFO - 2020-09-14 14:32:04 --> Helper loaded: url_helper
INFO - 2020-09-14 14:32:04 --> Database Driver Class Initialized
INFO - 2020-09-14 14:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:32:04 --> Email Class Initialized
INFO - 2020-09-14 14:32:04 --> Controller Class Initialized
DEBUG - 2020-09-14 14:32:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 14:32:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 14:32:04 --> Model Class Initialized
INFO - 2020-09-14 14:32:04 --> Model Class Initialized
INFO - 2020-09-14 14:32:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-14 14:32:04 --> Final output sent to browser
DEBUG - 2020-09-14 14:32:04 --> Total execution time: 0.0234
ERROR - 2020-09-14 14:32:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:32:28 --> Config Class Initialized
INFO - 2020-09-14 14:32:28 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:32:28 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:32:28 --> Utf8 Class Initialized
INFO - 2020-09-14 14:32:28 --> URI Class Initialized
INFO - 2020-09-14 14:32:28 --> Router Class Initialized
INFO - 2020-09-14 14:32:28 --> Output Class Initialized
INFO - 2020-09-14 14:32:28 --> Security Class Initialized
DEBUG - 2020-09-14 14:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:32:28 --> Input Class Initialized
INFO - 2020-09-14 14:32:28 --> Language Class Initialized
INFO - 2020-09-14 14:32:28 --> Loader Class Initialized
INFO - 2020-09-14 14:32:28 --> Helper loaded: url_helper
INFO - 2020-09-14 14:32:28 --> Database Driver Class Initialized
INFO - 2020-09-14 14:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:32:28 --> Email Class Initialized
INFO - 2020-09-14 14:32:28 --> Controller Class Initialized
DEBUG - 2020-09-14 14:32:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 14:32:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 14:32:28 --> Model Class Initialized
INFO - 2020-09-14 14:32:28 --> Model Class Initialized
INFO - 2020-09-14 14:32:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-14 14:32:28 --> Final output sent to browser
DEBUG - 2020-09-14 14:32:28 --> Total execution time: 0.0224
ERROR - 2020-09-14 14:32:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:32:53 --> Config Class Initialized
INFO - 2020-09-14 14:32:53 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:32:53 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:32:53 --> Utf8 Class Initialized
INFO - 2020-09-14 14:32:53 --> URI Class Initialized
INFO - 2020-09-14 14:32:53 --> Router Class Initialized
INFO - 2020-09-14 14:32:53 --> Output Class Initialized
INFO - 2020-09-14 14:32:53 --> Security Class Initialized
DEBUG - 2020-09-14 14:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:32:53 --> Input Class Initialized
INFO - 2020-09-14 14:32:53 --> Language Class Initialized
INFO - 2020-09-14 14:32:53 --> Loader Class Initialized
INFO - 2020-09-14 14:32:53 --> Helper loaded: url_helper
INFO - 2020-09-14 14:32:53 --> Database Driver Class Initialized
INFO - 2020-09-14 14:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:32:53 --> Email Class Initialized
INFO - 2020-09-14 14:32:53 --> Controller Class Initialized
DEBUG - 2020-09-14 14:32:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 14:32:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 14:32:53 --> Model Class Initialized
INFO - 2020-09-14 14:32:53 --> Model Class Initialized
INFO - 2020-09-14 14:32:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-14 14:32:53 --> Final output sent to browser
DEBUG - 2020-09-14 14:32:53 --> Total execution time: 0.1312
ERROR - 2020-09-14 14:33:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:33:01 --> Config Class Initialized
INFO - 2020-09-14 14:33:01 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:33:01 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:33:01 --> Utf8 Class Initialized
INFO - 2020-09-14 14:33:01 --> URI Class Initialized
INFO - 2020-09-14 14:33:01 --> Router Class Initialized
INFO - 2020-09-14 14:33:01 --> Output Class Initialized
INFO - 2020-09-14 14:33:01 --> Security Class Initialized
DEBUG - 2020-09-14 14:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:33:01 --> Input Class Initialized
INFO - 2020-09-14 14:33:01 --> Language Class Initialized
INFO - 2020-09-14 14:33:01 --> Loader Class Initialized
INFO - 2020-09-14 14:33:01 --> Helper loaded: url_helper
INFO - 2020-09-14 14:33:01 --> Database Driver Class Initialized
INFO - 2020-09-14 14:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:33:01 --> Email Class Initialized
INFO - 2020-09-14 14:33:01 --> Controller Class Initialized
DEBUG - 2020-09-14 14:33:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 14:33:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 14:33:01 --> Model Class Initialized
INFO - 2020-09-14 14:33:01 --> Model Class Initialized
INFO - 2020-09-14 14:33:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-09-14 14:33:01 --> Final output sent to browser
DEBUG - 2020-09-14 14:33:01 --> Total execution time: 0.0457
ERROR - 2020-09-14 14:33:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:33:04 --> Config Class Initialized
INFO - 2020-09-14 14:33:04 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:33:04 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:33:04 --> Utf8 Class Initialized
INFO - 2020-09-14 14:33:04 --> URI Class Initialized
INFO - 2020-09-14 14:33:04 --> Router Class Initialized
INFO - 2020-09-14 14:33:04 --> Output Class Initialized
INFO - 2020-09-14 14:33:04 --> Security Class Initialized
DEBUG - 2020-09-14 14:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:33:04 --> Input Class Initialized
INFO - 2020-09-14 14:33:04 --> Language Class Initialized
INFO - 2020-09-14 14:33:04 --> Loader Class Initialized
INFO - 2020-09-14 14:33:04 --> Helper loaded: url_helper
INFO - 2020-09-14 14:33:04 --> Database Driver Class Initialized
INFO - 2020-09-14 14:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:33:04 --> Email Class Initialized
INFO - 2020-09-14 14:33:04 --> Controller Class Initialized
DEBUG - 2020-09-14 14:33:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 14:33:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 14:33:04 --> Model Class Initialized
INFO - 2020-09-14 14:33:04 --> Model Class Initialized
INFO - 2020-09-14 14:33:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-14 14:33:04 --> Final output sent to browser
DEBUG - 2020-09-14 14:33:04 --> Total execution time: 0.0262
ERROR - 2020-09-14 14:33:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:33:58 --> Config Class Initialized
INFO - 2020-09-14 14:33:58 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:33:58 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:33:58 --> Utf8 Class Initialized
INFO - 2020-09-14 14:33:58 --> URI Class Initialized
INFO - 2020-09-14 14:33:58 --> Router Class Initialized
INFO - 2020-09-14 14:33:58 --> Output Class Initialized
INFO - 2020-09-14 14:33:58 --> Security Class Initialized
DEBUG - 2020-09-14 14:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:33:58 --> Input Class Initialized
INFO - 2020-09-14 14:33:58 --> Language Class Initialized
INFO - 2020-09-14 14:33:58 --> Loader Class Initialized
INFO - 2020-09-14 14:33:58 --> Helper loaded: url_helper
INFO - 2020-09-14 14:33:58 --> Database Driver Class Initialized
INFO - 2020-09-14 14:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:33:58 --> Email Class Initialized
INFO - 2020-09-14 14:33:58 --> Controller Class Initialized
DEBUG - 2020-09-14 14:33:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 14:33:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 14:33:58 --> Model Class Initialized
INFO - 2020-09-14 14:33:58 --> Model Class Initialized
INFO - 2020-09-14 14:33:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-14 14:33:58 --> Final output sent to browser
DEBUG - 2020-09-14 14:33:58 --> Total execution time: 0.0242
ERROR - 2020-09-14 14:34:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:34:08 --> Config Class Initialized
INFO - 2020-09-14 14:34:08 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:34:08 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:34:08 --> Utf8 Class Initialized
INFO - 2020-09-14 14:34:08 --> URI Class Initialized
INFO - 2020-09-14 14:34:08 --> Router Class Initialized
INFO - 2020-09-14 14:34:08 --> Output Class Initialized
INFO - 2020-09-14 14:34:08 --> Security Class Initialized
DEBUG - 2020-09-14 14:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:34:08 --> Input Class Initialized
INFO - 2020-09-14 14:34:08 --> Language Class Initialized
INFO - 2020-09-14 14:34:08 --> Loader Class Initialized
INFO - 2020-09-14 14:34:08 --> Helper loaded: url_helper
INFO - 2020-09-14 14:34:08 --> Database Driver Class Initialized
INFO - 2020-09-14 14:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:34:08 --> Email Class Initialized
INFO - 2020-09-14 14:34:08 --> Controller Class Initialized
DEBUG - 2020-09-14 14:34:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 14:34:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 14:34:08 --> Model Class Initialized
INFO - 2020-09-14 14:34:08 --> Model Class Initialized
INFO - 2020-09-14 14:34:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-14 14:34:08 --> Final output sent to browser
DEBUG - 2020-09-14 14:34:08 --> Total execution time: 0.0960
ERROR - 2020-09-14 14:34:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:34:11 --> Config Class Initialized
INFO - 2020-09-14 14:34:11 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:34:11 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:34:11 --> Utf8 Class Initialized
INFO - 2020-09-14 14:34:11 --> URI Class Initialized
INFO - 2020-09-14 14:34:11 --> Router Class Initialized
INFO - 2020-09-14 14:34:11 --> Output Class Initialized
INFO - 2020-09-14 14:34:11 --> Security Class Initialized
DEBUG - 2020-09-14 14:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:34:11 --> Input Class Initialized
INFO - 2020-09-14 14:34:11 --> Language Class Initialized
INFO - 2020-09-14 14:34:11 --> Loader Class Initialized
INFO - 2020-09-14 14:34:11 --> Helper loaded: url_helper
INFO - 2020-09-14 14:34:11 --> Database Driver Class Initialized
INFO - 2020-09-14 14:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:34:11 --> Email Class Initialized
INFO - 2020-09-14 14:34:11 --> Controller Class Initialized
DEBUG - 2020-09-14 14:34:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 14:34:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 14:34:11 --> Model Class Initialized
INFO - 2020-09-14 14:34:11 --> Model Class Initialized
INFO - 2020-09-14 14:34:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-14 14:34:11 --> Final output sent to browser
DEBUG - 2020-09-14 14:34:11 --> Total execution time: 0.0225
ERROR - 2020-09-14 14:43:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:43:28 --> Config Class Initialized
INFO - 2020-09-14 14:43:28 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:43:28 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:43:28 --> Utf8 Class Initialized
INFO - 2020-09-14 14:43:28 --> URI Class Initialized
INFO - 2020-09-14 14:43:28 --> Router Class Initialized
INFO - 2020-09-14 14:43:28 --> Output Class Initialized
INFO - 2020-09-14 14:43:28 --> Security Class Initialized
DEBUG - 2020-09-14 14:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:43:28 --> Input Class Initialized
INFO - 2020-09-14 14:43:28 --> Language Class Initialized
INFO - 2020-09-14 14:43:28 --> Loader Class Initialized
INFO - 2020-09-14 14:43:28 --> Helper loaded: url_helper
INFO - 2020-09-14 14:43:28 --> Database Driver Class Initialized
INFO - 2020-09-14 14:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:43:28 --> Email Class Initialized
INFO - 2020-09-14 14:43:28 --> Controller Class Initialized
DEBUG - 2020-09-14 14:43:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 14:43:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 14:43:28 --> Model Class Initialized
INFO - 2020-09-14 14:43:28 --> Model Class Initialized
INFO - 2020-09-14 14:43:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-14 14:43:28 --> Final output sent to browser
DEBUG - 2020-09-14 14:43:28 --> Total execution time: 0.0217
ERROR - 2020-09-14 14:46:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:46:29 --> Config Class Initialized
INFO - 2020-09-14 14:46:29 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:46:29 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:46:29 --> Utf8 Class Initialized
INFO - 2020-09-14 14:46:29 --> URI Class Initialized
INFO - 2020-09-14 14:46:29 --> Router Class Initialized
INFO - 2020-09-14 14:46:29 --> Output Class Initialized
INFO - 2020-09-14 14:46:29 --> Security Class Initialized
DEBUG - 2020-09-14 14:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:46:29 --> Input Class Initialized
INFO - 2020-09-14 14:46:29 --> Language Class Initialized
INFO - 2020-09-14 14:46:29 --> Loader Class Initialized
INFO - 2020-09-14 14:46:29 --> Helper loaded: url_helper
INFO - 2020-09-14 14:46:29 --> Database Driver Class Initialized
INFO - 2020-09-14 14:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:46:29 --> Email Class Initialized
INFO - 2020-09-14 14:46:29 --> Controller Class Initialized
DEBUG - 2020-09-14 14:46:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 14:46:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 14:46:29 --> Model Class Initialized
INFO - 2020-09-14 14:46:29 --> Model Class Initialized
INFO - 2020-09-14 14:46:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-14 14:46:29 --> Final output sent to browser
DEBUG - 2020-09-14 14:46:29 --> Total execution time: 0.0268
ERROR - 2020-09-14 14:46:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 14:46:36 --> Config Class Initialized
INFO - 2020-09-14 14:46:36 --> Hooks Class Initialized
DEBUG - 2020-09-14 14:46:36 --> UTF-8 Support Enabled
INFO - 2020-09-14 14:46:36 --> Utf8 Class Initialized
INFO - 2020-09-14 14:46:36 --> URI Class Initialized
INFO - 2020-09-14 14:46:36 --> Router Class Initialized
INFO - 2020-09-14 14:46:36 --> Output Class Initialized
INFO - 2020-09-14 14:46:36 --> Security Class Initialized
DEBUG - 2020-09-14 14:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 14:46:36 --> Input Class Initialized
INFO - 2020-09-14 14:46:36 --> Language Class Initialized
INFO - 2020-09-14 14:46:36 --> Loader Class Initialized
INFO - 2020-09-14 14:46:36 --> Helper loaded: url_helper
INFO - 2020-09-14 14:46:36 --> Database Driver Class Initialized
INFO - 2020-09-14 14:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 14:46:36 --> Email Class Initialized
INFO - 2020-09-14 14:46:36 --> Controller Class Initialized
DEBUG - 2020-09-14 14:46:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 14:46:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 14:46:36 --> Model Class Initialized
INFO - 2020-09-14 14:46:36 --> Model Class Initialized
INFO - 2020-09-14 14:46:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-14 14:46:36 --> Final output sent to browser
DEBUG - 2020-09-14 14:46:36 --> Total execution time: 0.3546
ERROR - 2020-09-14 15:29:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 15:29:03 --> Config Class Initialized
INFO - 2020-09-14 15:29:03 --> Hooks Class Initialized
DEBUG - 2020-09-14 15:29:03 --> UTF-8 Support Enabled
INFO - 2020-09-14 15:29:03 --> Utf8 Class Initialized
INFO - 2020-09-14 15:29:03 --> URI Class Initialized
DEBUG - 2020-09-14 15:29:03 --> No URI present. Default controller set.
INFO - 2020-09-14 15:29:03 --> Router Class Initialized
INFO - 2020-09-14 15:29:03 --> Output Class Initialized
INFO - 2020-09-14 15:29:03 --> Security Class Initialized
DEBUG - 2020-09-14 15:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 15:29:03 --> Input Class Initialized
INFO - 2020-09-14 15:29:03 --> Language Class Initialized
INFO - 2020-09-14 15:29:03 --> Loader Class Initialized
INFO - 2020-09-14 15:29:03 --> Helper loaded: url_helper
INFO - 2020-09-14 15:29:03 --> Database Driver Class Initialized
INFO - 2020-09-14 15:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 15:29:03 --> Email Class Initialized
INFO - 2020-09-14 15:29:03 --> Controller Class Initialized
INFO - 2020-09-14 15:29:03 --> Model Class Initialized
INFO - 2020-09-14 15:29:03 --> Model Class Initialized
DEBUG - 2020-09-14 15:29:03 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-14 15:29:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-14 15:29:03 --> Final output sent to browser
DEBUG - 2020-09-14 15:29:03 --> Total execution time: 0.0298
ERROR - 2020-09-14 15:29:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 15:29:18 --> Config Class Initialized
INFO - 2020-09-14 15:29:18 --> Hooks Class Initialized
DEBUG - 2020-09-14 15:29:18 --> UTF-8 Support Enabled
INFO - 2020-09-14 15:29:18 --> Utf8 Class Initialized
INFO - 2020-09-14 15:29:18 --> URI Class Initialized
INFO - 2020-09-14 15:29:18 --> Router Class Initialized
INFO - 2020-09-14 15:29:18 --> Output Class Initialized
INFO - 2020-09-14 15:29:18 --> Security Class Initialized
DEBUG - 2020-09-14 15:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 15:29:18 --> Input Class Initialized
INFO - 2020-09-14 15:29:18 --> Language Class Initialized
INFO - 2020-09-14 15:29:18 --> Loader Class Initialized
INFO - 2020-09-14 15:29:18 --> Helper loaded: url_helper
INFO - 2020-09-14 15:29:18 --> Database Driver Class Initialized
INFO - 2020-09-14 15:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 15:29:18 --> Email Class Initialized
INFO - 2020-09-14 15:29:18 --> Controller Class Initialized
INFO - 2020-09-14 15:29:18 --> Model Class Initialized
INFO - 2020-09-14 15:29:18 --> Model Class Initialized
DEBUG - 2020-09-14 15:29:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 15:29:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 15:29:18 --> Model Class Initialized
INFO - 2020-09-14 15:29:18 --> Final output sent to browser
DEBUG - 2020-09-14 15:29:18 --> Total execution time: 0.0243
ERROR - 2020-09-14 15:29:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 15:29:18 --> Config Class Initialized
INFO - 2020-09-14 15:29:18 --> Hooks Class Initialized
DEBUG - 2020-09-14 15:29:18 --> UTF-8 Support Enabled
INFO - 2020-09-14 15:29:18 --> Utf8 Class Initialized
INFO - 2020-09-14 15:29:18 --> URI Class Initialized
INFO - 2020-09-14 15:29:18 --> Router Class Initialized
INFO - 2020-09-14 15:29:18 --> Output Class Initialized
INFO - 2020-09-14 15:29:18 --> Security Class Initialized
DEBUG - 2020-09-14 15:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 15:29:18 --> Input Class Initialized
INFO - 2020-09-14 15:29:18 --> Language Class Initialized
INFO - 2020-09-14 15:29:18 --> Loader Class Initialized
INFO - 2020-09-14 15:29:18 --> Helper loaded: url_helper
INFO - 2020-09-14 15:29:18 --> Database Driver Class Initialized
INFO - 2020-09-14 15:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 15:29:18 --> Email Class Initialized
INFO - 2020-09-14 15:29:18 --> Controller Class Initialized
INFO - 2020-09-14 15:29:18 --> Model Class Initialized
INFO - 2020-09-14 15:29:18 --> Model Class Initialized
DEBUG - 2020-09-14 15:29:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 15:29:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 15:29:18 --> Config Class Initialized
INFO - 2020-09-14 15:29:18 --> Hooks Class Initialized
DEBUG - 2020-09-14 15:29:18 --> UTF-8 Support Enabled
INFO - 2020-09-14 15:29:18 --> Utf8 Class Initialized
INFO - 2020-09-14 15:29:18 --> URI Class Initialized
INFO - 2020-09-14 15:29:18 --> Router Class Initialized
INFO - 2020-09-14 15:29:18 --> Output Class Initialized
INFO - 2020-09-14 15:29:18 --> Security Class Initialized
DEBUG - 2020-09-14 15:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 15:29:18 --> Input Class Initialized
INFO - 2020-09-14 15:29:18 --> Language Class Initialized
INFO - 2020-09-14 15:29:18 --> Loader Class Initialized
INFO - 2020-09-14 15:29:18 --> Helper loaded: url_helper
INFO - 2020-09-14 15:29:18 --> Database Driver Class Initialized
INFO - 2020-09-14 15:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 15:29:18 --> Email Class Initialized
INFO - 2020-09-14 15:29:18 --> Controller Class Initialized
DEBUG - 2020-09-14 15:29:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 15:29:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 15:29:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-14 15:29:18 --> Final output sent to browser
DEBUG - 2020-09-14 15:29:18 --> Total execution time: 0.0202
ERROR - 2020-09-14 15:29:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 15:29:30 --> Config Class Initialized
INFO - 2020-09-14 15:29:30 --> Hooks Class Initialized
DEBUG - 2020-09-14 15:29:30 --> UTF-8 Support Enabled
INFO - 2020-09-14 15:29:30 --> Utf8 Class Initialized
INFO - 2020-09-14 15:29:30 --> URI Class Initialized
DEBUG - 2020-09-14 15:29:30 --> No URI present. Default controller set.
INFO - 2020-09-14 15:29:30 --> Router Class Initialized
INFO - 2020-09-14 15:29:30 --> Output Class Initialized
INFO - 2020-09-14 15:29:30 --> Security Class Initialized
DEBUG - 2020-09-14 15:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 15:29:30 --> Input Class Initialized
INFO - 2020-09-14 15:29:30 --> Language Class Initialized
INFO - 2020-09-14 15:29:30 --> Loader Class Initialized
INFO - 2020-09-14 15:29:30 --> Helper loaded: url_helper
INFO - 2020-09-14 15:29:30 --> Database Driver Class Initialized
INFO - 2020-09-14 15:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 15:29:30 --> Email Class Initialized
INFO - 2020-09-14 15:29:30 --> Controller Class Initialized
INFO - 2020-09-14 15:29:30 --> Model Class Initialized
INFO - 2020-09-14 15:29:30 --> Model Class Initialized
DEBUG - 2020-09-14 15:29:30 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-14 15:29:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-14 15:29:30 --> Final output sent to browser
DEBUG - 2020-09-14 15:29:30 --> Total execution time: 0.0197
ERROR - 2020-09-14 15:29:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 15:29:33 --> Config Class Initialized
INFO - 2020-09-14 15:29:33 --> Hooks Class Initialized
DEBUG - 2020-09-14 15:29:33 --> UTF-8 Support Enabled
INFO - 2020-09-14 15:29:33 --> Utf8 Class Initialized
INFO - 2020-09-14 15:29:33 --> URI Class Initialized
INFO - 2020-09-14 15:29:33 --> Router Class Initialized
INFO - 2020-09-14 15:29:33 --> Output Class Initialized
INFO - 2020-09-14 15:29:33 --> Security Class Initialized
DEBUG - 2020-09-14 15:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 15:29:33 --> Input Class Initialized
INFO - 2020-09-14 15:29:33 --> Language Class Initialized
INFO - 2020-09-14 15:29:33 --> Loader Class Initialized
INFO - 2020-09-14 15:29:33 --> Helper loaded: url_helper
INFO - 2020-09-14 15:29:33 --> Database Driver Class Initialized
INFO - 2020-09-14 15:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 15:29:33 --> Email Class Initialized
INFO - 2020-09-14 15:29:33 --> Controller Class Initialized
INFO - 2020-09-14 15:29:33 --> Model Class Initialized
INFO - 2020-09-14 15:29:33 --> Model Class Initialized
DEBUG - 2020-09-14 15:29:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 15:29:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 15:29:33 --> Model Class Initialized
INFO - 2020-09-14 15:29:33 --> Final output sent to browser
DEBUG - 2020-09-14 15:29:33 --> Total execution time: 0.0214
ERROR - 2020-09-14 15:29:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 15:29:33 --> Config Class Initialized
INFO - 2020-09-14 15:29:33 --> Hooks Class Initialized
DEBUG - 2020-09-14 15:29:33 --> UTF-8 Support Enabled
INFO - 2020-09-14 15:29:33 --> Utf8 Class Initialized
INFO - 2020-09-14 15:29:33 --> URI Class Initialized
INFO - 2020-09-14 15:29:33 --> Router Class Initialized
INFO - 2020-09-14 15:29:33 --> Output Class Initialized
INFO - 2020-09-14 15:29:33 --> Security Class Initialized
DEBUG - 2020-09-14 15:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 15:29:33 --> Input Class Initialized
INFO - 2020-09-14 15:29:33 --> Language Class Initialized
INFO - 2020-09-14 15:29:33 --> Loader Class Initialized
INFO - 2020-09-14 15:29:33 --> Helper loaded: url_helper
INFO - 2020-09-14 15:29:33 --> Database Driver Class Initialized
INFO - 2020-09-14 15:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 15:29:33 --> Email Class Initialized
INFO - 2020-09-14 15:29:33 --> Controller Class Initialized
INFO - 2020-09-14 15:29:33 --> Model Class Initialized
INFO - 2020-09-14 15:29:33 --> Model Class Initialized
DEBUG - 2020-09-14 15:29:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 15:29:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 15:29:33 --> Config Class Initialized
INFO - 2020-09-14 15:29:33 --> Hooks Class Initialized
DEBUG - 2020-09-14 15:29:33 --> UTF-8 Support Enabled
INFO - 2020-09-14 15:29:33 --> Utf8 Class Initialized
INFO - 2020-09-14 15:29:33 --> URI Class Initialized
INFO - 2020-09-14 15:29:33 --> Router Class Initialized
INFO - 2020-09-14 15:29:33 --> Output Class Initialized
INFO - 2020-09-14 15:29:33 --> Security Class Initialized
DEBUG - 2020-09-14 15:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 15:29:33 --> Input Class Initialized
INFO - 2020-09-14 15:29:33 --> Language Class Initialized
INFO - 2020-09-14 15:29:33 --> Loader Class Initialized
INFO - 2020-09-14 15:29:33 --> Helper loaded: url_helper
INFO - 2020-09-14 15:29:33 --> Database Driver Class Initialized
INFO - 2020-09-14 15:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 15:29:33 --> Email Class Initialized
INFO - 2020-09-14 15:29:33 --> Controller Class Initialized
DEBUG - 2020-09-14 15:29:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 15:29:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 15:29:33 --> Model Class Initialized
INFO - 2020-09-14 15:29:33 --> Model Class Initialized
INFO - 2020-09-14 15:29:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 15:29:33 --> Final output sent to browser
DEBUG - 2020-09-14 15:29:33 --> Total execution time: 0.0193
ERROR - 2020-09-14 15:33:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 15:33:23 --> Config Class Initialized
INFO - 2020-09-14 15:33:23 --> Hooks Class Initialized
DEBUG - 2020-09-14 15:33:23 --> UTF-8 Support Enabled
INFO - 2020-09-14 15:33:23 --> Utf8 Class Initialized
INFO - 2020-09-14 15:33:23 --> URI Class Initialized
INFO - 2020-09-14 15:33:23 --> Router Class Initialized
INFO - 2020-09-14 15:33:23 --> Output Class Initialized
INFO - 2020-09-14 15:33:23 --> Security Class Initialized
DEBUG - 2020-09-14 15:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 15:33:23 --> Input Class Initialized
INFO - 2020-09-14 15:33:23 --> Language Class Initialized
INFO - 2020-09-14 15:33:23 --> Loader Class Initialized
INFO - 2020-09-14 15:33:23 --> Helper loaded: url_helper
INFO - 2020-09-14 15:33:23 --> Database Driver Class Initialized
INFO - 2020-09-14 15:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 15:33:23 --> Email Class Initialized
INFO - 2020-09-14 15:33:23 --> Controller Class Initialized
DEBUG - 2020-09-14 15:33:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 15:33:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 15:33:23 --> Model Class Initialized
INFO - 2020-09-14 15:33:23 --> Model Class Initialized
INFO - 2020-09-14 15:33:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 15:33:23 --> Final output sent to browser
DEBUG - 2020-09-14 15:33:23 --> Total execution time: 0.0242
ERROR - 2020-09-14 15:34:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 15:34:06 --> Config Class Initialized
INFO - 2020-09-14 15:34:06 --> Hooks Class Initialized
DEBUG - 2020-09-14 15:34:06 --> UTF-8 Support Enabled
INFO - 2020-09-14 15:34:06 --> Utf8 Class Initialized
INFO - 2020-09-14 15:34:06 --> URI Class Initialized
INFO - 2020-09-14 15:34:06 --> Router Class Initialized
INFO - 2020-09-14 15:34:06 --> Output Class Initialized
INFO - 2020-09-14 15:34:06 --> Security Class Initialized
DEBUG - 2020-09-14 15:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 15:34:06 --> Input Class Initialized
INFO - 2020-09-14 15:34:06 --> Language Class Initialized
INFO - 2020-09-14 15:34:06 --> Loader Class Initialized
INFO - 2020-09-14 15:34:06 --> Helper loaded: url_helper
INFO - 2020-09-14 15:34:06 --> Database Driver Class Initialized
INFO - 2020-09-14 15:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 15:34:06 --> Email Class Initialized
INFO - 2020-09-14 15:34:06 --> Controller Class Initialized
DEBUG - 2020-09-14 15:34:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 15:34:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 15:34:06 --> Model Class Initialized
INFO - 2020-09-14 15:34:06 --> Model Class Initialized
INFO - 2020-09-14 15:34:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 15:34:06 --> Final output sent to browser
DEBUG - 2020-09-14 15:34:06 --> Total execution time: 0.0216
ERROR - 2020-09-14 15:37:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 15:37:16 --> Config Class Initialized
INFO - 2020-09-14 15:37:16 --> Hooks Class Initialized
DEBUG - 2020-09-14 15:37:16 --> UTF-8 Support Enabled
INFO - 2020-09-14 15:37:16 --> Utf8 Class Initialized
INFO - 2020-09-14 15:37:16 --> URI Class Initialized
INFO - 2020-09-14 15:37:16 --> Router Class Initialized
INFO - 2020-09-14 15:37:16 --> Output Class Initialized
INFO - 2020-09-14 15:37:16 --> Security Class Initialized
DEBUG - 2020-09-14 15:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 15:37:16 --> Input Class Initialized
INFO - 2020-09-14 15:37:16 --> Language Class Initialized
INFO - 2020-09-14 15:37:16 --> Loader Class Initialized
INFO - 2020-09-14 15:37:16 --> Helper loaded: url_helper
INFO - 2020-09-14 15:37:16 --> Database Driver Class Initialized
INFO - 2020-09-14 15:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 15:37:16 --> Email Class Initialized
INFO - 2020-09-14 15:37:16 --> Controller Class Initialized
DEBUG - 2020-09-14 15:37:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 15:37:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 15:37:16 --> Model Class Initialized
INFO - 2020-09-14 15:37:16 --> Model Class Initialized
INFO - 2020-09-14 15:37:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 15:37:16 --> Final output sent to browser
DEBUG - 2020-09-14 15:37:16 --> Total execution time: 0.0207
ERROR - 2020-09-14 15:43:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 15:43:03 --> Config Class Initialized
INFO - 2020-09-14 15:43:03 --> Hooks Class Initialized
DEBUG - 2020-09-14 15:43:03 --> UTF-8 Support Enabled
INFO - 2020-09-14 15:43:03 --> Utf8 Class Initialized
INFO - 2020-09-14 15:43:03 --> URI Class Initialized
INFO - 2020-09-14 15:43:03 --> Router Class Initialized
INFO - 2020-09-14 15:43:03 --> Output Class Initialized
INFO - 2020-09-14 15:43:03 --> Security Class Initialized
DEBUG - 2020-09-14 15:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 15:43:03 --> Input Class Initialized
INFO - 2020-09-14 15:43:03 --> Language Class Initialized
INFO - 2020-09-14 15:43:03 --> Loader Class Initialized
INFO - 2020-09-14 15:43:03 --> Helper loaded: url_helper
INFO - 2020-09-14 15:43:03 --> Database Driver Class Initialized
INFO - 2020-09-14 15:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 15:43:03 --> Email Class Initialized
INFO - 2020-09-14 15:43:03 --> Controller Class Initialized
DEBUG - 2020-09-14 15:43:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 15:43:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 15:43:03 --> Model Class Initialized
INFO - 2020-09-14 15:43:03 --> Model Class Initialized
INFO - 2020-09-14 15:43:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 15:43:03 --> Final output sent to browser
DEBUG - 2020-09-14 15:43:03 --> Total execution time: 0.0218
ERROR - 2020-09-14 15:43:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 15:43:06 --> Config Class Initialized
INFO - 2020-09-14 15:43:06 --> Hooks Class Initialized
DEBUG - 2020-09-14 15:43:06 --> UTF-8 Support Enabled
INFO - 2020-09-14 15:43:06 --> Utf8 Class Initialized
INFO - 2020-09-14 15:43:06 --> URI Class Initialized
INFO - 2020-09-14 15:43:06 --> Router Class Initialized
INFO - 2020-09-14 15:43:06 --> Output Class Initialized
INFO - 2020-09-14 15:43:06 --> Security Class Initialized
DEBUG - 2020-09-14 15:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 15:43:06 --> Input Class Initialized
INFO - 2020-09-14 15:43:06 --> Language Class Initialized
INFO - 2020-09-14 15:43:06 --> Loader Class Initialized
INFO - 2020-09-14 15:43:06 --> Helper loaded: url_helper
INFO - 2020-09-14 15:43:06 --> Database Driver Class Initialized
INFO - 2020-09-14 15:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 15:43:06 --> Email Class Initialized
INFO - 2020-09-14 15:43:06 --> Controller Class Initialized
DEBUG - 2020-09-14 15:43:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 15:43:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 15:43:06 --> Model Class Initialized
INFO - 2020-09-14 15:43:06 --> Model Class Initialized
ERROR - 2020-09-14 15:43:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Sale_rep.php:50) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-09-14 15:43:06 --> Severity: Error --> Call to undefined method Sale_model::sale_rep_list() /home/purpu1ex/public_html/carsm/application/controllers/Sale_rep.php 50
ERROR - 2020-09-14 15:44:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 15:44:34 --> Config Class Initialized
INFO - 2020-09-14 15:44:34 --> Hooks Class Initialized
DEBUG - 2020-09-14 15:44:34 --> UTF-8 Support Enabled
INFO - 2020-09-14 15:44:34 --> Utf8 Class Initialized
INFO - 2020-09-14 15:44:34 --> URI Class Initialized
INFO - 2020-09-14 15:44:34 --> Router Class Initialized
INFO - 2020-09-14 15:44:34 --> Output Class Initialized
INFO - 2020-09-14 15:44:34 --> Security Class Initialized
DEBUG - 2020-09-14 15:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 15:44:34 --> Input Class Initialized
INFO - 2020-09-14 15:44:34 --> Language Class Initialized
INFO - 2020-09-14 15:44:34 --> Loader Class Initialized
INFO - 2020-09-14 15:44:34 --> Helper loaded: url_helper
INFO - 2020-09-14 15:44:34 --> Database Driver Class Initialized
INFO - 2020-09-14 15:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 15:44:34 --> Email Class Initialized
INFO - 2020-09-14 15:44:34 --> Controller Class Initialized
DEBUG - 2020-09-14 15:44:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 15:44:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 15:44:34 --> Model Class Initialized
INFO - 2020-09-14 15:44:34 --> Model Class Initialized
INFO - 2020-09-14 15:44:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 15:44:34 --> Final output sent to browser
DEBUG - 2020-09-14 15:44:34 --> Total execution time: 0.0265
ERROR - 2020-09-14 15:46:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 15:46:25 --> Config Class Initialized
INFO - 2020-09-14 15:46:25 --> Hooks Class Initialized
DEBUG - 2020-09-14 15:46:25 --> UTF-8 Support Enabled
INFO - 2020-09-14 15:46:25 --> Utf8 Class Initialized
INFO - 2020-09-14 15:46:25 --> URI Class Initialized
INFO - 2020-09-14 15:46:25 --> Router Class Initialized
INFO - 2020-09-14 15:46:25 --> Output Class Initialized
INFO - 2020-09-14 15:46:25 --> Security Class Initialized
DEBUG - 2020-09-14 15:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 15:46:25 --> Input Class Initialized
INFO - 2020-09-14 15:46:25 --> Language Class Initialized
INFO - 2020-09-14 15:46:25 --> Loader Class Initialized
INFO - 2020-09-14 15:46:25 --> Helper loaded: url_helper
INFO - 2020-09-14 15:46:25 --> Database Driver Class Initialized
INFO - 2020-09-14 15:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 15:46:25 --> Email Class Initialized
INFO - 2020-09-14 15:46:25 --> Controller Class Initialized
DEBUG - 2020-09-14 15:46:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 15:46:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 15:46:25 --> Model Class Initialized
INFO - 2020-09-14 15:46:25 --> Model Class Initialized
INFO - 2020-09-14 15:46:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 15:46:25 --> Final output sent to browser
DEBUG - 2020-09-14 15:46:25 --> Total execution time: 0.0224
ERROR - 2020-09-14 15:50:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 15:50:56 --> Config Class Initialized
INFO - 2020-09-14 15:50:56 --> Hooks Class Initialized
DEBUG - 2020-09-14 15:50:56 --> UTF-8 Support Enabled
INFO - 2020-09-14 15:50:56 --> Utf8 Class Initialized
INFO - 2020-09-14 15:50:56 --> URI Class Initialized
INFO - 2020-09-14 15:50:56 --> Router Class Initialized
INFO - 2020-09-14 15:50:56 --> Output Class Initialized
INFO - 2020-09-14 15:50:56 --> Security Class Initialized
DEBUG - 2020-09-14 15:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 15:50:56 --> Input Class Initialized
INFO - 2020-09-14 15:50:56 --> Language Class Initialized
INFO - 2020-09-14 15:50:56 --> Loader Class Initialized
INFO - 2020-09-14 15:50:56 --> Helper loaded: url_helper
INFO - 2020-09-14 15:50:56 --> Database Driver Class Initialized
INFO - 2020-09-14 15:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 15:50:56 --> Email Class Initialized
INFO - 2020-09-14 15:50:56 --> Controller Class Initialized
DEBUG - 2020-09-14 15:50:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 15:50:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 15:50:56 --> Model Class Initialized
INFO - 2020-09-14 15:50:56 --> Model Class Initialized
INFO - 2020-09-14 15:50:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 15:50:56 --> Final output sent to browser
DEBUG - 2020-09-14 15:50:56 --> Total execution time: 0.0213
ERROR - 2020-09-14 15:51:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 15:51:05 --> Config Class Initialized
INFO - 2020-09-14 15:51:05 --> Hooks Class Initialized
DEBUG - 2020-09-14 15:51:05 --> UTF-8 Support Enabled
INFO - 2020-09-14 15:51:05 --> Utf8 Class Initialized
INFO - 2020-09-14 15:51:05 --> URI Class Initialized
INFO - 2020-09-14 15:51:05 --> Router Class Initialized
INFO - 2020-09-14 15:51:05 --> Output Class Initialized
INFO - 2020-09-14 15:51:05 --> Security Class Initialized
DEBUG - 2020-09-14 15:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 15:51:05 --> Input Class Initialized
INFO - 2020-09-14 15:51:05 --> Language Class Initialized
INFO - 2020-09-14 15:51:05 --> Loader Class Initialized
INFO - 2020-09-14 15:51:05 --> Helper loaded: url_helper
INFO - 2020-09-14 15:51:05 --> Database Driver Class Initialized
INFO - 2020-09-14 15:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 15:51:05 --> Email Class Initialized
INFO - 2020-09-14 15:51:05 --> Controller Class Initialized
DEBUG - 2020-09-14 15:51:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 15:51:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 15:51:05 --> Model Class Initialized
INFO - 2020-09-14 15:51:05 --> Model Class Initialized
INFO - 2020-09-14 15:51:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 15:51:05 --> Final output sent to browser
DEBUG - 2020-09-14 15:51:05 --> Total execution time: 0.0210
ERROR - 2020-09-14 15:56:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 15:56:38 --> Config Class Initialized
INFO - 2020-09-14 15:56:38 --> Hooks Class Initialized
DEBUG - 2020-09-14 15:56:38 --> UTF-8 Support Enabled
INFO - 2020-09-14 15:56:38 --> Utf8 Class Initialized
INFO - 2020-09-14 15:56:38 --> URI Class Initialized
INFO - 2020-09-14 15:56:38 --> Router Class Initialized
INFO - 2020-09-14 15:56:38 --> Output Class Initialized
INFO - 2020-09-14 15:56:38 --> Security Class Initialized
DEBUG - 2020-09-14 15:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 15:56:38 --> Input Class Initialized
INFO - 2020-09-14 15:56:38 --> Language Class Initialized
INFO - 2020-09-14 15:56:38 --> Loader Class Initialized
INFO - 2020-09-14 15:56:38 --> Helper loaded: url_helper
INFO - 2020-09-14 15:56:38 --> Database Driver Class Initialized
INFO - 2020-09-14 15:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 15:56:38 --> Email Class Initialized
INFO - 2020-09-14 15:56:38 --> Controller Class Initialized
DEBUG - 2020-09-14 15:56:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 15:56:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 15:56:38 --> Model Class Initialized
INFO - 2020-09-14 15:56:38 --> Model Class Initialized
INFO - 2020-09-14 15:56:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 15:56:38 --> Final output sent to browser
DEBUG - 2020-09-14 15:56:38 --> Total execution time: 0.0240
ERROR - 2020-09-14 15:57:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 15:57:22 --> Config Class Initialized
INFO - 2020-09-14 15:57:22 --> Hooks Class Initialized
DEBUG - 2020-09-14 15:57:22 --> UTF-8 Support Enabled
INFO - 2020-09-14 15:57:22 --> Utf8 Class Initialized
INFO - 2020-09-14 15:57:22 --> URI Class Initialized
INFO - 2020-09-14 15:57:22 --> Router Class Initialized
INFO - 2020-09-14 15:57:22 --> Output Class Initialized
INFO - 2020-09-14 15:57:22 --> Security Class Initialized
DEBUG - 2020-09-14 15:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 15:57:22 --> Input Class Initialized
INFO - 2020-09-14 15:57:22 --> Language Class Initialized
INFO - 2020-09-14 15:57:22 --> Loader Class Initialized
INFO - 2020-09-14 15:57:22 --> Helper loaded: url_helper
INFO - 2020-09-14 15:57:22 --> Database Driver Class Initialized
INFO - 2020-09-14 15:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 15:57:22 --> Email Class Initialized
INFO - 2020-09-14 15:57:22 --> Controller Class Initialized
DEBUG - 2020-09-14 15:57:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 15:57:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 15:57:22 --> Model Class Initialized
INFO - 2020-09-14 15:57:22 --> Model Class Initialized
INFO - 2020-09-14 15:57:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 15:57:22 --> Final output sent to browser
DEBUG - 2020-09-14 15:57:22 --> Total execution time: 0.0229
ERROR - 2020-09-14 15:57:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 15:57:27 --> Config Class Initialized
INFO - 2020-09-14 15:57:27 --> Hooks Class Initialized
DEBUG - 2020-09-14 15:57:27 --> UTF-8 Support Enabled
INFO - 2020-09-14 15:57:27 --> Utf8 Class Initialized
INFO - 2020-09-14 15:57:27 --> URI Class Initialized
INFO - 2020-09-14 15:57:27 --> Router Class Initialized
INFO - 2020-09-14 15:57:27 --> Output Class Initialized
INFO - 2020-09-14 15:57:27 --> Security Class Initialized
DEBUG - 2020-09-14 15:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 15:57:27 --> Input Class Initialized
INFO - 2020-09-14 15:57:27 --> Language Class Initialized
INFO - 2020-09-14 15:57:27 --> Loader Class Initialized
INFO - 2020-09-14 15:57:27 --> Helper loaded: url_helper
INFO - 2020-09-14 15:57:27 --> Database Driver Class Initialized
INFO - 2020-09-14 15:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 15:57:27 --> Email Class Initialized
INFO - 2020-09-14 15:57:27 --> Controller Class Initialized
DEBUG - 2020-09-14 15:57:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 15:57:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 15:57:27 --> Model Class Initialized
INFO - 2020-09-14 15:57:27 --> Model Class Initialized
INFO - 2020-09-14 15:57:27 --> Model Class Initialized
INFO - 2020-09-14 15:57:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-14 15:57:27 --> Final output sent to browser
DEBUG - 2020-09-14 15:57:27 --> Total execution time: 0.0216
ERROR - 2020-09-14 15:57:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 15:57:48 --> Config Class Initialized
INFO - 2020-09-14 15:57:48 --> Hooks Class Initialized
DEBUG - 2020-09-14 15:57:48 --> UTF-8 Support Enabled
INFO - 2020-09-14 15:57:48 --> Utf8 Class Initialized
INFO - 2020-09-14 15:57:48 --> URI Class Initialized
INFO - 2020-09-14 15:57:48 --> Router Class Initialized
INFO - 2020-09-14 15:57:48 --> Output Class Initialized
INFO - 2020-09-14 15:57:48 --> Security Class Initialized
DEBUG - 2020-09-14 15:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 15:57:48 --> Input Class Initialized
INFO - 2020-09-14 15:57:48 --> Language Class Initialized
INFO - 2020-09-14 15:57:48 --> Loader Class Initialized
INFO - 2020-09-14 15:57:48 --> Helper loaded: url_helper
INFO - 2020-09-14 15:57:48 --> Database Driver Class Initialized
INFO - 2020-09-14 15:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 15:57:48 --> Email Class Initialized
INFO - 2020-09-14 15:57:48 --> Controller Class Initialized
DEBUG - 2020-09-14 15:57:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 15:57:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 15:57:48 --> Model Class Initialized
INFO - 2020-09-14 15:57:48 --> Model Class Initialized
INFO - 2020-09-14 15:57:48 --> Model Class Initialized
INFO - 2020-09-14 15:57:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-14 15:57:48 --> Final output sent to browser
DEBUG - 2020-09-14 15:57:48 --> Total execution time: 0.0214
ERROR - 2020-09-14 15:57:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 15:57:51 --> Config Class Initialized
INFO - 2020-09-14 15:57:51 --> Hooks Class Initialized
DEBUG - 2020-09-14 15:57:51 --> UTF-8 Support Enabled
INFO - 2020-09-14 15:57:51 --> Utf8 Class Initialized
INFO - 2020-09-14 15:57:51 --> URI Class Initialized
INFO - 2020-09-14 15:57:51 --> Router Class Initialized
INFO - 2020-09-14 15:57:51 --> Output Class Initialized
INFO - 2020-09-14 15:57:51 --> Security Class Initialized
DEBUG - 2020-09-14 15:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 15:57:51 --> Input Class Initialized
INFO - 2020-09-14 15:57:51 --> Language Class Initialized
INFO - 2020-09-14 15:57:51 --> Loader Class Initialized
INFO - 2020-09-14 15:57:51 --> Helper loaded: url_helper
INFO - 2020-09-14 15:57:51 --> Database Driver Class Initialized
INFO - 2020-09-14 15:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 15:57:51 --> Email Class Initialized
INFO - 2020-09-14 15:57:51 --> Controller Class Initialized
DEBUG - 2020-09-14 15:57:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 15:57:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 15:57:51 --> Model Class Initialized
INFO - 2020-09-14 15:57:51 --> Model Class Initialized
INFO - 2020-09-14 15:57:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 15:57:51 --> Final output sent to browser
DEBUG - 2020-09-14 15:57:51 --> Total execution time: 0.0228
ERROR - 2020-09-14 15:57:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 15:57:54 --> Config Class Initialized
INFO - 2020-09-14 15:57:54 --> Hooks Class Initialized
DEBUG - 2020-09-14 15:57:54 --> UTF-8 Support Enabled
INFO - 2020-09-14 15:57:54 --> Utf8 Class Initialized
INFO - 2020-09-14 15:57:54 --> URI Class Initialized
INFO - 2020-09-14 15:57:54 --> Router Class Initialized
INFO - 2020-09-14 15:57:54 --> Output Class Initialized
INFO - 2020-09-14 15:57:54 --> Security Class Initialized
DEBUG - 2020-09-14 15:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 15:57:54 --> Input Class Initialized
INFO - 2020-09-14 15:57:54 --> Language Class Initialized
INFO - 2020-09-14 15:57:54 --> Loader Class Initialized
INFO - 2020-09-14 15:57:54 --> Helper loaded: url_helper
INFO - 2020-09-14 15:57:54 --> Database Driver Class Initialized
INFO - 2020-09-14 15:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 15:57:54 --> Email Class Initialized
INFO - 2020-09-14 15:57:54 --> Controller Class Initialized
DEBUG - 2020-09-14 15:57:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 15:57:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 15:57:54 --> Model Class Initialized
INFO - 2020-09-14 15:57:54 --> Model Class Initialized
INFO - 2020-09-14 15:57:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 15:57:54 --> Final output sent to browser
DEBUG - 2020-09-14 15:57:54 --> Total execution time: 0.0226
ERROR - 2020-09-14 15:57:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 15:57:57 --> Config Class Initialized
INFO - 2020-09-14 15:57:57 --> Hooks Class Initialized
DEBUG - 2020-09-14 15:57:57 --> UTF-8 Support Enabled
INFO - 2020-09-14 15:57:57 --> Utf8 Class Initialized
INFO - 2020-09-14 15:57:57 --> URI Class Initialized
INFO - 2020-09-14 15:57:57 --> Router Class Initialized
INFO - 2020-09-14 15:57:57 --> Output Class Initialized
INFO - 2020-09-14 15:57:57 --> Security Class Initialized
DEBUG - 2020-09-14 15:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 15:57:57 --> Input Class Initialized
INFO - 2020-09-14 15:57:57 --> Language Class Initialized
INFO - 2020-09-14 15:57:57 --> Loader Class Initialized
INFO - 2020-09-14 15:57:57 --> Helper loaded: url_helper
INFO - 2020-09-14 15:57:57 --> Database Driver Class Initialized
INFO - 2020-09-14 15:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 15:57:57 --> Email Class Initialized
INFO - 2020-09-14 15:57:57 --> Controller Class Initialized
DEBUG - 2020-09-14 15:57:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 15:57:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 15:57:57 --> Model Class Initialized
INFO - 2020-09-14 15:57:57 --> Model Class Initialized
INFO - 2020-09-14 15:57:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 15:57:57 --> Final output sent to browser
DEBUG - 2020-09-14 15:57:57 --> Total execution time: 0.0241
ERROR - 2020-09-14 15:58:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 15:58:02 --> Config Class Initialized
INFO - 2020-09-14 15:58:02 --> Hooks Class Initialized
DEBUG - 2020-09-14 15:58:02 --> UTF-8 Support Enabled
INFO - 2020-09-14 15:58:02 --> Utf8 Class Initialized
INFO - 2020-09-14 15:58:02 --> URI Class Initialized
INFO - 2020-09-14 15:58:02 --> Router Class Initialized
INFO - 2020-09-14 15:58:02 --> Output Class Initialized
INFO - 2020-09-14 15:58:02 --> Security Class Initialized
DEBUG - 2020-09-14 15:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 15:58:02 --> Input Class Initialized
INFO - 2020-09-14 15:58:02 --> Language Class Initialized
INFO - 2020-09-14 15:58:02 --> Loader Class Initialized
INFO - 2020-09-14 15:58:02 --> Helper loaded: url_helper
INFO - 2020-09-14 15:58:02 --> Database Driver Class Initialized
INFO - 2020-09-14 15:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 15:58:02 --> Email Class Initialized
INFO - 2020-09-14 15:58:02 --> Controller Class Initialized
DEBUG - 2020-09-14 15:58:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 15:58:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 15:58:02 --> Model Class Initialized
INFO - 2020-09-14 15:58:02 --> Model Class Initialized
INFO - 2020-09-14 15:58:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 15:58:02 --> Final output sent to browser
DEBUG - 2020-09-14 15:58:02 --> Total execution time: 0.0238
ERROR - 2020-09-14 15:58:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 15:58:05 --> Config Class Initialized
INFO - 2020-09-14 15:58:05 --> Hooks Class Initialized
DEBUG - 2020-09-14 15:58:05 --> UTF-8 Support Enabled
INFO - 2020-09-14 15:58:05 --> Utf8 Class Initialized
INFO - 2020-09-14 15:58:05 --> URI Class Initialized
INFO - 2020-09-14 15:58:05 --> Router Class Initialized
INFO - 2020-09-14 15:58:05 --> Output Class Initialized
INFO - 2020-09-14 15:58:05 --> Security Class Initialized
DEBUG - 2020-09-14 15:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 15:58:05 --> Input Class Initialized
INFO - 2020-09-14 15:58:05 --> Language Class Initialized
INFO - 2020-09-14 15:58:05 --> Loader Class Initialized
INFO - 2020-09-14 15:58:05 --> Helper loaded: url_helper
INFO - 2020-09-14 15:58:05 --> Database Driver Class Initialized
INFO - 2020-09-14 15:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 15:58:05 --> Email Class Initialized
INFO - 2020-09-14 15:58:05 --> Controller Class Initialized
DEBUG - 2020-09-14 15:58:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 15:58:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 15:58:05 --> Model Class Initialized
INFO - 2020-09-14 15:58:05 --> Model Class Initialized
INFO - 2020-09-14 15:58:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 15:58:05 --> Final output sent to browser
DEBUG - 2020-09-14 15:58:05 --> Total execution time: 0.0199
ERROR - 2020-09-14 15:58:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 15:58:06 --> Config Class Initialized
INFO - 2020-09-14 15:58:06 --> Hooks Class Initialized
DEBUG - 2020-09-14 15:58:06 --> UTF-8 Support Enabled
INFO - 2020-09-14 15:58:06 --> Utf8 Class Initialized
INFO - 2020-09-14 15:58:06 --> URI Class Initialized
INFO - 2020-09-14 15:58:06 --> Router Class Initialized
INFO - 2020-09-14 15:58:06 --> Output Class Initialized
INFO - 2020-09-14 15:58:06 --> Security Class Initialized
DEBUG - 2020-09-14 15:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 15:58:06 --> Input Class Initialized
INFO - 2020-09-14 15:58:06 --> Language Class Initialized
INFO - 2020-09-14 15:58:06 --> Loader Class Initialized
INFO - 2020-09-14 15:58:06 --> Helper loaded: url_helper
INFO - 2020-09-14 15:58:06 --> Database Driver Class Initialized
INFO - 2020-09-14 15:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 15:58:06 --> Email Class Initialized
INFO - 2020-09-14 15:58:06 --> Controller Class Initialized
DEBUG - 2020-09-14 15:58:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 15:58:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 15:58:06 --> Model Class Initialized
INFO - 2020-09-14 15:58:06 --> Model Class Initialized
INFO - 2020-09-14 15:58:06 --> Model Class Initialized
INFO - 2020-09-14 15:58:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-14 15:58:06 --> Final output sent to browser
DEBUG - 2020-09-14 15:58:06 --> Total execution time: 0.0220
ERROR - 2020-09-14 15:59:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 15:59:09 --> Config Class Initialized
INFO - 2020-09-14 15:59:09 --> Hooks Class Initialized
DEBUG - 2020-09-14 15:59:09 --> UTF-8 Support Enabled
INFO - 2020-09-14 15:59:09 --> Utf8 Class Initialized
INFO - 2020-09-14 15:59:09 --> URI Class Initialized
INFO - 2020-09-14 15:59:09 --> Router Class Initialized
INFO - 2020-09-14 15:59:09 --> Output Class Initialized
INFO - 2020-09-14 15:59:09 --> Security Class Initialized
DEBUG - 2020-09-14 15:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 15:59:09 --> Input Class Initialized
INFO - 2020-09-14 15:59:09 --> Language Class Initialized
INFO - 2020-09-14 15:59:09 --> Loader Class Initialized
INFO - 2020-09-14 15:59:09 --> Helper loaded: url_helper
INFO - 2020-09-14 15:59:09 --> Database Driver Class Initialized
INFO - 2020-09-14 15:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 15:59:09 --> Email Class Initialized
INFO - 2020-09-14 15:59:09 --> Controller Class Initialized
DEBUG - 2020-09-14 15:59:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 15:59:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 15:59:09 --> Model Class Initialized
INFO - 2020-09-14 15:59:09 --> Model Class Initialized
INFO - 2020-09-14 15:59:09 --> Model Class Initialized
INFO - 2020-09-14 15:59:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-14 15:59:09 --> Final output sent to browser
DEBUG - 2020-09-14 15:59:09 --> Total execution time: 0.0234
ERROR - 2020-09-14 15:59:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 15:59:12 --> Config Class Initialized
INFO - 2020-09-14 15:59:12 --> Hooks Class Initialized
DEBUG - 2020-09-14 15:59:12 --> UTF-8 Support Enabled
INFO - 2020-09-14 15:59:12 --> Utf8 Class Initialized
INFO - 2020-09-14 15:59:12 --> URI Class Initialized
INFO - 2020-09-14 15:59:12 --> Router Class Initialized
INFO - 2020-09-14 15:59:12 --> Output Class Initialized
INFO - 2020-09-14 15:59:12 --> Security Class Initialized
DEBUG - 2020-09-14 15:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 15:59:12 --> Input Class Initialized
INFO - 2020-09-14 15:59:12 --> Language Class Initialized
INFO - 2020-09-14 15:59:12 --> Loader Class Initialized
INFO - 2020-09-14 15:59:12 --> Helper loaded: url_helper
INFO - 2020-09-14 15:59:12 --> Database Driver Class Initialized
INFO - 2020-09-14 15:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 15:59:12 --> Email Class Initialized
INFO - 2020-09-14 15:59:12 --> Controller Class Initialized
DEBUG - 2020-09-14 15:59:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 15:59:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 15:59:12 --> Model Class Initialized
INFO - 2020-09-14 15:59:12 --> Model Class Initialized
INFO - 2020-09-14 15:59:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 15:59:12 --> Final output sent to browser
DEBUG - 2020-09-14 15:59:12 --> Total execution time: 0.0231
ERROR - 2020-09-14 15:59:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 15:59:14 --> Config Class Initialized
INFO - 2020-09-14 15:59:14 --> Hooks Class Initialized
DEBUG - 2020-09-14 15:59:14 --> UTF-8 Support Enabled
INFO - 2020-09-14 15:59:14 --> Utf8 Class Initialized
INFO - 2020-09-14 15:59:14 --> URI Class Initialized
INFO - 2020-09-14 15:59:14 --> Router Class Initialized
INFO - 2020-09-14 15:59:14 --> Output Class Initialized
INFO - 2020-09-14 15:59:14 --> Security Class Initialized
DEBUG - 2020-09-14 15:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 15:59:14 --> Input Class Initialized
INFO - 2020-09-14 15:59:14 --> Language Class Initialized
INFO - 2020-09-14 15:59:14 --> Loader Class Initialized
INFO - 2020-09-14 15:59:14 --> Helper loaded: url_helper
INFO - 2020-09-14 15:59:14 --> Database Driver Class Initialized
INFO - 2020-09-14 15:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 15:59:14 --> Email Class Initialized
INFO - 2020-09-14 15:59:14 --> Controller Class Initialized
DEBUG - 2020-09-14 15:59:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 15:59:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 15:59:14 --> Model Class Initialized
INFO - 2020-09-14 15:59:14 --> Model Class Initialized
INFO - 2020-09-14 15:59:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 15:59:14 --> Final output sent to browser
DEBUG - 2020-09-14 15:59:14 --> Total execution time: 0.0208
ERROR - 2020-09-14 15:59:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 15:59:16 --> Config Class Initialized
INFO - 2020-09-14 15:59:16 --> Hooks Class Initialized
DEBUG - 2020-09-14 15:59:16 --> UTF-8 Support Enabled
INFO - 2020-09-14 15:59:16 --> Utf8 Class Initialized
INFO - 2020-09-14 15:59:16 --> URI Class Initialized
INFO - 2020-09-14 15:59:16 --> Router Class Initialized
INFO - 2020-09-14 15:59:16 --> Output Class Initialized
INFO - 2020-09-14 15:59:16 --> Security Class Initialized
DEBUG - 2020-09-14 15:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 15:59:16 --> Input Class Initialized
INFO - 2020-09-14 15:59:16 --> Language Class Initialized
INFO - 2020-09-14 15:59:16 --> Loader Class Initialized
INFO - 2020-09-14 15:59:16 --> Helper loaded: url_helper
INFO - 2020-09-14 15:59:16 --> Database Driver Class Initialized
INFO - 2020-09-14 15:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 15:59:16 --> Email Class Initialized
INFO - 2020-09-14 15:59:16 --> Controller Class Initialized
DEBUG - 2020-09-14 15:59:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 15:59:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 15:59:16 --> Model Class Initialized
INFO - 2020-09-14 15:59:16 --> Model Class Initialized
INFO - 2020-09-14 15:59:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-09-14 15:59:16 --> Final output sent to browser
DEBUG - 2020-09-14 15:59:16 --> Total execution time: 0.0207
ERROR - 2020-09-14 16:02:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:02:56 --> Config Class Initialized
INFO - 2020-09-14 16:02:56 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:02:56 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:02:56 --> Utf8 Class Initialized
INFO - 2020-09-14 16:02:56 --> URI Class Initialized
INFO - 2020-09-14 16:02:56 --> Router Class Initialized
INFO - 2020-09-14 16:02:56 --> Output Class Initialized
INFO - 2020-09-14 16:02:56 --> Security Class Initialized
DEBUG - 2020-09-14 16:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:02:56 --> Input Class Initialized
INFO - 2020-09-14 16:02:56 --> Language Class Initialized
INFO - 2020-09-14 16:02:56 --> Loader Class Initialized
INFO - 2020-09-14 16:02:56 --> Helper loaded: url_helper
INFO - 2020-09-14 16:02:56 --> Database Driver Class Initialized
INFO - 2020-09-14 16:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:02:56 --> Email Class Initialized
INFO - 2020-09-14 16:02:56 --> Controller Class Initialized
DEBUG - 2020-09-14 16:02:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:02:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:02:56 --> Model Class Initialized
INFO - 2020-09-14 16:02:56 --> Model Class Initialized
INFO - 2020-09-14 16:02:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-09-14 16:02:56 --> Final output sent to browser
DEBUG - 2020-09-14 16:02:56 --> Total execution time: 0.0222
ERROR - 2020-09-14 16:03:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:03:25 --> Config Class Initialized
INFO - 2020-09-14 16:03:25 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:03:25 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:03:25 --> Utf8 Class Initialized
INFO - 2020-09-14 16:03:25 --> URI Class Initialized
INFO - 2020-09-14 16:03:25 --> Router Class Initialized
INFO - 2020-09-14 16:03:25 --> Output Class Initialized
INFO - 2020-09-14 16:03:25 --> Security Class Initialized
DEBUG - 2020-09-14 16:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:03:25 --> Input Class Initialized
INFO - 2020-09-14 16:03:25 --> Language Class Initialized
INFO - 2020-09-14 16:03:25 --> Loader Class Initialized
INFO - 2020-09-14 16:03:25 --> Helper loaded: url_helper
INFO - 2020-09-14 16:03:25 --> Database Driver Class Initialized
INFO - 2020-09-14 16:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:03:25 --> Email Class Initialized
INFO - 2020-09-14 16:03:25 --> Controller Class Initialized
DEBUG - 2020-09-14 16:03:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:03:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:03:25 --> Model Class Initialized
INFO - 2020-09-14 16:03:25 --> Model Class Initialized
INFO - 2020-09-14 16:03:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-09-14 16:03:25 --> Final output sent to browser
DEBUG - 2020-09-14 16:03:25 --> Total execution time: 0.0203
ERROR - 2020-09-14 16:07:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:07:50 --> Config Class Initialized
INFO - 2020-09-14 16:07:50 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:07:50 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:07:50 --> Utf8 Class Initialized
INFO - 2020-09-14 16:07:50 --> URI Class Initialized
INFO - 2020-09-14 16:07:50 --> Router Class Initialized
INFO - 2020-09-14 16:07:50 --> Output Class Initialized
INFO - 2020-09-14 16:07:50 --> Security Class Initialized
DEBUG - 2020-09-14 16:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:07:50 --> Input Class Initialized
INFO - 2020-09-14 16:07:50 --> Language Class Initialized
INFO - 2020-09-14 16:07:50 --> Loader Class Initialized
INFO - 2020-09-14 16:07:50 --> Helper loaded: url_helper
INFO - 2020-09-14 16:07:50 --> Database Driver Class Initialized
INFO - 2020-09-14 16:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:07:50 --> Email Class Initialized
INFO - 2020-09-14 16:07:50 --> Controller Class Initialized
DEBUG - 2020-09-14 16:07:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:07:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:07:50 --> Model Class Initialized
INFO - 2020-09-14 16:07:50 --> Model Class Initialized
INFO - 2020-09-14 16:07:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 16:07:50 --> Final output sent to browser
DEBUG - 2020-09-14 16:07:50 --> Total execution time: 0.0211
ERROR - 2020-09-14 16:08:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:08:09 --> Config Class Initialized
INFO - 2020-09-14 16:08:09 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:08:09 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:08:09 --> Utf8 Class Initialized
INFO - 2020-09-14 16:08:09 --> URI Class Initialized
INFO - 2020-09-14 16:08:09 --> Router Class Initialized
INFO - 2020-09-14 16:08:09 --> Output Class Initialized
INFO - 2020-09-14 16:08:09 --> Security Class Initialized
DEBUG - 2020-09-14 16:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:08:09 --> Input Class Initialized
INFO - 2020-09-14 16:08:09 --> Language Class Initialized
INFO - 2020-09-14 16:08:09 --> Loader Class Initialized
INFO - 2020-09-14 16:08:09 --> Helper loaded: url_helper
INFO - 2020-09-14 16:08:09 --> Database Driver Class Initialized
INFO - 2020-09-14 16:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:08:09 --> Email Class Initialized
INFO - 2020-09-14 16:08:09 --> Controller Class Initialized
DEBUG - 2020-09-14 16:08:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:08:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:08:09 --> Model Class Initialized
INFO - 2020-09-14 16:08:09 --> Model Class Initialized
INFO - 2020-09-14 16:08:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 16:08:09 --> Final output sent to browser
DEBUG - 2020-09-14 16:08:09 --> Total execution time: 0.0195
ERROR - 2020-09-14 16:08:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:08:12 --> Config Class Initialized
INFO - 2020-09-14 16:08:12 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:08:12 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:08:12 --> Utf8 Class Initialized
INFO - 2020-09-14 16:08:12 --> URI Class Initialized
INFO - 2020-09-14 16:08:12 --> Router Class Initialized
INFO - 2020-09-14 16:08:12 --> Output Class Initialized
INFO - 2020-09-14 16:08:12 --> Security Class Initialized
DEBUG - 2020-09-14 16:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:08:12 --> Input Class Initialized
INFO - 2020-09-14 16:08:12 --> Language Class Initialized
INFO - 2020-09-14 16:08:12 --> Loader Class Initialized
INFO - 2020-09-14 16:08:12 --> Helper loaded: url_helper
INFO - 2020-09-14 16:08:12 --> Database Driver Class Initialized
INFO - 2020-09-14 16:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:08:12 --> Email Class Initialized
INFO - 2020-09-14 16:08:12 --> Controller Class Initialized
DEBUG - 2020-09-14 16:08:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:08:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:08:12 --> Model Class Initialized
INFO - 2020-09-14 16:08:12 --> Model Class Initialized
INFO - 2020-09-14 16:08:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-09-14 16:08:12 --> Final output sent to browser
DEBUG - 2020-09-14 16:08:12 --> Total execution time: 0.0188
ERROR - 2020-09-14 16:22:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:22:48 --> Config Class Initialized
INFO - 2020-09-14 16:22:48 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:22:48 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:22:48 --> Utf8 Class Initialized
INFO - 2020-09-14 16:22:48 --> URI Class Initialized
INFO - 2020-09-14 16:22:48 --> Router Class Initialized
INFO - 2020-09-14 16:22:48 --> Output Class Initialized
INFO - 2020-09-14 16:22:48 --> Security Class Initialized
DEBUG - 2020-09-14 16:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:22:48 --> Input Class Initialized
INFO - 2020-09-14 16:22:48 --> Language Class Initialized
INFO - 2020-09-14 16:22:48 --> Loader Class Initialized
INFO - 2020-09-14 16:22:48 --> Helper loaded: url_helper
INFO - 2020-09-14 16:22:48 --> Database Driver Class Initialized
INFO - 2020-09-14 16:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:22:48 --> Email Class Initialized
INFO - 2020-09-14 16:22:48 --> Controller Class Initialized
DEBUG - 2020-09-14 16:22:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:22:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:22:48 --> Model Class Initialized
INFO - 2020-09-14 16:22:48 --> Model Class Initialized
INFO - 2020-09-14 16:22:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-09-14 16:22:48 --> Final output sent to browser
DEBUG - 2020-09-14 16:22:48 --> Total execution time: 0.0416
ERROR - 2020-09-14 16:23:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:23:11 --> Config Class Initialized
INFO - 2020-09-14 16:23:11 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:23:11 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:23:11 --> Utf8 Class Initialized
INFO - 2020-09-14 16:23:11 --> URI Class Initialized
INFO - 2020-09-14 16:23:11 --> Router Class Initialized
INFO - 2020-09-14 16:23:11 --> Output Class Initialized
INFO - 2020-09-14 16:23:11 --> Security Class Initialized
DEBUG - 2020-09-14 16:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:23:11 --> Input Class Initialized
INFO - 2020-09-14 16:23:11 --> Language Class Initialized
INFO - 2020-09-14 16:23:11 --> Loader Class Initialized
INFO - 2020-09-14 16:23:11 --> Helper loaded: url_helper
INFO - 2020-09-14 16:23:11 --> Database Driver Class Initialized
INFO - 2020-09-14 16:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:23:11 --> Email Class Initialized
INFO - 2020-09-14 16:23:11 --> Controller Class Initialized
DEBUG - 2020-09-14 16:23:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:23:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:23:11 --> Model Class Initialized
INFO - 2020-09-14 16:23:11 --> Model Class Initialized
INFO - 2020-09-14 16:23:11 --> Model Class Initialized
INFO - 2020-09-14 16:23:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 16:23:11 --> Final output sent to browser
DEBUG - 2020-09-14 16:23:11 --> Total execution time: 0.0710
ERROR - 2020-09-14 16:27:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:27:10 --> Config Class Initialized
INFO - 2020-09-14 16:27:10 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:27:10 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:27:10 --> Utf8 Class Initialized
INFO - 2020-09-14 16:27:10 --> URI Class Initialized
INFO - 2020-09-14 16:27:10 --> Router Class Initialized
INFO - 2020-09-14 16:27:10 --> Output Class Initialized
INFO - 2020-09-14 16:27:10 --> Security Class Initialized
DEBUG - 2020-09-14 16:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:27:10 --> Input Class Initialized
INFO - 2020-09-14 16:27:10 --> Language Class Initialized
INFO - 2020-09-14 16:27:10 --> Loader Class Initialized
INFO - 2020-09-14 16:27:10 --> Helper loaded: url_helper
INFO - 2020-09-14 16:27:10 --> Database Driver Class Initialized
INFO - 2020-09-14 16:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:27:10 --> Email Class Initialized
INFO - 2020-09-14 16:27:10 --> Controller Class Initialized
DEBUG - 2020-09-14 16:27:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:27:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:27:10 --> Model Class Initialized
INFO - 2020-09-14 16:27:10 --> Model Class Initialized
INFO - 2020-09-14 16:27:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-09-14 16:27:10 --> Final output sent to browser
DEBUG - 2020-09-14 16:27:10 --> Total execution time: 0.0213
ERROR - 2020-09-14 16:27:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:27:29 --> Config Class Initialized
INFO - 2020-09-14 16:27:29 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:27:29 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:27:29 --> Utf8 Class Initialized
INFO - 2020-09-14 16:27:29 --> URI Class Initialized
INFO - 2020-09-14 16:27:29 --> Router Class Initialized
INFO - 2020-09-14 16:27:29 --> Output Class Initialized
INFO - 2020-09-14 16:27:29 --> Security Class Initialized
DEBUG - 2020-09-14 16:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:27:29 --> Input Class Initialized
INFO - 2020-09-14 16:27:29 --> Language Class Initialized
INFO - 2020-09-14 16:27:29 --> Loader Class Initialized
INFO - 2020-09-14 16:27:29 --> Helper loaded: url_helper
INFO - 2020-09-14 16:27:29 --> Database Driver Class Initialized
INFO - 2020-09-14 16:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:27:29 --> Email Class Initialized
INFO - 2020-09-14 16:27:29 --> Controller Class Initialized
DEBUG - 2020-09-14 16:27:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:27:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:27:29 --> Model Class Initialized
INFO - 2020-09-14 16:27:29 --> Model Class Initialized
INFO - 2020-09-14 16:27:29 --> Model Class Initialized
INFO - 2020-09-14 16:27:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 16:27:30 --> Final output sent to browser
DEBUG - 2020-09-14 16:27:30 --> Total execution time: 0.0670
ERROR - 2020-09-14 16:36:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:36:57 --> Config Class Initialized
INFO - 2020-09-14 16:36:57 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:36:57 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:36:57 --> Utf8 Class Initialized
INFO - 2020-09-14 16:36:57 --> URI Class Initialized
INFO - 2020-09-14 16:36:57 --> Router Class Initialized
INFO - 2020-09-14 16:36:57 --> Output Class Initialized
INFO - 2020-09-14 16:36:57 --> Security Class Initialized
DEBUG - 2020-09-14 16:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:36:57 --> Input Class Initialized
INFO - 2020-09-14 16:36:57 --> Language Class Initialized
INFO - 2020-09-14 16:36:57 --> Loader Class Initialized
INFO - 2020-09-14 16:36:57 --> Helper loaded: url_helper
INFO - 2020-09-14 16:36:57 --> Database Driver Class Initialized
INFO - 2020-09-14 16:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:36:57 --> Email Class Initialized
INFO - 2020-09-14 16:36:57 --> Controller Class Initialized
DEBUG - 2020-09-14 16:36:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:36:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:36:57 --> Model Class Initialized
INFO - 2020-09-14 16:36:57 --> Model Class Initialized
INFO - 2020-09-14 16:36:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-09-14 16:36:57 --> Final output sent to browser
DEBUG - 2020-09-14 16:36:57 --> Total execution time: 0.0210
ERROR - 2020-09-14 16:37:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:37:19 --> Config Class Initialized
INFO - 2020-09-14 16:37:19 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:37:19 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:37:19 --> Utf8 Class Initialized
INFO - 2020-09-14 16:37:19 --> URI Class Initialized
INFO - 2020-09-14 16:37:19 --> Router Class Initialized
INFO - 2020-09-14 16:37:19 --> Output Class Initialized
INFO - 2020-09-14 16:37:19 --> Security Class Initialized
DEBUG - 2020-09-14 16:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:37:19 --> Input Class Initialized
INFO - 2020-09-14 16:37:19 --> Language Class Initialized
INFO - 2020-09-14 16:37:19 --> Loader Class Initialized
INFO - 2020-09-14 16:37:19 --> Helper loaded: url_helper
INFO - 2020-09-14 16:37:19 --> Database Driver Class Initialized
INFO - 2020-09-14 16:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:37:19 --> Email Class Initialized
INFO - 2020-09-14 16:37:19 --> Controller Class Initialized
DEBUG - 2020-09-14 16:37:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:37:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:37:19 --> Model Class Initialized
INFO - 2020-09-14 16:37:19 --> Model Class Initialized
INFO - 2020-09-14 16:37:19 --> Model Class Initialized
INFO - 2020-09-14 16:37:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 16:37:19 --> Final output sent to browser
DEBUG - 2020-09-14 16:37:19 --> Total execution time: 0.0772
ERROR - 2020-09-14 16:47:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:47:26 --> Config Class Initialized
INFO - 2020-09-14 16:47:26 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:47:26 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:47:26 --> Utf8 Class Initialized
INFO - 2020-09-14 16:47:26 --> URI Class Initialized
INFO - 2020-09-14 16:47:26 --> Router Class Initialized
INFO - 2020-09-14 16:47:26 --> Output Class Initialized
INFO - 2020-09-14 16:47:26 --> Security Class Initialized
DEBUG - 2020-09-14 16:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:47:26 --> Input Class Initialized
INFO - 2020-09-14 16:47:26 --> Language Class Initialized
INFO - 2020-09-14 16:47:26 --> Loader Class Initialized
INFO - 2020-09-14 16:47:26 --> Helper loaded: url_helper
INFO - 2020-09-14 16:47:26 --> Database Driver Class Initialized
INFO - 2020-09-14 16:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:47:26 --> Email Class Initialized
INFO - 2020-09-14 16:47:26 --> Controller Class Initialized
DEBUG - 2020-09-14 16:47:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:47:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:47:26 --> Model Class Initialized
INFO - 2020-09-14 16:47:26 --> Model Class Initialized
INFO - 2020-09-14 16:47:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 16:47:26 --> Final output sent to browser
DEBUG - 2020-09-14 16:47:26 --> Total execution time: 0.0214
ERROR - 2020-09-14 16:47:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:47:29 --> Config Class Initialized
INFO - 2020-09-14 16:47:29 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:47:29 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:47:29 --> Utf8 Class Initialized
INFO - 2020-09-14 16:47:29 --> URI Class Initialized
INFO - 2020-09-14 16:47:29 --> Router Class Initialized
INFO - 2020-09-14 16:47:29 --> Output Class Initialized
INFO - 2020-09-14 16:47:29 --> Security Class Initialized
DEBUG - 2020-09-14 16:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:47:29 --> Input Class Initialized
INFO - 2020-09-14 16:47:29 --> Language Class Initialized
ERROR - 2020-09-14 16:47:29 --> 404 Page Not Found: Sale_rep/campain_view
ERROR - 2020-09-14 16:48:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:48:04 --> Config Class Initialized
INFO - 2020-09-14 16:48:04 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:48:04 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:48:04 --> Utf8 Class Initialized
INFO - 2020-09-14 16:48:04 --> URI Class Initialized
INFO - 2020-09-14 16:48:04 --> Router Class Initialized
INFO - 2020-09-14 16:48:04 --> Output Class Initialized
INFO - 2020-09-14 16:48:04 --> Security Class Initialized
DEBUG - 2020-09-14 16:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:48:04 --> Input Class Initialized
INFO - 2020-09-14 16:48:04 --> Language Class Initialized
INFO - 2020-09-14 16:48:04 --> Loader Class Initialized
INFO - 2020-09-14 16:48:04 --> Helper loaded: url_helper
INFO - 2020-09-14 16:48:04 --> Database Driver Class Initialized
INFO - 2020-09-14 16:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:48:04 --> Email Class Initialized
INFO - 2020-09-14 16:48:04 --> Controller Class Initialized
DEBUG - 2020-09-14 16:48:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:48:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:48:04 --> Model Class Initialized
INFO - 2020-09-14 16:48:04 --> Model Class Initialized
INFO - 2020-09-14 16:48:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 16:48:04 --> Final output sent to browser
DEBUG - 2020-09-14 16:48:04 --> Total execution time: 0.0205
ERROR - 2020-09-14 16:48:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:48:07 --> Config Class Initialized
INFO - 2020-09-14 16:48:07 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:48:07 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:48:07 --> Utf8 Class Initialized
INFO - 2020-09-14 16:48:07 --> URI Class Initialized
INFO - 2020-09-14 16:48:07 --> Router Class Initialized
INFO - 2020-09-14 16:48:07 --> Output Class Initialized
INFO - 2020-09-14 16:48:07 --> Security Class Initialized
DEBUG - 2020-09-14 16:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:48:07 --> Input Class Initialized
INFO - 2020-09-14 16:48:07 --> Language Class Initialized
INFO - 2020-09-14 16:48:07 --> Loader Class Initialized
INFO - 2020-09-14 16:48:07 --> Helper loaded: url_helper
INFO - 2020-09-14 16:48:07 --> Database Driver Class Initialized
INFO - 2020-09-14 16:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:48:07 --> Email Class Initialized
INFO - 2020-09-14 16:48:07 --> Controller Class Initialized
DEBUG - 2020-09-14 16:48:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:48:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:48:07 --> Model Class Initialized
INFO - 2020-09-14 16:48:07 --> Model Class Initialized
INFO - 2020-09-14 16:48:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 16:48:07 --> Final output sent to browser
DEBUG - 2020-09-14 16:48:07 --> Total execution time: 0.0237
ERROR - 2020-09-14 16:48:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:48:10 --> Config Class Initialized
INFO - 2020-09-14 16:48:10 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:48:10 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:48:10 --> Utf8 Class Initialized
INFO - 2020-09-14 16:48:10 --> URI Class Initialized
INFO - 2020-09-14 16:48:10 --> Router Class Initialized
INFO - 2020-09-14 16:48:10 --> Output Class Initialized
INFO - 2020-09-14 16:48:10 --> Security Class Initialized
DEBUG - 2020-09-14 16:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:48:10 --> Input Class Initialized
INFO - 2020-09-14 16:48:10 --> Language Class Initialized
ERROR - 2020-09-14 16:48:10 --> 404 Page Not Found: Sale_rep/campain_view
ERROR - 2020-09-14 16:48:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:48:15 --> Config Class Initialized
INFO - 2020-09-14 16:48:15 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:48:15 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:48:15 --> Utf8 Class Initialized
INFO - 2020-09-14 16:48:15 --> URI Class Initialized
INFO - 2020-09-14 16:48:15 --> Router Class Initialized
INFO - 2020-09-14 16:48:15 --> Output Class Initialized
INFO - 2020-09-14 16:48:15 --> Security Class Initialized
DEBUG - 2020-09-14 16:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:48:15 --> Input Class Initialized
INFO - 2020-09-14 16:48:15 --> Language Class Initialized
INFO - 2020-09-14 16:48:15 --> Loader Class Initialized
INFO - 2020-09-14 16:48:15 --> Helper loaded: url_helper
INFO - 2020-09-14 16:48:15 --> Database Driver Class Initialized
INFO - 2020-09-14 16:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:48:15 --> Email Class Initialized
INFO - 2020-09-14 16:48:15 --> Controller Class Initialized
DEBUG - 2020-09-14 16:48:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:48:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:48:15 --> Model Class Initialized
INFO - 2020-09-14 16:48:15 --> Model Class Initialized
INFO - 2020-09-14 16:48:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 16:48:15 --> Final output sent to browser
DEBUG - 2020-09-14 16:48:15 --> Total execution time: 0.0260
ERROR - 2020-09-14 16:48:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:48:18 --> Config Class Initialized
INFO - 2020-09-14 16:48:18 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:48:18 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:48:18 --> Utf8 Class Initialized
INFO - 2020-09-14 16:48:18 --> URI Class Initialized
INFO - 2020-09-14 16:48:18 --> Router Class Initialized
INFO - 2020-09-14 16:48:18 --> Output Class Initialized
INFO - 2020-09-14 16:48:18 --> Security Class Initialized
DEBUG - 2020-09-14 16:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:48:18 --> Input Class Initialized
INFO - 2020-09-14 16:48:18 --> Language Class Initialized
INFO - 2020-09-14 16:48:18 --> Loader Class Initialized
INFO - 2020-09-14 16:48:18 --> Helper loaded: url_helper
INFO - 2020-09-14 16:48:18 --> Database Driver Class Initialized
INFO - 2020-09-14 16:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:48:18 --> Email Class Initialized
INFO - 2020-09-14 16:48:18 --> Controller Class Initialized
DEBUG - 2020-09-14 16:48:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:48:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:48:18 --> Model Class Initialized
INFO - 2020-09-14 16:48:18 --> Model Class Initialized
INFO - 2020-09-14 16:48:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 16:48:18 --> Final output sent to browser
DEBUG - 2020-09-14 16:48:18 --> Total execution time: 0.0232
ERROR - 2020-09-14 16:48:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:48:24 --> Config Class Initialized
INFO - 2020-09-14 16:48:24 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:48:24 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:48:24 --> Utf8 Class Initialized
INFO - 2020-09-14 16:48:24 --> URI Class Initialized
INFO - 2020-09-14 16:48:24 --> Router Class Initialized
INFO - 2020-09-14 16:48:24 --> Output Class Initialized
INFO - 2020-09-14 16:48:24 --> Security Class Initialized
DEBUG - 2020-09-14 16:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:48:24 --> Input Class Initialized
INFO - 2020-09-14 16:48:24 --> Language Class Initialized
ERROR - 2020-09-14 16:48:24 --> 404 Page Not Found: Sale_rep/campain_view
ERROR - 2020-09-14 16:48:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:48:51 --> Config Class Initialized
INFO - 2020-09-14 16:48:51 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:48:51 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:48:51 --> Utf8 Class Initialized
INFO - 2020-09-14 16:48:51 --> URI Class Initialized
INFO - 2020-09-14 16:48:51 --> Router Class Initialized
INFO - 2020-09-14 16:48:51 --> Output Class Initialized
INFO - 2020-09-14 16:48:51 --> Security Class Initialized
DEBUG - 2020-09-14 16:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:48:51 --> Input Class Initialized
INFO - 2020-09-14 16:48:51 --> Language Class Initialized
INFO - 2020-09-14 16:48:51 --> Loader Class Initialized
INFO - 2020-09-14 16:48:51 --> Helper loaded: url_helper
INFO - 2020-09-14 16:48:51 --> Database Driver Class Initialized
INFO - 2020-09-14 16:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:48:51 --> Email Class Initialized
INFO - 2020-09-14 16:48:51 --> Controller Class Initialized
DEBUG - 2020-09-14 16:48:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:48:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:48:51 --> Model Class Initialized
INFO - 2020-09-14 16:48:51 --> Model Class Initialized
INFO - 2020-09-14 16:48:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 16:48:51 --> Final output sent to browser
DEBUG - 2020-09-14 16:48:51 --> Total execution time: 0.0280
ERROR - 2020-09-14 16:48:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:48:56 --> Config Class Initialized
INFO - 2020-09-14 16:48:56 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:48:56 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:48:56 --> Utf8 Class Initialized
INFO - 2020-09-14 16:48:56 --> URI Class Initialized
DEBUG - 2020-09-14 16:48:56 --> No URI present. Default controller set.
INFO - 2020-09-14 16:48:56 --> Router Class Initialized
INFO - 2020-09-14 16:48:56 --> Output Class Initialized
INFO - 2020-09-14 16:48:56 --> Security Class Initialized
DEBUG - 2020-09-14 16:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:48:56 --> Input Class Initialized
INFO - 2020-09-14 16:48:56 --> Language Class Initialized
INFO - 2020-09-14 16:48:56 --> Loader Class Initialized
INFO - 2020-09-14 16:48:56 --> Helper loaded: url_helper
INFO - 2020-09-14 16:48:56 --> Database Driver Class Initialized
INFO - 2020-09-14 16:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:48:56 --> Email Class Initialized
INFO - 2020-09-14 16:48:56 --> Controller Class Initialized
INFO - 2020-09-14 16:48:56 --> Model Class Initialized
INFO - 2020-09-14 16:48:56 --> Model Class Initialized
DEBUG - 2020-09-14 16:48:56 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:48:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-14 16:48:56 --> Final output sent to browser
DEBUG - 2020-09-14 16:48:56 --> Total execution time: 0.0178
ERROR - 2020-09-14 16:49:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-14 16:49:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:49:09 --> Config Class Initialized
INFO - 2020-09-14 16:49:09 --> Hooks Class Initialized
INFO - 2020-09-14 16:49:09 --> Config Class Initialized
INFO - 2020-09-14 16:49:09 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:49:09 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:49:09 --> Utf8 Class Initialized
INFO - 2020-09-14 16:49:09 --> URI Class Initialized
DEBUG - 2020-09-14 16:49:09 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:49:09 --> Utf8 Class Initialized
INFO - 2020-09-14 16:49:09 --> Router Class Initialized
INFO - 2020-09-14 16:49:09 --> URI Class Initialized
INFO - 2020-09-14 16:49:09 --> Router Class Initialized
INFO - 2020-09-14 16:49:09 --> Output Class Initialized
INFO - 2020-09-14 16:49:09 --> Security Class Initialized
INFO - 2020-09-14 16:49:09 --> Output Class Initialized
INFO - 2020-09-14 16:49:09 --> Security Class Initialized
DEBUG - 2020-09-14 16:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:49:09 --> Input Class Initialized
INFO - 2020-09-14 16:49:09 --> Language Class Initialized
DEBUG - 2020-09-14 16:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:49:09 --> Input Class Initialized
INFO - 2020-09-14 16:49:09 --> Language Class Initialized
INFO - 2020-09-14 16:49:09 --> Loader Class Initialized
INFO - 2020-09-14 16:49:09 --> Helper loaded: url_helper
INFO - 2020-09-14 16:49:09 --> Loader Class Initialized
INFO - 2020-09-14 16:49:09 --> Helper loaded: url_helper
INFO - 2020-09-14 16:49:09 --> Database Driver Class Initialized
INFO - 2020-09-14 16:49:09 --> Database Driver Class Initialized
INFO - 2020-09-14 16:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:49:09 --> Email Class Initialized
INFO - 2020-09-14 16:49:09 --> Controller Class Initialized
INFO - 2020-09-14 16:49:09 --> Model Class Initialized
INFO - 2020-09-14 16:49:09 --> Model Class Initialized
DEBUG - 2020-09-14 16:49:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:49:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:49:09 --> Model Class Initialized
INFO - 2020-09-14 16:49:09 --> Final output sent to browser
DEBUG - 2020-09-14 16:49:09 --> Total execution time: 0.0223
INFO - 2020-09-14 16:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:49:09 --> Email Class Initialized
INFO - 2020-09-14 16:49:09 --> Controller Class Initialized
INFO - 2020-09-14 16:49:09 --> Model Class Initialized
INFO - 2020-09-14 16:49:09 --> Model Class Initialized
DEBUG - 2020-09-14 16:49:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 16:49:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:49:10 --> Config Class Initialized
INFO - 2020-09-14 16:49:10 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:49:10 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:49:10 --> Utf8 Class Initialized
INFO - 2020-09-14 16:49:10 --> URI Class Initialized
INFO - 2020-09-14 16:49:10 --> Router Class Initialized
INFO - 2020-09-14 16:49:10 --> Output Class Initialized
INFO - 2020-09-14 16:49:10 --> Security Class Initialized
DEBUG - 2020-09-14 16:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:49:10 --> Input Class Initialized
INFO - 2020-09-14 16:49:10 --> Language Class Initialized
INFO - 2020-09-14 16:49:10 --> Loader Class Initialized
INFO - 2020-09-14 16:49:10 --> Helper loaded: url_helper
INFO - 2020-09-14 16:49:10 --> Database Driver Class Initialized
INFO - 2020-09-14 16:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:49:10 --> Email Class Initialized
INFO - 2020-09-14 16:49:10 --> Controller Class Initialized
DEBUG - 2020-09-14 16:49:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:49:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:49:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-14 16:49:10 --> Final output sent to browser
DEBUG - 2020-09-14 16:49:10 --> Total execution time: 0.0228
ERROR - 2020-09-14 16:49:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:49:21 --> Config Class Initialized
INFO - 2020-09-14 16:49:21 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:49:21 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:49:21 --> Utf8 Class Initialized
INFO - 2020-09-14 16:49:21 --> URI Class Initialized
DEBUG - 2020-09-14 16:49:21 --> No URI present. Default controller set.
INFO - 2020-09-14 16:49:21 --> Router Class Initialized
INFO - 2020-09-14 16:49:21 --> Output Class Initialized
INFO - 2020-09-14 16:49:21 --> Security Class Initialized
DEBUG - 2020-09-14 16:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:49:21 --> Input Class Initialized
INFO - 2020-09-14 16:49:21 --> Language Class Initialized
INFO - 2020-09-14 16:49:21 --> Loader Class Initialized
INFO - 2020-09-14 16:49:21 --> Helper loaded: url_helper
INFO - 2020-09-14 16:49:21 --> Database Driver Class Initialized
INFO - 2020-09-14 16:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:49:21 --> Email Class Initialized
INFO - 2020-09-14 16:49:21 --> Controller Class Initialized
INFO - 2020-09-14 16:49:21 --> Model Class Initialized
INFO - 2020-09-14 16:49:21 --> Model Class Initialized
DEBUG - 2020-09-14 16:49:21 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:49:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-14 16:49:21 --> Final output sent to browser
DEBUG - 2020-09-14 16:49:21 --> Total execution time: 0.0177
ERROR - 2020-09-14 16:49:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:49:23 --> Config Class Initialized
INFO - 2020-09-14 16:49:23 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:49:23 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:49:23 --> Utf8 Class Initialized
INFO - 2020-09-14 16:49:23 --> URI Class Initialized
INFO - 2020-09-14 16:49:23 --> Router Class Initialized
INFO - 2020-09-14 16:49:23 --> Output Class Initialized
INFO - 2020-09-14 16:49:23 --> Security Class Initialized
DEBUG - 2020-09-14 16:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:49:23 --> Input Class Initialized
INFO - 2020-09-14 16:49:23 --> Language Class Initialized
INFO - 2020-09-14 16:49:23 --> Loader Class Initialized
INFO - 2020-09-14 16:49:23 --> Helper loaded: url_helper
INFO - 2020-09-14 16:49:23 --> Database Driver Class Initialized
INFO - 2020-09-14 16:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:49:23 --> Email Class Initialized
INFO - 2020-09-14 16:49:23 --> Controller Class Initialized
INFO - 2020-09-14 16:49:23 --> Model Class Initialized
INFO - 2020-09-14 16:49:23 --> Model Class Initialized
DEBUG - 2020-09-14 16:49:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:49:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:49:23 --> Model Class Initialized
INFO - 2020-09-14 16:49:23 --> Final output sent to browser
DEBUG - 2020-09-14 16:49:23 --> Total execution time: 0.0222
ERROR - 2020-09-14 16:49:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:49:23 --> Config Class Initialized
INFO - 2020-09-14 16:49:23 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:49:23 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:49:23 --> Utf8 Class Initialized
INFO - 2020-09-14 16:49:23 --> URI Class Initialized
INFO - 2020-09-14 16:49:23 --> Router Class Initialized
INFO - 2020-09-14 16:49:23 --> Output Class Initialized
INFO - 2020-09-14 16:49:23 --> Security Class Initialized
DEBUG - 2020-09-14 16:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:49:23 --> Input Class Initialized
INFO - 2020-09-14 16:49:23 --> Language Class Initialized
INFO - 2020-09-14 16:49:23 --> Loader Class Initialized
INFO - 2020-09-14 16:49:23 --> Helper loaded: url_helper
INFO - 2020-09-14 16:49:23 --> Database Driver Class Initialized
INFO - 2020-09-14 16:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:49:23 --> Email Class Initialized
INFO - 2020-09-14 16:49:23 --> Controller Class Initialized
INFO - 2020-09-14 16:49:23 --> Model Class Initialized
INFO - 2020-09-14 16:49:23 --> Model Class Initialized
DEBUG - 2020-09-14 16:49:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 16:49:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:49:24 --> Config Class Initialized
INFO - 2020-09-14 16:49:24 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:49:24 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:49:24 --> Utf8 Class Initialized
INFO - 2020-09-14 16:49:24 --> URI Class Initialized
INFO - 2020-09-14 16:49:24 --> Router Class Initialized
INFO - 2020-09-14 16:49:24 --> Output Class Initialized
INFO - 2020-09-14 16:49:24 --> Security Class Initialized
DEBUG - 2020-09-14 16:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:49:24 --> Input Class Initialized
INFO - 2020-09-14 16:49:24 --> Language Class Initialized
INFO - 2020-09-14 16:49:24 --> Loader Class Initialized
INFO - 2020-09-14 16:49:24 --> Helper loaded: url_helper
INFO - 2020-09-14 16:49:24 --> Database Driver Class Initialized
INFO - 2020-09-14 16:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:49:24 --> Email Class Initialized
INFO - 2020-09-14 16:49:24 --> Controller Class Initialized
DEBUG - 2020-09-14 16:49:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:49:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:49:24 --> Model Class Initialized
INFO - 2020-09-14 16:49:24 --> Model Class Initialized
INFO - 2020-09-14 16:49:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 16:49:24 --> Final output sent to browser
DEBUG - 2020-09-14 16:49:24 --> Total execution time: 0.0245
ERROR - 2020-09-14 16:49:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:49:26 --> Config Class Initialized
INFO - 2020-09-14 16:49:26 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:49:26 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:49:26 --> Utf8 Class Initialized
INFO - 2020-09-14 16:49:26 --> URI Class Initialized
INFO - 2020-09-14 16:49:26 --> Router Class Initialized
INFO - 2020-09-14 16:49:26 --> Output Class Initialized
INFO - 2020-09-14 16:49:26 --> Security Class Initialized
DEBUG - 2020-09-14 16:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:49:26 --> Input Class Initialized
INFO - 2020-09-14 16:49:26 --> Language Class Initialized
INFO - 2020-09-14 16:49:26 --> Loader Class Initialized
INFO - 2020-09-14 16:49:26 --> Helper loaded: url_helper
INFO - 2020-09-14 16:49:26 --> Database Driver Class Initialized
INFO - 2020-09-14 16:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:49:26 --> Email Class Initialized
INFO - 2020-09-14 16:49:26 --> Controller Class Initialized
DEBUG - 2020-09-14 16:49:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:49:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:49:26 --> Model Class Initialized
INFO - 2020-09-14 16:49:26 --> Model Class Initialized
INFO - 2020-09-14 16:49:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 16:49:26 --> Final output sent to browser
DEBUG - 2020-09-14 16:49:26 --> Total execution time: 0.0185
ERROR - 2020-09-14 16:49:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:49:29 --> Config Class Initialized
INFO - 2020-09-14 16:49:29 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:49:29 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:49:29 --> Utf8 Class Initialized
INFO - 2020-09-14 16:49:29 --> URI Class Initialized
INFO - 2020-09-14 16:49:29 --> Router Class Initialized
INFO - 2020-09-14 16:49:29 --> Output Class Initialized
INFO - 2020-09-14 16:49:29 --> Security Class Initialized
DEBUG - 2020-09-14 16:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:49:29 --> Input Class Initialized
INFO - 2020-09-14 16:49:29 --> Language Class Initialized
ERROR - 2020-09-14 16:49:29 --> 404 Page Not Found: Sale_rep/campain_view
ERROR - 2020-09-14 16:50:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:50:40 --> Config Class Initialized
INFO - 2020-09-14 16:50:40 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:50:40 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:50:40 --> Utf8 Class Initialized
INFO - 2020-09-14 16:50:40 --> URI Class Initialized
INFO - 2020-09-14 16:50:40 --> Router Class Initialized
INFO - 2020-09-14 16:50:40 --> Output Class Initialized
INFO - 2020-09-14 16:50:40 --> Security Class Initialized
DEBUG - 2020-09-14 16:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:50:40 --> Input Class Initialized
INFO - 2020-09-14 16:50:40 --> Language Class Initialized
INFO - 2020-09-14 16:50:40 --> Loader Class Initialized
INFO - 2020-09-14 16:50:40 --> Helper loaded: url_helper
INFO - 2020-09-14 16:50:40 --> Database Driver Class Initialized
INFO - 2020-09-14 16:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:50:40 --> Email Class Initialized
INFO - 2020-09-14 16:50:40 --> Controller Class Initialized
DEBUG - 2020-09-14 16:50:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:50:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:50:40 --> Model Class Initialized
INFO - 2020-09-14 16:50:40 --> Model Class Initialized
INFO - 2020-09-14 16:50:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 16:50:40 --> Final output sent to browser
DEBUG - 2020-09-14 16:50:40 --> Total execution time: 0.0212
ERROR - 2020-09-14 16:50:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:50:43 --> Config Class Initialized
INFO - 2020-09-14 16:50:43 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:50:43 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:50:43 --> Utf8 Class Initialized
INFO - 2020-09-14 16:50:43 --> URI Class Initialized
INFO - 2020-09-14 16:50:43 --> Router Class Initialized
INFO - 2020-09-14 16:50:43 --> Output Class Initialized
INFO - 2020-09-14 16:50:43 --> Security Class Initialized
DEBUG - 2020-09-14 16:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:50:43 --> Input Class Initialized
INFO - 2020-09-14 16:50:43 --> Language Class Initialized
INFO - 2020-09-14 16:50:43 --> Loader Class Initialized
INFO - 2020-09-14 16:50:43 --> Helper loaded: url_helper
INFO - 2020-09-14 16:50:43 --> Database Driver Class Initialized
INFO - 2020-09-14 16:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:50:43 --> Email Class Initialized
INFO - 2020-09-14 16:50:43 --> Controller Class Initialized
DEBUG - 2020-09-14 16:50:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:50:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:50:43 --> Model Class Initialized
INFO - 2020-09-14 16:50:43 --> Model Class Initialized
INFO - 2020-09-14 16:50:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 16:50:43 --> Final output sent to browser
DEBUG - 2020-09-14 16:50:43 --> Total execution time: 0.0228
ERROR - 2020-09-14 16:51:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:51:04 --> Config Class Initialized
INFO - 2020-09-14 16:51:04 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:51:04 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:51:04 --> Utf8 Class Initialized
INFO - 2020-09-14 16:51:04 --> URI Class Initialized
INFO - 2020-09-14 16:51:04 --> Router Class Initialized
INFO - 2020-09-14 16:51:04 --> Output Class Initialized
INFO - 2020-09-14 16:51:04 --> Security Class Initialized
DEBUG - 2020-09-14 16:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:51:04 --> Input Class Initialized
INFO - 2020-09-14 16:51:04 --> Language Class Initialized
INFO - 2020-09-14 16:51:04 --> Loader Class Initialized
INFO - 2020-09-14 16:51:04 --> Helper loaded: url_helper
INFO - 2020-09-14 16:51:04 --> Database Driver Class Initialized
INFO - 2020-09-14 16:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:51:04 --> Email Class Initialized
INFO - 2020-09-14 16:51:04 --> Controller Class Initialized
DEBUG - 2020-09-14 16:51:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:51:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:51:04 --> Model Class Initialized
INFO - 2020-09-14 16:51:04 --> Model Class Initialized
INFO - 2020-09-14 16:51:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 16:51:04 --> Final output sent to browser
DEBUG - 2020-09-14 16:51:04 --> Total execution time: 0.0195
ERROR - 2020-09-14 16:51:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:51:22 --> Config Class Initialized
INFO - 2020-09-14 16:51:22 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:51:22 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:51:22 --> Utf8 Class Initialized
INFO - 2020-09-14 16:51:22 --> URI Class Initialized
DEBUG - 2020-09-14 16:51:22 --> No URI present. Default controller set.
INFO - 2020-09-14 16:51:22 --> Router Class Initialized
INFO - 2020-09-14 16:51:22 --> Output Class Initialized
INFO - 2020-09-14 16:51:22 --> Security Class Initialized
DEBUG - 2020-09-14 16:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:51:22 --> Input Class Initialized
INFO - 2020-09-14 16:51:22 --> Language Class Initialized
INFO - 2020-09-14 16:51:22 --> Loader Class Initialized
INFO - 2020-09-14 16:51:22 --> Helper loaded: url_helper
INFO - 2020-09-14 16:51:22 --> Database Driver Class Initialized
INFO - 2020-09-14 16:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:51:22 --> Email Class Initialized
INFO - 2020-09-14 16:51:22 --> Controller Class Initialized
INFO - 2020-09-14 16:51:22 --> Model Class Initialized
INFO - 2020-09-14 16:51:22 --> Model Class Initialized
DEBUG - 2020-09-14 16:51:22 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:51:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-14 16:51:22 --> Final output sent to browser
DEBUG - 2020-09-14 16:51:22 --> Total execution time: 0.0185
ERROR - 2020-09-14 16:51:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-14 16:51:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:51:25 --> Config Class Initialized
INFO - 2020-09-14 16:51:25 --> Hooks Class Initialized
INFO - 2020-09-14 16:51:25 --> Config Class Initialized
INFO - 2020-09-14 16:51:25 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:51:25 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:51:25 --> Utf8 Class Initialized
DEBUG - 2020-09-14 16:51:25 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:51:25 --> Utf8 Class Initialized
INFO - 2020-09-14 16:51:25 --> URI Class Initialized
INFO - 2020-09-14 16:51:25 --> URI Class Initialized
INFO - 2020-09-14 16:51:25 --> Router Class Initialized
INFO - 2020-09-14 16:51:25 --> Router Class Initialized
INFO - 2020-09-14 16:51:25 --> Output Class Initialized
INFO - 2020-09-14 16:51:25 --> Output Class Initialized
INFO - 2020-09-14 16:51:25 --> Security Class Initialized
INFO - 2020-09-14 16:51:25 --> Security Class Initialized
DEBUG - 2020-09-14 16:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:51:25 --> Input Class Initialized
DEBUG - 2020-09-14 16:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:51:25 --> Input Class Initialized
INFO - 2020-09-14 16:51:25 --> Language Class Initialized
INFO - 2020-09-14 16:51:25 --> Language Class Initialized
INFO - 2020-09-14 16:51:25 --> Loader Class Initialized
INFO - 2020-09-14 16:51:25 --> Loader Class Initialized
INFO - 2020-09-14 16:51:25 --> Helper loaded: url_helper
INFO - 2020-09-14 16:51:25 --> Helper loaded: url_helper
INFO - 2020-09-14 16:51:25 --> Database Driver Class Initialized
INFO - 2020-09-14 16:51:25 --> Database Driver Class Initialized
INFO - 2020-09-14 16:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:51:25 --> Email Class Initialized
INFO - 2020-09-14 16:51:25 --> Controller Class Initialized
INFO - 2020-09-14 16:51:25 --> Model Class Initialized
INFO - 2020-09-14 16:51:25 --> Model Class Initialized
DEBUG - 2020-09-14 16:51:25 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:51:25 --> Email Class Initialized
INFO - 2020-09-14 16:51:25 --> Controller Class Initialized
INFO - 2020-09-14 16:51:25 --> Model Class Initialized
INFO - 2020-09-14 16:51:25 --> Model Class Initialized
DEBUG - 2020-09-14 16:51:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:51:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:51:25 --> Model Class Initialized
INFO - 2020-09-14 16:51:25 --> Final output sent to browser
DEBUG - 2020-09-14 16:51:25 --> Total execution time: 0.0276
ERROR - 2020-09-14 16:51:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:51:25 --> Config Class Initialized
INFO - 2020-09-14 16:51:25 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:51:25 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:51:25 --> Utf8 Class Initialized
INFO - 2020-09-14 16:51:25 --> URI Class Initialized
INFO - 2020-09-14 16:51:25 --> Router Class Initialized
INFO - 2020-09-14 16:51:25 --> Output Class Initialized
INFO - 2020-09-14 16:51:25 --> Security Class Initialized
DEBUG - 2020-09-14 16:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:51:25 --> Input Class Initialized
INFO - 2020-09-14 16:51:25 --> Language Class Initialized
INFO - 2020-09-14 16:51:25 --> Loader Class Initialized
INFO - 2020-09-14 16:51:25 --> Helper loaded: url_helper
INFO - 2020-09-14 16:51:25 --> Database Driver Class Initialized
INFO - 2020-09-14 16:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:51:25 --> Email Class Initialized
INFO - 2020-09-14 16:51:25 --> Controller Class Initialized
DEBUG - 2020-09-14 16:51:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:51:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:51:25 --> Model Class Initialized
INFO - 2020-09-14 16:51:25 --> Model Class Initialized
INFO - 2020-09-14 16:51:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 16:51:25 --> Final output sent to browser
DEBUG - 2020-09-14 16:51:25 --> Total execution time: 0.0193
ERROR - 2020-09-14 16:51:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:51:28 --> Config Class Initialized
INFO - 2020-09-14 16:51:28 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:51:28 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:51:28 --> Utf8 Class Initialized
INFO - 2020-09-14 16:51:28 --> URI Class Initialized
INFO - 2020-09-14 16:51:28 --> Router Class Initialized
INFO - 2020-09-14 16:51:28 --> Output Class Initialized
INFO - 2020-09-14 16:51:28 --> Security Class Initialized
DEBUG - 2020-09-14 16:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:51:28 --> Input Class Initialized
INFO - 2020-09-14 16:51:28 --> Language Class Initialized
INFO - 2020-09-14 16:51:28 --> Loader Class Initialized
INFO - 2020-09-14 16:51:28 --> Helper loaded: url_helper
INFO - 2020-09-14 16:51:28 --> Database Driver Class Initialized
INFO - 2020-09-14 16:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:51:28 --> Email Class Initialized
INFO - 2020-09-14 16:51:28 --> Controller Class Initialized
DEBUG - 2020-09-14 16:51:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:51:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:51:28 --> Model Class Initialized
INFO - 2020-09-14 16:51:28 --> Model Class Initialized
INFO - 2020-09-14 16:51:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 16:51:28 --> Final output sent to browser
DEBUG - 2020-09-14 16:51:28 --> Total execution time: 0.0213
ERROR - 2020-09-14 16:51:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:51:33 --> Config Class Initialized
INFO - 2020-09-14 16:51:33 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:51:33 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:51:33 --> Utf8 Class Initialized
INFO - 2020-09-14 16:51:33 --> URI Class Initialized
INFO - 2020-09-14 16:51:33 --> Router Class Initialized
INFO - 2020-09-14 16:51:33 --> Output Class Initialized
INFO - 2020-09-14 16:51:33 --> Security Class Initialized
DEBUG - 2020-09-14 16:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:51:33 --> Input Class Initialized
INFO - 2020-09-14 16:51:33 --> Language Class Initialized
INFO - 2020-09-14 16:51:33 --> Loader Class Initialized
INFO - 2020-09-14 16:51:33 --> Helper loaded: url_helper
INFO - 2020-09-14 16:51:33 --> Database Driver Class Initialized
INFO - 2020-09-14 16:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:51:33 --> Email Class Initialized
INFO - 2020-09-14 16:51:33 --> Controller Class Initialized
DEBUG - 2020-09-14 16:51:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:51:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:51:33 --> Model Class Initialized
INFO - 2020-09-14 16:51:33 --> Model Class Initialized
ERROR - 2020-09-14 16:51:33 --> Query error: Unknown column 'undefined' in 'field list' - Invalid query: CALL sale_representative_edit(undefined)
INFO - 2020-09-14 16:51:33 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-14 16:52:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:52:35 --> Config Class Initialized
INFO - 2020-09-14 16:52:35 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:52:35 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:52:35 --> Utf8 Class Initialized
INFO - 2020-09-14 16:52:35 --> URI Class Initialized
INFO - 2020-09-14 16:52:35 --> Router Class Initialized
INFO - 2020-09-14 16:52:35 --> Output Class Initialized
INFO - 2020-09-14 16:52:35 --> Security Class Initialized
DEBUG - 2020-09-14 16:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:52:35 --> Input Class Initialized
INFO - 2020-09-14 16:52:35 --> Language Class Initialized
INFO - 2020-09-14 16:52:35 --> Loader Class Initialized
INFO - 2020-09-14 16:52:35 --> Helper loaded: url_helper
INFO - 2020-09-14 16:52:35 --> Database Driver Class Initialized
INFO - 2020-09-14 16:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:52:35 --> Email Class Initialized
INFO - 2020-09-14 16:52:35 --> Controller Class Initialized
DEBUG - 2020-09-14 16:52:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:52:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:52:35 --> Model Class Initialized
INFO - 2020-09-14 16:52:35 --> Model Class Initialized
ERROR - 2020-09-14 16:52:35 --> Query error: Unknown column 'undefined' in 'field list' - Invalid query: CALL sale_representative_edit(undefined)
INFO - 2020-09-14 16:52:35 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-14 16:52:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:52:38 --> Config Class Initialized
INFO - 2020-09-14 16:52:38 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:52:38 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:52:38 --> Utf8 Class Initialized
INFO - 2020-09-14 16:52:38 --> URI Class Initialized
INFO - 2020-09-14 16:52:38 --> Router Class Initialized
INFO - 2020-09-14 16:52:38 --> Output Class Initialized
INFO - 2020-09-14 16:52:38 --> Security Class Initialized
DEBUG - 2020-09-14 16:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:52:38 --> Input Class Initialized
INFO - 2020-09-14 16:52:38 --> Language Class Initialized
INFO - 2020-09-14 16:52:38 --> Loader Class Initialized
INFO - 2020-09-14 16:52:38 --> Helper loaded: url_helper
INFO - 2020-09-14 16:52:38 --> Database Driver Class Initialized
INFO - 2020-09-14 16:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:52:38 --> Email Class Initialized
INFO - 2020-09-14 16:52:38 --> Controller Class Initialized
DEBUG - 2020-09-14 16:52:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:52:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:52:38 --> Model Class Initialized
INFO - 2020-09-14 16:52:38 --> Model Class Initialized
INFO - 2020-09-14 16:52:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 16:52:38 --> Final output sent to browser
DEBUG - 2020-09-14 16:52:38 --> Total execution time: 0.0231
ERROR - 2020-09-14 16:52:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:52:40 --> Config Class Initialized
INFO - 2020-09-14 16:52:40 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:52:40 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:52:40 --> Utf8 Class Initialized
INFO - 2020-09-14 16:52:40 --> URI Class Initialized
INFO - 2020-09-14 16:52:40 --> Router Class Initialized
INFO - 2020-09-14 16:52:40 --> Output Class Initialized
INFO - 2020-09-14 16:52:40 --> Security Class Initialized
DEBUG - 2020-09-14 16:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:52:40 --> Input Class Initialized
INFO - 2020-09-14 16:52:40 --> Language Class Initialized
INFO - 2020-09-14 16:52:40 --> Loader Class Initialized
INFO - 2020-09-14 16:52:40 --> Helper loaded: url_helper
INFO - 2020-09-14 16:52:40 --> Database Driver Class Initialized
INFO - 2020-09-14 16:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:52:40 --> Email Class Initialized
INFO - 2020-09-14 16:52:40 --> Controller Class Initialized
DEBUG - 2020-09-14 16:52:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:52:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:52:40 --> Model Class Initialized
INFO - 2020-09-14 16:52:40 --> Model Class Initialized
INFO - 2020-09-14 16:52:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_view.php
INFO - 2020-09-14 16:52:40 --> Final output sent to browser
DEBUG - 2020-09-14 16:52:40 --> Total execution time: 0.0248
ERROR - 2020-09-14 16:52:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:52:45 --> Config Class Initialized
INFO - 2020-09-14 16:52:45 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:52:45 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:52:45 --> Utf8 Class Initialized
INFO - 2020-09-14 16:52:45 --> URI Class Initialized
INFO - 2020-09-14 16:52:45 --> Router Class Initialized
INFO - 2020-09-14 16:52:45 --> Output Class Initialized
INFO - 2020-09-14 16:52:45 --> Security Class Initialized
DEBUG - 2020-09-14 16:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:52:45 --> Input Class Initialized
INFO - 2020-09-14 16:52:45 --> Language Class Initialized
INFO - 2020-09-14 16:52:45 --> Loader Class Initialized
INFO - 2020-09-14 16:52:45 --> Helper loaded: url_helper
INFO - 2020-09-14 16:52:45 --> Database Driver Class Initialized
INFO - 2020-09-14 16:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:52:45 --> Email Class Initialized
INFO - 2020-09-14 16:52:45 --> Controller Class Initialized
DEBUG - 2020-09-14 16:52:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:52:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:52:45 --> Model Class Initialized
INFO - 2020-09-14 16:52:45 --> Model Class Initialized
INFO - 2020-09-14 16:52:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 16:52:45 --> Final output sent to browser
DEBUG - 2020-09-14 16:52:45 --> Total execution time: 0.0236
ERROR - 2020-09-14 16:52:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:52:53 --> Config Class Initialized
INFO - 2020-09-14 16:52:53 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:52:53 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:52:53 --> Utf8 Class Initialized
INFO - 2020-09-14 16:52:53 --> URI Class Initialized
INFO - 2020-09-14 16:52:53 --> Router Class Initialized
INFO - 2020-09-14 16:52:53 --> Output Class Initialized
INFO - 2020-09-14 16:52:53 --> Security Class Initialized
DEBUG - 2020-09-14 16:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:52:53 --> Input Class Initialized
INFO - 2020-09-14 16:52:53 --> Language Class Initialized
INFO - 2020-09-14 16:52:53 --> Loader Class Initialized
INFO - 2020-09-14 16:52:53 --> Helper loaded: url_helper
INFO - 2020-09-14 16:52:53 --> Database Driver Class Initialized
INFO - 2020-09-14 16:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:52:53 --> Email Class Initialized
INFO - 2020-09-14 16:52:53 --> Controller Class Initialized
DEBUG - 2020-09-14 16:52:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:52:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:52:53 --> Model Class Initialized
INFO - 2020-09-14 16:52:53 --> Model Class Initialized
INFO - 2020-09-14 16:52:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_view.php
INFO - 2020-09-14 16:52:53 --> Final output sent to browser
DEBUG - 2020-09-14 16:52:53 --> Total execution time: 0.0184
ERROR - 2020-09-14 16:52:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:52:57 --> Config Class Initialized
INFO - 2020-09-14 16:52:57 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:52:57 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:52:57 --> Utf8 Class Initialized
INFO - 2020-09-14 16:52:57 --> URI Class Initialized
INFO - 2020-09-14 16:52:57 --> Router Class Initialized
INFO - 2020-09-14 16:52:57 --> Output Class Initialized
INFO - 2020-09-14 16:52:57 --> Security Class Initialized
DEBUG - 2020-09-14 16:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:52:57 --> Input Class Initialized
INFO - 2020-09-14 16:52:57 --> Language Class Initialized
INFO - 2020-09-14 16:52:57 --> Loader Class Initialized
INFO - 2020-09-14 16:52:57 --> Helper loaded: url_helper
INFO - 2020-09-14 16:52:57 --> Database Driver Class Initialized
INFO - 2020-09-14 16:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:52:57 --> Email Class Initialized
INFO - 2020-09-14 16:52:57 --> Controller Class Initialized
DEBUG - 2020-09-14 16:52:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:52:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:52:57 --> Model Class Initialized
INFO - 2020-09-14 16:52:57 --> Model Class Initialized
INFO - 2020-09-14 16:52:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 16:52:57 --> Final output sent to browser
DEBUG - 2020-09-14 16:52:57 --> Total execution time: 0.0236
ERROR - 2020-09-14 16:53:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:53:00 --> Config Class Initialized
INFO - 2020-09-14 16:53:00 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:53:00 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:53:00 --> Utf8 Class Initialized
INFO - 2020-09-14 16:53:00 --> URI Class Initialized
INFO - 2020-09-14 16:53:00 --> Router Class Initialized
INFO - 2020-09-14 16:53:00 --> Output Class Initialized
INFO - 2020-09-14 16:53:00 --> Security Class Initialized
DEBUG - 2020-09-14 16:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:53:00 --> Input Class Initialized
INFO - 2020-09-14 16:53:00 --> Language Class Initialized
INFO - 2020-09-14 16:53:00 --> Loader Class Initialized
INFO - 2020-09-14 16:53:00 --> Helper loaded: url_helper
INFO - 2020-09-14 16:53:00 --> Database Driver Class Initialized
INFO - 2020-09-14 16:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:53:00 --> Email Class Initialized
INFO - 2020-09-14 16:53:00 --> Controller Class Initialized
DEBUG - 2020-09-14 16:53:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:53:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:53:00 --> Model Class Initialized
INFO - 2020-09-14 16:53:00 --> Model Class Initialized
INFO - 2020-09-14 16:53:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_view.php
INFO - 2020-09-14 16:53:00 --> Final output sent to browser
DEBUG - 2020-09-14 16:53:00 --> Total execution time: 0.0216
ERROR - 2020-09-14 16:53:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:53:31 --> Config Class Initialized
INFO - 2020-09-14 16:53:31 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:53:31 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:53:31 --> Utf8 Class Initialized
INFO - 2020-09-14 16:53:31 --> URI Class Initialized
INFO - 2020-09-14 16:53:31 --> Router Class Initialized
INFO - 2020-09-14 16:53:31 --> Output Class Initialized
INFO - 2020-09-14 16:53:31 --> Security Class Initialized
DEBUG - 2020-09-14 16:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:53:31 --> Input Class Initialized
INFO - 2020-09-14 16:53:31 --> Language Class Initialized
INFO - 2020-09-14 16:53:31 --> Loader Class Initialized
INFO - 2020-09-14 16:53:31 --> Helper loaded: url_helper
INFO - 2020-09-14 16:53:31 --> Database Driver Class Initialized
INFO - 2020-09-14 16:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:53:31 --> Email Class Initialized
INFO - 2020-09-14 16:53:31 --> Controller Class Initialized
DEBUG - 2020-09-14 16:53:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:53:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:53:31 --> Model Class Initialized
INFO - 2020-09-14 16:53:31 --> Model Class Initialized
INFO - 2020-09-14 16:53:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_view.php
INFO - 2020-09-14 16:53:31 --> Final output sent to browser
DEBUG - 2020-09-14 16:53:31 --> Total execution time: 0.4849
ERROR - 2020-09-14 16:53:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:53:35 --> Config Class Initialized
INFO - 2020-09-14 16:53:35 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:53:35 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:53:35 --> Utf8 Class Initialized
INFO - 2020-09-14 16:53:35 --> URI Class Initialized
INFO - 2020-09-14 16:53:35 --> Router Class Initialized
INFO - 2020-09-14 16:53:35 --> Output Class Initialized
INFO - 2020-09-14 16:53:35 --> Security Class Initialized
DEBUG - 2020-09-14 16:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:53:35 --> Input Class Initialized
INFO - 2020-09-14 16:53:35 --> Language Class Initialized
INFO - 2020-09-14 16:53:35 --> Loader Class Initialized
INFO - 2020-09-14 16:53:35 --> Helper loaded: url_helper
INFO - 2020-09-14 16:53:35 --> Database Driver Class Initialized
INFO - 2020-09-14 16:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:53:35 --> Email Class Initialized
INFO - 2020-09-14 16:53:35 --> Controller Class Initialized
DEBUG - 2020-09-14 16:53:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:53:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:53:35 --> Model Class Initialized
INFO - 2020-09-14 16:53:35 --> Model Class Initialized
INFO - 2020-09-14 16:53:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 16:53:35 --> Final output sent to browser
DEBUG - 2020-09-14 16:53:35 --> Total execution time: 0.0215
ERROR - 2020-09-14 16:53:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:53:49 --> Config Class Initialized
INFO - 2020-09-14 16:53:49 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:53:49 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:53:49 --> Utf8 Class Initialized
INFO - 2020-09-14 16:53:49 --> URI Class Initialized
INFO - 2020-09-14 16:53:49 --> Router Class Initialized
INFO - 2020-09-14 16:53:49 --> Output Class Initialized
INFO - 2020-09-14 16:53:49 --> Security Class Initialized
DEBUG - 2020-09-14 16:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:53:49 --> Input Class Initialized
INFO - 2020-09-14 16:53:49 --> Language Class Initialized
INFO - 2020-09-14 16:53:49 --> Loader Class Initialized
INFO - 2020-09-14 16:53:49 --> Helper loaded: url_helper
INFO - 2020-09-14 16:53:49 --> Database Driver Class Initialized
INFO - 2020-09-14 16:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:53:49 --> Email Class Initialized
INFO - 2020-09-14 16:53:49 --> Controller Class Initialized
DEBUG - 2020-09-14 16:53:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:53:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:53:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-14 16:53:49 --> Final output sent to browser
DEBUG - 2020-09-14 16:53:49 --> Total execution time: 0.0193
ERROR - 2020-09-14 16:54:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:54:11 --> Config Class Initialized
INFO - 2020-09-14 16:54:11 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:54:11 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:54:11 --> Utf8 Class Initialized
INFO - 2020-09-14 16:54:11 --> URI Class Initialized
DEBUG - 2020-09-14 16:54:11 --> No URI present. Default controller set.
INFO - 2020-09-14 16:54:11 --> Router Class Initialized
INFO - 2020-09-14 16:54:11 --> Output Class Initialized
INFO - 2020-09-14 16:54:11 --> Security Class Initialized
DEBUG - 2020-09-14 16:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:54:11 --> Input Class Initialized
INFO - 2020-09-14 16:54:11 --> Language Class Initialized
INFO - 2020-09-14 16:54:11 --> Loader Class Initialized
INFO - 2020-09-14 16:54:11 --> Helper loaded: url_helper
INFO - 2020-09-14 16:54:11 --> Database Driver Class Initialized
INFO - 2020-09-14 16:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:54:11 --> Email Class Initialized
INFO - 2020-09-14 16:54:11 --> Controller Class Initialized
INFO - 2020-09-14 16:54:11 --> Model Class Initialized
INFO - 2020-09-14 16:54:11 --> Model Class Initialized
DEBUG - 2020-09-14 16:54:11 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:54:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-14 16:54:11 --> Final output sent to browser
DEBUG - 2020-09-14 16:54:11 --> Total execution time: 0.0208
ERROR - 2020-09-14 16:54:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:54:14 --> Config Class Initialized
INFO - 2020-09-14 16:54:14 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:54:14 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:54:14 --> Utf8 Class Initialized
INFO - 2020-09-14 16:54:14 --> URI Class Initialized
INFO - 2020-09-14 16:54:14 --> Router Class Initialized
INFO - 2020-09-14 16:54:14 --> Output Class Initialized
INFO - 2020-09-14 16:54:14 --> Security Class Initialized
DEBUG - 2020-09-14 16:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:54:14 --> Input Class Initialized
INFO - 2020-09-14 16:54:14 --> Language Class Initialized
INFO - 2020-09-14 16:54:14 --> Loader Class Initialized
INFO - 2020-09-14 16:54:14 --> Helper loaded: url_helper
INFO - 2020-09-14 16:54:14 --> Database Driver Class Initialized
INFO - 2020-09-14 16:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:54:14 --> Email Class Initialized
INFO - 2020-09-14 16:54:14 --> Controller Class Initialized
INFO - 2020-09-14 16:54:14 --> Model Class Initialized
INFO - 2020-09-14 16:54:14 --> Model Class Initialized
DEBUG - 2020-09-14 16:54:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:54:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:54:14 --> Model Class Initialized
INFO - 2020-09-14 16:54:14 --> Final output sent to browser
DEBUG - 2020-09-14 16:54:14 --> Total execution time: 0.0249
ERROR - 2020-09-14 16:54:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:54:14 --> Config Class Initialized
INFO - 2020-09-14 16:54:14 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:54:14 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:54:14 --> Utf8 Class Initialized
INFO - 2020-09-14 16:54:14 --> URI Class Initialized
INFO - 2020-09-14 16:54:14 --> Router Class Initialized
INFO - 2020-09-14 16:54:14 --> Output Class Initialized
INFO - 2020-09-14 16:54:14 --> Security Class Initialized
DEBUG - 2020-09-14 16:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:54:14 --> Input Class Initialized
INFO - 2020-09-14 16:54:14 --> Language Class Initialized
INFO - 2020-09-14 16:54:14 --> Loader Class Initialized
INFO - 2020-09-14 16:54:14 --> Helper loaded: url_helper
INFO - 2020-09-14 16:54:14 --> Database Driver Class Initialized
INFO - 2020-09-14 16:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:54:14 --> Email Class Initialized
INFO - 2020-09-14 16:54:14 --> Controller Class Initialized
INFO - 2020-09-14 16:54:14 --> Model Class Initialized
INFO - 2020-09-14 16:54:14 --> Model Class Initialized
DEBUG - 2020-09-14 16:54:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 16:54:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 16:54:15 --> Config Class Initialized
INFO - 2020-09-14 16:54:15 --> Hooks Class Initialized
DEBUG - 2020-09-14 16:54:15 --> UTF-8 Support Enabled
INFO - 2020-09-14 16:54:15 --> Utf8 Class Initialized
INFO - 2020-09-14 16:54:15 --> URI Class Initialized
INFO - 2020-09-14 16:54:15 --> Router Class Initialized
INFO - 2020-09-14 16:54:15 --> Output Class Initialized
INFO - 2020-09-14 16:54:15 --> Security Class Initialized
DEBUG - 2020-09-14 16:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 16:54:15 --> Input Class Initialized
INFO - 2020-09-14 16:54:15 --> Language Class Initialized
INFO - 2020-09-14 16:54:15 --> Loader Class Initialized
INFO - 2020-09-14 16:54:15 --> Helper loaded: url_helper
INFO - 2020-09-14 16:54:15 --> Database Driver Class Initialized
INFO - 2020-09-14 16:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 16:54:15 --> Email Class Initialized
INFO - 2020-09-14 16:54:15 --> Controller Class Initialized
DEBUG - 2020-09-14 16:54:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 16:54:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 16:54:15 --> Model Class Initialized
INFO - 2020-09-14 16:54:15 --> Model Class Initialized
INFO - 2020-09-14 16:54:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 16:54:15 --> Final output sent to browser
DEBUG - 2020-09-14 16:54:15 --> Total execution time: 0.0233
ERROR - 2020-09-14 17:04:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:04:28 --> Config Class Initialized
INFO - 2020-09-14 17:04:28 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:04:28 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:04:28 --> Utf8 Class Initialized
INFO - 2020-09-14 17:04:28 --> URI Class Initialized
INFO - 2020-09-14 17:04:28 --> Router Class Initialized
INFO - 2020-09-14 17:04:28 --> Output Class Initialized
INFO - 2020-09-14 17:04:28 --> Security Class Initialized
DEBUG - 2020-09-14 17:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:04:28 --> Input Class Initialized
INFO - 2020-09-14 17:04:28 --> Language Class Initialized
INFO - 2020-09-14 17:04:28 --> Loader Class Initialized
INFO - 2020-09-14 17:04:28 --> Helper loaded: url_helper
INFO - 2020-09-14 17:04:28 --> Database Driver Class Initialized
INFO - 2020-09-14 17:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:04:28 --> Email Class Initialized
INFO - 2020-09-14 17:04:28 --> Controller Class Initialized
DEBUG - 2020-09-14 17:04:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:04:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:04:28 --> Model Class Initialized
INFO - 2020-09-14 17:04:28 --> Model Class Initialized
INFO - 2020-09-14 17:04:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 17:04:28 --> Final output sent to browser
DEBUG - 2020-09-14 17:04:28 --> Total execution time: 0.0334
ERROR - 2020-09-14 17:04:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:04:31 --> Config Class Initialized
INFO - 2020-09-14 17:04:31 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:04:31 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:04:31 --> Utf8 Class Initialized
INFO - 2020-09-14 17:04:31 --> URI Class Initialized
INFO - 2020-09-14 17:04:31 --> Router Class Initialized
INFO - 2020-09-14 17:04:31 --> Output Class Initialized
INFO - 2020-09-14 17:04:31 --> Security Class Initialized
DEBUG - 2020-09-14 17:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:04:31 --> Input Class Initialized
INFO - 2020-09-14 17:04:31 --> Language Class Initialized
INFO - 2020-09-14 17:04:31 --> Loader Class Initialized
INFO - 2020-09-14 17:04:31 --> Helper loaded: url_helper
INFO - 2020-09-14 17:04:31 --> Database Driver Class Initialized
INFO - 2020-09-14 17:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:04:31 --> Email Class Initialized
INFO - 2020-09-14 17:04:31 --> Controller Class Initialized
DEBUG - 2020-09-14 17:04:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:04:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:04:31 --> Model Class Initialized
INFO - 2020-09-14 17:04:31 --> Model Class Initialized
INFO - 2020-09-14 17:04:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 17:04:31 --> Final output sent to browser
DEBUG - 2020-09-14 17:04:31 --> Total execution time: 0.0215
ERROR - 2020-09-14 17:04:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:04:34 --> Config Class Initialized
INFO - 2020-09-14 17:04:34 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:04:34 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:04:34 --> Utf8 Class Initialized
INFO - 2020-09-14 17:04:34 --> URI Class Initialized
INFO - 2020-09-14 17:04:34 --> Router Class Initialized
INFO - 2020-09-14 17:04:34 --> Output Class Initialized
INFO - 2020-09-14 17:04:34 --> Security Class Initialized
DEBUG - 2020-09-14 17:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:04:34 --> Input Class Initialized
INFO - 2020-09-14 17:04:34 --> Language Class Initialized
INFO - 2020-09-14 17:04:34 --> Loader Class Initialized
INFO - 2020-09-14 17:04:34 --> Helper loaded: url_helper
INFO - 2020-09-14 17:04:34 --> Database Driver Class Initialized
INFO - 2020-09-14 17:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:04:34 --> Email Class Initialized
INFO - 2020-09-14 17:04:34 --> Controller Class Initialized
DEBUG - 2020-09-14 17:04:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:04:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:04:34 --> Model Class Initialized
INFO - 2020-09-14 17:04:34 --> Model Class Initialized
INFO - 2020-09-14 17:04:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-09-14 17:04:34 --> Final output sent to browser
DEBUG - 2020-09-14 17:04:34 --> Total execution time: 0.0248
ERROR - 2020-09-14 17:15:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:15:18 --> Config Class Initialized
INFO - 2020-09-14 17:15:18 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:15:18 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:15:18 --> Utf8 Class Initialized
INFO - 2020-09-14 17:15:18 --> URI Class Initialized
INFO - 2020-09-14 17:15:18 --> Router Class Initialized
INFO - 2020-09-14 17:15:18 --> Output Class Initialized
INFO - 2020-09-14 17:15:18 --> Security Class Initialized
DEBUG - 2020-09-14 17:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:15:18 --> Input Class Initialized
INFO - 2020-09-14 17:15:18 --> Language Class Initialized
INFO - 2020-09-14 17:15:18 --> Loader Class Initialized
INFO - 2020-09-14 17:15:18 --> Helper loaded: url_helper
INFO - 2020-09-14 17:15:18 --> Database Driver Class Initialized
INFO - 2020-09-14 17:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:15:18 --> Email Class Initialized
INFO - 2020-09-14 17:15:18 --> Controller Class Initialized
DEBUG - 2020-09-14 17:15:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:15:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:15:18 --> Model Class Initialized
INFO - 2020-09-14 17:15:18 --> Model Class Initialized
INFO - 2020-09-14 17:15:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-09-14 17:15:18 --> Final output sent to browser
DEBUG - 2020-09-14 17:15:18 --> Total execution time: 0.0224
ERROR - 2020-09-14 17:15:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:15:25 --> Config Class Initialized
INFO - 2020-09-14 17:15:25 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:15:25 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:15:25 --> Utf8 Class Initialized
INFO - 2020-09-14 17:15:25 --> URI Class Initialized
INFO - 2020-09-14 17:15:25 --> Router Class Initialized
INFO - 2020-09-14 17:15:25 --> Output Class Initialized
INFO - 2020-09-14 17:15:25 --> Security Class Initialized
DEBUG - 2020-09-14 17:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:15:25 --> Input Class Initialized
INFO - 2020-09-14 17:15:25 --> Language Class Initialized
INFO - 2020-09-14 17:15:25 --> Loader Class Initialized
INFO - 2020-09-14 17:15:25 --> Helper loaded: url_helper
INFO - 2020-09-14 17:15:25 --> Database Driver Class Initialized
INFO - 2020-09-14 17:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:15:25 --> Email Class Initialized
INFO - 2020-09-14 17:15:25 --> Controller Class Initialized
DEBUG - 2020-09-14 17:15:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:15:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:15:25 --> Model Class Initialized
INFO - 2020-09-14 17:15:25 --> Model Class Initialized
ERROR - 2020-09-14 17:15:25 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
INFO - 2020-09-14 17:15:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 17:15:25 --> Final output sent to browser
DEBUG - 2020-09-14 17:15:25 --> Total execution time: 0.0336
ERROR - 2020-09-14 17:16:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:16:18 --> Config Class Initialized
INFO - 2020-09-14 17:16:18 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:16:18 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:16:18 --> Utf8 Class Initialized
INFO - 2020-09-14 17:16:18 --> URI Class Initialized
INFO - 2020-09-14 17:16:18 --> Router Class Initialized
INFO - 2020-09-14 17:16:18 --> Output Class Initialized
INFO - 2020-09-14 17:16:18 --> Security Class Initialized
DEBUG - 2020-09-14 17:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:16:18 --> Input Class Initialized
INFO - 2020-09-14 17:16:18 --> Language Class Initialized
INFO - 2020-09-14 17:16:18 --> Loader Class Initialized
INFO - 2020-09-14 17:16:18 --> Helper loaded: url_helper
INFO - 2020-09-14 17:16:18 --> Database Driver Class Initialized
INFO - 2020-09-14 17:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:16:18 --> Email Class Initialized
INFO - 2020-09-14 17:16:18 --> Controller Class Initialized
DEBUG - 2020-09-14 17:16:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:16:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:16:18 --> Model Class Initialized
INFO - 2020-09-14 17:16:18 --> Model Class Initialized
INFO - 2020-09-14 17:16:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-09-14 17:16:18 --> Final output sent to browser
DEBUG - 2020-09-14 17:16:18 --> Total execution time: 0.0206
ERROR - 2020-09-14 17:16:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:16:24 --> Config Class Initialized
INFO - 2020-09-14 17:16:24 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:16:24 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:16:24 --> Utf8 Class Initialized
INFO - 2020-09-14 17:16:24 --> URI Class Initialized
INFO - 2020-09-14 17:16:24 --> Router Class Initialized
INFO - 2020-09-14 17:16:24 --> Output Class Initialized
INFO - 2020-09-14 17:16:24 --> Security Class Initialized
DEBUG - 2020-09-14 17:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:16:24 --> Input Class Initialized
INFO - 2020-09-14 17:16:24 --> Language Class Initialized
INFO - 2020-09-14 17:16:24 --> Loader Class Initialized
INFO - 2020-09-14 17:16:24 --> Helper loaded: url_helper
INFO - 2020-09-14 17:16:24 --> Database Driver Class Initialized
INFO - 2020-09-14 17:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:16:24 --> Email Class Initialized
INFO - 2020-09-14 17:16:24 --> Controller Class Initialized
DEBUG - 2020-09-14 17:16:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:16:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:16:24 --> Model Class Initialized
INFO - 2020-09-14 17:16:24 --> Model Class Initialized
INFO - 2020-09-14 17:16:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 17:16:24 --> Final output sent to browser
DEBUG - 2020-09-14 17:16:24 --> Total execution time: 0.0254
ERROR - 2020-09-14 17:16:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:16:57 --> Config Class Initialized
INFO - 2020-09-14 17:16:57 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:16:57 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:16:57 --> Utf8 Class Initialized
INFO - 2020-09-14 17:16:57 --> URI Class Initialized
INFO - 2020-09-14 17:16:57 --> Router Class Initialized
INFO - 2020-09-14 17:16:57 --> Output Class Initialized
INFO - 2020-09-14 17:16:57 --> Security Class Initialized
DEBUG - 2020-09-14 17:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:16:57 --> Input Class Initialized
INFO - 2020-09-14 17:16:57 --> Language Class Initialized
INFO - 2020-09-14 17:16:57 --> Loader Class Initialized
INFO - 2020-09-14 17:16:57 --> Helper loaded: url_helper
INFO - 2020-09-14 17:16:57 --> Database Driver Class Initialized
INFO - 2020-09-14 17:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:16:57 --> Email Class Initialized
INFO - 2020-09-14 17:16:57 --> Controller Class Initialized
DEBUG - 2020-09-14 17:16:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:16:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:16:57 --> Model Class Initialized
INFO - 2020-09-14 17:16:57 --> Model Class Initialized
INFO - 2020-09-14 17:16:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 17:16:57 --> Final output sent to browser
DEBUG - 2020-09-14 17:16:57 --> Total execution time: 0.0233
ERROR - 2020-09-14 17:17:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:17:02 --> Config Class Initialized
INFO - 2020-09-14 17:17:02 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:17:02 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:17:02 --> Utf8 Class Initialized
INFO - 2020-09-14 17:17:02 --> URI Class Initialized
INFO - 2020-09-14 17:17:02 --> Router Class Initialized
INFO - 2020-09-14 17:17:02 --> Output Class Initialized
INFO - 2020-09-14 17:17:02 --> Security Class Initialized
DEBUG - 2020-09-14 17:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:17:02 --> Input Class Initialized
INFO - 2020-09-14 17:17:02 --> Language Class Initialized
INFO - 2020-09-14 17:17:02 --> Loader Class Initialized
INFO - 2020-09-14 17:17:02 --> Helper loaded: url_helper
INFO - 2020-09-14 17:17:02 --> Database Driver Class Initialized
INFO - 2020-09-14 17:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:17:02 --> Email Class Initialized
INFO - 2020-09-14 17:17:02 --> Controller Class Initialized
DEBUG - 2020-09-14 17:17:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:17:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:17:02 --> Model Class Initialized
INFO - 2020-09-14 17:17:02 --> Model Class Initialized
INFO - 2020-09-14 17:17:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-09-14 17:17:02 --> Final output sent to browser
DEBUG - 2020-09-14 17:17:02 --> Total execution time: 0.0227
ERROR - 2020-09-14 17:17:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:17:11 --> Config Class Initialized
INFO - 2020-09-14 17:17:11 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:17:11 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:17:11 --> Utf8 Class Initialized
INFO - 2020-09-14 17:17:11 --> URI Class Initialized
INFO - 2020-09-14 17:17:11 --> Router Class Initialized
INFO - 2020-09-14 17:17:11 --> Output Class Initialized
INFO - 2020-09-14 17:17:11 --> Security Class Initialized
DEBUG - 2020-09-14 17:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:17:11 --> Input Class Initialized
INFO - 2020-09-14 17:17:11 --> Language Class Initialized
INFO - 2020-09-14 17:17:11 --> Loader Class Initialized
INFO - 2020-09-14 17:17:11 --> Helper loaded: url_helper
INFO - 2020-09-14 17:17:11 --> Database Driver Class Initialized
INFO - 2020-09-14 17:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:17:11 --> Email Class Initialized
INFO - 2020-09-14 17:17:11 --> Controller Class Initialized
DEBUG - 2020-09-14 17:17:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:17:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:17:11 --> Model Class Initialized
INFO - 2020-09-14 17:17:11 --> Model Class Initialized
INFO - 2020-09-14 17:17:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 17:17:11 --> Final output sent to browser
DEBUG - 2020-09-14 17:17:11 --> Total execution time: 0.0201
ERROR - 2020-09-14 17:17:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:17:30 --> Config Class Initialized
INFO - 2020-09-14 17:17:30 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:17:30 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:17:30 --> Utf8 Class Initialized
INFO - 2020-09-14 17:17:30 --> URI Class Initialized
DEBUG - 2020-09-14 17:17:30 --> No URI present. Default controller set.
INFO - 2020-09-14 17:17:30 --> Router Class Initialized
INFO - 2020-09-14 17:17:30 --> Output Class Initialized
INFO - 2020-09-14 17:17:30 --> Security Class Initialized
DEBUG - 2020-09-14 17:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:17:30 --> Input Class Initialized
INFO - 2020-09-14 17:17:30 --> Language Class Initialized
INFO - 2020-09-14 17:17:30 --> Loader Class Initialized
INFO - 2020-09-14 17:17:30 --> Helper loaded: url_helper
INFO - 2020-09-14 17:17:30 --> Database Driver Class Initialized
INFO - 2020-09-14 17:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:17:30 --> Email Class Initialized
INFO - 2020-09-14 17:17:30 --> Controller Class Initialized
INFO - 2020-09-14 17:17:30 --> Model Class Initialized
INFO - 2020-09-14 17:17:30 --> Model Class Initialized
DEBUG - 2020-09-14 17:17:30 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:17:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-14 17:17:30 --> Final output sent to browser
DEBUG - 2020-09-14 17:17:30 --> Total execution time: 0.0197
ERROR - 2020-09-14 17:17:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:17:33 --> Config Class Initialized
INFO - 2020-09-14 17:17:33 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:17:33 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:17:33 --> Utf8 Class Initialized
INFO - 2020-09-14 17:17:33 --> URI Class Initialized
INFO - 2020-09-14 17:17:33 --> Router Class Initialized
INFO - 2020-09-14 17:17:33 --> Output Class Initialized
INFO - 2020-09-14 17:17:33 --> Security Class Initialized
DEBUG - 2020-09-14 17:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:17:33 --> Input Class Initialized
INFO - 2020-09-14 17:17:33 --> Language Class Initialized
INFO - 2020-09-14 17:17:33 --> Loader Class Initialized
INFO - 2020-09-14 17:17:33 --> Helper loaded: url_helper
INFO - 2020-09-14 17:17:33 --> Database Driver Class Initialized
INFO - 2020-09-14 17:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:17:33 --> Email Class Initialized
INFO - 2020-09-14 17:17:33 --> Controller Class Initialized
INFO - 2020-09-14 17:17:33 --> Model Class Initialized
INFO - 2020-09-14 17:17:33 --> Model Class Initialized
DEBUG - 2020-09-14 17:17:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 17:17:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:17:33 --> Config Class Initialized
INFO - 2020-09-14 17:17:33 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:17:33 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:17:33 --> Utf8 Class Initialized
INFO - 2020-09-14 17:17:33 --> URI Class Initialized
INFO - 2020-09-14 17:17:33 --> Router Class Initialized
INFO - 2020-09-14 17:17:33 --> Output Class Initialized
INFO - 2020-09-14 17:17:33 --> Security Class Initialized
DEBUG - 2020-09-14 17:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:17:33 --> Input Class Initialized
INFO - 2020-09-14 17:17:33 --> Language Class Initialized
INFO - 2020-09-14 17:17:33 --> Loader Class Initialized
INFO - 2020-09-14 17:17:33 --> Helper loaded: url_helper
INFO - 2020-09-14 17:17:33 --> Database Driver Class Initialized
INFO - 2020-09-14 17:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:17:33 --> Email Class Initialized
INFO - 2020-09-14 17:17:33 --> Controller Class Initialized
INFO - 2020-09-14 17:17:33 --> Model Class Initialized
INFO - 2020-09-14 17:17:33 --> Model Class Initialized
DEBUG - 2020-09-14 17:17:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:17:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:17:33 --> Model Class Initialized
INFO - 2020-09-14 17:17:33 --> Final output sent to browser
DEBUG - 2020-09-14 17:17:33 --> Total execution time: 0.0202
ERROR - 2020-09-14 17:17:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:17:33 --> Config Class Initialized
INFO - 2020-09-14 17:17:33 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:17:33 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:17:33 --> Utf8 Class Initialized
INFO - 2020-09-14 17:17:33 --> URI Class Initialized
INFO - 2020-09-14 17:17:33 --> Router Class Initialized
INFO - 2020-09-14 17:17:33 --> Output Class Initialized
INFO - 2020-09-14 17:17:33 --> Security Class Initialized
DEBUG - 2020-09-14 17:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:17:33 --> Input Class Initialized
INFO - 2020-09-14 17:17:33 --> Language Class Initialized
INFO - 2020-09-14 17:17:33 --> Loader Class Initialized
INFO - 2020-09-14 17:17:33 --> Helper loaded: url_helper
INFO - 2020-09-14 17:17:33 --> Database Driver Class Initialized
INFO - 2020-09-14 17:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:17:33 --> Email Class Initialized
INFO - 2020-09-14 17:17:33 --> Controller Class Initialized
DEBUG - 2020-09-14 17:17:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:17:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:17:33 --> Model Class Initialized
INFO - 2020-09-14 17:17:33 --> Model Class Initialized
INFO - 2020-09-14 17:17:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 17:17:33 --> Final output sent to browser
DEBUG - 2020-09-14 17:17:33 --> Total execution time: 0.0235
ERROR - 2020-09-14 17:17:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:17:37 --> Config Class Initialized
INFO - 2020-09-14 17:17:37 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:17:37 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:17:37 --> Utf8 Class Initialized
INFO - 2020-09-14 17:17:37 --> URI Class Initialized
INFO - 2020-09-14 17:17:37 --> Router Class Initialized
INFO - 2020-09-14 17:17:37 --> Output Class Initialized
INFO - 2020-09-14 17:17:37 --> Security Class Initialized
DEBUG - 2020-09-14 17:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:17:37 --> Input Class Initialized
INFO - 2020-09-14 17:17:37 --> Language Class Initialized
INFO - 2020-09-14 17:17:37 --> Loader Class Initialized
INFO - 2020-09-14 17:17:37 --> Helper loaded: url_helper
INFO - 2020-09-14 17:17:37 --> Database Driver Class Initialized
INFO - 2020-09-14 17:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:17:37 --> Email Class Initialized
INFO - 2020-09-14 17:17:37 --> Controller Class Initialized
DEBUG - 2020-09-14 17:17:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:17:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:17:37 --> Model Class Initialized
INFO - 2020-09-14 17:17:37 --> Model Class Initialized
INFO - 2020-09-14 17:17:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 17:17:37 --> Final output sent to browser
DEBUG - 2020-09-14 17:17:37 --> Total execution time: 0.0215
ERROR - 2020-09-14 17:17:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:17:41 --> Config Class Initialized
INFO - 2020-09-14 17:17:41 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:17:41 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:17:41 --> Utf8 Class Initialized
INFO - 2020-09-14 17:17:41 --> URI Class Initialized
INFO - 2020-09-14 17:17:41 --> Router Class Initialized
INFO - 2020-09-14 17:17:41 --> Output Class Initialized
INFO - 2020-09-14 17:17:41 --> Security Class Initialized
DEBUG - 2020-09-14 17:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:17:41 --> Input Class Initialized
INFO - 2020-09-14 17:17:41 --> Language Class Initialized
INFO - 2020-09-14 17:17:41 --> Loader Class Initialized
INFO - 2020-09-14 17:17:41 --> Helper loaded: url_helper
INFO - 2020-09-14 17:17:41 --> Database Driver Class Initialized
INFO - 2020-09-14 17:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:17:41 --> Email Class Initialized
INFO - 2020-09-14 17:17:41 --> Controller Class Initialized
DEBUG - 2020-09-14 17:17:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:17:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:17:41 --> Model Class Initialized
INFO - 2020-09-14 17:17:41 --> Model Class Initialized
INFO - 2020-09-14 17:17:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_view.php
INFO - 2020-09-14 17:17:41 --> Final output sent to browser
DEBUG - 2020-09-14 17:17:41 --> Total execution time: 0.0184
ERROR - 2020-09-14 17:17:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:17:44 --> Config Class Initialized
INFO - 2020-09-14 17:17:44 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:17:44 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:17:44 --> Utf8 Class Initialized
INFO - 2020-09-14 17:17:44 --> URI Class Initialized
INFO - 2020-09-14 17:17:44 --> Router Class Initialized
INFO - 2020-09-14 17:17:44 --> Output Class Initialized
INFO - 2020-09-14 17:17:44 --> Security Class Initialized
DEBUG - 2020-09-14 17:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:17:44 --> Input Class Initialized
INFO - 2020-09-14 17:17:44 --> Language Class Initialized
INFO - 2020-09-14 17:17:44 --> Loader Class Initialized
INFO - 2020-09-14 17:17:44 --> Helper loaded: url_helper
INFO - 2020-09-14 17:17:44 --> Database Driver Class Initialized
INFO - 2020-09-14 17:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:17:44 --> Email Class Initialized
INFO - 2020-09-14 17:17:44 --> Controller Class Initialized
DEBUG - 2020-09-14 17:17:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:17:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:17:44 --> Model Class Initialized
INFO - 2020-09-14 17:17:44 --> Model Class Initialized
INFO - 2020-09-14 17:17:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 17:17:44 --> Final output sent to browser
DEBUG - 2020-09-14 17:17:44 --> Total execution time: 0.0200
ERROR - 2020-09-14 17:17:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:17:46 --> Config Class Initialized
INFO - 2020-09-14 17:17:46 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:17:46 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:17:46 --> Utf8 Class Initialized
INFO - 2020-09-14 17:17:46 --> URI Class Initialized
INFO - 2020-09-14 17:17:46 --> Router Class Initialized
INFO - 2020-09-14 17:17:46 --> Output Class Initialized
INFO - 2020-09-14 17:17:46 --> Security Class Initialized
DEBUG - 2020-09-14 17:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:17:46 --> Input Class Initialized
INFO - 2020-09-14 17:17:46 --> Language Class Initialized
INFO - 2020-09-14 17:17:46 --> Loader Class Initialized
INFO - 2020-09-14 17:17:46 --> Helper loaded: url_helper
INFO - 2020-09-14 17:17:46 --> Database Driver Class Initialized
INFO - 2020-09-14 17:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:17:46 --> Email Class Initialized
INFO - 2020-09-14 17:17:46 --> Controller Class Initialized
DEBUG - 2020-09-14 17:17:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:17:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:17:46 --> Model Class Initialized
INFO - 2020-09-14 17:17:46 --> Model Class Initialized
INFO - 2020-09-14 17:17:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-09-14 17:17:46 --> Final output sent to browser
DEBUG - 2020-09-14 17:17:46 --> Total execution time: 0.0193
ERROR - 2020-09-14 17:17:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:17:47 --> Config Class Initialized
INFO - 2020-09-14 17:17:47 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:17:47 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:17:47 --> Utf8 Class Initialized
INFO - 2020-09-14 17:17:47 --> URI Class Initialized
INFO - 2020-09-14 17:17:47 --> Router Class Initialized
INFO - 2020-09-14 17:17:47 --> Output Class Initialized
INFO - 2020-09-14 17:17:47 --> Security Class Initialized
DEBUG - 2020-09-14 17:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:17:47 --> Input Class Initialized
INFO - 2020-09-14 17:17:47 --> Language Class Initialized
INFO - 2020-09-14 17:17:47 --> Loader Class Initialized
INFO - 2020-09-14 17:17:47 --> Helper loaded: url_helper
INFO - 2020-09-14 17:17:47 --> Database Driver Class Initialized
INFO - 2020-09-14 17:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:17:47 --> Email Class Initialized
INFO - 2020-09-14 17:17:47 --> Controller Class Initialized
DEBUG - 2020-09-14 17:17:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:17:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:17:47 --> Model Class Initialized
INFO - 2020-09-14 17:17:47 --> Model Class Initialized
INFO - 2020-09-14 17:17:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 17:17:47 --> Final output sent to browser
DEBUG - 2020-09-14 17:17:47 --> Total execution time: 0.0239
ERROR - 2020-09-14 17:17:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:17:51 --> Config Class Initialized
INFO - 2020-09-14 17:17:51 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:17:51 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:17:51 --> Utf8 Class Initialized
INFO - 2020-09-14 17:17:51 --> URI Class Initialized
INFO - 2020-09-14 17:17:51 --> Router Class Initialized
INFO - 2020-09-14 17:17:51 --> Output Class Initialized
INFO - 2020-09-14 17:17:51 --> Security Class Initialized
DEBUG - 2020-09-14 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:17:51 --> Input Class Initialized
INFO - 2020-09-14 17:17:51 --> Language Class Initialized
INFO - 2020-09-14 17:17:51 --> Loader Class Initialized
INFO - 2020-09-14 17:17:51 --> Helper loaded: url_helper
INFO - 2020-09-14 17:17:51 --> Database Driver Class Initialized
INFO - 2020-09-14 17:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:17:51 --> Email Class Initialized
INFO - 2020-09-14 17:17:51 --> Controller Class Initialized
DEBUG - 2020-09-14 17:17:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:17:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:17:51 --> Model Class Initialized
INFO - 2020-09-14 17:17:51 --> Model Class Initialized
INFO - 2020-09-14 17:17:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-09-14 17:17:51 --> Final output sent to browser
DEBUG - 2020-09-14 17:17:51 --> Total execution time: 0.0193
ERROR - 2020-09-14 17:17:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:17:53 --> Config Class Initialized
INFO - 2020-09-14 17:17:53 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:17:53 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:17:53 --> Utf8 Class Initialized
INFO - 2020-09-14 17:17:53 --> URI Class Initialized
INFO - 2020-09-14 17:17:53 --> Router Class Initialized
INFO - 2020-09-14 17:17:53 --> Output Class Initialized
INFO - 2020-09-14 17:17:53 --> Security Class Initialized
DEBUG - 2020-09-14 17:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:17:53 --> Input Class Initialized
INFO - 2020-09-14 17:17:53 --> Language Class Initialized
INFO - 2020-09-14 17:17:53 --> Loader Class Initialized
INFO - 2020-09-14 17:17:53 --> Helper loaded: url_helper
INFO - 2020-09-14 17:17:53 --> Database Driver Class Initialized
INFO - 2020-09-14 17:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:17:53 --> Email Class Initialized
INFO - 2020-09-14 17:17:53 --> Controller Class Initialized
DEBUG - 2020-09-14 17:17:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:17:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:17:53 --> Model Class Initialized
INFO - 2020-09-14 17:17:53 --> Model Class Initialized
INFO - 2020-09-14 17:17:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 17:17:53 --> Final output sent to browser
DEBUG - 2020-09-14 17:17:53 --> Total execution time: 0.0213
ERROR - 2020-09-14 17:18:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:18:01 --> Config Class Initialized
INFO - 2020-09-14 17:18:01 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:18:01 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:18:01 --> Utf8 Class Initialized
INFO - 2020-09-14 17:18:01 --> URI Class Initialized
INFO - 2020-09-14 17:18:01 --> Router Class Initialized
INFO - 2020-09-14 17:18:01 --> Output Class Initialized
INFO - 2020-09-14 17:18:01 --> Security Class Initialized
DEBUG - 2020-09-14 17:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:18:01 --> Input Class Initialized
INFO - 2020-09-14 17:18:01 --> Language Class Initialized
INFO - 2020-09-14 17:18:01 --> Loader Class Initialized
INFO - 2020-09-14 17:18:01 --> Helper loaded: url_helper
INFO - 2020-09-14 17:18:01 --> Database Driver Class Initialized
INFO - 2020-09-14 17:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:18:01 --> Email Class Initialized
INFO - 2020-09-14 17:18:01 --> Controller Class Initialized
DEBUG - 2020-09-14 17:18:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:18:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:18:01 --> Model Class Initialized
INFO - 2020-09-14 17:18:01 --> Model Class Initialized
INFO - 2020-09-14 17:18:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_view.php
INFO - 2020-09-14 17:18:01 --> Final output sent to browser
DEBUG - 2020-09-14 17:18:01 --> Total execution time: 0.0221
ERROR - 2020-09-14 17:18:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:18:05 --> Config Class Initialized
INFO - 2020-09-14 17:18:05 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:18:05 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:18:05 --> Utf8 Class Initialized
INFO - 2020-09-14 17:18:05 --> URI Class Initialized
INFO - 2020-09-14 17:18:05 --> Router Class Initialized
INFO - 2020-09-14 17:18:05 --> Output Class Initialized
INFO - 2020-09-14 17:18:05 --> Security Class Initialized
DEBUG - 2020-09-14 17:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:18:05 --> Input Class Initialized
INFO - 2020-09-14 17:18:05 --> Language Class Initialized
INFO - 2020-09-14 17:18:05 --> Loader Class Initialized
INFO - 2020-09-14 17:18:05 --> Helper loaded: url_helper
INFO - 2020-09-14 17:18:05 --> Database Driver Class Initialized
INFO - 2020-09-14 17:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:18:05 --> Email Class Initialized
INFO - 2020-09-14 17:18:05 --> Controller Class Initialized
DEBUG - 2020-09-14 17:18:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:18:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:18:05 --> Model Class Initialized
INFO - 2020-09-14 17:18:05 --> Model Class Initialized
INFO - 2020-09-14 17:18:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 17:18:05 --> Final output sent to browser
DEBUG - 2020-09-14 17:18:05 --> Total execution time: 0.0237
ERROR - 2020-09-14 17:18:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:18:41 --> Config Class Initialized
INFO - 2020-09-14 17:18:41 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:18:41 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:18:41 --> Utf8 Class Initialized
INFO - 2020-09-14 17:18:41 --> URI Class Initialized
INFO - 2020-09-14 17:18:41 --> Router Class Initialized
INFO - 2020-09-14 17:18:41 --> Output Class Initialized
INFO - 2020-09-14 17:18:41 --> Security Class Initialized
DEBUG - 2020-09-14 17:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:18:41 --> Input Class Initialized
INFO - 2020-09-14 17:18:41 --> Language Class Initialized
INFO - 2020-09-14 17:18:41 --> Loader Class Initialized
INFO - 2020-09-14 17:18:41 --> Helper loaded: url_helper
INFO - 2020-09-14 17:18:41 --> Database Driver Class Initialized
INFO - 2020-09-14 17:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:18:41 --> Email Class Initialized
INFO - 2020-09-14 17:18:41 --> Controller Class Initialized
DEBUG - 2020-09-14 17:18:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:18:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:18:41 --> Model Class Initialized
INFO - 2020-09-14 17:18:41 --> Model Class Initialized
INFO - 2020-09-14 17:18:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 17:18:41 --> Final output sent to browser
DEBUG - 2020-09-14 17:18:41 --> Total execution time: 0.0232
ERROR - 2020-09-14 17:18:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:18:44 --> Config Class Initialized
INFO - 2020-09-14 17:18:44 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:18:44 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:18:44 --> Utf8 Class Initialized
INFO - 2020-09-14 17:18:44 --> URI Class Initialized
INFO - 2020-09-14 17:18:44 --> Router Class Initialized
INFO - 2020-09-14 17:18:44 --> Output Class Initialized
INFO - 2020-09-14 17:18:44 --> Security Class Initialized
DEBUG - 2020-09-14 17:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:18:44 --> Input Class Initialized
INFO - 2020-09-14 17:18:44 --> Language Class Initialized
INFO - 2020-09-14 17:18:44 --> Loader Class Initialized
INFO - 2020-09-14 17:18:44 --> Helper loaded: url_helper
INFO - 2020-09-14 17:18:44 --> Database Driver Class Initialized
INFO - 2020-09-14 17:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:18:44 --> Email Class Initialized
INFO - 2020-09-14 17:18:44 --> Controller Class Initialized
DEBUG - 2020-09-14 17:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:18:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:18:44 --> Model Class Initialized
INFO - 2020-09-14 17:18:44 --> Model Class Initialized
INFO - 2020-09-14 17:18:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 17:18:44 --> Final output sent to browser
DEBUG - 2020-09-14 17:18:44 --> Total execution time: 0.0205
ERROR - 2020-09-14 17:19:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:19:32 --> Config Class Initialized
INFO - 2020-09-14 17:19:32 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:19:32 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:19:32 --> Utf8 Class Initialized
INFO - 2020-09-14 17:19:32 --> URI Class Initialized
INFO - 2020-09-14 17:19:32 --> Router Class Initialized
INFO - 2020-09-14 17:19:32 --> Output Class Initialized
INFO - 2020-09-14 17:19:32 --> Security Class Initialized
DEBUG - 2020-09-14 17:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:19:32 --> Input Class Initialized
INFO - 2020-09-14 17:19:32 --> Language Class Initialized
INFO - 2020-09-14 17:19:32 --> Loader Class Initialized
INFO - 2020-09-14 17:19:32 --> Helper loaded: url_helper
INFO - 2020-09-14 17:19:32 --> Database Driver Class Initialized
INFO - 2020-09-14 17:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:19:32 --> Email Class Initialized
INFO - 2020-09-14 17:19:32 --> Controller Class Initialized
DEBUG - 2020-09-14 17:19:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:19:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:19:32 --> Model Class Initialized
INFO - 2020-09-14 17:19:32 --> Model Class Initialized
INFO - 2020-09-14 17:19:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-09-14 17:19:32 --> Final output sent to browser
DEBUG - 2020-09-14 17:19:32 --> Total execution time: 0.0244
ERROR - 2020-09-14 17:19:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:19:35 --> Config Class Initialized
INFO - 2020-09-14 17:19:35 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:19:35 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:19:35 --> Utf8 Class Initialized
INFO - 2020-09-14 17:19:35 --> URI Class Initialized
INFO - 2020-09-14 17:19:35 --> Router Class Initialized
INFO - 2020-09-14 17:19:35 --> Output Class Initialized
INFO - 2020-09-14 17:19:35 --> Security Class Initialized
DEBUG - 2020-09-14 17:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:19:35 --> Input Class Initialized
INFO - 2020-09-14 17:19:35 --> Language Class Initialized
INFO - 2020-09-14 17:19:35 --> Loader Class Initialized
INFO - 2020-09-14 17:19:35 --> Helper loaded: url_helper
INFO - 2020-09-14 17:19:35 --> Database Driver Class Initialized
INFO - 2020-09-14 17:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:19:35 --> Email Class Initialized
INFO - 2020-09-14 17:19:35 --> Controller Class Initialized
DEBUG - 2020-09-14 17:19:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:19:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:19:35 --> Model Class Initialized
INFO - 2020-09-14 17:19:35 --> Model Class Initialized
INFO - 2020-09-14 17:19:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 17:19:35 --> Final output sent to browser
DEBUG - 2020-09-14 17:19:35 --> Total execution time: 0.0234
ERROR - 2020-09-14 17:19:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:19:39 --> Config Class Initialized
INFO - 2020-09-14 17:19:39 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:19:39 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:19:39 --> Utf8 Class Initialized
INFO - 2020-09-14 17:19:39 --> URI Class Initialized
INFO - 2020-09-14 17:19:39 --> Router Class Initialized
INFO - 2020-09-14 17:19:39 --> Output Class Initialized
INFO - 2020-09-14 17:19:39 --> Security Class Initialized
DEBUG - 2020-09-14 17:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:19:39 --> Input Class Initialized
INFO - 2020-09-14 17:19:39 --> Language Class Initialized
INFO - 2020-09-14 17:19:39 --> Loader Class Initialized
INFO - 2020-09-14 17:19:39 --> Helper loaded: url_helper
INFO - 2020-09-14 17:19:39 --> Database Driver Class Initialized
INFO - 2020-09-14 17:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:19:39 --> Email Class Initialized
INFO - 2020-09-14 17:19:39 --> Controller Class Initialized
DEBUG - 2020-09-14 17:19:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:19:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:19:39 --> Model Class Initialized
INFO - 2020-09-14 17:19:39 --> Model Class Initialized
INFO - 2020-09-14 17:19:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 17:19:39 --> Final output sent to browser
DEBUG - 2020-09-14 17:19:39 --> Total execution time: 0.0299
ERROR - 2020-09-14 17:19:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:19:42 --> Config Class Initialized
INFO - 2020-09-14 17:19:42 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:19:42 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:19:42 --> Utf8 Class Initialized
INFO - 2020-09-14 17:19:42 --> URI Class Initialized
INFO - 2020-09-14 17:19:42 --> Router Class Initialized
INFO - 2020-09-14 17:19:42 --> Output Class Initialized
INFO - 2020-09-14 17:19:42 --> Security Class Initialized
DEBUG - 2020-09-14 17:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:19:42 --> Input Class Initialized
INFO - 2020-09-14 17:19:42 --> Language Class Initialized
INFO - 2020-09-14 17:19:42 --> Loader Class Initialized
INFO - 2020-09-14 17:19:42 --> Helper loaded: url_helper
INFO - 2020-09-14 17:19:42 --> Database Driver Class Initialized
INFO - 2020-09-14 17:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:19:42 --> Email Class Initialized
INFO - 2020-09-14 17:19:42 --> Controller Class Initialized
DEBUG - 2020-09-14 17:19:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:19:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:19:42 --> Model Class Initialized
INFO - 2020-09-14 17:19:42 --> Model Class Initialized
INFO - 2020-09-14 17:19:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_view.php
INFO - 2020-09-14 17:19:42 --> Final output sent to browser
DEBUG - 2020-09-14 17:19:42 --> Total execution time: 0.0266
ERROR - 2020-09-14 17:19:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:19:43 --> Config Class Initialized
INFO - 2020-09-14 17:19:43 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:19:43 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:19:43 --> Utf8 Class Initialized
INFO - 2020-09-14 17:19:43 --> URI Class Initialized
INFO - 2020-09-14 17:19:43 --> Router Class Initialized
INFO - 2020-09-14 17:19:43 --> Output Class Initialized
INFO - 2020-09-14 17:19:43 --> Security Class Initialized
DEBUG - 2020-09-14 17:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:19:43 --> Input Class Initialized
INFO - 2020-09-14 17:19:43 --> Language Class Initialized
INFO - 2020-09-14 17:19:43 --> Loader Class Initialized
INFO - 2020-09-14 17:19:43 --> Helper loaded: url_helper
INFO - 2020-09-14 17:19:43 --> Database Driver Class Initialized
INFO - 2020-09-14 17:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:19:44 --> Email Class Initialized
INFO - 2020-09-14 17:19:44 --> Controller Class Initialized
DEBUG - 2020-09-14 17:19:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:19:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:19:44 --> Model Class Initialized
INFO - 2020-09-14 17:19:44 --> Model Class Initialized
INFO - 2020-09-14 17:19:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 17:19:44 --> Final output sent to browser
DEBUG - 2020-09-14 17:19:44 --> Total execution time: 0.4212
ERROR - 2020-09-14 17:19:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:19:47 --> Config Class Initialized
INFO - 2020-09-14 17:19:47 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:19:47 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:19:47 --> Utf8 Class Initialized
INFO - 2020-09-14 17:19:47 --> URI Class Initialized
INFO - 2020-09-14 17:19:47 --> Router Class Initialized
INFO - 2020-09-14 17:19:47 --> Output Class Initialized
INFO - 2020-09-14 17:19:47 --> Security Class Initialized
DEBUG - 2020-09-14 17:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:19:47 --> Input Class Initialized
INFO - 2020-09-14 17:19:47 --> Language Class Initialized
INFO - 2020-09-14 17:19:47 --> Loader Class Initialized
INFO - 2020-09-14 17:19:47 --> Helper loaded: url_helper
INFO - 2020-09-14 17:19:47 --> Database Driver Class Initialized
INFO - 2020-09-14 17:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:19:48 --> Email Class Initialized
INFO - 2020-09-14 17:19:48 --> Controller Class Initialized
DEBUG - 2020-09-14 17:19:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:19:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:19:48 --> Model Class Initialized
INFO - 2020-09-14 17:19:48 --> Model Class Initialized
INFO - 2020-09-14 17:19:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 17:19:48 --> Final output sent to browser
DEBUG - 2020-09-14 17:19:48 --> Total execution time: 0.1003
ERROR - 2020-09-14 17:19:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:19:50 --> Config Class Initialized
INFO - 2020-09-14 17:19:50 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:19:50 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:19:50 --> Utf8 Class Initialized
INFO - 2020-09-14 17:19:50 --> URI Class Initialized
INFO - 2020-09-14 17:19:50 --> Router Class Initialized
INFO - 2020-09-14 17:19:50 --> Output Class Initialized
INFO - 2020-09-14 17:19:50 --> Security Class Initialized
DEBUG - 2020-09-14 17:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:19:50 --> Input Class Initialized
INFO - 2020-09-14 17:19:50 --> Language Class Initialized
INFO - 2020-09-14 17:19:50 --> Loader Class Initialized
INFO - 2020-09-14 17:19:50 --> Helper loaded: url_helper
INFO - 2020-09-14 17:19:50 --> Database Driver Class Initialized
INFO - 2020-09-14 17:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:19:50 --> Email Class Initialized
INFO - 2020-09-14 17:19:50 --> Controller Class Initialized
DEBUG - 2020-09-14 17:19:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:19:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:19:50 --> Model Class Initialized
INFO - 2020-09-14 17:19:50 --> Model Class Initialized
INFO - 2020-09-14 17:19:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-09-14 17:19:50 --> Final output sent to browser
DEBUG - 2020-09-14 17:19:50 --> Total execution time: 0.0192
ERROR - 2020-09-14 17:19:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:19:53 --> Config Class Initialized
INFO - 2020-09-14 17:19:53 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:19:53 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:19:53 --> Utf8 Class Initialized
INFO - 2020-09-14 17:19:53 --> URI Class Initialized
INFO - 2020-09-14 17:19:53 --> Router Class Initialized
INFO - 2020-09-14 17:19:53 --> Output Class Initialized
INFO - 2020-09-14 17:19:53 --> Security Class Initialized
DEBUG - 2020-09-14 17:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:19:53 --> Input Class Initialized
INFO - 2020-09-14 17:19:53 --> Language Class Initialized
INFO - 2020-09-14 17:19:53 --> Loader Class Initialized
INFO - 2020-09-14 17:19:53 --> Helper loaded: url_helper
INFO - 2020-09-14 17:19:53 --> Database Driver Class Initialized
INFO - 2020-09-14 17:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:19:53 --> Email Class Initialized
INFO - 2020-09-14 17:19:53 --> Controller Class Initialized
DEBUG - 2020-09-14 17:19:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:19:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:19:53 --> Model Class Initialized
INFO - 2020-09-14 17:19:53 --> Model Class Initialized
INFO - 2020-09-14 17:19:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 17:19:53 --> Final output sent to browser
DEBUG - 2020-09-14 17:19:53 --> Total execution time: 0.0214
ERROR - 2020-09-14 17:19:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:19:57 --> Config Class Initialized
INFO - 2020-09-14 17:19:57 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:19:57 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:19:57 --> Utf8 Class Initialized
INFO - 2020-09-14 17:19:57 --> URI Class Initialized
INFO - 2020-09-14 17:19:57 --> Router Class Initialized
INFO - 2020-09-14 17:19:57 --> Output Class Initialized
INFO - 2020-09-14 17:19:57 --> Security Class Initialized
DEBUG - 2020-09-14 17:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:19:57 --> Input Class Initialized
INFO - 2020-09-14 17:19:57 --> Language Class Initialized
INFO - 2020-09-14 17:19:57 --> Loader Class Initialized
INFO - 2020-09-14 17:19:57 --> Helper loaded: url_helper
INFO - 2020-09-14 17:19:57 --> Database Driver Class Initialized
INFO - 2020-09-14 17:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:19:57 --> Email Class Initialized
INFO - 2020-09-14 17:19:57 --> Controller Class Initialized
DEBUG - 2020-09-14 17:19:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:19:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:19:57 --> Model Class Initialized
INFO - 2020-09-14 17:19:57 --> Model Class Initialized
INFO - 2020-09-14 17:19:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-09-14 17:19:57 --> Final output sent to browser
DEBUG - 2020-09-14 17:19:57 --> Total execution time: 0.0217
ERROR - 2020-09-14 17:19:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:19:59 --> Config Class Initialized
INFO - 2020-09-14 17:19:59 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:19:59 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:19:59 --> Utf8 Class Initialized
INFO - 2020-09-14 17:19:59 --> URI Class Initialized
INFO - 2020-09-14 17:19:59 --> Router Class Initialized
INFO - 2020-09-14 17:19:59 --> Output Class Initialized
INFO - 2020-09-14 17:19:59 --> Security Class Initialized
DEBUG - 2020-09-14 17:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:19:59 --> Input Class Initialized
INFO - 2020-09-14 17:19:59 --> Language Class Initialized
INFO - 2020-09-14 17:19:59 --> Loader Class Initialized
INFO - 2020-09-14 17:19:59 --> Helper loaded: url_helper
INFO - 2020-09-14 17:19:59 --> Database Driver Class Initialized
INFO - 2020-09-14 17:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:19:59 --> Email Class Initialized
INFO - 2020-09-14 17:19:59 --> Controller Class Initialized
DEBUG - 2020-09-14 17:19:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:19:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:19:59 --> Model Class Initialized
INFO - 2020-09-14 17:19:59 --> Model Class Initialized
INFO - 2020-09-14 17:19:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 17:19:59 --> Final output sent to browser
DEBUG - 2020-09-14 17:19:59 --> Total execution time: 0.0230
ERROR - 2020-09-14 17:21:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:21:36 --> Config Class Initialized
INFO - 2020-09-14 17:21:36 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:21:36 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:21:36 --> Utf8 Class Initialized
INFO - 2020-09-14 17:21:36 --> URI Class Initialized
INFO - 2020-09-14 17:21:36 --> Router Class Initialized
INFO - 2020-09-14 17:21:36 --> Output Class Initialized
INFO - 2020-09-14 17:21:36 --> Security Class Initialized
DEBUG - 2020-09-14 17:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:21:36 --> Input Class Initialized
INFO - 2020-09-14 17:21:36 --> Language Class Initialized
INFO - 2020-09-14 17:21:36 --> Loader Class Initialized
INFO - 2020-09-14 17:21:36 --> Helper loaded: url_helper
INFO - 2020-09-14 17:21:36 --> Database Driver Class Initialized
INFO - 2020-09-14 17:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:21:36 --> Email Class Initialized
INFO - 2020-09-14 17:21:36 --> Controller Class Initialized
DEBUG - 2020-09-14 17:21:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:21:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:21:36 --> Model Class Initialized
INFO - 2020-09-14 17:21:36 --> Model Class Initialized
INFO - 2020-09-14 17:21:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 17:21:36 --> Final output sent to browser
DEBUG - 2020-09-14 17:21:36 --> Total execution time: 0.0258
ERROR - 2020-09-14 17:21:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:21:46 --> Config Class Initialized
INFO - 2020-09-14 17:21:46 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:21:46 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:21:46 --> Utf8 Class Initialized
INFO - 2020-09-14 17:21:46 --> URI Class Initialized
INFO - 2020-09-14 17:21:46 --> Router Class Initialized
INFO - 2020-09-14 17:21:46 --> Output Class Initialized
INFO - 2020-09-14 17:21:46 --> Security Class Initialized
DEBUG - 2020-09-14 17:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:21:46 --> Input Class Initialized
INFO - 2020-09-14 17:21:46 --> Language Class Initialized
INFO - 2020-09-14 17:21:46 --> Loader Class Initialized
INFO - 2020-09-14 17:21:46 --> Helper loaded: url_helper
INFO - 2020-09-14 17:21:46 --> Database Driver Class Initialized
INFO - 2020-09-14 17:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:21:46 --> Email Class Initialized
INFO - 2020-09-14 17:21:46 --> Controller Class Initialized
DEBUG - 2020-09-14 17:21:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:21:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:21:46 --> Model Class Initialized
INFO - 2020-09-14 17:21:46 --> Model Class Initialized
INFO - 2020-09-14 17:21:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-09-14 17:21:46 --> Final output sent to browser
DEBUG - 2020-09-14 17:21:46 --> Total execution time: 0.0216
ERROR - 2020-09-14 17:22:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:22:33 --> Config Class Initialized
INFO - 2020-09-14 17:22:33 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:22:33 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:22:33 --> Utf8 Class Initialized
INFO - 2020-09-14 17:22:33 --> URI Class Initialized
INFO - 2020-09-14 17:22:33 --> Router Class Initialized
INFO - 2020-09-14 17:22:33 --> Output Class Initialized
INFO - 2020-09-14 17:22:33 --> Security Class Initialized
DEBUG - 2020-09-14 17:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:22:33 --> Input Class Initialized
INFO - 2020-09-14 17:22:33 --> Language Class Initialized
INFO - 2020-09-14 17:22:33 --> Loader Class Initialized
INFO - 2020-09-14 17:22:33 --> Helper loaded: url_helper
INFO - 2020-09-14 17:22:33 --> Database Driver Class Initialized
INFO - 2020-09-14 17:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:22:33 --> Email Class Initialized
INFO - 2020-09-14 17:22:33 --> Controller Class Initialized
DEBUG - 2020-09-14 17:22:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:22:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:22:33 --> Model Class Initialized
INFO - 2020-09-14 17:22:33 --> Model Class Initialized
INFO - 2020-09-14 17:22:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-09-14 17:22:33 --> Final output sent to browser
DEBUG - 2020-09-14 17:22:33 --> Total execution time: 0.0240
ERROR - 2020-09-14 17:22:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:22:59 --> Config Class Initialized
INFO - 2020-09-14 17:22:59 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:22:59 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:22:59 --> Utf8 Class Initialized
INFO - 2020-09-14 17:22:59 --> URI Class Initialized
INFO - 2020-09-14 17:22:59 --> Router Class Initialized
INFO - 2020-09-14 17:22:59 --> Output Class Initialized
INFO - 2020-09-14 17:22:59 --> Security Class Initialized
DEBUG - 2020-09-14 17:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:22:59 --> Input Class Initialized
INFO - 2020-09-14 17:22:59 --> Language Class Initialized
INFO - 2020-09-14 17:22:59 --> Loader Class Initialized
INFO - 2020-09-14 17:22:59 --> Helper loaded: url_helper
INFO - 2020-09-14 17:22:59 --> Database Driver Class Initialized
INFO - 2020-09-14 17:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:22:59 --> Email Class Initialized
INFO - 2020-09-14 17:22:59 --> Controller Class Initialized
DEBUG - 2020-09-14 17:22:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:22:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:22:59 --> Model Class Initialized
INFO - 2020-09-14 17:22:59 --> Model Class Initialized
INFO - 2020-09-14 17:22:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-09-14 17:22:59 --> Final output sent to browser
DEBUG - 2020-09-14 17:22:59 --> Total execution time: 0.0235
ERROR - 2020-09-14 17:23:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:23:02 --> Config Class Initialized
INFO - 2020-09-14 17:23:02 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:23:02 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:23:02 --> Utf8 Class Initialized
INFO - 2020-09-14 17:23:02 --> URI Class Initialized
INFO - 2020-09-14 17:23:02 --> Router Class Initialized
INFO - 2020-09-14 17:23:02 --> Output Class Initialized
INFO - 2020-09-14 17:23:02 --> Security Class Initialized
DEBUG - 2020-09-14 17:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:23:02 --> Input Class Initialized
INFO - 2020-09-14 17:23:02 --> Language Class Initialized
INFO - 2020-09-14 17:23:02 --> Loader Class Initialized
INFO - 2020-09-14 17:23:02 --> Helper loaded: url_helper
INFO - 2020-09-14 17:23:02 --> Database Driver Class Initialized
INFO - 2020-09-14 17:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:23:02 --> Email Class Initialized
INFO - 2020-09-14 17:23:02 --> Controller Class Initialized
DEBUG - 2020-09-14 17:23:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:23:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:23:02 --> Model Class Initialized
INFO - 2020-09-14 17:23:02 --> Model Class Initialized
INFO - 2020-09-14 17:23:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 17:23:02 --> Final output sent to browser
DEBUG - 2020-09-14 17:23:02 --> Total execution time: 0.0219
ERROR - 2020-09-14 17:23:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:23:04 --> Config Class Initialized
INFO - 2020-09-14 17:23:04 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:23:04 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:23:04 --> Utf8 Class Initialized
INFO - 2020-09-14 17:23:04 --> URI Class Initialized
INFO - 2020-09-14 17:23:04 --> Router Class Initialized
INFO - 2020-09-14 17:23:04 --> Output Class Initialized
INFO - 2020-09-14 17:23:04 --> Security Class Initialized
DEBUG - 2020-09-14 17:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:23:04 --> Input Class Initialized
INFO - 2020-09-14 17:23:04 --> Language Class Initialized
INFO - 2020-09-14 17:23:04 --> Loader Class Initialized
INFO - 2020-09-14 17:23:04 --> Helper loaded: url_helper
INFO - 2020-09-14 17:23:04 --> Database Driver Class Initialized
INFO - 2020-09-14 17:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:23:04 --> Email Class Initialized
INFO - 2020-09-14 17:23:04 --> Controller Class Initialized
DEBUG - 2020-09-14 17:23:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:23:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:23:04 --> Model Class Initialized
INFO - 2020-09-14 17:23:04 --> Model Class Initialized
INFO - 2020-09-14 17:23:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_view.php
INFO - 2020-09-14 17:23:04 --> Final output sent to browser
DEBUG - 2020-09-14 17:23:04 --> Total execution time: 0.0241
ERROR - 2020-09-14 17:23:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:23:09 --> Config Class Initialized
INFO - 2020-09-14 17:23:09 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:23:09 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:23:09 --> Utf8 Class Initialized
INFO - 2020-09-14 17:23:09 --> URI Class Initialized
INFO - 2020-09-14 17:23:09 --> Router Class Initialized
INFO - 2020-09-14 17:23:09 --> Output Class Initialized
INFO - 2020-09-14 17:23:09 --> Security Class Initialized
DEBUG - 2020-09-14 17:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:23:09 --> Input Class Initialized
INFO - 2020-09-14 17:23:09 --> Language Class Initialized
INFO - 2020-09-14 17:23:09 --> Loader Class Initialized
INFO - 2020-09-14 17:23:09 --> Helper loaded: url_helper
INFO - 2020-09-14 17:23:09 --> Database Driver Class Initialized
INFO - 2020-09-14 17:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:23:09 --> Email Class Initialized
INFO - 2020-09-14 17:23:09 --> Controller Class Initialized
DEBUG - 2020-09-14 17:23:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:23:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:23:09 --> Model Class Initialized
INFO - 2020-09-14 17:23:09 --> Model Class Initialized
INFO - 2020-09-14 17:23:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 17:23:09 --> Final output sent to browser
DEBUG - 2020-09-14 17:23:09 --> Total execution time: 0.0198
ERROR - 2020-09-14 17:23:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:23:33 --> Config Class Initialized
INFO - 2020-09-14 17:23:33 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:23:33 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:23:33 --> Utf8 Class Initialized
INFO - 2020-09-14 17:23:33 --> URI Class Initialized
INFO - 2020-09-14 17:23:33 --> Router Class Initialized
INFO - 2020-09-14 17:23:33 --> Output Class Initialized
INFO - 2020-09-14 17:23:33 --> Security Class Initialized
DEBUG - 2020-09-14 17:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:23:33 --> Input Class Initialized
INFO - 2020-09-14 17:23:33 --> Language Class Initialized
INFO - 2020-09-14 17:23:33 --> Loader Class Initialized
INFO - 2020-09-14 17:23:33 --> Helper loaded: url_helper
INFO - 2020-09-14 17:23:33 --> Database Driver Class Initialized
INFO - 2020-09-14 17:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:23:33 --> Email Class Initialized
INFO - 2020-09-14 17:23:33 --> Controller Class Initialized
DEBUG - 2020-09-14 17:23:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:23:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:23:33 --> Model Class Initialized
INFO - 2020-09-14 17:23:33 --> Model Class Initialized
INFO - 2020-09-14 17:23:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 17:23:33 --> Final output sent to browser
DEBUG - 2020-09-14 17:23:33 --> Total execution time: 0.0238
ERROR - 2020-09-14 17:24:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:24:01 --> Config Class Initialized
INFO - 2020-09-14 17:24:01 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:24:01 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:24:01 --> Utf8 Class Initialized
INFO - 2020-09-14 17:24:01 --> URI Class Initialized
INFO - 2020-09-14 17:24:01 --> Router Class Initialized
INFO - 2020-09-14 17:24:01 --> Output Class Initialized
INFO - 2020-09-14 17:24:01 --> Security Class Initialized
DEBUG - 2020-09-14 17:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:24:01 --> Input Class Initialized
INFO - 2020-09-14 17:24:01 --> Language Class Initialized
INFO - 2020-09-14 17:24:01 --> Loader Class Initialized
INFO - 2020-09-14 17:24:01 --> Helper loaded: url_helper
INFO - 2020-09-14 17:24:01 --> Database Driver Class Initialized
INFO - 2020-09-14 17:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:24:01 --> Email Class Initialized
INFO - 2020-09-14 17:24:01 --> Controller Class Initialized
DEBUG - 2020-09-14 17:24:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:24:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:24:01 --> Model Class Initialized
INFO - 2020-09-14 17:24:01 --> Model Class Initialized
INFO - 2020-09-14 17:24:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 17:24:01 --> Final output sent to browser
DEBUG - 2020-09-14 17:24:01 --> Total execution time: 0.0234
ERROR - 2020-09-14 17:24:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:24:08 --> Config Class Initialized
INFO - 2020-09-14 17:24:08 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:24:08 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:24:08 --> Utf8 Class Initialized
INFO - 2020-09-14 17:24:08 --> URI Class Initialized
INFO - 2020-09-14 17:24:08 --> Router Class Initialized
INFO - 2020-09-14 17:24:08 --> Output Class Initialized
INFO - 2020-09-14 17:24:08 --> Security Class Initialized
DEBUG - 2020-09-14 17:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:24:08 --> Input Class Initialized
INFO - 2020-09-14 17:24:08 --> Language Class Initialized
INFO - 2020-09-14 17:24:08 --> Loader Class Initialized
INFO - 2020-09-14 17:24:08 --> Helper loaded: url_helper
INFO - 2020-09-14 17:24:08 --> Database Driver Class Initialized
INFO - 2020-09-14 17:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:24:08 --> Email Class Initialized
INFO - 2020-09-14 17:24:08 --> Controller Class Initialized
DEBUG - 2020-09-14 17:24:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:24:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:24:08 --> Model Class Initialized
INFO - 2020-09-14 17:24:08 --> Model Class Initialized
INFO - 2020-09-14 17:24:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 17:24:08 --> Final output sent to browser
DEBUG - 2020-09-14 17:24:08 --> Total execution time: 0.0248
ERROR - 2020-09-14 17:24:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:24:10 --> Config Class Initialized
INFO - 2020-09-14 17:24:10 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:24:10 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:24:10 --> Utf8 Class Initialized
INFO - 2020-09-14 17:24:10 --> URI Class Initialized
INFO - 2020-09-14 17:24:10 --> Router Class Initialized
INFO - 2020-09-14 17:24:10 --> Output Class Initialized
INFO - 2020-09-14 17:24:10 --> Security Class Initialized
DEBUG - 2020-09-14 17:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:24:10 --> Input Class Initialized
INFO - 2020-09-14 17:24:10 --> Language Class Initialized
INFO - 2020-09-14 17:24:10 --> Loader Class Initialized
INFO - 2020-09-14 17:24:10 --> Helper loaded: url_helper
INFO - 2020-09-14 17:24:10 --> Database Driver Class Initialized
INFO - 2020-09-14 17:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:24:10 --> Email Class Initialized
INFO - 2020-09-14 17:24:10 --> Controller Class Initialized
DEBUG - 2020-09-14 17:24:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:24:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:24:10 --> Model Class Initialized
INFO - 2020-09-14 17:24:10 --> Model Class Initialized
INFO - 2020-09-14 17:24:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-09-14 17:24:10 --> Final output sent to browser
DEBUG - 2020-09-14 17:24:10 --> Total execution time: 0.0215
ERROR - 2020-09-14 17:24:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:24:15 --> Config Class Initialized
INFO - 2020-09-14 17:24:15 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:24:15 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:24:15 --> Utf8 Class Initialized
INFO - 2020-09-14 17:24:15 --> URI Class Initialized
INFO - 2020-09-14 17:24:15 --> Router Class Initialized
INFO - 2020-09-14 17:24:15 --> Output Class Initialized
INFO - 2020-09-14 17:24:15 --> Security Class Initialized
DEBUG - 2020-09-14 17:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:24:15 --> Input Class Initialized
INFO - 2020-09-14 17:24:15 --> Language Class Initialized
INFO - 2020-09-14 17:24:15 --> Loader Class Initialized
INFO - 2020-09-14 17:24:15 --> Helper loaded: url_helper
INFO - 2020-09-14 17:24:15 --> Database Driver Class Initialized
INFO - 2020-09-14 17:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:24:15 --> Email Class Initialized
INFO - 2020-09-14 17:24:15 --> Controller Class Initialized
DEBUG - 2020-09-14 17:24:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:24:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:24:15 --> Model Class Initialized
INFO - 2020-09-14 17:24:15 --> Model Class Initialized
INFO - 2020-09-14 17:24:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 17:24:15 --> Final output sent to browser
DEBUG - 2020-09-14 17:24:15 --> Total execution time: 0.0225
ERROR - 2020-09-14 17:24:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:24:20 --> Config Class Initialized
INFO - 2020-09-14 17:24:20 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:24:20 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:24:20 --> Utf8 Class Initialized
INFO - 2020-09-14 17:24:20 --> URI Class Initialized
INFO - 2020-09-14 17:24:20 --> Router Class Initialized
INFO - 2020-09-14 17:24:20 --> Output Class Initialized
INFO - 2020-09-14 17:24:20 --> Security Class Initialized
DEBUG - 2020-09-14 17:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:24:20 --> Input Class Initialized
INFO - 2020-09-14 17:24:20 --> Language Class Initialized
INFO - 2020-09-14 17:24:20 --> Loader Class Initialized
INFO - 2020-09-14 17:24:20 --> Helper loaded: url_helper
INFO - 2020-09-14 17:24:20 --> Database Driver Class Initialized
INFO - 2020-09-14 17:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:24:20 --> Email Class Initialized
INFO - 2020-09-14 17:24:20 --> Controller Class Initialized
DEBUG - 2020-09-14 17:24:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:24:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:24:20 --> Model Class Initialized
INFO - 2020-09-14 17:24:20 --> Model Class Initialized
INFO - 2020-09-14 17:24:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-14 17:24:20 --> Final output sent to browser
DEBUG - 2020-09-14 17:24:20 --> Total execution time: 0.0319
ERROR - 2020-09-14 17:24:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:24:31 --> Config Class Initialized
INFO - 2020-09-14 17:24:31 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:24:31 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:24:31 --> Utf8 Class Initialized
INFO - 2020-09-14 17:24:31 --> URI Class Initialized
DEBUG - 2020-09-14 17:24:31 --> No URI present. Default controller set.
INFO - 2020-09-14 17:24:31 --> Router Class Initialized
INFO - 2020-09-14 17:24:31 --> Output Class Initialized
INFO - 2020-09-14 17:24:31 --> Security Class Initialized
DEBUG - 2020-09-14 17:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:24:31 --> Input Class Initialized
INFO - 2020-09-14 17:24:31 --> Language Class Initialized
INFO - 2020-09-14 17:24:31 --> Loader Class Initialized
INFO - 2020-09-14 17:24:31 --> Helper loaded: url_helper
INFO - 2020-09-14 17:24:31 --> Database Driver Class Initialized
INFO - 2020-09-14 17:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:24:31 --> Email Class Initialized
INFO - 2020-09-14 17:24:31 --> Controller Class Initialized
INFO - 2020-09-14 17:24:31 --> Model Class Initialized
INFO - 2020-09-14 17:24:31 --> Model Class Initialized
DEBUG - 2020-09-14 17:24:31 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:24:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-14 17:24:31 --> Final output sent to browser
DEBUG - 2020-09-14 17:24:31 --> Total execution time: 0.0198
ERROR - 2020-09-14 17:24:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:24:37 --> Config Class Initialized
INFO - 2020-09-14 17:24:37 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:24:37 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:24:37 --> Utf8 Class Initialized
INFO - 2020-09-14 17:24:37 --> URI Class Initialized
INFO - 2020-09-14 17:24:37 --> Router Class Initialized
INFO - 2020-09-14 17:24:37 --> Output Class Initialized
INFO - 2020-09-14 17:24:37 --> Security Class Initialized
DEBUG - 2020-09-14 17:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:24:37 --> Input Class Initialized
INFO - 2020-09-14 17:24:37 --> Language Class Initialized
INFO - 2020-09-14 17:24:37 --> Loader Class Initialized
INFO - 2020-09-14 17:24:37 --> Helper loaded: url_helper
INFO - 2020-09-14 17:24:37 --> Database Driver Class Initialized
INFO - 2020-09-14 17:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:24:37 --> Email Class Initialized
INFO - 2020-09-14 17:24:37 --> Controller Class Initialized
INFO - 2020-09-14 17:24:37 --> Model Class Initialized
INFO - 2020-09-14 17:24:37 --> Model Class Initialized
DEBUG - 2020-09-14 17:24:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:24:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:24:37 --> Model Class Initialized
INFO - 2020-09-14 17:24:37 --> Final output sent to browser
DEBUG - 2020-09-14 17:24:37 --> Total execution time: 0.0229
ERROR - 2020-09-14 17:24:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:24:37 --> Config Class Initialized
INFO - 2020-09-14 17:24:37 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:24:37 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:24:37 --> Utf8 Class Initialized
INFO - 2020-09-14 17:24:37 --> URI Class Initialized
INFO - 2020-09-14 17:24:37 --> Router Class Initialized
INFO - 2020-09-14 17:24:37 --> Output Class Initialized
INFO - 2020-09-14 17:24:37 --> Security Class Initialized
DEBUG - 2020-09-14 17:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:24:37 --> Input Class Initialized
INFO - 2020-09-14 17:24:37 --> Language Class Initialized
INFO - 2020-09-14 17:24:37 --> Loader Class Initialized
INFO - 2020-09-14 17:24:37 --> Helper loaded: url_helper
INFO - 2020-09-14 17:24:37 --> Database Driver Class Initialized
INFO - 2020-09-14 17:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:24:37 --> Email Class Initialized
INFO - 2020-09-14 17:24:37 --> Controller Class Initialized
INFO - 2020-09-14 17:24:37 --> Model Class Initialized
INFO - 2020-09-14 17:24:37 --> Model Class Initialized
DEBUG - 2020-09-14 17:24:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 17:24:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:24:38 --> Config Class Initialized
INFO - 2020-09-14 17:24:38 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:24:38 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:24:38 --> Utf8 Class Initialized
INFO - 2020-09-14 17:24:38 --> URI Class Initialized
INFO - 2020-09-14 17:24:38 --> Router Class Initialized
INFO - 2020-09-14 17:24:38 --> Output Class Initialized
INFO - 2020-09-14 17:24:38 --> Security Class Initialized
DEBUG - 2020-09-14 17:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:24:38 --> Input Class Initialized
INFO - 2020-09-14 17:24:38 --> Language Class Initialized
INFO - 2020-09-14 17:24:38 --> Loader Class Initialized
INFO - 2020-09-14 17:24:38 --> Helper loaded: url_helper
INFO - 2020-09-14 17:24:38 --> Database Driver Class Initialized
INFO - 2020-09-14 17:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:24:38 --> Email Class Initialized
INFO - 2020-09-14 17:24:38 --> Controller Class Initialized
DEBUG - 2020-09-14 17:24:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:24:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:24:38 --> Model Class Initialized
INFO - 2020-09-14 17:24:38 --> Model Class Initialized
INFO - 2020-09-14 17:24:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 17:24:38 --> Final output sent to browser
DEBUG - 2020-09-14 17:24:38 --> Total execution time: 0.0228
ERROR - 2020-09-14 17:24:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:24:55 --> Config Class Initialized
INFO - 2020-09-14 17:24:55 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:24:55 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:24:55 --> Utf8 Class Initialized
INFO - 2020-09-14 17:24:55 --> URI Class Initialized
INFO - 2020-09-14 17:24:55 --> Router Class Initialized
INFO - 2020-09-14 17:24:55 --> Output Class Initialized
INFO - 2020-09-14 17:24:55 --> Security Class Initialized
DEBUG - 2020-09-14 17:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:24:55 --> Input Class Initialized
INFO - 2020-09-14 17:24:55 --> Language Class Initialized
INFO - 2020-09-14 17:24:55 --> Loader Class Initialized
INFO - 2020-09-14 17:24:55 --> Helper loaded: url_helper
INFO - 2020-09-14 17:24:55 --> Database Driver Class Initialized
INFO - 2020-09-14 17:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:24:55 --> Email Class Initialized
INFO - 2020-09-14 17:24:55 --> Controller Class Initialized
DEBUG - 2020-09-14 17:24:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:24:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:24:55 --> Model Class Initialized
INFO - 2020-09-14 17:24:55 --> Model Class Initialized
INFO - 2020-09-14 17:24:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-14 17:24:55 --> Final output sent to browser
DEBUG - 2020-09-14 17:24:55 --> Total execution time: 0.0200
ERROR - 2020-09-14 17:27:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:27:56 --> Config Class Initialized
INFO - 2020-09-14 17:27:56 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:27:56 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:27:56 --> Utf8 Class Initialized
INFO - 2020-09-14 17:27:56 --> URI Class Initialized
INFO - 2020-09-14 17:27:56 --> Router Class Initialized
INFO - 2020-09-14 17:27:56 --> Output Class Initialized
INFO - 2020-09-14 17:27:56 --> Security Class Initialized
DEBUG - 2020-09-14 17:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:27:56 --> Input Class Initialized
INFO - 2020-09-14 17:27:56 --> Language Class Initialized
INFO - 2020-09-14 17:27:56 --> Loader Class Initialized
INFO - 2020-09-14 17:27:56 --> Helper loaded: url_helper
INFO - 2020-09-14 17:27:56 --> Database Driver Class Initialized
INFO - 2020-09-14 17:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:27:56 --> Email Class Initialized
INFO - 2020-09-14 17:27:56 --> Controller Class Initialized
DEBUG - 2020-09-14 17:27:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:27:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:27:56 --> Model Class Initialized
INFO - 2020-09-14 17:27:56 --> Model Class Initialized
INFO - 2020-09-14 17:27:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-14 17:27:56 --> Final output sent to browser
DEBUG - 2020-09-14 17:27:56 --> Total execution time: 0.0248
ERROR - 2020-09-14 17:28:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:28:02 --> Config Class Initialized
INFO - 2020-09-14 17:28:02 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:28:02 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:28:02 --> Utf8 Class Initialized
INFO - 2020-09-14 17:28:02 --> URI Class Initialized
INFO - 2020-09-14 17:28:02 --> Router Class Initialized
INFO - 2020-09-14 17:28:02 --> Output Class Initialized
INFO - 2020-09-14 17:28:02 --> Security Class Initialized
DEBUG - 2020-09-14 17:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:28:02 --> Input Class Initialized
INFO - 2020-09-14 17:28:02 --> Language Class Initialized
INFO - 2020-09-14 17:28:02 --> Loader Class Initialized
INFO - 2020-09-14 17:28:02 --> Helper loaded: url_helper
INFO - 2020-09-14 17:28:02 --> Database Driver Class Initialized
INFO - 2020-09-14 17:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:28:02 --> Email Class Initialized
INFO - 2020-09-14 17:28:02 --> Controller Class Initialized
DEBUG - 2020-09-14 17:28:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:28:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:28:02 --> Model Class Initialized
INFO - 2020-09-14 17:28:02 --> Model Class Initialized
INFO - 2020-09-14 17:28:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-14 17:28:02 --> Final output sent to browser
DEBUG - 2020-09-14 17:28:02 --> Total execution time: 0.0252
ERROR - 2020-09-14 17:28:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:28:35 --> Config Class Initialized
INFO - 2020-09-14 17:28:35 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:28:35 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:28:35 --> Utf8 Class Initialized
INFO - 2020-09-14 17:28:35 --> URI Class Initialized
INFO - 2020-09-14 17:28:35 --> Router Class Initialized
INFO - 2020-09-14 17:28:35 --> Output Class Initialized
INFO - 2020-09-14 17:28:35 --> Security Class Initialized
DEBUG - 2020-09-14 17:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:28:35 --> Input Class Initialized
INFO - 2020-09-14 17:28:35 --> Language Class Initialized
INFO - 2020-09-14 17:28:35 --> Loader Class Initialized
INFO - 2020-09-14 17:28:35 --> Helper loaded: url_helper
INFO - 2020-09-14 17:28:35 --> Database Driver Class Initialized
INFO - 2020-09-14 17:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:28:35 --> Email Class Initialized
INFO - 2020-09-14 17:28:35 --> Controller Class Initialized
DEBUG - 2020-09-14 17:28:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:28:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:28:35 --> Model Class Initialized
INFO - 2020-09-14 17:28:35 --> Model Class Initialized
INFO - 2020-09-14 17:28:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-14 17:28:35 --> Final output sent to browser
DEBUG - 2020-09-14 17:28:35 --> Total execution time: 0.0217
ERROR - 2020-09-14 17:28:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:28:37 --> Config Class Initialized
INFO - 2020-09-14 17:28:37 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:28:37 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:28:37 --> Utf8 Class Initialized
INFO - 2020-09-14 17:28:37 --> URI Class Initialized
INFO - 2020-09-14 17:28:37 --> Router Class Initialized
INFO - 2020-09-14 17:28:37 --> Output Class Initialized
INFO - 2020-09-14 17:28:37 --> Security Class Initialized
DEBUG - 2020-09-14 17:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:28:37 --> Input Class Initialized
INFO - 2020-09-14 17:28:37 --> Language Class Initialized
INFO - 2020-09-14 17:28:37 --> Loader Class Initialized
INFO - 2020-09-14 17:28:37 --> Helper loaded: url_helper
INFO - 2020-09-14 17:28:37 --> Database Driver Class Initialized
INFO - 2020-09-14 17:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:28:37 --> Email Class Initialized
INFO - 2020-09-14 17:28:37 --> Controller Class Initialized
INFO - 2020-09-14 17:28:37 --> Model Class Initialized
INFO - 2020-09-14 17:28:37 --> Model Class Initialized
INFO - 2020-09-14 17:28:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-14 17:28:37 --> Final output sent to browser
DEBUG - 2020-09-14 17:28:37 --> Total execution time: 0.2506
ERROR - 2020-09-14 17:28:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:28:38 --> Config Class Initialized
INFO - 2020-09-14 17:28:38 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:28:38 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:28:38 --> Utf8 Class Initialized
INFO - 2020-09-14 17:28:38 --> URI Class Initialized
INFO - 2020-09-14 17:28:38 --> Router Class Initialized
INFO - 2020-09-14 17:28:38 --> Output Class Initialized
INFO - 2020-09-14 17:28:38 --> Security Class Initialized
DEBUG - 2020-09-14 17:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:28:38 --> Input Class Initialized
INFO - 2020-09-14 17:28:38 --> Language Class Initialized
INFO - 2020-09-14 17:28:38 --> Loader Class Initialized
INFO - 2020-09-14 17:28:38 --> Helper loaded: url_helper
INFO - 2020-09-14 17:28:38 --> Database Driver Class Initialized
INFO - 2020-09-14 17:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:28:38 --> Email Class Initialized
INFO - 2020-09-14 17:28:38 --> Controller Class Initialized
INFO - 2020-09-14 17:28:38 --> Model Class Initialized
INFO - 2020-09-14 17:28:38 --> Model Class Initialized
INFO - 2020-09-14 17:28:38 --> Final output sent to browser
DEBUG - 2020-09-14 17:28:38 --> Total execution time: 0.0331
ERROR - 2020-09-14 17:28:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:28:51 --> Config Class Initialized
INFO - 2020-09-14 17:28:51 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:28:51 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:28:51 --> Utf8 Class Initialized
INFO - 2020-09-14 17:28:51 --> URI Class Initialized
INFO - 2020-09-14 17:28:51 --> Router Class Initialized
INFO - 2020-09-14 17:28:51 --> Output Class Initialized
INFO - 2020-09-14 17:28:51 --> Security Class Initialized
DEBUG - 2020-09-14 17:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:28:51 --> Input Class Initialized
INFO - 2020-09-14 17:28:51 --> Language Class Initialized
INFO - 2020-09-14 17:28:51 --> Loader Class Initialized
INFO - 2020-09-14 17:28:51 --> Helper loaded: url_helper
INFO - 2020-09-14 17:28:51 --> Database Driver Class Initialized
INFO - 2020-09-14 17:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:28:51 --> Email Class Initialized
INFO - 2020-09-14 17:28:51 --> Controller Class Initialized
INFO - 2020-09-14 17:28:51 --> Model Class Initialized
INFO - 2020-09-14 17:28:51 --> Model Class Initialized
INFO - 2020-09-14 17:28:51 --> Final output sent to browser
DEBUG - 2020-09-14 17:28:51 --> Total execution time: 0.2726
ERROR - 2020-09-14 17:28:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:28:51 --> Config Class Initialized
INFO - 2020-09-14 17:28:51 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:28:51 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:28:51 --> Utf8 Class Initialized
INFO - 2020-09-14 17:28:51 --> URI Class Initialized
INFO - 2020-09-14 17:28:51 --> Router Class Initialized
INFO - 2020-09-14 17:28:51 --> Output Class Initialized
INFO - 2020-09-14 17:28:51 --> Security Class Initialized
DEBUG - 2020-09-14 17:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:28:51 --> Input Class Initialized
INFO - 2020-09-14 17:28:51 --> Language Class Initialized
INFO - 2020-09-14 17:28:51 --> Loader Class Initialized
INFO - 2020-09-14 17:28:51 --> Helper loaded: url_helper
INFO - 2020-09-14 17:28:51 --> Database Driver Class Initialized
INFO - 2020-09-14 17:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:28:51 --> Email Class Initialized
INFO - 2020-09-14 17:28:51 --> Controller Class Initialized
INFO - 2020-09-14 17:28:51 --> Model Class Initialized
INFO - 2020-09-14 17:28:51 --> Model Class Initialized
INFO - 2020-09-14 17:28:51 --> Final output sent to browser
DEBUG - 2020-09-14 17:28:51 --> Total execution time: 0.0375
ERROR - 2020-09-14 17:28:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:28:56 --> Config Class Initialized
INFO - 2020-09-14 17:28:56 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:28:56 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:28:56 --> Utf8 Class Initialized
INFO - 2020-09-14 17:28:56 --> URI Class Initialized
INFO - 2020-09-14 17:28:56 --> Router Class Initialized
INFO - 2020-09-14 17:28:56 --> Output Class Initialized
INFO - 2020-09-14 17:28:56 --> Security Class Initialized
DEBUG - 2020-09-14 17:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:28:56 --> Input Class Initialized
INFO - 2020-09-14 17:28:56 --> Language Class Initialized
INFO - 2020-09-14 17:28:56 --> Loader Class Initialized
INFO - 2020-09-14 17:28:56 --> Helper loaded: url_helper
INFO - 2020-09-14 17:28:56 --> Database Driver Class Initialized
INFO - 2020-09-14 17:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:28:56 --> Email Class Initialized
INFO - 2020-09-14 17:28:56 --> Controller Class Initialized
INFO - 2020-09-14 17:28:56 --> Model Class Initialized
INFO - 2020-09-14 17:28:56 --> Model Class Initialized
INFO - 2020-09-14 17:28:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-14 17:28:56 --> Final output sent to browser
DEBUG - 2020-09-14 17:28:56 --> Total execution time: 0.0990
ERROR - 2020-09-14 17:28:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:28:57 --> Config Class Initialized
INFO - 2020-09-14 17:28:57 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:28:57 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:28:57 --> Utf8 Class Initialized
INFO - 2020-09-14 17:28:57 --> URI Class Initialized
INFO - 2020-09-14 17:28:57 --> Router Class Initialized
INFO - 2020-09-14 17:28:57 --> Output Class Initialized
INFO - 2020-09-14 17:28:57 --> Security Class Initialized
DEBUG - 2020-09-14 17:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:28:57 --> Input Class Initialized
INFO - 2020-09-14 17:28:57 --> Language Class Initialized
INFO - 2020-09-14 17:28:57 --> Loader Class Initialized
INFO - 2020-09-14 17:28:57 --> Helper loaded: url_helper
INFO - 2020-09-14 17:28:57 --> Database Driver Class Initialized
INFO - 2020-09-14 17:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:28:57 --> Email Class Initialized
INFO - 2020-09-14 17:28:57 --> Controller Class Initialized
INFO - 2020-09-14 17:28:57 --> Model Class Initialized
INFO - 2020-09-14 17:28:57 --> Model Class Initialized
INFO - 2020-09-14 17:28:57 --> Final output sent to browser
DEBUG - 2020-09-14 17:28:57 --> Total execution time: 0.0388
ERROR - 2020-09-14 17:29:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:29:02 --> Config Class Initialized
INFO - 2020-09-14 17:29:02 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:29:02 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:29:02 --> Utf8 Class Initialized
INFO - 2020-09-14 17:29:02 --> URI Class Initialized
INFO - 2020-09-14 17:29:02 --> Router Class Initialized
INFO - 2020-09-14 17:29:02 --> Output Class Initialized
INFO - 2020-09-14 17:29:02 --> Security Class Initialized
DEBUG - 2020-09-14 17:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:29:02 --> Input Class Initialized
INFO - 2020-09-14 17:29:02 --> Language Class Initialized
INFO - 2020-09-14 17:29:02 --> Loader Class Initialized
INFO - 2020-09-14 17:29:02 --> Helper loaded: url_helper
INFO - 2020-09-14 17:29:02 --> Database Driver Class Initialized
INFO - 2020-09-14 17:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:29:02 --> Email Class Initialized
INFO - 2020-09-14 17:29:02 --> Controller Class Initialized
DEBUG - 2020-09-14 17:29:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:29:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:29:02 --> Model Class Initialized
INFO - 2020-09-14 17:29:02 --> Model Class Initialized
INFO - 2020-09-14 17:29:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-14 17:29:02 --> Final output sent to browser
DEBUG - 2020-09-14 17:29:02 --> Total execution time: 0.0264
ERROR - 2020-09-14 17:29:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:29:24 --> Config Class Initialized
INFO - 2020-09-14 17:29:24 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:29:24 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:29:24 --> Utf8 Class Initialized
INFO - 2020-09-14 17:29:24 --> URI Class Initialized
INFO - 2020-09-14 17:29:24 --> Router Class Initialized
INFO - 2020-09-14 17:29:24 --> Output Class Initialized
INFO - 2020-09-14 17:29:24 --> Security Class Initialized
DEBUG - 2020-09-14 17:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:29:24 --> Input Class Initialized
INFO - 2020-09-14 17:29:24 --> Language Class Initialized
INFO - 2020-09-14 17:29:24 --> Loader Class Initialized
INFO - 2020-09-14 17:29:24 --> Helper loaded: url_helper
INFO - 2020-09-14 17:29:24 --> Database Driver Class Initialized
INFO - 2020-09-14 17:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:29:24 --> Email Class Initialized
INFO - 2020-09-14 17:29:24 --> Controller Class Initialized
DEBUG - 2020-09-14 17:29:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:29:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:29:24 --> Model Class Initialized
INFO - 2020-09-14 17:29:24 --> Model Class Initialized
INFO - 2020-09-14 17:29:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-14 17:29:24 --> Final output sent to browser
DEBUG - 2020-09-14 17:29:24 --> Total execution time: 0.0227
ERROR - 2020-09-14 17:29:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:29:26 --> Config Class Initialized
INFO - 2020-09-14 17:29:26 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:29:26 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:29:26 --> Utf8 Class Initialized
INFO - 2020-09-14 17:29:26 --> URI Class Initialized
INFO - 2020-09-14 17:29:26 --> Router Class Initialized
INFO - 2020-09-14 17:29:26 --> Output Class Initialized
INFO - 2020-09-14 17:29:26 --> Security Class Initialized
DEBUG - 2020-09-14 17:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:29:26 --> Input Class Initialized
INFO - 2020-09-14 17:29:26 --> Language Class Initialized
INFO - 2020-09-14 17:29:26 --> Loader Class Initialized
INFO - 2020-09-14 17:29:26 --> Helper loaded: url_helper
INFO - 2020-09-14 17:29:26 --> Database Driver Class Initialized
INFO - 2020-09-14 17:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:29:26 --> Email Class Initialized
INFO - 2020-09-14 17:29:26 --> Controller Class Initialized
DEBUG - 2020-09-14 17:29:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:29:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:29:26 --> Model Class Initialized
INFO - 2020-09-14 17:29:26 --> Model Class Initialized
INFO - 2020-09-14 17:29:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-14 17:29:26 --> Final output sent to browser
DEBUG - 2020-09-14 17:29:26 --> Total execution time: 0.0199
ERROR - 2020-09-14 17:29:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:29:30 --> Config Class Initialized
INFO - 2020-09-14 17:29:30 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:29:30 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:29:30 --> Utf8 Class Initialized
INFO - 2020-09-14 17:29:30 --> URI Class Initialized
INFO - 2020-09-14 17:29:30 --> Router Class Initialized
INFO - 2020-09-14 17:29:30 --> Output Class Initialized
INFO - 2020-09-14 17:29:30 --> Security Class Initialized
DEBUG - 2020-09-14 17:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:29:30 --> Input Class Initialized
INFO - 2020-09-14 17:29:30 --> Language Class Initialized
INFO - 2020-09-14 17:29:30 --> Loader Class Initialized
INFO - 2020-09-14 17:29:30 --> Helper loaded: url_helper
INFO - 2020-09-14 17:29:30 --> Database Driver Class Initialized
INFO - 2020-09-14 17:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:29:30 --> Email Class Initialized
INFO - 2020-09-14 17:29:30 --> Controller Class Initialized
DEBUG - 2020-09-14 17:29:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:29:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:29:30 --> Model Class Initialized
INFO - 2020-09-14 17:29:30 --> Model Class Initialized
INFO - 2020-09-14 17:29:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-09-14 17:29:30 --> Final output sent to browser
DEBUG - 2020-09-14 17:29:30 --> Total execution time: 0.0388
ERROR - 2020-09-14 17:30:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:30:37 --> Config Class Initialized
INFO - 2020-09-14 17:30:37 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:30:37 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:30:37 --> Utf8 Class Initialized
INFO - 2020-09-14 17:30:37 --> URI Class Initialized
INFO - 2020-09-14 17:30:37 --> Router Class Initialized
INFO - 2020-09-14 17:30:37 --> Output Class Initialized
INFO - 2020-09-14 17:30:37 --> Security Class Initialized
DEBUG - 2020-09-14 17:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:30:37 --> Input Class Initialized
INFO - 2020-09-14 17:30:37 --> Language Class Initialized
INFO - 2020-09-14 17:30:37 --> Loader Class Initialized
INFO - 2020-09-14 17:30:37 --> Helper loaded: url_helper
INFO - 2020-09-14 17:30:37 --> Database Driver Class Initialized
INFO - 2020-09-14 17:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:30:37 --> Email Class Initialized
INFO - 2020-09-14 17:30:37 --> Controller Class Initialized
DEBUG - 2020-09-14 17:30:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:30:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:30:37 --> Model Class Initialized
INFO - 2020-09-14 17:30:37 --> Model Class Initialized
INFO - 2020-09-14 17:30:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-09-14 17:30:37 --> Final output sent to browser
DEBUG - 2020-09-14 17:30:37 --> Total execution time: 0.0226
ERROR - 2020-09-14 17:30:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:30:52 --> Config Class Initialized
INFO - 2020-09-14 17:30:52 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:30:52 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:30:52 --> Utf8 Class Initialized
INFO - 2020-09-14 17:30:52 --> URI Class Initialized
INFO - 2020-09-14 17:30:52 --> Router Class Initialized
INFO - 2020-09-14 17:30:52 --> Output Class Initialized
INFO - 2020-09-14 17:30:52 --> Security Class Initialized
DEBUG - 2020-09-14 17:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:30:52 --> Input Class Initialized
INFO - 2020-09-14 17:30:53 --> Language Class Initialized
INFO - 2020-09-14 17:30:53 --> Loader Class Initialized
INFO - 2020-09-14 17:30:53 --> Helper loaded: url_helper
INFO - 2020-09-14 17:30:53 --> Database Driver Class Initialized
INFO - 2020-09-14 17:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:30:53 --> Email Class Initialized
INFO - 2020-09-14 17:30:53 --> Controller Class Initialized
DEBUG - 2020-09-14 17:30:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:30:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:30:53 --> Model Class Initialized
INFO - 2020-09-14 17:30:53 --> Model Class Initialized
INFO - 2020-09-14 17:30:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 17:30:53 --> Final output sent to browser
DEBUG - 2020-09-14 17:30:53 --> Total execution time: 0.0247
ERROR - 2020-09-14 17:31:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:31:01 --> Config Class Initialized
INFO - 2020-09-14 17:31:01 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:31:01 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:31:01 --> Utf8 Class Initialized
INFO - 2020-09-14 17:31:01 --> URI Class Initialized
INFO - 2020-09-14 17:31:01 --> Router Class Initialized
INFO - 2020-09-14 17:31:01 --> Output Class Initialized
INFO - 2020-09-14 17:31:01 --> Security Class Initialized
DEBUG - 2020-09-14 17:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:31:01 --> Input Class Initialized
INFO - 2020-09-14 17:31:01 --> Language Class Initialized
INFO - 2020-09-14 17:31:01 --> Loader Class Initialized
INFO - 2020-09-14 17:31:01 --> Helper loaded: url_helper
INFO - 2020-09-14 17:31:01 --> Database Driver Class Initialized
INFO - 2020-09-14 17:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:31:01 --> Email Class Initialized
INFO - 2020-09-14 17:31:01 --> Controller Class Initialized
DEBUG - 2020-09-14 17:31:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:31:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:31:01 --> Model Class Initialized
INFO - 2020-09-14 17:31:01 --> Model Class Initialized
INFO - 2020-09-14 17:31:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 17:31:01 --> Final output sent to browser
DEBUG - 2020-09-14 17:31:01 --> Total execution time: 0.0239
ERROR - 2020-09-14 17:31:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:31:14 --> Config Class Initialized
INFO - 2020-09-14 17:31:14 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:31:14 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:31:14 --> Utf8 Class Initialized
INFO - 2020-09-14 17:31:14 --> URI Class Initialized
INFO - 2020-09-14 17:31:14 --> Router Class Initialized
INFO - 2020-09-14 17:31:14 --> Output Class Initialized
INFO - 2020-09-14 17:31:14 --> Security Class Initialized
DEBUG - 2020-09-14 17:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:31:14 --> Input Class Initialized
INFO - 2020-09-14 17:31:14 --> Language Class Initialized
INFO - 2020-09-14 17:31:14 --> Loader Class Initialized
INFO - 2020-09-14 17:31:14 --> Helper loaded: url_helper
INFO - 2020-09-14 17:31:14 --> Database Driver Class Initialized
INFO - 2020-09-14 17:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:31:14 --> Email Class Initialized
INFO - 2020-09-14 17:31:14 --> Controller Class Initialized
DEBUG - 2020-09-14 17:31:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:31:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:31:14 --> Model Class Initialized
INFO - 2020-09-14 17:31:14 --> Model Class Initialized
INFO - 2020-09-14 17:31:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-14 17:31:14 --> Final output sent to browser
DEBUG - 2020-09-14 17:31:14 --> Total execution time: 0.0228
ERROR - 2020-09-14 17:31:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:31:22 --> Config Class Initialized
INFO - 2020-09-14 17:31:22 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:31:22 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:31:22 --> Utf8 Class Initialized
INFO - 2020-09-14 17:31:22 --> URI Class Initialized
INFO - 2020-09-14 17:31:22 --> Router Class Initialized
INFO - 2020-09-14 17:31:22 --> Output Class Initialized
INFO - 2020-09-14 17:31:22 --> Security Class Initialized
DEBUG - 2020-09-14 17:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:31:22 --> Input Class Initialized
INFO - 2020-09-14 17:31:22 --> Language Class Initialized
ERROR - 2020-09-14 17:31:22 --> 404 Page Not Found: Dealer/dash.html
ERROR - 2020-09-14 17:31:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:31:28 --> Config Class Initialized
INFO - 2020-09-14 17:31:28 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:31:28 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:31:28 --> Utf8 Class Initialized
INFO - 2020-09-14 17:31:28 --> URI Class Initialized
INFO - 2020-09-14 17:31:28 --> Router Class Initialized
INFO - 2020-09-14 17:31:28 --> Output Class Initialized
INFO - 2020-09-14 17:31:28 --> Security Class Initialized
DEBUG - 2020-09-14 17:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:31:28 --> Input Class Initialized
INFO - 2020-09-14 17:31:28 --> Language Class Initialized
INFO - 2020-09-14 17:31:28 --> Loader Class Initialized
INFO - 2020-09-14 17:31:28 --> Helper loaded: url_helper
INFO - 2020-09-14 17:31:28 --> Database Driver Class Initialized
INFO - 2020-09-14 17:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:31:28 --> Email Class Initialized
INFO - 2020-09-14 17:31:28 --> Controller Class Initialized
DEBUG - 2020-09-14 17:31:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:31:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:31:28 --> Model Class Initialized
INFO - 2020-09-14 17:31:28 --> Model Class Initialized
INFO - 2020-09-14 17:31:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-14 17:31:28 --> Final output sent to browser
DEBUG - 2020-09-14 17:31:28 --> Total execution time: 0.0206
ERROR - 2020-09-14 17:31:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:31:31 --> Config Class Initialized
INFO - 2020-09-14 17:31:31 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:31:31 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:31:31 --> Utf8 Class Initialized
INFO - 2020-09-14 17:31:31 --> URI Class Initialized
INFO - 2020-09-14 17:31:31 --> Router Class Initialized
INFO - 2020-09-14 17:31:31 --> Output Class Initialized
INFO - 2020-09-14 17:31:31 --> Security Class Initialized
DEBUG - 2020-09-14 17:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:31:31 --> Input Class Initialized
INFO - 2020-09-14 17:31:31 --> Language Class Initialized
INFO - 2020-09-14 17:31:31 --> Loader Class Initialized
INFO - 2020-09-14 17:31:31 --> Helper loaded: url_helper
INFO - 2020-09-14 17:31:31 --> Database Driver Class Initialized
INFO - 2020-09-14 17:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:31:31 --> Email Class Initialized
INFO - 2020-09-14 17:31:31 --> Controller Class Initialized
DEBUG - 2020-09-14 17:31:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:31:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:31:31 --> Model Class Initialized
INFO - 2020-09-14 17:31:31 --> Model Class Initialized
INFO - 2020-09-14 17:31:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-14 17:31:31 --> Final output sent to browser
DEBUG - 2020-09-14 17:31:31 --> Total execution time: 0.0231
ERROR - 2020-09-14 17:31:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:31:36 --> Config Class Initialized
INFO - 2020-09-14 17:31:36 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:31:36 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:31:36 --> Utf8 Class Initialized
INFO - 2020-09-14 17:31:36 --> URI Class Initialized
INFO - 2020-09-14 17:31:36 --> Router Class Initialized
INFO - 2020-09-14 17:31:36 --> Output Class Initialized
INFO - 2020-09-14 17:31:36 --> Security Class Initialized
DEBUG - 2020-09-14 17:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:31:36 --> Input Class Initialized
INFO - 2020-09-14 17:31:36 --> Language Class Initialized
INFO - 2020-09-14 17:31:36 --> Loader Class Initialized
INFO - 2020-09-14 17:31:36 --> Helper loaded: url_helper
INFO - 2020-09-14 17:31:36 --> Database Driver Class Initialized
INFO - 2020-09-14 17:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:31:36 --> Email Class Initialized
INFO - 2020-09-14 17:31:36 --> Controller Class Initialized
DEBUG - 2020-09-14 17:31:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:31:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:31:36 --> Model Class Initialized
INFO - 2020-09-14 17:31:36 --> Model Class Initialized
INFO - 2020-09-14 17:31:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-09-14 17:31:36 --> Final output sent to browser
DEBUG - 2020-09-14 17:31:36 --> Total execution time: 0.0345
ERROR - 2020-09-14 17:32:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:32:03 --> Config Class Initialized
INFO - 2020-09-14 17:32:03 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:32:03 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:32:03 --> Utf8 Class Initialized
INFO - 2020-09-14 17:32:03 --> URI Class Initialized
INFO - 2020-09-14 17:32:03 --> Router Class Initialized
INFO - 2020-09-14 17:32:03 --> Output Class Initialized
INFO - 2020-09-14 17:32:03 --> Security Class Initialized
DEBUG - 2020-09-14 17:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:32:03 --> Input Class Initialized
INFO - 2020-09-14 17:32:03 --> Language Class Initialized
INFO - 2020-09-14 17:32:03 --> Loader Class Initialized
INFO - 2020-09-14 17:32:03 --> Helper loaded: url_helper
INFO - 2020-09-14 17:32:03 --> Database Driver Class Initialized
INFO - 2020-09-14 17:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:32:03 --> Email Class Initialized
INFO - 2020-09-14 17:32:03 --> Controller Class Initialized
DEBUG - 2020-09-14 17:32:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:32:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:32:03 --> Model Class Initialized
INFO - 2020-09-14 17:32:03 --> Model Class Initialized
INFO - 2020-09-14 17:32:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-09-14 17:32:03 --> Final output sent to browser
DEBUG - 2020-09-14 17:32:03 --> Total execution time: 0.0234
ERROR - 2020-09-14 17:32:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:32:05 --> Config Class Initialized
INFO - 2020-09-14 17:32:05 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:32:05 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:32:05 --> Utf8 Class Initialized
INFO - 2020-09-14 17:32:05 --> URI Class Initialized
INFO - 2020-09-14 17:32:05 --> Router Class Initialized
INFO - 2020-09-14 17:32:05 --> Output Class Initialized
INFO - 2020-09-14 17:32:05 --> Security Class Initialized
DEBUG - 2020-09-14 17:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:32:05 --> Input Class Initialized
INFO - 2020-09-14 17:32:05 --> Language Class Initialized
INFO - 2020-09-14 17:32:05 --> Loader Class Initialized
INFO - 2020-09-14 17:32:05 --> Helper loaded: url_helper
INFO - 2020-09-14 17:32:05 --> Database Driver Class Initialized
INFO - 2020-09-14 17:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:32:05 --> Email Class Initialized
INFO - 2020-09-14 17:32:05 --> Controller Class Initialized
DEBUG - 2020-09-14 17:32:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:32:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:32:05 --> Model Class Initialized
INFO - 2020-09-14 17:32:05 --> Model Class Initialized
INFO - 2020-09-14 17:32:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-14 17:32:05 --> Final output sent to browser
DEBUG - 2020-09-14 17:32:05 --> Total execution time: 0.0243
ERROR - 2020-09-14 17:32:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:32:08 --> Config Class Initialized
INFO - 2020-09-14 17:32:08 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:32:08 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:32:08 --> Utf8 Class Initialized
INFO - 2020-09-14 17:32:08 --> URI Class Initialized
INFO - 2020-09-14 17:32:08 --> Router Class Initialized
INFO - 2020-09-14 17:32:08 --> Output Class Initialized
INFO - 2020-09-14 17:32:08 --> Security Class Initialized
DEBUG - 2020-09-14 17:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:32:08 --> Input Class Initialized
INFO - 2020-09-14 17:32:08 --> Language Class Initialized
INFO - 2020-09-14 17:32:08 --> Loader Class Initialized
INFO - 2020-09-14 17:32:08 --> Helper loaded: url_helper
INFO - 2020-09-14 17:32:08 --> Database Driver Class Initialized
INFO - 2020-09-14 17:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:32:08 --> Email Class Initialized
INFO - 2020-09-14 17:32:08 --> Controller Class Initialized
DEBUG - 2020-09-14 17:32:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:32:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:32:08 --> Model Class Initialized
INFO - 2020-09-14 17:32:08 --> Model Class Initialized
INFO - 2020-09-14 17:32:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-09-14 17:32:08 --> Final output sent to browser
DEBUG - 2020-09-14 17:32:08 --> Total execution time: 0.0280
ERROR - 2020-09-14 17:32:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:32:14 --> Config Class Initialized
INFO - 2020-09-14 17:32:14 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:32:14 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:32:14 --> Utf8 Class Initialized
INFO - 2020-09-14 17:32:14 --> URI Class Initialized
INFO - 2020-09-14 17:32:14 --> Router Class Initialized
INFO - 2020-09-14 17:32:14 --> Output Class Initialized
INFO - 2020-09-14 17:32:14 --> Security Class Initialized
DEBUG - 2020-09-14 17:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:32:14 --> Input Class Initialized
INFO - 2020-09-14 17:32:14 --> Language Class Initialized
INFO - 2020-09-14 17:32:14 --> Loader Class Initialized
INFO - 2020-09-14 17:32:14 --> Helper loaded: url_helper
INFO - 2020-09-14 17:32:14 --> Database Driver Class Initialized
INFO - 2020-09-14 17:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:32:14 --> Email Class Initialized
INFO - 2020-09-14 17:32:14 --> Controller Class Initialized
DEBUG - 2020-09-14 17:32:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:32:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:32:14 --> Model Class Initialized
INFO - 2020-09-14 17:32:14 --> Model Class Initialized
INFO - 2020-09-14 17:32:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-14 17:32:14 --> Final output sent to browser
DEBUG - 2020-09-14 17:32:14 --> Total execution time: 0.0229
ERROR - 2020-09-14 17:32:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:32:17 --> Config Class Initialized
INFO - 2020-09-14 17:32:17 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:32:17 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:32:17 --> Utf8 Class Initialized
INFO - 2020-09-14 17:32:17 --> URI Class Initialized
INFO - 2020-09-14 17:32:17 --> Router Class Initialized
INFO - 2020-09-14 17:32:17 --> Output Class Initialized
INFO - 2020-09-14 17:32:17 --> Security Class Initialized
DEBUG - 2020-09-14 17:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:32:17 --> Input Class Initialized
INFO - 2020-09-14 17:32:17 --> Language Class Initialized
INFO - 2020-09-14 17:32:17 --> Loader Class Initialized
INFO - 2020-09-14 17:32:17 --> Helper loaded: url_helper
INFO - 2020-09-14 17:32:17 --> Database Driver Class Initialized
INFO - 2020-09-14 17:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:32:17 --> Email Class Initialized
INFO - 2020-09-14 17:32:17 --> Controller Class Initialized
DEBUG - 2020-09-14 17:32:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:32:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:32:17 --> Model Class Initialized
INFO - 2020-09-14 17:32:17 --> Model Class Initialized
INFO - 2020-09-14 17:32:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 17:32:17 --> Final output sent to browser
DEBUG - 2020-09-14 17:32:17 --> Total execution time: 0.0239
ERROR - 2020-09-14 17:32:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:32:47 --> Config Class Initialized
INFO - 2020-09-14 17:32:47 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:32:47 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:32:47 --> Utf8 Class Initialized
INFO - 2020-09-14 17:32:47 --> URI Class Initialized
INFO - 2020-09-14 17:32:47 --> Router Class Initialized
INFO - 2020-09-14 17:32:47 --> Output Class Initialized
INFO - 2020-09-14 17:32:47 --> Security Class Initialized
DEBUG - 2020-09-14 17:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:32:47 --> Input Class Initialized
INFO - 2020-09-14 17:32:47 --> Language Class Initialized
INFO - 2020-09-14 17:32:47 --> Loader Class Initialized
INFO - 2020-09-14 17:32:47 --> Helper loaded: url_helper
INFO - 2020-09-14 17:32:47 --> Database Driver Class Initialized
INFO - 2020-09-14 17:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:32:47 --> Email Class Initialized
INFO - 2020-09-14 17:32:47 --> Controller Class Initialized
DEBUG - 2020-09-14 17:32:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:32:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:32:47 --> Model Class Initialized
INFO - 2020-09-14 17:32:47 --> Model Class Initialized
INFO - 2020-09-14 17:32:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 17:32:47 --> Final output sent to browser
DEBUG - 2020-09-14 17:32:47 --> Total execution time: 0.0204
ERROR - 2020-09-14 17:32:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:32:49 --> Config Class Initialized
INFO - 2020-09-14 17:32:49 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:32:49 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:32:49 --> Utf8 Class Initialized
INFO - 2020-09-14 17:32:49 --> URI Class Initialized
INFO - 2020-09-14 17:32:49 --> Router Class Initialized
INFO - 2020-09-14 17:32:49 --> Output Class Initialized
INFO - 2020-09-14 17:32:49 --> Security Class Initialized
DEBUG - 2020-09-14 17:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:32:49 --> Input Class Initialized
INFO - 2020-09-14 17:32:49 --> Language Class Initialized
ERROR - 2020-09-14 17:32:49 --> 404 Page Not Found: Dealer/dash.html
ERROR - 2020-09-14 17:32:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:32:52 --> Config Class Initialized
INFO - 2020-09-14 17:32:52 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:32:52 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:32:52 --> Utf8 Class Initialized
INFO - 2020-09-14 17:32:52 --> URI Class Initialized
INFO - 2020-09-14 17:32:52 --> Router Class Initialized
INFO - 2020-09-14 17:32:52 --> Output Class Initialized
INFO - 2020-09-14 17:32:52 --> Security Class Initialized
DEBUG - 2020-09-14 17:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:32:52 --> Input Class Initialized
INFO - 2020-09-14 17:32:52 --> Language Class Initialized
INFO - 2020-09-14 17:32:52 --> Loader Class Initialized
INFO - 2020-09-14 17:32:52 --> Helper loaded: url_helper
INFO - 2020-09-14 17:32:52 --> Database Driver Class Initialized
INFO - 2020-09-14 17:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:32:52 --> Email Class Initialized
INFO - 2020-09-14 17:32:52 --> Controller Class Initialized
DEBUG - 2020-09-14 17:32:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:32:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:32:52 --> Model Class Initialized
INFO - 2020-09-14 17:32:52 --> Model Class Initialized
INFO - 2020-09-14 17:32:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 17:32:52 --> Final output sent to browser
DEBUG - 2020-09-14 17:32:52 --> Total execution time: 0.0248
ERROR - 2020-09-14 17:32:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:32:53 --> Config Class Initialized
INFO - 2020-09-14 17:32:53 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:32:53 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:32:53 --> Utf8 Class Initialized
INFO - 2020-09-14 17:32:53 --> URI Class Initialized
INFO - 2020-09-14 17:32:53 --> Router Class Initialized
INFO - 2020-09-14 17:32:53 --> Output Class Initialized
INFO - 2020-09-14 17:32:53 --> Security Class Initialized
DEBUG - 2020-09-14 17:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:32:53 --> Input Class Initialized
INFO - 2020-09-14 17:32:53 --> Language Class Initialized
INFO - 2020-09-14 17:32:53 --> Loader Class Initialized
INFO - 2020-09-14 17:32:53 --> Helper loaded: url_helper
INFO - 2020-09-14 17:32:53 --> Database Driver Class Initialized
INFO - 2020-09-14 17:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:32:53 --> Email Class Initialized
INFO - 2020-09-14 17:32:53 --> Controller Class Initialized
DEBUG - 2020-09-14 17:32:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:32:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:32:53 --> Model Class Initialized
INFO - 2020-09-14 17:32:53 --> Model Class Initialized
INFO - 2020-09-14 17:32:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 17:32:53 --> Final output sent to browser
DEBUG - 2020-09-14 17:32:53 --> Total execution time: 0.0215
ERROR - 2020-09-14 17:33:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:33:07 --> Config Class Initialized
INFO - 2020-09-14 17:33:07 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:33:07 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:33:07 --> Utf8 Class Initialized
INFO - 2020-09-14 17:33:07 --> URI Class Initialized
INFO - 2020-09-14 17:33:07 --> Router Class Initialized
INFO - 2020-09-14 17:33:07 --> Output Class Initialized
INFO - 2020-09-14 17:33:07 --> Security Class Initialized
DEBUG - 2020-09-14 17:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:33:07 --> Input Class Initialized
INFO - 2020-09-14 17:33:07 --> Language Class Initialized
INFO - 2020-09-14 17:33:07 --> Loader Class Initialized
INFO - 2020-09-14 17:33:07 --> Helper loaded: url_helper
INFO - 2020-09-14 17:33:07 --> Database Driver Class Initialized
INFO - 2020-09-14 17:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:33:07 --> Email Class Initialized
INFO - 2020-09-14 17:33:07 --> Controller Class Initialized
DEBUG - 2020-09-14 17:33:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:33:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:33:07 --> Model Class Initialized
INFO - 2020-09-14 17:33:07 --> Model Class Initialized
INFO - 2020-09-14 17:33:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-14 17:33:07 --> Final output sent to browser
DEBUG - 2020-09-14 17:33:07 --> Total execution time: 0.0207
ERROR - 2020-09-14 17:33:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:33:13 --> Config Class Initialized
INFO - 2020-09-14 17:33:13 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:33:13 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:33:13 --> Utf8 Class Initialized
INFO - 2020-09-14 17:33:13 --> URI Class Initialized
INFO - 2020-09-14 17:33:13 --> Router Class Initialized
INFO - 2020-09-14 17:33:13 --> Output Class Initialized
INFO - 2020-09-14 17:33:13 --> Security Class Initialized
DEBUG - 2020-09-14 17:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:33:13 --> Input Class Initialized
INFO - 2020-09-14 17:33:13 --> Language Class Initialized
INFO - 2020-09-14 17:33:13 --> Loader Class Initialized
INFO - 2020-09-14 17:33:13 --> Helper loaded: url_helper
INFO - 2020-09-14 17:33:13 --> Database Driver Class Initialized
INFO - 2020-09-14 17:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:33:13 --> Email Class Initialized
INFO - 2020-09-14 17:33:13 --> Controller Class Initialized
DEBUG - 2020-09-14 17:33:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:33:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:33:13 --> Model Class Initialized
INFO - 2020-09-14 17:33:13 --> Model Class Initialized
INFO - 2020-09-14 17:33:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 17:33:13 --> Final output sent to browser
DEBUG - 2020-09-14 17:33:13 --> Total execution time: 0.0221
ERROR - 2020-09-14 17:33:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:33:30 --> Config Class Initialized
INFO - 2020-09-14 17:33:30 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:33:30 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:33:30 --> Utf8 Class Initialized
INFO - 2020-09-14 17:33:30 --> URI Class Initialized
INFO - 2020-09-14 17:33:30 --> Router Class Initialized
INFO - 2020-09-14 17:33:30 --> Output Class Initialized
INFO - 2020-09-14 17:33:30 --> Security Class Initialized
DEBUG - 2020-09-14 17:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:33:30 --> Input Class Initialized
INFO - 2020-09-14 17:33:30 --> Language Class Initialized
INFO - 2020-09-14 17:33:30 --> Loader Class Initialized
INFO - 2020-09-14 17:33:30 --> Helper loaded: url_helper
INFO - 2020-09-14 17:33:30 --> Database Driver Class Initialized
INFO - 2020-09-14 17:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:33:30 --> Email Class Initialized
INFO - 2020-09-14 17:33:30 --> Controller Class Initialized
DEBUG - 2020-09-14 17:33:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:33:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:33:30 --> Model Class Initialized
INFO - 2020-09-14 17:33:30 --> Model Class Initialized
INFO - 2020-09-14 17:33:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 17:33:30 --> Final output sent to browser
DEBUG - 2020-09-14 17:33:30 --> Total execution time: 0.0212
ERROR - 2020-09-14 17:33:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:33:42 --> Config Class Initialized
INFO - 2020-09-14 17:33:42 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:33:42 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:33:42 --> Utf8 Class Initialized
INFO - 2020-09-14 17:33:42 --> URI Class Initialized
INFO - 2020-09-14 17:33:42 --> Router Class Initialized
INFO - 2020-09-14 17:33:42 --> Output Class Initialized
INFO - 2020-09-14 17:33:42 --> Security Class Initialized
DEBUG - 2020-09-14 17:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:33:42 --> Input Class Initialized
INFO - 2020-09-14 17:33:42 --> Language Class Initialized
INFO - 2020-09-14 17:33:42 --> Loader Class Initialized
INFO - 2020-09-14 17:33:42 --> Helper loaded: url_helper
INFO - 2020-09-14 17:33:42 --> Database Driver Class Initialized
INFO - 2020-09-14 17:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:33:42 --> Email Class Initialized
INFO - 2020-09-14 17:33:42 --> Controller Class Initialized
DEBUG - 2020-09-14 17:33:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:33:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:33:42 --> Model Class Initialized
INFO - 2020-09-14 17:33:42 --> Model Class Initialized
INFO - 2020-09-14 17:33:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 17:33:42 --> Final output sent to browser
DEBUG - 2020-09-14 17:33:42 --> Total execution time: 0.0230
ERROR - 2020-09-14 17:35:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:35:05 --> Config Class Initialized
INFO - 2020-09-14 17:35:05 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:35:05 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:35:05 --> Utf8 Class Initialized
INFO - 2020-09-14 17:35:05 --> URI Class Initialized
INFO - 2020-09-14 17:35:05 --> Router Class Initialized
INFO - 2020-09-14 17:35:05 --> Output Class Initialized
INFO - 2020-09-14 17:35:05 --> Security Class Initialized
DEBUG - 2020-09-14 17:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:35:05 --> Input Class Initialized
INFO - 2020-09-14 17:35:05 --> Language Class Initialized
INFO - 2020-09-14 17:35:05 --> Loader Class Initialized
INFO - 2020-09-14 17:35:05 --> Helper loaded: url_helper
INFO - 2020-09-14 17:35:05 --> Database Driver Class Initialized
INFO - 2020-09-14 17:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:35:05 --> Email Class Initialized
INFO - 2020-09-14 17:35:05 --> Controller Class Initialized
DEBUG - 2020-09-14 17:35:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:35:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:35:05 --> Model Class Initialized
INFO - 2020-09-14 17:35:05 --> Model Class Initialized
INFO - 2020-09-14 17:35:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 17:35:05 --> Final output sent to browser
DEBUG - 2020-09-14 17:35:05 --> Total execution time: 0.0204
ERROR - 2020-09-14 17:35:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:35:10 --> Config Class Initialized
INFO - 2020-09-14 17:35:10 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:35:10 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:35:10 --> Utf8 Class Initialized
INFO - 2020-09-14 17:35:10 --> URI Class Initialized
DEBUG - 2020-09-14 17:35:10 --> No URI present. Default controller set.
INFO - 2020-09-14 17:35:10 --> Router Class Initialized
INFO - 2020-09-14 17:35:10 --> Output Class Initialized
INFO - 2020-09-14 17:35:10 --> Security Class Initialized
DEBUG - 2020-09-14 17:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:35:10 --> Input Class Initialized
INFO - 2020-09-14 17:35:10 --> Language Class Initialized
INFO - 2020-09-14 17:35:10 --> Loader Class Initialized
INFO - 2020-09-14 17:35:10 --> Helper loaded: url_helper
INFO - 2020-09-14 17:35:10 --> Database Driver Class Initialized
INFO - 2020-09-14 17:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:35:10 --> Email Class Initialized
INFO - 2020-09-14 17:35:10 --> Controller Class Initialized
INFO - 2020-09-14 17:35:10 --> Model Class Initialized
INFO - 2020-09-14 17:35:10 --> Model Class Initialized
DEBUG - 2020-09-14 17:35:10 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:35:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-14 17:35:10 --> Final output sent to browser
DEBUG - 2020-09-14 17:35:10 --> Total execution time: 0.0182
ERROR - 2020-09-14 17:37:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:37:37 --> Config Class Initialized
INFO - 2020-09-14 17:37:37 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:37:37 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:37:37 --> Utf8 Class Initialized
INFO - 2020-09-14 17:37:37 --> URI Class Initialized
INFO - 2020-09-14 17:37:37 --> Router Class Initialized
INFO - 2020-09-14 17:37:37 --> Output Class Initialized
INFO - 2020-09-14 17:37:37 --> Security Class Initialized
DEBUG - 2020-09-14 17:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:37:37 --> Input Class Initialized
INFO - 2020-09-14 17:37:37 --> Language Class Initialized
INFO - 2020-09-14 17:37:37 --> Loader Class Initialized
INFO - 2020-09-14 17:37:37 --> Helper loaded: url_helper
INFO - 2020-09-14 17:37:37 --> Database Driver Class Initialized
INFO - 2020-09-14 17:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:37:37 --> Email Class Initialized
INFO - 2020-09-14 17:37:37 --> Controller Class Initialized
INFO - 2020-09-14 17:37:37 --> Model Class Initialized
INFO - 2020-09-14 17:37:37 --> Model Class Initialized
DEBUG - 2020-09-14 17:37:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 17:37:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:37:37 --> Config Class Initialized
INFO - 2020-09-14 17:37:37 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:37:37 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:37:37 --> Utf8 Class Initialized
INFO - 2020-09-14 17:37:37 --> URI Class Initialized
INFO - 2020-09-14 17:37:37 --> Router Class Initialized
INFO - 2020-09-14 17:37:37 --> Output Class Initialized
INFO - 2020-09-14 17:37:37 --> Security Class Initialized
DEBUG - 2020-09-14 17:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:37:37 --> Input Class Initialized
INFO - 2020-09-14 17:37:37 --> Language Class Initialized
INFO - 2020-09-14 17:37:37 --> Loader Class Initialized
INFO - 2020-09-14 17:37:37 --> Helper loaded: url_helper
INFO - 2020-09-14 17:37:37 --> Database Driver Class Initialized
INFO - 2020-09-14 17:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:37:37 --> Email Class Initialized
INFO - 2020-09-14 17:37:37 --> Controller Class Initialized
INFO - 2020-09-14 17:37:37 --> Model Class Initialized
INFO - 2020-09-14 17:37:37 --> Model Class Initialized
DEBUG - 2020-09-14 17:37:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:37:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:37:37 --> Model Class Initialized
INFO - 2020-09-14 17:37:37 --> Final output sent to browser
DEBUG - 2020-09-14 17:37:37 --> Total execution time: 0.0236
ERROR - 2020-09-14 17:37:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:37:37 --> Config Class Initialized
INFO - 2020-09-14 17:37:37 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:37:37 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:37:37 --> Utf8 Class Initialized
INFO - 2020-09-14 17:37:37 --> URI Class Initialized
INFO - 2020-09-14 17:37:37 --> Router Class Initialized
INFO - 2020-09-14 17:37:37 --> Output Class Initialized
INFO - 2020-09-14 17:37:37 --> Security Class Initialized
DEBUG - 2020-09-14 17:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:37:37 --> Input Class Initialized
INFO - 2020-09-14 17:37:37 --> Language Class Initialized
INFO - 2020-09-14 17:37:37 --> Loader Class Initialized
INFO - 2020-09-14 17:37:37 --> Helper loaded: url_helper
INFO - 2020-09-14 17:37:37 --> Database Driver Class Initialized
INFO - 2020-09-14 17:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:37:37 --> Email Class Initialized
INFO - 2020-09-14 17:37:37 --> Controller Class Initialized
DEBUG - 2020-09-14 17:37:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:37:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:37:37 --> Model Class Initialized
INFO - 2020-09-14 17:37:37 --> Model Class Initialized
INFO - 2020-09-14 17:37:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 17:37:37 --> Final output sent to browser
DEBUG - 2020-09-14 17:37:37 --> Total execution time: 0.0232
ERROR - 2020-09-14 17:39:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:39:40 --> Config Class Initialized
INFO - 2020-09-14 17:39:40 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:39:40 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:39:40 --> Utf8 Class Initialized
INFO - 2020-09-14 17:39:40 --> URI Class Initialized
DEBUG - 2020-09-14 17:39:40 --> No URI present. Default controller set.
INFO - 2020-09-14 17:39:40 --> Router Class Initialized
INFO - 2020-09-14 17:39:40 --> Output Class Initialized
INFO - 2020-09-14 17:39:40 --> Security Class Initialized
DEBUG - 2020-09-14 17:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:39:40 --> Input Class Initialized
INFO - 2020-09-14 17:39:40 --> Language Class Initialized
INFO - 2020-09-14 17:39:40 --> Loader Class Initialized
INFO - 2020-09-14 17:39:40 --> Helper loaded: url_helper
INFO - 2020-09-14 17:39:40 --> Database Driver Class Initialized
INFO - 2020-09-14 17:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:39:40 --> Email Class Initialized
INFO - 2020-09-14 17:39:40 --> Controller Class Initialized
INFO - 2020-09-14 17:39:40 --> Model Class Initialized
INFO - 2020-09-14 17:39:40 --> Model Class Initialized
DEBUG - 2020-09-14 17:39:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:39:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-14 17:39:40 --> Final output sent to browser
DEBUG - 2020-09-14 17:39:40 --> Total execution time: 0.0207
ERROR - 2020-09-14 17:40:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:40:00 --> Config Class Initialized
INFO - 2020-09-14 17:40:00 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:40:00 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:40:00 --> Utf8 Class Initialized
INFO - 2020-09-14 17:40:00 --> URI Class Initialized
INFO - 2020-09-14 17:40:00 --> Router Class Initialized
INFO - 2020-09-14 17:40:00 --> Output Class Initialized
INFO - 2020-09-14 17:40:00 --> Security Class Initialized
DEBUG - 2020-09-14 17:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:40:00 --> Input Class Initialized
INFO - 2020-09-14 17:40:00 --> Language Class Initialized
INFO - 2020-09-14 17:40:00 --> Loader Class Initialized
INFO - 2020-09-14 17:40:00 --> Helper loaded: url_helper
INFO - 2020-09-14 17:40:00 --> Database Driver Class Initialized
INFO - 2020-09-14 17:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:40:00 --> Email Class Initialized
INFO - 2020-09-14 17:40:00 --> Controller Class Initialized
INFO - 2020-09-14 17:40:00 --> Model Class Initialized
INFO - 2020-09-14 17:40:00 --> Model Class Initialized
DEBUG - 2020-09-14 17:40:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:40:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:40:00 --> Model Class Initialized
INFO - 2020-09-14 17:40:00 --> Final output sent to browser
DEBUG - 2020-09-14 17:40:00 --> Total execution time: 0.0240
ERROR - 2020-09-14 17:40:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:40:00 --> Config Class Initialized
INFO - 2020-09-14 17:40:00 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:40:00 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:40:00 --> Utf8 Class Initialized
INFO - 2020-09-14 17:40:00 --> URI Class Initialized
INFO - 2020-09-14 17:40:00 --> Router Class Initialized
INFO - 2020-09-14 17:40:00 --> Output Class Initialized
INFO - 2020-09-14 17:40:00 --> Security Class Initialized
DEBUG - 2020-09-14 17:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:40:00 --> Input Class Initialized
INFO - 2020-09-14 17:40:00 --> Language Class Initialized
INFO - 2020-09-14 17:40:00 --> Loader Class Initialized
INFO - 2020-09-14 17:40:00 --> Helper loaded: url_helper
INFO - 2020-09-14 17:40:00 --> Database Driver Class Initialized
INFO - 2020-09-14 17:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:40:00 --> Email Class Initialized
INFO - 2020-09-14 17:40:00 --> Controller Class Initialized
INFO - 2020-09-14 17:40:00 --> Model Class Initialized
INFO - 2020-09-14 17:40:00 --> Model Class Initialized
DEBUG - 2020-09-14 17:40:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 17:40:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:40:00 --> Config Class Initialized
INFO - 2020-09-14 17:40:00 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:40:00 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:40:00 --> Utf8 Class Initialized
INFO - 2020-09-14 17:40:00 --> URI Class Initialized
INFO - 2020-09-14 17:40:00 --> Router Class Initialized
INFO - 2020-09-14 17:40:00 --> Output Class Initialized
INFO - 2020-09-14 17:40:00 --> Security Class Initialized
DEBUG - 2020-09-14 17:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:40:00 --> Input Class Initialized
INFO - 2020-09-14 17:40:00 --> Language Class Initialized
INFO - 2020-09-14 17:40:00 --> Loader Class Initialized
INFO - 2020-09-14 17:40:00 --> Helper loaded: url_helper
INFO - 2020-09-14 17:40:00 --> Database Driver Class Initialized
INFO - 2020-09-14 17:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:40:00 --> Email Class Initialized
INFO - 2020-09-14 17:40:00 --> Controller Class Initialized
DEBUG - 2020-09-14 17:40:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:40:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:40:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-14 17:40:00 --> Final output sent to browser
DEBUG - 2020-09-14 17:40:00 --> Total execution time: 0.0210
ERROR - 2020-09-14 17:40:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:40:36 --> Config Class Initialized
INFO - 2020-09-14 17:40:36 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:40:36 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:40:36 --> Utf8 Class Initialized
INFO - 2020-09-14 17:40:36 --> URI Class Initialized
INFO - 2020-09-14 17:40:36 --> Router Class Initialized
INFO - 2020-09-14 17:40:36 --> Output Class Initialized
INFO - 2020-09-14 17:40:36 --> Security Class Initialized
DEBUG - 2020-09-14 17:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:40:36 --> Input Class Initialized
INFO - 2020-09-14 17:40:36 --> Language Class Initialized
INFO - 2020-09-14 17:40:36 --> Loader Class Initialized
INFO - 2020-09-14 17:40:36 --> Helper loaded: url_helper
INFO - 2020-09-14 17:40:36 --> Database Driver Class Initialized
INFO - 2020-09-14 17:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:40:36 --> Email Class Initialized
INFO - 2020-09-14 17:40:36 --> Controller Class Initialized
DEBUG - 2020-09-14 17:40:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:40:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:40:36 --> Model Class Initialized
INFO - 2020-09-14 17:40:36 --> Model Class Initialized
INFO - 2020-09-14 17:40:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-14 17:40:36 --> Final output sent to browser
DEBUG - 2020-09-14 17:40:36 --> Total execution time: 0.0295
ERROR - 2020-09-14 17:40:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:40:38 --> Config Class Initialized
INFO - 2020-09-14 17:40:38 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:40:38 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:40:38 --> Utf8 Class Initialized
INFO - 2020-09-14 17:40:38 --> URI Class Initialized
INFO - 2020-09-14 17:40:38 --> Router Class Initialized
INFO - 2020-09-14 17:40:38 --> Output Class Initialized
INFO - 2020-09-14 17:40:38 --> Security Class Initialized
DEBUG - 2020-09-14 17:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:40:38 --> Input Class Initialized
INFO - 2020-09-14 17:40:38 --> Language Class Initialized
INFO - 2020-09-14 17:40:38 --> Loader Class Initialized
INFO - 2020-09-14 17:40:38 --> Helper loaded: url_helper
INFO - 2020-09-14 17:40:38 --> Database Driver Class Initialized
INFO - 2020-09-14 17:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:40:38 --> Email Class Initialized
INFO - 2020-09-14 17:40:38 --> Controller Class Initialized
DEBUG - 2020-09-14 17:40:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:40:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:40:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-14 17:40:38 --> Final output sent to browser
DEBUG - 2020-09-14 17:40:38 --> Total execution time: 0.0180
ERROR - 2020-09-14 17:40:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:40:43 --> Config Class Initialized
INFO - 2020-09-14 17:40:43 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:40:43 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:40:43 --> Utf8 Class Initialized
INFO - 2020-09-14 17:40:43 --> URI Class Initialized
INFO - 2020-09-14 17:40:43 --> Router Class Initialized
INFO - 2020-09-14 17:40:43 --> Output Class Initialized
INFO - 2020-09-14 17:40:43 --> Security Class Initialized
DEBUG - 2020-09-14 17:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:40:43 --> Input Class Initialized
INFO - 2020-09-14 17:40:43 --> Language Class Initialized
INFO - 2020-09-14 17:40:43 --> Loader Class Initialized
INFO - 2020-09-14 17:40:43 --> Helper loaded: url_helper
INFO - 2020-09-14 17:40:43 --> Database Driver Class Initialized
INFO - 2020-09-14 17:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:40:43 --> Email Class Initialized
INFO - 2020-09-14 17:40:43 --> Controller Class Initialized
DEBUG - 2020-09-14 17:40:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:40:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:40:43 --> Model Class Initialized
INFO - 2020-09-14 17:40:43 --> Model Class Initialized
INFO - 2020-09-14 17:40:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-14 17:40:43 --> Final output sent to browser
DEBUG - 2020-09-14 17:40:43 --> Total execution time: 0.0238
ERROR - 2020-09-14 17:40:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:40:50 --> Config Class Initialized
INFO - 2020-09-14 17:40:50 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:40:50 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:40:50 --> Utf8 Class Initialized
INFO - 2020-09-14 17:40:50 --> URI Class Initialized
INFO - 2020-09-14 17:40:50 --> Router Class Initialized
INFO - 2020-09-14 17:40:50 --> Output Class Initialized
INFO - 2020-09-14 17:40:50 --> Security Class Initialized
DEBUG - 2020-09-14 17:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:40:50 --> Input Class Initialized
INFO - 2020-09-14 17:40:50 --> Language Class Initialized
INFO - 2020-09-14 17:40:50 --> Loader Class Initialized
INFO - 2020-09-14 17:40:50 --> Helper loaded: url_helper
INFO - 2020-09-14 17:40:50 --> Database Driver Class Initialized
INFO - 2020-09-14 17:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:40:50 --> Email Class Initialized
INFO - 2020-09-14 17:40:50 --> Controller Class Initialized
DEBUG - 2020-09-14 17:40:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:40:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:40:50 --> Model Class Initialized
INFO - 2020-09-14 17:40:50 --> Model Class Initialized
INFO - 2020-09-14 17:40:50 --> Model Class Initialized
INFO - 2020-09-14 17:40:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-09-14 17:40:50 --> Final output sent to browser
DEBUG - 2020-09-14 17:40:50 --> Total execution time: 0.0358
ERROR - 2020-09-14 17:40:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:40:52 --> Config Class Initialized
INFO - 2020-09-14 17:40:52 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:40:52 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:40:52 --> Utf8 Class Initialized
INFO - 2020-09-14 17:40:52 --> URI Class Initialized
INFO - 2020-09-14 17:40:52 --> Router Class Initialized
INFO - 2020-09-14 17:40:52 --> Output Class Initialized
INFO - 2020-09-14 17:40:52 --> Security Class Initialized
DEBUG - 2020-09-14 17:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:40:52 --> Input Class Initialized
INFO - 2020-09-14 17:40:52 --> Language Class Initialized
INFO - 2020-09-14 17:40:52 --> Loader Class Initialized
INFO - 2020-09-14 17:40:52 --> Helper loaded: url_helper
INFO - 2020-09-14 17:40:52 --> Database Driver Class Initialized
INFO - 2020-09-14 17:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:40:52 --> Email Class Initialized
INFO - 2020-09-14 17:40:52 --> Controller Class Initialized
DEBUG - 2020-09-14 17:40:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:40:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:40:52 --> Model Class Initialized
INFO - 2020-09-14 17:40:52 --> Model Class Initialized
INFO - 2020-09-14 17:40:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 17:40:52 --> Final output sent to browser
DEBUG - 2020-09-14 17:40:52 --> Total execution time: 0.0220
ERROR - 2020-09-14 17:41:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:41:17 --> Config Class Initialized
INFO - 2020-09-14 17:41:17 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:41:17 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:41:17 --> Utf8 Class Initialized
INFO - 2020-09-14 17:41:17 --> URI Class Initialized
INFO - 2020-09-14 17:41:17 --> Router Class Initialized
INFO - 2020-09-14 17:41:17 --> Output Class Initialized
INFO - 2020-09-14 17:41:17 --> Security Class Initialized
DEBUG - 2020-09-14 17:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:41:17 --> Input Class Initialized
INFO - 2020-09-14 17:41:17 --> Language Class Initialized
INFO - 2020-09-14 17:41:17 --> Loader Class Initialized
INFO - 2020-09-14 17:41:17 --> Helper loaded: url_helper
INFO - 2020-09-14 17:41:17 --> Database Driver Class Initialized
INFO - 2020-09-14 17:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:41:17 --> Email Class Initialized
INFO - 2020-09-14 17:41:17 --> Controller Class Initialized
DEBUG - 2020-09-14 17:41:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:41:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:41:17 --> Model Class Initialized
INFO - 2020-09-14 17:41:17 --> Model Class Initialized
INFO - 2020-09-14 17:41:17 --> Model Class Initialized
INFO - 2020-09-14 17:41:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-09-14 17:41:17 --> Final output sent to browser
DEBUG - 2020-09-14 17:41:17 --> Total execution time: 0.0197
ERROR - 2020-09-14 17:41:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:41:22 --> Config Class Initialized
INFO - 2020-09-14 17:41:22 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:41:22 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:41:22 --> Utf8 Class Initialized
INFO - 2020-09-14 17:41:22 --> URI Class Initialized
INFO - 2020-09-14 17:41:22 --> Router Class Initialized
INFO - 2020-09-14 17:41:22 --> Output Class Initialized
INFO - 2020-09-14 17:41:22 --> Security Class Initialized
DEBUG - 2020-09-14 17:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:41:22 --> Input Class Initialized
INFO - 2020-09-14 17:41:22 --> Language Class Initialized
ERROR - 2020-09-14 17:41:22 --> 404 Page Not Found: Dealer/index.html
ERROR - 2020-09-14 17:41:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:41:25 --> Config Class Initialized
INFO - 2020-09-14 17:41:25 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:41:25 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:41:25 --> Utf8 Class Initialized
INFO - 2020-09-14 17:41:25 --> URI Class Initialized
INFO - 2020-09-14 17:41:25 --> Router Class Initialized
INFO - 2020-09-14 17:41:25 --> Output Class Initialized
INFO - 2020-09-14 17:41:25 --> Security Class Initialized
DEBUG - 2020-09-14 17:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:41:25 --> Input Class Initialized
INFO - 2020-09-14 17:41:25 --> Language Class Initialized
INFO - 2020-09-14 17:41:25 --> Loader Class Initialized
INFO - 2020-09-14 17:41:25 --> Helper loaded: url_helper
INFO - 2020-09-14 17:41:25 --> Database Driver Class Initialized
INFO - 2020-09-14 17:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:41:25 --> Email Class Initialized
INFO - 2020-09-14 17:41:25 --> Controller Class Initialized
DEBUG - 2020-09-14 17:41:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:41:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:41:25 --> Model Class Initialized
INFO - 2020-09-14 17:41:25 --> Model Class Initialized
INFO - 2020-09-14 17:41:25 --> Model Class Initialized
INFO - 2020-09-14 17:41:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-09-14 17:41:25 --> Final output sent to browser
DEBUG - 2020-09-14 17:41:25 --> Total execution time: 0.0193
ERROR - 2020-09-14 17:41:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:41:31 --> Config Class Initialized
INFO - 2020-09-14 17:41:31 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:41:31 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:41:31 --> Utf8 Class Initialized
INFO - 2020-09-14 17:41:31 --> URI Class Initialized
INFO - 2020-09-14 17:41:31 --> Router Class Initialized
INFO - 2020-09-14 17:41:31 --> Output Class Initialized
INFO - 2020-09-14 17:41:31 --> Security Class Initialized
DEBUG - 2020-09-14 17:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:41:31 --> Input Class Initialized
INFO - 2020-09-14 17:41:31 --> Language Class Initialized
INFO - 2020-09-14 17:41:31 --> Loader Class Initialized
INFO - 2020-09-14 17:41:31 --> Helper loaded: url_helper
INFO - 2020-09-14 17:41:31 --> Database Driver Class Initialized
INFO - 2020-09-14 17:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:41:31 --> Email Class Initialized
INFO - 2020-09-14 17:41:31 --> Controller Class Initialized
DEBUG - 2020-09-14 17:41:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:41:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:41:31 --> Model Class Initialized
INFO - 2020-09-14 17:41:31 --> Model Class Initialized
INFO - 2020-09-14 17:41:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-14 17:41:31 --> Final output sent to browser
DEBUG - 2020-09-14 17:41:31 --> Total execution time: 0.0225
ERROR - 2020-09-14 17:41:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:41:33 --> Config Class Initialized
INFO - 2020-09-14 17:41:33 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:41:33 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:41:33 --> Utf8 Class Initialized
INFO - 2020-09-14 17:41:33 --> URI Class Initialized
INFO - 2020-09-14 17:41:33 --> Router Class Initialized
INFO - 2020-09-14 17:41:33 --> Output Class Initialized
INFO - 2020-09-14 17:41:33 --> Security Class Initialized
DEBUG - 2020-09-14 17:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:41:33 --> Input Class Initialized
INFO - 2020-09-14 17:41:33 --> Language Class Initialized
INFO - 2020-09-14 17:41:33 --> Loader Class Initialized
INFO - 2020-09-14 17:41:33 --> Helper loaded: url_helper
INFO - 2020-09-14 17:41:33 --> Database Driver Class Initialized
INFO - 2020-09-14 17:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:41:33 --> Email Class Initialized
INFO - 2020-09-14 17:41:33 --> Controller Class Initialized
DEBUG - 2020-09-14 17:41:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:41:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:41:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-14 17:41:33 --> Final output sent to browser
DEBUG - 2020-09-14 17:41:33 --> Total execution time: 0.0195
ERROR - 2020-09-14 17:41:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:41:55 --> Config Class Initialized
INFO - 2020-09-14 17:41:55 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:41:55 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:41:55 --> Utf8 Class Initialized
INFO - 2020-09-14 17:41:55 --> URI Class Initialized
INFO - 2020-09-14 17:41:55 --> Router Class Initialized
INFO - 2020-09-14 17:41:55 --> Output Class Initialized
INFO - 2020-09-14 17:41:55 --> Security Class Initialized
DEBUG - 2020-09-14 17:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:41:55 --> Input Class Initialized
INFO - 2020-09-14 17:41:55 --> Language Class Initialized
INFO - 2020-09-14 17:41:55 --> Loader Class Initialized
INFO - 2020-09-14 17:41:55 --> Helper loaded: url_helper
INFO - 2020-09-14 17:41:55 --> Database Driver Class Initialized
INFO - 2020-09-14 17:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:41:55 --> Email Class Initialized
INFO - 2020-09-14 17:41:55 --> Controller Class Initialized
DEBUG - 2020-09-14 17:41:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:41:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:41:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-14 17:41:55 --> Final output sent to browser
DEBUG - 2020-09-14 17:41:55 --> Total execution time: 0.0298
ERROR - 2020-09-14 17:42:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:42:15 --> Config Class Initialized
INFO - 2020-09-14 17:42:15 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:42:15 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:42:15 --> Utf8 Class Initialized
INFO - 2020-09-14 17:42:15 --> URI Class Initialized
INFO - 2020-09-14 17:42:15 --> Router Class Initialized
INFO - 2020-09-14 17:42:15 --> Output Class Initialized
INFO - 2020-09-14 17:42:15 --> Security Class Initialized
DEBUG - 2020-09-14 17:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:42:15 --> Input Class Initialized
INFO - 2020-09-14 17:42:15 --> Language Class Initialized
INFO - 2020-09-14 17:42:15 --> Loader Class Initialized
INFO - 2020-09-14 17:42:15 --> Helper loaded: url_helper
INFO - 2020-09-14 17:42:15 --> Database Driver Class Initialized
INFO - 2020-09-14 17:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:42:15 --> Email Class Initialized
INFO - 2020-09-14 17:42:15 --> Controller Class Initialized
DEBUG - 2020-09-14 17:42:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:42:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:42:15 --> Model Class Initialized
INFO - 2020-09-14 17:42:15 --> Model Class Initialized
INFO - 2020-09-14 17:42:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-14 17:42:15 --> Final output sent to browser
DEBUG - 2020-09-14 17:42:15 --> Total execution time: 0.0232
ERROR - 2020-09-14 17:44:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:44:42 --> Config Class Initialized
INFO - 2020-09-14 17:44:42 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:44:42 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:44:42 --> Utf8 Class Initialized
INFO - 2020-09-14 17:44:42 --> URI Class Initialized
INFO - 2020-09-14 17:44:42 --> Router Class Initialized
INFO - 2020-09-14 17:44:42 --> Output Class Initialized
INFO - 2020-09-14 17:44:42 --> Security Class Initialized
DEBUG - 2020-09-14 17:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:44:42 --> Input Class Initialized
INFO - 2020-09-14 17:44:42 --> Language Class Initialized
INFO - 2020-09-14 17:44:42 --> Loader Class Initialized
INFO - 2020-09-14 17:44:42 --> Helper loaded: url_helper
INFO - 2020-09-14 17:44:42 --> Database Driver Class Initialized
INFO - 2020-09-14 17:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:44:42 --> Email Class Initialized
INFO - 2020-09-14 17:44:42 --> Controller Class Initialized
DEBUG - 2020-09-14 17:44:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:44:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:44:42 --> Model Class Initialized
INFO - 2020-09-14 17:44:42 --> Model Class Initialized
INFO - 2020-09-14 17:44:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-14 17:44:42 --> Final output sent to browser
DEBUG - 2020-09-14 17:44:42 --> Total execution time: 0.0216
ERROR - 2020-09-14 17:46:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:46:43 --> Config Class Initialized
INFO - 2020-09-14 17:46:43 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:46:43 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:46:43 --> Utf8 Class Initialized
INFO - 2020-09-14 17:46:43 --> URI Class Initialized
INFO - 2020-09-14 17:46:43 --> Router Class Initialized
INFO - 2020-09-14 17:46:43 --> Output Class Initialized
INFO - 2020-09-14 17:46:43 --> Security Class Initialized
DEBUG - 2020-09-14 17:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:46:43 --> Input Class Initialized
INFO - 2020-09-14 17:46:43 --> Language Class Initialized
INFO - 2020-09-14 17:46:43 --> Loader Class Initialized
INFO - 2020-09-14 17:46:43 --> Helper loaded: url_helper
INFO - 2020-09-14 17:46:43 --> Database Driver Class Initialized
INFO - 2020-09-14 17:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:46:43 --> Email Class Initialized
INFO - 2020-09-14 17:46:43 --> Controller Class Initialized
DEBUG - 2020-09-14 17:46:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:46:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:46:43 --> Model Class Initialized
INFO - 2020-09-14 17:46:43 --> Model Class Initialized
INFO - 2020-09-14 17:46:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-14 17:46:43 --> Final output sent to browser
DEBUG - 2020-09-14 17:46:43 --> Total execution time: 0.0218
ERROR - 2020-09-14 17:47:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:47:23 --> Config Class Initialized
INFO - 2020-09-14 17:47:23 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:47:23 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:47:23 --> Utf8 Class Initialized
INFO - 2020-09-14 17:47:23 --> URI Class Initialized
INFO - 2020-09-14 17:47:23 --> Router Class Initialized
INFO - 2020-09-14 17:47:23 --> Output Class Initialized
INFO - 2020-09-14 17:47:23 --> Security Class Initialized
DEBUG - 2020-09-14 17:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:47:23 --> Input Class Initialized
INFO - 2020-09-14 17:47:23 --> Language Class Initialized
INFO - 2020-09-14 17:47:23 --> Loader Class Initialized
INFO - 2020-09-14 17:47:23 --> Helper loaded: url_helper
INFO - 2020-09-14 17:47:23 --> Database Driver Class Initialized
INFO - 2020-09-14 17:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:47:23 --> Email Class Initialized
INFO - 2020-09-14 17:47:23 --> Controller Class Initialized
DEBUG - 2020-09-14 17:47:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:47:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:47:23 --> Model Class Initialized
INFO - 2020-09-14 17:47:23 --> Model Class Initialized
INFO - 2020-09-14 17:47:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-14 17:47:23 --> Final output sent to browser
DEBUG - 2020-09-14 17:47:23 --> Total execution time: 0.0244
ERROR - 2020-09-14 17:47:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:47:25 --> Config Class Initialized
INFO - 2020-09-14 17:47:25 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:47:25 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:47:25 --> Utf8 Class Initialized
INFO - 2020-09-14 17:47:25 --> URI Class Initialized
INFO - 2020-09-14 17:47:25 --> Router Class Initialized
INFO - 2020-09-14 17:47:25 --> Output Class Initialized
INFO - 2020-09-14 17:47:25 --> Security Class Initialized
DEBUG - 2020-09-14 17:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:47:25 --> Input Class Initialized
INFO - 2020-09-14 17:47:25 --> Language Class Initialized
INFO - 2020-09-14 17:47:25 --> Loader Class Initialized
INFO - 2020-09-14 17:47:25 --> Helper loaded: url_helper
INFO - 2020-09-14 17:47:25 --> Database Driver Class Initialized
INFO - 2020-09-14 17:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:47:25 --> Email Class Initialized
INFO - 2020-09-14 17:47:25 --> Controller Class Initialized
DEBUG - 2020-09-14 17:47:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:47:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:47:25 --> Model Class Initialized
INFO - 2020-09-14 17:47:25 --> Model Class Initialized
INFO - 2020-09-14 17:47:25 --> Model Class Initialized
INFO - 2020-09-14 17:47:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-14 17:47:25 --> Final output sent to browser
DEBUG - 2020-09-14 17:47:25 --> Total execution time: 0.0332
ERROR - 2020-09-14 17:47:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:47:30 --> Config Class Initialized
INFO - 2020-09-14 17:47:30 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:47:30 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:47:30 --> Utf8 Class Initialized
INFO - 2020-09-14 17:47:30 --> URI Class Initialized
INFO - 2020-09-14 17:47:30 --> Router Class Initialized
INFO - 2020-09-14 17:47:30 --> Output Class Initialized
INFO - 2020-09-14 17:47:30 --> Security Class Initialized
DEBUG - 2020-09-14 17:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:47:30 --> Input Class Initialized
INFO - 2020-09-14 17:47:30 --> Language Class Initialized
INFO - 2020-09-14 17:47:30 --> Loader Class Initialized
INFO - 2020-09-14 17:47:30 --> Helper loaded: url_helper
INFO - 2020-09-14 17:47:30 --> Database Driver Class Initialized
INFO - 2020-09-14 17:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:47:30 --> Email Class Initialized
INFO - 2020-09-14 17:47:30 --> Controller Class Initialized
DEBUG - 2020-09-14 17:47:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:47:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:47:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-14 17:47:30 --> Final output sent to browser
DEBUG - 2020-09-14 17:47:30 --> Total execution time: 0.0210
ERROR - 2020-09-14 17:47:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:47:34 --> Config Class Initialized
INFO - 2020-09-14 17:47:34 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:47:34 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:47:34 --> Utf8 Class Initialized
INFO - 2020-09-14 17:47:34 --> URI Class Initialized
INFO - 2020-09-14 17:47:34 --> Router Class Initialized
INFO - 2020-09-14 17:47:34 --> Output Class Initialized
INFO - 2020-09-14 17:47:34 --> Security Class Initialized
DEBUG - 2020-09-14 17:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:47:34 --> Input Class Initialized
INFO - 2020-09-14 17:47:34 --> Language Class Initialized
INFO - 2020-09-14 17:47:34 --> Loader Class Initialized
INFO - 2020-09-14 17:47:34 --> Helper loaded: url_helper
INFO - 2020-09-14 17:47:34 --> Database Driver Class Initialized
INFO - 2020-09-14 17:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:47:34 --> Email Class Initialized
INFO - 2020-09-14 17:47:34 --> Controller Class Initialized
DEBUG - 2020-09-14 17:47:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:47:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:47:34 --> Model Class Initialized
INFO - 2020-09-14 17:47:34 --> Model Class Initialized
INFO - 2020-09-14 17:47:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-14 17:47:34 --> Final output sent to browser
DEBUG - 2020-09-14 17:47:34 --> Total execution time: 0.0233
ERROR - 2020-09-14 17:47:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:47:38 --> Config Class Initialized
INFO - 2020-09-14 17:47:38 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:47:38 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:47:38 --> Utf8 Class Initialized
INFO - 2020-09-14 17:47:38 --> URI Class Initialized
INFO - 2020-09-14 17:47:38 --> Router Class Initialized
INFO - 2020-09-14 17:47:38 --> Output Class Initialized
INFO - 2020-09-14 17:47:38 --> Security Class Initialized
DEBUG - 2020-09-14 17:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:47:38 --> Input Class Initialized
INFO - 2020-09-14 17:47:38 --> Language Class Initialized
INFO - 2020-09-14 17:47:38 --> Loader Class Initialized
INFO - 2020-09-14 17:47:38 --> Helper loaded: url_helper
INFO - 2020-09-14 17:47:38 --> Database Driver Class Initialized
INFO - 2020-09-14 17:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:47:38 --> Email Class Initialized
INFO - 2020-09-14 17:47:38 --> Controller Class Initialized
DEBUG - 2020-09-14 17:47:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:47:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:47:38 --> Model Class Initialized
INFO - 2020-09-14 17:47:38 --> Model Class Initialized
INFO - 2020-09-14 17:47:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_view.php
INFO - 2020-09-14 17:47:38 --> Final output sent to browser
DEBUG - 2020-09-14 17:47:38 --> Total execution time: 0.0239
ERROR - 2020-09-14 17:47:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:47:58 --> Config Class Initialized
INFO - 2020-09-14 17:47:58 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:47:58 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:47:58 --> Utf8 Class Initialized
INFO - 2020-09-14 17:47:58 --> URI Class Initialized
INFO - 2020-09-14 17:47:58 --> Router Class Initialized
INFO - 2020-09-14 17:47:58 --> Output Class Initialized
INFO - 2020-09-14 17:47:58 --> Security Class Initialized
DEBUG - 2020-09-14 17:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:47:58 --> Input Class Initialized
INFO - 2020-09-14 17:47:58 --> Language Class Initialized
INFO - 2020-09-14 17:47:58 --> Loader Class Initialized
INFO - 2020-09-14 17:47:58 --> Helper loaded: url_helper
INFO - 2020-09-14 17:47:58 --> Database Driver Class Initialized
INFO - 2020-09-14 17:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:47:58 --> Email Class Initialized
INFO - 2020-09-14 17:47:58 --> Controller Class Initialized
DEBUG - 2020-09-14 17:47:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:47:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:47:58 --> Model Class Initialized
INFO - 2020-09-14 17:47:58 --> Model Class Initialized
INFO - 2020-09-14 17:47:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_view.php
INFO - 2020-09-14 17:47:58 --> Final output sent to browser
DEBUG - 2020-09-14 17:47:58 --> Total execution time: 0.0229
ERROR - 2020-09-14 17:48:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:48:01 --> Config Class Initialized
INFO - 2020-09-14 17:48:01 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:48:01 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:48:01 --> Utf8 Class Initialized
INFO - 2020-09-14 17:48:01 --> URI Class Initialized
INFO - 2020-09-14 17:48:01 --> Router Class Initialized
INFO - 2020-09-14 17:48:01 --> Output Class Initialized
INFO - 2020-09-14 17:48:01 --> Security Class Initialized
DEBUG - 2020-09-14 17:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:48:01 --> Input Class Initialized
INFO - 2020-09-14 17:48:01 --> Language Class Initialized
INFO - 2020-09-14 17:48:01 --> Loader Class Initialized
INFO - 2020-09-14 17:48:01 --> Helper loaded: url_helper
INFO - 2020-09-14 17:48:01 --> Database Driver Class Initialized
INFO - 2020-09-14 17:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:48:01 --> Email Class Initialized
INFO - 2020-09-14 17:48:01 --> Controller Class Initialized
DEBUG - 2020-09-14 17:48:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:48:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:48:01 --> Model Class Initialized
INFO - 2020-09-14 17:48:01 --> Model Class Initialized
INFO - 2020-09-14 17:48:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-14 17:48:01 --> Final output sent to browser
DEBUG - 2020-09-14 17:48:01 --> Total execution time: 0.0246
ERROR - 2020-09-14 17:48:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:48:07 --> Config Class Initialized
INFO - 2020-09-14 17:48:07 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:48:07 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:48:07 --> Utf8 Class Initialized
INFO - 2020-09-14 17:48:07 --> URI Class Initialized
INFO - 2020-09-14 17:48:07 --> Router Class Initialized
INFO - 2020-09-14 17:48:07 --> Output Class Initialized
INFO - 2020-09-14 17:48:07 --> Security Class Initialized
DEBUG - 2020-09-14 17:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:48:07 --> Input Class Initialized
INFO - 2020-09-14 17:48:07 --> Language Class Initialized
INFO - 2020-09-14 17:48:07 --> Loader Class Initialized
INFO - 2020-09-14 17:48:07 --> Helper loaded: url_helper
INFO - 2020-09-14 17:48:07 --> Database Driver Class Initialized
INFO - 2020-09-14 17:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:48:07 --> Email Class Initialized
INFO - 2020-09-14 17:48:07 --> Controller Class Initialized
DEBUG - 2020-09-14 17:48:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:48:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:48:07 --> Model Class Initialized
INFO - 2020-09-14 17:48:07 --> Model Class Initialized
INFO - 2020-09-14 17:48:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-14 17:48:07 --> Final output sent to browser
DEBUG - 2020-09-14 17:48:07 --> Total execution time: 0.0214
ERROR - 2020-09-14 17:48:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:48:12 --> Config Class Initialized
INFO - 2020-09-14 17:48:12 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:48:12 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:48:12 --> Utf8 Class Initialized
INFO - 2020-09-14 17:48:12 --> URI Class Initialized
INFO - 2020-09-14 17:48:12 --> Router Class Initialized
INFO - 2020-09-14 17:48:12 --> Output Class Initialized
INFO - 2020-09-14 17:48:12 --> Security Class Initialized
DEBUG - 2020-09-14 17:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:48:12 --> Input Class Initialized
INFO - 2020-09-14 17:48:12 --> Language Class Initialized
INFO - 2020-09-14 17:48:12 --> Loader Class Initialized
INFO - 2020-09-14 17:48:12 --> Helper loaded: url_helper
INFO - 2020-09-14 17:48:12 --> Database Driver Class Initialized
INFO - 2020-09-14 17:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:48:12 --> Email Class Initialized
INFO - 2020-09-14 17:48:12 --> Controller Class Initialized
DEBUG - 2020-09-14 17:48:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:48:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:48:12 --> Model Class Initialized
INFO - 2020-09-14 17:48:12 --> Model Class Initialized
INFO - 2020-09-14 17:48:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_view.php
INFO - 2020-09-14 17:48:12 --> Final output sent to browser
DEBUG - 2020-09-14 17:48:12 --> Total execution time: 0.0223
ERROR - 2020-09-14 17:48:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:48:15 --> Config Class Initialized
INFO - 2020-09-14 17:48:15 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:48:15 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:48:15 --> Utf8 Class Initialized
INFO - 2020-09-14 17:48:15 --> URI Class Initialized
INFO - 2020-09-14 17:48:15 --> Router Class Initialized
INFO - 2020-09-14 17:48:15 --> Output Class Initialized
INFO - 2020-09-14 17:48:15 --> Security Class Initialized
DEBUG - 2020-09-14 17:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:48:15 --> Input Class Initialized
INFO - 2020-09-14 17:48:15 --> Language Class Initialized
INFO - 2020-09-14 17:48:15 --> Loader Class Initialized
INFO - 2020-09-14 17:48:16 --> Helper loaded: url_helper
INFO - 2020-09-14 17:48:16 --> Database Driver Class Initialized
INFO - 2020-09-14 17:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:48:16 --> Email Class Initialized
INFO - 2020-09-14 17:48:16 --> Controller Class Initialized
DEBUG - 2020-09-14 17:48:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:48:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:48:16 --> Model Class Initialized
INFO - 2020-09-14 17:48:16 --> Model Class Initialized
INFO - 2020-09-14 17:48:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-14 17:48:16 --> Final output sent to browser
DEBUG - 2020-09-14 17:48:16 --> Total execution time: 0.0217
ERROR - 2020-09-14 17:48:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:48:20 --> Config Class Initialized
INFO - 2020-09-14 17:48:20 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:48:20 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:48:20 --> Utf8 Class Initialized
INFO - 2020-09-14 17:48:20 --> URI Class Initialized
INFO - 2020-09-14 17:48:20 --> Router Class Initialized
INFO - 2020-09-14 17:48:20 --> Output Class Initialized
INFO - 2020-09-14 17:48:20 --> Security Class Initialized
DEBUG - 2020-09-14 17:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:48:20 --> Input Class Initialized
INFO - 2020-09-14 17:48:20 --> Language Class Initialized
INFO - 2020-09-14 17:48:20 --> Loader Class Initialized
INFO - 2020-09-14 17:48:20 --> Helper loaded: url_helper
INFO - 2020-09-14 17:48:20 --> Database Driver Class Initialized
INFO - 2020-09-14 17:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:48:20 --> Email Class Initialized
INFO - 2020-09-14 17:48:20 --> Controller Class Initialized
DEBUG - 2020-09-14 17:48:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:48:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:48:20 --> Model Class Initialized
INFO - 2020-09-14 17:48:20 --> Model Class Initialized
INFO - 2020-09-14 17:48:20 --> Model Class Initialized
INFO - 2020-09-14 17:48:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-09-14 17:48:20 --> Final output sent to browser
DEBUG - 2020-09-14 17:48:20 --> Total execution time: 0.0222
ERROR - 2020-09-14 17:48:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:48:28 --> Config Class Initialized
INFO - 2020-09-14 17:48:28 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:48:28 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:48:28 --> Utf8 Class Initialized
INFO - 2020-09-14 17:48:28 --> URI Class Initialized
INFO - 2020-09-14 17:48:28 --> Router Class Initialized
INFO - 2020-09-14 17:48:28 --> Output Class Initialized
INFO - 2020-09-14 17:48:28 --> Security Class Initialized
DEBUG - 2020-09-14 17:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:48:28 --> Input Class Initialized
INFO - 2020-09-14 17:48:28 --> Language Class Initialized
INFO - 2020-09-14 17:48:28 --> Loader Class Initialized
INFO - 2020-09-14 17:48:28 --> Helper loaded: url_helper
INFO - 2020-09-14 17:48:28 --> Database Driver Class Initialized
INFO - 2020-09-14 17:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:48:28 --> Email Class Initialized
INFO - 2020-09-14 17:48:28 --> Controller Class Initialized
DEBUG - 2020-09-14 17:48:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:48:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:48:28 --> Model Class Initialized
INFO - 2020-09-14 17:48:28 --> Model Class Initialized
INFO - 2020-09-14 17:48:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-14 17:48:28 --> Final output sent to browser
DEBUG - 2020-09-14 17:48:28 --> Total execution time: 0.0249
ERROR - 2020-09-14 17:48:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:48:39 --> Config Class Initialized
INFO - 2020-09-14 17:48:39 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:48:39 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:48:39 --> Utf8 Class Initialized
INFO - 2020-09-14 17:48:39 --> URI Class Initialized
INFO - 2020-09-14 17:48:39 --> Router Class Initialized
INFO - 2020-09-14 17:48:39 --> Output Class Initialized
INFO - 2020-09-14 17:48:39 --> Security Class Initialized
DEBUG - 2020-09-14 17:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:48:39 --> Input Class Initialized
INFO - 2020-09-14 17:48:39 --> Language Class Initialized
INFO - 2020-09-14 17:48:39 --> Loader Class Initialized
INFO - 2020-09-14 17:48:39 --> Helper loaded: url_helper
INFO - 2020-09-14 17:48:39 --> Database Driver Class Initialized
INFO - 2020-09-14 17:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:48:39 --> Email Class Initialized
INFO - 2020-09-14 17:48:39 --> Controller Class Initialized
DEBUG - 2020-09-14 17:48:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:48:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:48:39 --> Model Class Initialized
INFO - 2020-09-14 17:48:39 --> Model Class Initialized
INFO - 2020-09-14 17:48:39 --> Model Class Initialized
INFO - 2020-09-14 17:48:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-14 17:48:39 --> Final output sent to browser
DEBUG - 2020-09-14 17:48:39 --> Total execution time: 0.0231
ERROR - 2020-09-14 17:48:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:48:43 --> Config Class Initialized
INFO - 2020-09-14 17:48:43 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:48:43 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:48:43 --> Utf8 Class Initialized
INFO - 2020-09-14 17:48:43 --> URI Class Initialized
INFO - 2020-09-14 17:48:43 --> Router Class Initialized
INFO - 2020-09-14 17:48:43 --> Output Class Initialized
INFO - 2020-09-14 17:48:43 --> Security Class Initialized
DEBUG - 2020-09-14 17:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:48:43 --> Input Class Initialized
INFO - 2020-09-14 17:48:43 --> Language Class Initialized
INFO - 2020-09-14 17:48:43 --> Loader Class Initialized
INFO - 2020-09-14 17:48:43 --> Helper loaded: url_helper
INFO - 2020-09-14 17:48:43 --> Database Driver Class Initialized
INFO - 2020-09-14 17:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:48:43 --> Email Class Initialized
INFO - 2020-09-14 17:48:43 --> Controller Class Initialized
DEBUG - 2020-09-14 17:48:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:48:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:48:43 --> Model Class Initialized
INFO - 2020-09-14 17:48:43 --> Model Class Initialized
INFO - 2020-09-14 17:48:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-14 17:48:43 --> Final output sent to browser
DEBUG - 2020-09-14 17:48:43 --> Total execution time: 0.0232
ERROR - 2020-09-14 17:48:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:48:45 --> Config Class Initialized
INFO - 2020-09-14 17:48:45 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:48:45 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:48:45 --> Utf8 Class Initialized
INFO - 2020-09-14 17:48:45 --> URI Class Initialized
INFO - 2020-09-14 17:48:45 --> Router Class Initialized
INFO - 2020-09-14 17:48:45 --> Output Class Initialized
INFO - 2020-09-14 17:48:45 --> Security Class Initialized
DEBUG - 2020-09-14 17:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:48:45 --> Input Class Initialized
INFO - 2020-09-14 17:48:45 --> Language Class Initialized
INFO - 2020-09-14 17:48:45 --> Loader Class Initialized
INFO - 2020-09-14 17:48:45 --> Helper loaded: url_helper
INFO - 2020-09-14 17:48:45 --> Database Driver Class Initialized
INFO - 2020-09-14 17:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:48:45 --> Email Class Initialized
INFO - 2020-09-14 17:48:45 --> Controller Class Initialized
DEBUG - 2020-09-14 17:48:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:48:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:48:45 --> Model Class Initialized
INFO - 2020-09-14 17:48:45 --> Model Class Initialized
INFO - 2020-09-14 17:48:45 --> Model Class Initialized
INFO - 2020-09-14 17:48:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-09-14 17:48:45 --> Final output sent to browser
DEBUG - 2020-09-14 17:48:45 --> Total execution time: 0.0202
ERROR - 2020-09-14 17:49:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:49:19 --> Config Class Initialized
INFO - 2020-09-14 17:49:19 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:49:19 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:49:19 --> Utf8 Class Initialized
INFO - 2020-09-14 17:49:19 --> URI Class Initialized
INFO - 2020-09-14 17:49:19 --> Router Class Initialized
INFO - 2020-09-14 17:49:19 --> Output Class Initialized
INFO - 2020-09-14 17:49:19 --> Security Class Initialized
DEBUG - 2020-09-14 17:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:49:19 --> Input Class Initialized
INFO - 2020-09-14 17:49:19 --> Language Class Initialized
INFO - 2020-09-14 17:49:19 --> Loader Class Initialized
INFO - 2020-09-14 17:49:19 --> Helper loaded: url_helper
INFO - 2020-09-14 17:49:19 --> Database Driver Class Initialized
INFO - 2020-09-14 17:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:49:19 --> Email Class Initialized
INFO - 2020-09-14 17:49:19 --> Controller Class Initialized
DEBUG - 2020-09-14 17:49:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:49:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:49:19 --> Model Class Initialized
INFO - 2020-09-14 17:49:19 --> Model Class Initialized
INFO - 2020-09-14 17:49:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-14 17:49:19 --> Final output sent to browser
DEBUG - 2020-09-14 17:49:19 --> Total execution time: 0.0220
ERROR - 2020-09-14 17:50:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:50:54 --> Config Class Initialized
INFO - 2020-09-14 17:50:54 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:50:54 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:50:54 --> Utf8 Class Initialized
INFO - 2020-09-14 17:50:54 --> URI Class Initialized
INFO - 2020-09-14 17:50:54 --> Router Class Initialized
INFO - 2020-09-14 17:50:54 --> Output Class Initialized
INFO - 2020-09-14 17:50:54 --> Security Class Initialized
DEBUG - 2020-09-14 17:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:50:54 --> Input Class Initialized
INFO - 2020-09-14 17:50:54 --> Language Class Initialized
INFO - 2020-09-14 17:50:54 --> Loader Class Initialized
INFO - 2020-09-14 17:50:54 --> Helper loaded: url_helper
INFO - 2020-09-14 17:50:54 --> Database Driver Class Initialized
INFO - 2020-09-14 17:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:50:54 --> Email Class Initialized
INFO - 2020-09-14 17:50:54 --> Controller Class Initialized
DEBUG - 2020-09-14 17:50:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:50:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:50:54 --> Model Class Initialized
INFO - 2020-09-14 17:50:54 --> Model Class Initialized
INFO - 2020-09-14 17:50:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-09-14 17:50:54 --> Final output sent to browser
DEBUG - 2020-09-14 17:50:54 --> Total execution time: 0.0194
ERROR - 2020-09-14 17:51:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:51:00 --> Config Class Initialized
INFO - 2020-09-14 17:51:00 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:51:00 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:51:00 --> Utf8 Class Initialized
INFO - 2020-09-14 17:51:00 --> URI Class Initialized
INFO - 2020-09-14 17:51:00 --> Router Class Initialized
INFO - 2020-09-14 17:51:00 --> Output Class Initialized
INFO - 2020-09-14 17:51:00 --> Security Class Initialized
DEBUG - 2020-09-14 17:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:51:00 --> Input Class Initialized
INFO - 2020-09-14 17:51:00 --> Language Class Initialized
INFO - 2020-09-14 17:51:00 --> Loader Class Initialized
INFO - 2020-09-14 17:51:00 --> Helper loaded: url_helper
INFO - 2020-09-14 17:51:00 --> Database Driver Class Initialized
INFO - 2020-09-14 17:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:51:00 --> Email Class Initialized
INFO - 2020-09-14 17:51:00 --> Controller Class Initialized
DEBUG - 2020-09-14 17:51:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:51:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:51:00 --> Model Class Initialized
INFO - 2020-09-14 17:51:00 --> Model Class Initialized
INFO - 2020-09-14 17:51:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-14 17:51:00 --> Final output sent to browser
DEBUG - 2020-09-14 17:51:00 --> Total execution time: 0.0219
ERROR - 2020-09-14 17:51:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:51:33 --> Config Class Initialized
INFO - 2020-09-14 17:51:33 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:51:33 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:51:33 --> Utf8 Class Initialized
INFO - 2020-09-14 17:51:33 --> URI Class Initialized
INFO - 2020-09-14 17:51:33 --> Router Class Initialized
INFO - 2020-09-14 17:51:33 --> Output Class Initialized
INFO - 2020-09-14 17:51:33 --> Security Class Initialized
DEBUG - 2020-09-14 17:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:51:33 --> Input Class Initialized
INFO - 2020-09-14 17:51:33 --> Language Class Initialized
INFO - 2020-09-14 17:51:33 --> Loader Class Initialized
INFO - 2020-09-14 17:51:33 --> Helper loaded: url_helper
INFO - 2020-09-14 17:51:33 --> Database Driver Class Initialized
INFO - 2020-09-14 17:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:51:34 --> Email Class Initialized
INFO - 2020-09-14 17:51:34 --> Controller Class Initialized
DEBUG - 2020-09-14 17:51:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:51:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:51:34 --> Model Class Initialized
INFO - 2020-09-14 17:51:34 --> Model Class Initialized
INFO - 2020-09-14 17:51:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-09-14 17:51:34 --> Final output sent to browser
DEBUG - 2020-09-14 17:51:34 --> Total execution time: 0.1944
ERROR - 2020-09-14 17:51:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:51:44 --> Config Class Initialized
INFO - 2020-09-14 17:51:44 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:51:44 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:51:44 --> Utf8 Class Initialized
INFO - 2020-09-14 17:51:44 --> URI Class Initialized
INFO - 2020-09-14 17:51:44 --> Router Class Initialized
INFO - 2020-09-14 17:51:44 --> Output Class Initialized
INFO - 2020-09-14 17:51:44 --> Security Class Initialized
DEBUG - 2020-09-14 17:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:51:44 --> Input Class Initialized
INFO - 2020-09-14 17:51:44 --> Language Class Initialized
INFO - 2020-09-14 17:51:44 --> Loader Class Initialized
INFO - 2020-09-14 17:51:44 --> Helper loaded: url_helper
INFO - 2020-09-14 17:51:44 --> Database Driver Class Initialized
INFO - 2020-09-14 17:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:51:44 --> Email Class Initialized
INFO - 2020-09-14 17:51:44 --> Controller Class Initialized
DEBUG - 2020-09-14 17:51:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:51:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:51:44 --> Model Class Initialized
INFO - 2020-09-14 17:51:44 --> Model Class Initialized
INFO - 2020-09-14 17:51:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-14 17:51:44 --> Final output sent to browser
DEBUG - 2020-09-14 17:51:44 --> Total execution time: 0.0227
ERROR - 2020-09-14 17:51:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:51:53 --> Config Class Initialized
INFO - 2020-09-14 17:51:53 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:51:53 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:51:53 --> Utf8 Class Initialized
INFO - 2020-09-14 17:51:53 --> URI Class Initialized
INFO - 2020-09-14 17:51:53 --> Router Class Initialized
INFO - 2020-09-14 17:51:53 --> Output Class Initialized
INFO - 2020-09-14 17:51:53 --> Security Class Initialized
DEBUG - 2020-09-14 17:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:51:53 --> Input Class Initialized
INFO - 2020-09-14 17:51:53 --> Language Class Initialized
INFO - 2020-09-14 17:51:53 --> Loader Class Initialized
INFO - 2020-09-14 17:51:53 --> Helper loaded: url_helper
INFO - 2020-09-14 17:51:53 --> Database Driver Class Initialized
INFO - 2020-09-14 17:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:51:53 --> Email Class Initialized
INFO - 2020-09-14 17:51:53 --> Controller Class Initialized
DEBUG - 2020-09-14 17:51:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:51:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:51:53 --> Model Class Initialized
INFO - 2020-09-14 17:51:53 --> Model Class Initialized
INFO - 2020-09-14 17:51:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-09-14 17:51:53 --> Final output sent to browser
DEBUG - 2020-09-14 17:51:53 --> Total execution time: 0.0325
ERROR - 2020-09-14 17:52:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:52:14 --> Config Class Initialized
INFO - 2020-09-14 17:52:14 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:52:14 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:52:14 --> Utf8 Class Initialized
INFO - 2020-09-14 17:52:14 --> URI Class Initialized
INFO - 2020-09-14 17:52:14 --> Router Class Initialized
INFO - 2020-09-14 17:52:14 --> Output Class Initialized
INFO - 2020-09-14 17:52:14 --> Security Class Initialized
DEBUG - 2020-09-14 17:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:52:14 --> Input Class Initialized
INFO - 2020-09-14 17:52:14 --> Language Class Initialized
INFO - 2020-09-14 17:52:14 --> Loader Class Initialized
INFO - 2020-09-14 17:52:14 --> Helper loaded: url_helper
INFO - 2020-09-14 17:52:14 --> Database Driver Class Initialized
INFO - 2020-09-14 17:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:52:14 --> Email Class Initialized
INFO - 2020-09-14 17:52:14 --> Controller Class Initialized
DEBUG - 2020-09-14 17:52:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:52:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:52:14 --> Model Class Initialized
INFO - 2020-09-14 17:52:14 --> Model Class Initialized
INFO - 2020-09-14 17:52:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-09-14 17:52:14 --> Final output sent to browser
DEBUG - 2020-09-14 17:52:14 --> Total execution time: 0.0225
ERROR - 2020-09-14 17:52:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:52:24 --> Config Class Initialized
INFO - 2020-09-14 17:52:24 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:52:24 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:52:24 --> Utf8 Class Initialized
INFO - 2020-09-14 17:52:24 --> URI Class Initialized
INFO - 2020-09-14 17:52:24 --> Router Class Initialized
INFO - 2020-09-14 17:52:24 --> Output Class Initialized
INFO - 2020-09-14 17:52:24 --> Security Class Initialized
DEBUG - 2020-09-14 17:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:52:24 --> Input Class Initialized
INFO - 2020-09-14 17:52:24 --> Language Class Initialized
INFO - 2020-09-14 17:52:24 --> Loader Class Initialized
INFO - 2020-09-14 17:52:24 --> Helper loaded: url_helper
INFO - 2020-09-14 17:52:24 --> Database Driver Class Initialized
INFO - 2020-09-14 17:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:52:24 --> Email Class Initialized
INFO - 2020-09-14 17:52:24 --> Controller Class Initialized
DEBUG - 2020-09-14 17:52:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:52:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:52:24 --> Model Class Initialized
INFO - 2020-09-14 17:52:24 --> Model Class Initialized
INFO - 2020-09-14 17:52:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-14 17:52:24 --> Final output sent to browser
DEBUG - 2020-09-14 17:52:24 --> Total execution time: 0.0260
ERROR - 2020-09-14 17:52:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:52:37 --> Config Class Initialized
INFO - 2020-09-14 17:52:37 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:52:37 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:52:37 --> Utf8 Class Initialized
INFO - 2020-09-14 17:52:37 --> URI Class Initialized
INFO - 2020-09-14 17:52:37 --> Router Class Initialized
INFO - 2020-09-14 17:52:37 --> Output Class Initialized
INFO - 2020-09-14 17:52:37 --> Security Class Initialized
DEBUG - 2020-09-14 17:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:52:37 --> Input Class Initialized
INFO - 2020-09-14 17:52:37 --> Language Class Initialized
INFO - 2020-09-14 17:52:37 --> Loader Class Initialized
INFO - 2020-09-14 17:52:37 --> Helper loaded: url_helper
INFO - 2020-09-14 17:52:37 --> Database Driver Class Initialized
INFO - 2020-09-14 17:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:52:37 --> Email Class Initialized
INFO - 2020-09-14 17:52:37 --> Controller Class Initialized
DEBUG - 2020-09-14 17:52:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:52:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:52:37 --> Model Class Initialized
INFO - 2020-09-14 17:52:37 --> Model Class Initialized
INFO - 2020-09-14 17:52:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-14 17:52:37 --> Final output sent to browser
DEBUG - 2020-09-14 17:52:37 --> Total execution time: 0.0230
ERROR - 2020-09-14 17:52:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:52:43 --> Config Class Initialized
INFO - 2020-09-14 17:52:43 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:52:43 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:52:43 --> Utf8 Class Initialized
INFO - 2020-09-14 17:52:43 --> URI Class Initialized
INFO - 2020-09-14 17:52:43 --> Router Class Initialized
INFO - 2020-09-14 17:52:43 --> Output Class Initialized
INFO - 2020-09-14 17:52:43 --> Security Class Initialized
DEBUG - 2020-09-14 17:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:52:43 --> Input Class Initialized
INFO - 2020-09-14 17:52:43 --> Language Class Initialized
INFO - 2020-09-14 17:52:43 --> Loader Class Initialized
INFO - 2020-09-14 17:52:43 --> Helper loaded: url_helper
INFO - 2020-09-14 17:52:43 --> Database Driver Class Initialized
INFO - 2020-09-14 17:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:52:43 --> Email Class Initialized
INFO - 2020-09-14 17:52:43 --> Controller Class Initialized
DEBUG - 2020-09-14 17:52:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:52:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:52:43 --> Model Class Initialized
INFO - 2020-09-14 17:52:43 --> Model Class Initialized
INFO - 2020-09-14 17:52:43 --> Model Class Initialized
INFO - 2020-09-14 17:52:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-09-14 17:52:43 --> Final output sent to browser
DEBUG - 2020-09-14 17:52:43 --> Total execution time: 0.0237
ERROR - 2020-09-14 17:54:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:54:29 --> Config Class Initialized
INFO - 2020-09-14 17:54:29 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:54:29 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:54:29 --> Utf8 Class Initialized
INFO - 2020-09-14 17:54:29 --> URI Class Initialized
INFO - 2020-09-14 17:54:29 --> Router Class Initialized
INFO - 2020-09-14 17:54:29 --> Output Class Initialized
INFO - 2020-09-14 17:54:29 --> Security Class Initialized
DEBUG - 2020-09-14 17:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:54:29 --> Input Class Initialized
INFO - 2020-09-14 17:54:29 --> Language Class Initialized
INFO - 2020-09-14 17:54:29 --> Loader Class Initialized
INFO - 2020-09-14 17:54:29 --> Helper loaded: url_helper
INFO - 2020-09-14 17:54:29 --> Database Driver Class Initialized
INFO - 2020-09-14 17:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:54:29 --> Email Class Initialized
INFO - 2020-09-14 17:54:29 --> Controller Class Initialized
DEBUG - 2020-09-14 17:54:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:54:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:54:29 --> Model Class Initialized
INFO - 2020-09-14 17:54:29 --> Model Class Initialized
INFO - 2020-09-14 17:54:29 --> Model Class Initialized
INFO - 2020-09-14 17:54:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-09-14 17:54:29 --> Final output sent to browser
DEBUG - 2020-09-14 17:54:29 --> Total execution time: 0.0234
ERROR - 2020-09-14 17:54:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:54:37 --> Config Class Initialized
INFO - 2020-09-14 17:54:37 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:54:37 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:54:37 --> Utf8 Class Initialized
INFO - 2020-09-14 17:54:37 --> URI Class Initialized
INFO - 2020-09-14 17:54:37 --> Router Class Initialized
INFO - 2020-09-14 17:54:37 --> Output Class Initialized
INFO - 2020-09-14 17:54:37 --> Security Class Initialized
DEBUG - 2020-09-14 17:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:54:37 --> Input Class Initialized
INFO - 2020-09-14 17:54:37 --> Language Class Initialized
INFO - 2020-09-14 17:54:37 --> Loader Class Initialized
INFO - 2020-09-14 17:54:37 --> Helper loaded: url_helper
INFO - 2020-09-14 17:54:37 --> Database Driver Class Initialized
INFO - 2020-09-14 17:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:54:37 --> Email Class Initialized
INFO - 2020-09-14 17:54:37 --> Controller Class Initialized
DEBUG - 2020-09-14 17:54:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:54:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:54:37 --> Model Class Initialized
INFO - 2020-09-14 17:54:37 --> Model Class Initialized
INFO - 2020-09-14 17:54:37 --> Model Class Initialized
INFO - 2020-09-14 17:54:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-09-14 17:54:37 --> Final output sent to browser
DEBUG - 2020-09-14 17:54:37 --> Total execution time: 0.0217
ERROR - 2020-09-14 17:56:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:56:25 --> Config Class Initialized
INFO - 2020-09-14 17:56:25 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:56:25 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:56:25 --> Utf8 Class Initialized
INFO - 2020-09-14 17:56:25 --> URI Class Initialized
INFO - 2020-09-14 17:56:25 --> Router Class Initialized
INFO - 2020-09-14 17:56:25 --> Output Class Initialized
INFO - 2020-09-14 17:56:25 --> Security Class Initialized
DEBUG - 2020-09-14 17:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:56:25 --> Input Class Initialized
INFO - 2020-09-14 17:56:25 --> Language Class Initialized
INFO - 2020-09-14 17:56:25 --> Loader Class Initialized
INFO - 2020-09-14 17:56:25 --> Helper loaded: url_helper
INFO - 2020-09-14 17:56:25 --> Database Driver Class Initialized
INFO - 2020-09-14 17:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:56:25 --> Email Class Initialized
INFO - 2020-09-14 17:56:25 --> Controller Class Initialized
DEBUG - 2020-09-14 17:56:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:56:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:56:25 --> Model Class Initialized
INFO - 2020-09-14 17:56:25 --> Model Class Initialized
INFO - 2020-09-14 17:56:25 --> Model Class Initialized
INFO - 2020-09-14 17:56:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-09-14 17:56:25 --> Final output sent to browser
DEBUG - 2020-09-14 17:56:25 --> Total execution time: 0.0225
ERROR - 2020-09-14 17:56:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:56:31 --> Config Class Initialized
INFO - 2020-09-14 17:56:31 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:56:31 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:56:31 --> Utf8 Class Initialized
INFO - 2020-09-14 17:56:31 --> URI Class Initialized
INFO - 2020-09-14 17:56:31 --> Router Class Initialized
INFO - 2020-09-14 17:56:31 --> Output Class Initialized
INFO - 2020-09-14 17:56:31 --> Security Class Initialized
DEBUG - 2020-09-14 17:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:56:31 --> Input Class Initialized
INFO - 2020-09-14 17:56:31 --> Language Class Initialized
INFO - 2020-09-14 17:56:31 --> Loader Class Initialized
INFO - 2020-09-14 17:56:31 --> Helper loaded: url_helper
INFO - 2020-09-14 17:56:31 --> Database Driver Class Initialized
INFO - 2020-09-14 17:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:56:31 --> Email Class Initialized
INFO - 2020-09-14 17:56:31 --> Controller Class Initialized
DEBUG - 2020-09-14 17:56:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:56:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:56:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-14 17:56:31 --> Final output sent to browser
DEBUG - 2020-09-14 17:56:31 --> Total execution time: 0.0199
ERROR - 2020-09-14 17:56:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:56:40 --> Config Class Initialized
INFO - 2020-09-14 17:56:40 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:56:40 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:56:40 --> Utf8 Class Initialized
INFO - 2020-09-14 17:56:40 --> URI Class Initialized
INFO - 2020-09-14 17:56:40 --> Router Class Initialized
INFO - 2020-09-14 17:56:40 --> Output Class Initialized
INFO - 2020-09-14 17:56:40 --> Security Class Initialized
DEBUG - 2020-09-14 17:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:56:40 --> Input Class Initialized
INFO - 2020-09-14 17:56:40 --> Language Class Initialized
INFO - 2020-09-14 17:56:40 --> Loader Class Initialized
INFO - 2020-09-14 17:56:40 --> Helper loaded: url_helper
INFO - 2020-09-14 17:56:40 --> Database Driver Class Initialized
INFO - 2020-09-14 17:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:56:40 --> Email Class Initialized
INFO - 2020-09-14 17:56:40 --> Controller Class Initialized
DEBUG - 2020-09-14 17:56:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:56:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:56:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-14 17:56:40 --> Final output sent to browser
DEBUG - 2020-09-14 17:56:40 --> Total execution time: 0.0186
ERROR - 2020-09-14 17:56:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:56:43 --> Config Class Initialized
INFO - 2020-09-14 17:56:43 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:56:43 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:56:43 --> Utf8 Class Initialized
INFO - 2020-09-14 17:56:43 --> URI Class Initialized
INFO - 2020-09-14 17:56:43 --> Router Class Initialized
INFO - 2020-09-14 17:56:43 --> Output Class Initialized
INFO - 2020-09-14 17:56:43 --> Security Class Initialized
DEBUG - 2020-09-14 17:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:56:43 --> Input Class Initialized
INFO - 2020-09-14 17:56:43 --> Language Class Initialized
INFO - 2020-09-14 17:56:43 --> Loader Class Initialized
INFO - 2020-09-14 17:56:43 --> Helper loaded: url_helper
INFO - 2020-09-14 17:56:43 --> Database Driver Class Initialized
INFO - 2020-09-14 17:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:56:43 --> Email Class Initialized
INFO - 2020-09-14 17:56:43 --> Controller Class Initialized
DEBUG - 2020-09-14 17:56:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:56:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:56:43 --> Model Class Initialized
INFO - 2020-09-14 17:56:43 --> Model Class Initialized
INFO - 2020-09-14 17:56:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-14 17:56:43 --> Final output sent to browser
DEBUG - 2020-09-14 17:56:43 --> Total execution time: 0.0206
ERROR - 2020-09-14 17:57:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:57:15 --> Config Class Initialized
INFO - 2020-09-14 17:57:15 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:57:15 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:57:15 --> Utf8 Class Initialized
INFO - 2020-09-14 17:57:15 --> URI Class Initialized
INFO - 2020-09-14 17:57:15 --> Router Class Initialized
INFO - 2020-09-14 17:57:15 --> Output Class Initialized
INFO - 2020-09-14 17:57:15 --> Security Class Initialized
DEBUG - 2020-09-14 17:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:57:15 --> Input Class Initialized
INFO - 2020-09-14 17:57:15 --> Language Class Initialized
INFO - 2020-09-14 17:57:15 --> Loader Class Initialized
INFO - 2020-09-14 17:57:15 --> Helper loaded: url_helper
INFO - 2020-09-14 17:57:15 --> Database Driver Class Initialized
INFO - 2020-09-14 17:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:57:15 --> Email Class Initialized
INFO - 2020-09-14 17:57:15 --> Controller Class Initialized
DEBUG - 2020-09-14 17:57:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:57:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:57:15 --> Model Class Initialized
INFO - 2020-09-14 17:57:15 --> Model Class Initialized
INFO - 2020-09-14 17:57:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-14 17:57:15 --> Final output sent to browser
DEBUG - 2020-09-14 17:57:15 --> Total execution time: 0.0250
ERROR - 2020-09-14 17:57:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:57:19 --> Config Class Initialized
INFO - 2020-09-14 17:57:19 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:57:19 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:57:19 --> Utf8 Class Initialized
INFO - 2020-09-14 17:57:19 --> URI Class Initialized
INFO - 2020-09-14 17:57:19 --> Router Class Initialized
INFO - 2020-09-14 17:57:19 --> Output Class Initialized
INFO - 2020-09-14 17:57:19 --> Security Class Initialized
DEBUG - 2020-09-14 17:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:57:19 --> Input Class Initialized
INFO - 2020-09-14 17:57:19 --> Language Class Initialized
INFO - 2020-09-14 17:57:19 --> Loader Class Initialized
INFO - 2020-09-14 17:57:19 --> Helper loaded: url_helper
INFO - 2020-09-14 17:57:19 --> Database Driver Class Initialized
INFO - 2020-09-14 17:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:57:19 --> Email Class Initialized
INFO - 2020-09-14 17:57:19 --> Controller Class Initialized
DEBUG - 2020-09-14 17:57:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:57:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:57:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-14 17:57:19 --> Final output sent to browser
DEBUG - 2020-09-14 17:57:19 --> Total execution time: 0.0210
ERROR - 2020-09-14 17:57:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:57:23 --> Config Class Initialized
INFO - 2020-09-14 17:57:23 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:57:23 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:57:23 --> Utf8 Class Initialized
INFO - 2020-09-14 17:57:23 --> URI Class Initialized
INFO - 2020-09-14 17:57:23 --> Router Class Initialized
INFO - 2020-09-14 17:57:23 --> Output Class Initialized
INFO - 2020-09-14 17:57:23 --> Security Class Initialized
DEBUG - 2020-09-14 17:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:57:23 --> Input Class Initialized
INFO - 2020-09-14 17:57:23 --> Language Class Initialized
INFO - 2020-09-14 17:57:23 --> Loader Class Initialized
INFO - 2020-09-14 17:57:23 --> Helper loaded: url_helper
INFO - 2020-09-14 17:57:23 --> Database Driver Class Initialized
INFO - 2020-09-14 17:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:57:23 --> Email Class Initialized
INFO - 2020-09-14 17:57:23 --> Controller Class Initialized
DEBUG - 2020-09-14 17:57:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:57:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:57:23 --> Model Class Initialized
INFO - 2020-09-14 17:57:23 --> Model Class Initialized
INFO - 2020-09-14 17:57:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-14 17:57:23 --> Final output sent to browser
DEBUG - 2020-09-14 17:57:23 --> Total execution time: 0.0230
ERROR - 2020-09-14 17:57:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:57:39 --> Config Class Initialized
INFO - 2020-09-14 17:57:39 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:57:39 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:57:39 --> Utf8 Class Initialized
INFO - 2020-09-14 17:57:39 --> URI Class Initialized
INFO - 2020-09-14 17:57:39 --> Router Class Initialized
INFO - 2020-09-14 17:57:39 --> Output Class Initialized
INFO - 2020-09-14 17:57:39 --> Security Class Initialized
DEBUG - 2020-09-14 17:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:57:39 --> Input Class Initialized
INFO - 2020-09-14 17:57:39 --> Language Class Initialized
INFO - 2020-09-14 17:57:39 --> Loader Class Initialized
INFO - 2020-09-14 17:57:39 --> Helper loaded: url_helper
INFO - 2020-09-14 17:57:39 --> Database Driver Class Initialized
INFO - 2020-09-14 17:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:57:39 --> Email Class Initialized
INFO - 2020-09-14 17:57:39 --> Controller Class Initialized
DEBUG - 2020-09-14 17:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:57:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:57:39 --> Model Class Initialized
INFO - 2020-09-14 17:57:39 --> Model Class Initialized
INFO - 2020-09-14 17:57:39 --> Model Class Initialized
INFO - 2020-09-14 17:57:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-09-14 17:57:39 --> Final output sent to browser
DEBUG - 2020-09-14 17:57:39 --> Total execution time: 0.0219
ERROR - 2020-09-14 17:58:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:58:22 --> Config Class Initialized
INFO - 2020-09-14 17:58:22 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:58:22 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:58:22 --> Utf8 Class Initialized
INFO - 2020-09-14 17:58:22 --> URI Class Initialized
INFO - 2020-09-14 17:58:22 --> Router Class Initialized
INFO - 2020-09-14 17:58:22 --> Output Class Initialized
INFO - 2020-09-14 17:58:22 --> Security Class Initialized
DEBUG - 2020-09-14 17:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:58:22 --> Input Class Initialized
INFO - 2020-09-14 17:58:22 --> Language Class Initialized
INFO - 2020-09-14 17:58:22 --> Loader Class Initialized
INFO - 2020-09-14 17:58:22 --> Helper loaded: url_helper
INFO - 2020-09-14 17:58:22 --> Database Driver Class Initialized
INFO - 2020-09-14 17:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:58:22 --> Email Class Initialized
INFO - 2020-09-14 17:58:22 --> Controller Class Initialized
DEBUG - 2020-09-14 17:58:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:58:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:58:22 --> Model Class Initialized
INFO - 2020-09-14 17:58:22 --> Model Class Initialized
INFO - 2020-09-14 17:58:22 --> Model Class Initialized
INFO - 2020-09-14 17:58:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-09-14 17:58:22 --> Final output sent to browser
DEBUG - 2020-09-14 17:58:22 --> Total execution time: 0.0249
ERROR - 2020-09-14 17:58:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:58:27 --> Config Class Initialized
INFO - 2020-09-14 17:58:27 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:58:27 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:58:27 --> Utf8 Class Initialized
INFO - 2020-09-14 17:58:27 --> URI Class Initialized
INFO - 2020-09-14 17:58:27 --> Router Class Initialized
INFO - 2020-09-14 17:58:27 --> Output Class Initialized
INFO - 2020-09-14 17:58:27 --> Security Class Initialized
DEBUG - 2020-09-14 17:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:58:27 --> Input Class Initialized
INFO - 2020-09-14 17:58:27 --> Language Class Initialized
INFO - 2020-09-14 17:58:27 --> Loader Class Initialized
INFO - 2020-09-14 17:58:27 --> Helper loaded: url_helper
INFO - 2020-09-14 17:58:27 --> Database Driver Class Initialized
INFO - 2020-09-14 17:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:58:27 --> Email Class Initialized
INFO - 2020-09-14 17:58:27 --> Controller Class Initialized
DEBUG - 2020-09-14 17:58:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:58:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:58:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-14 17:58:27 --> Final output sent to browser
DEBUG - 2020-09-14 17:58:27 --> Total execution time: 0.0197
ERROR - 2020-09-14 17:58:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:58:36 --> Config Class Initialized
INFO - 2020-09-14 17:58:36 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:58:36 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:58:36 --> Utf8 Class Initialized
INFO - 2020-09-14 17:58:36 --> URI Class Initialized
INFO - 2020-09-14 17:58:36 --> Router Class Initialized
INFO - 2020-09-14 17:58:36 --> Output Class Initialized
INFO - 2020-09-14 17:58:36 --> Security Class Initialized
DEBUG - 2020-09-14 17:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:58:36 --> Input Class Initialized
INFO - 2020-09-14 17:58:36 --> Language Class Initialized
INFO - 2020-09-14 17:58:36 --> Loader Class Initialized
INFO - 2020-09-14 17:58:36 --> Helper loaded: url_helper
INFO - 2020-09-14 17:58:36 --> Database Driver Class Initialized
INFO - 2020-09-14 17:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:58:36 --> Email Class Initialized
INFO - 2020-09-14 17:58:36 --> Controller Class Initialized
DEBUG - 2020-09-14 17:58:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:58:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:58:36 --> Model Class Initialized
INFO - 2020-09-14 17:58:36 --> Model Class Initialized
INFO - 2020-09-14 17:58:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-14 17:58:36 --> Final output sent to browser
DEBUG - 2020-09-14 17:58:36 --> Total execution time: 0.0219
ERROR - 2020-09-14 17:58:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:58:41 --> Config Class Initialized
INFO - 2020-09-14 17:58:41 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:58:41 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:58:41 --> Utf8 Class Initialized
INFO - 2020-09-14 17:58:41 --> URI Class Initialized
INFO - 2020-09-14 17:58:41 --> Router Class Initialized
INFO - 2020-09-14 17:58:41 --> Output Class Initialized
INFO - 2020-09-14 17:58:41 --> Security Class Initialized
DEBUG - 2020-09-14 17:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:58:41 --> Input Class Initialized
INFO - 2020-09-14 17:58:41 --> Language Class Initialized
INFO - 2020-09-14 17:58:41 --> Loader Class Initialized
INFO - 2020-09-14 17:58:41 --> Helper loaded: url_helper
INFO - 2020-09-14 17:58:41 --> Database Driver Class Initialized
INFO - 2020-09-14 17:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:58:41 --> Email Class Initialized
INFO - 2020-09-14 17:58:41 --> Controller Class Initialized
DEBUG - 2020-09-14 17:58:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:58:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:58:41 --> Model Class Initialized
INFO - 2020-09-14 17:58:41 --> Model Class Initialized
INFO - 2020-09-14 17:58:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-14 17:58:41 --> Final output sent to browser
DEBUG - 2020-09-14 17:58:41 --> Total execution time: 0.0220
ERROR - 2020-09-14 17:58:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:58:45 --> Config Class Initialized
INFO - 2020-09-14 17:58:45 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:58:45 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:58:45 --> Utf8 Class Initialized
INFO - 2020-09-14 17:58:45 --> URI Class Initialized
INFO - 2020-09-14 17:58:45 --> Router Class Initialized
INFO - 2020-09-14 17:58:45 --> Output Class Initialized
INFO - 2020-09-14 17:58:45 --> Security Class Initialized
DEBUG - 2020-09-14 17:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:58:45 --> Input Class Initialized
INFO - 2020-09-14 17:58:45 --> Language Class Initialized
INFO - 2020-09-14 17:58:45 --> Loader Class Initialized
INFO - 2020-09-14 17:58:45 --> Helper loaded: url_helper
INFO - 2020-09-14 17:58:45 --> Database Driver Class Initialized
INFO - 2020-09-14 17:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:58:45 --> Email Class Initialized
INFO - 2020-09-14 17:58:45 --> Controller Class Initialized
DEBUG - 2020-09-14 17:58:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:58:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:58:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-14 17:58:45 --> Final output sent to browser
DEBUG - 2020-09-14 17:58:45 --> Total execution time: 0.0185
ERROR - 2020-09-14 17:58:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:58:49 --> Config Class Initialized
INFO - 2020-09-14 17:58:49 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:58:49 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:58:49 --> Utf8 Class Initialized
INFO - 2020-09-14 17:58:49 --> URI Class Initialized
INFO - 2020-09-14 17:58:49 --> Router Class Initialized
INFO - 2020-09-14 17:58:49 --> Output Class Initialized
INFO - 2020-09-14 17:58:49 --> Security Class Initialized
DEBUG - 2020-09-14 17:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:58:49 --> Input Class Initialized
INFO - 2020-09-14 17:58:49 --> Language Class Initialized
INFO - 2020-09-14 17:58:49 --> Loader Class Initialized
INFO - 2020-09-14 17:58:49 --> Helper loaded: url_helper
INFO - 2020-09-14 17:58:49 --> Database Driver Class Initialized
INFO - 2020-09-14 17:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:58:49 --> Email Class Initialized
INFO - 2020-09-14 17:58:49 --> Controller Class Initialized
DEBUG - 2020-09-14 17:58:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:58:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:58:49 --> Model Class Initialized
INFO - 2020-09-14 17:58:49 --> Model Class Initialized
INFO - 2020-09-14 17:58:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-14 17:58:49 --> Final output sent to browser
DEBUG - 2020-09-14 17:58:49 --> Total execution time: 0.0218
ERROR - 2020-09-14 17:59:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:59:00 --> Config Class Initialized
INFO - 2020-09-14 17:59:00 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:59:00 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:59:00 --> Utf8 Class Initialized
INFO - 2020-09-14 17:59:00 --> URI Class Initialized
INFO - 2020-09-14 17:59:00 --> Router Class Initialized
INFO - 2020-09-14 17:59:00 --> Output Class Initialized
INFO - 2020-09-14 17:59:00 --> Security Class Initialized
DEBUG - 2020-09-14 17:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:59:00 --> Input Class Initialized
INFO - 2020-09-14 17:59:00 --> Language Class Initialized
INFO - 2020-09-14 17:59:00 --> Loader Class Initialized
INFO - 2020-09-14 17:59:00 --> Helper loaded: url_helper
INFO - 2020-09-14 17:59:00 --> Database Driver Class Initialized
INFO - 2020-09-14 17:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:59:00 --> Email Class Initialized
INFO - 2020-09-14 17:59:00 --> Controller Class Initialized
DEBUG - 2020-09-14 17:59:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 17:59:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 17:59:00 --> Model Class Initialized
INFO - 2020-09-14 17:59:00 --> Model Class Initialized
INFO - 2020-09-14 17:59:00 --> Model Class Initialized
INFO - 2020-09-14 17:59:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-09-14 17:59:00 --> Final output sent to browser
DEBUG - 2020-09-14 17:59:00 --> Total execution time: 0.0269
ERROR - 2020-09-14 17:59:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:59:15 --> Config Class Initialized
INFO - 2020-09-14 17:59:15 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:59:15 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:59:15 --> Utf8 Class Initialized
INFO - 2020-09-14 17:59:15 --> URI Class Initialized
INFO - 2020-09-14 17:59:15 --> Router Class Initialized
INFO - 2020-09-14 17:59:15 --> Output Class Initialized
INFO - 2020-09-14 17:59:15 --> Security Class Initialized
DEBUG - 2020-09-14 17:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:59:15 --> Input Class Initialized
INFO - 2020-09-14 17:59:15 --> Language Class Initialized
INFO - 2020-09-14 17:59:15 --> Loader Class Initialized
INFO - 2020-09-14 17:59:15 --> Helper loaded: url_helper
INFO - 2020-09-14 17:59:15 --> Database Driver Class Initialized
INFO - 2020-09-14 17:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:59:15 --> Email Class Initialized
INFO - 2020-09-14 17:59:15 --> Controller Class Initialized
INFO - 2020-09-14 17:59:15 --> Model Class Initialized
INFO - 2020-09-14 17:59:15 --> Model Class Initialized
INFO - 2020-09-14 17:59:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-14 17:59:15 --> Final output sent to browser
DEBUG - 2020-09-14 17:59:15 --> Total execution time: 0.0422
ERROR - 2020-09-14 17:59:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 17:59:15 --> Config Class Initialized
INFO - 2020-09-14 17:59:15 --> Hooks Class Initialized
DEBUG - 2020-09-14 17:59:15 --> UTF-8 Support Enabled
INFO - 2020-09-14 17:59:15 --> Utf8 Class Initialized
INFO - 2020-09-14 17:59:15 --> URI Class Initialized
INFO - 2020-09-14 17:59:15 --> Router Class Initialized
INFO - 2020-09-14 17:59:15 --> Output Class Initialized
INFO - 2020-09-14 17:59:15 --> Security Class Initialized
DEBUG - 2020-09-14 17:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 17:59:15 --> Input Class Initialized
INFO - 2020-09-14 17:59:15 --> Language Class Initialized
INFO - 2020-09-14 17:59:15 --> Loader Class Initialized
INFO - 2020-09-14 17:59:15 --> Helper loaded: url_helper
INFO - 2020-09-14 17:59:15 --> Database Driver Class Initialized
INFO - 2020-09-14 17:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 17:59:15 --> Email Class Initialized
INFO - 2020-09-14 17:59:15 --> Controller Class Initialized
INFO - 2020-09-14 17:59:15 --> Model Class Initialized
INFO - 2020-09-14 17:59:15 --> Model Class Initialized
INFO - 2020-09-14 17:59:15 --> Final output sent to browser
DEBUG - 2020-09-14 17:59:15 --> Total execution time: 0.0396
ERROR - 2020-09-14 18:00:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:00:57 --> Config Class Initialized
INFO - 2020-09-14 18:00:57 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:00:57 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:00:57 --> Utf8 Class Initialized
INFO - 2020-09-14 18:00:57 --> URI Class Initialized
INFO - 2020-09-14 18:00:57 --> Router Class Initialized
INFO - 2020-09-14 18:00:57 --> Output Class Initialized
INFO - 2020-09-14 18:00:57 --> Security Class Initialized
DEBUG - 2020-09-14 18:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:00:57 --> Input Class Initialized
INFO - 2020-09-14 18:00:57 --> Language Class Initialized
INFO - 2020-09-14 18:00:57 --> Loader Class Initialized
INFO - 2020-09-14 18:00:57 --> Helper loaded: url_helper
INFO - 2020-09-14 18:00:57 --> Database Driver Class Initialized
INFO - 2020-09-14 18:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:00:57 --> Email Class Initialized
INFO - 2020-09-14 18:00:57 --> Controller Class Initialized
INFO - 2020-09-14 18:00:57 --> Model Class Initialized
INFO - 2020-09-14 18:00:57 --> Model Class Initialized
INFO - 2020-09-14 18:00:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-14 18:00:57 --> Final output sent to browser
DEBUG - 2020-09-14 18:00:57 --> Total execution time: 0.0362
ERROR - 2020-09-14 18:00:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:00:58 --> Config Class Initialized
INFO - 2020-09-14 18:00:58 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:00:58 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:00:58 --> Utf8 Class Initialized
INFO - 2020-09-14 18:00:58 --> URI Class Initialized
INFO - 2020-09-14 18:00:58 --> Router Class Initialized
INFO - 2020-09-14 18:00:58 --> Output Class Initialized
INFO - 2020-09-14 18:00:58 --> Security Class Initialized
DEBUG - 2020-09-14 18:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:00:58 --> Input Class Initialized
INFO - 2020-09-14 18:00:58 --> Language Class Initialized
INFO - 2020-09-14 18:00:58 --> Loader Class Initialized
INFO - 2020-09-14 18:00:58 --> Helper loaded: url_helper
INFO - 2020-09-14 18:00:58 --> Database Driver Class Initialized
INFO - 2020-09-14 18:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:00:58 --> Email Class Initialized
INFO - 2020-09-14 18:00:58 --> Controller Class Initialized
INFO - 2020-09-14 18:00:58 --> Model Class Initialized
INFO - 2020-09-14 18:00:58 --> Model Class Initialized
INFO - 2020-09-14 18:00:58 --> Final output sent to browser
DEBUG - 2020-09-14 18:00:58 --> Total execution time: 0.0388
ERROR - 2020-09-14 18:01:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:01:06 --> Config Class Initialized
INFO - 2020-09-14 18:01:06 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:01:06 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:01:06 --> Utf8 Class Initialized
INFO - 2020-09-14 18:01:06 --> URI Class Initialized
INFO - 2020-09-14 18:01:06 --> Router Class Initialized
INFO - 2020-09-14 18:01:06 --> Output Class Initialized
INFO - 2020-09-14 18:01:06 --> Security Class Initialized
DEBUG - 2020-09-14 18:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:01:06 --> Input Class Initialized
INFO - 2020-09-14 18:01:06 --> Language Class Initialized
INFO - 2020-09-14 18:01:06 --> Loader Class Initialized
INFO - 2020-09-14 18:01:06 --> Helper loaded: url_helper
INFO - 2020-09-14 18:01:06 --> Database Driver Class Initialized
INFO - 2020-09-14 18:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:01:06 --> Email Class Initialized
INFO - 2020-09-14 18:01:06 --> Controller Class Initialized
DEBUG - 2020-09-14 18:01:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:01:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:01:06 --> Model Class Initialized
INFO - 2020-09-14 18:01:06 --> Model Class Initialized
INFO - 2020-09-14 18:01:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-14 18:01:06 --> Final output sent to browser
DEBUG - 2020-09-14 18:01:06 --> Total execution time: 0.0245
ERROR - 2020-09-14 18:01:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:01:08 --> Config Class Initialized
INFO - 2020-09-14 18:01:08 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:01:08 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:01:08 --> Utf8 Class Initialized
INFO - 2020-09-14 18:01:08 --> URI Class Initialized
INFO - 2020-09-14 18:01:08 --> Router Class Initialized
INFO - 2020-09-14 18:01:08 --> Output Class Initialized
INFO - 2020-09-14 18:01:08 --> Security Class Initialized
DEBUG - 2020-09-14 18:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:01:08 --> Input Class Initialized
INFO - 2020-09-14 18:01:08 --> Language Class Initialized
INFO - 2020-09-14 18:01:08 --> Loader Class Initialized
INFO - 2020-09-14 18:01:08 --> Helper loaded: url_helper
INFO - 2020-09-14 18:01:08 --> Database Driver Class Initialized
INFO - 2020-09-14 18:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:01:08 --> Email Class Initialized
INFO - 2020-09-14 18:01:08 --> Controller Class Initialized
DEBUG - 2020-09-14 18:01:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:01:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:01:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-14 18:01:08 --> Final output sent to browser
DEBUG - 2020-09-14 18:01:08 --> Total execution time: 0.0210
ERROR - 2020-09-14 18:01:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:01:30 --> Config Class Initialized
INFO - 2020-09-14 18:01:30 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:01:30 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:01:30 --> Utf8 Class Initialized
INFO - 2020-09-14 18:01:30 --> URI Class Initialized
INFO - 2020-09-14 18:01:30 --> Router Class Initialized
INFO - 2020-09-14 18:01:30 --> Output Class Initialized
INFO - 2020-09-14 18:01:30 --> Security Class Initialized
DEBUG - 2020-09-14 18:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:01:30 --> Input Class Initialized
INFO - 2020-09-14 18:01:30 --> Language Class Initialized
INFO - 2020-09-14 18:01:30 --> Loader Class Initialized
INFO - 2020-09-14 18:01:30 --> Helper loaded: url_helper
INFO - 2020-09-14 18:01:30 --> Database Driver Class Initialized
INFO - 2020-09-14 18:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:01:30 --> Email Class Initialized
INFO - 2020-09-14 18:01:30 --> Controller Class Initialized
DEBUG - 2020-09-14 18:01:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:01:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:01:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-14 18:01:30 --> Final output sent to browser
DEBUG - 2020-09-14 18:01:30 --> Total execution time: 0.0197
ERROR - 2020-09-14 18:01:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:01:39 --> Config Class Initialized
INFO - 2020-09-14 18:01:39 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:01:39 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:01:39 --> Utf8 Class Initialized
INFO - 2020-09-14 18:01:39 --> URI Class Initialized
INFO - 2020-09-14 18:01:39 --> Router Class Initialized
INFO - 2020-09-14 18:01:39 --> Output Class Initialized
INFO - 2020-09-14 18:01:39 --> Security Class Initialized
DEBUG - 2020-09-14 18:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:01:39 --> Input Class Initialized
INFO - 2020-09-14 18:01:39 --> Language Class Initialized
INFO - 2020-09-14 18:01:39 --> Loader Class Initialized
INFO - 2020-09-14 18:01:39 --> Helper loaded: url_helper
INFO - 2020-09-14 18:01:39 --> Database Driver Class Initialized
INFO - 2020-09-14 18:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:01:39 --> Email Class Initialized
INFO - 2020-09-14 18:01:39 --> Controller Class Initialized
INFO - 2020-09-14 18:01:39 --> Model Class Initialized
INFO - 2020-09-14 18:01:39 --> Model Class Initialized
INFO - 2020-09-14 18:01:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-14 18:01:39 --> Final output sent to browser
DEBUG - 2020-09-14 18:01:39 --> Total execution time: 0.0399
ERROR - 2020-09-14 18:01:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:01:39 --> Config Class Initialized
INFO - 2020-09-14 18:01:39 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:01:39 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:01:39 --> Utf8 Class Initialized
INFO - 2020-09-14 18:01:39 --> URI Class Initialized
INFO - 2020-09-14 18:01:39 --> Router Class Initialized
INFO - 2020-09-14 18:01:39 --> Output Class Initialized
INFO - 2020-09-14 18:01:39 --> Security Class Initialized
DEBUG - 2020-09-14 18:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:01:39 --> Input Class Initialized
INFO - 2020-09-14 18:01:39 --> Language Class Initialized
INFO - 2020-09-14 18:01:39 --> Loader Class Initialized
INFO - 2020-09-14 18:01:39 --> Helper loaded: url_helper
INFO - 2020-09-14 18:01:39 --> Database Driver Class Initialized
INFO - 2020-09-14 18:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:01:39 --> Email Class Initialized
INFO - 2020-09-14 18:01:39 --> Controller Class Initialized
INFO - 2020-09-14 18:01:39 --> Model Class Initialized
INFO - 2020-09-14 18:01:39 --> Model Class Initialized
INFO - 2020-09-14 18:01:40 --> Final output sent to browser
DEBUG - 2020-09-14 18:01:40 --> Total execution time: 0.0573
ERROR - 2020-09-14 18:01:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:01:42 --> Config Class Initialized
INFO - 2020-09-14 18:01:42 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:01:42 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:01:42 --> Utf8 Class Initialized
INFO - 2020-09-14 18:01:42 --> URI Class Initialized
INFO - 2020-09-14 18:01:42 --> Router Class Initialized
INFO - 2020-09-14 18:01:42 --> Output Class Initialized
INFO - 2020-09-14 18:01:42 --> Security Class Initialized
DEBUG - 2020-09-14 18:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:01:42 --> Input Class Initialized
INFO - 2020-09-14 18:01:42 --> Language Class Initialized
INFO - 2020-09-14 18:01:42 --> Loader Class Initialized
INFO - 2020-09-14 18:01:42 --> Helper loaded: url_helper
INFO - 2020-09-14 18:01:42 --> Database Driver Class Initialized
INFO - 2020-09-14 18:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:01:42 --> Email Class Initialized
INFO - 2020-09-14 18:01:42 --> Controller Class Initialized
DEBUG - 2020-09-14 18:01:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:01:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:01:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-14 18:01:42 --> Final output sent to browser
DEBUG - 2020-09-14 18:01:42 --> Total execution time: 0.0208
ERROR - 2020-09-14 18:01:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:01:46 --> Config Class Initialized
INFO - 2020-09-14 18:01:46 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:01:46 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:01:46 --> Utf8 Class Initialized
INFO - 2020-09-14 18:01:46 --> URI Class Initialized
INFO - 2020-09-14 18:01:46 --> Router Class Initialized
INFO - 2020-09-14 18:01:46 --> Output Class Initialized
INFO - 2020-09-14 18:01:46 --> Security Class Initialized
DEBUG - 2020-09-14 18:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:01:46 --> Input Class Initialized
INFO - 2020-09-14 18:01:46 --> Language Class Initialized
INFO - 2020-09-14 18:01:46 --> Loader Class Initialized
INFO - 2020-09-14 18:01:46 --> Helper loaded: url_helper
INFO - 2020-09-14 18:01:46 --> Database Driver Class Initialized
INFO - 2020-09-14 18:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:01:46 --> Email Class Initialized
INFO - 2020-09-14 18:01:46 --> Controller Class Initialized
DEBUG - 2020-09-14 18:01:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:01:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:01:46 --> Model Class Initialized
INFO - 2020-09-14 18:01:46 --> Model Class Initialized
INFO - 2020-09-14 18:01:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-14 18:01:46 --> Final output sent to browser
DEBUG - 2020-09-14 18:01:46 --> Total execution time: 0.0211
ERROR - 2020-09-14 18:01:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:01:49 --> Config Class Initialized
INFO - 2020-09-14 18:01:49 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:01:49 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:01:49 --> Utf8 Class Initialized
INFO - 2020-09-14 18:01:49 --> URI Class Initialized
INFO - 2020-09-14 18:01:49 --> Router Class Initialized
INFO - 2020-09-14 18:01:49 --> Output Class Initialized
INFO - 2020-09-14 18:01:49 --> Security Class Initialized
DEBUG - 2020-09-14 18:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:01:49 --> Input Class Initialized
INFO - 2020-09-14 18:01:49 --> Language Class Initialized
INFO - 2020-09-14 18:01:49 --> Loader Class Initialized
INFO - 2020-09-14 18:01:49 --> Helper loaded: url_helper
INFO - 2020-09-14 18:01:49 --> Database Driver Class Initialized
INFO - 2020-09-14 18:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:01:49 --> Email Class Initialized
INFO - 2020-09-14 18:01:49 --> Controller Class Initialized
INFO - 2020-09-14 18:01:49 --> Model Class Initialized
INFO - 2020-09-14 18:01:49 --> Model Class Initialized
INFO - 2020-09-14 18:01:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-14 18:01:49 --> Final output sent to browser
DEBUG - 2020-09-14 18:01:49 --> Total execution time: 0.0344
ERROR - 2020-09-14 18:02:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:02:02 --> Config Class Initialized
INFO - 2020-09-14 18:02:02 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:02:02 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:02:02 --> Utf8 Class Initialized
INFO - 2020-09-14 18:02:02 --> URI Class Initialized
INFO - 2020-09-14 18:02:02 --> Router Class Initialized
INFO - 2020-09-14 18:02:02 --> Output Class Initialized
INFO - 2020-09-14 18:02:02 --> Security Class Initialized
DEBUG - 2020-09-14 18:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:02:02 --> Input Class Initialized
INFO - 2020-09-14 18:02:02 --> Language Class Initialized
INFO - 2020-09-14 18:02:02 --> Loader Class Initialized
INFO - 2020-09-14 18:02:02 --> Helper loaded: url_helper
INFO - 2020-09-14 18:02:02 --> Database Driver Class Initialized
INFO - 2020-09-14 18:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:02:02 --> Email Class Initialized
INFO - 2020-09-14 18:02:02 --> Controller Class Initialized
INFO - 2020-09-14 18:02:02 --> Model Class Initialized
INFO - 2020-09-14 18:02:02 --> Model Class Initialized
INFO - 2020-09-14 18:02:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-14 18:02:02 --> Final output sent to browser
DEBUG - 2020-09-14 18:02:02 --> Total execution time: 0.0357
ERROR - 2020-09-14 18:02:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:02:03 --> Config Class Initialized
INFO - 2020-09-14 18:02:03 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:02:03 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:02:03 --> Utf8 Class Initialized
INFO - 2020-09-14 18:02:03 --> URI Class Initialized
INFO - 2020-09-14 18:02:03 --> Router Class Initialized
INFO - 2020-09-14 18:02:03 --> Output Class Initialized
INFO - 2020-09-14 18:02:03 --> Security Class Initialized
DEBUG - 2020-09-14 18:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:02:03 --> Input Class Initialized
INFO - 2020-09-14 18:02:03 --> Language Class Initialized
INFO - 2020-09-14 18:02:03 --> Loader Class Initialized
INFO - 2020-09-14 18:02:03 --> Helper loaded: url_helper
INFO - 2020-09-14 18:02:03 --> Database Driver Class Initialized
INFO - 2020-09-14 18:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:02:03 --> Email Class Initialized
INFO - 2020-09-14 18:02:03 --> Controller Class Initialized
INFO - 2020-09-14 18:02:03 --> Model Class Initialized
INFO - 2020-09-14 18:02:03 --> Model Class Initialized
INFO - 2020-09-14 18:02:03 --> Final output sent to browser
DEBUG - 2020-09-14 18:02:03 --> Total execution time: 0.0427
ERROR - 2020-09-14 18:02:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:02:06 --> Config Class Initialized
INFO - 2020-09-14 18:02:06 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:02:06 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:02:06 --> Utf8 Class Initialized
INFO - 2020-09-14 18:02:06 --> URI Class Initialized
INFO - 2020-09-14 18:02:06 --> Router Class Initialized
INFO - 2020-09-14 18:02:06 --> Output Class Initialized
INFO - 2020-09-14 18:02:06 --> Security Class Initialized
DEBUG - 2020-09-14 18:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:02:06 --> Input Class Initialized
INFO - 2020-09-14 18:02:06 --> Language Class Initialized
INFO - 2020-09-14 18:02:06 --> Loader Class Initialized
INFO - 2020-09-14 18:02:06 --> Helper loaded: url_helper
INFO - 2020-09-14 18:02:06 --> Database Driver Class Initialized
INFO - 2020-09-14 18:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:02:06 --> Email Class Initialized
INFO - 2020-09-14 18:02:06 --> Controller Class Initialized
DEBUG - 2020-09-14 18:02:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:02:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:02:06 --> Model Class Initialized
INFO - 2020-09-14 18:02:06 --> Model Class Initialized
INFO - 2020-09-14 18:02:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-14 18:02:06 --> Final output sent to browser
DEBUG - 2020-09-14 18:02:06 --> Total execution time: 0.0218
ERROR - 2020-09-14 18:02:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:02:10 --> Config Class Initialized
INFO - 2020-09-14 18:02:10 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:02:10 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:02:10 --> Utf8 Class Initialized
INFO - 2020-09-14 18:02:10 --> URI Class Initialized
INFO - 2020-09-14 18:02:10 --> Router Class Initialized
INFO - 2020-09-14 18:02:10 --> Output Class Initialized
INFO - 2020-09-14 18:02:10 --> Security Class Initialized
DEBUG - 2020-09-14 18:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:02:10 --> Input Class Initialized
INFO - 2020-09-14 18:02:10 --> Language Class Initialized
INFO - 2020-09-14 18:02:10 --> Loader Class Initialized
INFO - 2020-09-14 18:02:10 --> Helper loaded: url_helper
INFO - 2020-09-14 18:02:10 --> Database Driver Class Initialized
INFO - 2020-09-14 18:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:02:10 --> Email Class Initialized
INFO - 2020-09-14 18:02:10 --> Controller Class Initialized
DEBUG - 2020-09-14 18:02:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:02:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:02:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-14 18:02:10 --> Final output sent to browser
DEBUG - 2020-09-14 18:02:10 --> Total execution time: 0.0183
ERROR - 2020-09-14 18:02:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:02:47 --> Config Class Initialized
INFO - 2020-09-14 18:02:47 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:02:47 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:02:47 --> Utf8 Class Initialized
INFO - 2020-09-14 18:02:47 --> URI Class Initialized
DEBUG - 2020-09-14 18:02:47 --> No URI present. Default controller set.
INFO - 2020-09-14 18:02:47 --> Router Class Initialized
INFO - 2020-09-14 18:02:47 --> Output Class Initialized
INFO - 2020-09-14 18:02:47 --> Security Class Initialized
DEBUG - 2020-09-14 18:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:02:47 --> Input Class Initialized
INFO - 2020-09-14 18:02:47 --> Language Class Initialized
INFO - 2020-09-14 18:02:47 --> Loader Class Initialized
INFO - 2020-09-14 18:02:47 --> Helper loaded: url_helper
INFO - 2020-09-14 18:02:47 --> Database Driver Class Initialized
INFO - 2020-09-14 18:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:02:47 --> Email Class Initialized
INFO - 2020-09-14 18:02:47 --> Controller Class Initialized
INFO - 2020-09-14 18:02:47 --> Model Class Initialized
INFO - 2020-09-14 18:02:47 --> Model Class Initialized
DEBUG - 2020-09-14 18:02:47 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:02:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-14 18:02:47 --> Final output sent to browser
DEBUG - 2020-09-14 18:02:47 --> Total execution time: 0.0197
ERROR - 2020-09-14 18:03:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:03:02 --> Config Class Initialized
INFO - 2020-09-14 18:03:02 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:03:02 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:03:02 --> Utf8 Class Initialized
INFO - 2020-09-14 18:03:02 --> URI Class Initialized
INFO - 2020-09-14 18:03:02 --> Router Class Initialized
INFO - 2020-09-14 18:03:02 --> Output Class Initialized
INFO - 2020-09-14 18:03:02 --> Security Class Initialized
DEBUG - 2020-09-14 18:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:03:02 --> Input Class Initialized
INFO - 2020-09-14 18:03:02 --> Language Class Initialized
INFO - 2020-09-14 18:03:02 --> Loader Class Initialized
INFO - 2020-09-14 18:03:02 --> Helper loaded: url_helper
INFO - 2020-09-14 18:03:02 --> Database Driver Class Initialized
INFO - 2020-09-14 18:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:03:02 --> Email Class Initialized
INFO - 2020-09-14 18:03:02 --> Controller Class Initialized
INFO - 2020-09-14 18:03:02 --> Model Class Initialized
INFO - 2020-09-14 18:03:02 --> Model Class Initialized
DEBUG - 2020-09-14 18:03:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:03:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:03:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-09-14 18:03:02 --> Final output sent to browser
DEBUG - 2020-09-14 18:03:02 --> Total execution time: 0.0422
ERROR - 2020-09-14 18:04:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:04:53 --> Config Class Initialized
INFO - 2020-09-14 18:04:53 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:04:53 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:04:53 --> Utf8 Class Initialized
INFO - 2020-09-14 18:04:53 --> URI Class Initialized
INFO - 2020-09-14 18:04:53 --> Router Class Initialized
INFO - 2020-09-14 18:04:53 --> Output Class Initialized
INFO - 2020-09-14 18:04:53 --> Security Class Initialized
DEBUG - 2020-09-14 18:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:04:53 --> Input Class Initialized
INFO - 2020-09-14 18:04:53 --> Language Class Initialized
INFO - 2020-09-14 18:04:53 --> Loader Class Initialized
INFO - 2020-09-14 18:04:53 --> Helper loaded: url_helper
INFO - 2020-09-14 18:04:53 --> Database Driver Class Initialized
INFO - 2020-09-14 18:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:04:53 --> Email Class Initialized
INFO - 2020-09-14 18:04:53 --> Controller Class Initialized
INFO - 2020-09-14 18:04:53 --> Model Class Initialized
INFO - 2020-09-14 18:04:53 --> Model Class Initialized
DEBUG - 2020-09-14 18:04:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:04:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:04:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-09-14 18:04:53 --> Final output sent to browser
DEBUG - 2020-09-14 18:04:53 --> Total execution time: 0.0219
ERROR - 2020-09-14 18:05:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:05:02 --> Config Class Initialized
INFO - 2020-09-14 18:05:02 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:05:02 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:05:02 --> Utf8 Class Initialized
INFO - 2020-09-14 18:05:02 --> URI Class Initialized
DEBUG - 2020-09-14 18:05:02 --> No URI present. Default controller set.
INFO - 2020-09-14 18:05:02 --> Router Class Initialized
INFO - 2020-09-14 18:05:02 --> Output Class Initialized
INFO - 2020-09-14 18:05:02 --> Security Class Initialized
DEBUG - 2020-09-14 18:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:05:02 --> Input Class Initialized
INFO - 2020-09-14 18:05:02 --> Language Class Initialized
INFO - 2020-09-14 18:05:02 --> Loader Class Initialized
INFO - 2020-09-14 18:05:02 --> Helper loaded: url_helper
INFO - 2020-09-14 18:05:02 --> Database Driver Class Initialized
INFO - 2020-09-14 18:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:05:02 --> Email Class Initialized
INFO - 2020-09-14 18:05:02 --> Controller Class Initialized
INFO - 2020-09-14 18:05:02 --> Model Class Initialized
INFO - 2020-09-14 18:05:02 --> Model Class Initialized
DEBUG - 2020-09-14 18:05:02 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:05:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-14 18:05:02 --> Final output sent to browser
DEBUG - 2020-09-14 18:05:02 --> Total execution time: 0.0193
ERROR - 2020-09-14 18:06:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:06:40 --> Config Class Initialized
INFO - 2020-09-14 18:06:40 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:06:40 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:06:40 --> Utf8 Class Initialized
INFO - 2020-09-14 18:06:40 --> URI Class Initialized
INFO - 2020-09-14 18:06:40 --> Router Class Initialized
INFO - 2020-09-14 18:06:40 --> Output Class Initialized
INFO - 2020-09-14 18:06:40 --> Security Class Initialized
DEBUG - 2020-09-14 18:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:06:40 --> Input Class Initialized
INFO - 2020-09-14 18:06:40 --> Language Class Initialized
INFO - 2020-09-14 18:06:40 --> Loader Class Initialized
INFO - 2020-09-14 18:06:40 --> Helper loaded: url_helper
INFO - 2020-09-14 18:06:40 --> Database Driver Class Initialized
INFO - 2020-09-14 18:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:06:40 --> Email Class Initialized
INFO - 2020-09-14 18:06:40 --> Controller Class Initialized
INFO - 2020-09-14 18:06:40 --> Model Class Initialized
INFO - 2020-09-14 18:06:40 --> Model Class Initialized
DEBUG - 2020-09-14 18:06:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 18:06:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:06:40 --> Config Class Initialized
INFO - 2020-09-14 18:06:40 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:06:40 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:06:40 --> Utf8 Class Initialized
INFO - 2020-09-14 18:06:40 --> URI Class Initialized
INFO - 2020-09-14 18:06:40 --> Router Class Initialized
INFO - 2020-09-14 18:06:40 --> Output Class Initialized
INFO - 2020-09-14 18:06:40 --> Security Class Initialized
DEBUG - 2020-09-14 18:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:06:40 --> Input Class Initialized
INFO - 2020-09-14 18:06:40 --> Language Class Initialized
INFO - 2020-09-14 18:06:40 --> Loader Class Initialized
INFO - 2020-09-14 18:06:40 --> Helper loaded: url_helper
INFO - 2020-09-14 18:06:40 --> Database Driver Class Initialized
INFO - 2020-09-14 18:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:06:40 --> Email Class Initialized
INFO - 2020-09-14 18:06:40 --> Controller Class Initialized
INFO - 2020-09-14 18:06:40 --> Model Class Initialized
INFO - 2020-09-14 18:06:40 --> Model Class Initialized
DEBUG - 2020-09-14 18:06:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:06:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:06:40 --> Model Class Initialized
INFO - 2020-09-14 18:06:40 --> Final output sent to browser
DEBUG - 2020-09-14 18:06:40 --> Total execution time: 0.0199
ERROR - 2020-09-14 18:06:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:06:40 --> Config Class Initialized
INFO - 2020-09-14 18:06:40 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:06:40 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:06:40 --> Utf8 Class Initialized
INFO - 2020-09-14 18:06:40 --> URI Class Initialized
INFO - 2020-09-14 18:06:40 --> Router Class Initialized
INFO - 2020-09-14 18:06:40 --> Output Class Initialized
INFO - 2020-09-14 18:06:40 --> Security Class Initialized
DEBUG - 2020-09-14 18:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:06:40 --> Input Class Initialized
INFO - 2020-09-14 18:06:40 --> Language Class Initialized
INFO - 2020-09-14 18:06:40 --> Loader Class Initialized
INFO - 2020-09-14 18:06:40 --> Helper loaded: url_helper
INFO - 2020-09-14 18:06:40 --> Database Driver Class Initialized
INFO - 2020-09-14 18:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:06:40 --> Email Class Initialized
INFO - 2020-09-14 18:06:40 --> Controller Class Initialized
DEBUG - 2020-09-14 18:06:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:06:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:06:40 --> Model Class Initialized
INFO - 2020-09-14 18:06:40 --> Model Class Initialized
INFO - 2020-09-14 18:06:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 18:06:40 --> Final output sent to browser
DEBUG - 2020-09-14 18:06:40 --> Total execution time: 0.0215
ERROR - 2020-09-14 18:06:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:06:44 --> Config Class Initialized
INFO - 2020-09-14 18:06:44 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:06:44 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:06:44 --> Utf8 Class Initialized
INFO - 2020-09-14 18:06:44 --> URI Class Initialized
INFO - 2020-09-14 18:06:44 --> Router Class Initialized
INFO - 2020-09-14 18:06:44 --> Output Class Initialized
INFO - 2020-09-14 18:06:44 --> Security Class Initialized
DEBUG - 2020-09-14 18:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:06:44 --> Input Class Initialized
INFO - 2020-09-14 18:06:44 --> Language Class Initialized
INFO - 2020-09-14 18:06:44 --> Loader Class Initialized
INFO - 2020-09-14 18:06:44 --> Helper loaded: url_helper
INFO - 2020-09-14 18:06:44 --> Database Driver Class Initialized
INFO - 2020-09-14 18:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:06:44 --> Email Class Initialized
INFO - 2020-09-14 18:06:44 --> Controller Class Initialized
DEBUG - 2020-09-14 18:06:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:06:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:06:44 --> Model Class Initialized
INFO - 2020-09-14 18:06:44 --> Model Class Initialized
INFO - 2020-09-14 18:06:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 18:06:44 --> Final output sent to browser
DEBUG - 2020-09-14 18:06:44 --> Total execution time: 0.0245
ERROR - 2020-09-14 18:06:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:06:48 --> Config Class Initialized
INFO - 2020-09-14 18:06:48 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:06:48 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:06:48 --> Utf8 Class Initialized
INFO - 2020-09-14 18:06:48 --> URI Class Initialized
INFO - 2020-09-14 18:06:48 --> Router Class Initialized
INFO - 2020-09-14 18:06:48 --> Output Class Initialized
INFO - 2020-09-14 18:06:48 --> Security Class Initialized
DEBUG - 2020-09-14 18:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:06:48 --> Input Class Initialized
INFO - 2020-09-14 18:06:48 --> Language Class Initialized
INFO - 2020-09-14 18:06:48 --> Loader Class Initialized
INFO - 2020-09-14 18:06:48 --> Helper loaded: url_helper
INFO - 2020-09-14 18:06:48 --> Database Driver Class Initialized
INFO - 2020-09-14 18:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:06:48 --> Email Class Initialized
INFO - 2020-09-14 18:06:48 --> Controller Class Initialized
DEBUG - 2020-09-14 18:06:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:06:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:06:48 --> Model Class Initialized
INFO - 2020-09-14 18:06:48 --> Model Class Initialized
INFO - 2020-09-14 18:06:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-09-14 18:06:48 --> Final output sent to browser
DEBUG - 2020-09-14 18:06:48 --> Total execution time: 0.0231
ERROR - 2020-09-14 18:09:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:09:12 --> Config Class Initialized
INFO - 2020-09-14 18:09:12 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:09:12 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:09:12 --> Utf8 Class Initialized
INFO - 2020-09-14 18:09:12 --> URI Class Initialized
INFO - 2020-09-14 18:09:12 --> Router Class Initialized
INFO - 2020-09-14 18:09:12 --> Output Class Initialized
INFO - 2020-09-14 18:09:12 --> Security Class Initialized
DEBUG - 2020-09-14 18:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:09:12 --> Input Class Initialized
INFO - 2020-09-14 18:09:12 --> Language Class Initialized
INFO - 2020-09-14 18:09:12 --> Loader Class Initialized
INFO - 2020-09-14 18:09:12 --> Helper loaded: url_helper
INFO - 2020-09-14 18:09:12 --> Database Driver Class Initialized
INFO - 2020-09-14 18:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:09:12 --> Email Class Initialized
INFO - 2020-09-14 18:09:12 --> Controller Class Initialized
DEBUG - 2020-09-14 18:09:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:09:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:09:12 --> Model Class Initialized
INFO - 2020-09-14 18:09:12 --> Model Class Initialized
INFO - 2020-09-14 18:09:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-09-14 18:09:12 --> Final output sent to browser
DEBUG - 2020-09-14 18:09:12 --> Total execution time: 0.0175
ERROR - 2020-09-14 18:09:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:09:17 --> Config Class Initialized
INFO - 2020-09-14 18:09:17 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:09:17 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:09:17 --> Utf8 Class Initialized
INFO - 2020-09-14 18:09:17 --> URI Class Initialized
INFO - 2020-09-14 18:09:17 --> Router Class Initialized
INFO - 2020-09-14 18:09:17 --> Output Class Initialized
INFO - 2020-09-14 18:09:17 --> Security Class Initialized
DEBUG - 2020-09-14 18:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:09:17 --> Input Class Initialized
INFO - 2020-09-14 18:09:17 --> Language Class Initialized
INFO - 2020-09-14 18:09:17 --> Loader Class Initialized
INFO - 2020-09-14 18:09:17 --> Helper loaded: url_helper
INFO - 2020-09-14 18:09:17 --> Database Driver Class Initialized
INFO - 2020-09-14 18:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:09:17 --> Email Class Initialized
INFO - 2020-09-14 18:09:17 --> Controller Class Initialized
DEBUG - 2020-09-14 18:09:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:09:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:09:17 --> Model Class Initialized
INFO - 2020-09-14 18:09:17 --> Model Class Initialized
INFO - 2020-09-14 18:09:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 18:09:17 --> Final output sent to browser
DEBUG - 2020-09-14 18:09:17 --> Total execution time: 0.0196
ERROR - 2020-09-14 18:09:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:09:20 --> Config Class Initialized
INFO - 2020-09-14 18:09:20 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:09:20 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:09:20 --> Utf8 Class Initialized
INFO - 2020-09-14 18:09:20 --> URI Class Initialized
INFO - 2020-09-14 18:09:20 --> Router Class Initialized
INFO - 2020-09-14 18:09:20 --> Output Class Initialized
INFO - 2020-09-14 18:09:20 --> Security Class Initialized
DEBUG - 2020-09-14 18:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:09:20 --> Input Class Initialized
INFO - 2020-09-14 18:09:20 --> Language Class Initialized
INFO - 2020-09-14 18:09:20 --> Loader Class Initialized
INFO - 2020-09-14 18:09:20 --> Helper loaded: url_helper
INFO - 2020-09-14 18:09:20 --> Database Driver Class Initialized
INFO - 2020-09-14 18:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:09:20 --> Email Class Initialized
INFO - 2020-09-14 18:09:20 --> Controller Class Initialized
DEBUG - 2020-09-14 18:09:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:09:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:09:20 --> Model Class Initialized
INFO - 2020-09-14 18:09:20 --> Model Class Initialized
INFO - 2020-09-14 18:09:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-09-14 18:09:20 --> Final output sent to browser
DEBUG - 2020-09-14 18:09:20 --> Total execution time: 0.0207
ERROR - 2020-09-14 18:09:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:09:37 --> Config Class Initialized
INFO - 2020-09-14 18:09:37 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:09:37 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:09:37 --> Utf8 Class Initialized
INFO - 2020-09-14 18:09:37 --> URI Class Initialized
INFO - 2020-09-14 18:09:37 --> Router Class Initialized
INFO - 2020-09-14 18:09:37 --> Output Class Initialized
INFO - 2020-09-14 18:09:37 --> Security Class Initialized
DEBUG - 2020-09-14 18:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:09:37 --> Input Class Initialized
INFO - 2020-09-14 18:09:37 --> Language Class Initialized
INFO - 2020-09-14 18:09:37 --> Loader Class Initialized
INFO - 2020-09-14 18:09:37 --> Helper loaded: url_helper
INFO - 2020-09-14 18:09:37 --> Database Driver Class Initialized
INFO - 2020-09-14 18:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:09:37 --> Email Class Initialized
INFO - 2020-09-14 18:09:37 --> Controller Class Initialized
DEBUG - 2020-09-14 18:09:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:09:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:09:37 --> Model Class Initialized
INFO - 2020-09-14 18:09:37 --> Model Class Initialized
INFO - 2020-09-14 18:09:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 18:09:37 --> Final output sent to browser
DEBUG - 2020-09-14 18:09:37 --> Total execution time: 0.4212
ERROR - 2020-09-14 18:09:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:09:44 --> Config Class Initialized
INFO - 2020-09-14 18:09:44 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:09:44 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:09:44 --> Utf8 Class Initialized
INFO - 2020-09-14 18:09:44 --> URI Class Initialized
INFO - 2020-09-14 18:09:44 --> Router Class Initialized
INFO - 2020-09-14 18:09:44 --> Output Class Initialized
INFO - 2020-09-14 18:09:44 --> Security Class Initialized
DEBUG - 2020-09-14 18:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:09:44 --> Input Class Initialized
INFO - 2020-09-14 18:09:44 --> Language Class Initialized
INFO - 2020-09-14 18:09:44 --> Loader Class Initialized
INFO - 2020-09-14 18:09:44 --> Helper loaded: url_helper
INFO - 2020-09-14 18:09:44 --> Database Driver Class Initialized
INFO - 2020-09-14 18:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:09:44 --> Email Class Initialized
INFO - 2020-09-14 18:09:44 --> Controller Class Initialized
DEBUG - 2020-09-14 18:09:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:09:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:09:44 --> Model Class Initialized
INFO - 2020-09-14 18:09:44 --> Model Class Initialized
INFO - 2020-09-14 18:09:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-09-14 18:09:44 --> Final output sent to browser
DEBUG - 2020-09-14 18:09:44 --> Total execution time: 0.0224
ERROR - 2020-09-14 18:09:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:09:53 --> Config Class Initialized
INFO - 2020-09-14 18:09:53 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:09:53 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:09:53 --> Utf8 Class Initialized
INFO - 2020-09-14 18:09:53 --> URI Class Initialized
INFO - 2020-09-14 18:09:53 --> Router Class Initialized
INFO - 2020-09-14 18:09:53 --> Output Class Initialized
INFO - 2020-09-14 18:09:53 --> Security Class Initialized
DEBUG - 2020-09-14 18:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:09:53 --> Input Class Initialized
INFO - 2020-09-14 18:09:53 --> Language Class Initialized
INFO - 2020-09-14 18:09:53 --> Loader Class Initialized
INFO - 2020-09-14 18:09:53 --> Helper loaded: url_helper
INFO - 2020-09-14 18:09:53 --> Database Driver Class Initialized
INFO - 2020-09-14 18:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:09:53 --> Email Class Initialized
INFO - 2020-09-14 18:09:53 --> Controller Class Initialized
DEBUG - 2020-09-14 18:09:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:09:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:09:53 --> Model Class Initialized
INFO - 2020-09-14 18:09:53 --> Model Class Initialized
INFO - 2020-09-14 18:09:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 18:09:53 --> Final output sent to browser
DEBUG - 2020-09-14 18:09:53 --> Total execution time: 0.0202
ERROR - 2020-09-14 18:09:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:09:58 --> Config Class Initialized
INFO - 2020-09-14 18:09:58 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:09:58 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:09:58 --> Utf8 Class Initialized
INFO - 2020-09-14 18:09:58 --> URI Class Initialized
INFO - 2020-09-14 18:09:58 --> Router Class Initialized
INFO - 2020-09-14 18:09:58 --> Output Class Initialized
INFO - 2020-09-14 18:09:58 --> Security Class Initialized
DEBUG - 2020-09-14 18:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:09:58 --> Input Class Initialized
INFO - 2020-09-14 18:09:58 --> Language Class Initialized
INFO - 2020-09-14 18:09:58 --> Loader Class Initialized
INFO - 2020-09-14 18:09:58 --> Helper loaded: url_helper
INFO - 2020-09-14 18:09:58 --> Database Driver Class Initialized
INFO - 2020-09-14 18:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:09:58 --> Email Class Initialized
INFO - 2020-09-14 18:09:58 --> Controller Class Initialized
DEBUG - 2020-09-14 18:09:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:09:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:09:58 --> Model Class Initialized
INFO - 2020-09-14 18:09:58 --> Model Class Initialized
INFO - 2020-09-14 18:09:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-09-14 18:09:58 --> Final output sent to browser
DEBUG - 2020-09-14 18:09:58 --> Total execution time: 0.0212
ERROR - 2020-09-14 18:10:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:10:01 --> Config Class Initialized
INFO - 2020-09-14 18:10:01 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:10:01 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:10:01 --> Utf8 Class Initialized
INFO - 2020-09-14 18:10:01 --> URI Class Initialized
INFO - 2020-09-14 18:10:01 --> Router Class Initialized
INFO - 2020-09-14 18:10:01 --> Output Class Initialized
INFO - 2020-09-14 18:10:01 --> Security Class Initialized
DEBUG - 2020-09-14 18:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:10:01 --> Input Class Initialized
INFO - 2020-09-14 18:10:01 --> Language Class Initialized
INFO - 2020-09-14 18:10:01 --> Loader Class Initialized
INFO - 2020-09-14 18:10:01 --> Helper loaded: url_helper
INFO - 2020-09-14 18:10:01 --> Database Driver Class Initialized
INFO - 2020-09-14 18:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:10:01 --> Email Class Initialized
INFO - 2020-09-14 18:10:01 --> Controller Class Initialized
DEBUG - 2020-09-14 18:10:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:10:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:10:01 --> Model Class Initialized
INFO - 2020-09-14 18:10:01 --> Model Class Initialized
INFO - 2020-09-14 18:10:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 18:10:01 --> Final output sent to browser
DEBUG - 2020-09-14 18:10:01 --> Total execution time: 0.0239
ERROR - 2020-09-14 18:10:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:10:13 --> Config Class Initialized
INFO - 2020-09-14 18:10:13 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:10:13 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:10:13 --> Utf8 Class Initialized
INFO - 2020-09-14 18:10:13 --> URI Class Initialized
INFO - 2020-09-14 18:10:13 --> Router Class Initialized
INFO - 2020-09-14 18:10:13 --> Output Class Initialized
INFO - 2020-09-14 18:10:13 --> Security Class Initialized
DEBUG - 2020-09-14 18:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:10:13 --> Input Class Initialized
INFO - 2020-09-14 18:10:13 --> Language Class Initialized
INFO - 2020-09-14 18:10:13 --> Loader Class Initialized
INFO - 2020-09-14 18:10:13 --> Helper loaded: url_helper
INFO - 2020-09-14 18:10:13 --> Database Driver Class Initialized
INFO - 2020-09-14 18:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:10:13 --> Email Class Initialized
INFO - 2020-09-14 18:10:13 --> Controller Class Initialized
DEBUG - 2020-09-14 18:10:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:10:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:10:13 --> Model Class Initialized
INFO - 2020-09-14 18:10:13 --> Model Class Initialized
INFO - 2020-09-14 18:10:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-14 18:10:13 --> Final output sent to browser
DEBUG - 2020-09-14 18:10:13 --> Total execution time: 0.0182
ERROR - 2020-09-14 18:10:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:10:18 --> Config Class Initialized
INFO - 2020-09-14 18:10:18 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:10:18 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:10:18 --> Utf8 Class Initialized
INFO - 2020-09-14 18:10:18 --> URI Class Initialized
INFO - 2020-09-14 18:10:18 --> Router Class Initialized
INFO - 2020-09-14 18:10:18 --> Output Class Initialized
INFO - 2020-09-14 18:10:18 --> Security Class Initialized
DEBUG - 2020-09-14 18:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:10:18 --> Input Class Initialized
INFO - 2020-09-14 18:10:18 --> Language Class Initialized
INFO - 2020-09-14 18:10:18 --> Loader Class Initialized
INFO - 2020-09-14 18:10:18 --> Helper loaded: url_helper
INFO - 2020-09-14 18:10:18 --> Database Driver Class Initialized
INFO - 2020-09-14 18:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:10:18 --> Email Class Initialized
INFO - 2020-09-14 18:10:18 --> Controller Class Initialized
DEBUG - 2020-09-14 18:10:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:10:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:10:18 --> Model Class Initialized
INFO - 2020-09-14 18:10:18 --> Model Class Initialized
INFO - 2020-09-14 18:10:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-14 18:10:18 --> Final output sent to browser
DEBUG - 2020-09-14 18:10:18 --> Total execution time: 0.0229
ERROR - 2020-09-14 18:10:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:10:36 --> Config Class Initialized
INFO - 2020-09-14 18:10:36 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:10:36 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:10:36 --> Utf8 Class Initialized
INFO - 2020-09-14 18:10:36 --> URI Class Initialized
DEBUG - 2020-09-14 18:10:36 --> No URI present. Default controller set.
INFO - 2020-09-14 18:10:36 --> Router Class Initialized
INFO - 2020-09-14 18:10:36 --> Output Class Initialized
INFO - 2020-09-14 18:10:36 --> Security Class Initialized
DEBUG - 2020-09-14 18:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:10:36 --> Input Class Initialized
INFO - 2020-09-14 18:10:36 --> Language Class Initialized
INFO - 2020-09-14 18:10:36 --> Loader Class Initialized
INFO - 2020-09-14 18:10:36 --> Helper loaded: url_helper
INFO - 2020-09-14 18:10:36 --> Database Driver Class Initialized
INFO - 2020-09-14 18:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:10:36 --> Email Class Initialized
INFO - 2020-09-14 18:10:36 --> Controller Class Initialized
INFO - 2020-09-14 18:10:36 --> Model Class Initialized
INFO - 2020-09-14 18:10:36 --> Model Class Initialized
DEBUG - 2020-09-14 18:10:36 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:10:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-14 18:10:36 --> Final output sent to browser
DEBUG - 2020-09-14 18:10:36 --> Total execution time: 0.0201
ERROR - 2020-09-14 18:10:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:10:46 --> Config Class Initialized
INFO - 2020-09-14 18:10:46 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:10:46 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:10:46 --> Utf8 Class Initialized
INFO - 2020-09-14 18:10:46 --> URI Class Initialized
INFO - 2020-09-14 18:10:46 --> Router Class Initialized
INFO - 2020-09-14 18:10:46 --> Output Class Initialized
INFO - 2020-09-14 18:10:46 --> Security Class Initialized
DEBUG - 2020-09-14 18:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:10:46 --> Input Class Initialized
INFO - 2020-09-14 18:10:46 --> Language Class Initialized
INFO - 2020-09-14 18:10:46 --> Loader Class Initialized
INFO - 2020-09-14 18:10:46 --> Helper loaded: url_helper
INFO - 2020-09-14 18:10:46 --> Database Driver Class Initialized
INFO - 2020-09-14 18:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:10:46 --> Email Class Initialized
INFO - 2020-09-14 18:10:46 --> Controller Class Initialized
INFO - 2020-09-14 18:10:46 --> Model Class Initialized
INFO - 2020-09-14 18:10:46 --> Model Class Initialized
DEBUG - 2020-09-14 18:10:46 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 18:10:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:10:47 --> Config Class Initialized
INFO - 2020-09-14 18:10:47 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:10:47 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:10:47 --> Utf8 Class Initialized
INFO - 2020-09-14 18:10:47 --> URI Class Initialized
INFO - 2020-09-14 18:10:47 --> Router Class Initialized
INFO - 2020-09-14 18:10:47 --> Output Class Initialized
INFO - 2020-09-14 18:10:47 --> Security Class Initialized
DEBUG - 2020-09-14 18:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:10:47 --> Input Class Initialized
INFO - 2020-09-14 18:10:47 --> Language Class Initialized
INFO - 2020-09-14 18:10:47 --> Loader Class Initialized
INFO - 2020-09-14 18:10:47 --> Helper loaded: url_helper
INFO - 2020-09-14 18:10:47 --> Database Driver Class Initialized
INFO - 2020-09-14 18:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:10:47 --> Email Class Initialized
INFO - 2020-09-14 18:10:47 --> Controller Class Initialized
INFO - 2020-09-14 18:10:47 --> Model Class Initialized
INFO - 2020-09-14 18:10:47 --> Model Class Initialized
DEBUG - 2020-09-14 18:10:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:10:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:10:47 --> Model Class Initialized
INFO - 2020-09-14 18:10:47 --> Final output sent to browser
DEBUG - 2020-09-14 18:10:47 --> Total execution time: 0.0197
ERROR - 2020-09-14 18:10:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:10:47 --> Config Class Initialized
INFO - 2020-09-14 18:10:47 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:10:47 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:10:47 --> Utf8 Class Initialized
INFO - 2020-09-14 18:10:47 --> URI Class Initialized
INFO - 2020-09-14 18:10:47 --> Router Class Initialized
INFO - 2020-09-14 18:10:47 --> Output Class Initialized
INFO - 2020-09-14 18:10:47 --> Security Class Initialized
DEBUG - 2020-09-14 18:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:10:47 --> Input Class Initialized
INFO - 2020-09-14 18:10:47 --> Language Class Initialized
INFO - 2020-09-14 18:10:47 --> Loader Class Initialized
INFO - 2020-09-14 18:10:47 --> Helper loaded: url_helper
INFO - 2020-09-14 18:10:47 --> Database Driver Class Initialized
INFO - 2020-09-14 18:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:10:47 --> Email Class Initialized
INFO - 2020-09-14 18:10:47 --> Controller Class Initialized
DEBUG - 2020-09-14 18:10:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:10:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:10:47 --> Model Class Initialized
INFO - 2020-09-14 18:10:47 --> Model Class Initialized
INFO - 2020-09-14 18:10:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 18:10:47 --> Final output sent to browser
DEBUG - 2020-09-14 18:10:47 --> Total execution time: 0.0214
ERROR - 2020-09-14 18:10:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:10:51 --> Config Class Initialized
INFO - 2020-09-14 18:10:51 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:10:51 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:10:51 --> Utf8 Class Initialized
INFO - 2020-09-14 18:10:51 --> URI Class Initialized
INFO - 2020-09-14 18:10:51 --> Router Class Initialized
INFO - 2020-09-14 18:10:51 --> Output Class Initialized
INFO - 2020-09-14 18:10:51 --> Security Class Initialized
DEBUG - 2020-09-14 18:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:10:51 --> Input Class Initialized
INFO - 2020-09-14 18:10:51 --> Language Class Initialized
INFO - 2020-09-14 18:10:51 --> Loader Class Initialized
INFO - 2020-09-14 18:10:51 --> Helper loaded: url_helper
INFO - 2020-09-14 18:10:51 --> Database Driver Class Initialized
INFO - 2020-09-14 18:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:10:51 --> Email Class Initialized
INFO - 2020-09-14 18:10:51 --> Controller Class Initialized
DEBUG - 2020-09-14 18:10:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:10:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:10:51 --> Model Class Initialized
INFO - 2020-09-14 18:10:51 --> Model Class Initialized
INFO - 2020-09-14 18:10:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-14 18:10:51 --> Final output sent to browser
DEBUG - 2020-09-14 18:10:51 --> Total execution time: 0.0225
ERROR - 2020-09-14 18:11:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:11:13 --> Config Class Initialized
INFO - 2020-09-14 18:11:13 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:11:13 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:11:13 --> Utf8 Class Initialized
INFO - 2020-09-14 18:11:13 --> URI Class Initialized
INFO - 2020-09-14 18:11:13 --> Router Class Initialized
INFO - 2020-09-14 18:11:13 --> Output Class Initialized
INFO - 2020-09-14 18:11:13 --> Security Class Initialized
DEBUG - 2020-09-14 18:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:11:13 --> Input Class Initialized
INFO - 2020-09-14 18:11:13 --> Language Class Initialized
INFO - 2020-09-14 18:11:13 --> Loader Class Initialized
INFO - 2020-09-14 18:11:13 --> Helper loaded: url_helper
INFO - 2020-09-14 18:11:13 --> Database Driver Class Initialized
INFO - 2020-09-14 18:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:11:13 --> Email Class Initialized
INFO - 2020-09-14 18:11:13 --> Controller Class Initialized
DEBUG - 2020-09-14 18:11:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:11:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:11:13 --> Model Class Initialized
INFO - 2020-09-14 18:11:13 --> Model Class Initialized
INFO - 2020-09-14 18:11:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 18:11:13 --> Final output sent to browser
DEBUG - 2020-09-14 18:11:13 --> Total execution time: 0.0256
ERROR - 2020-09-14 18:11:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:11:16 --> Config Class Initialized
INFO - 2020-09-14 18:11:16 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:11:16 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:11:16 --> Utf8 Class Initialized
INFO - 2020-09-14 18:11:16 --> URI Class Initialized
INFO - 2020-09-14 18:11:16 --> Router Class Initialized
INFO - 2020-09-14 18:11:16 --> Output Class Initialized
INFO - 2020-09-14 18:11:16 --> Security Class Initialized
DEBUG - 2020-09-14 18:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:11:16 --> Input Class Initialized
INFO - 2020-09-14 18:11:16 --> Language Class Initialized
INFO - 2020-09-14 18:11:16 --> Loader Class Initialized
INFO - 2020-09-14 18:11:16 --> Helper loaded: url_helper
INFO - 2020-09-14 18:11:16 --> Database Driver Class Initialized
INFO - 2020-09-14 18:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:11:16 --> Email Class Initialized
INFO - 2020-09-14 18:11:16 --> Controller Class Initialized
DEBUG - 2020-09-14 18:11:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:11:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:11:16 --> Model Class Initialized
INFO - 2020-09-14 18:11:16 --> Model Class Initialized
INFO - 2020-09-14 18:11:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-14 18:11:16 --> Final output sent to browser
DEBUG - 2020-09-14 18:11:16 --> Total execution time: 0.0236
ERROR - 2020-09-14 18:11:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:11:21 --> Config Class Initialized
INFO - 2020-09-14 18:11:21 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:11:21 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:11:21 --> Utf8 Class Initialized
INFO - 2020-09-14 18:11:21 --> URI Class Initialized
INFO - 2020-09-14 18:11:21 --> Router Class Initialized
INFO - 2020-09-14 18:11:21 --> Output Class Initialized
INFO - 2020-09-14 18:11:21 --> Security Class Initialized
DEBUG - 2020-09-14 18:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:11:21 --> Input Class Initialized
INFO - 2020-09-14 18:11:21 --> Language Class Initialized
INFO - 2020-09-14 18:11:21 --> Loader Class Initialized
INFO - 2020-09-14 18:11:21 --> Helper loaded: url_helper
INFO - 2020-09-14 18:11:21 --> Database Driver Class Initialized
INFO - 2020-09-14 18:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:11:21 --> Email Class Initialized
INFO - 2020-09-14 18:11:21 --> Controller Class Initialized
DEBUG - 2020-09-14 18:11:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:11:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:11:21 --> Model Class Initialized
INFO - 2020-09-14 18:11:21 --> Model Class Initialized
INFO - 2020-09-14 18:11:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 18:11:21 --> Final output sent to browser
DEBUG - 2020-09-14 18:11:21 --> Total execution time: 0.0210
ERROR - 2020-09-14 18:11:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:11:38 --> Config Class Initialized
INFO - 2020-09-14 18:11:38 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:11:38 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:11:38 --> Utf8 Class Initialized
INFO - 2020-09-14 18:11:38 --> URI Class Initialized
INFO - 2020-09-14 18:11:38 --> Router Class Initialized
INFO - 2020-09-14 18:11:38 --> Output Class Initialized
INFO - 2020-09-14 18:11:38 --> Security Class Initialized
DEBUG - 2020-09-14 18:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:11:38 --> Input Class Initialized
INFO - 2020-09-14 18:11:38 --> Language Class Initialized
INFO - 2020-09-14 18:11:38 --> Loader Class Initialized
INFO - 2020-09-14 18:11:38 --> Helper loaded: url_helper
INFO - 2020-09-14 18:11:38 --> Database Driver Class Initialized
INFO - 2020-09-14 18:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:11:38 --> Email Class Initialized
INFO - 2020-09-14 18:11:38 --> Controller Class Initialized
DEBUG - 2020-09-14 18:11:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:11:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:11:38 --> Model Class Initialized
INFO - 2020-09-14 18:11:38 --> Model Class Initialized
INFO - 2020-09-14 18:11:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 18:11:38 --> Final output sent to browser
DEBUG - 2020-09-14 18:11:38 --> Total execution time: 0.0232
ERROR - 2020-09-14 18:11:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:11:42 --> Config Class Initialized
INFO - 2020-09-14 18:11:42 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:11:42 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:11:42 --> Utf8 Class Initialized
INFO - 2020-09-14 18:11:42 --> URI Class Initialized
INFO - 2020-09-14 18:11:42 --> Router Class Initialized
INFO - 2020-09-14 18:11:42 --> Output Class Initialized
INFO - 2020-09-14 18:11:42 --> Security Class Initialized
DEBUG - 2020-09-14 18:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:11:42 --> Input Class Initialized
INFO - 2020-09-14 18:11:42 --> Language Class Initialized
INFO - 2020-09-14 18:11:42 --> Loader Class Initialized
INFO - 2020-09-14 18:11:42 --> Helper loaded: url_helper
INFO - 2020-09-14 18:11:42 --> Database Driver Class Initialized
INFO - 2020-09-14 18:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:11:42 --> Email Class Initialized
INFO - 2020-09-14 18:11:42 --> Controller Class Initialized
DEBUG - 2020-09-14 18:11:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:11:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:11:42 --> Model Class Initialized
INFO - 2020-09-14 18:11:42 --> Model Class Initialized
INFO - 2020-09-14 18:11:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-14 18:11:42 --> Final output sent to browser
DEBUG - 2020-09-14 18:11:42 --> Total execution time: 0.0212
ERROR - 2020-09-14 18:11:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:11:45 --> Config Class Initialized
INFO - 2020-09-14 18:11:45 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:11:45 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:11:45 --> Utf8 Class Initialized
INFO - 2020-09-14 18:11:45 --> URI Class Initialized
INFO - 2020-09-14 18:11:45 --> Router Class Initialized
INFO - 2020-09-14 18:11:45 --> Output Class Initialized
INFO - 2020-09-14 18:11:45 --> Security Class Initialized
DEBUG - 2020-09-14 18:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:11:45 --> Input Class Initialized
INFO - 2020-09-14 18:11:45 --> Language Class Initialized
INFO - 2020-09-14 18:11:45 --> Loader Class Initialized
INFO - 2020-09-14 18:11:45 --> Helper loaded: url_helper
INFO - 2020-09-14 18:11:45 --> Database Driver Class Initialized
INFO - 2020-09-14 18:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:11:45 --> Email Class Initialized
INFO - 2020-09-14 18:11:45 --> Controller Class Initialized
DEBUG - 2020-09-14 18:11:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:11:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:11:45 --> Model Class Initialized
INFO - 2020-09-14 18:11:45 --> Model Class Initialized
INFO - 2020-09-14 18:11:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 18:11:45 --> Final output sent to browser
DEBUG - 2020-09-14 18:11:45 --> Total execution time: 0.0247
ERROR - 2020-09-14 18:11:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:11:48 --> Config Class Initialized
INFO - 2020-09-14 18:11:48 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:11:48 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:11:48 --> Utf8 Class Initialized
INFO - 2020-09-14 18:11:48 --> URI Class Initialized
INFO - 2020-09-14 18:11:48 --> Router Class Initialized
INFO - 2020-09-14 18:11:48 --> Output Class Initialized
INFO - 2020-09-14 18:11:48 --> Security Class Initialized
DEBUG - 2020-09-14 18:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:11:48 --> Input Class Initialized
INFO - 2020-09-14 18:11:48 --> Language Class Initialized
INFO - 2020-09-14 18:11:48 --> Loader Class Initialized
INFO - 2020-09-14 18:11:48 --> Helper loaded: url_helper
INFO - 2020-09-14 18:11:48 --> Database Driver Class Initialized
INFO - 2020-09-14 18:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:11:48 --> Email Class Initialized
INFO - 2020-09-14 18:11:48 --> Controller Class Initialized
DEBUG - 2020-09-14 18:11:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:11:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:11:48 --> Model Class Initialized
INFO - 2020-09-14 18:11:48 --> Model Class Initialized
INFO - 2020-09-14 18:11:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_view.php
INFO - 2020-09-14 18:11:48 --> Final output sent to browser
DEBUG - 2020-09-14 18:11:48 --> Total execution time: 0.0224
ERROR - 2020-09-14 18:11:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:11:51 --> Config Class Initialized
INFO - 2020-09-14 18:11:51 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:11:51 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:11:51 --> Utf8 Class Initialized
INFO - 2020-09-14 18:11:51 --> URI Class Initialized
INFO - 2020-09-14 18:11:51 --> Router Class Initialized
INFO - 2020-09-14 18:11:51 --> Output Class Initialized
INFO - 2020-09-14 18:11:51 --> Security Class Initialized
DEBUG - 2020-09-14 18:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:11:51 --> Input Class Initialized
INFO - 2020-09-14 18:11:51 --> Language Class Initialized
INFO - 2020-09-14 18:11:51 --> Loader Class Initialized
INFO - 2020-09-14 18:11:51 --> Helper loaded: url_helper
INFO - 2020-09-14 18:11:51 --> Database Driver Class Initialized
INFO - 2020-09-14 18:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:11:51 --> Email Class Initialized
INFO - 2020-09-14 18:11:51 --> Controller Class Initialized
DEBUG - 2020-09-14 18:11:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:11:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:11:51 --> Model Class Initialized
INFO - 2020-09-14 18:11:51 --> Model Class Initialized
INFO - 2020-09-14 18:11:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-14 18:11:51 --> Final output sent to browser
DEBUG - 2020-09-14 18:11:51 --> Total execution time: 0.0317
ERROR - 2020-09-14 18:11:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:11:56 --> Config Class Initialized
INFO - 2020-09-14 18:11:56 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:11:56 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:11:56 --> Utf8 Class Initialized
INFO - 2020-09-14 18:11:56 --> URI Class Initialized
INFO - 2020-09-14 18:11:56 --> Router Class Initialized
INFO - 2020-09-14 18:11:56 --> Output Class Initialized
INFO - 2020-09-14 18:11:56 --> Security Class Initialized
DEBUG - 2020-09-14 18:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:11:56 --> Input Class Initialized
INFO - 2020-09-14 18:11:56 --> Language Class Initialized
INFO - 2020-09-14 18:11:56 --> Loader Class Initialized
INFO - 2020-09-14 18:11:56 --> Helper loaded: url_helper
INFO - 2020-09-14 18:11:56 --> Database Driver Class Initialized
INFO - 2020-09-14 18:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:11:56 --> Email Class Initialized
INFO - 2020-09-14 18:11:56 --> Controller Class Initialized
DEBUG - 2020-09-14 18:11:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:11:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:11:56 --> Model Class Initialized
INFO - 2020-09-14 18:11:56 --> Model Class Initialized
INFO - 2020-09-14 18:11:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 18:11:56 --> Final output sent to browser
DEBUG - 2020-09-14 18:11:56 --> Total execution time: 0.0211
ERROR - 2020-09-14 18:11:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:11:58 --> Config Class Initialized
INFO - 2020-09-14 18:11:58 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:11:58 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:11:58 --> Utf8 Class Initialized
INFO - 2020-09-14 18:11:58 --> URI Class Initialized
INFO - 2020-09-14 18:11:58 --> Router Class Initialized
INFO - 2020-09-14 18:11:58 --> Output Class Initialized
INFO - 2020-09-14 18:11:58 --> Security Class Initialized
DEBUG - 2020-09-14 18:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:11:58 --> Input Class Initialized
INFO - 2020-09-14 18:11:58 --> Language Class Initialized
INFO - 2020-09-14 18:11:58 --> Loader Class Initialized
INFO - 2020-09-14 18:11:58 --> Helper loaded: url_helper
INFO - 2020-09-14 18:11:58 --> Database Driver Class Initialized
INFO - 2020-09-14 18:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:11:58 --> Email Class Initialized
INFO - 2020-09-14 18:11:58 --> Controller Class Initialized
DEBUG - 2020-09-14 18:11:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:11:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:11:58 --> Model Class Initialized
INFO - 2020-09-14 18:11:58 --> Model Class Initialized
INFO - 2020-09-14 18:11:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-09-14 18:11:58 --> Final output sent to browser
DEBUG - 2020-09-14 18:11:58 --> Total execution time: 0.0251
ERROR - 2020-09-14 18:12:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:12:01 --> Config Class Initialized
INFO - 2020-09-14 18:12:01 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:12:01 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:12:01 --> Utf8 Class Initialized
INFO - 2020-09-14 18:12:01 --> URI Class Initialized
INFO - 2020-09-14 18:12:01 --> Router Class Initialized
INFO - 2020-09-14 18:12:01 --> Output Class Initialized
INFO - 2020-09-14 18:12:01 --> Security Class Initialized
DEBUG - 2020-09-14 18:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:12:01 --> Input Class Initialized
INFO - 2020-09-14 18:12:01 --> Language Class Initialized
INFO - 2020-09-14 18:12:01 --> Loader Class Initialized
INFO - 2020-09-14 18:12:01 --> Helper loaded: url_helper
INFO - 2020-09-14 18:12:01 --> Database Driver Class Initialized
INFO - 2020-09-14 18:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:12:01 --> Email Class Initialized
INFO - 2020-09-14 18:12:01 --> Controller Class Initialized
DEBUG - 2020-09-14 18:12:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:12:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:12:01 --> Model Class Initialized
INFO - 2020-09-14 18:12:01 --> Model Class Initialized
INFO - 2020-09-14 18:12:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-14 18:12:01 --> Final output sent to browser
DEBUG - 2020-09-14 18:12:01 --> Total execution time: 0.0244
ERROR - 2020-09-14 18:12:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:12:05 --> Config Class Initialized
INFO - 2020-09-14 18:12:05 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:12:05 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:12:05 --> Utf8 Class Initialized
INFO - 2020-09-14 18:12:05 --> URI Class Initialized
DEBUG - 2020-09-14 18:12:05 --> No URI present. Default controller set.
INFO - 2020-09-14 18:12:05 --> Router Class Initialized
INFO - 2020-09-14 18:12:05 --> Output Class Initialized
INFO - 2020-09-14 18:12:05 --> Security Class Initialized
DEBUG - 2020-09-14 18:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:12:05 --> Input Class Initialized
INFO - 2020-09-14 18:12:05 --> Language Class Initialized
INFO - 2020-09-14 18:12:05 --> Loader Class Initialized
INFO - 2020-09-14 18:12:05 --> Helper loaded: url_helper
INFO - 2020-09-14 18:12:05 --> Database Driver Class Initialized
INFO - 2020-09-14 18:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:12:05 --> Email Class Initialized
INFO - 2020-09-14 18:12:05 --> Controller Class Initialized
INFO - 2020-09-14 18:12:05 --> Model Class Initialized
INFO - 2020-09-14 18:12:05 --> Model Class Initialized
DEBUG - 2020-09-14 18:12:05 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:12:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-14 18:12:05 --> Final output sent to browser
DEBUG - 2020-09-14 18:12:05 --> Total execution time: 0.0184
ERROR - 2020-09-14 18:12:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:12:19 --> Config Class Initialized
INFO - 2020-09-14 18:12:19 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:12:19 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:12:19 --> Utf8 Class Initialized
INFO - 2020-09-14 18:12:19 --> URI Class Initialized
INFO - 2020-09-14 18:12:19 --> Router Class Initialized
INFO - 2020-09-14 18:12:19 --> Output Class Initialized
INFO - 2020-09-14 18:12:19 --> Security Class Initialized
DEBUG - 2020-09-14 18:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:12:19 --> Input Class Initialized
INFO - 2020-09-14 18:12:19 --> Language Class Initialized
INFO - 2020-09-14 18:12:19 --> Loader Class Initialized
INFO - 2020-09-14 18:12:19 --> Helper loaded: url_helper
INFO - 2020-09-14 18:12:19 --> Database Driver Class Initialized
INFO - 2020-09-14 18:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:12:19 --> Email Class Initialized
INFO - 2020-09-14 18:12:19 --> Controller Class Initialized
INFO - 2020-09-14 18:12:19 --> Model Class Initialized
INFO - 2020-09-14 18:12:19 --> Model Class Initialized
DEBUG - 2020-09-14 18:12:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:12:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:12:19 --> Model Class Initialized
INFO - 2020-09-14 18:12:19 --> Final output sent to browser
DEBUG - 2020-09-14 18:12:19 --> Total execution time: 0.0242
ERROR - 2020-09-14 18:12:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:12:19 --> Config Class Initialized
INFO - 2020-09-14 18:12:19 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:12:19 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:12:19 --> Utf8 Class Initialized
INFO - 2020-09-14 18:12:19 --> URI Class Initialized
INFO - 2020-09-14 18:12:19 --> Router Class Initialized
INFO - 2020-09-14 18:12:19 --> Output Class Initialized
INFO - 2020-09-14 18:12:19 --> Security Class Initialized
DEBUG - 2020-09-14 18:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:12:19 --> Input Class Initialized
INFO - 2020-09-14 18:12:19 --> Language Class Initialized
INFO - 2020-09-14 18:12:19 --> Loader Class Initialized
INFO - 2020-09-14 18:12:19 --> Helper loaded: url_helper
INFO - 2020-09-14 18:12:19 --> Database Driver Class Initialized
INFO - 2020-09-14 18:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:12:19 --> Email Class Initialized
INFO - 2020-09-14 18:12:19 --> Controller Class Initialized
INFO - 2020-09-14 18:12:19 --> Model Class Initialized
INFO - 2020-09-14 18:12:19 --> Model Class Initialized
DEBUG - 2020-09-14 18:12:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 18:12:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:12:19 --> Config Class Initialized
INFO - 2020-09-14 18:12:19 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:12:19 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:12:19 --> Utf8 Class Initialized
INFO - 2020-09-14 18:12:19 --> URI Class Initialized
INFO - 2020-09-14 18:12:19 --> Router Class Initialized
INFO - 2020-09-14 18:12:19 --> Output Class Initialized
INFO - 2020-09-14 18:12:19 --> Security Class Initialized
DEBUG - 2020-09-14 18:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:12:19 --> Input Class Initialized
INFO - 2020-09-14 18:12:19 --> Language Class Initialized
INFO - 2020-09-14 18:12:19 --> Loader Class Initialized
INFO - 2020-09-14 18:12:19 --> Helper loaded: url_helper
INFO - 2020-09-14 18:12:19 --> Database Driver Class Initialized
INFO - 2020-09-14 18:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:12:19 --> Email Class Initialized
INFO - 2020-09-14 18:12:19 --> Controller Class Initialized
DEBUG - 2020-09-14 18:12:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:12:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:12:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-14 18:12:19 --> Final output sent to browser
DEBUG - 2020-09-14 18:12:19 --> Total execution time: 0.0204
ERROR - 2020-09-14 18:12:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:12:26 --> Config Class Initialized
INFO - 2020-09-14 18:12:26 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:12:26 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:12:26 --> Utf8 Class Initialized
INFO - 2020-09-14 18:12:26 --> URI Class Initialized
INFO - 2020-09-14 18:12:26 --> Router Class Initialized
INFO - 2020-09-14 18:12:26 --> Output Class Initialized
INFO - 2020-09-14 18:12:26 --> Security Class Initialized
DEBUG - 2020-09-14 18:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:12:26 --> Input Class Initialized
INFO - 2020-09-14 18:12:26 --> Language Class Initialized
INFO - 2020-09-14 18:12:26 --> Loader Class Initialized
INFO - 2020-09-14 18:12:26 --> Helper loaded: url_helper
INFO - 2020-09-14 18:12:26 --> Database Driver Class Initialized
INFO - 2020-09-14 18:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:12:26 --> Email Class Initialized
INFO - 2020-09-14 18:12:26 --> Controller Class Initialized
DEBUG - 2020-09-14 18:12:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:12:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:12:26 --> Model Class Initialized
INFO - 2020-09-14 18:12:26 --> Model Class Initialized
INFO - 2020-09-14 18:12:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-14 18:12:26 --> Final output sent to browser
DEBUG - 2020-09-14 18:12:26 --> Total execution time: 0.0246
ERROR - 2020-09-14 18:12:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:12:29 --> Config Class Initialized
INFO - 2020-09-14 18:12:29 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:12:29 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:12:29 --> Utf8 Class Initialized
INFO - 2020-09-14 18:12:29 --> URI Class Initialized
INFO - 2020-09-14 18:12:29 --> Router Class Initialized
INFO - 2020-09-14 18:12:29 --> Output Class Initialized
INFO - 2020-09-14 18:12:29 --> Security Class Initialized
DEBUG - 2020-09-14 18:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:12:29 --> Input Class Initialized
INFO - 2020-09-14 18:12:29 --> Language Class Initialized
INFO - 2020-09-14 18:12:29 --> Loader Class Initialized
INFO - 2020-09-14 18:12:29 --> Helper loaded: url_helper
INFO - 2020-09-14 18:12:29 --> Database Driver Class Initialized
INFO - 2020-09-14 18:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:12:30 --> Email Class Initialized
INFO - 2020-09-14 18:12:30 --> Controller Class Initialized
DEBUG - 2020-09-14 18:12:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:12:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:12:30 --> Model Class Initialized
INFO - 2020-09-14 18:12:30 --> Model Class Initialized
INFO - 2020-09-14 18:12:30 --> Model Class Initialized
INFO - 2020-09-14 18:12:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-09-14 18:12:30 --> Final output sent to browser
DEBUG - 2020-09-14 18:12:30 --> Total execution time: 0.0266
ERROR - 2020-09-14 18:14:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:14:44 --> Config Class Initialized
INFO - 2020-09-14 18:14:44 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:14:44 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:14:44 --> Utf8 Class Initialized
INFO - 2020-09-14 18:14:44 --> URI Class Initialized
INFO - 2020-09-14 18:14:44 --> Router Class Initialized
INFO - 2020-09-14 18:14:44 --> Output Class Initialized
INFO - 2020-09-14 18:14:44 --> Security Class Initialized
DEBUG - 2020-09-14 18:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:14:44 --> Input Class Initialized
INFO - 2020-09-14 18:14:44 --> Language Class Initialized
INFO - 2020-09-14 18:14:44 --> Loader Class Initialized
INFO - 2020-09-14 18:14:44 --> Helper loaded: url_helper
INFO - 2020-09-14 18:14:44 --> Database Driver Class Initialized
INFO - 2020-09-14 18:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:14:44 --> Email Class Initialized
INFO - 2020-09-14 18:14:44 --> Controller Class Initialized
INFO - 2020-09-14 18:14:44 --> Model Class Initialized
INFO - 2020-09-14 18:14:44 --> Model Class Initialized
INFO - 2020-09-14 18:14:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-14 18:14:44 --> Final output sent to browser
DEBUG - 2020-09-14 18:14:44 --> Total execution time: 0.0434
ERROR - 2020-09-14 18:14:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:14:45 --> Config Class Initialized
INFO - 2020-09-14 18:14:45 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:14:45 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:14:45 --> Utf8 Class Initialized
INFO - 2020-09-14 18:14:45 --> URI Class Initialized
INFO - 2020-09-14 18:14:45 --> Router Class Initialized
INFO - 2020-09-14 18:14:45 --> Output Class Initialized
INFO - 2020-09-14 18:14:45 --> Security Class Initialized
DEBUG - 2020-09-14 18:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:14:45 --> Input Class Initialized
INFO - 2020-09-14 18:14:45 --> Language Class Initialized
INFO - 2020-09-14 18:14:45 --> Loader Class Initialized
INFO - 2020-09-14 18:14:45 --> Helper loaded: url_helper
INFO - 2020-09-14 18:14:45 --> Database Driver Class Initialized
INFO - 2020-09-14 18:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:14:45 --> Email Class Initialized
INFO - 2020-09-14 18:14:45 --> Controller Class Initialized
INFO - 2020-09-14 18:14:45 --> Model Class Initialized
INFO - 2020-09-14 18:14:45 --> Model Class Initialized
INFO - 2020-09-14 18:14:45 --> Final output sent to browser
DEBUG - 2020-09-14 18:14:45 --> Total execution time: 0.0465
ERROR - 2020-09-14 18:14:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:14:52 --> Config Class Initialized
INFO - 2020-09-14 18:14:52 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:14:52 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:14:52 --> Utf8 Class Initialized
INFO - 2020-09-14 18:14:52 --> URI Class Initialized
INFO - 2020-09-14 18:14:52 --> Router Class Initialized
INFO - 2020-09-14 18:14:52 --> Output Class Initialized
INFO - 2020-09-14 18:14:52 --> Security Class Initialized
DEBUG - 2020-09-14 18:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:14:52 --> Input Class Initialized
INFO - 2020-09-14 18:14:52 --> Language Class Initialized
INFO - 2020-09-14 18:14:52 --> Loader Class Initialized
INFO - 2020-09-14 18:14:52 --> Helper loaded: url_helper
INFO - 2020-09-14 18:14:52 --> Database Driver Class Initialized
INFO - 2020-09-14 18:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:14:52 --> Email Class Initialized
INFO - 2020-09-14 18:14:52 --> Controller Class Initialized
INFO - 2020-09-14 18:14:52 --> Model Class Initialized
INFO - 2020-09-14 18:14:52 --> Model Class Initialized
INFO - 2020-09-14 18:14:52 --> Final output sent to browser
DEBUG - 2020-09-14 18:14:52 --> Total execution time: 0.1435
ERROR - 2020-09-14 18:14:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:14:52 --> Config Class Initialized
INFO - 2020-09-14 18:14:52 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:14:52 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:14:52 --> Utf8 Class Initialized
INFO - 2020-09-14 18:14:52 --> URI Class Initialized
INFO - 2020-09-14 18:14:52 --> Router Class Initialized
INFO - 2020-09-14 18:14:52 --> Output Class Initialized
INFO - 2020-09-14 18:14:52 --> Security Class Initialized
DEBUG - 2020-09-14 18:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:14:52 --> Input Class Initialized
INFO - 2020-09-14 18:14:52 --> Language Class Initialized
INFO - 2020-09-14 18:14:52 --> Loader Class Initialized
INFO - 2020-09-14 18:14:52 --> Helper loaded: url_helper
INFO - 2020-09-14 18:14:52 --> Database Driver Class Initialized
INFO - 2020-09-14 18:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:14:52 --> Email Class Initialized
INFO - 2020-09-14 18:14:52 --> Controller Class Initialized
INFO - 2020-09-14 18:14:52 --> Model Class Initialized
INFO - 2020-09-14 18:14:52 --> Model Class Initialized
INFO - 2020-09-14 18:14:52 --> Final output sent to browser
DEBUG - 2020-09-14 18:14:52 --> Total execution time: 0.0405
ERROR - 2020-09-14 18:15:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:15:16 --> Config Class Initialized
INFO - 2020-09-14 18:15:16 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:15:16 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:15:16 --> Utf8 Class Initialized
INFO - 2020-09-14 18:15:16 --> URI Class Initialized
INFO - 2020-09-14 18:15:16 --> Router Class Initialized
INFO - 2020-09-14 18:15:16 --> Output Class Initialized
INFO - 2020-09-14 18:15:16 --> Security Class Initialized
DEBUG - 2020-09-14 18:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:15:16 --> Input Class Initialized
INFO - 2020-09-14 18:15:16 --> Language Class Initialized
INFO - 2020-09-14 18:15:16 --> Loader Class Initialized
INFO - 2020-09-14 18:15:16 --> Helper loaded: url_helper
INFO - 2020-09-14 18:15:16 --> Database Driver Class Initialized
INFO - 2020-09-14 18:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:15:16 --> Email Class Initialized
INFO - 2020-09-14 18:15:16 --> Controller Class Initialized
INFO - 2020-09-14 18:15:16 --> Model Class Initialized
INFO - 2020-09-14 18:15:16 --> Model Class Initialized
INFO - 2020-09-14 18:15:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-14 18:15:16 --> Final output sent to browser
DEBUG - 2020-09-14 18:15:16 --> Total execution time: 0.0896
ERROR - 2020-09-14 18:15:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:15:17 --> Config Class Initialized
INFO - 2020-09-14 18:15:17 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:15:17 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:15:17 --> Utf8 Class Initialized
INFO - 2020-09-14 18:15:17 --> URI Class Initialized
INFO - 2020-09-14 18:15:17 --> Router Class Initialized
INFO - 2020-09-14 18:15:17 --> Output Class Initialized
INFO - 2020-09-14 18:15:17 --> Security Class Initialized
DEBUG - 2020-09-14 18:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:15:17 --> Input Class Initialized
INFO - 2020-09-14 18:15:17 --> Language Class Initialized
INFO - 2020-09-14 18:15:17 --> Loader Class Initialized
INFO - 2020-09-14 18:15:17 --> Helper loaded: url_helper
INFO - 2020-09-14 18:15:17 --> Database Driver Class Initialized
INFO - 2020-09-14 18:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:15:17 --> Email Class Initialized
INFO - 2020-09-14 18:15:17 --> Controller Class Initialized
INFO - 2020-09-14 18:15:17 --> Model Class Initialized
INFO - 2020-09-14 18:15:17 --> Model Class Initialized
INFO - 2020-09-14 18:15:17 --> Final output sent to browser
DEBUG - 2020-09-14 18:15:17 --> Total execution time: 0.0389
ERROR - 2020-09-14 18:15:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:15:47 --> Config Class Initialized
INFO - 2020-09-14 18:15:47 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:15:47 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:15:47 --> Utf8 Class Initialized
INFO - 2020-09-14 18:15:47 --> URI Class Initialized
INFO - 2020-09-14 18:15:47 --> Router Class Initialized
INFO - 2020-09-14 18:15:47 --> Output Class Initialized
INFO - 2020-09-14 18:15:47 --> Security Class Initialized
DEBUG - 2020-09-14 18:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:15:47 --> Input Class Initialized
INFO - 2020-09-14 18:15:47 --> Language Class Initialized
INFO - 2020-09-14 18:15:47 --> Loader Class Initialized
INFO - 2020-09-14 18:15:47 --> Helper loaded: url_helper
INFO - 2020-09-14 18:15:47 --> Database Driver Class Initialized
INFO - 2020-09-14 18:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:15:47 --> Email Class Initialized
INFO - 2020-09-14 18:15:47 --> Controller Class Initialized
DEBUG - 2020-09-14 18:15:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:15:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:15:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-14 18:15:47 --> Final output sent to browser
DEBUG - 2020-09-14 18:15:47 --> Total execution time: 0.0189
ERROR - 2020-09-14 18:18:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:18:59 --> Config Class Initialized
INFO - 2020-09-14 18:18:59 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:18:59 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:18:59 --> Utf8 Class Initialized
INFO - 2020-09-14 18:18:59 --> URI Class Initialized
INFO - 2020-09-14 18:18:59 --> Router Class Initialized
INFO - 2020-09-14 18:18:59 --> Output Class Initialized
INFO - 2020-09-14 18:18:59 --> Security Class Initialized
DEBUG - 2020-09-14 18:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:18:59 --> Input Class Initialized
INFO - 2020-09-14 18:18:59 --> Language Class Initialized
INFO - 2020-09-14 18:18:59 --> Loader Class Initialized
INFO - 2020-09-14 18:18:59 --> Helper loaded: url_helper
INFO - 2020-09-14 18:18:59 --> Database Driver Class Initialized
INFO - 2020-09-14 18:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:18:59 --> Email Class Initialized
INFO - 2020-09-14 18:18:59 --> Controller Class Initialized
DEBUG - 2020-09-14 18:18:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:18:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:18:59 --> Model Class Initialized
INFO - 2020-09-14 18:18:59 --> Model Class Initialized
INFO - 2020-09-14 18:18:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-14 18:18:59 --> Final output sent to browser
DEBUG - 2020-09-14 18:18:59 --> Total execution time: 0.0207
ERROR - 2020-09-14 18:19:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:19:50 --> Config Class Initialized
INFO - 2020-09-14 18:19:50 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:19:50 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:19:50 --> Utf8 Class Initialized
INFO - 2020-09-14 18:19:50 --> URI Class Initialized
DEBUG - 2020-09-14 18:19:50 --> No URI present. Default controller set.
INFO - 2020-09-14 18:19:50 --> Router Class Initialized
INFO - 2020-09-14 18:19:50 --> Output Class Initialized
INFO - 2020-09-14 18:19:50 --> Security Class Initialized
DEBUG - 2020-09-14 18:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:19:50 --> Input Class Initialized
INFO - 2020-09-14 18:19:50 --> Language Class Initialized
INFO - 2020-09-14 18:19:50 --> Loader Class Initialized
INFO - 2020-09-14 18:19:50 --> Helper loaded: url_helper
INFO - 2020-09-14 18:19:50 --> Database Driver Class Initialized
INFO - 2020-09-14 18:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:19:50 --> Email Class Initialized
INFO - 2020-09-14 18:19:50 --> Controller Class Initialized
INFO - 2020-09-14 18:19:50 --> Model Class Initialized
INFO - 2020-09-14 18:19:50 --> Model Class Initialized
DEBUG - 2020-09-14 18:19:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:19:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-14 18:19:50 --> Final output sent to browser
DEBUG - 2020-09-14 18:19:50 --> Total execution time: 0.0212
ERROR - 2020-09-14 18:20:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:20:04 --> Config Class Initialized
INFO - 2020-09-14 18:20:04 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:20:04 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:20:04 --> Utf8 Class Initialized
INFO - 2020-09-14 18:20:04 --> URI Class Initialized
DEBUG - 2020-09-14 18:20:04 --> No URI present. Default controller set.
INFO - 2020-09-14 18:20:04 --> Router Class Initialized
INFO - 2020-09-14 18:20:04 --> Output Class Initialized
INFO - 2020-09-14 18:20:04 --> Security Class Initialized
DEBUG - 2020-09-14 18:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:20:04 --> Input Class Initialized
INFO - 2020-09-14 18:20:04 --> Language Class Initialized
INFO - 2020-09-14 18:20:04 --> Loader Class Initialized
INFO - 2020-09-14 18:20:04 --> Helper loaded: url_helper
INFO - 2020-09-14 18:20:04 --> Database Driver Class Initialized
INFO - 2020-09-14 18:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:20:04 --> Email Class Initialized
INFO - 2020-09-14 18:20:04 --> Controller Class Initialized
INFO - 2020-09-14 18:20:04 --> Model Class Initialized
INFO - 2020-09-14 18:20:04 --> Model Class Initialized
DEBUG - 2020-09-14 18:20:04 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:20:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-14 18:20:04 --> Final output sent to browser
DEBUG - 2020-09-14 18:20:04 --> Total execution time: 0.0211
ERROR - 2020-09-14 18:20:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:20:06 --> Config Class Initialized
INFO - 2020-09-14 18:20:06 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:20:06 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:20:06 --> Utf8 Class Initialized
INFO - 2020-09-14 18:20:06 --> URI Class Initialized
INFO - 2020-09-14 18:20:06 --> Router Class Initialized
INFO - 2020-09-14 18:20:06 --> Output Class Initialized
INFO - 2020-09-14 18:20:06 --> Security Class Initialized
DEBUG - 2020-09-14 18:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:20:06 --> Input Class Initialized
INFO - 2020-09-14 18:20:06 --> Language Class Initialized
INFO - 2020-09-14 18:20:06 --> Loader Class Initialized
INFO - 2020-09-14 18:20:06 --> Helper loaded: url_helper
INFO - 2020-09-14 18:20:06 --> Database Driver Class Initialized
INFO - 2020-09-14 18:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:20:06 --> Email Class Initialized
INFO - 2020-09-14 18:20:06 --> Controller Class Initialized
INFO - 2020-09-14 18:20:06 --> Model Class Initialized
INFO - 2020-09-14 18:20:06 --> Model Class Initialized
DEBUG - 2020-09-14 18:20:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:20:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:20:06 --> Model Class Initialized
INFO - 2020-09-14 18:20:06 --> Final output sent to browser
DEBUG - 2020-09-14 18:20:06 --> Total execution time: 0.0186
ERROR - 2020-09-14 18:20:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:20:06 --> Config Class Initialized
INFO - 2020-09-14 18:20:06 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:20:06 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:20:06 --> Utf8 Class Initialized
INFO - 2020-09-14 18:20:06 --> URI Class Initialized
INFO - 2020-09-14 18:20:06 --> Router Class Initialized
INFO - 2020-09-14 18:20:06 --> Output Class Initialized
INFO - 2020-09-14 18:20:06 --> Security Class Initialized
DEBUG - 2020-09-14 18:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:20:06 --> Input Class Initialized
INFO - 2020-09-14 18:20:06 --> Language Class Initialized
INFO - 2020-09-14 18:20:06 --> Loader Class Initialized
INFO - 2020-09-14 18:20:06 --> Helper loaded: url_helper
INFO - 2020-09-14 18:20:06 --> Database Driver Class Initialized
INFO - 2020-09-14 18:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:20:06 --> Email Class Initialized
INFO - 2020-09-14 18:20:06 --> Controller Class Initialized
INFO - 2020-09-14 18:20:06 --> Model Class Initialized
INFO - 2020-09-14 18:20:06 --> Model Class Initialized
DEBUG - 2020-09-14 18:20:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 18:20:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:20:07 --> Config Class Initialized
INFO - 2020-09-14 18:20:07 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:20:07 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:20:07 --> Utf8 Class Initialized
INFO - 2020-09-14 18:20:07 --> URI Class Initialized
INFO - 2020-09-14 18:20:07 --> Router Class Initialized
INFO - 2020-09-14 18:20:07 --> Output Class Initialized
INFO - 2020-09-14 18:20:07 --> Security Class Initialized
DEBUG - 2020-09-14 18:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:20:07 --> Input Class Initialized
INFO - 2020-09-14 18:20:07 --> Language Class Initialized
INFO - 2020-09-14 18:20:07 --> Loader Class Initialized
INFO - 2020-09-14 18:20:07 --> Helper loaded: url_helper
INFO - 2020-09-14 18:20:07 --> Database Driver Class Initialized
INFO - 2020-09-14 18:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:20:07 --> Email Class Initialized
INFO - 2020-09-14 18:20:07 --> Controller Class Initialized
DEBUG - 2020-09-14 18:20:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:20:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:20:07 --> Model Class Initialized
INFO - 2020-09-14 18:20:07 --> Model Class Initialized
INFO - 2020-09-14 18:20:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 18:20:07 --> Final output sent to browser
DEBUG - 2020-09-14 18:20:07 --> Total execution time: 0.0193
ERROR - 2020-09-14 18:20:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:20:37 --> Config Class Initialized
INFO - 2020-09-14 18:20:37 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:20:37 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:20:37 --> Utf8 Class Initialized
INFO - 2020-09-14 18:20:37 --> URI Class Initialized
INFO - 2020-09-14 18:20:37 --> Router Class Initialized
INFO - 2020-09-14 18:20:37 --> Output Class Initialized
INFO - 2020-09-14 18:20:37 --> Security Class Initialized
DEBUG - 2020-09-14 18:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:20:37 --> Input Class Initialized
INFO - 2020-09-14 18:20:37 --> Language Class Initialized
INFO - 2020-09-14 18:20:37 --> Loader Class Initialized
INFO - 2020-09-14 18:20:37 --> Helper loaded: url_helper
INFO - 2020-09-14 18:20:37 --> Database Driver Class Initialized
INFO - 2020-09-14 18:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:20:37 --> Email Class Initialized
INFO - 2020-09-14 18:20:37 --> Controller Class Initialized
DEBUG - 2020-09-14 18:20:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:20:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:20:37 --> Model Class Initialized
INFO - 2020-09-14 18:20:37 --> Model Class Initialized
INFO - 2020-09-14 18:20:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-14 18:20:37 --> Final output sent to browser
DEBUG - 2020-09-14 18:20:37 --> Total execution time: 0.0208
ERROR - 2020-09-14 18:20:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:20:46 --> Config Class Initialized
INFO - 2020-09-14 18:20:46 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:20:46 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:20:46 --> Utf8 Class Initialized
INFO - 2020-09-14 18:20:46 --> URI Class Initialized
INFO - 2020-09-14 18:20:46 --> Router Class Initialized
INFO - 2020-09-14 18:20:46 --> Output Class Initialized
INFO - 2020-09-14 18:20:46 --> Security Class Initialized
DEBUG - 2020-09-14 18:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:20:46 --> Input Class Initialized
INFO - 2020-09-14 18:20:46 --> Language Class Initialized
INFO - 2020-09-14 18:20:46 --> Loader Class Initialized
INFO - 2020-09-14 18:20:46 --> Helper loaded: url_helper
INFO - 2020-09-14 18:20:46 --> Database Driver Class Initialized
INFO - 2020-09-14 18:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:20:46 --> Email Class Initialized
INFO - 2020-09-14 18:20:46 --> Controller Class Initialized
DEBUG - 2020-09-14 18:20:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:20:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:20:46 --> Model Class Initialized
INFO - 2020-09-14 18:20:46 --> Model Class Initialized
INFO - 2020-09-14 18:20:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-09-14 18:20:46 --> Final output sent to browser
DEBUG - 2020-09-14 18:20:46 --> Total execution time: 0.0240
ERROR - 2020-09-14 18:21:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:21:43 --> Config Class Initialized
INFO - 2020-09-14 18:21:43 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:21:43 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:21:43 --> Utf8 Class Initialized
INFO - 2020-09-14 18:21:43 --> URI Class Initialized
DEBUG - 2020-09-14 18:21:43 --> No URI present. Default controller set.
INFO - 2020-09-14 18:21:43 --> Router Class Initialized
INFO - 2020-09-14 18:21:43 --> Output Class Initialized
INFO - 2020-09-14 18:21:43 --> Security Class Initialized
DEBUG - 2020-09-14 18:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:21:43 --> Input Class Initialized
INFO - 2020-09-14 18:21:43 --> Language Class Initialized
INFO - 2020-09-14 18:21:43 --> Loader Class Initialized
INFO - 2020-09-14 18:21:43 --> Helper loaded: url_helper
INFO - 2020-09-14 18:21:44 --> Database Driver Class Initialized
INFO - 2020-09-14 18:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:21:44 --> Email Class Initialized
INFO - 2020-09-14 18:21:44 --> Controller Class Initialized
INFO - 2020-09-14 18:21:44 --> Model Class Initialized
INFO - 2020-09-14 18:21:44 --> Model Class Initialized
DEBUG - 2020-09-14 18:21:44 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:21:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-14 18:21:44 --> Final output sent to browser
DEBUG - 2020-09-14 18:21:44 --> Total execution time: 0.0190
ERROR - 2020-09-14 18:21:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:21:47 --> Config Class Initialized
INFO - 2020-09-14 18:21:47 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:21:47 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:21:47 --> Utf8 Class Initialized
INFO - 2020-09-14 18:21:47 --> URI Class Initialized
INFO - 2020-09-14 18:21:47 --> Router Class Initialized
INFO - 2020-09-14 18:21:47 --> Output Class Initialized
INFO - 2020-09-14 18:21:47 --> Security Class Initialized
DEBUG - 2020-09-14 18:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:21:47 --> Input Class Initialized
INFO - 2020-09-14 18:21:47 --> Language Class Initialized
INFO - 2020-09-14 18:21:47 --> Loader Class Initialized
INFO - 2020-09-14 18:21:47 --> Helper loaded: url_helper
INFO - 2020-09-14 18:21:47 --> Database Driver Class Initialized
INFO - 2020-09-14 18:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:21:47 --> Email Class Initialized
INFO - 2020-09-14 18:21:47 --> Controller Class Initialized
INFO - 2020-09-14 18:21:47 --> Model Class Initialized
INFO - 2020-09-14 18:21:47 --> Model Class Initialized
DEBUG - 2020-09-14 18:21:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:21:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:21:47 --> Model Class Initialized
INFO - 2020-09-14 18:21:47 --> Final output sent to browser
DEBUG - 2020-09-14 18:21:47 --> Total execution time: 0.0203
ERROR - 2020-09-14 18:21:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:21:47 --> Config Class Initialized
INFO - 2020-09-14 18:21:47 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:21:47 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:21:47 --> Utf8 Class Initialized
INFO - 2020-09-14 18:21:47 --> URI Class Initialized
INFO - 2020-09-14 18:21:47 --> Router Class Initialized
INFO - 2020-09-14 18:21:47 --> Output Class Initialized
INFO - 2020-09-14 18:21:47 --> Security Class Initialized
DEBUG - 2020-09-14 18:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:21:47 --> Input Class Initialized
INFO - 2020-09-14 18:21:47 --> Language Class Initialized
INFO - 2020-09-14 18:21:47 --> Loader Class Initialized
INFO - 2020-09-14 18:21:47 --> Helper loaded: url_helper
INFO - 2020-09-14 18:21:47 --> Database Driver Class Initialized
INFO - 2020-09-14 18:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:21:47 --> Email Class Initialized
INFO - 2020-09-14 18:21:47 --> Controller Class Initialized
INFO - 2020-09-14 18:21:47 --> Model Class Initialized
INFO - 2020-09-14 18:21:47 --> Model Class Initialized
DEBUG - 2020-09-14 18:21:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 18:21:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:21:48 --> Config Class Initialized
INFO - 2020-09-14 18:21:48 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:21:48 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:21:48 --> Utf8 Class Initialized
INFO - 2020-09-14 18:21:48 --> URI Class Initialized
INFO - 2020-09-14 18:21:48 --> Router Class Initialized
INFO - 2020-09-14 18:21:48 --> Output Class Initialized
INFO - 2020-09-14 18:21:48 --> Security Class Initialized
DEBUG - 2020-09-14 18:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:21:48 --> Input Class Initialized
INFO - 2020-09-14 18:21:48 --> Language Class Initialized
INFO - 2020-09-14 18:21:48 --> Loader Class Initialized
INFO - 2020-09-14 18:21:48 --> Helper loaded: url_helper
INFO - 2020-09-14 18:21:48 --> Database Driver Class Initialized
INFO - 2020-09-14 18:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:21:48 --> Email Class Initialized
INFO - 2020-09-14 18:21:48 --> Controller Class Initialized
DEBUG - 2020-09-14 18:21:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:21:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:21:48 --> Model Class Initialized
INFO - 2020-09-14 18:21:48 --> Model Class Initialized
INFO - 2020-09-14 18:21:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 18:21:48 --> Final output sent to browser
DEBUG - 2020-09-14 18:21:48 --> Total execution time: 0.0218
ERROR - 2020-09-14 18:21:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:21:52 --> Config Class Initialized
INFO - 2020-09-14 18:21:52 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:21:52 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:21:52 --> Utf8 Class Initialized
INFO - 2020-09-14 18:21:52 --> URI Class Initialized
INFO - 2020-09-14 18:21:52 --> Router Class Initialized
INFO - 2020-09-14 18:21:52 --> Output Class Initialized
INFO - 2020-09-14 18:21:52 --> Security Class Initialized
DEBUG - 2020-09-14 18:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:21:52 --> Input Class Initialized
INFO - 2020-09-14 18:21:52 --> Language Class Initialized
INFO - 2020-09-14 18:21:52 --> Loader Class Initialized
INFO - 2020-09-14 18:21:52 --> Helper loaded: url_helper
INFO - 2020-09-14 18:21:52 --> Database Driver Class Initialized
INFO - 2020-09-14 18:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:21:52 --> Email Class Initialized
INFO - 2020-09-14 18:21:52 --> Controller Class Initialized
DEBUG - 2020-09-14 18:21:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:21:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:21:52 --> Model Class Initialized
INFO - 2020-09-14 18:21:52 --> Model Class Initialized
INFO - 2020-09-14 18:21:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 18:21:52 --> Final output sent to browser
DEBUG - 2020-09-14 18:21:52 --> Total execution time: 0.0244
ERROR - 2020-09-14 18:21:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:21:58 --> Config Class Initialized
INFO - 2020-09-14 18:21:58 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:21:58 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:21:58 --> Utf8 Class Initialized
INFO - 2020-09-14 18:21:58 --> URI Class Initialized
INFO - 2020-09-14 18:21:58 --> Router Class Initialized
INFO - 2020-09-14 18:21:58 --> Output Class Initialized
INFO - 2020-09-14 18:21:58 --> Security Class Initialized
DEBUG - 2020-09-14 18:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:21:58 --> Input Class Initialized
INFO - 2020-09-14 18:21:58 --> Language Class Initialized
INFO - 2020-09-14 18:21:58 --> Loader Class Initialized
INFO - 2020-09-14 18:21:58 --> Helper loaded: url_helper
INFO - 2020-09-14 18:21:58 --> Database Driver Class Initialized
INFO - 2020-09-14 18:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:21:58 --> Email Class Initialized
INFO - 2020-09-14 18:21:58 --> Controller Class Initialized
DEBUG - 2020-09-14 18:21:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:21:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:21:58 --> Model Class Initialized
INFO - 2020-09-14 18:21:58 --> Model Class Initialized
INFO - 2020-09-14 18:21:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-14 18:21:58 --> Final output sent to browser
DEBUG - 2020-09-14 18:21:58 --> Total execution time: 0.0193
ERROR - 2020-09-14 18:22:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:22:02 --> Config Class Initialized
INFO - 2020-09-14 18:22:02 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:22:02 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:22:02 --> Utf8 Class Initialized
INFO - 2020-09-14 18:22:02 --> URI Class Initialized
INFO - 2020-09-14 18:22:02 --> Router Class Initialized
INFO - 2020-09-14 18:22:02 --> Output Class Initialized
INFO - 2020-09-14 18:22:02 --> Security Class Initialized
DEBUG - 2020-09-14 18:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:22:02 --> Input Class Initialized
INFO - 2020-09-14 18:22:02 --> Language Class Initialized
INFO - 2020-09-14 18:22:02 --> Loader Class Initialized
INFO - 2020-09-14 18:22:02 --> Helper loaded: url_helper
INFO - 2020-09-14 18:22:02 --> Database Driver Class Initialized
INFO - 2020-09-14 18:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:22:02 --> Email Class Initialized
INFO - 2020-09-14 18:22:02 --> Controller Class Initialized
DEBUG - 2020-09-14 18:22:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:22:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:22:02 --> Model Class Initialized
INFO - 2020-09-14 18:22:02 --> Model Class Initialized
INFO - 2020-09-14 18:22:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-09-14 18:22:02 --> Final output sent to browser
DEBUG - 2020-09-14 18:22:02 --> Total execution time: 0.0190
ERROR - 2020-09-14 18:22:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:22:11 --> Config Class Initialized
INFO - 2020-09-14 18:22:11 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:22:11 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:22:11 --> Utf8 Class Initialized
INFO - 2020-09-14 18:22:11 --> URI Class Initialized
INFO - 2020-09-14 18:22:11 --> Router Class Initialized
INFO - 2020-09-14 18:22:11 --> Output Class Initialized
INFO - 2020-09-14 18:22:11 --> Security Class Initialized
DEBUG - 2020-09-14 18:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:22:11 --> Input Class Initialized
INFO - 2020-09-14 18:22:11 --> Language Class Initialized
INFO - 2020-09-14 18:22:11 --> Loader Class Initialized
INFO - 2020-09-14 18:22:11 --> Helper loaded: url_helper
INFO - 2020-09-14 18:22:11 --> Database Driver Class Initialized
INFO - 2020-09-14 18:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:22:11 --> Email Class Initialized
INFO - 2020-09-14 18:22:11 --> Controller Class Initialized
DEBUG - 2020-09-14 18:22:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:22:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:22:11 --> Model Class Initialized
INFO - 2020-09-14 18:22:11 --> Model Class Initialized
INFO - 2020-09-14 18:22:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 18:22:11 --> Final output sent to browser
DEBUG - 2020-09-14 18:22:11 --> Total execution time: 0.0248
ERROR - 2020-09-14 18:24:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:24:41 --> Config Class Initialized
INFO - 2020-09-14 18:24:41 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:24:41 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:24:41 --> Utf8 Class Initialized
INFO - 2020-09-14 18:24:41 --> URI Class Initialized
DEBUG - 2020-09-14 18:24:41 --> No URI present. Default controller set.
INFO - 2020-09-14 18:24:41 --> Router Class Initialized
INFO - 2020-09-14 18:24:41 --> Output Class Initialized
INFO - 2020-09-14 18:24:41 --> Security Class Initialized
DEBUG - 2020-09-14 18:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:24:41 --> Input Class Initialized
INFO - 2020-09-14 18:24:41 --> Language Class Initialized
INFO - 2020-09-14 18:24:41 --> Loader Class Initialized
INFO - 2020-09-14 18:24:41 --> Helper loaded: url_helper
INFO - 2020-09-14 18:24:41 --> Database Driver Class Initialized
INFO - 2020-09-14 18:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:24:41 --> Email Class Initialized
INFO - 2020-09-14 18:24:41 --> Controller Class Initialized
INFO - 2020-09-14 18:24:41 --> Model Class Initialized
INFO - 2020-09-14 18:24:41 --> Model Class Initialized
DEBUG - 2020-09-14 18:24:41 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:24:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-14 18:24:41 --> Final output sent to browser
DEBUG - 2020-09-14 18:24:41 --> Total execution time: 0.0212
ERROR - 2020-09-14 18:24:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:24:58 --> Config Class Initialized
INFO - 2020-09-14 18:24:58 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:24:58 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:24:58 --> Utf8 Class Initialized
INFO - 2020-09-14 18:24:58 --> URI Class Initialized
INFO - 2020-09-14 18:24:58 --> Router Class Initialized
INFO - 2020-09-14 18:24:58 --> Output Class Initialized
INFO - 2020-09-14 18:24:58 --> Security Class Initialized
DEBUG - 2020-09-14 18:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:24:58 --> Input Class Initialized
INFO - 2020-09-14 18:24:58 --> Language Class Initialized
INFO - 2020-09-14 18:24:58 --> Loader Class Initialized
INFO - 2020-09-14 18:24:58 --> Helper loaded: url_helper
INFO - 2020-09-14 18:24:58 --> Database Driver Class Initialized
INFO - 2020-09-14 18:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:24:58 --> Email Class Initialized
INFO - 2020-09-14 18:24:58 --> Controller Class Initialized
INFO - 2020-09-14 18:24:58 --> Model Class Initialized
INFO - 2020-09-14 18:24:58 --> Model Class Initialized
DEBUG - 2020-09-14 18:24:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:24:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:24:58 --> Model Class Initialized
INFO - 2020-09-14 18:24:58 --> Final output sent to browser
DEBUG - 2020-09-14 18:24:58 --> Total execution time: 0.0237
ERROR - 2020-09-14 18:24:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:24:58 --> Config Class Initialized
INFO - 2020-09-14 18:24:58 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:24:58 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:24:58 --> Utf8 Class Initialized
INFO - 2020-09-14 18:24:58 --> URI Class Initialized
INFO - 2020-09-14 18:24:58 --> Router Class Initialized
INFO - 2020-09-14 18:24:58 --> Output Class Initialized
INFO - 2020-09-14 18:24:58 --> Security Class Initialized
DEBUG - 2020-09-14 18:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:24:58 --> Input Class Initialized
INFO - 2020-09-14 18:24:58 --> Language Class Initialized
INFO - 2020-09-14 18:24:58 --> Loader Class Initialized
INFO - 2020-09-14 18:24:58 --> Helper loaded: url_helper
INFO - 2020-09-14 18:24:58 --> Database Driver Class Initialized
INFO - 2020-09-14 18:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:24:59 --> Email Class Initialized
INFO - 2020-09-14 18:24:59 --> Controller Class Initialized
INFO - 2020-09-14 18:24:59 --> Model Class Initialized
INFO - 2020-09-14 18:24:59 --> Model Class Initialized
DEBUG - 2020-09-14 18:24:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 18:24:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:24:59 --> Config Class Initialized
INFO - 2020-09-14 18:24:59 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:24:59 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:24:59 --> Utf8 Class Initialized
INFO - 2020-09-14 18:24:59 --> URI Class Initialized
INFO - 2020-09-14 18:24:59 --> Router Class Initialized
INFO - 2020-09-14 18:24:59 --> Output Class Initialized
INFO - 2020-09-14 18:24:59 --> Security Class Initialized
DEBUG - 2020-09-14 18:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:24:59 --> Input Class Initialized
INFO - 2020-09-14 18:24:59 --> Language Class Initialized
INFO - 2020-09-14 18:24:59 --> Loader Class Initialized
INFO - 2020-09-14 18:24:59 --> Helper loaded: url_helper
INFO - 2020-09-14 18:24:59 --> Database Driver Class Initialized
INFO - 2020-09-14 18:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:24:59 --> Email Class Initialized
INFO - 2020-09-14 18:24:59 --> Controller Class Initialized
DEBUG - 2020-09-14 18:24:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:24:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:24:59 --> Model Class Initialized
INFO - 2020-09-14 18:24:59 --> Model Class Initialized
INFO - 2020-09-14 18:24:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-14 18:24:59 --> Final output sent to browser
DEBUG - 2020-09-14 18:24:59 --> Total execution time: 0.0235
ERROR - 2020-09-14 18:25:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:25:05 --> Config Class Initialized
INFO - 2020-09-14 18:25:05 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:25:05 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:25:05 --> Utf8 Class Initialized
INFO - 2020-09-14 18:25:05 --> URI Class Initialized
DEBUG - 2020-09-14 18:25:05 --> No URI present. Default controller set.
INFO - 2020-09-14 18:25:05 --> Router Class Initialized
INFO - 2020-09-14 18:25:05 --> Output Class Initialized
INFO - 2020-09-14 18:25:05 --> Security Class Initialized
DEBUG - 2020-09-14 18:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:25:05 --> Input Class Initialized
INFO - 2020-09-14 18:25:05 --> Language Class Initialized
INFO - 2020-09-14 18:25:05 --> Loader Class Initialized
INFO - 2020-09-14 18:25:05 --> Helper loaded: url_helper
INFO - 2020-09-14 18:25:05 --> Database Driver Class Initialized
INFO - 2020-09-14 18:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:25:05 --> Email Class Initialized
INFO - 2020-09-14 18:25:05 --> Controller Class Initialized
INFO - 2020-09-14 18:25:05 --> Model Class Initialized
INFO - 2020-09-14 18:25:05 --> Model Class Initialized
DEBUG - 2020-09-14 18:25:05 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:25:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-14 18:25:05 --> Final output sent to browser
DEBUG - 2020-09-14 18:25:05 --> Total execution time: 0.0214
ERROR - 2020-09-14 18:25:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-14 18:25:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:25:19 --> Config Class Initialized
INFO - 2020-09-14 18:25:19 --> Hooks Class Initialized
INFO - 2020-09-14 18:25:19 --> Config Class Initialized
INFO - 2020-09-14 18:25:19 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:25:19 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:25:19 --> Utf8 Class Initialized
DEBUG - 2020-09-14 18:25:19 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:25:19 --> Utf8 Class Initialized
INFO - 2020-09-14 18:25:19 --> URI Class Initialized
INFO - 2020-09-14 18:25:19 --> URI Class Initialized
INFO - 2020-09-14 18:25:19 --> Router Class Initialized
INFO - 2020-09-14 18:25:19 --> Router Class Initialized
INFO - 2020-09-14 18:25:19 --> Output Class Initialized
INFO - 2020-09-14 18:25:19 --> Output Class Initialized
INFO - 2020-09-14 18:25:19 --> Security Class Initialized
INFO - 2020-09-14 18:25:19 --> Security Class Initialized
DEBUG - 2020-09-14 18:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:25:19 --> Input Class Initialized
DEBUG - 2020-09-14 18:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:25:19 --> Input Class Initialized
INFO - 2020-09-14 18:25:19 --> Language Class Initialized
INFO - 2020-09-14 18:25:19 --> Language Class Initialized
INFO - 2020-09-14 18:25:19 --> Loader Class Initialized
INFO - 2020-09-14 18:25:19 --> Loader Class Initialized
INFO - 2020-09-14 18:25:19 --> Helper loaded: url_helper
INFO - 2020-09-14 18:25:19 --> Helper loaded: url_helper
INFO - 2020-09-14 18:25:19 --> Database Driver Class Initialized
INFO - 2020-09-14 18:25:19 --> Database Driver Class Initialized
INFO - 2020-09-14 18:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:25:19 --> Email Class Initialized
INFO - 2020-09-14 18:25:19 --> Controller Class Initialized
INFO - 2020-09-14 18:25:19 --> Model Class Initialized
INFO - 2020-09-14 18:25:19 --> Model Class Initialized
DEBUG - 2020-09-14 18:25:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:25:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:25:19 --> Model Class Initialized
INFO - 2020-09-14 18:25:19 --> Final output sent to browser
DEBUG - 2020-09-14 18:25:19 --> Total execution time: 0.0219
INFO - 2020-09-14 18:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:25:19 --> Email Class Initialized
INFO - 2020-09-14 18:25:19 --> Controller Class Initialized
INFO - 2020-09-14 18:25:19 --> Model Class Initialized
INFO - 2020-09-14 18:25:19 --> Model Class Initialized
DEBUG - 2020-09-14 18:25:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-14 18:25:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:25:19 --> Config Class Initialized
INFO - 2020-09-14 18:25:19 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:25:19 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:25:19 --> Utf8 Class Initialized
INFO - 2020-09-14 18:25:19 --> URI Class Initialized
INFO - 2020-09-14 18:25:19 --> Router Class Initialized
INFO - 2020-09-14 18:25:19 --> Output Class Initialized
INFO - 2020-09-14 18:25:19 --> Security Class Initialized
DEBUG - 2020-09-14 18:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:25:19 --> Input Class Initialized
INFO - 2020-09-14 18:25:19 --> Language Class Initialized
INFO - 2020-09-14 18:25:19 --> Loader Class Initialized
INFO - 2020-09-14 18:25:19 --> Helper loaded: url_helper
INFO - 2020-09-14 18:25:19 --> Database Driver Class Initialized
INFO - 2020-09-14 18:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:25:19 --> Email Class Initialized
INFO - 2020-09-14 18:25:19 --> Controller Class Initialized
DEBUG - 2020-09-14 18:25:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:25:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:25:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-14 18:25:19 --> Final output sent to browser
DEBUG - 2020-09-14 18:25:19 --> Total execution time: 0.0169
ERROR - 2020-09-14 18:25:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:25:27 --> Config Class Initialized
INFO - 2020-09-14 18:25:27 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:25:27 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:25:27 --> Utf8 Class Initialized
INFO - 2020-09-14 18:25:27 --> URI Class Initialized
INFO - 2020-09-14 18:25:27 --> Router Class Initialized
INFO - 2020-09-14 18:25:27 --> Output Class Initialized
INFO - 2020-09-14 18:25:27 --> Security Class Initialized
DEBUG - 2020-09-14 18:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:25:27 --> Input Class Initialized
INFO - 2020-09-14 18:25:27 --> Language Class Initialized
INFO - 2020-09-14 18:25:27 --> Loader Class Initialized
INFO - 2020-09-14 18:25:27 --> Helper loaded: url_helper
INFO - 2020-09-14 18:25:27 --> Database Driver Class Initialized
INFO - 2020-09-14 18:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:25:27 --> Email Class Initialized
INFO - 2020-09-14 18:25:27 --> Controller Class Initialized
DEBUG - 2020-09-14 18:25:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:25:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:25:27 --> Model Class Initialized
INFO - 2020-09-14 18:25:27 --> Model Class Initialized
INFO - 2020-09-14 18:25:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-14 18:25:27 --> Final output sent to browser
DEBUG - 2020-09-14 18:25:27 --> Total execution time: 0.0233
ERROR - 2020-09-14 18:25:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:25:30 --> Config Class Initialized
INFO - 2020-09-14 18:25:30 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:25:30 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:25:30 --> Utf8 Class Initialized
INFO - 2020-09-14 18:25:30 --> URI Class Initialized
INFO - 2020-09-14 18:25:30 --> Router Class Initialized
INFO - 2020-09-14 18:25:30 --> Output Class Initialized
INFO - 2020-09-14 18:25:30 --> Security Class Initialized
DEBUG - 2020-09-14 18:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:25:30 --> Input Class Initialized
INFO - 2020-09-14 18:25:30 --> Language Class Initialized
INFO - 2020-09-14 18:25:30 --> Loader Class Initialized
INFO - 2020-09-14 18:25:30 --> Helper loaded: url_helper
INFO - 2020-09-14 18:25:30 --> Database Driver Class Initialized
INFO - 2020-09-14 18:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:25:30 --> Email Class Initialized
INFO - 2020-09-14 18:25:30 --> Controller Class Initialized
DEBUG - 2020-09-14 18:25:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:25:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:25:30 --> Model Class Initialized
INFO - 2020-09-14 18:25:30 --> Model Class Initialized
INFO - 2020-09-14 18:25:30 --> Model Class Initialized
INFO - 2020-09-14 18:25:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-14 18:25:30 --> Final output sent to browser
DEBUG - 2020-09-14 18:25:30 --> Total execution time: 0.0280
ERROR - 2020-09-14 18:29:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-14 18:29:03 --> Config Class Initialized
INFO - 2020-09-14 18:29:03 --> Hooks Class Initialized
DEBUG - 2020-09-14 18:29:03 --> UTF-8 Support Enabled
INFO - 2020-09-14 18:29:03 --> Utf8 Class Initialized
INFO - 2020-09-14 18:29:03 --> URI Class Initialized
INFO - 2020-09-14 18:29:03 --> Router Class Initialized
INFO - 2020-09-14 18:29:03 --> Output Class Initialized
INFO - 2020-09-14 18:29:03 --> Security Class Initialized
DEBUG - 2020-09-14 18:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-14 18:29:03 --> Input Class Initialized
INFO - 2020-09-14 18:29:03 --> Language Class Initialized
INFO - 2020-09-14 18:29:03 --> Loader Class Initialized
INFO - 2020-09-14 18:29:03 --> Helper loaded: url_helper
INFO - 2020-09-14 18:29:03 --> Database Driver Class Initialized
INFO - 2020-09-14 18:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-14 18:29:03 --> Email Class Initialized
INFO - 2020-09-14 18:29:03 --> Controller Class Initialized
DEBUG - 2020-09-14 18:29:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-14 18:29:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-14 18:29:03 --> Model Class Initialized
INFO - 2020-09-14 18:29:03 --> Model Class Initialized
INFO - 2020-09-14 18:29:03 --> Model Class Initialized
INFO - 2020-09-14 18:29:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-14 18:29:03 --> Final output sent to browser
DEBUG - 2020-09-14 18:29:03 --> Total execution time: 0.0250
