<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-07-29 03:11:10 --> Config Class Initialized
INFO - 2020-07-29 03:11:10 --> Hooks Class Initialized
DEBUG - 2020-07-29 03:11:10 --> UTF-8 Support Enabled
INFO - 2020-07-29 03:11:10 --> Utf8 Class Initialized
INFO - 2020-07-29 03:11:10 --> URI Class Initialized
DEBUG - 2020-07-29 03:11:10 --> No URI present. Default controller set.
INFO - 2020-07-29 03:11:10 --> Router Class Initialized
INFO - 2020-07-29 03:11:10 --> Output Class Initialized
INFO - 2020-07-29 03:11:10 --> Security Class Initialized
DEBUG - 2020-07-29 03:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 03:11:10 --> Input Class Initialized
INFO - 2020-07-29 03:11:10 --> Language Class Initialized
INFO - 2020-07-29 03:11:10 --> Loader Class Initialized
INFO - 2020-07-29 03:11:10 --> Helper loaded: url_helper
INFO - 2020-07-29 03:11:10 --> Database Driver Class Initialized
INFO - 2020-07-29 03:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 03:11:10 --> Email Class Initialized
INFO - 2020-07-29 03:11:10 --> Controller Class Initialized
INFO - 2020-07-29 03:11:10 --> Model Class Initialized
INFO - 2020-07-29 03:11:10 --> Model Class Initialized
DEBUG - 2020-07-29 03:11:10 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 03:11:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 03:11:10 --> Final output sent to browser
DEBUG - 2020-07-29 03:11:10 --> Total execution time: 0.0472
INFO - 2020-07-29 03:11:13 --> Config Class Initialized
INFO - 2020-07-29 03:11:13 --> Hooks Class Initialized
DEBUG - 2020-07-29 03:11:13 --> UTF-8 Support Enabled
INFO - 2020-07-29 03:11:13 --> Utf8 Class Initialized
INFO - 2020-07-29 03:11:13 --> URI Class Initialized
INFO - 2020-07-29 03:11:13 --> Router Class Initialized
INFO - 2020-07-29 03:11:13 --> Output Class Initialized
INFO - 2020-07-29 03:11:13 --> Security Class Initialized
DEBUG - 2020-07-29 03:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 03:11:13 --> Input Class Initialized
INFO - 2020-07-29 03:11:13 --> Language Class Initialized
INFO - 2020-07-29 03:11:13 --> Loader Class Initialized
INFO - 2020-07-29 03:11:13 --> Helper loaded: url_helper
INFO - 2020-07-29 03:11:13 --> Database Driver Class Initialized
INFO - 2020-07-29 03:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 03:11:13 --> Email Class Initialized
INFO - 2020-07-29 03:11:13 --> Controller Class Initialized
INFO - 2020-07-29 03:11:13 --> Model Class Initialized
INFO - 2020-07-29 03:11:13 --> Model Class Initialized
DEBUG - 2020-07-29 03:11:13 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 03:11:14 --> Config Class Initialized
INFO - 2020-07-29 03:11:14 --> Hooks Class Initialized
DEBUG - 2020-07-29 03:11:14 --> UTF-8 Support Enabled
INFO - 2020-07-29 03:11:14 --> Utf8 Class Initialized
INFO - 2020-07-29 03:11:14 --> URI Class Initialized
INFO - 2020-07-29 03:11:14 --> Router Class Initialized
INFO - 2020-07-29 03:11:14 --> Output Class Initialized
INFO - 2020-07-29 03:11:14 --> Security Class Initialized
DEBUG - 2020-07-29 03:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 03:11:14 --> Input Class Initialized
INFO - 2020-07-29 03:11:14 --> Language Class Initialized
INFO - 2020-07-29 03:11:14 --> Loader Class Initialized
INFO - 2020-07-29 03:11:14 --> Helper loaded: url_helper
INFO - 2020-07-29 03:11:14 --> Database Driver Class Initialized
INFO - 2020-07-29 03:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 03:11:14 --> Email Class Initialized
INFO - 2020-07-29 03:11:14 --> Controller Class Initialized
DEBUG - 2020-07-29 03:11:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 03:11:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 03:11:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 03:11:14 --> Final output sent to browser
DEBUG - 2020-07-29 03:11:14 --> Total execution time: 0.0203
INFO - 2020-07-29 03:11:19 --> Config Class Initialized
INFO - 2020-07-29 03:11:19 --> Hooks Class Initialized
DEBUG - 2020-07-29 03:11:19 --> UTF-8 Support Enabled
INFO - 2020-07-29 03:11:19 --> Utf8 Class Initialized
INFO - 2020-07-29 03:11:19 --> URI Class Initialized
INFO - 2020-07-29 03:11:19 --> Router Class Initialized
INFO - 2020-07-29 03:11:19 --> Output Class Initialized
INFO - 2020-07-29 03:11:19 --> Security Class Initialized
DEBUG - 2020-07-29 03:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 03:11:19 --> Input Class Initialized
INFO - 2020-07-29 03:11:19 --> Language Class Initialized
INFO - 2020-07-29 03:11:19 --> Loader Class Initialized
INFO - 2020-07-29 03:11:19 --> Helper loaded: url_helper
INFO - 2020-07-29 03:11:19 --> Database Driver Class Initialized
INFO - 2020-07-29 03:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 03:11:19 --> Email Class Initialized
INFO - 2020-07-29 03:11:19 --> Controller Class Initialized
DEBUG - 2020-07-29 03:11:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 03:11:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 03:11:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 03:11:19 --> Final output sent to browser
DEBUG - 2020-07-29 03:11:19 --> Total execution time: 0.0207
INFO - 2020-07-29 03:11:34 --> Config Class Initialized
INFO - 2020-07-29 03:11:34 --> Hooks Class Initialized
DEBUG - 2020-07-29 03:11:34 --> UTF-8 Support Enabled
INFO - 2020-07-29 03:11:34 --> Utf8 Class Initialized
INFO - 2020-07-29 03:11:34 --> URI Class Initialized
INFO - 2020-07-29 03:11:34 --> Router Class Initialized
INFO - 2020-07-29 03:11:34 --> Output Class Initialized
INFO - 2020-07-29 03:11:34 --> Security Class Initialized
DEBUG - 2020-07-29 03:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 03:11:34 --> Input Class Initialized
INFO - 2020-07-29 03:11:34 --> Language Class Initialized
INFO - 2020-07-29 03:11:34 --> Loader Class Initialized
INFO - 2020-07-29 03:11:34 --> Helper loaded: url_helper
INFO - 2020-07-29 03:11:34 --> Database Driver Class Initialized
INFO - 2020-07-29 03:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 03:11:34 --> Email Class Initialized
INFO - 2020-07-29 03:11:34 --> Controller Class Initialized
DEBUG - 2020-07-29 03:11:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 03:11:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 03:11:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-29 03:11:34 --> Final output sent to browser
DEBUG - 2020-07-29 03:11:34 --> Total execution time: 0.0207
INFO - 2020-07-29 03:12:03 --> Config Class Initialized
INFO - 2020-07-29 03:12:03 --> Hooks Class Initialized
DEBUG - 2020-07-29 03:12:03 --> UTF-8 Support Enabled
INFO - 2020-07-29 03:12:03 --> Utf8 Class Initialized
INFO - 2020-07-29 03:12:03 --> URI Class Initialized
INFO - 2020-07-29 03:12:03 --> Router Class Initialized
INFO - 2020-07-29 03:12:03 --> Output Class Initialized
INFO - 2020-07-29 03:12:03 --> Security Class Initialized
DEBUG - 2020-07-29 03:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 03:12:03 --> Input Class Initialized
INFO - 2020-07-29 03:12:03 --> Language Class Initialized
INFO - 2020-07-29 03:12:03 --> Loader Class Initialized
INFO - 2020-07-29 03:12:03 --> Helper loaded: url_helper
INFO - 2020-07-29 03:12:03 --> Database Driver Class Initialized
INFO - 2020-07-29 03:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 03:12:03 --> Email Class Initialized
INFO - 2020-07-29 03:12:03 --> Controller Class Initialized
DEBUG - 2020-07-29 03:12:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 03:12:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 03:12:03 --> Model Class Initialized
INFO - 2020-07-29 03:12:03 --> Model Class Initialized
ERROR - 2020-07-29 03:12:03 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2020-07-29 03:12:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 03:12:03 --> Severity: Error --> Call to undefined method CI_DB_mysql_result::next_result() /home/purpu1ex/public_html/carsm/application/models/Admin_model.php 25
INFO - 2020-07-29 03:18:16 --> Config Class Initialized
INFO - 2020-07-29 03:18:16 --> Hooks Class Initialized
DEBUG - 2020-07-29 03:18:16 --> UTF-8 Support Enabled
INFO - 2020-07-29 03:18:16 --> Utf8 Class Initialized
INFO - 2020-07-29 03:18:16 --> URI Class Initialized
DEBUG - 2020-07-29 03:18:16 --> No URI present. Default controller set.
INFO - 2020-07-29 03:18:16 --> Router Class Initialized
INFO - 2020-07-29 03:18:16 --> Output Class Initialized
INFO - 2020-07-29 03:18:16 --> Security Class Initialized
DEBUG - 2020-07-29 03:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 03:18:16 --> Input Class Initialized
INFO - 2020-07-29 03:18:16 --> Language Class Initialized
INFO - 2020-07-29 03:18:16 --> Loader Class Initialized
INFO - 2020-07-29 03:18:16 --> Helper loaded: url_helper
INFO - 2020-07-29 03:18:16 --> Database Driver Class Initialized
INFO - 2020-07-29 03:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 03:18:16 --> Email Class Initialized
INFO - 2020-07-29 03:18:16 --> Controller Class Initialized
INFO - 2020-07-29 03:18:16 --> Model Class Initialized
INFO - 2020-07-29 03:18:16 --> Model Class Initialized
DEBUG - 2020-07-29 03:18:16 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 03:18:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 03:18:16 --> Final output sent to browser
DEBUG - 2020-07-29 03:18:16 --> Total execution time: 0.0233
INFO - 2020-07-29 03:20:44 --> Config Class Initialized
INFO - 2020-07-29 03:20:44 --> Hooks Class Initialized
DEBUG - 2020-07-29 03:20:44 --> UTF-8 Support Enabled
INFO - 2020-07-29 03:20:44 --> Utf8 Class Initialized
INFO - 2020-07-29 03:20:44 --> URI Class Initialized
INFO - 2020-07-29 03:20:44 --> Router Class Initialized
INFO - 2020-07-29 03:20:44 --> Output Class Initialized
INFO - 2020-07-29 03:20:44 --> Security Class Initialized
DEBUG - 2020-07-29 03:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 03:20:44 --> Input Class Initialized
INFO - 2020-07-29 03:20:44 --> Language Class Initialized
INFO - 2020-07-29 03:20:44 --> Loader Class Initialized
INFO - 2020-07-29 03:20:44 --> Helper loaded: url_helper
INFO - 2020-07-29 03:20:44 --> Database Driver Class Initialized
INFO - 2020-07-29 03:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 03:20:44 --> Email Class Initialized
INFO - 2020-07-29 03:20:44 --> Controller Class Initialized
INFO - 2020-07-29 03:20:44 --> Model Class Initialized
INFO - 2020-07-29 03:20:44 --> Model Class Initialized
DEBUG - 2020-07-29 03:20:44 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 03:20:46 --> Config Class Initialized
INFO - 2020-07-29 03:20:46 --> Hooks Class Initialized
DEBUG - 2020-07-29 03:20:46 --> UTF-8 Support Enabled
INFO - 2020-07-29 03:20:46 --> Utf8 Class Initialized
INFO - 2020-07-29 03:20:46 --> URI Class Initialized
INFO - 2020-07-29 03:20:46 --> Router Class Initialized
INFO - 2020-07-29 03:20:46 --> Output Class Initialized
INFO - 2020-07-29 03:20:46 --> Security Class Initialized
DEBUG - 2020-07-29 03:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 03:20:46 --> Input Class Initialized
INFO - 2020-07-29 03:20:46 --> Language Class Initialized
INFO - 2020-07-29 03:20:46 --> Loader Class Initialized
INFO - 2020-07-29 03:20:46 --> Helper loaded: url_helper
INFO - 2020-07-29 03:20:46 --> Database Driver Class Initialized
INFO - 2020-07-29 03:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 03:20:46 --> Email Class Initialized
INFO - 2020-07-29 03:20:46 --> Controller Class Initialized
DEBUG - 2020-07-29 03:20:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 03:20:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 03:20:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 03:20:46 --> Final output sent to browser
DEBUG - 2020-07-29 03:20:46 --> Total execution time: 0.0261
INFO - 2020-07-29 03:20:50 --> Config Class Initialized
INFO - 2020-07-29 03:20:50 --> Hooks Class Initialized
DEBUG - 2020-07-29 03:20:50 --> UTF-8 Support Enabled
INFO - 2020-07-29 03:20:50 --> Utf8 Class Initialized
INFO - 2020-07-29 03:20:50 --> URI Class Initialized
INFO - 2020-07-29 03:20:50 --> Router Class Initialized
INFO - 2020-07-29 03:20:50 --> Output Class Initialized
INFO - 2020-07-29 03:20:50 --> Security Class Initialized
DEBUG - 2020-07-29 03:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 03:20:50 --> Input Class Initialized
INFO - 2020-07-29 03:20:50 --> Language Class Initialized
INFO - 2020-07-29 03:20:50 --> Loader Class Initialized
INFO - 2020-07-29 03:20:50 --> Helper loaded: url_helper
INFO - 2020-07-29 03:20:50 --> Database Driver Class Initialized
INFO - 2020-07-29 03:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 03:20:50 --> Email Class Initialized
INFO - 2020-07-29 03:20:50 --> Controller Class Initialized
DEBUG - 2020-07-29 03:20:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 03:20:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 03:20:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 03:20:50 --> Final output sent to browser
DEBUG - 2020-07-29 03:20:50 --> Total execution time: 0.0204
INFO - 2020-07-29 03:20:51 --> Config Class Initialized
INFO - 2020-07-29 03:20:51 --> Hooks Class Initialized
DEBUG - 2020-07-29 03:20:51 --> UTF-8 Support Enabled
INFO - 2020-07-29 03:20:51 --> Utf8 Class Initialized
INFO - 2020-07-29 03:20:51 --> URI Class Initialized
INFO - 2020-07-29 03:20:51 --> Router Class Initialized
INFO - 2020-07-29 03:20:51 --> Output Class Initialized
INFO - 2020-07-29 03:20:51 --> Security Class Initialized
DEBUG - 2020-07-29 03:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 03:20:51 --> Input Class Initialized
INFO - 2020-07-29 03:20:51 --> Language Class Initialized
INFO - 2020-07-29 03:20:51 --> Loader Class Initialized
INFO - 2020-07-29 03:20:51 --> Helper loaded: url_helper
INFO - 2020-07-29 03:20:51 --> Database Driver Class Initialized
INFO - 2020-07-29 03:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 03:20:51 --> Email Class Initialized
INFO - 2020-07-29 03:20:51 --> Controller Class Initialized
DEBUG - 2020-07-29 03:20:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 03:20:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 03:20:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-29 03:20:51 --> Final output sent to browser
DEBUG - 2020-07-29 03:20:51 --> Total execution time: 0.0207
INFO - 2020-07-29 03:21:13 --> Config Class Initialized
INFO - 2020-07-29 03:21:13 --> Hooks Class Initialized
DEBUG - 2020-07-29 03:21:13 --> UTF-8 Support Enabled
INFO - 2020-07-29 03:21:13 --> Utf8 Class Initialized
INFO - 2020-07-29 03:21:13 --> URI Class Initialized
INFO - 2020-07-29 03:21:13 --> Router Class Initialized
INFO - 2020-07-29 03:21:13 --> Output Class Initialized
INFO - 2020-07-29 03:21:13 --> Security Class Initialized
DEBUG - 2020-07-29 03:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 03:21:13 --> Input Class Initialized
INFO - 2020-07-29 03:21:13 --> Language Class Initialized
INFO - 2020-07-29 03:21:13 --> Loader Class Initialized
INFO - 2020-07-29 03:21:13 --> Helper loaded: url_helper
INFO - 2020-07-29 03:21:13 --> Database Driver Class Initialized
INFO - 2020-07-29 03:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 03:21:13 --> Email Class Initialized
INFO - 2020-07-29 03:21:13 --> Controller Class Initialized
DEBUG - 2020-07-29 03:21:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 03:21:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 03:21:13 --> Model Class Initialized
INFO - 2020-07-29 03:21:13 --> Model Class Initialized
ERROR - 2020-07-29 03:21:13 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2020-07-29 03:21:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 03:21:13 --> Severity: Error --> Call to undefined method CI_DB_mysql_result::next_result() /home/purpu1ex/public_html/carsm/application/models/Admin_model.php 25
INFO - 2020-07-29 03:21:18 --> Config Class Initialized
INFO - 2020-07-29 03:21:18 --> Hooks Class Initialized
DEBUG - 2020-07-29 03:21:18 --> UTF-8 Support Enabled
INFO - 2020-07-29 03:21:18 --> Utf8 Class Initialized
INFO - 2020-07-29 03:21:18 --> URI Class Initialized
INFO - 2020-07-29 03:21:18 --> Router Class Initialized
INFO - 2020-07-29 03:21:18 --> Output Class Initialized
INFO - 2020-07-29 03:21:18 --> Security Class Initialized
DEBUG - 2020-07-29 03:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 03:21:18 --> Input Class Initialized
INFO - 2020-07-29 03:21:18 --> Language Class Initialized
INFO - 2020-07-29 03:21:18 --> Loader Class Initialized
INFO - 2020-07-29 03:21:18 --> Helper loaded: url_helper
INFO - 2020-07-29 03:21:18 --> Database Driver Class Initialized
INFO - 2020-07-29 03:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 03:21:18 --> Email Class Initialized
INFO - 2020-07-29 03:21:18 --> Controller Class Initialized
DEBUG - 2020-07-29 03:21:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 03:21:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 03:21:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-29 03:21:18 --> Final output sent to browser
DEBUG - 2020-07-29 03:21:18 --> Total execution time: 0.0223
INFO - 2020-07-29 03:23:46 --> Config Class Initialized
INFO - 2020-07-29 03:23:46 --> Hooks Class Initialized
DEBUG - 2020-07-29 03:23:46 --> UTF-8 Support Enabled
INFO - 2020-07-29 03:23:46 --> Utf8 Class Initialized
INFO - 2020-07-29 03:23:46 --> URI Class Initialized
INFO - 2020-07-29 03:23:46 --> Router Class Initialized
INFO - 2020-07-29 03:23:46 --> Output Class Initialized
INFO - 2020-07-29 03:23:46 --> Security Class Initialized
DEBUG - 2020-07-29 03:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 03:23:46 --> Input Class Initialized
INFO - 2020-07-29 03:23:46 --> Language Class Initialized
INFO - 2020-07-29 03:23:46 --> Loader Class Initialized
INFO - 2020-07-29 03:23:46 --> Helper loaded: url_helper
INFO - 2020-07-29 03:23:46 --> Database Driver Class Initialized
INFO - 2020-07-29 03:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 03:23:46 --> Email Class Initialized
INFO - 2020-07-29 03:23:46 --> Controller Class Initialized
DEBUG - 2020-07-29 03:23:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 03:23:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 03:23:46 --> Model Class Initialized
INFO - 2020-07-29 03:23:46 --> Model Class Initialized
ERROR - 2020-07-29 03:23:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2020-07-29 03:23:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 03:23:46 --> Severity: Error --> Call to undefined method CI_DB_mysql_result::next_result() /home/purpu1ex/public_html/carsm/application/models/Admin_model.php 26
INFO - 2020-07-29 03:24:49 --> Config Class Initialized
INFO - 2020-07-29 03:24:49 --> Hooks Class Initialized
DEBUG - 2020-07-29 03:24:49 --> UTF-8 Support Enabled
INFO - 2020-07-29 03:24:49 --> Utf8 Class Initialized
INFO - 2020-07-29 03:24:49 --> URI Class Initialized
INFO - 2020-07-29 03:24:49 --> Router Class Initialized
INFO - 2020-07-29 03:24:49 --> Output Class Initialized
INFO - 2020-07-29 03:24:49 --> Security Class Initialized
DEBUG - 2020-07-29 03:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 03:24:49 --> Input Class Initialized
INFO - 2020-07-29 03:24:49 --> Language Class Initialized
INFO - 2020-07-29 03:24:49 --> Loader Class Initialized
INFO - 2020-07-29 03:24:49 --> Helper loaded: url_helper
INFO - 2020-07-29 03:24:49 --> Database Driver Class Initialized
INFO - 2020-07-29 03:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 03:24:49 --> Email Class Initialized
INFO - 2020-07-29 03:24:49 --> Controller Class Initialized
DEBUG - 2020-07-29 03:24:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 03:24:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 03:24:49 --> Model Class Initialized
INFO - 2020-07-29 03:24:49 --> Model Class Initialized
ERROR - 2020-07-29 03:24:49 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
INFO - 2020-07-29 03:24:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 03:24:49 --> Final output sent to browser
DEBUG - 2020-07-29 03:24:49 --> Total execution time: 0.0283
INFO - 2020-07-29 03:26:13 --> Config Class Initialized
INFO - 2020-07-29 03:26:13 --> Hooks Class Initialized
DEBUG - 2020-07-29 03:26:13 --> UTF-8 Support Enabled
INFO - 2020-07-29 03:26:13 --> Utf8 Class Initialized
INFO - 2020-07-29 03:26:13 --> URI Class Initialized
INFO - 2020-07-29 03:26:13 --> Router Class Initialized
INFO - 2020-07-29 03:26:13 --> Output Class Initialized
INFO - 2020-07-29 03:26:13 --> Security Class Initialized
DEBUG - 2020-07-29 03:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 03:26:13 --> Input Class Initialized
INFO - 2020-07-29 03:26:13 --> Language Class Initialized
INFO - 2020-07-29 03:26:13 --> Loader Class Initialized
INFO - 2020-07-29 03:26:13 --> Helper loaded: url_helper
INFO - 2020-07-29 03:26:13 --> Database Driver Class Initialized
INFO - 2020-07-29 03:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 03:26:13 --> Email Class Initialized
INFO - 2020-07-29 03:26:13 --> Controller Class Initialized
DEBUG - 2020-07-29 03:26:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 03:26:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 03:26:13 --> Model Class Initialized
INFO - 2020-07-29 03:26:13 --> Model Class Initialized
ERROR - 2020-07-29 03:26:13 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2020-07-29 03:26:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 03:26:13 --> Severity: Error --> Call to undefined method CI_DB_mysql_result::next_result() /home/purpu1ex/public_html/carsm/application/models/Admin_model.php 26
INFO - 2020-07-29 03:28:37 --> Config Class Initialized
INFO - 2020-07-29 03:28:37 --> Hooks Class Initialized
DEBUG - 2020-07-29 03:28:37 --> UTF-8 Support Enabled
INFO - 2020-07-29 03:28:37 --> Utf8 Class Initialized
INFO - 2020-07-29 03:28:37 --> URI Class Initialized
INFO - 2020-07-29 03:28:37 --> Router Class Initialized
INFO - 2020-07-29 03:28:37 --> Output Class Initialized
INFO - 2020-07-29 03:28:37 --> Security Class Initialized
DEBUG - 2020-07-29 03:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 03:28:37 --> Input Class Initialized
INFO - 2020-07-29 03:28:37 --> Language Class Initialized
INFO - 2020-07-29 03:28:37 --> Loader Class Initialized
INFO - 2020-07-29 03:28:37 --> Helper loaded: url_helper
INFO - 2020-07-29 03:28:37 --> Database Driver Class Initialized
INFO - 2020-07-29 03:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 03:28:37 --> Email Class Initialized
INFO - 2020-07-29 03:28:37 --> Controller Class Initialized
DEBUG - 2020-07-29 03:28:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 03:28:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 03:28:37 --> Model Class Initialized
INFO - 2020-07-29 03:28:37 --> Model Class Initialized
ERROR - 2020-07-29 03:28:37 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2020-07-29 03:28:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 03:28:37 --> Severity: Error --> Call to undefined method CI_DB_mysql_result::next_result() /home/purpu1ex/public_html/carsm/application/models/Admin_model.php 26
INFO - 2020-07-29 03:28:43 --> Config Class Initialized
INFO - 2020-07-29 03:28:43 --> Hooks Class Initialized
DEBUG - 2020-07-29 03:28:43 --> UTF-8 Support Enabled
INFO - 2020-07-29 03:28:43 --> Utf8 Class Initialized
INFO - 2020-07-29 03:28:43 --> URI Class Initialized
INFO - 2020-07-29 03:28:43 --> Router Class Initialized
INFO - 2020-07-29 03:28:43 --> Output Class Initialized
INFO - 2020-07-29 03:28:43 --> Security Class Initialized
DEBUG - 2020-07-29 03:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 03:28:43 --> Input Class Initialized
INFO - 2020-07-29 03:28:43 --> Language Class Initialized
INFO - 2020-07-29 03:28:43 --> Loader Class Initialized
INFO - 2020-07-29 03:28:43 --> Helper loaded: url_helper
INFO - 2020-07-29 03:28:43 --> Database Driver Class Initialized
INFO - 2020-07-29 03:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 03:28:43 --> Email Class Initialized
INFO - 2020-07-29 03:28:43 --> Controller Class Initialized
DEBUG - 2020-07-29 03:28:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 03:28:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 03:28:43 --> Model Class Initialized
INFO - 2020-07-29 03:28:43 --> Model Class Initialized
ERROR - 2020-07-29 03:28:43 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2020-07-29 03:28:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 03:28:43 --> Severity: Error --> Call to undefined method CI_DB_mysql_result::next_result() /home/purpu1ex/public_html/carsm/application/models/Admin_model.php 26
INFO - 2020-07-29 03:33:08 --> Config Class Initialized
INFO - 2020-07-29 03:33:08 --> Hooks Class Initialized
DEBUG - 2020-07-29 03:33:08 --> UTF-8 Support Enabled
INFO - 2020-07-29 03:33:08 --> Utf8 Class Initialized
INFO - 2020-07-29 03:33:08 --> URI Class Initialized
INFO - 2020-07-29 03:33:08 --> Router Class Initialized
INFO - 2020-07-29 03:33:08 --> Output Class Initialized
INFO - 2020-07-29 03:33:08 --> Security Class Initialized
DEBUG - 2020-07-29 03:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 03:33:08 --> Input Class Initialized
INFO - 2020-07-29 03:33:08 --> Language Class Initialized
INFO - 2020-07-29 03:33:08 --> Loader Class Initialized
INFO - 2020-07-29 03:33:08 --> Helper loaded: url_helper
INFO - 2020-07-29 03:33:08 --> Database Driver Class Initialized
INFO - 2020-07-29 03:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 03:33:08 --> Email Class Initialized
INFO - 2020-07-29 03:33:08 --> Controller Class Initialized
DEBUG - 2020-07-29 03:33:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 03:33:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 03:33:08 --> Model Class Initialized
INFO - 2020-07-29 03:33:08 --> Model Class Initialized
ERROR - 2020-07-29 03:33:08 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2020-07-29 03:33:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 03:33:08 --> Severity: Error --> Call to undefined method CI_DB_mysql_result::next_result() /home/purpu1ex/public_html/carsm/application/models/Admin_model.php 26
INFO - 2020-07-29 03:33:28 --> Config Class Initialized
INFO - 2020-07-29 03:33:28 --> Hooks Class Initialized
DEBUG - 2020-07-29 03:33:28 --> UTF-8 Support Enabled
INFO - 2020-07-29 03:33:28 --> Utf8 Class Initialized
INFO - 2020-07-29 03:33:28 --> URI Class Initialized
INFO - 2020-07-29 03:33:28 --> Router Class Initialized
INFO - 2020-07-29 03:33:28 --> Output Class Initialized
INFO - 2020-07-29 03:33:28 --> Security Class Initialized
DEBUG - 2020-07-29 03:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 03:33:28 --> Input Class Initialized
INFO - 2020-07-29 03:33:28 --> Language Class Initialized
INFO - 2020-07-29 03:33:28 --> Loader Class Initialized
INFO - 2020-07-29 03:33:28 --> Helper loaded: url_helper
INFO - 2020-07-29 03:33:28 --> Database Driver Class Initialized
INFO - 2020-07-29 03:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 03:33:28 --> Email Class Initialized
INFO - 2020-07-29 03:33:28 --> Controller Class Initialized
DEBUG - 2020-07-29 03:33:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 03:33:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 03:33:28 --> Model Class Initialized
INFO - 2020-07-29 03:33:28 --> Model Class Initialized
ERROR - 2020-07-29 03:33:28 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
INFO - 2020-07-29 03:33:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 03:33:28 --> Final output sent to browser
DEBUG - 2020-07-29 03:33:28 --> Total execution time: 0.0330
INFO - 2020-07-29 03:33:50 --> Config Class Initialized
INFO - 2020-07-29 03:33:50 --> Hooks Class Initialized
DEBUG - 2020-07-29 03:33:50 --> UTF-8 Support Enabled
INFO - 2020-07-29 03:33:50 --> Utf8 Class Initialized
INFO - 2020-07-29 03:33:50 --> URI Class Initialized
INFO - 2020-07-29 03:33:50 --> Router Class Initialized
INFO - 2020-07-29 03:33:50 --> Output Class Initialized
INFO - 2020-07-29 03:33:50 --> Security Class Initialized
DEBUG - 2020-07-29 03:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 03:33:50 --> Input Class Initialized
INFO - 2020-07-29 03:33:50 --> Language Class Initialized
INFO - 2020-07-29 03:33:50 --> Loader Class Initialized
INFO - 2020-07-29 03:33:50 --> Helper loaded: url_helper
INFO - 2020-07-29 03:33:50 --> Database Driver Class Initialized
INFO - 2020-07-29 03:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 03:33:50 --> Email Class Initialized
INFO - 2020-07-29 03:33:50 --> Controller Class Initialized
DEBUG - 2020-07-29 03:33:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 03:33:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 03:33:50 --> Model Class Initialized
INFO - 2020-07-29 03:33:50 --> Model Class Initialized
ERROR - 2020-07-29 03:33:50 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
INFO - 2020-07-29 03:33:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 03:33:50 --> Final output sent to browser
DEBUG - 2020-07-29 03:33:50 --> Total execution time: 0.0238
INFO - 2020-07-29 03:34:57 --> Config Class Initialized
INFO - 2020-07-29 03:34:57 --> Hooks Class Initialized
DEBUG - 2020-07-29 03:34:57 --> UTF-8 Support Enabled
INFO - 2020-07-29 03:34:57 --> Utf8 Class Initialized
INFO - 2020-07-29 03:34:57 --> URI Class Initialized
INFO - 2020-07-29 03:34:57 --> Router Class Initialized
INFO - 2020-07-29 03:34:57 --> Output Class Initialized
INFO - 2020-07-29 03:34:57 --> Security Class Initialized
DEBUG - 2020-07-29 03:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 03:34:57 --> Input Class Initialized
INFO - 2020-07-29 03:34:57 --> Language Class Initialized
INFO - 2020-07-29 03:34:57 --> Loader Class Initialized
INFO - 2020-07-29 03:34:57 --> Helper loaded: url_helper
INFO - 2020-07-29 03:34:57 --> Database Driver Class Initialized
INFO - 2020-07-29 03:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 03:34:57 --> Email Class Initialized
INFO - 2020-07-29 03:34:57 --> Controller Class Initialized
DEBUG - 2020-07-29 03:34:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 03:34:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 03:34:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-29 03:34:57 --> Final output sent to browser
DEBUG - 2020-07-29 03:34:57 --> Total execution time: 0.0213
INFO - 2020-07-29 03:34:59 --> Config Class Initialized
INFO - 2020-07-29 03:34:59 --> Hooks Class Initialized
DEBUG - 2020-07-29 03:34:59 --> UTF-8 Support Enabled
INFO - 2020-07-29 03:34:59 --> Utf8 Class Initialized
INFO - 2020-07-29 03:34:59 --> URI Class Initialized
INFO - 2020-07-29 03:34:59 --> Router Class Initialized
INFO - 2020-07-29 03:34:59 --> Output Class Initialized
INFO - 2020-07-29 03:34:59 --> Security Class Initialized
DEBUG - 2020-07-29 03:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 03:34:59 --> Input Class Initialized
INFO - 2020-07-29 03:34:59 --> Language Class Initialized
INFO - 2020-07-29 03:34:59 --> Loader Class Initialized
INFO - 2020-07-29 03:34:59 --> Helper loaded: url_helper
INFO - 2020-07-29 03:34:59 --> Database Driver Class Initialized
INFO - 2020-07-29 03:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 03:34:59 --> Email Class Initialized
INFO - 2020-07-29 03:34:59 --> Controller Class Initialized
DEBUG - 2020-07-29 03:34:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 03:34:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 03:34:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 03:34:59 --> Final output sent to browser
DEBUG - 2020-07-29 03:34:59 --> Total execution time: 0.0234
INFO - 2020-07-29 03:36:13 --> Config Class Initialized
INFO - 2020-07-29 03:36:13 --> Hooks Class Initialized
DEBUG - 2020-07-29 03:36:13 --> UTF-8 Support Enabled
INFO - 2020-07-29 03:36:13 --> Utf8 Class Initialized
INFO - 2020-07-29 03:36:13 --> URI Class Initialized
INFO - 2020-07-29 03:36:13 --> Router Class Initialized
INFO - 2020-07-29 03:36:13 --> Output Class Initialized
INFO - 2020-07-29 03:36:13 --> Security Class Initialized
DEBUG - 2020-07-29 03:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 03:36:13 --> Input Class Initialized
INFO - 2020-07-29 03:36:13 --> Language Class Initialized
INFO - 2020-07-29 03:36:13 --> Loader Class Initialized
INFO - 2020-07-29 03:36:13 --> Helper loaded: url_helper
INFO - 2020-07-29 03:36:13 --> Database Driver Class Initialized
INFO - 2020-07-29 03:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 03:36:13 --> Email Class Initialized
INFO - 2020-07-29 03:36:13 --> Controller Class Initialized
DEBUG - 2020-07-29 03:36:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 03:36:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 03:36:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 03:36:13 --> Final output sent to browser
DEBUG - 2020-07-29 03:36:13 --> Total execution time: 0.0222
INFO - 2020-07-29 03:36:15 --> Config Class Initialized
INFO - 2020-07-29 03:36:15 --> Hooks Class Initialized
DEBUG - 2020-07-29 03:36:15 --> UTF-8 Support Enabled
INFO - 2020-07-29 03:36:15 --> Utf8 Class Initialized
INFO - 2020-07-29 03:36:15 --> URI Class Initialized
INFO - 2020-07-29 03:36:15 --> Router Class Initialized
INFO - 2020-07-29 03:36:15 --> Output Class Initialized
INFO - 2020-07-29 03:36:15 --> Security Class Initialized
DEBUG - 2020-07-29 03:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 03:36:15 --> Input Class Initialized
INFO - 2020-07-29 03:36:15 --> Language Class Initialized
INFO - 2020-07-29 03:36:15 --> Loader Class Initialized
INFO - 2020-07-29 03:36:15 --> Helper loaded: url_helper
INFO - 2020-07-29 03:36:15 --> Database Driver Class Initialized
INFO - 2020-07-29 03:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 03:36:15 --> Email Class Initialized
INFO - 2020-07-29 03:36:15 --> Controller Class Initialized
DEBUG - 2020-07-29 03:36:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 03:36:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 03:36:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-29 03:36:15 --> Final output sent to browser
DEBUG - 2020-07-29 03:36:15 --> Total execution time: 0.0227
INFO - 2020-07-29 03:36:37 --> Config Class Initialized
INFO - 2020-07-29 03:36:37 --> Hooks Class Initialized
DEBUG - 2020-07-29 03:36:37 --> UTF-8 Support Enabled
INFO - 2020-07-29 03:36:37 --> Utf8 Class Initialized
INFO - 2020-07-29 03:36:37 --> URI Class Initialized
INFO - 2020-07-29 03:36:37 --> Router Class Initialized
INFO - 2020-07-29 03:36:37 --> Output Class Initialized
INFO - 2020-07-29 03:36:37 --> Security Class Initialized
DEBUG - 2020-07-29 03:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 03:36:37 --> Input Class Initialized
INFO - 2020-07-29 03:36:37 --> Language Class Initialized
INFO - 2020-07-29 03:36:37 --> Loader Class Initialized
INFO - 2020-07-29 03:36:37 --> Helper loaded: url_helper
INFO - 2020-07-29 03:36:37 --> Database Driver Class Initialized
INFO - 2020-07-29 03:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 03:36:37 --> Email Class Initialized
INFO - 2020-07-29 03:36:37 --> Controller Class Initialized
DEBUG - 2020-07-29 03:36:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 03:36:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 03:36:37 --> Model Class Initialized
INFO - 2020-07-29 03:36:37 --> Model Class Initialized
ERROR - 2020-07-29 03:36:37 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
INFO - 2020-07-29 03:36:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 03:36:37 --> Final output sent to browser
DEBUG - 2020-07-29 03:36:37 --> Total execution time: 0.0254
INFO - 2020-07-29 03:37:24 --> Config Class Initialized
INFO - 2020-07-29 03:37:24 --> Hooks Class Initialized
DEBUG - 2020-07-29 03:37:24 --> UTF-8 Support Enabled
INFO - 2020-07-29 03:37:24 --> Utf8 Class Initialized
INFO - 2020-07-29 03:37:24 --> URI Class Initialized
INFO - 2020-07-29 03:37:24 --> Router Class Initialized
INFO - 2020-07-29 03:37:24 --> Output Class Initialized
INFO - 2020-07-29 03:37:24 --> Security Class Initialized
DEBUG - 2020-07-29 03:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 03:37:24 --> Input Class Initialized
INFO - 2020-07-29 03:37:24 --> Language Class Initialized
INFO - 2020-07-29 03:37:24 --> Loader Class Initialized
INFO - 2020-07-29 03:37:24 --> Helper loaded: url_helper
INFO - 2020-07-29 03:37:24 --> Database Driver Class Initialized
INFO - 2020-07-29 03:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 03:37:24 --> Email Class Initialized
INFO - 2020-07-29 03:37:24 --> Controller Class Initialized
DEBUG - 2020-07-29 03:37:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 03:37:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 03:37:24 --> Model Class Initialized
INFO - 2020-07-29 03:37:24 --> Model Class Initialized
ERROR - 2020-07-29 03:37:24 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2020-07-29 03:37:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 03:37:24 --> Severity: Error --> Call to undefined method CI_DB_mysql_result::next_result() /home/purpu1ex/public_html/carsm/application/models/Admin_model.php 26
INFO - 2020-07-29 03:59:09 --> Config Class Initialized
INFO - 2020-07-29 03:59:09 --> Hooks Class Initialized
DEBUG - 2020-07-29 03:59:09 --> UTF-8 Support Enabled
INFO - 2020-07-29 03:59:09 --> Utf8 Class Initialized
INFO - 2020-07-29 03:59:09 --> URI Class Initialized
INFO - 2020-07-29 03:59:09 --> Router Class Initialized
INFO - 2020-07-29 03:59:09 --> Output Class Initialized
INFO - 2020-07-29 03:59:09 --> Security Class Initialized
DEBUG - 2020-07-29 03:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 03:59:09 --> Input Class Initialized
INFO - 2020-07-29 03:59:09 --> Language Class Initialized
INFO - 2020-07-29 03:59:09 --> Loader Class Initialized
INFO - 2020-07-29 03:59:09 --> Helper loaded: url_helper
INFO - 2020-07-29 03:59:09 --> Database Driver Class Initialized
INFO - 2020-07-29 03:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 03:59:09 --> Email Class Initialized
INFO - 2020-07-29 03:59:09 --> Controller Class Initialized
DEBUG - 2020-07-29 03:59:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 03:59:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 03:59:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-29 03:59:09 --> Final output sent to browser
DEBUG - 2020-07-29 03:59:09 --> Total execution time: 0.0221
INFO - 2020-07-29 03:59:12 --> Config Class Initialized
INFO - 2020-07-29 03:59:12 --> Hooks Class Initialized
DEBUG - 2020-07-29 03:59:12 --> UTF-8 Support Enabled
INFO - 2020-07-29 03:59:12 --> Utf8 Class Initialized
INFO - 2020-07-29 03:59:12 --> URI Class Initialized
INFO - 2020-07-29 03:59:12 --> Router Class Initialized
INFO - 2020-07-29 03:59:12 --> Output Class Initialized
INFO - 2020-07-29 03:59:12 --> Security Class Initialized
DEBUG - 2020-07-29 03:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 03:59:12 --> Input Class Initialized
INFO - 2020-07-29 03:59:12 --> Language Class Initialized
INFO - 2020-07-29 03:59:12 --> Loader Class Initialized
INFO - 2020-07-29 03:59:12 --> Helper loaded: url_helper
INFO - 2020-07-29 03:59:12 --> Database Driver Class Initialized
INFO - 2020-07-29 03:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 03:59:12 --> Email Class Initialized
INFO - 2020-07-29 03:59:12 --> Controller Class Initialized
DEBUG - 2020-07-29 03:59:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 03:59:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 03:59:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 03:59:12 --> Final output sent to browser
DEBUG - 2020-07-29 03:59:12 --> Total execution time: 0.0216
INFO - 2020-07-29 04:06:33 --> Config Class Initialized
INFO - 2020-07-29 04:06:33 --> Hooks Class Initialized
DEBUG - 2020-07-29 04:06:33 --> UTF-8 Support Enabled
INFO - 2020-07-29 04:06:33 --> Utf8 Class Initialized
INFO - 2020-07-29 04:06:33 --> URI Class Initialized
INFO - 2020-07-29 04:06:33 --> Router Class Initialized
INFO - 2020-07-29 04:06:33 --> Output Class Initialized
INFO - 2020-07-29 04:06:33 --> Security Class Initialized
DEBUG - 2020-07-29 04:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 04:06:33 --> Input Class Initialized
INFO - 2020-07-29 04:06:33 --> Language Class Initialized
INFO - 2020-07-29 04:06:33 --> Loader Class Initialized
INFO - 2020-07-29 04:06:33 --> Helper loaded: url_helper
INFO - 2020-07-29 04:06:33 --> Database Driver Class Initialized
INFO - 2020-07-29 04:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 04:06:33 --> Email Class Initialized
INFO - 2020-07-29 04:06:33 --> Controller Class Initialized
DEBUG - 2020-07-29 04:06:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 04:06:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 04:06:33 --> Model Class Initialized
INFO - 2020-07-29 04:06:33 --> Model Class Initialized
ERROR - 2020-07-29 04:06:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/Admin_model.php:63) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 04:06:33 --> Severity: Error --> Call to undefined method CI_DB_mysql_result::next_result() /home/purpu1ex/public_html/carsm/application/models/Admin_model.php 63
INFO - 2020-07-29 04:06:45 --> Config Class Initialized
INFO - 2020-07-29 04:06:45 --> Hooks Class Initialized
DEBUG - 2020-07-29 04:06:45 --> UTF-8 Support Enabled
INFO - 2020-07-29 04:06:45 --> Utf8 Class Initialized
INFO - 2020-07-29 04:06:45 --> URI Class Initialized
INFO - 2020-07-29 04:06:45 --> Router Class Initialized
INFO - 2020-07-29 04:06:45 --> Output Class Initialized
INFO - 2020-07-29 04:06:45 --> Security Class Initialized
DEBUG - 2020-07-29 04:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 04:06:45 --> Input Class Initialized
INFO - 2020-07-29 04:06:45 --> Language Class Initialized
INFO - 2020-07-29 04:06:45 --> Loader Class Initialized
INFO - 2020-07-29 04:06:45 --> Helper loaded: url_helper
INFO - 2020-07-29 04:06:45 --> Database Driver Class Initialized
INFO - 2020-07-29 04:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 04:06:45 --> Email Class Initialized
INFO - 2020-07-29 04:06:45 --> Controller Class Initialized
DEBUG - 2020-07-29 04:06:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 04:06:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 04:06:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-29 04:06:45 --> Final output sent to browser
DEBUG - 2020-07-29 04:06:45 --> Total execution time: 0.0211
INFO - 2020-07-29 04:06:48 --> Config Class Initialized
INFO - 2020-07-29 04:06:48 --> Hooks Class Initialized
DEBUG - 2020-07-29 04:06:48 --> UTF-8 Support Enabled
INFO - 2020-07-29 04:06:48 --> Utf8 Class Initialized
INFO - 2020-07-29 04:06:48 --> URI Class Initialized
DEBUG - 2020-07-29 04:06:48 --> No URI present. Default controller set.
INFO - 2020-07-29 04:06:48 --> Router Class Initialized
INFO - 2020-07-29 04:06:48 --> Output Class Initialized
INFO - 2020-07-29 04:06:48 --> Security Class Initialized
DEBUG - 2020-07-29 04:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 04:06:48 --> Input Class Initialized
INFO - 2020-07-29 04:06:48 --> Language Class Initialized
INFO - 2020-07-29 04:06:48 --> Loader Class Initialized
INFO - 2020-07-29 04:06:48 --> Helper loaded: url_helper
INFO - 2020-07-29 04:06:48 --> Database Driver Class Initialized
INFO - 2020-07-29 04:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 04:06:48 --> Email Class Initialized
INFO - 2020-07-29 04:06:48 --> Controller Class Initialized
INFO - 2020-07-29 04:06:48 --> Model Class Initialized
INFO - 2020-07-29 04:06:48 --> Model Class Initialized
DEBUG - 2020-07-29 04:06:48 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 04:06:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 04:06:48 --> Final output sent to browser
DEBUG - 2020-07-29 04:06:48 --> Total execution time: 0.0212
INFO - 2020-07-29 04:06:51 --> Config Class Initialized
INFO - 2020-07-29 04:06:51 --> Hooks Class Initialized
DEBUG - 2020-07-29 04:06:51 --> UTF-8 Support Enabled
INFO - 2020-07-29 04:06:51 --> Utf8 Class Initialized
INFO - 2020-07-29 04:06:51 --> URI Class Initialized
INFO - 2020-07-29 04:06:51 --> Router Class Initialized
INFO - 2020-07-29 04:06:51 --> Output Class Initialized
INFO - 2020-07-29 04:06:51 --> Security Class Initialized
DEBUG - 2020-07-29 04:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 04:06:51 --> Input Class Initialized
INFO - 2020-07-29 04:06:51 --> Language Class Initialized
INFO - 2020-07-29 04:06:51 --> Loader Class Initialized
INFO - 2020-07-29 04:06:51 --> Helper loaded: url_helper
INFO - 2020-07-29 04:06:51 --> Database Driver Class Initialized
INFO - 2020-07-29 04:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 04:06:51 --> Email Class Initialized
INFO - 2020-07-29 04:06:51 --> Controller Class Initialized
INFO - 2020-07-29 04:06:51 --> Model Class Initialized
INFO - 2020-07-29 04:06:51 --> Model Class Initialized
DEBUG - 2020-07-29 04:06:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 04:06:51 --> Config Class Initialized
INFO - 2020-07-29 04:06:51 --> Hooks Class Initialized
DEBUG - 2020-07-29 04:06:51 --> UTF-8 Support Enabled
INFO - 2020-07-29 04:06:51 --> Utf8 Class Initialized
INFO - 2020-07-29 04:06:51 --> URI Class Initialized
INFO - 2020-07-29 04:06:51 --> Router Class Initialized
INFO - 2020-07-29 04:06:51 --> Output Class Initialized
INFO - 2020-07-29 04:06:51 --> Security Class Initialized
DEBUG - 2020-07-29 04:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 04:06:51 --> Input Class Initialized
INFO - 2020-07-29 04:06:51 --> Language Class Initialized
INFO - 2020-07-29 04:06:51 --> Loader Class Initialized
INFO - 2020-07-29 04:06:51 --> Helper loaded: url_helper
INFO - 2020-07-29 04:06:51 --> Database Driver Class Initialized
INFO - 2020-07-29 04:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 04:06:51 --> Email Class Initialized
INFO - 2020-07-29 04:06:51 --> Controller Class Initialized
DEBUG - 2020-07-29 04:06:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 04:06:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 04:06:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 04:06:51 --> Final output sent to browser
DEBUG - 2020-07-29 04:06:51 --> Total execution time: 0.0204
INFO - 2020-07-29 04:06:54 --> Config Class Initialized
INFO - 2020-07-29 04:06:54 --> Hooks Class Initialized
DEBUG - 2020-07-29 04:06:54 --> UTF-8 Support Enabled
INFO - 2020-07-29 04:06:54 --> Utf8 Class Initialized
INFO - 2020-07-29 04:06:54 --> URI Class Initialized
INFO - 2020-07-29 04:06:54 --> Router Class Initialized
INFO - 2020-07-29 04:06:54 --> Output Class Initialized
INFO - 2020-07-29 04:06:54 --> Security Class Initialized
DEBUG - 2020-07-29 04:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 04:06:54 --> Input Class Initialized
INFO - 2020-07-29 04:06:54 --> Language Class Initialized
INFO - 2020-07-29 04:06:54 --> Loader Class Initialized
INFO - 2020-07-29 04:06:54 --> Helper loaded: url_helper
INFO - 2020-07-29 04:06:54 --> Database Driver Class Initialized
INFO - 2020-07-29 04:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 04:06:54 --> Email Class Initialized
INFO - 2020-07-29 04:06:54 --> Controller Class Initialized
DEBUG - 2020-07-29 04:06:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 04:06:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 04:06:54 --> Model Class Initialized
INFO - 2020-07-29 04:06:54 --> Model Class Initialized
ERROR - 2020-07-29 04:06:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/Admin_model.php:63) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 04:06:54 --> Severity: Error --> Call to undefined method CI_DB_mysql_result::next_result() /home/purpu1ex/public_html/carsm/application/models/Admin_model.php 63
INFO - 2020-07-29 04:07:40 --> Config Class Initialized
INFO - 2020-07-29 04:07:40 --> Hooks Class Initialized
DEBUG - 2020-07-29 04:07:40 --> UTF-8 Support Enabled
INFO - 2020-07-29 04:07:40 --> Utf8 Class Initialized
INFO - 2020-07-29 04:07:40 --> URI Class Initialized
INFO - 2020-07-29 04:07:40 --> Router Class Initialized
INFO - 2020-07-29 04:07:40 --> Output Class Initialized
INFO - 2020-07-29 04:07:40 --> Security Class Initialized
DEBUG - 2020-07-29 04:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 04:07:40 --> Input Class Initialized
INFO - 2020-07-29 04:07:40 --> Language Class Initialized
INFO - 2020-07-29 04:07:40 --> Loader Class Initialized
INFO - 2020-07-29 04:07:40 --> Helper loaded: url_helper
INFO - 2020-07-29 04:07:40 --> Database Driver Class Initialized
INFO - 2020-07-29 04:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 04:07:40 --> Email Class Initialized
INFO - 2020-07-29 04:07:40 --> Controller Class Initialized
DEBUG - 2020-07-29 04:07:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 04:07:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 04:07:40 --> Model Class Initialized
INFO - 2020-07-29 04:07:40 --> Model Class Initialized
INFO - 2020-07-29 04:07:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 04:07:40 --> Final output sent to browser
DEBUG - 2020-07-29 04:07:40 --> Total execution time: 0.0259
INFO - 2020-07-29 04:09:14 --> Config Class Initialized
INFO - 2020-07-29 04:09:14 --> Hooks Class Initialized
DEBUG - 2020-07-29 04:09:14 --> UTF-8 Support Enabled
INFO - 2020-07-29 04:09:14 --> Utf8 Class Initialized
INFO - 2020-07-29 04:09:14 --> URI Class Initialized
INFO - 2020-07-29 04:09:14 --> Router Class Initialized
INFO - 2020-07-29 04:09:14 --> Output Class Initialized
INFO - 2020-07-29 04:09:14 --> Security Class Initialized
DEBUG - 2020-07-29 04:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 04:09:14 --> Input Class Initialized
INFO - 2020-07-29 04:09:14 --> Language Class Initialized
INFO - 2020-07-29 04:09:14 --> Loader Class Initialized
INFO - 2020-07-29 04:09:14 --> Helper loaded: url_helper
INFO - 2020-07-29 04:09:14 --> Database Driver Class Initialized
INFO - 2020-07-29 04:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 04:09:14 --> Email Class Initialized
INFO - 2020-07-29 04:09:14 --> Controller Class Initialized
DEBUG - 2020-07-29 04:09:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 04:09:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 04:09:14 --> Model Class Initialized
INFO - 2020-07-29 04:09:14 --> Model Class Initialized
INFO - 2020-07-29 04:09:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 04:09:14 --> Final output sent to browser
DEBUG - 2020-07-29 04:09:14 --> Total execution time: 0.0254
INFO - 2020-07-29 04:16:30 --> Config Class Initialized
INFO - 2020-07-29 04:16:30 --> Hooks Class Initialized
DEBUG - 2020-07-29 04:16:30 --> UTF-8 Support Enabled
INFO - 2020-07-29 04:16:30 --> Utf8 Class Initialized
INFO - 2020-07-29 04:16:30 --> URI Class Initialized
INFO - 2020-07-29 04:16:30 --> Router Class Initialized
INFO - 2020-07-29 04:16:30 --> Output Class Initialized
INFO - 2020-07-29 04:16:30 --> Security Class Initialized
DEBUG - 2020-07-29 04:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 04:16:30 --> Input Class Initialized
INFO - 2020-07-29 04:16:30 --> Language Class Initialized
INFO - 2020-07-29 04:16:30 --> Loader Class Initialized
INFO - 2020-07-29 04:16:30 --> Helper loaded: url_helper
INFO - 2020-07-29 04:16:30 --> Database Driver Class Initialized
INFO - 2020-07-29 04:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 04:16:30 --> Email Class Initialized
INFO - 2020-07-29 04:16:30 --> Controller Class Initialized
DEBUG - 2020-07-29 04:16:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 04:16:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 04:16:30 --> Model Class Initialized
ERROR - 2020-07-29 04:16:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/Admin_model.php:76) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 04:16:30 --> Severity: Compile Error --> Cannot redeclare Admin_model::dealer_list() /home/purpu1ex/public_html/carsm/application/models/Admin_model.php 76
INFO - 2020-07-29 04:16:43 --> Config Class Initialized
INFO - 2020-07-29 04:16:43 --> Hooks Class Initialized
DEBUG - 2020-07-29 04:16:43 --> UTF-8 Support Enabled
INFO - 2020-07-29 04:16:43 --> Utf8 Class Initialized
INFO - 2020-07-29 04:16:43 --> URI Class Initialized
INFO - 2020-07-29 04:16:43 --> Router Class Initialized
INFO - 2020-07-29 04:16:43 --> Output Class Initialized
INFO - 2020-07-29 04:16:43 --> Security Class Initialized
DEBUG - 2020-07-29 04:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 04:16:43 --> Input Class Initialized
INFO - 2020-07-29 04:16:43 --> Language Class Initialized
INFO - 2020-07-29 04:16:43 --> Loader Class Initialized
INFO - 2020-07-29 04:16:43 --> Helper loaded: url_helper
INFO - 2020-07-29 04:16:43 --> Database Driver Class Initialized
INFO - 2020-07-29 04:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 04:16:43 --> Email Class Initialized
INFO - 2020-07-29 04:16:43 --> Controller Class Initialized
DEBUG - 2020-07-29 04:16:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 04:16:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 04:16:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 04:16:43 --> Final output sent to browser
DEBUG - 2020-07-29 04:16:43 --> Total execution time: 0.0227
INFO - 2020-07-29 04:16:47 --> Config Class Initialized
INFO - 2020-07-29 04:16:47 --> Hooks Class Initialized
DEBUG - 2020-07-29 04:16:47 --> UTF-8 Support Enabled
INFO - 2020-07-29 04:16:47 --> Utf8 Class Initialized
INFO - 2020-07-29 04:16:47 --> URI Class Initialized
INFO - 2020-07-29 04:16:47 --> Router Class Initialized
INFO - 2020-07-29 04:16:47 --> Output Class Initialized
INFO - 2020-07-29 04:16:47 --> Security Class Initialized
DEBUG - 2020-07-29 04:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 04:16:47 --> Input Class Initialized
INFO - 2020-07-29 04:16:47 --> Language Class Initialized
INFO - 2020-07-29 04:16:47 --> Loader Class Initialized
INFO - 2020-07-29 04:16:47 --> Helper loaded: url_helper
INFO - 2020-07-29 04:16:47 --> Database Driver Class Initialized
INFO - 2020-07-29 04:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 04:16:47 --> Email Class Initialized
INFO - 2020-07-29 04:16:47 --> Controller Class Initialized
DEBUG - 2020-07-29 04:16:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 04:16:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 04:16:47 --> Model Class Initialized
ERROR - 2020-07-29 04:16:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/Admin_model.php:76) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 04:16:47 --> Severity: Compile Error --> Cannot redeclare Admin_model::dealer_list() /home/purpu1ex/public_html/carsm/application/models/Admin_model.php 76
INFO - 2020-07-29 04:17:46 --> Config Class Initialized
INFO - 2020-07-29 04:17:46 --> Hooks Class Initialized
DEBUG - 2020-07-29 04:17:46 --> UTF-8 Support Enabled
INFO - 2020-07-29 04:17:46 --> Utf8 Class Initialized
INFO - 2020-07-29 04:17:46 --> URI Class Initialized
INFO - 2020-07-29 04:17:46 --> Router Class Initialized
INFO - 2020-07-29 04:17:46 --> Output Class Initialized
INFO - 2020-07-29 04:17:46 --> Security Class Initialized
DEBUG - 2020-07-29 04:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 04:17:46 --> Input Class Initialized
INFO - 2020-07-29 04:17:46 --> Language Class Initialized
INFO - 2020-07-29 04:17:46 --> Loader Class Initialized
INFO - 2020-07-29 04:17:46 --> Helper loaded: url_helper
INFO - 2020-07-29 04:17:46 --> Database Driver Class Initialized
INFO - 2020-07-29 04:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 04:17:46 --> Email Class Initialized
INFO - 2020-07-29 04:17:46 --> Controller Class Initialized
DEBUG - 2020-07-29 04:17:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 04:17:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 04:17:46 --> Model Class Initialized
INFO - 2020-07-29 04:17:46 --> Model Class Initialized
INFO - 2020-07-29 04:17:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 04:17:46 --> Final output sent to browser
DEBUG - 2020-07-29 04:17:46 --> Total execution time: 0.0242
INFO - 2020-07-29 04:17:50 --> Config Class Initialized
INFO - 2020-07-29 04:17:50 --> Hooks Class Initialized
DEBUG - 2020-07-29 04:17:50 --> UTF-8 Support Enabled
INFO - 2020-07-29 04:17:50 --> Utf8 Class Initialized
INFO - 2020-07-29 04:17:50 --> URI Class Initialized
INFO - 2020-07-29 04:17:50 --> Router Class Initialized
INFO - 2020-07-29 04:17:50 --> Output Class Initialized
INFO - 2020-07-29 04:17:50 --> Security Class Initialized
DEBUG - 2020-07-29 04:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 04:17:50 --> Input Class Initialized
INFO - 2020-07-29 04:17:50 --> Language Class Initialized
INFO - 2020-07-29 04:17:50 --> Loader Class Initialized
INFO - 2020-07-29 04:17:50 --> Helper loaded: url_helper
INFO - 2020-07-29 04:17:50 --> Database Driver Class Initialized
INFO - 2020-07-29 04:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 04:17:50 --> Email Class Initialized
INFO - 2020-07-29 04:17:50 --> Controller Class Initialized
DEBUG - 2020-07-29 04:17:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 04:17:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 04:17:50 --> Model Class Initialized
INFO - 2020-07-29 04:17:50 --> Model Class Initialized
ERROR - 2020-07-29 04:17:50 --> Query error: Incorrect number of arguments for PROCEDURE purpu1ex_carsm.dealer_edit; expected 1, got 0 - Invalid query: CALL dealer_edit()
INFO - 2020-07-29 04:17:50 --> Language file loaded: language/english/db_lang.php
INFO - 2020-07-29 04:44:40 --> Config Class Initialized
INFO - 2020-07-29 04:44:40 --> Hooks Class Initialized
DEBUG - 2020-07-29 04:44:40 --> UTF-8 Support Enabled
INFO - 2020-07-29 04:44:40 --> Utf8 Class Initialized
INFO - 2020-07-29 04:44:40 --> URI Class Initialized
DEBUG - 2020-07-29 04:44:40 --> No URI present. Default controller set.
INFO - 2020-07-29 04:44:40 --> Router Class Initialized
INFO - 2020-07-29 04:44:40 --> Output Class Initialized
INFO - 2020-07-29 04:44:40 --> Security Class Initialized
DEBUG - 2020-07-29 04:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 04:44:40 --> Input Class Initialized
INFO - 2020-07-29 04:44:40 --> Language Class Initialized
INFO - 2020-07-29 04:44:40 --> Loader Class Initialized
INFO - 2020-07-29 04:44:40 --> Helper loaded: url_helper
INFO - 2020-07-29 04:44:40 --> Database Driver Class Initialized
INFO - 2020-07-29 04:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 04:44:40 --> Email Class Initialized
INFO - 2020-07-29 04:44:40 --> Controller Class Initialized
INFO - 2020-07-29 04:44:40 --> Model Class Initialized
INFO - 2020-07-29 04:44:40 --> Model Class Initialized
DEBUG - 2020-07-29 04:44:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 04:44:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 04:44:40 --> Final output sent to browser
DEBUG - 2020-07-29 04:44:40 --> Total execution time: 0.0520
INFO - 2020-07-29 04:44:45 --> Config Class Initialized
INFO - 2020-07-29 04:44:45 --> Hooks Class Initialized
DEBUG - 2020-07-29 04:44:45 --> UTF-8 Support Enabled
INFO - 2020-07-29 04:44:45 --> Utf8 Class Initialized
INFO - 2020-07-29 04:44:45 --> URI Class Initialized
INFO - 2020-07-29 04:44:45 --> Router Class Initialized
INFO - 2020-07-29 04:44:45 --> Output Class Initialized
INFO - 2020-07-29 04:44:45 --> Security Class Initialized
DEBUG - 2020-07-29 04:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 04:44:45 --> Input Class Initialized
INFO - 2020-07-29 04:44:45 --> Language Class Initialized
INFO - 2020-07-29 04:44:45 --> Loader Class Initialized
INFO - 2020-07-29 04:44:45 --> Helper loaded: url_helper
INFO - 2020-07-29 04:44:45 --> Database Driver Class Initialized
INFO - 2020-07-29 04:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 04:44:45 --> Email Class Initialized
INFO - 2020-07-29 04:44:45 --> Controller Class Initialized
INFO - 2020-07-29 04:44:45 --> Model Class Initialized
INFO - 2020-07-29 04:44:45 --> Model Class Initialized
DEBUG - 2020-07-29 04:44:45 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 04:44:45 --> Config Class Initialized
INFO - 2020-07-29 04:44:45 --> Hooks Class Initialized
DEBUG - 2020-07-29 04:44:45 --> UTF-8 Support Enabled
INFO - 2020-07-29 04:44:45 --> Utf8 Class Initialized
INFO - 2020-07-29 04:44:45 --> URI Class Initialized
INFO - 2020-07-29 04:44:45 --> Router Class Initialized
INFO - 2020-07-29 04:44:45 --> Output Class Initialized
INFO - 2020-07-29 04:44:45 --> Security Class Initialized
DEBUG - 2020-07-29 04:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 04:44:45 --> Input Class Initialized
INFO - 2020-07-29 04:44:45 --> Language Class Initialized
INFO - 2020-07-29 04:44:45 --> Loader Class Initialized
INFO - 2020-07-29 04:44:45 --> Helper loaded: url_helper
INFO - 2020-07-29 04:44:45 --> Database Driver Class Initialized
INFO - 2020-07-29 04:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 04:44:45 --> Email Class Initialized
INFO - 2020-07-29 04:44:45 --> Controller Class Initialized
DEBUG - 2020-07-29 04:44:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 04:44:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 04:44:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 04:44:45 --> Final output sent to browser
DEBUG - 2020-07-29 04:44:45 --> Total execution time: 0.0220
INFO - 2020-07-29 04:44:52 --> Config Class Initialized
INFO - 2020-07-29 04:44:52 --> Hooks Class Initialized
DEBUG - 2020-07-29 04:44:52 --> UTF-8 Support Enabled
INFO - 2020-07-29 04:44:52 --> Utf8 Class Initialized
INFO - 2020-07-29 04:44:52 --> URI Class Initialized
INFO - 2020-07-29 04:44:52 --> Router Class Initialized
INFO - 2020-07-29 04:44:52 --> Output Class Initialized
INFO - 2020-07-29 04:44:52 --> Security Class Initialized
DEBUG - 2020-07-29 04:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 04:44:52 --> Input Class Initialized
INFO - 2020-07-29 04:44:52 --> Language Class Initialized
INFO - 2020-07-29 04:44:52 --> Loader Class Initialized
INFO - 2020-07-29 04:44:52 --> Helper loaded: url_helper
INFO - 2020-07-29 04:44:52 --> Database Driver Class Initialized
INFO - 2020-07-29 04:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 04:44:52 --> Email Class Initialized
INFO - 2020-07-29 04:44:52 --> Controller Class Initialized
DEBUG - 2020-07-29 04:44:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 04:44:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 04:44:52 --> Model Class Initialized
INFO - 2020-07-29 04:44:52 --> Model Class Initialized
INFO - 2020-07-29 04:44:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 04:44:52 --> Final output sent to browser
DEBUG - 2020-07-29 04:44:52 --> Total execution time: 0.0241
INFO - 2020-07-29 04:55:58 --> Config Class Initialized
INFO - 2020-07-29 04:55:58 --> Hooks Class Initialized
DEBUG - 2020-07-29 04:55:58 --> UTF-8 Support Enabled
INFO - 2020-07-29 04:55:58 --> Utf8 Class Initialized
INFO - 2020-07-29 04:55:58 --> URI Class Initialized
INFO - 2020-07-29 04:55:58 --> Router Class Initialized
INFO - 2020-07-29 04:55:58 --> Output Class Initialized
INFO - 2020-07-29 04:55:58 --> Security Class Initialized
DEBUG - 2020-07-29 04:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 04:55:58 --> Input Class Initialized
INFO - 2020-07-29 04:55:58 --> Language Class Initialized
INFO - 2020-07-29 04:55:58 --> Loader Class Initialized
INFO - 2020-07-29 04:55:58 --> Helper loaded: url_helper
INFO - 2020-07-29 04:55:58 --> Database Driver Class Initialized
INFO - 2020-07-29 04:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 04:55:58 --> Email Class Initialized
INFO - 2020-07-29 04:55:58 --> Controller Class Initialized
DEBUG - 2020-07-29 04:55:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 04:55:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 04:55:58 --> Model Class Initialized
INFO - 2020-07-29 04:55:59 --> Model Class Initialized
INFO - 2020-07-29 04:55:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 04:55:59 --> Final output sent to browser
DEBUG - 2020-07-29 04:55:59 --> Total execution time: 0.0381
INFO - 2020-07-29 04:56:01 --> Config Class Initialized
INFO - 2020-07-29 04:56:01 --> Hooks Class Initialized
DEBUG - 2020-07-29 04:56:01 --> UTF-8 Support Enabled
INFO - 2020-07-29 04:56:01 --> Utf8 Class Initialized
INFO - 2020-07-29 04:56:01 --> URI Class Initialized
INFO - 2020-07-29 04:56:01 --> Router Class Initialized
INFO - 2020-07-29 04:56:01 --> Output Class Initialized
INFO - 2020-07-29 04:56:01 --> Security Class Initialized
DEBUG - 2020-07-29 04:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 04:56:01 --> Input Class Initialized
INFO - 2020-07-29 04:56:01 --> Language Class Initialized
INFO - 2020-07-29 04:56:01 --> Loader Class Initialized
INFO - 2020-07-29 04:56:01 --> Helper loaded: url_helper
INFO - 2020-07-29 04:56:01 --> Database Driver Class Initialized
INFO - 2020-07-29 04:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 04:56:01 --> Email Class Initialized
INFO - 2020-07-29 04:56:01 --> Controller Class Initialized
DEBUG - 2020-07-29 04:56:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 04:56:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 04:56:01 --> Model Class Initialized
INFO - 2020-07-29 04:56:01 --> Model Class Initialized
INFO - 2020-07-29 04:56:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-07-29 04:56:01 --> Final output sent to browser
DEBUG - 2020-07-29 04:56:01 --> Total execution time: 0.0235
INFO - 2020-07-29 04:56:08 --> Config Class Initialized
INFO - 2020-07-29 04:56:08 --> Hooks Class Initialized
DEBUG - 2020-07-29 04:56:08 --> UTF-8 Support Enabled
INFO - 2020-07-29 04:56:08 --> Utf8 Class Initialized
INFO - 2020-07-29 04:56:08 --> URI Class Initialized
INFO - 2020-07-29 04:56:08 --> Router Class Initialized
INFO - 2020-07-29 04:56:08 --> Output Class Initialized
INFO - 2020-07-29 04:56:08 --> Security Class Initialized
DEBUG - 2020-07-29 04:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 04:56:08 --> Input Class Initialized
INFO - 2020-07-29 04:56:08 --> Language Class Initialized
INFO - 2020-07-29 04:56:08 --> Loader Class Initialized
INFO - 2020-07-29 04:56:08 --> Helper loaded: url_helper
INFO - 2020-07-29 04:56:08 --> Database Driver Class Initialized
INFO - 2020-07-29 04:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 04:56:08 --> Email Class Initialized
INFO - 2020-07-29 04:56:08 --> Controller Class Initialized
DEBUG - 2020-07-29 04:56:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 04:56:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 04:56:08 --> Model Class Initialized
INFO - 2020-07-29 04:56:08 --> Model Class Initialized
INFO - 2020-07-29 04:56:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 04:56:08 --> Final output sent to browser
DEBUG - 2020-07-29 04:56:08 --> Total execution time: 0.3111
INFO - 2020-07-29 04:56:11 --> Config Class Initialized
INFO - 2020-07-29 04:56:11 --> Hooks Class Initialized
DEBUG - 2020-07-29 04:56:11 --> UTF-8 Support Enabled
INFO - 2020-07-29 04:56:11 --> Utf8 Class Initialized
INFO - 2020-07-29 04:56:11 --> URI Class Initialized
INFO - 2020-07-29 04:56:11 --> Router Class Initialized
INFO - 2020-07-29 04:56:11 --> Output Class Initialized
INFO - 2020-07-29 04:56:11 --> Security Class Initialized
DEBUG - 2020-07-29 04:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 04:56:11 --> Input Class Initialized
INFO - 2020-07-29 04:56:11 --> Language Class Initialized
INFO - 2020-07-29 04:56:11 --> Loader Class Initialized
INFO - 2020-07-29 04:56:11 --> Helper loaded: url_helper
INFO - 2020-07-29 04:56:11 --> Database Driver Class Initialized
INFO - 2020-07-29 04:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 04:56:11 --> Email Class Initialized
INFO - 2020-07-29 04:56:11 --> Controller Class Initialized
DEBUG - 2020-07-29 04:56:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 04:56:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 04:56:11 --> Model Class Initialized
INFO - 2020-07-29 04:56:11 --> Model Class Initialized
INFO - 2020-07-29 04:56:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-07-29 04:56:11 --> Final output sent to browser
DEBUG - 2020-07-29 04:56:11 --> Total execution time: 0.0216
INFO - 2020-07-29 04:56:15 --> Config Class Initialized
INFO - 2020-07-29 04:56:15 --> Hooks Class Initialized
DEBUG - 2020-07-29 04:56:15 --> UTF-8 Support Enabled
INFO - 2020-07-29 04:56:15 --> Utf8 Class Initialized
INFO - 2020-07-29 04:56:15 --> URI Class Initialized
INFO - 2020-07-29 04:56:15 --> Router Class Initialized
INFO - 2020-07-29 04:56:15 --> Output Class Initialized
INFO - 2020-07-29 04:56:15 --> Security Class Initialized
DEBUG - 2020-07-29 04:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 04:56:15 --> Input Class Initialized
INFO - 2020-07-29 04:56:15 --> Language Class Initialized
INFO - 2020-07-29 04:56:15 --> Loader Class Initialized
INFO - 2020-07-29 04:56:15 --> Helper loaded: url_helper
INFO - 2020-07-29 04:56:15 --> Database Driver Class Initialized
INFO - 2020-07-29 04:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 04:56:15 --> Email Class Initialized
INFO - 2020-07-29 04:56:15 --> Controller Class Initialized
DEBUG - 2020-07-29 04:56:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 04:56:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 04:56:15 --> Model Class Initialized
INFO - 2020-07-29 04:56:15 --> Model Class Initialized
INFO - 2020-07-29 04:56:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 04:56:15 --> Final output sent to browser
DEBUG - 2020-07-29 04:56:15 --> Total execution time: 0.0235
INFO - 2020-07-29 05:06:27 --> Config Class Initialized
INFO - 2020-07-29 05:06:27 --> Hooks Class Initialized
DEBUG - 2020-07-29 05:06:27 --> UTF-8 Support Enabled
INFO - 2020-07-29 05:06:27 --> Utf8 Class Initialized
INFO - 2020-07-29 05:06:27 --> URI Class Initialized
INFO - 2020-07-29 05:06:27 --> Router Class Initialized
INFO - 2020-07-29 05:06:27 --> Output Class Initialized
INFO - 2020-07-29 05:06:27 --> Security Class Initialized
DEBUG - 2020-07-29 05:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 05:06:27 --> Input Class Initialized
INFO - 2020-07-29 05:06:27 --> Language Class Initialized
INFO - 2020-07-29 05:06:27 --> Loader Class Initialized
INFO - 2020-07-29 05:06:27 --> Helper loaded: url_helper
INFO - 2020-07-29 05:06:27 --> Database Driver Class Initialized
INFO - 2020-07-29 05:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 05:06:27 --> Email Class Initialized
INFO - 2020-07-29 05:06:27 --> Controller Class Initialized
DEBUG - 2020-07-29 05:06:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 05:06:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 05:06:27 --> Model Class Initialized
INFO - 2020-07-29 05:06:27 --> Model Class Initialized
INFO - 2020-07-29 05:06:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-07-29 05:06:27 --> Final output sent to browser
DEBUG - 2020-07-29 05:06:27 --> Total execution time: 0.0333
INFO - 2020-07-29 05:06:33 --> Config Class Initialized
INFO - 2020-07-29 05:06:33 --> Hooks Class Initialized
DEBUG - 2020-07-29 05:06:33 --> UTF-8 Support Enabled
INFO - 2020-07-29 05:06:33 --> Utf8 Class Initialized
INFO - 2020-07-29 05:06:33 --> URI Class Initialized
INFO - 2020-07-29 05:06:33 --> Router Class Initialized
INFO - 2020-07-29 05:06:33 --> Output Class Initialized
INFO - 2020-07-29 05:06:33 --> Security Class Initialized
DEBUG - 2020-07-29 05:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 05:06:33 --> Input Class Initialized
INFO - 2020-07-29 05:06:33 --> Language Class Initialized
INFO - 2020-07-29 05:06:33 --> Loader Class Initialized
INFO - 2020-07-29 05:06:33 --> Helper loaded: url_helper
INFO - 2020-07-29 05:06:33 --> Database Driver Class Initialized
INFO - 2020-07-29 05:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 05:06:33 --> Email Class Initialized
INFO - 2020-07-29 05:06:33 --> Controller Class Initialized
DEBUG - 2020-07-29 05:06:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 05:06:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 05:06:33 --> Model Class Initialized
INFO - 2020-07-29 05:06:33 --> Model Class Initialized
INFO - 2020-07-29 05:06:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 05:06:33 --> Final output sent to browser
DEBUG - 2020-07-29 05:06:33 --> Total execution time: 0.0246
INFO - 2020-07-29 05:07:03 --> Config Class Initialized
INFO - 2020-07-29 05:07:03 --> Hooks Class Initialized
DEBUG - 2020-07-29 05:07:03 --> UTF-8 Support Enabled
INFO - 2020-07-29 05:07:03 --> Utf8 Class Initialized
INFO - 2020-07-29 05:07:03 --> URI Class Initialized
INFO - 2020-07-29 05:07:03 --> Router Class Initialized
INFO - 2020-07-29 05:07:03 --> Output Class Initialized
INFO - 2020-07-29 05:07:03 --> Security Class Initialized
DEBUG - 2020-07-29 05:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 05:07:03 --> Input Class Initialized
INFO - 2020-07-29 05:07:03 --> Language Class Initialized
ERROR - 2020-07-29 05:07:03 --> 404 Page Not Found: Admin/product_edit
INFO - 2020-07-29 05:07:12 --> Config Class Initialized
INFO - 2020-07-29 05:07:12 --> Hooks Class Initialized
DEBUG - 2020-07-29 05:07:12 --> UTF-8 Support Enabled
INFO - 2020-07-29 05:07:12 --> Utf8 Class Initialized
INFO - 2020-07-29 05:07:12 --> URI Class Initialized
INFO - 2020-07-29 05:07:12 --> Router Class Initialized
INFO - 2020-07-29 05:07:12 --> Output Class Initialized
INFO - 2020-07-29 05:07:12 --> Security Class Initialized
DEBUG - 2020-07-29 05:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 05:07:12 --> Input Class Initialized
INFO - 2020-07-29 05:07:12 --> Language Class Initialized
INFO - 2020-07-29 05:07:12 --> Loader Class Initialized
INFO - 2020-07-29 05:07:12 --> Helper loaded: url_helper
INFO - 2020-07-29 05:07:12 --> Database Driver Class Initialized
INFO - 2020-07-29 05:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 05:07:12 --> Email Class Initialized
INFO - 2020-07-29 05:07:12 --> Controller Class Initialized
DEBUG - 2020-07-29 05:07:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 05:07:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 05:07:12 --> Model Class Initialized
INFO - 2020-07-29 05:07:12 --> Model Class Initialized
INFO - 2020-07-29 05:07:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 05:07:12 --> Final output sent to browser
DEBUG - 2020-07-29 05:07:12 --> Total execution time: 0.0220
INFO - 2020-07-29 05:24:53 --> Config Class Initialized
INFO - 2020-07-29 05:24:53 --> Hooks Class Initialized
DEBUG - 2020-07-29 05:24:53 --> UTF-8 Support Enabled
INFO - 2020-07-29 05:24:53 --> Utf8 Class Initialized
INFO - 2020-07-29 05:24:53 --> URI Class Initialized
INFO - 2020-07-29 05:24:53 --> Router Class Initialized
INFO - 2020-07-29 05:24:53 --> Output Class Initialized
INFO - 2020-07-29 05:24:53 --> Security Class Initialized
DEBUG - 2020-07-29 05:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 05:24:53 --> Input Class Initialized
INFO - 2020-07-29 05:24:53 --> Language Class Initialized
INFO - 2020-07-29 05:24:53 --> Loader Class Initialized
INFO - 2020-07-29 05:24:53 --> Helper loaded: url_helper
INFO - 2020-07-29 05:24:53 --> Database Driver Class Initialized
INFO - 2020-07-29 05:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 05:24:53 --> Email Class Initialized
INFO - 2020-07-29 05:24:53 --> Controller Class Initialized
DEBUG - 2020-07-29 05:24:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 05:24:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 05:24:53 --> Model Class Initialized
INFO - 2020-07-29 05:24:53 --> Model Class Initialized
INFO - 2020-07-29 05:24:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 05:24:53 --> Final output sent to browser
DEBUG - 2020-07-29 05:24:53 --> Total execution time: 0.0241
INFO - 2020-07-29 05:24:56 --> Config Class Initialized
INFO - 2020-07-29 05:24:56 --> Hooks Class Initialized
DEBUG - 2020-07-29 05:24:56 --> UTF-8 Support Enabled
INFO - 2020-07-29 05:24:56 --> Utf8 Class Initialized
INFO - 2020-07-29 05:24:56 --> URI Class Initialized
INFO - 2020-07-29 05:24:56 --> Router Class Initialized
INFO - 2020-07-29 05:24:56 --> Output Class Initialized
INFO - 2020-07-29 05:24:56 --> Security Class Initialized
DEBUG - 2020-07-29 05:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 05:24:56 --> Input Class Initialized
INFO - 2020-07-29 05:24:56 --> Language Class Initialized
INFO - 2020-07-29 05:24:56 --> Loader Class Initialized
INFO - 2020-07-29 05:24:56 --> Helper loaded: url_helper
INFO - 2020-07-29 05:24:56 --> Database Driver Class Initialized
INFO - 2020-07-29 05:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 05:24:56 --> Email Class Initialized
INFO - 2020-07-29 05:24:56 --> Controller Class Initialized
DEBUG - 2020-07-29 05:24:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 05:24:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 05:24:56 --> Model Class Initialized
INFO - 2020-07-29 05:24:56 --> Model Class Initialized
INFO - 2020-07-29 05:24:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 05:24:56 --> Final output sent to browser
DEBUG - 2020-07-29 05:24:56 --> Total execution time: 0.0225
INFO - 2020-07-29 05:25:02 --> Config Class Initialized
INFO - 2020-07-29 05:25:02 --> Hooks Class Initialized
DEBUG - 2020-07-29 05:25:02 --> UTF-8 Support Enabled
INFO - 2020-07-29 05:25:02 --> Utf8 Class Initialized
INFO - 2020-07-29 05:25:02 --> URI Class Initialized
INFO - 2020-07-29 05:25:02 --> Router Class Initialized
INFO - 2020-07-29 05:25:02 --> Output Class Initialized
INFO - 2020-07-29 05:25:02 --> Security Class Initialized
DEBUG - 2020-07-29 05:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 05:25:02 --> Input Class Initialized
INFO - 2020-07-29 05:25:02 --> Language Class Initialized
INFO - 2020-07-29 05:25:02 --> Loader Class Initialized
INFO - 2020-07-29 05:25:02 --> Helper loaded: url_helper
INFO - 2020-07-29 05:25:02 --> Database Driver Class Initialized
INFO - 2020-07-29 05:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 05:25:02 --> Email Class Initialized
INFO - 2020-07-29 05:25:02 --> Controller Class Initialized
DEBUG - 2020-07-29 05:25:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 05:25:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 05:25:02 --> Model Class Initialized
INFO - 2020-07-29 05:25:02 --> Model Class Initialized
INFO - 2020-07-29 05:25:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 05:25:02 --> Final output sent to browser
DEBUG - 2020-07-29 05:25:02 --> Total execution time: 0.0276
INFO - 2020-07-29 05:27:11 --> Config Class Initialized
INFO - 2020-07-29 05:27:11 --> Hooks Class Initialized
DEBUG - 2020-07-29 05:27:11 --> UTF-8 Support Enabled
INFO - 2020-07-29 05:27:11 --> Utf8 Class Initialized
INFO - 2020-07-29 05:27:11 --> URI Class Initialized
INFO - 2020-07-29 05:27:11 --> Router Class Initialized
INFO - 2020-07-29 05:27:11 --> Output Class Initialized
INFO - 2020-07-29 05:27:11 --> Security Class Initialized
DEBUG - 2020-07-29 05:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 05:27:11 --> Input Class Initialized
INFO - 2020-07-29 05:27:11 --> Language Class Initialized
INFO - 2020-07-29 05:27:11 --> Loader Class Initialized
INFO - 2020-07-29 05:27:11 --> Helper loaded: url_helper
INFO - 2020-07-29 05:27:11 --> Database Driver Class Initialized
INFO - 2020-07-29 05:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 05:27:11 --> Email Class Initialized
INFO - 2020-07-29 05:27:11 --> Controller Class Initialized
DEBUG - 2020-07-29 05:27:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 05:27:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 05:27:11 --> Model Class Initialized
INFO - 2020-07-29 05:27:11 --> Model Class Initialized
INFO - 2020-07-29 05:27:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 05:27:11 --> Final output sent to browser
DEBUG - 2020-07-29 05:27:11 --> Total execution time: 0.0256
INFO - 2020-07-29 05:27:13 --> Config Class Initialized
INFO - 2020-07-29 05:27:13 --> Hooks Class Initialized
DEBUG - 2020-07-29 05:27:13 --> UTF-8 Support Enabled
INFO - 2020-07-29 05:27:13 --> Utf8 Class Initialized
INFO - 2020-07-29 05:27:13 --> URI Class Initialized
INFO - 2020-07-29 05:27:13 --> Router Class Initialized
INFO - 2020-07-29 05:27:13 --> Output Class Initialized
INFO - 2020-07-29 05:27:13 --> Security Class Initialized
DEBUG - 2020-07-29 05:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 05:27:13 --> Input Class Initialized
INFO - 2020-07-29 05:27:13 --> Language Class Initialized
INFO - 2020-07-29 05:27:13 --> Loader Class Initialized
INFO - 2020-07-29 05:27:13 --> Helper loaded: url_helper
INFO - 2020-07-29 05:27:13 --> Database Driver Class Initialized
INFO - 2020-07-29 05:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 05:27:13 --> Email Class Initialized
INFO - 2020-07-29 05:27:13 --> Controller Class Initialized
DEBUG - 2020-07-29 05:27:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 05:27:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 05:27:13 --> Model Class Initialized
INFO - 2020-07-29 05:27:13 --> Model Class Initialized
INFO - 2020-07-29 05:27:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 05:27:13 --> Final output sent to browser
DEBUG - 2020-07-29 05:27:13 --> Total execution time: 0.0280
INFO - 2020-07-29 05:27:41 --> Config Class Initialized
INFO - 2020-07-29 05:27:41 --> Hooks Class Initialized
DEBUG - 2020-07-29 05:27:41 --> UTF-8 Support Enabled
INFO - 2020-07-29 05:27:41 --> Utf8 Class Initialized
INFO - 2020-07-29 05:27:41 --> URI Class Initialized
INFO - 2020-07-29 05:27:41 --> Router Class Initialized
INFO - 2020-07-29 05:27:41 --> Output Class Initialized
INFO - 2020-07-29 05:27:41 --> Security Class Initialized
DEBUG - 2020-07-29 05:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 05:27:41 --> Input Class Initialized
INFO - 2020-07-29 05:27:41 --> Language Class Initialized
INFO - 2020-07-29 05:27:41 --> Loader Class Initialized
INFO - 2020-07-29 05:27:41 --> Helper loaded: url_helper
INFO - 2020-07-29 05:27:41 --> Database Driver Class Initialized
INFO - 2020-07-29 05:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 05:27:41 --> Email Class Initialized
INFO - 2020-07-29 05:27:41 --> Controller Class Initialized
DEBUG - 2020-07-29 05:27:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 05:27:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 05:27:41 --> Model Class Initialized
INFO - 2020-07-29 05:27:41 --> Model Class Initialized
INFO - 2020-07-29 05:27:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 05:27:41 --> Final output sent to browser
DEBUG - 2020-07-29 05:27:41 --> Total execution time: 0.0216
INFO - 2020-07-29 05:32:01 --> Config Class Initialized
INFO - 2020-07-29 05:32:01 --> Hooks Class Initialized
DEBUG - 2020-07-29 05:32:01 --> UTF-8 Support Enabled
INFO - 2020-07-29 05:32:01 --> Utf8 Class Initialized
INFO - 2020-07-29 05:32:01 --> URI Class Initialized
INFO - 2020-07-29 05:32:01 --> Router Class Initialized
INFO - 2020-07-29 05:32:01 --> Output Class Initialized
INFO - 2020-07-29 05:32:01 --> Security Class Initialized
DEBUG - 2020-07-29 05:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 05:32:01 --> Input Class Initialized
INFO - 2020-07-29 05:32:01 --> Language Class Initialized
INFO - 2020-07-29 05:32:01 --> Loader Class Initialized
INFO - 2020-07-29 05:32:01 --> Helper loaded: url_helper
INFO - 2020-07-29 05:32:01 --> Database Driver Class Initialized
INFO - 2020-07-29 05:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 05:32:01 --> Email Class Initialized
INFO - 2020-07-29 05:32:01 --> Controller Class Initialized
DEBUG - 2020-07-29 05:32:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 05:32:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 05:32:01 --> Model Class Initialized
INFO - 2020-07-29 05:32:01 --> Model Class Initialized
INFO - 2020-07-29 05:32:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 05:32:01 --> Final output sent to browser
DEBUG - 2020-07-29 05:32:01 --> Total execution time: 0.0210
INFO - 2020-07-29 05:32:03 --> Config Class Initialized
INFO - 2020-07-29 05:32:03 --> Hooks Class Initialized
DEBUG - 2020-07-29 05:32:03 --> UTF-8 Support Enabled
INFO - 2020-07-29 05:32:03 --> Utf8 Class Initialized
INFO - 2020-07-29 05:32:03 --> URI Class Initialized
INFO - 2020-07-29 05:32:03 --> Router Class Initialized
INFO - 2020-07-29 05:32:03 --> Output Class Initialized
INFO - 2020-07-29 05:32:03 --> Security Class Initialized
DEBUG - 2020-07-29 05:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 05:32:03 --> Input Class Initialized
INFO - 2020-07-29 05:32:03 --> Language Class Initialized
INFO - 2020-07-29 05:32:03 --> Loader Class Initialized
INFO - 2020-07-29 05:32:03 --> Helper loaded: url_helper
INFO - 2020-07-29 05:32:03 --> Database Driver Class Initialized
INFO - 2020-07-29 05:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 05:32:03 --> Email Class Initialized
INFO - 2020-07-29 05:32:03 --> Controller Class Initialized
DEBUG - 2020-07-29 05:32:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 05:32:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 05:32:03 --> Model Class Initialized
INFO - 2020-07-29 05:32:03 --> Model Class Initialized
INFO - 2020-07-29 05:32:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 05:32:03 --> Final output sent to browser
DEBUG - 2020-07-29 05:32:03 --> Total execution time: 0.0210
INFO - 2020-07-29 05:33:47 --> Config Class Initialized
INFO - 2020-07-29 05:33:47 --> Hooks Class Initialized
DEBUG - 2020-07-29 05:33:47 --> UTF-8 Support Enabled
INFO - 2020-07-29 05:33:47 --> Utf8 Class Initialized
INFO - 2020-07-29 05:33:47 --> URI Class Initialized
INFO - 2020-07-29 05:33:47 --> Router Class Initialized
INFO - 2020-07-29 05:33:47 --> Output Class Initialized
INFO - 2020-07-29 05:33:47 --> Security Class Initialized
DEBUG - 2020-07-29 05:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 05:33:47 --> Input Class Initialized
INFO - 2020-07-29 05:33:47 --> Language Class Initialized
INFO - 2020-07-29 05:33:47 --> Loader Class Initialized
INFO - 2020-07-29 05:33:47 --> Helper loaded: url_helper
INFO - 2020-07-29 05:33:47 --> Database Driver Class Initialized
INFO - 2020-07-29 05:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 05:33:47 --> Email Class Initialized
INFO - 2020-07-29 05:33:47 --> Controller Class Initialized
DEBUG - 2020-07-29 05:33:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 05:33:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 05:33:47 --> Model Class Initialized
INFO - 2020-07-29 05:33:47 --> Model Class Initialized
INFO - 2020-07-29 05:33:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 05:33:47 --> Final output sent to browser
DEBUG - 2020-07-29 05:33:47 --> Total execution time: 0.0242
INFO - 2020-07-29 05:34:34 --> Config Class Initialized
INFO - 2020-07-29 05:34:34 --> Hooks Class Initialized
DEBUG - 2020-07-29 05:34:34 --> UTF-8 Support Enabled
INFO - 2020-07-29 05:34:34 --> Utf8 Class Initialized
INFO - 2020-07-29 05:34:34 --> URI Class Initialized
INFO - 2020-07-29 05:34:34 --> Router Class Initialized
INFO - 2020-07-29 05:34:34 --> Output Class Initialized
INFO - 2020-07-29 05:34:34 --> Security Class Initialized
DEBUG - 2020-07-29 05:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 05:34:34 --> Input Class Initialized
INFO - 2020-07-29 05:34:34 --> Language Class Initialized
INFO - 2020-07-29 05:34:34 --> Loader Class Initialized
INFO - 2020-07-29 05:34:34 --> Helper loaded: url_helper
INFO - 2020-07-29 05:34:34 --> Database Driver Class Initialized
INFO - 2020-07-29 05:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 05:34:34 --> Email Class Initialized
INFO - 2020-07-29 05:34:34 --> Controller Class Initialized
DEBUG - 2020-07-29 05:34:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 05:34:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 05:34:34 --> Model Class Initialized
INFO - 2020-07-29 05:34:34 --> Model Class Initialized
INFO - 2020-07-29 05:34:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 05:34:34 --> Final output sent to browser
DEBUG - 2020-07-29 05:34:34 --> Total execution time: 0.0212
INFO - 2020-07-29 05:34:37 --> Config Class Initialized
INFO - 2020-07-29 05:34:37 --> Hooks Class Initialized
DEBUG - 2020-07-29 05:34:37 --> UTF-8 Support Enabled
INFO - 2020-07-29 05:34:37 --> Utf8 Class Initialized
INFO - 2020-07-29 05:34:37 --> URI Class Initialized
INFO - 2020-07-29 05:34:37 --> Router Class Initialized
INFO - 2020-07-29 05:34:37 --> Output Class Initialized
INFO - 2020-07-29 05:34:37 --> Security Class Initialized
DEBUG - 2020-07-29 05:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 05:34:37 --> Input Class Initialized
INFO - 2020-07-29 05:34:37 --> Language Class Initialized
INFO - 2020-07-29 05:34:37 --> Loader Class Initialized
INFO - 2020-07-29 05:34:37 --> Helper loaded: url_helper
INFO - 2020-07-29 05:34:37 --> Database Driver Class Initialized
INFO - 2020-07-29 05:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 05:34:37 --> Email Class Initialized
INFO - 2020-07-29 05:34:37 --> Controller Class Initialized
DEBUG - 2020-07-29 05:34:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 05:34:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 05:34:37 --> Model Class Initialized
INFO - 2020-07-29 05:34:37 --> Model Class Initialized
INFO - 2020-07-29 05:34:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 05:34:37 --> Final output sent to browser
DEBUG - 2020-07-29 05:34:37 --> Total execution time: 0.0205
INFO - 2020-07-29 05:36:30 --> Config Class Initialized
INFO - 2020-07-29 05:36:30 --> Hooks Class Initialized
DEBUG - 2020-07-29 05:36:30 --> UTF-8 Support Enabled
INFO - 2020-07-29 05:36:30 --> Utf8 Class Initialized
INFO - 2020-07-29 05:36:30 --> URI Class Initialized
INFO - 2020-07-29 05:36:30 --> Router Class Initialized
INFO - 2020-07-29 05:36:30 --> Output Class Initialized
INFO - 2020-07-29 05:36:30 --> Security Class Initialized
DEBUG - 2020-07-29 05:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 05:36:30 --> Input Class Initialized
INFO - 2020-07-29 05:36:30 --> Language Class Initialized
INFO - 2020-07-29 05:36:30 --> Loader Class Initialized
INFO - 2020-07-29 05:36:30 --> Helper loaded: url_helper
INFO - 2020-07-29 05:36:30 --> Database Driver Class Initialized
INFO - 2020-07-29 05:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 05:36:30 --> Email Class Initialized
INFO - 2020-07-29 05:36:30 --> Controller Class Initialized
DEBUG - 2020-07-29 05:36:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 05:36:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 05:36:30 --> Model Class Initialized
INFO - 2020-07-29 05:36:30 --> Model Class Initialized
ERROR - 2020-07-29 05:36:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '.'sdfgsg','sdgfds','df@fdg','dbdg',)' at line 1 - Invalid query: CALL dealer_update('','43543532','dfgfs','gsdf3','1','1','ef3'.'sdfgsg','sdgfds','df@fdg','dbdg',)
INFO - 2020-07-29 05:36:30 --> Language file loaded: language/english/db_lang.php
INFO - 2020-07-29 05:41:12 --> Config Class Initialized
INFO - 2020-07-29 05:41:12 --> Hooks Class Initialized
DEBUG - 2020-07-29 05:41:12 --> UTF-8 Support Enabled
INFO - 2020-07-29 05:41:12 --> Utf8 Class Initialized
INFO - 2020-07-29 05:41:12 --> URI Class Initialized
INFO - 2020-07-29 05:41:12 --> Router Class Initialized
INFO - 2020-07-29 05:41:12 --> Output Class Initialized
INFO - 2020-07-29 05:41:12 --> Security Class Initialized
DEBUG - 2020-07-29 05:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 05:41:12 --> Input Class Initialized
INFO - 2020-07-29 05:41:12 --> Language Class Initialized
INFO - 2020-07-29 05:41:12 --> Loader Class Initialized
INFO - 2020-07-29 05:41:12 --> Helper loaded: url_helper
INFO - 2020-07-29 05:41:12 --> Database Driver Class Initialized
INFO - 2020-07-29 05:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 05:41:12 --> Email Class Initialized
INFO - 2020-07-29 05:41:12 --> Controller Class Initialized
DEBUG - 2020-07-29 05:41:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 05:41:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 05:41:12 --> Model Class Initialized
INFO - 2020-07-29 05:41:12 --> Model Class Initialized
INFO - 2020-07-29 05:41:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 05:41:12 --> Final output sent to browser
DEBUG - 2020-07-29 05:41:12 --> Total execution time: 0.0244
INFO - 2020-07-29 05:42:05 --> Config Class Initialized
INFO - 2020-07-29 05:42:05 --> Hooks Class Initialized
DEBUG - 2020-07-29 05:42:05 --> UTF-8 Support Enabled
INFO - 2020-07-29 05:42:05 --> Utf8 Class Initialized
INFO - 2020-07-29 05:42:05 --> URI Class Initialized
INFO - 2020-07-29 05:42:05 --> Router Class Initialized
INFO - 2020-07-29 05:42:05 --> Output Class Initialized
INFO - 2020-07-29 05:42:05 --> Security Class Initialized
DEBUG - 2020-07-29 05:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 05:42:05 --> Input Class Initialized
INFO - 2020-07-29 05:42:05 --> Language Class Initialized
INFO - 2020-07-29 05:42:05 --> Loader Class Initialized
INFO - 2020-07-29 05:42:05 --> Helper loaded: url_helper
INFO - 2020-07-29 05:42:05 --> Database Driver Class Initialized
INFO - 2020-07-29 05:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 05:42:05 --> Email Class Initialized
INFO - 2020-07-29 05:42:05 --> Controller Class Initialized
DEBUG - 2020-07-29 05:42:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 05:42:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 05:42:05 --> Model Class Initialized
INFO - 2020-07-29 05:42:05 --> Model Class Initialized
ERROR - 2020-07-29 05:42:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '.'sdfgsg','sdgfds','df@fdg','dbdg',1)' at line 1 - Invalid query: CALL dealer_update('sou','43543532','dfgfs','gsdf3','1','1','ef3'.'sdfgsg','sdgfds','df@fdg','dbdg',1)
INFO - 2020-07-29 05:42:05 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-07-29 05:42:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Admin.php:128) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
INFO - 2020-07-29 05:53:52 --> Config Class Initialized
INFO - 2020-07-29 05:53:52 --> Hooks Class Initialized
DEBUG - 2020-07-29 05:53:52 --> UTF-8 Support Enabled
INFO - 2020-07-29 05:53:52 --> Utf8 Class Initialized
INFO - 2020-07-29 05:53:52 --> URI Class Initialized
DEBUG - 2020-07-29 05:53:52 --> No URI present. Default controller set.
INFO - 2020-07-29 05:53:52 --> Router Class Initialized
INFO - 2020-07-29 05:53:52 --> Output Class Initialized
INFO - 2020-07-29 05:53:52 --> Security Class Initialized
DEBUG - 2020-07-29 05:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 05:53:52 --> Input Class Initialized
INFO - 2020-07-29 05:53:52 --> Language Class Initialized
INFO - 2020-07-29 05:53:52 --> Loader Class Initialized
INFO - 2020-07-29 05:53:52 --> Helper loaded: url_helper
INFO - 2020-07-29 05:53:52 --> Database Driver Class Initialized
INFO - 2020-07-29 05:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 05:53:52 --> Email Class Initialized
INFO - 2020-07-29 05:53:52 --> Controller Class Initialized
INFO - 2020-07-29 05:53:52 --> Model Class Initialized
INFO - 2020-07-29 05:53:52 --> Model Class Initialized
DEBUG - 2020-07-29 05:53:52 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 05:53:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 05:53:52 --> Final output sent to browser
DEBUG - 2020-07-29 05:53:52 --> Total execution time: 0.0545
INFO - 2020-07-29 06:05:55 --> Config Class Initialized
INFO - 2020-07-29 06:05:55 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:05:55 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:05:55 --> Utf8 Class Initialized
INFO - 2020-07-29 06:05:55 --> URI Class Initialized
INFO - 2020-07-29 06:05:55 --> Router Class Initialized
INFO - 2020-07-29 06:05:55 --> Output Class Initialized
INFO - 2020-07-29 06:05:55 --> Security Class Initialized
DEBUG - 2020-07-29 06:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:05:55 --> Input Class Initialized
INFO - 2020-07-29 06:05:55 --> Language Class Initialized
INFO - 2020-07-29 06:05:55 --> Loader Class Initialized
INFO - 2020-07-29 06:05:55 --> Helper loaded: url_helper
INFO - 2020-07-29 06:05:55 --> Database Driver Class Initialized
INFO - 2020-07-29 06:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:05:55 --> Email Class Initialized
INFO - 2020-07-29 06:05:55 --> Controller Class Initialized
INFO - 2020-07-29 06:05:55 --> Model Class Initialized
INFO - 2020-07-29 06:05:55 --> Model Class Initialized
DEBUG - 2020-07-29 06:05:55 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:05:55 --> Config Class Initialized
INFO - 2020-07-29 06:05:55 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:05:55 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:05:55 --> Utf8 Class Initialized
INFO - 2020-07-29 06:05:55 --> URI Class Initialized
INFO - 2020-07-29 06:05:55 --> Router Class Initialized
INFO - 2020-07-29 06:05:55 --> Output Class Initialized
INFO - 2020-07-29 06:05:55 --> Security Class Initialized
DEBUG - 2020-07-29 06:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:05:55 --> Input Class Initialized
INFO - 2020-07-29 06:05:55 --> Language Class Initialized
INFO - 2020-07-29 06:05:55 --> Loader Class Initialized
INFO - 2020-07-29 06:05:55 --> Helper loaded: url_helper
INFO - 2020-07-29 06:05:55 --> Database Driver Class Initialized
INFO - 2020-07-29 06:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:05:55 --> Email Class Initialized
INFO - 2020-07-29 06:05:55 --> Controller Class Initialized
DEBUG - 2020-07-29 06:05:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:05:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:05:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 06:05:55 --> Final output sent to browser
DEBUG - 2020-07-29 06:05:55 --> Total execution time: 0.0283
INFO - 2020-07-29 06:05:59 --> Config Class Initialized
INFO - 2020-07-29 06:05:59 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:05:59 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:05:59 --> Utf8 Class Initialized
INFO - 2020-07-29 06:05:59 --> URI Class Initialized
INFO - 2020-07-29 06:05:59 --> Router Class Initialized
INFO - 2020-07-29 06:05:59 --> Output Class Initialized
INFO - 2020-07-29 06:05:59 --> Security Class Initialized
DEBUG - 2020-07-29 06:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:05:59 --> Input Class Initialized
INFO - 2020-07-29 06:05:59 --> Language Class Initialized
INFO - 2020-07-29 06:05:59 --> Loader Class Initialized
INFO - 2020-07-29 06:05:59 --> Helper loaded: url_helper
INFO - 2020-07-29 06:05:59 --> Database Driver Class Initialized
INFO - 2020-07-29 06:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:05:59 --> Email Class Initialized
INFO - 2020-07-29 06:05:59 --> Controller Class Initialized
DEBUG - 2020-07-29 06:05:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:05:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:05:59 --> Model Class Initialized
INFO - 2020-07-29 06:05:59 --> Model Class Initialized
INFO - 2020-07-29 06:05:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 06:05:59 --> Final output sent to browser
DEBUG - 2020-07-29 06:05:59 --> Total execution time: 0.0245
INFO - 2020-07-29 06:06:03 --> Config Class Initialized
INFO - 2020-07-29 06:06:03 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:06:03 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:06:03 --> Utf8 Class Initialized
INFO - 2020-07-29 06:06:03 --> URI Class Initialized
INFO - 2020-07-29 06:06:03 --> Router Class Initialized
INFO - 2020-07-29 06:06:03 --> Output Class Initialized
INFO - 2020-07-29 06:06:03 --> Security Class Initialized
DEBUG - 2020-07-29 06:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:06:03 --> Input Class Initialized
INFO - 2020-07-29 06:06:03 --> Language Class Initialized
INFO - 2020-07-29 06:06:03 --> Loader Class Initialized
INFO - 2020-07-29 06:06:03 --> Helper loaded: url_helper
INFO - 2020-07-29 06:06:03 --> Database Driver Class Initialized
INFO - 2020-07-29 06:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:06:03 --> Email Class Initialized
INFO - 2020-07-29 06:06:03 --> Controller Class Initialized
DEBUG - 2020-07-29 06:06:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:06:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:06:03 --> Model Class Initialized
INFO - 2020-07-29 06:06:03 --> Model Class Initialized
INFO - 2020-07-29 06:06:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 06:06:03 --> Final output sent to browser
DEBUG - 2020-07-29 06:06:03 --> Total execution time: 0.0226
INFO - 2020-07-29 06:06:15 --> Config Class Initialized
INFO - 2020-07-29 06:06:15 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:06:15 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:06:15 --> Utf8 Class Initialized
INFO - 2020-07-29 06:06:15 --> URI Class Initialized
INFO - 2020-07-29 06:06:15 --> Router Class Initialized
INFO - 2020-07-29 06:06:15 --> Output Class Initialized
INFO - 2020-07-29 06:06:15 --> Security Class Initialized
DEBUG - 2020-07-29 06:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:06:15 --> Input Class Initialized
INFO - 2020-07-29 06:06:15 --> Language Class Initialized
INFO - 2020-07-29 06:06:15 --> Loader Class Initialized
INFO - 2020-07-29 06:06:15 --> Helper loaded: url_helper
INFO - 2020-07-29 06:06:15 --> Database Driver Class Initialized
INFO - 2020-07-29 06:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:06:15 --> Email Class Initialized
INFO - 2020-07-29 06:06:15 --> Controller Class Initialized
DEBUG - 2020-07-29 06:06:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:06:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:06:15 --> Model Class Initialized
INFO - 2020-07-29 06:06:15 --> Model Class Initialized
ERROR - 2020-07-29 06:06:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '.'sdfgsg','sdgfds','df@fdg','dbdg',1)' at line 1 - Invalid query: CALL dealer_update('sou','43543532','dfgfs','gsdf3','1','1','ef3'.'sdfgsg','sdgfds','df@fdg','dbdg',1)
INFO - 2020-07-29 06:06:15 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-07-29 06:06:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Admin.php:128) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
INFO - 2020-07-29 06:08:24 --> Config Class Initialized
INFO - 2020-07-29 06:08:24 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:08:24 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:08:24 --> Utf8 Class Initialized
INFO - 2020-07-29 06:08:24 --> URI Class Initialized
INFO - 2020-07-29 06:08:24 --> Router Class Initialized
INFO - 2020-07-29 06:08:24 --> Output Class Initialized
INFO - 2020-07-29 06:08:24 --> Security Class Initialized
DEBUG - 2020-07-29 06:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:08:24 --> Input Class Initialized
INFO - 2020-07-29 06:08:24 --> Language Class Initialized
INFO - 2020-07-29 06:08:24 --> Loader Class Initialized
INFO - 2020-07-29 06:08:24 --> Helper loaded: url_helper
INFO - 2020-07-29 06:08:24 --> Database Driver Class Initialized
INFO - 2020-07-29 06:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:08:24 --> Email Class Initialized
INFO - 2020-07-29 06:08:24 --> Controller Class Initialized
DEBUG - 2020-07-29 06:08:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:08:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:08:24 --> Model Class Initialized
INFO - 2020-07-29 06:08:24 --> Model Class Initialized
INFO - 2020-07-29 06:08:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 06:08:24 --> Final output sent to browser
DEBUG - 2020-07-29 06:08:24 --> Total execution time: 0.0248
INFO - 2020-07-29 06:08:32 --> Config Class Initialized
INFO - 2020-07-29 06:08:32 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:08:32 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:08:32 --> Utf8 Class Initialized
INFO - 2020-07-29 06:08:32 --> URI Class Initialized
INFO - 2020-07-29 06:08:32 --> Router Class Initialized
INFO - 2020-07-29 06:08:32 --> Output Class Initialized
INFO - 2020-07-29 06:08:32 --> Security Class Initialized
DEBUG - 2020-07-29 06:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:08:32 --> Input Class Initialized
INFO - 2020-07-29 06:08:32 --> Language Class Initialized
INFO - 2020-07-29 06:08:32 --> Loader Class Initialized
INFO - 2020-07-29 06:08:32 --> Helper loaded: url_helper
INFO - 2020-07-29 06:08:32 --> Database Driver Class Initialized
INFO - 2020-07-29 06:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:08:32 --> Email Class Initialized
INFO - 2020-07-29 06:08:32 --> Controller Class Initialized
DEBUG - 2020-07-29 06:08:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:08:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:08:32 --> Model Class Initialized
INFO - 2020-07-29 06:08:32 --> Model Class Initialized
ERROR - 2020-07-29 06:08:32 --> Query error: PROCEDURE purpu1ex_carsm.dealer_update does not exist - Invalid query: CALL dealer_update('sou','43543532','dfgfs','gsdf3','1','1','ef3','sdfgsg','sdgfds','df@fdg','dbdg',1)
INFO - 2020-07-29 06:08:32 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-07-29 06:08:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Admin.php:128) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
INFO - 2020-07-29 06:10:05 --> Config Class Initialized
INFO - 2020-07-29 06:10:05 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:10:05 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:10:05 --> Utf8 Class Initialized
INFO - 2020-07-29 06:10:05 --> URI Class Initialized
INFO - 2020-07-29 06:10:05 --> Router Class Initialized
INFO - 2020-07-29 06:10:05 --> Output Class Initialized
INFO - 2020-07-29 06:10:05 --> Security Class Initialized
DEBUG - 2020-07-29 06:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:10:05 --> Input Class Initialized
INFO - 2020-07-29 06:10:05 --> Language Class Initialized
INFO - 2020-07-29 06:10:05 --> Loader Class Initialized
INFO - 2020-07-29 06:10:05 --> Helper loaded: url_helper
INFO - 2020-07-29 06:10:05 --> Database Driver Class Initialized
INFO - 2020-07-29 06:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:10:05 --> Email Class Initialized
INFO - 2020-07-29 06:10:05 --> Controller Class Initialized
DEBUG - 2020-07-29 06:10:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:10:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:10:05 --> Model Class Initialized
INFO - 2020-07-29 06:10:05 --> Model Class Initialized
INFO - 2020-07-29 06:10:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 06:10:05 --> Final output sent to browser
DEBUG - 2020-07-29 06:10:05 --> Total execution time: 0.0239
INFO - 2020-07-29 06:10:54 --> Config Class Initialized
INFO - 2020-07-29 06:10:54 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:10:54 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:10:54 --> Utf8 Class Initialized
INFO - 2020-07-29 06:10:54 --> URI Class Initialized
INFO - 2020-07-29 06:10:54 --> Router Class Initialized
INFO - 2020-07-29 06:10:54 --> Output Class Initialized
INFO - 2020-07-29 06:10:54 --> Security Class Initialized
DEBUG - 2020-07-29 06:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:10:54 --> Input Class Initialized
INFO - 2020-07-29 06:10:54 --> Language Class Initialized
INFO - 2020-07-29 06:10:54 --> Loader Class Initialized
INFO - 2020-07-29 06:10:54 --> Helper loaded: url_helper
INFO - 2020-07-29 06:10:54 --> Database Driver Class Initialized
INFO - 2020-07-29 06:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:10:54 --> Email Class Initialized
INFO - 2020-07-29 06:10:54 --> Controller Class Initialized
DEBUG - 2020-07-29 06:10:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:10:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:10:54 --> Model Class Initialized
INFO - 2020-07-29 06:10:54 --> Model Class Initialized
ERROR - 2020-07-29 06:10:54 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2020-07-29 06:10:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Admin.php:128) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 06:10:54 --> Severity: Error --> Call to undefined method CI_DB_mysql_result::next_result() /home/purpu1ex/public_html/carsm/application/models/Admin_model.php 47
INFO - 2020-07-29 06:11:34 --> Config Class Initialized
INFO - 2020-07-29 06:11:34 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:11:34 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:11:34 --> Utf8 Class Initialized
INFO - 2020-07-29 06:11:34 --> URI Class Initialized
INFO - 2020-07-29 06:11:34 --> Router Class Initialized
INFO - 2020-07-29 06:11:34 --> Output Class Initialized
INFO - 2020-07-29 06:11:34 --> Security Class Initialized
DEBUG - 2020-07-29 06:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:11:34 --> Input Class Initialized
INFO - 2020-07-29 06:11:34 --> Language Class Initialized
INFO - 2020-07-29 06:11:34 --> Loader Class Initialized
INFO - 2020-07-29 06:11:34 --> Helper loaded: url_helper
INFO - 2020-07-29 06:11:34 --> Database Driver Class Initialized
INFO - 2020-07-29 06:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:11:34 --> Email Class Initialized
INFO - 2020-07-29 06:11:34 --> Controller Class Initialized
DEBUG - 2020-07-29 06:11:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:11:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:11:34 --> Model Class Initialized
INFO - 2020-07-29 06:11:34 --> Model Class Initialized
ERROR - 2020-07-29 06:11:34 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2020-07-29 06:11:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Admin.php:128) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 06:11:34 --> Severity: Error --> Call to a member function dealer_list() on a non-object /home/purpu1ex/public_html/carsm/application/controllers/Admin.php 133
INFO - 2020-07-29 06:11:49 --> Config Class Initialized
INFO - 2020-07-29 06:11:49 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:11:49 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:11:49 --> Utf8 Class Initialized
INFO - 2020-07-29 06:11:49 --> URI Class Initialized
INFO - 2020-07-29 06:11:49 --> Router Class Initialized
INFO - 2020-07-29 06:11:49 --> Output Class Initialized
INFO - 2020-07-29 06:11:49 --> Security Class Initialized
DEBUG - 2020-07-29 06:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:11:49 --> Input Class Initialized
INFO - 2020-07-29 06:11:49 --> Language Class Initialized
INFO - 2020-07-29 06:11:49 --> Loader Class Initialized
INFO - 2020-07-29 06:11:49 --> Helper loaded: url_helper
INFO - 2020-07-29 06:11:49 --> Database Driver Class Initialized
INFO - 2020-07-29 06:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:11:49 --> Email Class Initialized
INFO - 2020-07-29 06:11:49 --> Controller Class Initialized
DEBUG - 2020-07-29 06:11:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:11:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:11:49 --> Model Class Initialized
INFO - 2020-07-29 06:11:49 --> Model Class Initialized
INFO - 2020-07-29 06:11:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 06:11:49 --> Final output sent to browser
DEBUG - 2020-07-29 06:11:49 --> Total execution time: 0.0219
INFO - 2020-07-29 06:11:52 --> Config Class Initialized
INFO - 2020-07-29 06:11:52 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:11:52 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:11:52 --> Utf8 Class Initialized
INFO - 2020-07-29 06:11:52 --> URI Class Initialized
INFO - 2020-07-29 06:11:52 --> Router Class Initialized
INFO - 2020-07-29 06:11:52 --> Output Class Initialized
INFO - 2020-07-29 06:11:52 --> Security Class Initialized
DEBUG - 2020-07-29 06:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:11:52 --> Input Class Initialized
INFO - 2020-07-29 06:11:52 --> Language Class Initialized
INFO - 2020-07-29 06:11:52 --> Loader Class Initialized
INFO - 2020-07-29 06:11:52 --> Helper loaded: url_helper
INFO - 2020-07-29 06:11:52 --> Database Driver Class Initialized
INFO - 2020-07-29 06:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:11:52 --> Email Class Initialized
INFO - 2020-07-29 06:11:52 --> Controller Class Initialized
DEBUG - 2020-07-29 06:11:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:11:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:11:52 --> Model Class Initialized
INFO - 2020-07-29 06:11:52 --> Model Class Initialized
ERROR - 2020-07-29 06:11:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2020-07-29 06:11:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Admin.php:128) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 06:11:52 --> Severity: Error --> Call to a member function dealer_list() on a non-object /home/purpu1ex/public_html/carsm/application/controllers/Admin.php 133
INFO - 2020-07-29 06:39:17 --> Config Class Initialized
INFO - 2020-07-29 06:39:17 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:39:17 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:39:17 --> Utf8 Class Initialized
INFO - 2020-07-29 06:39:17 --> URI Class Initialized
DEBUG - 2020-07-29 06:39:17 --> No URI present. Default controller set.
INFO - 2020-07-29 06:39:17 --> Router Class Initialized
INFO - 2020-07-29 06:39:17 --> Output Class Initialized
INFO - 2020-07-29 06:39:17 --> Security Class Initialized
DEBUG - 2020-07-29 06:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:39:17 --> Input Class Initialized
INFO - 2020-07-29 06:39:17 --> Language Class Initialized
INFO - 2020-07-29 06:39:17 --> Loader Class Initialized
INFO - 2020-07-29 06:39:17 --> Helper loaded: url_helper
INFO - 2020-07-29 06:39:17 --> Database Driver Class Initialized
INFO - 2020-07-29 06:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:39:17 --> Email Class Initialized
INFO - 2020-07-29 06:39:17 --> Controller Class Initialized
INFO - 2020-07-29 06:39:17 --> Model Class Initialized
INFO - 2020-07-29 06:39:17 --> Model Class Initialized
DEBUG - 2020-07-29 06:39:17 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:39:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 06:39:17 --> Final output sent to browser
DEBUG - 2020-07-29 06:39:17 --> Total execution time: 0.1075
INFO - 2020-07-29 06:39:30 --> Config Class Initialized
INFO - 2020-07-29 06:39:30 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:39:30 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:39:30 --> Utf8 Class Initialized
INFO - 2020-07-29 06:39:30 --> URI Class Initialized
INFO - 2020-07-29 06:39:30 --> Router Class Initialized
INFO - 2020-07-29 06:39:30 --> Output Class Initialized
INFO - 2020-07-29 06:39:30 --> Security Class Initialized
DEBUG - 2020-07-29 06:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:39:30 --> Input Class Initialized
INFO - 2020-07-29 06:39:30 --> Language Class Initialized
INFO - 2020-07-29 06:39:30 --> Loader Class Initialized
INFO - 2020-07-29 06:39:30 --> Helper loaded: url_helper
INFO - 2020-07-29 06:39:30 --> Database Driver Class Initialized
INFO - 2020-07-29 06:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:39:30 --> Email Class Initialized
INFO - 2020-07-29 06:39:30 --> Controller Class Initialized
INFO - 2020-07-29 06:39:30 --> Model Class Initialized
INFO - 2020-07-29 06:39:30 --> Model Class Initialized
DEBUG - 2020-07-29 06:39:30 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:39:30 --> Config Class Initialized
INFO - 2020-07-29 06:39:30 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:39:30 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:39:30 --> Utf8 Class Initialized
INFO - 2020-07-29 06:39:30 --> URI Class Initialized
INFO - 2020-07-29 06:39:30 --> Router Class Initialized
INFO - 2020-07-29 06:39:30 --> Output Class Initialized
INFO - 2020-07-29 06:39:30 --> Security Class Initialized
DEBUG - 2020-07-29 06:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:39:30 --> Input Class Initialized
INFO - 2020-07-29 06:39:30 --> Language Class Initialized
INFO - 2020-07-29 06:39:30 --> Loader Class Initialized
INFO - 2020-07-29 06:39:30 --> Helper loaded: url_helper
INFO - 2020-07-29 06:39:30 --> Database Driver Class Initialized
INFO - 2020-07-29 06:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:39:30 --> Email Class Initialized
INFO - 2020-07-29 06:39:30 --> Controller Class Initialized
DEBUG - 2020-07-29 06:39:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:39:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:39:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 06:39:30 --> Final output sent to browser
DEBUG - 2020-07-29 06:39:30 --> Total execution time: 0.0238
INFO - 2020-07-29 06:39:35 --> Config Class Initialized
INFO - 2020-07-29 06:39:35 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:39:35 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:39:35 --> Utf8 Class Initialized
INFO - 2020-07-29 06:39:35 --> URI Class Initialized
INFO - 2020-07-29 06:39:35 --> Router Class Initialized
INFO - 2020-07-29 06:39:35 --> Output Class Initialized
INFO - 2020-07-29 06:39:35 --> Security Class Initialized
DEBUG - 2020-07-29 06:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:39:35 --> Input Class Initialized
INFO - 2020-07-29 06:39:35 --> Language Class Initialized
INFO - 2020-07-29 06:39:35 --> Loader Class Initialized
INFO - 2020-07-29 06:39:35 --> Helper loaded: url_helper
INFO - 2020-07-29 06:39:35 --> Database Driver Class Initialized
INFO - 2020-07-29 06:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:39:35 --> Email Class Initialized
INFO - 2020-07-29 06:39:35 --> Controller Class Initialized
DEBUG - 2020-07-29 06:39:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:39:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:39:35 --> Model Class Initialized
INFO - 2020-07-29 06:39:35 --> Model Class Initialized
INFO - 2020-07-29 06:39:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 06:39:35 --> Final output sent to browser
DEBUG - 2020-07-29 06:39:35 --> Total execution time: 0.0257
INFO - 2020-07-29 06:39:38 --> Config Class Initialized
INFO - 2020-07-29 06:39:38 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:39:38 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:39:38 --> Utf8 Class Initialized
INFO - 2020-07-29 06:39:38 --> URI Class Initialized
INFO - 2020-07-29 06:39:38 --> Router Class Initialized
INFO - 2020-07-29 06:39:38 --> Output Class Initialized
INFO - 2020-07-29 06:39:38 --> Security Class Initialized
DEBUG - 2020-07-29 06:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:39:38 --> Input Class Initialized
INFO - 2020-07-29 06:39:38 --> Language Class Initialized
INFO - 2020-07-29 06:39:38 --> Loader Class Initialized
INFO - 2020-07-29 06:39:38 --> Helper loaded: url_helper
INFO - 2020-07-29 06:39:38 --> Database Driver Class Initialized
INFO - 2020-07-29 06:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:39:38 --> Email Class Initialized
INFO - 2020-07-29 06:39:38 --> Controller Class Initialized
DEBUG - 2020-07-29 06:39:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:39:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:39:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-29 06:39:38 --> Final output sent to browser
DEBUG - 2020-07-29 06:39:38 --> Total execution time: 0.0320
INFO - 2020-07-29 06:39:43 --> Config Class Initialized
INFO - 2020-07-29 06:39:43 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:39:43 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:39:43 --> Utf8 Class Initialized
INFO - 2020-07-29 06:39:43 --> URI Class Initialized
INFO - 2020-07-29 06:39:43 --> Router Class Initialized
INFO - 2020-07-29 06:39:43 --> Output Class Initialized
INFO - 2020-07-29 06:39:43 --> Security Class Initialized
DEBUG - 2020-07-29 06:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:39:43 --> Input Class Initialized
INFO - 2020-07-29 06:39:43 --> Language Class Initialized
INFO - 2020-07-29 06:39:43 --> Loader Class Initialized
INFO - 2020-07-29 06:39:43 --> Helper loaded: url_helper
INFO - 2020-07-29 06:39:43 --> Database Driver Class Initialized
INFO - 2020-07-29 06:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:39:43 --> Email Class Initialized
INFO - 2020-07-29 06:39:43 --> Controller Class Initialized
DEBUG - 2020-07-29 06:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:39:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:39:43 --> Model Class Initialized
INFO - 2020-07-29 06:39:43 --> Model Class Initialized
INFO - 2020-07-29 06:39:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 06:39:43 --> Final output sent to browser
DEBUG - 2020-07-29 06:39:43 --> Total execution time: 0.0244
INFO - 2020-07-29 06:39:48 --> Config Class Initialized
INFO - 2020-07-29 06:39:48 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:39:48 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:39:48 --> Utf8 Class Initialized
INFO - 2020-07-29 06:39:48 --> URI Class Initialized
INFO - 2020-07-29 06:39:48 --> Router Class Initialized
INFO - 2020-07-29 06:39:48 --> Output Class Initialized
INFO - 2020-07-29 06:39:48 --> Security Class Initialized
DEBUG - 2020-07-29 06:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:39:48 --> Input Class Initialized
INFO - 2020-07-29 06:39:48 --> Language Class Initialized
INFO - 2020-07-29 06:39:48 --> Loader Class Initialized
INFO - 2020-07-29 06:39:48 --> Helper loaded: url_helper
INFO - 2020-07-29 06:39:48 --> Database Driver Class Initialized
INFO - 2020-07-29 06:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:39:48 --> Email Class Initialized
INFO - 2020-07-29 06:39:48 --> Controller Class Initialized
DEBUG - 2020-07-29 06:39:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:39:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:39:48 --> Model Class Initialized
INFO - 2020-07-29 06:39:48 --> Model Class Initialized
INFO - 2020-07-29 06:39:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 06:39:48 --> Final output sent to browser
DEBUG - 2020-07-29 06:39:48 --> Total execution time: 0.0267
INFO - 2020-07-29 06:39:54 --> Config Class Initialized
INFO - 2020-07-29 06:39:54 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:39:54 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:39:54 --> Utf8 Class Initialized
INFO - 2020-07-29 06:39:54 --> URI Class Initialized
INFO - 2020-07-29 06:39:54 --> Router Class Initialized
INFO - 2020-07-29 06:39:54 --> Output Class Initialized
INFO - 2020-07-29 06:39:54 --> Security Class Initialized
DEBUG - 2020-07-29 06:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:39:54 --> Input Class Initialized
INFO - 2020-07-29 06:39:54 --> Language Class Initialized
INFO - 2020-07-29 06:39:54 --> Loader Class Initialized
INFO - 2020-07-29 06:39:54 --> Helper loaded: url_helper
INFO - 2020-07-29 06:39:54 --> Database Driver Class Initialized
INFO - 2020-07-29 06:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:39:54 --> Email Class Initialized
INFO - 2020-07-29 06:39:54 --> Controller Class Initialized
DEBUG - 2020-07-29 06:39:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:39:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:39:54 --> Model Class Initialized
INFO - 2020-07-29 06:39:54 --> Model Class Initialized
ERROR - 2020-07-29 06:39:54 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2020-07-29 06:39:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Admin.php:128) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 06:39:54 --> Severity: Error --> Call to a member function dealer_list() on a non-object /home/purpu1ex/public_html/carsm/application/controllers/Admin.php 133
INFO - 2020-07-29 06:40:50 --> Config Class Initialized
INFO - 2020-07-29 06:40:50 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:40:50 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:40:50 --> Utf8 Class Initialized
INFO - 2020-07-29 06:40:50 --> URI Class Initialized
INFO - 2020-07-29 06:40:50 --> Router Class Initialized
INFO - 2020-07-29 06:40:50 --> Output Class Initialized
INFO - 2020-07-29 06:40:50 --> Security Class Initialized
DEBUG - 2020-07-29 06:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:40:50 --> Input Class Initialized
INFO - 2020-07-29 06:40:50 --> Language Class Initialized
INFO - 2020-07-29 06:40:50 --> Loader Class Initialized
INFO - 2020-07-29 06:40:50 --> Helper loaded: url_helper
INFO - 2020-07-29 06:40:50 --> Database Driver Class Initialized
INFO - 2020-07-29 06:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:40:50 --> Email Class Initialized
INFO - 2020-07-29 06:40:50 --> Controller Class Initialized
DEBUG - 2020-07-29 06:40:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:40:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:40:50 --> Model Class Initialized
INFO - 2020-07-29 06:40:50 --> Model Class Initialized
ERROR - 2020-07-29 06:40:50 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2020-07-29 06:40:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 06:40:50 --> Severity: Error --> Call to a member function dealer_list() on a non-object /home/purpu1ex/public_html/carsm/application/controllers/Admin.php 133
INFO - 2020-07-29 06:41:17 --> Config Class Initialized
INFO - 2020-07-29 06:41:17 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:41:17 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:41:17 --> Utf8 Class Initialized
INFO - 2020-07-29 06:41:17 --> URI Class Initialized
INFO - 2020-07-29 06:41:17 --> Router Class Initialized
INFO - 2020-07-29 06:41:17 --> Output Class Initialized
INFO - 2020-07-29 06:41:17 --> Security Class Initialized
DEBUG - 2020-07-29 06:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:41:17 --> Input Class Initialized
INFO - 2020-07-29 06:41:17 --> Language Class Initialized
INFO - 2020-07-29 06:41:17 --> Loader Class Initialized
INFO - 2020-07-29 06:41:17 --> Helper loaded: url_helper
INFO - 2020-07-29 06:41:17 --> Database Driver Class Initialized
INFO - 2020-07-29 06:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:41:17 --> Email Class Initialized
INFO - 2020-07-29 06:41:17 --> Controller Class Initialized
DEBUG - 2020-07-29 06:41:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:41:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:41:17 --> Model Class Initialized
INFO - 2020-07-29 06:41:17 --> Model Class Initialized
ERROR - 2020-07-29 06:41:17 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
INFO - 2020-07-29 06:41:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 06:41:17 --> Final output sent to browser
DEBUG - 2020-07-29 06:41:17 --> Total execution time: 0.0243
INFO - 2020-07-29 06:41:35 --> Config Class Initialized
INFO - 2020-07-29 06:41:35 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:41:35 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:41:35 --> Utf8 Class Initialized
INFO - 2020-07-29 06:41:35 --> URI Class Initialized
INFO - 2020-07-29 06:41:35 --> Router Class Initialized
INFO - 2020-07-29 06:41:35 --> Output Class Initialized
INFO - 2020-07-29 06:41:35 --> Security Class Initialized
DEBUG - 2020-07-29 06:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:41:35 --> Input Class Initialized
INFO - 2020-07-29 06:41:35 --> Language Class Initialized
INFO - 2020-07-29 06:41:35 --> Loader Class Initialized
INFO - 2020-07-29 06:41:35 --> Helper loaded: url_helper
INFO - 2020-07-29 06:41:35 --> Database Driver Class Initialized
INFO - 2020-07-29 06:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:41:35 --> Email Class Initialized
INFO - 2020-07-29 06:41:35 --> Controller Class Initialized
DEBUG - 2020-07-29 06:41:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:41:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:41:35 --> Model Class Initialized
INFO - 2020-07-29 06:41:35 --> Model Class Initialized
INFO - 2020-07-29 06:41:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 06:41:35 --> Final output sent to browser
DEBUG - 2020-07-29 06:41:35 --> Total execution time: 0.0274
INFO - 2020-07-29 06:41:41 --> Config Class Initialized
INFO - 2020-07-29 06:41:41 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:41:41 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:41:41 --> Utf8 Class Initialized
INFO - 2020-07-29 06:41:41 --> URI Class Initialized
INFO - 2020-07-29 06:41:41 --> Router Class Initialized
INFO - 2020-07-29 06:41:41 --> Output Class Initialized
INFO - 2020-07-29 06:41:41 --> Security Class Initialized
DEBUG - 2020-07-29 06:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:41:41 --> Input Class Initialized
INFO - 2020-07-29 06:41:41 --> Language Class Initialized
INFO - 2020-07-29 06:41:41 --> Loader Class Initialized
INFO - 2020-07-29 06:41:41 --> Helper loaded: url_helper
INFO - 2020-07-29 06:41:41 --> Database Driver Class Initialized
INFO - 2020-07-29 06:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:41:41 --> Email Class Initialized
INFO - 2020-07-29 06:41:41 --> Controller Class Initialized
DEBUG - 2020-07-29 06:41:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:41:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:41:41 --> Model Class Initialized
INFO - 2020-07-29 06:41:41 --> Model Class Initialized
INFO - 2020-07-29 06:41:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 06:41:41 --> Final output sent to browser
DEBUG - 2020-07-29 06:41:41 --> Total execution time: 0.0251
INFO - 2020-07-29 06:41:43 --> Config Class Initialized
INFO - 2020-07-29 06:41:43 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:41:43 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:41:43 --> Utf8 Class Initialized
INFO - 2020-07-29 06:41:43 --> URI Class Initialized
INFO - 2020-07-29 06:41:43 --> Router Class Initialized
INFO - 2020-07-29 06:41:43 --> Output Class Initialized
INFO - 2020-07-29 06:41:43 --> Security Class Initialized
DEBUG - 2020-07-29 06:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:41:43 --> Input Class Initialized
INFO - 2020-07-29 06:41:43 --> Language Class Initialized
INFO - 2020-07-29 06:41:43 --> Loader Class Initialized
INFO - 2020-07-29 06:41:43 --> Helper loaded: url_helper
INFO - 2020-07-29 06:41:43 --> Database Driver Class Initialized
INFO - 2020-07-29 06:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:41:43 --> Email Class Initialized
INFO - 2020-07-29 06:41:43 --> Controller Class Initialized
DEBUG - 2020-07-29 06:41:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:41:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:41:43 --> Model Class Initialized
INFO - 2020-07-29 06:41:43 --> Model Class Initialized
ERROR - 2020-07-29 06:41:43 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
INFO - 2020-07-29 06:41:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 06:41:43 --> Final output sent to browser
DEBUG - 2020-07-29 06:41:43 --> Total execution time: 0.1182
INFO - 2020-07-29 06:41:47 --> Config Class Initialized
INFO - 2020-07-29 06:41:47 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:41:47 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:41:47 --> Utf8 Class Initialized
INFO - 2020-07-29 06:41:47 --> URI Class Initialized
INFO - 2020-07-29 06:41:47 --> Router Class Initialized
INFO - 2020-07-29 06:41:47 --> Output Class Initialized
INFO - 2020-07-29 06:41:47 --> Security Class Initialized
DEBUG - 2020-07-29 06:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:41:47 --> Input Class Initialized
INFO - 2020-07-29 06:41:47 --> Language Class Initialized
INFO - 2020-07-29 06:41:47 --> Loader Class Initialized
INFO - 2020-07-29 06:41:47 --> Helper loaded: url_helper
INFO - 2020-07-29 06:41:47 --> Database Driver Class Initialized
INFO - 2020-07-29 06:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:41:47 --> Email Class Initialized
INFO - 2020-07-29 06:41:47 --> Controller Class Initialized
DEBUG - 2020-07-29 06:41:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:41:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:41:47 --> Model Class Initialized
INFO - 2020-07-29 06:41:47 --> Model Class Initialized
INFO - 2020-07-29 06:41:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 06:41:47 --> Final output sent to browser
DEBUG - 2020-07-29 06:41:47 --> Total execution time: 0.0233
INFO - 2020-07-29 06:41:55 --> Config Class Initialized
INFO - 2020-07-29 06:41:55 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:41:55 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:41:55 --> Utf8 Class Initialized
INFO - 2020-07-29 06:41:55 --> URI Class Initialized
INFO - 2020-07-29 06:41:55 --> Router Class Initialized
INFO - 2020-07-29 06:41:55 --> Output Class Initialized
INFO - 2020-07-29 06:41:55 --> Security Class Initialized
DEBUG - 2020-07-29 06:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:41:55 --> Input Class Initialized
INFO - 2020-07-29 06:41:55 --> Language Class Initialized
INFO - 2020-07-29 06:41:55 --> Loader Class Initialized
INFO - 2020-07-29 06:41:55 --> Helper loaded: url_helper
INFO - 2020-07-29 06:41:55 --> Database Driver Class Initialized
INFO - 2020-07-29 06:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:41:55 --> Email Class Initialized
INFO - 2020-07-29 06:41:55 --> Controller Class Initialized
DEBUG - 2020-07-29 06:41:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:41:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:41:55 --> Model Class Initialized
INFO - 2020-07-29 06:41:55 --> Model Class Initialized
ERROR - 2020-07-29 06:41:55 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
INFO - 2020-07-29 06:41:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 06:41:55 --> Final output sent to browser
DEBUG - 2020-07-29 06:41:55 --> Total execution time: 0.0247
INFO - 2020-07-29 06:42:21 --> Config Class Initialized
INFO - 2020-07-29 06:42:21 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:42:21 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:42:21 --> Utf8 Class Initialized
INFO - 2020-07-29 06:42:21 --> URI Class Initialized
INFO - 2020-07-29 06:42:21 --> Router Class Initialized
INFO - 2020-07-29 06:42:21 --> Output Class Initialized
INFO - 2020-07-29 06:42:21 --> Security Class Initialized
DEBUG - 2020-07-29 06:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:42:21 --> Input Class Initialized
INFO - 2020-07-29 06:42:21 --> Language Class Initialized
INFO - 2020-07-29 06:42:21 --> Loader Class Initialized
INFO - 2020-07-29 06:42:21 --> Helper loaded: url_helper
INFO - 2020-07-29 06:42:21 --> Database Driver Class Initialized
INFO - 2020-07-29 06:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:42:21 --> Email Class Initialized
INFO - 2020-07-29 06:42:21 --> Controller Class Initialized
DEBUG - 2020-07-29 06:42:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:42:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:42:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-29 06:42:21 --> Final output sent to browser
DEBUG - 2020-07-29 06:42:21 --> Total execution time: 0.0210
INFO - 2020-07-29 06:42:48 --> Config Class Initialized
INFO - 2020-07-29 06:42:48 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:42:48 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:42:48 --> Utf8 Class Initialized
INFO - 2020-07-29 06:42:48 --> URI Class Initialized
INFO - 2020-07-29 06:42:48 --> Router Class Initialized
INFO - 2020-07-29 06:42:48 --> Output Class Initialized
INFO - 2020-07-29 06:42:48 --> Security Class Initialized
DEBUG - 2020-07-29 06:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:42:48 --> Input Class Initialized
INFO - 2020-07-29 06:42:48 --> Language Class Initialized
INFO - 2020-07-29 06:42:48 --> Loader Class Initialized
INFO - 2020-07-29 06:42:48 --> Helper loaded: url_helper
INFO - 2020-07-29 06:42:48 --> Database Driver Class Initialized
INFO - 2020-07-29 06:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:42:48 --> Email Class Initialized
INFO - 2020-07-29 06:42:48 --> Controller Class Initialized
DEBUG - 2020-07-29 06:42:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:42:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:42:48 --> Model Class Initialized
INFO - 2020-07-29 06:42:48 --> Model Class Initialized
ERROR - 2020-07-29 06:42:48 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2020-07-29 06:42:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 06:42:48 --> Severity: Error --> Call to undefined method CI_DB_mysql_result::next_result() /home/purpu1ex/public_html/carsm/application/models/Admin_model.php 26
INFO - 2020-07-29 06:44:13 --> Config Class Initialized
INFO - 2020-07-29 06:44:13 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:44:13 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:44:13 --> Utf8 Class Initialized
INFO - 2020-07-29 06:44:13 --> URI Class Initialized
INFO - 2020-07-29 06:44:13 --> Router Class Initialized
INFO - 2020-07-29 06:44:13 --> Output Class Initialized
INFO - 2020-07-29 06:44:13 --> Security Class Initialized
DEBUG - 2020-07-29 06:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:44:13 --> Input Class Initialized
INFO - 2020-07-29 06:44:13 --> Language Class Initialized
INFO - 2020-07-29 06:44:13 --> Loader Class Initialized
INFO - 2020-07-29 06:44:13 --> Helper loaded: url_helper
INFO - 2020-07-29 06:44:13 --> Database Driver Class Initialized
INFO - 2020-07-29 06:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:44:13 --> Email Class Initialized
INFO - 2020-07-29 06:44:13 --> Controller Class Initialized
DEBUG - 2020-07-29 06:44:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:44:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:44:13 --> Model Class Initialized
INFO - 2020-07-29 06:44:13 --> Model Class Initialized
ERROR - 2020-07-29 06:44:13 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
INFO - 2020-07-29 06:44:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 06:44:13 --> Final output sent to browser
DEBUG - 2020-07-29 06:44:13 --> Total execution time: 0.0242
INFO - 2020-07-29 06:45:01 --> Config Class Initialized
INFO - 2020-07-29 06:45:01 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:45:01 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:45:01 --> Utf8 Class Initialized
INFO - 2020-07-29 06:45:01 --> URI Class Initialized
INFO - 2020-07-29 06:45:01 --> Router Class Initialized
INFO - 2020-07-29 06:45:01 --> Output Class Initialized
INFO - 2020-07-29 06:45:01 --> Security Class Initialized
DEBUG - 2020-07-29 06:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:45:01 --> Input Class Initialized
INFO - 2020-07-29 06:45:01 --> Language Class Initialized
INFO - 2020-07-29 06:45:01 --> Loader Class Initialized
INFO - 2020-07-29 06:45:01 --> Helper loaded: url_helper
INFO - 2020-07-29 06:45:01 --> Database Driver Class Initialized
INFO - 2020-07-29 06:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:45:01 --> Email Class Initialized
INFO - 2020-07-29 06:45:01 --> Controller Class Initialized
DEBUG - 2020-07-29 06:45:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:45:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:45:01 --> Model Class Initialized
INFO - 2020-07-29 06:45:01 --> Model Class Initialized
ERROR - 2020-07-29 06:45:01 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
INFO - 2020-07-29 06:45:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 06:45:01 --> Final output sent to browser
DEBUG - 2020-07-29 06:45:01 --> Total execution time: 0.0266
INFO - 2020-07-29 06:45:55 --> Config Class Initialized
INFO - 2020-07-29 06:45:55 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:45:55 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:45:55 --> Utf8 Class Initialized
INFO - 2020-07-29 06:45:55 --> URI Class Initialized
INFO - 2020-07-29 06:45:55 --> Router Class Initialized
INFO - 2020-07-29 06:45:55 --> Output Class Initialized
INFO - 2020-07-29 06:45:55 --> Security Class Initialized
DEBUG - 2020-07-29 06:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:45:55 --> Input Class Initialized
INFO - 2020-07-29 06:45:55 --> Language Class Initialized
INFO - 2020-07-29 06:45:55 --> Loader Class Initialized
INFO - 2020-07-29 06:45:55 --> Helper loaded: url_helper
INFO - 2020-07-29 06:45:55 --> Database Driver Class Initialized
INFO - 2020-07-29 06:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:45:55 --> Email Class Initialized
INFO - 2020-07-29 06:45:55 --> Controller Class Initialized
DEBUG - 2020-07-29 06:45:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:45:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:45:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-29 06:45:55 --> Final output sent to browser
DEBUG - 2020-07-29 06:45:55 --> Total execution time: 0.0268
INFO - 2020-07-29 06:46:16 --> Config Class Initialized
INFO - 2020-07-29 06:46:16 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:46:16 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:46:16 --> Utf8 Class Initialized
INFO - 2020-07-29 06:46:16 --> URI Class Initialized
INFO - 2020-07-29 06:46:16 --> Router Class Initialized
INFO - 2020-07-29 06:46:16 --> Output Class Initialized
INFO - 2020-07-29 06:46:16 --> Security Class Initialized
DEBUG - 2020-07-29 06:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:46:16 --> Input Class Initialized
INFO - 2020-07-29 06:46:16 --> Language Class Initialized
INFO - 2020-07-29 06:46:16 --> Loader Class Initialized
INFO - 2020-07-29 06:46:16 --> Helper loaded: url_helper
INFO - 2020-07-29 06:46:16 --> Database Driver Class Initialized
INFO - 2020-07-29 06:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:46:16 --> Email Class Initialized
INFO - 2020-07-29 06:46:16 --> Controller Class Initialized
DEBUG - 2020-07-29 06:46:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:46:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:46:16 --> Model Class Initialized
INFO - 2020-07-29 06:46:16 --> Model Class Initialized
ERROR - 2020-07-29 06:46:16 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2020-07-29 06:46:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 06:46:16 --> Severity: Error --> Call to undefined method CI_DB_mysql_result::next_result() /home/purpu1ex/public_html/carsm/application/models/Admin_model.php 26
INFO - 2020-07-29 06:46:35 --> Config Class Initialized
INFO - 2020-07-29 06:46:35 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:46:35 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:46:35 --> Utf8 Class Initialized
INFO - 2020-07-29 06:46:35 --> URI Class Initialized
INFO - 2020-07-29 06:46:35 --> Router Class Initialized
INFO - 2020-07-29 06:46:35 --> Output Class Initialized
INFO - 2020-07-29 06:46:35 --> Security Class Initialized
DEBUG - 2020-07-29 06:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:46:35 --> Input Class Initialized
INFO - 2020-07-29 06:46:35 --> Language Class Initialized
INFO - 2020-07-29 06:46:35 --> Loader Class Initialized
INFO - 2020-07-29 06:46:35 --> Helper loaded: url_helper
INFO - 2020-07-29 06:46:35 --> Database Driver Class Initialized
INFO - 2020-07-29 06:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:46:35 --> Email Class Initialized
INFO - 2020-07-29 06:46:35 --> Controller Class Initialized
DEBUG - 2020-07-29 06:46:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:46:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:46:35 --> Model Class Initialized
INFO - 2020-07-29 06:46:35 --> Model Class Initialized
ERROR - 2020-07-29 06:46:35 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
INFO - 2020-07-29 06:46:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 06:46:35 --> Final output sent to browser
DEBUG - 2020-07-29 06:46:35 --> Total execution time: 0.0251
INFO - 2020-07-29 06:49:23 --> Config Class Initialized
INFO - 2020-07-29 06:49:23 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:49:23 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:49:23 --> Utf8 Class Initialized
INFO - 2020-07-29 06:49:23 --> URI Class Initialized
INFO - 2020-07-29 06:49:23 --> Router Class Initialized
INFO - 2020-07-29 06:49:23 --> Output Class Initialized
INFO - 2020-07-29 06:49:23 --> Security Class Initialized
DEBUG - 2020-07-29 06:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:49:23 --> Input Class Initialized
INFO - 2020-07-29 06:49:23 --> Language Class Initialized
INFO - 2020-07-29 06:49:23 --> Loader Class Initialized
INFO - 2020-07-29 06:49:23 --> Helper loaded: url_helper
INFO - 2020-07-29 06:49:23 --> Database Driver Class Initialized
INFO - 2020-07-29 06:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:49:23 --> Email Class Initialized
INFO - 2020-07-29 06:49:23 --> Controller Class Initialized
DEBUG - 2020-07-29 06:49:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:49:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:49:23 --> Model Class Initialized
INFO - 2020-07-29 06:49:23 --> Model Class Initialized
INFO - 2020-07-29 06:49:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 06:49:23 --> Final output sent to browser
DEBUG - 2020-07-29 06:49:23 --> Total execution time: 0.0241
INFO - 2020-07-29 06:49:26 --> Config Class Initialized
INFO - 2020-07-29 06:49:26 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:49:26 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:49:26 --> Utf8 Class Initialized
INFO - 2020-07-29 06:49:26 --> URI Class Initialized
INFO - 2020-07-29 06:49:26 --> Router Class Initialized
INFO - 2020-07-29 06:49:26 --> Output Class Initialized
INFO - 2020-07-29 06:49:26 --> Security Class Initialized
DEBUG - 2020-07-29 06:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:49:26 --> Input Class Initialized
INFO - 2020-07-29 06:49:26 --> Language Class Initialized
INFO - 2020-07-29 06:49:26 --> Loader Class Initialized
INFO - 2020-07-29 06:49:26 --> Helper loaded: url_helper
INFO - 2020-07-29 06:49:26 --> Database Driver Class Initialized
INFO - 2020-07-29 06:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:49:26 --> Email Class Initialized
INFO - 2020-07-29 06:49:26 --> Controller Class Initialized
DEBUG - 2020-07-29 06:49:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:49:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:49:26 --> Model Class Initialized
INFO - 2020-07-29 06:49:26 --> Model Class Initialized
ERROR - 2020-07-29 06:49:26 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
INFO - 2020-07-29 06:49:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 06:49:26 --> Final output sent to browser
DEBUG - 2020-07-29 06:49:26 --> Total execution time: 0.0219
INFO - 2020-07-29 06:59:15 --> Config Class Initialized
INFO - 2020-07-29 06:59:15 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:59:15 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:59:15 --> Utf8 Class Initialized
INFO - 2020-07-29 06:59:15 --> URI Class Initialized
INFO - 2020-07-29 06:59:15 --> Router Class Initialized
INFO - 2020-07-29 06:59:15 --> Output Class Initialized
INFO - 2020-07-29 06:59:15 --> Security Class Initialized
DEBUG - 2020-07-29 06:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:59:15 --> Input Class Initialized
INFO - 2020-07-29 06:59:15 --> Language Class Initialized
INFO - 2020-07-29 06:59:15 --> Loader Class Initialized
INFO - 2020-07-29 06:59:15 --> Helper loaded: url_helper
INFO - 2020-07-29 06:59:15 --> Database Driver Class Initialized
INFO - 2020-07-29 06:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:59:15 --> Email Class Initialized
INFO - 2020-07-29 06:59:15 --> Controller Class Initialized
DEBUG - 2020-07-29 06:59:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:59:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:59:15 --> Model Class Initialized
INFO - 2020-07-29 06:59:15 --> Model Class Initialized
INFO - 2020-07-29 06:59:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 06:59:15 --> Final output sent to browser
DEBUG - 2020-07-29 06:59:15 --> Total execution time: 0.0225
INFO - 2020-07-29 06:59:18 --> Config Class Initialized
INFO - 2020-07-29 06:59:18 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:59:18 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:59:18 --> Utf8 Class Initialized
INFO - 2020-07-29 06:59:18 --> URI Class Initialized
INFO - 2020-07-29 06:59:18 --> Router Class Initialized
INFO - 2020-07-29 06:59:18 --> Output Class Initialized
INFO - 2020-07-29 06:59:18 --> Security Class Initialized
DEBUG - 2020-07-29 06:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:59:18 --> Input Class Initialized
INFO - 2020-07-29 06:59:18 --> Language Class Initialized
INFO - 2020-07-29 06:59:18 --> Loader Class Initialized
INFO - 2020-07-29 06:59:18 --> Helper loaded: url_helper
INFO - 2020-07-29 06:59:18 --> Database Driver Class Initialized
INFO - 2020-07-29 06:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:59:18 --> Email Class Initialized
INFO - 2020-07-29 06:59:18 --> Controller Class Initialized
DEBUG - 2020-07-29 06:59:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:59:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:59:18 --> Model Class Initialized
INFO - 2020-07-29 06:59:18 --> Model Class Initialized
ERROR - 2020-07-29 06:59:18 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
INFO - 2020-07-29 06:59:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 06:59:18 --> Final output sent to browser
DEBUG - 2020-07-29 06:59:18 --> Total execution time: 0.0242
INFO - 2020-07-29 06:59:24 --> Config Class Initialized
INFO - 2020-07-29 06:59:24 --> Hooks Class Initialized
DEBUG - 2020-07-29 06:59:24 --> UTF-8 Support Enabled
INFO - 2020-07-29 06:59:24 --> Utf8 Class Initialized
INFO - 2020-07-29 06:59:24 --> URI Class Initialized
INFO - 2020-07-29 06:59:24 --> Router Class Initialized
INFO - 2020-07-29 06:59:24 --> Output Class Initialized
INFO - 2020-07-29 06:59:24 --> Security Class Initialized
DEBUG - 2020-07-29 06:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 06:59:24 --> Input Class Initialized
INFO - 2020-07-29 06:59:24 --> Language Class Initialized
INFO - 2020-07-29 06:59:24 --> Loader Class Initialized
INFO - 2020-07-29 06:59:24 --> Helper loaded: url_helper
INFO - 2020-07-29 06:59:24 --> Database Driver Class Initialized
INFO - 2020-07-29 06:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 06:59:24 --> Email Class Initialized
INFO - 2020-07-29 06:59:24 --> Controller Class Initialized
DEBUG - 2020-07-29 06:59:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 06:59:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 06:59:24 --> Model Class Initialized
INFO - 2020-07-29 06:59:24 --> Model Class Initialized
ERROR - 2020-07-29 06:59:24 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
INFO - 2020-07-29 06:59:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 06:59:24 --> Final output sent to browser
DEBUG - 2020-07-29 06:59:24 --> Total execution time: 0.0284
INFO - 2020-07-29 07:00:30 --> Config Class Initialized
INFO - 2020-07-29 07:00:30 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:00:30 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:00:30 --> Utf8 Class Initialized
INFO - 2020-07-29 07:00:30 --> URI Class Initialized
INFO - 2020-07-29 07:00:30 --> Router Class Initialized
INFO - 2020-07-29 07:00:30 --> Output Class Initialized
INFO - 2020-07-29 07:00:30 --> Security Class Initialized
DEBUG - 2020-07-29 07:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:00:30 --> Input Class Initialized
INFO - 2020-07-29 07:00:30 --> Language Class Initialized
INFO - 2020-07-29 07:00:30 --> Loader Class Initialized
INFO - 2020-07-29 07:00:30 --> Helper loaded: url_helper
INFO - 2020-07-29 07:00:30 --> Database Driver Class Initialized
INFO - 2020-07-29 07:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:00:30 --> Email Class Initialized
INFO - 2020-07-29 07:00:30 --> Controller Class Initialized
DEBUG - 2020-07-29 07:00:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:00:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:00:30 --> Model Class Initialized
INFO - 2020-07-29 07:00:30 --> Model Class Initialized
INFO - 2020-07-29 07:00:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 07:00:30 --> Final output sent to browser
DEBUG - 2020-07-29 07:00:30 --> Total execution time: 0.0258
INFO - 2020-07-29 07:00:37 --> Config Class Initialized
INFO - 2020-07-29 07:00:37 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:00:37 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:00:37 --> Utf8 Class Initialized
INFO - 2020-07-29 07:00:37 --> URI Class Initialized
INFO - 2020-07-29 07:00:37 --> Router Class Initialized
INFO - 2020-07-29 07:00:37 --> Output Class Initialized
INFO - 2020-07-29 07:00:37 --> Security Class Initialized
DEBUG - 2020-07-29 07:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:00:37 --> Input Class Initialized
INFO - 2020-07-29 07:00:37 --> Language Class Initialized
INFO - 2020-07-29 07:00:37 --> Loader Class Initialized
INFO - 2020-07-29 07:00:37 --> Helper loaded: url_helper
INFO - 2020-07-29 07:00:37 --> Database Driver Class Initialized
INFO - 2020-07-29 07:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:00:37 --> Email Class Initialized
INFO - 2020-07-29 07:00:37 --> Controller Class Initialized
DEBUG - 2020-07-29 07:00:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:00:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:00:37 --> Model Class Initialized
INFO - 2020-07-29 07:00:37 --> Model Class Initialized
ERROR - 2020-07-29 07:00:37 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
INFO - 2020-07-29 07:00:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 07:00:37 --> Final output sent to browser
DEBUG - 2020-07-29 07:00:37 --> Total execution time: 0.0293
INFO - 2020-07-29 07:00:44 --> Config Class Initialized
INFO - 2020-07-29 07:00:44 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:00:44 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:00:44 --> Utf8 Class Initialized
INFO - 2020-07-29 07:00:44 --> URI Class Initialized
INFO - 2020-07-29 07:00:44 --> Router Class Initialized
INFO - 2020-07-29 07:00:44 --> Output Class Initialized
INFO - 2020-07-29 07:00:44 --> Security Class Initialized
DEBUG - 2020-07-29 07:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:00:44 --> Input Class Initialized
INFO - 2020-07-29 07:00:44 --> Language Class Initialized
INFO - 2020-07-29 07:00:44 --> Loader Class Initialized
INFO - 2020-07-29 07:00:44 --> Helper loaded: url_helper
INFO - 2020-07-29 07:00:44 --> Database Driver Class Initialized
INFO - 2020-07-29 07:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:00:44 --> Email Class Initialized
INFO - 2020-07-29 07:00:44 --> Controller Class Initialized
DEBUG - 2020-07-29 07:00:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:00:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:00:44 --> Model Class Initialized
INFO - 2020-07-29 07:00:44 --> Model Class Initialized
INFO - 2020-07-29 07:00:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 07:00:44 --> Final output sent to browser
DEBUG - 2020-07-29 07:00:44 --> Total execution time: 0.0251
INFO - 2020-07-29 07:00:54 --> Config Class Initialized
INFO - 2020-07-29 07:00:54 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:00:54 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:00:54 --> Utf8 Class Initialized
INFO - 2020-07-29 07:00:54 --> URI Class Initialized
INFO - 2020-07-29 07:00:54 --> Router Class Initialized
INFO - 2020-07-29 07:00:54 --> Output Class Initialized
INFO - 2020-07-29 07:00:54 --> Security Class Initialized
DEBUG - 2020-07-29 07:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:00:54 --> Input Class Initialized
INFO - 2020-07-29 07:00:54 --> Language Class Initialized
INFO - 2020-07-29 07:00:54 --> Loader Class Initialized
INFO - 2020-07-29 07:00:54 --> Helper loaded: url_helper
INFO - 2020-07-29 07:00:54 --> Database Driver Class Initialized
INFO - 2020-07-29 07:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:00:54 --> Email Class Initialized
INFO - 2020-07-29 07:00:54 --> Controller Class Initialized
DEBUG - 2020-07-29 07:00:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:00:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:00:54 --> Model Class Initialized
INFO - 2020-07-29 07:00:54 --> Model Class Initialized
INFO - 2020-07-29 07:00:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 07:00:54 --> Final output sent to browser
DEBUG - 2020-07-29 07:00:54 --> Total execution time: 0.0246
INFO - 2020-07-29 07:01:03 --> Config Class Initialized
INFO - 2020-07-29 07:01:03 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:01:03 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:01:03 --> Utf8 Class Initialized
INFO - 2020-07-29 07:01:03 --> URI Class Initialized
INFO - 2020-07-29 07:01:03 --> Router Class Initialized
INFO - 2020-07-29 07:01:03 --> Output Class Initialized
INFO - 2020-07-29 07:01:03 --> Security Class Initialized
DEBUG - 2020-07-29 07:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:01:03 --> Input Class Initialized
INFO - 2020-07-29 07:01:03 --> Language Class Initialized
INFO - 2020-07-29 07:01:03 --> Loader Class Initialized
INFO - 2020-07-29 07:01:03 --> Helper loaded: url_helper
INFO - 2020-07-29 07:01:03 --> Database Driver Class Initialized
INFO - 2020-07-29 07:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:01:03 --> Email Class Initialized
INFO - 2020-07-29 07:01:03 --> Controller Class Initialized
DEBUG - 2020-07-29 07:01:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:01:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:01:03 --> Model Class Initialized
INFO - 2020-07-29 07:01:03 --> Model Class Initialized
INFO - 2020-07-29 07:01:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 07:01:03 --> Final output sent to browser
DEBUG - 2020-07-29 07:01:03 --> Total execution time: 0.0262
INFO - 2020-07-29 07:01:05 --> Config Class Initialized
INFO - 2020-07-29 07:01:05 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:01:05 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:01:05 --> Utf8 Class Initialized
INFO - 2020-07-29 07:01:05 --> URI Class Initialized
INFO - 2020-07-29 07:01:05 --> Router Class Initialized
INFO - 2020-07-29 07:01:05 --> Output Class Initialized
INFO - 2020-07-29 07:01:05 --> Security Class Initialized
DEBUG - 2020-07-29 07:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:01:05 --> Input Class Initialized
INFO - 2020-07-29 07:01:05 --> Language Class Initialized
INFO - 2020-07-29 07:01:05 --> Loader Class Initialized
INFO - 2020-07-29 07:01:05 --> Helper loaded: url_helper
INFO - 2020-07-29 07:01:05 --> Database Driver Class Initialized
INFO - 2020-07-29 07:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:01:05 --> Email Class Initialized
INFO - 2020-07-29 07:01:05 --> Controller Class Initialized
DEBUG - 2020-07-29 07:01:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:01:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:01:05 --> Model Class Initialized
INFO - 2020-07-29 07:01:05 --> Model Class Initialized
ERROR - 2020-07-29 07:01:05 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
INFO - 2020-07-29 07:01:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 07:01:05 --> Final output sent to browser
DEBUG - 2020-07-29 07:01:05 --> Total execution time: 0.0286
INFO - 2020-07-29 07:01:10 --> Config Class Initialized
INFO - 2020-07-29 07:01:10 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:01:10 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:01:10 --> Utf8 Class Initialized
INFO - 2020-07-29 07:01:10 --> URI Class Initialized
INFO - 2020-07-29 07:01:10 --> Router Class Initialized
INFO - 2020-07-29 07:01:10 --> Output Class Initialized
INFO - 2020-07-29 07:01:10 --> Security Class Initialized
DEBUG - 2020-07-29 07:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:01:10 --> Input Class Initialized
INFO - 2020-07-29 07:01:10 --> Language Class Initialized
INFO - 2020-07-29 07:01:10 --> Loader Class Initialized
INFO - 2020-07-29 07:01:10 --> Helper loaded: url_helper
INFO - 2020-07-29 07:01:10 --> Database Driver Class Initialized
INFO - 2020-07-29 07:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:01:10 --> Email Class Initialized
INFO - 2020-07-29 07:01:10 --> Controller Class Initialized
DEBUG - 2020-07-29 07:01:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:01:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:01:10 --> Model Class Initialized
INFO - 2020-07-29 07:01:10 --> Model Class Initialized
INFO - 2020-07-29 07:01:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 07:01:10 --> Final output sent to browser
DEBUG - 2020-07-29 07:01:10 --> Total execution time: 0.0279
INFO - 2020-07-29 07:01:20 --> Config Class Initialized
INFO - 2020-07-29 07:01:20 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:01:20 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:01:20 --> Utf8 Class Initialized
INFO - 2020-07-29 07:01:20 --> URI Class Initialized
INFO - 2020-07-29 07:01:20 --> Router Class Initialized
INFO - 2020-07-29 07:01:20 --> Output Class Initialized
INFO - 2020-07-29 07:01:20 --> Security Class Initialized
DEBUG - 2020-07-29 07:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:01:20 --> Input Class Initialized
INFO - 2020-07-29 07:01:20 --> Language Class Initialized
INFO - 2020-07-29 07:01:20 --> Loader Class Initialized
INFO - 2020-07-29 07:01:20 --> Helper loaded: url_helper
INFO - 2020-07-29 07:01:20 --> Database Driver Class Initialized
INFO - 2020-07-29 07:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:01:20 --> Email Class Initialized
INFO - 2020-07-29 07:01:20 --> Controller Class Initialized
DEBUG - 2020-07-29 07:01:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:01:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:01:20 --> Model Class Initialized
INFO - 2020-07-29 07:01:20 --> Model Class Initialized
INFO - 2020-07-29 07:01:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 07:01:20 --> Final output sent to browser
DEBUG - 2020-07-29 07:01:20 --> Total execution time: 0.0268
INFO - 2020-07-29 07:01:43 --> Config Class Initialized
INFO - 2020-07-29 07:01:43 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:01:43 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:01:43 --> Utf8 Class Initialized
INFO - 2020-07-29 07:01:43 --> URI Class Initialized
INFO - 2020-07-29 07:01:43 --> Router Class Initialized
INFO - 2020-07-29 07:01:43 --> Output Class Initialized
INFO - 2020-07-29 07:01:43 --> Security Class Initialized
DEBUG - 2020-07-29 07:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:01:43 --> Input Class Initialized
INFO - 2020-07-29 07:01:43 --> Language Class Initialized
INFO - 2020-07-29 07:01:43 --> Loader Class Initialized
INFO - 2020-07-29 07:01:43 --> Helper loaded: url_helper
INFO - 2020-07-29 07:01:43 --> Database Driver Class Initialized
INFO - 2020-07-29 07:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:01:43 --> Email Class Initialized
INFO - 2020-07-29 07:01:43 --> Controller Class Initialized
DEBUG - 2020-07-29 07:01:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:01:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:01:43 --> Model Class Initialized
INFO - 2020-07-29 07:01:43 --> Model Class Initialized
INFO - 2020-07-29 07:01:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 07:01:43 --> Final output sent to browser
DEBUG - 2020-07-29 07:01:43 --> Total execution time: 0.0268
INFO - 2020-07-29 07:01:49 --> Config Class Initialized
INFO - 2020-07-29 07:01:49 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:01:49 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:01:49 --> Utf8 Class Initialized
INFO - 2020-07-29 07:01:49 --> URI Class Initialized
INFO - 2020-07-29 07:01:49 --> Router Class Initialized
INFO - 2020-07-29 07:01:49 --> Output Class Initialized
INFO - 2020-07-29 07:01:49 --> Security Class Initialized
DEBUG - 2020-07-29 07:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:01:49 --> Input Class Initialized
INFO - 2020-07-29 07:01:49 --> Language Class Initialized
INFO - 2020-07-29 07:01:49 --> Loader Class Initialized
INFO - 2020-07-29 07:01:49 --> Helper loaded: url_helper
INFO - 2020-07-29 07:01:49 --> Database Driver Class Initialized
INFO - 2020-07-29 07:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:01:49 --> Email Class Initialized
INFO - 2020-07-29 07:01:49 --> Controller Class Initialized
DEBUG - 2020-07-29 07:01:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:01:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:01:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-29 07:01:49 --> Final output sent to browser
DEBUG - 2020-07-29 07:01:49 --> Total execution time: 0.0213
INFO - 2020-07-29 07:05:42 --> Config Class Initialized
INFO - 2020-07-29 07:05:42 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:05:42 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:05:42 --> Utf8 Class Initialized
INFO - 2020-07-29 07:05:42 --> URI Class Initialized
INFO - 2020-07-29 07:05:42 --> Router Class Initialized
INFO - 2020-07-29 07:05:42 --> Output Class Initialized
INFO - 2020-07-29 07:05:42 --> Security Class Initialized
DEBUG - 2020-07-29 07:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:05:42 --> Input Class Initialized
INFO - 2020-07-29 07:05:42 --> Language Class Initialized
INFO - 2020-07-29 07:05:42 --> Loader Class Initialized
INFO - 2020-07-29 07:05:42 --> Helper loaded: url_helper
INFO - 2020-07-29 07:05:42 --> Database Driver Class Initialized
INFO - 2020-07-29 07:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:05:42 --> Email Class Initialized
INFO - 2020-07-29 07:05:42 --> Controller Class Initialized
DEBUG - 2020-07-29 07:05:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:05:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:05:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-29 07:05:42 --> Final output sent to browser
DEBUG - 2020-07-29 07:05:42 --> Total execution time: 0.0240
INFO - 2020-07-29 07:06:03 --> Config Class Initialized
INFO - 2020-07-29 07:06:03 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:06:03 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:06:03 --> Utf8 Class Initialized
INFO - 2020-07-29 07:06:03 --> URI Class Initialized
INFO - 2020-07-29 07:06:03 --> Router Class Initialized
INFO - 2020-07-29 07:06:03 --> Output Class Initialized
INFO - 2020-07-29 07:06:03 --> Security Class Initialized
DEBUG - 2020-07-29 07:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:06:03 --> Input Class Initialized
INFO - 2020-07-29 07:06:03 --> Language Class Initialized
INFO - 2020-07-29 07:06:03 --> Loader Class Initialized
INFO - 2020-07-29 07:06:03 --> Helper loaded: url_helper
INFO - 2020-07-29 07:06:03 --> Database Driver Class Initialized
INFO - 2020-07-29 07:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:06:03 --> Email Class Initialized
INFO - 2020-07-29 07:06:03 --> Controller Class Initialized
DEBUG - 2020-07-29 07:06:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:06:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:06:03 --> Model Class Initialized
INFO - 2020-07-29 07:06:03 --> Model Class Initialized
ERROR - 2020-07-29 07:06:03 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
INFO - 2020-07-29 07:06:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 07:06:03 --> Final output sent to browser
DEBUG - 2020-07-29 07:06:03 --> Total execution time: 0.0270
INFO - 2020-07-29 07:06:35 --> Config Class Initialized
INFO - 2020-07-29 07:06:35 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:06:35 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:06:35 --> Utf8 Class Initialized
INFO - 2020-07-29 07:06:35 --> URI Class Initialized
INFO - 2020-07-29 07:06:35 --> Router Class Initialized
INFO - 2020-07-29 07:06:35 --> Output Class Initialized
INFO - 2020-07-29 07:06:35 --> Security Class Initialized
DEBUG - 2020-07-29 07:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:06:35 --> Input Class Initialized
INFO - 2020-07-29 07:06:35 --> Language Class Initialized
INFO - 2020-07-29 07:06:35 --> Loader Class Initialized
INFO - 2020-07-29 07:06:35 --> Helper loaded: url_helper
INFO - 2020-07-29 07:06:35 --> Database Driver Class Initialized
INFO - 2020-07-29 07:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:06:35 --> Email Class Initialized
INFO - 2020-07-29 07:06:35 --> Controller Class Initialized
DEBUG - 2020-07-29 07:06:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:06:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:06:35 --> Model Class Initialized
INFO - 2020-07-29 07:06:35 --> Model Class Initialized
INFO - 2020-07-29 07:06:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 07:06:35 --> Final output sent to browser
DEBUG - 2020-07-29 07:06:35 --> Total execution time: 0.0278
INFO - 2020-07-29 07:06:48 --> Config Class Initialized
INFO - 2020-07-29 07:06:48 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:06:48 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:06:48 --> Utf8 Class Initialized
INFO - 2020-07-29 07:06:48 --> URI Class Initialized
INFO - 2020-07-29 07:06:48 --> Router Class Initialized
INFO - 2020-07-29 07:06:48 --> Output Class Initialized
INFO - 2020-07-29 07:06:48 --> Security Class Initialized
DEBUG - 2020-07-29 07:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:06:48 --> Input Class Initialized
INFO - 2020-07-29 07:06:48 --> Language Class Initialized
INFO - 2020-07-29 07:06:48 --> Loader Class Initialized
INFO - 2020-07-29 07:06:48 --> Helper loaded: url_helper
INFO - 2020-07-29 07:06:48 --> Database Driver Class Initialized
INFO - 2020-07-29 07:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:06:48 --> Email Class Initialized
INFO - 2020-07-29 07:06:48 --> Controller Class Initialized
DEBUG - 2020-07-29 07:06:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:06:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:06:48 --> Model Class Initialized
INFO - 2020-07-29 07:06:48 --> Model Class Initialized
INFO - 2020-07-29 07:06:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-07-29 07:06:48 --> Final output sent to browser
DEBUG - 2020-07-29 07:06:48 --> Total execution time: 0.0220
INFO - 2020-07-29 07:06:53 --> Config Class Initialized
INFO - 2020-07-29 07:06:53 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:06:53 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:06:53 --> Utf8 Class Initialized
INFO - 2020-07-29 07:06:53 --> URI Class Initialized
INFO - 2020-07-29 07:06:53 --> Router Class Initialized
INFO - 2020-07-29 07:06:53 --> Output Class Initialized
INFO - 2020-07-29 07:06:53 --> Security Class Initialized
DEBUG - 2020-07-29 07:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:06:53 --> Input Class Initialized
INFO - 2020-07-29 07:06:53 --> Language Class Initialized
INFO - 2020-07-29 07:06:53 --> Loader Class Initialized
INFO - 2020-07-29 07:06:53 --> Helper loaded: url_helper
INFO - 2020-07-29 07:06:53 --> Database Driver Class Initialized
INFO - 2020-07-29 07:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:06:53 --> Email Class Initialized
INFO - 2020-07-29 07:06:53 --> Controller Class Initialized
DEBUG - 2020-07-29 07:06:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:06:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:06:53 --> Model Class Initialized
INFO - 2020-07-29 07:06:53 --> Model Class Initialized
INFO - 2020-07-29 07:06:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 07:06:53 --> Final output sent to browser
DEBUG - 2020-07-29 07:06:53 --> Total execution time: 0.0255
INFO - 2020-07-29 07:06:57 --> Config Class Initialized
INFO - 2020-07-29 07:06:57 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:06:57 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:06:57 --> Utf8 Class Initialized
INFO - 2020-07-29 07:06:57 --> URI Class Initialized
INFO - 2020-07-29 07:06:57 --> Router Class Initialized
INFO - 2020-07-29 07:06:57 --> Output Class Initialized
INFO - 2020-07-29 07:06:57 --> Security Class Initialized
DEBUG - 2020-07-29 07:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:06:57 --> Input Class Initialized
INFO - 2020-07-29 07:06:57 --> Language Class Initialized
INFO - 2020-07-29 07:06:57 --> Loader Class Initialized
INFO - 2020-07-29 07:06:57 --> Helper loaded: url_helper
INFO - 2020-07-29 07:06:58 --> Database Driver Class Initialized
INFO - 2020-07-29 07:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:06:58 --> Email Class Initialized
INFO - 2020-07-29 07:06:58 --> Controller Class Initialized
DEBUG - 2020-07-29 07:06:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:06:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:06:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-29 07:06:58 --> Final output sent to browser
DEBUG - 2020-07-29 07:06:58 --> Total execution time: 0.0281
INFO - 2020-07-29 07:07:47 --> Config Class Initialized
INFO - 2020-07-29 07:07:47 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:07:47 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:07:47 --> Utf8 Class Initialized
INFO - 2020-07-29 07:07:47 --> URI Class Initialized
INFO - 2020-07-29 07:07:47 --> Router Class Initialized
INFO - 2020-07-29 07:07:47 --> Output Class Initialized
INFO - 2020-07-29 07:07:47 --> Security Class Initialized
DEBUG - 2020-07-29 07:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:07:47 --> Input Class Initialized
INFO - 2020-07-29 07:07:47 --> Language Class Initialized
INFO - 2020-07-29 07:07:47 --> Loader Class Initialized
INFO - 2020-07-29 07:07:47 --> Helper loaded: url_helper
INFO - 2020-07-29 07:07:47 --> Database Driver Class Initialized
INFO - 2020-07-29 07:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:07:47 --> Email Class Initialized
INFO - 2020-07-29 07:07:47 --> Controller Class Initialized
DEBUG - 2020-07-29 07:07:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:07:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:07:47 --> Model Class Initialized
INFO - 2020-07-29 07:07:47 --> Model Class Initialized
INFO - 2020-07-29 07:07:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 07:07:47 --> Final output sent to browser
DEBUG - 2020-07-29 07:07:47 --> Total execution time: 0.0231
INFO - 2020-07-29 07:09:57 --> Config Class Initialized
INFO - 2020-07-29 07:09:57 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:09:57 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:09:57 --> Utf8 Class Initialized
INFO - 2020-07-29 07:09:57 --> URI Class Initialized
DEBUG - 2020-07-29 07:09:57 --> No URI present. Default controller set.
INFO - 2020-07-29 07:09:57 --> Router Class Initialized
INFO - 2020-07-29 07:09:57 --> Output Class Initialized
INFO - 2020-07-29 07:09:57 --> Security Class Initialized
DEBUG - 2020-07-29 07:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:09:57 --> Input Class Initialized
INFO - 2020-07-29 07:09:57 --> Language Class Initialized
INFO - 2020-07-29 07:09:57 --> Loader Class Initialized
INFO - 2020-07-29 07:09:57 --> Helper loaded: url_helper
INFO - 2020-07-29 07:09:57 --> Database Driver Class Initialized
INFO - 2020-07-29 07:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:09:57 --> Email Class Initialized
INFO - 2020-07-29 07:09:57 --> Controller Class Initialized
INFO - 2020-07-29 07:09:57 --> Model Class Initialized
INFO - 2020-07-29 07:09:57 --> Model Class Initialized
DEBUG - 2020-07-29 07:09:57 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:09:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 07:09:57 --> Final output sent to browser
DEBUG - 2020-07-29 07:09:57 --> Total execution time: 0.0214
INFO - 2020-07-29 07:09:59 --> Config Class Initialized
INFO - 2020-07-29 07:09:59 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:09:59 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:09:59 --> Utf8 Class Initialized
INFO - 2020-07-29 07:09:59 --> URI Class Initialized
INFO - 2020-07-29 07:09:59 --> Router Class Initialized
INFO - 2020-07-29 07:09:59 --> Output Class Initialized
INFO - 2020-07-29 07:09:59 --> Security Class Initialized
DEBUG - 2020-07-29 07:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:09:59 --> Input Class Initialized
INFO - 2020-07-29 07:09:59 --> Language Class Initialized
INFO - 2020-07-29 07:09:59 --> Loader Class Initialized
INFO - 2020-07-29 07:09:59 --> Helper loaded: url_helper
INFO - 2020-07-29 07:09:59 --> Database Driver Class Initialized
INFO - 2020-07-29 07:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:09:59 --> Email Class Initialized
INFO - 2020-07-29 07:09:59 --> Controller Class Initialized
INFO - 2020-07-29 07:09:59 --> Model Class Initialized
INFO - 2020-07-29 07:09:59 --> Model Class Initialized
DEBUG - 2020-07-29 07:09:59 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:10:00 --> Config Class Initialized
INFO - 2020-07-29 07:10:00 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:10:00 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:10:00 --> Utf8 Class Initialized
INFO - 2020-07-29 07:10:00 --> URI Class Initialized
INFO - 2020-07-29 07:10:00 --> Router Class Initialized
INFO - 2020-07-29 07:10:00 --> Output Class Initialized
INFO - 2020-07-29 07:10:00 --> Security Class Initialized
DEBUG - 2020-07-29 07:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:10:00 --> Input Class Initialized
INFO - 2020-07-29 07:10:00 --> Language Class Initialized
INFO - 2020-07-29 07:10:00 --> Loader Class Initialized
INFO - 2020-07-29 07:10:00 --> Helper loaded: url_helper
INFO - 2020-07-29 07:10:00 --> Database Driver Class Initialized
INFO - 2020-07-29 07:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:10:00 --> Email Class Initialized
INFO - 2020-07-29 07:10:00 --> Controller Class Initialized
DEBUG - 2020-07-29 07:10:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:10:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:10:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 07:10:00 --> Final output sent to browser
DEBUG - 2020-07-29 07:10:00 --> Total execution time: 0.0231
INFO - 2020-07-29 07:10:36 --> Config Class Initialized
INFO - 2020-07-29 07:10:36 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:10:36 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:10:36 --> Utf8 Class Initialized
INFO - 2020-07-29 07:10:36 --> URI Class Initialized
INFO - 2020-07-29 07:10:36 --> Router Class Initialized
INFO - 2020-07-29 07:10:36 --> Output Class Initialized
INFO - 2020-07-29 07:10:36 --> Security Class Initialized
DEBUG - 2020-07-29 07:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:10:36 --> Input Class Initialized
INFO - 2020-07-29 07:10:36 --> Language Class Initialized
INFO - 2020-07-29 07:10:36 --> Loader Class Initialized
INFO - 2020-07-29 07:10:36 --> Helper loaded: url_helper
INFO - 2020-07-29 07:10:36 --> Database Driver Class Initialized
INFO - 2020-07-29 07:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:10:36 --> Email Class Initialized
INFO - 2020-07-29 07:10:36 --> Controller Class Initialized
DEBUG - 2020-07-29 07:10:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:10:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:10:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 07:10:36 --> Final output sent to browser
DEBUG - 2020-07-29 07:10:36 --> Total execution time: 0.0203
INFO - 2020-07-29 07:11:22 --> Config Class Initialized
INFO - 2020-07-29 07:11:22 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:11:22 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:11:22 --> Utf8 Class Initialized
INFO - 2020-07-29 07:11:22 --> URI Class Initialized
INFO - 2020-07-29 07:11:22 --> Router Class Initialized
INFO - 2020-07-29 07:11:22 --> Output Class Initialized
INFO - 2020-07-29 07:11:22 --> Security Class Initialized
DEBUG - 2020-07-29 07:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:11:22 --> Input Class Initialized
INFO - 2020-07-29 07:11:22 --> Language Class Initialized
INFO - 2020-07-29 07:11:22 --> Loader Class Initialized
INFO - 2020-07-29 07:11:22 --> Helper loaded: url_helper
INFO - 2020-07-29 07:11:22 --> Database Driver Class Initialized
INFO - 2020-07-29 07:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:11:22 --> Email Class Initialized
INFO - 2020-07-29 07:11:22 --> Controller Class Initialized
DEBUG - 2020-07-29 07:11:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:11:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:11:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 07:11:22 --> Final output sent to browser
DEBUG - 2020-07-29 07:11:22 --> Total execution time: 0.0241
INFO - 2020-07-29 07:11:25 --> Config Class Initialized
INFO - 2020-07-29 07:11:25 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:11:25 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:11:25 --> Utf8 Class Initialized
INFO - 2020-07-29 07:11:25 --> URI Class Initialized
INFO - 2020-07-29 07:11:25 --> Router Class Initialized
INFO - 2020-07-29 07:11:25 --> Output Class Initialized
INFO - 2020-07-29 07:11:25 --> Security Class Initialized
DEBUG - 2020-07-29 07:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:11:25 --> Input Class Initialized
INFO - 2020-07-29 07:11:25 --> Language Class Initialized
INFO - 2020-07-29 07:11:25 --> Loader Class Initialized
INFO - 2020-07-29 07:11:25 --> Helper loaded: url_helper
INFO - 2020-07-29 07:11:25 --> Database Driver Class Initialized
INFO - 2020-07-29 07:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:11:25 --> Email Class Initialized
INFO - 2020-07-29 07:11:25 --> Controller Class Initialized
DEBUG - 2020-07-29 07:11:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:11:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:11:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 07:11:25 --> Final output sent to browser
DEBUG - 2020-07-29 07:11:25 --> Total execution time: 0.0217
INFO - 2020-07-29 07:11:29 --> Config Class Initialized
INFO - 2020-07-29 07:11:29 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:11:29 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:11:29 --> Utf8 Class Initialized
INFO - 2020-07-29 07:11:29 --> URI Class Initialized
INFO - 2020-07-29 07:11:29 --> Router Class Initialized
INFO - 2020-07-29 07:11:29 --> Output Class Initialized
INFO - 2020-07-29 07:11:29 --> Security Class Initialized
DEBUG - 2020-07-29 07:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:11:29 --> Input Class Initialized
INFO - 2020-07-29 07:11:29 --> Language Class Initialized
INFO - 2020-07-29 07:11:29 --> Loader Class Initialized
INFO - 2020-07-29 07:11:29 --> Helper loaded: url_helper
INFO - 2020-07-29 07:11:29 --> Database Driver Class Initialized
INFO - 2020-07-29 07:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:11:29 --> Email Class Initialized
INFO - 2020-07-29 07:11:29 --> Controller Class Initialized
DEBUG - 2020-07-29 07:11:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:11:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:11:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 07:11:29 --> Final output sent to browser
DEBUG - 2020-07-29 07:11:29 --> Total execution time: 0.0220
INFO - 2020-07-29 07:11:35 --> Config Class Initialized
INFO - 2020-07-29 07:11:35 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:11:35 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:11:35 --> Utf8 Class Initialized
INFO - 2020-07-29 07:11:35 --> URI Class Initialized
DEBUG - 2020-07-29 07:11:35 --> No URI present. Default controller set.
INFO - 2020-07-29 07:11:35 --> Router Class Initialized
INFO - 2020-07-29 07:11:35 --> Output Class Initialized
INFO - 2020-07-29 07:11:35 --> Security Class Initialized
DEBUG - 2020-07-29 07:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:11:35 --> Input Class Initialized
INFO - 2020-07-29 07:11:35 --> Language Class Initialized
INFO - 2020-07-29 07:11:35 --> Loader Class Initialized
INFO - 2020-07-29 07:11:35 --> Helper loaded: url_helper
INFO - 2020-07-29 07:11:35 --> Database Driver Class Initialized
INFO - 2020-07-29 07:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:11:35 --> Email Class Initialized
INFO - 2020-07-29 07:11:35 --> Controller Class Initialized
INFO - 2020-07-29 07:11:35 --> Model Class Initialized
INFO - 2020-07-29 07:11:35 --> Model Class Initialized
DEBUG - 2020-07-29 07:11:35 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:11:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 07:11:35 --> Final output sent to browser
DEBUG - 2020-07-29 07:11:35 --> Total execution time: 0.0256
INFO - 2020-07-29 07:11:38 --> Config Class Initialized
INFO - 2020-07-29 07:11:38 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:11:38 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:11:38 --> Utf8 Class Initialized
INFO - 2020-07-29 07:11:38 --> URI Class Initialized
INFO - 2020-07-29 07:11:38 --> Router Class Initialized
INFO - 2020-07-29 07:11:38 --> Output Class Initialized
INFO - 2020-07-29 07:11:38 --> Security Class Initialized
DEBUG - 2020-07-29 07:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:11:38 --> Input Class Initialized
INFO - 2020-07-29 07:11:38 --> Language Class Initialized
INFO - 2020-07-29 07:11:38 --> Loader Class Initialized
INFO - 2020-07-29 07:11:38 --> Helper loaded: url_helper
INFO - 2020-07-29 07:11:38 --> Database Driver Class Initialized
INFO - 2020-07-29 07:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:11:38 --> Email Class Initialized
INFO - 2020-07-29 07:11:38 --> Controller Class Initialized
INFO - 2020-07-29 07:11:38 --> Model Class Initialized
INFO - 2020-07-29 07:11:38 --> Model Class Initialized
DEBUG - 2020-07-29 07:11:38 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:11:38 --> Config Class Initialized
INFO - 2020-07-29 07:11:38 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:11:38 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:11:38 --> Utf8 Class Initialized
INFO - 2020-07-29 07:11:38 --> URI Class Initialized
INFO - 2020-07-29 07:11:38 --> Router Class Initialized
INFO - 2020-07-29 07:11:38 --> Output Class Initialized
INFO - 2020-07-29 07:11:38 --> Security Class Initialized
DEBUG - 2020-07-29 07:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:11:38 --> Input Class Initialized
INFO - 2020-07-29 07:11:38 --> Language Class Initialized
INFO - 2020-07-29 07:11:38 --> Loader Class Initialized
INFO - 2020-07-29 07:11:38 --> Helper loaded: url_helper
INFO - 2020-07-29 07:11:38 --> Database Driver Class Initialized
INFO - 2020-07-29 07:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:11:39 --> Email Class Initialized
INFO - 2020-07-29 07:11:39 --> Controller Class Initialized
DEBUG - 2020-07-29 07:11:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:11:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:11:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 07:11:39 --> Final output sent to browser
DEBUG - 2020-07-29 07:11:39 --> Total execution time: 0.3326
INFO - 2020-07-29 07:12:32 --> Config Class Initialized
INFO - 2020-07-29 07:12:32 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:12:32 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:12:32 --> Utf8 Class Initialized
INFO - 2020-07-29 07:12:32 --> URI Class Initialized
INFO - 2020-07-29 07:12:32 --> Router Class Initialized
INFO - 2020-07-29 07:12:32 --> Output Class Initialized
INFO - 2020-07-29 07:12:32 --> Security Class Initialized
DEBUG - 2020-07-29 07:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:12:32 --> Input Class Initialized
INFO - 2020-07-29 07:12:32 --> Language Class Initialized
INFO - 2020-07-29 07:12:32 --> Loader Class Initialized
INFO - 2020-07-29 07:12:32 --> Helper loaded: url_helper
INFO - 2020-07-29 07:12:32 --> Database Driver Class Initialized
INFO - 2020-07-29 07:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:12:32 --> Email Class Initialized
INFO - 2020-07-29 07:12:32 --> Controller Class Initialized
DEBUG - 2020-07-29 07:12:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:12:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:12:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 07:12:32 --> Final output sent to browser
DEBUG - 2020-07-29 07:12:32 --> Total execution time: 0.0226
INFO - 2020-07-29 07:12:34 --> Config Class Initialized
INFO - 2020-07-29 07:12:34 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:12:34 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:12:34 --> Utf8 Class Initialized
INFO - 2020-07-29 07:12:34 --> URI Class Initialized
DEBUG - 2020-07-29 07:12:34 --> No URI present. Default controller set.
INFO - 2020-07-29 07:12:34 --> Router Class Initialized
INFO - 2020-07-29 07:12:34 --> Output Class Initialized
INFO - 2020-07-29 07:12:34 --> Security Class Initialized
DEBUG - 2020-07-29 07:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:12:34 --> Input Class Initialized
INFO - 2020-07-29 07:12:34 --> Language Class Initialized
INFO - 2020-07-29 07:12:34 --> Loader Class Initialized
INFO - 2020-07-29 07:12:34 --> Helper loaded: url_helper
INFO - 2020-07-29 07:12:34 --> Database Driver Class Initialized
INFO - 2020-07-29 07:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:12:34 --> Email Class Initialized
INFO - 2020-07-29 07:12:34 --> Controller Class Initialized
INFO - 2020-07-29 07:12:34 --> Model Class Initialized
INFO - 2020-07-29 07:12:34 --> Model Class Initialized
DEBUG - 2020-07-29 07:12:34 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:12:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 07:12:34 --> Final output sent to browser
DEBUG - 2020-07-29 07:12:34 --> Total execution time: 0.0218
INFO - 2020-07-29 07:14:37 --> Config Class Initialized
INFO - 2020-07-29 07:14:37 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:14:37 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:14:37 --> Utf8 Class Initialized
INFO - 2020-07-29 07:14:37 --> URI Class Initialized
INFO - 2020-07-29 07:14:37 --> Router Class Initialized
INFO - 2020-07-29 07:14:37 --> Output Class Initialized
INFO - 2020-07-29 07:14:37 --> Security Class Initialized
DEBUG - 2020-07-29 07:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:14:37 --> Input Class Initialized
INFO - 2020-07-29 07:14:37 --> Language Class Initialized
INFO - 2020-07-29 07:14:37 --> Loader Class Initialized
INFO - 2020-07-29 07:14:37 --> Helper loaded: url_helper
INFO - 2020-07-29 07:14:37 --> Database Driver Class Initialized
INFO - 2020-07-29 07:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:14:37 --> Email Class Initialized
INFO - 2020-07-29 07:14:37 --> Controller Class Initialized
INFO - 2020-07-29 07:14:37 --> Model Class Initialized
INFO - 2020-07-29 07:14:37 --> Model Class Initialized
DEBUG - 2020-07-29 07:14:37 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:14:38 --> Config Class Initialized
INFO - 2020-07-29 07:14:38 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:14:38 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:14:38 --> Utf8 Class Initialized
INFO - 2020-07-29 07:14:38 --> URI Class Initialized
INFO - 2020-07-29 07:14:38 --> Router Class Initialized
INFO - 2020-07-29 07:14:38 --> Output Class Initialized
INFO - 2020-07-29 07:14:38 --> Security Class Initialized
DEBUG - 2020-07-29 07:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:14:38 --> Input Class Initialized
INFO - 2020-07-29 07:14:38 --> Language Class Initialized
INFO - 2020-07-29 07:14:38 --> Loader Class Initialized
INFO - 2020-07-29 07:14:38 --> Helper loaded: url_helper
INFO - 2020-07-29 07:14:38 --> Database Driver Class Initialized
INFO - 2020-07-29 07:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:14:38 --> Email Class Initialized
INFO - 2020-07-29 07:14:38 --> Controller Class Initialized
DEBUG - 2020-07-29 07:14:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:14:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:14:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 07:14:38 --> Final output sent to browser
DEBUG - 2020-07-29 07:14:38 --> Total execution time: 0.0297
INFO - 2020-07-29 07:16:57 --> Config Class Initialized
INFO - 2020-07-29 07:16:57 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:16:57 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:16:57 --> Utf8 Class Initialized
INFO - 2020-07-29 07:16:57 --> URI Class Initialized
INFO - 2020-07-29 07:16:57 --> Router Class Initialized
INFO - 2020-07-29 07:16:57 --> Output Class Initialized
INFO - 2020-07-29 07:16:57 --> Security Class Initialized
DEBUG - 2020-07-29 07:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:16:57 --> Input Class Initialized
INFO - 2020-07-29 07:16:57 --> Language Class Initialized
INFO - 2020-07-29 07:16:57 --> Loader Class Initialized
INFO - 2020-07-29 07:16:57 --> Helper loaded: url_helper
INFO - 2020-07-29 07:16:57 --> Database Driver Class Initialized
INFO - 2020-07-29 07:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:16:57 --> Email Class Initialized
INFO - 2020-07-29 07:16:57 --> Controller Class Initialized
DEBUG - 2020-07-29 07:16:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:16:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:16:57 --> Model Class Initialized
INFO - 2020-07-29 07:16:57 --> Model Class Initialized
INFO - 2020-07-29 07:16:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 07:16:57 --> Final output sent to browser
DEBUG - 2020-07-29 07:16:57 --> Total execution time: 0.0219
INFO - 2020-07-29 07:18:14 --> Config Class Initialized
INFO - 2020-07-29 07:18:14 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:18:14 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:18:14 --> Utf8 Class Initialized
INFO - 2020-07-29 07:18:14 --> URI Class Initialized
INFO - 2020-07-29 07:18:14 --> Router Class Initialized
INFO - 2020-07-29 07:18:14 --> Output Class Initialized
INFO - 2020-07-29 07:18:14 --> Security Class Initialized
DEBUG - 2020-07-29 07:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:18:14 --> Input Class Initialized
INFO - 2020-07-29 07:18:14 --> Language Class Initialized
INFO - 2020-07-29 07:18:14 --> Loader Class Initialized
INFO - 2020-07-29 07:18:14 --> Helper loaded: url_helper
INFO - 2020-07-29 07:18:14 --> Database Driver Class Initialized
INFO - 2020-07-29 07:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:18:14 --> Email Class Initialized
INFO - 2020-07-29 07:18:14 --> Controller Class Initialized
DEBUG - 2020-07-29 07:18:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:18:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:18:14 --> Model Class Initialized
INFO - 2020-07-29 07:18:14 --> Model Class Initialized
INFO - 2020-07-29 07:18:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 07:18:14 --> Final output sent to browser
DEBUG - 2020-07-29 07:18:14 --> Total execution time: 0.0278
INFO - 2020-07-29 07:19:12 --> Config Class Initialized
INFO - 2020-07-29 07:19:12 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:19:12 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:19:12 --> Utf8 Class Initialized
INFO - 2020-07-29 07:19:12 --> URI Class Initialized
INFO - 2020-07-29 07:19:12 --> Router Class Initialized
INFO - 2020-07-29 07:19:12 --> Output Class Initialized
INFO - 2020-07-29 07:19:12 --> Security Class Initialized
DEBUG - 2020-07-29 07:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:19:12 --> Input Class Initialized
INFO - 2020-07-29 07:19:12 --> Language Class Initialized
INFO - 2020-07-29 07:19:12 --> Loader Class Initialized
INFO - 2020-07-29 07:19:12 --> Helper loaded: url_helper
INFO - 2020-07-29 07:19:12 --> Database Driver Class Initialized
INFO - 2020-07-29 07:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:19:12 --> Email Class Initialized
INFO - 2020-07-29 07:19:12 --> Controller Class Initialized
DEBUG - 2020-07-29 07:19:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:19:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:19:12 --> Model Class Initialized
INFO - 2020-07-29 07:19:12 --> Model Class Initialized
INFO - 2020-07-29 07:19:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 07:19:12 --> Final output sent to browser
DEBUG - 2020-07-29 07:19:12 --> Total execution time: 0.0236
INFO - 2020-07-29 07:20:30 --> Config Class Initialized
INFO - 2020-07-29 07:20:30 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:20:30 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:20:30 --> Utf8 Class Initialized
INFO - 2020-07-29 07:20:30 --> URI Class Initialized
DEBUG - 2020-07-29 07:20:30 --> No URI present. Default controller set.
INFO - 2020-07-29 07:20:30 --> Router Class Initialized
INFO - 2020-07-29 07:20:30 --> Output Class Initialized
INFO - 2020-07-29 07:20:30 --> Security Class Initialized
DEBUG - 2020-07-29 07:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:20:30 --> Input Class Initialized
INFO - 2020-07-29 07:20:30 --> Language Class Initialized
INFO - 2020-07-29 07:20:30 --> Loader Class Initialized
INFO - 2020-07-29 07:20:30 --> Helper loaded: url_helper
INFO - 2020-07-29 07:20:30 --> Database Driver Class Initialized
INFO - 2020-07-29 07:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:20:30 --> Email Class Initialized
INFO - 2020-07-29 07:20:30 --> Controller Class Initialized
INFO - 2020-07-29 07:20:30 --> Model Class Initialized
INFO - 2020-07-29 07:20:30 --> Model Class Initialized
DEBUG - 2020-07-29 07:20:30 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:20:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 07:20:30 --> Final output sent to browser
DEBUG - 2020-07-29 07:20:30 --> Total execution time: 0.0223
INFO - 2020-07-29 07:20:33 --> Config Class Initialized
INFO - 2020-07-29 07:20:33 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:20:33 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:20:33 --> Utf8 Class Initialized
INFO - 2020-07-29 07:20:33 --> URI Class Initialized
INFO - 2020-07-29 07:20:33 --> Router Class Initialized
INFO - 2020-07-29 07:20:33 --> Output Class Initialized
INFO - 2020-07-29 07:20:33 --> Security Class Initialized
DEBUG - 2020-07-29 07:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:20:33 --> Input Class Initialized
INFO - 2020-07-29 07:20:33 --> Language Class Initialized
INFO - 2020-07-29 07:20:33 --> Loader Class Initialized
INFO - 2020-07-29 07:20:33 --> Helper loaded: url_helper
INFO - 2020-07-29 07:20:33 --> Database Driver Class Initialized
INFO - 2020-07-29 07:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:20:33 --> Email Class Initialized
INFO - 2020-07-29 07:20:33 --> Controller Class Initialized
INFO - 2020-07-29 07:20:33 --> Model Class Initialized
INFO - 2020-07-29 07:20:33 --> Model Class Initialized
DEBUG - 2020-07-29 07:20:33 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:20:33 --> Config Class Initialized
INFO - 2020-07-29 07:20:33 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:20:33 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:20:33 --> Utf8 Class Initialized
INFO - 2020-07-29 07:20:33 --> URI Class Initialized
INFO - 2020-07-29 07:20:33 --> Router Class Initialized
INFO - 2020-07-29 07:20:33 --> Output Class Initialized
INFO - 2020-07-29 07:20:33 --> Security Class Initialized
DEBUG - 2020-07-29 07:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:20:33 --> Input Class Initialized
INFO - 2020-07-29 07:20:33 --> Language Class Initialized
INFO - 2020-07-29 07:20:33 --> Loader Class Initialized
INFO - 2020-07-29 07:20:33 --> Helper loaded: url_helper
INFO - 2020-07-29 07:20:33 --> Database Driver Class Initialized
INFO - 2020-07-29 07:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:20:33 --> Email Class Initialized
INFO - 2020-07-29 07:20:33 --> Controller Class Initialized
DEBUG - 2020-07-29 07:20:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:20:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:20:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 07:20:33 --> Final output sent to browser
DEBUG - 2020-07-29 07:20:33 --> Total execution time: 0.0220
INFO - 2020-07-29 07:20:37 --> Config Class Initialized
INFO - 2020-07-29 07:20:37 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:20:37 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:20:37 --> Utf8 Class Initialized
INFO - 2020-07-29 07:20:37 --> URI Class Initialized
INFO - 2020-07-29 07:20:37 --> Router Class Initialized
INFO - 2020-07-29 07:20:37 --> Output Class Initialized
INFO - 2020-07-29 07:20:37 --> Security Class Initialized
DEBUG - 2020-07-29 07:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:20:37 --> Input Class Initialized
INFO - 2020-07-29 07:20:37 --> Language Class Initialized
INFO - 2020-07-29 07:20:37 --> Loader Class Initialized
INFO - 2020-07-29 07:20:37 --> Helper loaded: url_helper
INFO - 2020-07-29 07:20:37 --> Database Driver Class Initialized
INFO - 2020-07-29 07:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:20:37 --> Email Class Initialized
INFO - 2020-07-29 07:20:37 --> Controller Class Initialized
DEBUG - 2020-07-29 07:20:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:20:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:20:37 --> Model Class Initialized
INFO - 2020-07-29 07:20:37 --> Model Class Initialized
INFO - 2020-07-29 07:20:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 07:20:37 --> Final output sent to browser
DEBUG - 2020-07-29 07:20:37 --> Total execution time: 0.0267
INFO - 2020-07-29 07:20:41 --> Config Class Initialized
INFO - 2020-07-29 07:20:41 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:20:41 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:20:41 --> Utf8 Class Initialized
INFO - 2020-07-29 07:20:41 --> URI Class Initialized
INFO - 2020-07-29 07:20:41 --> Router Class Initialized
INFO - 2020-07-29 07:20:41 --> Output Class Initialized
INFO - 2020-07-29 07:20:41 --> Security Class Initialized
DEBUG - 2020-07-29 07:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:20:41 --> Input Class Initialized
INFO - 2020-07-29 07:20:41 --> Language Class Initialized
INFO - 2020-07-29 07:20:41 --> Loader Class Initialized
INFO - 2020-07-29 07:20:41 --> Helper loaded: url_helper
INFO - 2020-07-29 07:20:41 --> Database Driver Class Initialized
INFO - 2020-07-29 07:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:20:41 --> Email Class Initialized
INFO - 2020-07-29 07:20:41 --> Controller Class Initialized
DEBUG - 2020-07-29 07:20:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:20:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:20:41 --> Model Class Initialized
INFO - 2020-07-29 07:20:41 --> Model Class Initialized
INFO - 2020-07-29 07:20:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-07-29 07:20:41 --> Final output sent to browser
DEBUG - 2020-07-29 07:20:41 --> Total execution time: 0.0211
INFO - 2020-07-29 07:21:24 --> Config Class Initialized
INFO - 2020-07-29 07:21:24 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:21:24 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:21:24 --> Utf8 Class Initialized
INFO - 2020-07-29 07:21:24 --> URI Class Initialized
INFO - 2020-07-29 07:21:24 --> Router Class Initialized
INFO - 2020-07-29 07:21:24 --> Output Class Initialized
INFO - 2020-07-29 07:21:24 --> Security Class Initialized
DEBUG - 2020-07-29 07:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:21:24 --> Input Class Initialized
INFO - 2020-07-29 07:21:24 --> Language Class Initialized
INFO - 2020-07-29 07:21:24 --> Loader Class Initialized
INFO - 2020-07-29 07:21:24 --> Helper loaded: url_helper
INFO - 2020-07-29 07:21:24 --> Database Driver Class Initialized
INFO - 2020-07-29 07:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:21:24 --> Email Class Initialized
INFO - 2020-07-29 07:21:24 --> Controller Class Initialized
DEBUG - 2020-07-29 07:21:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:21:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:21:24 --> Model Class Initialized
INFO - 2020-07-29 07:21:24 --> Model Class Initialized
INFO - 2020-07-29 07:21:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-07-29 07:21:24 --> Final output sent to browser
DEBUG - 2020-07-29 07:21:24 --> Total execution time: 0.0233
INFO - 2020-07-29 07:21:27 --> Config Class Initialized
INFO - 2020-07-29 07:21:27 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:21:27 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:21:27 --> Utf8 Class Initialized
INFO - 2020-07-29 07:21:27 --> URI Class Initialized
DEBUG - 2020-07-29 07:21:27 --> No URI present. Default controller set.
INFO - 2020-07-29 07:21:27 --> Router Class Initialized
INFO - 2020-07-29 07:21:27 --> Output Class Initialized
INFO - 2020-07-29 07:21:27 --> Security Class Initialized
DEBUG - 2020-07-29 07:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:21:27 --> Input Class Initialized
INFO - 2020-07-29 07:21:27 --> Language Class Initialized
INFO - 2020-07-29 07:21:27 --> Loader Class Initialized
INFO - 2020-07-29 07:21:27 --> Helper loaded: url_helper
INFO - 2020-07-29 07:21:27 --> Database Driver Class Initialized
INFO - 2020-07-29 07:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:21:27 --> Email Class Initialized
INFO - 2020-07-29 07:21:27 --> Controller Class Initialized
INFO - 2020-07-29 07:21:27 --> Model Class Initialized
INFO - 2020-07-29 07:21:27 --> Model Class Initialized
DEBUG - 2020-07-29 07:21:27 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:21:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 07:21:27 --> Final output sent to browser
DEBUG - 2020-07-29 07:21:27 --> Total execution time: 0.0218
INFO - 2020-07-29 07:22:19 --> Config Class Initialized
INFO - 2020-07-29 07:22:19 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:22:19 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:22:19 --> Utf8 Class Initialized
INFO - 2020-07-29 07:22:19 --> URI Class Initialized
INFO - 2020-07-29 07:22:19 --> Router Class Initialized
INFO - 2020-07-29 07:22:19 --> Output Class Initialized
INFO - 2020-07-29 07:22:19 --> Security Class Initialized
DEBUG - 2020-07-29 07:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:22:19 --> Input Class Initialized
INFO - 2020-07-29 07:22:19 --> Language Class Initialized
INFO - 2020-07-29 07:22:19 --> Loader Class Initialized
INFO - 2020-07-29 07:22:19 --> Helper loaded: url_helper
INFO - 2020-07-29 07:22:19 --> Database Driver Class Initialized
INFO - 2020-07-29 07:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:22:19 --> Email Class Initialized
INFO - 2020-07-29 07:22:19 --> Controller Class Initialized
INFO - 2020-07-29 07:22:19 --> Model Class Initialized
INFO - 2020-07-29 07:22:19 --> Model Class Initialized
DEBUG - 2020-07-29 07:22:19 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:22:19 --> Config Class Initialized
INFO - 2020-07-29 07:22:19 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:22:19 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:22:19 --> Utf8 Class Initialized
INFO - 2020-07-29 07:22:19 --> URI Class Initialized
INFO - 2020-07-29 07:22:19 --> Router Class Initialized
INFO - 2020-07-29 07:22:19 --> Output Class Initialized
INFO - 2020-07-29 07:22:19 --> Security Class Initialized
DEBUG - 2020-07-29 07:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:22:19 --> Input Class Initialized
INFO - 2020-07-29 07:22:19 --> Language Class Initialized
INFO - 2020-07-29 07:22:19 --> Loader Class Initialized
INFO - 2020-07-29 07:22:19 --> Helper loaded: url_helper
INFO - 2020-07-29 07:22:19 --> Database Driver Class Initialized
INFO - 2020-07-29 07:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:22:19 --> Email Class Initialized
INFO - 2020-07-29 07:22:19 --> Controller Class Initialized
DEBUG - 2020-07-29 07:22:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:22:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:22:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 07:22:19 --> Final output sent to browser
DEBUG - 2020-07-29 07:22:19 --> Total execution time: 0.0205
INFO - 2020-07-29 07:22:23 --> Config Class Initialized
INFO - 2020-07-29 07:22:23 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:22:23 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:22:23 --> Utf8 Class Initialized
INFO - 2020-07-29 07:22:23 --> URI Class Initialized
INFO - 2020-07-29 07:22:23 --> Router Class Initialized
INFO - 2020-07-29 07:22:23 --> Output Class Initialized
INFO - 2020-07-29 07:22:23 --> Security Class Initialized
DEBUG - 2020-07-29 07:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:22:23 --> Input Class Initialized
INFO - 2020-07-29 07:22:23 --> Language Class Initialized
INFO - 2020-07-29 07:22:23 --> Loader Class Initialized
INFO - 2020-07-29 07:22:23 --> Helper loaded: url_helper
INFO - 2020-07-29 07:22:23 --> Database Driver Class Initialized
INFO - 2020-07-29 07:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:22:23 --> Email Class Initialized
INFO - 2020-07-29 07:22:23 --> Controller Class Initialized
DEBUG - 2020-07-29 07:22:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:22:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:22:23 --> Model Class Initialized
INFO - 2020-07-29 07:22:23 --> Model Class Initialized
INFO - 2020-07-29 07:22:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 07:22:23 --> Final output sent to browser
DEBUG - 2020-07-29 07:22:23 --> Total execution time: 0.0219
INFO - 2020-07-29 07:22:29 --> Config Class Initialized
INFO - 2020-07-29 07:22:29 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:22:29 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:22:29 --> Utf8 Class Initialized
INFO - 2020-07-29 07:22:29 --> URI Class Initialized
INFO - 2020-07-29 07:22:29 --> Router Class Initialized
INFO - 2020-07-29 07:22:29 --> Output Class Initialized
INFO - 2020-07-29 07:22:29 --> Security Class Initialized
DEBUG - 2020-07-29 07:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:22:29 --> Input Class Initialized
INFO - 2020-07-29 07:22:29 --> Language Class Initialized
INFO - 2020-07-29 07:22:29 --> Loader Class Initialized
INFO - 2020-07-29 07:22:29 --> Helper loaded: url_helper
INFO - 2020-07-29 07:22:29 --> Database Driver Class Initialized
INFO - 2020-07-29 07:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:22:29 --> Email Class Initialized
INFO - 2020-07-29 07:22:29 --> Controller Class Initialized
DEBUG - 2020-07-29 07:22:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:22:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:22:29 --> Model Class Initialized
INFO - 2020-07-29 07:22:29 --> Model Class Initialized
INFO - 2020-07-29 07:22:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-07-29 07:22:29 --> Final output sent to browser
DEBUG - 2020-07-29 07:22:29 --> Total execution time: 0.0232
INFO - 2020-07-29 07:23:18 --> Config Class Initialized
INFO - 2020-07-29 07:23:18 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:23:18 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:23:18 --> Utf8 Class Initialized
INFO - 2020-07-29 07:23:18 --> URI Class Initialized
INFO - 2020-07-29 07:23:18 --> Router Class Initialized
INFO - 2020-07-29 07:23:18 --> Output Class Initialized
INFO - 2020-07-29 07:23:18 --> Security Class Initialized
DEBUG - 2020-07-29 07:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:23:18 --> Input Class Initialized
INFO - 2020-07-29 07:23:18 --> Language Class Initialized
INFO - 2020-07-29 07:23:18 --> Loader Class Initialized
INFO - 2020-07-29 07:23:18 --> Helper loaded: url_helper
INFO - 2020-07-29 07:23:18 --> Database Driver Class Initialized
INFO - 2020-07-29 07:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:23:18 --> Email Class Initialized
INFO - 2020-07-29 07:23:18 --> Controller Class Initialized
DEBUG - 2020-07-29 07:23:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:23:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:23:18 --> Model Class Initialized
INFO - 2020-07-29 07:23:18 --> Model Class Initialized
INFO - 2020-07-29 07:23:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-07-29 07:23:18 --> Final output sent to browser
DEBUG - 2020-07-29 07:23:18 --> Total execution time: 0.0235
INFO - 2020-07-29 07:23:20 --> Config Class Initialized
INFO - 2020-07-29 07:23:20 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:23:20 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:23:20 --> Utf8 Class Initialized
INFO - 2020-07-29 07:23:20 --> URI Class Initialized
INFO - 2020-07-29 07:23:20 --> Router Class Initialized
INFO - 2020-07-29 07:23:20 --> Output Class Initialized
INFO - 2020-07-29 07:23:20 --> Security Class Initialized
DEBUG - 2020-07-29 07:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:23:20 --> Input Class Initialized
INFO - 2020-07-29 07:23:20 --> Language Class Initialized
INFO - 2020-07-29 07:23:20 --> Loader Class Initialized
INFO - 2020-07-29 07:23:20 --> Helper loaded: url_helper
INFO - 2020-07-29 07:23:20 --> Database Driver Class Initialized
INFO - 2020-07-29 07:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:23:20 --> Email Class Initialized
INFO - 2020-07-29 07:23:20 --> Controller Class Initialized
DEBUG - 2020-07-29 07:23:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:23:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:23:20 --> Model Class Initialized
INFO - 2020-07-29 07:23:20 --> Model Class Initialized
INFO - 2020-07-29 07:23:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 07:23:20 --> Final output sent to browser
DEBUG - 2020-07-29 07:23:20 --> Total execution time: 0.0245
INFO - 2020-07-29 07:23:36 --> Config Class Initialized
INFO - 2020-07-29 07:23:36 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:23:36 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:23:36 --> Utf8 Class Initialized
INFO - 2020-07-29 07:23:36 --> URI Class Initialized
INFO - 2020-07-29 07:23:36 --> Router Class Initialized
INFO - 2020-07-29 07:23:36 --> Output Class Initialized
INFO - 2020-07-29 07:23:36 --> Security Class Initialized
DEBUG - 2020-07-29 07:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:23:36 --> Input Class Initialized
INFO - 2020-07-29 07:23:36 --> Language Class Initialized
INFO - 2020-07-29 07:23:36 --> Loader Class Initialized
INFO - 2020-07-29 07:23:36 --> Helper loaded: url_helper
INFO - 2020-07-29 07:23:36 --> Database Driver Class Initialized
INFO - 2020-07-29 07:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:23:36 --> Email Class Initialized
INFO - 2020-07-29 07:23:36 --> Controller Class Initialized
DEBUG - 2020-07-29 07:23:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:23:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:23:36 --> Model Class Initialized
INFO - 2020-07-29 07:23:36 --> Model Class Initialized
INFO - 2020-07-29 07:23:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-07-29 07:23:36 --> Final output sent to browser
DEBUG - 2020-07-29 07:23:36 --> Total execution time: 0.0241
INFO - 2020-07-29 07:23:38 --> Config Class Initialized
INFO - 2020-07-29 07:23:38 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:23:38 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:23:38 --> Utf8 Class Initialized
INFO - 2020-07-29 07:23:38 --> URI Class Initialized
INFO - 2020-07-29 07:23:38 --> Router Class Initialized
INFO - 2020-07-29 07:23:38 --> Output Class Initialized
INFO - 2020-07-29 07:23:38 --> Security Class Initialized
DEBUG - 2020-07-29 07:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:23:38 --> Input Class Initialized
INFO - 2020-07-29 07:23:38 --> Language Class Initialized
INFO - 2020-07-29 07:23:38 --> Loader Class Initialized
INFO - 2020-07-29 07:23:38 --> Helper loaded: url_helper
INFO - 2020-07-29 07:23:38 --> Database Driver Class Initialized
INFO - 2020-07-29 07:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:23:38 --> Email Class Initialized
INFO - 2020-07-29 07:23:38 --> Controller Class Initialized
DEBUG - 2020-07-29 07:23:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:23:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:23:38 --> Model Class Initialized
INFO - 2020-07-29 07:23:38 --> Model Class Initialized
INFO - 2020-07-29 07:23:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 07:23:38 --> Final output sent to browser
DEBUG - 2020-07-29 07:23:38 --> Total execution time: 0.0252
INFO - 2020-07-29 07:23:40 --> Config Class Initialized
INFO - 2020-07-29 07:23:40 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:23:40 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:23:40 --> Utf8 Class Initialized
INFO - 2020-07-29 07:23:40 --> URI Class Initialized
INFO - 2020-07-29 07:23:40 --> Router Class Initialized
INFO - 2020-07-29 07:23:40 --> Output Class Initialized
INFO - 2020-07-29 07:23:40 --> Security Class Initialized
DEBUG - 2020-07-29 07:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:23:40 --> Input Class Initialized
INFO - 2020-07-29 07:23:40 --> Language Class Initialized
INFO - 2020-07-29 07:23:40 --> Loader Class Initialized
INFO - 2020-07-29 07:23:40 --> Helper loaded: url_helper
INFO - 2020-07-29 07:23:40 --> Database Driver Class Initialized
INFO - 2020-07-29 07:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:23:40 --> Email Class Initialized
INFO - 2020-07-29 07:23:40 --> Controller Class Initialized
DEBUG - 2020-07-29 07:23:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:23:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:23:40 --> Model Class Initialized
INFO - 2020-07-29 07:23:40 --> Model Class Initialized
INFO - 2020-07-29 07:23:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 07:23:40 --> Final output sent to browser
DEBUG - 2020-07-29 07:23:40 --> Total execution time: 0.0239
INFO - 2020-07-29 07:23:44 --> Config Class Initialized
INFO - 2020-07-29 07:23:44 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:23:44 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:23:44 --> Utf8 Class Initialized
INFO - 2020-07-29 07:23:44 --> URI Class Initialized
INFO - 2020-07-29 07:23:44 --> Router Class Initialized
INFO - 2020-07-29 07:23:44 --> Output Class Initialized
INFO - 2020-07-29 07:23:44 --> Security Class Initialized
DEBUG - 2020-07-29 07:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:23:44 --> Input Class Initialized
INFO - 2020-07-29 07:23:44 --> Language Class Initialized
INFO - 2020-07-29 07:23:44 --> Loader Class Initialized
INFO - 2020-07-29 07:23:44 --> Helper loaded: url_helper
INFO - 2020-07-29 07:23:44 --> Database Driver Class Initialized
INFO - 2020-07-29 07:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:23:44 --> Email Class Initialized
INFO - 2020-07-29 07:23:44 --> Controller Class Initialized
DEBUG - 2020-07-29 07:23:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:23:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:23:44 --> Model Class Initialized
INFO - 2020-07-29 07:23:44 --> Model Class Initialized
INFO - 2020-07-29 07:23:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 07:23:44 --> Final output sent to browser
DEBUG - 2020-07-29 07:23:44 --> Total execution time: 0.0265
INFO - 2020-07-29 07:23:48 --> Config Class Initialized
INFO - 2020-07-29 07:23:48 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:23:48 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:23:48 --> Utf8 Class Initialized
INFO - 2020-07-29 07:23:48 --> URI Class Initialized
INFO - 2020-07-29 07:23:48 --> Router Class Initialized
INFO - 2020-07-29 07:23:48 --> Output Class Initialized
INFO - 2020-07-29 07:23:48 --> Security Class Initialized
DEBUG - 2020-07-29 07:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:23:48 --> Input Class Initialized
INFO - 2020-07-29 07:23:48 --> Language Class Initialized
INFO - 2020-07-29 07:23:48 --> Loader Class Initialized
INFO - 2020-07-29 07:23:48 --> Helper loaded: url_helper
INFO - 2020-07-29 07:23:48 --> Database Driver Class Initialized
INFO - 2020-07-29 07:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:23:48 --> Email Class Initialized
INFO - 2020-07-29 07:23:48 --> Controller Class Initialized
DEBUG - 2020-07-29 07:23:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:23:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:23:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-29 07:23:48 --> Final output sent to browser
DEBUG - 2020-07-29 07:23:48 --> Total execution time: 0.0228
INFO - 2020-07-29 07:23:50 --> Config Class Initialized
INFO - 2020-07-29 07:23:50 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:23:50 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:23:50 --> Utf8 Class Initialized
INFO - 2020-07-29 07:23:50 --> URI Class Initialized
INFO - 2020-07-29 07:23:50 --> Router Class Initialized
INFO - 2020-07-29 07:23:50 --> Output Class Initialized
INFO - 2020-07-29 07:23:50 --> Security Class Initialized
DEBUG - 2020-07-29 07:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:23:50 --> Input Class Initialized
INFO - 2020-07-29 07:23:50 --> Language Class Initialized
INFO - 2020-07-29 07:23:50 --> Loader Class Initialized
INFO - 2020-07-29 07:23:50 --> Helper loaded: url_helper
INFO - 2020-07-29 07:23:50 --> Database Driver Class Initialized
INFO - 2020-07-29 07:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:23:50 --> Email Class Initialized
INFO - 2020-07-29 07:23:50 --> Controller Class Initialized
DEBUG - 2020-07-29 07:23:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:23:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:23:50 --> Model Class Initialized
INFO - 2020-07-29 07:23:50 --> Model Class Initialized
INFO - 2020-07-29 07:23:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 07:23:50 --> Final output sent to browser
DEBUG - 2020-07-29 07:23:50 --> Total execution time: 0.0253
INFO - 2020-07-29 07:23:53 --> Config Class Initialized
INFO - 2020-07-29 07:23:53 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:23:53 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:23:53 --> Utf8 Class Initialized
INFO - 2020-07-29 07:23:53 --> URI Class Initialized
INFO - 2020-07-29 07:23:53 --> Router Class Initialized
INFO - 2020-07-29 07:23:53 --> Output Class Initialized
INFO - 2020-07-29 07:23:53 --> Security Class Initialized
DEBUG - 2020-07-29 07:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:23:53 --> Input Class Initialized
INFO - 2020-07-29 07:23:53 --> Language Class Initialized
INFO - 2020-07-29 07:23:53 --> Loader Class Initialized
INFO - 2020-07-29 07:23:53 --> Helper loaded: url_helper
INFO - 2020-07-29 07:23:53 --> Database Driver Class Initialized
INFO - 2020-07-29 07:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:23:53 --> Email Class Initialized
INFO - 2020-07-29 07:23:53 --> Controller Class Initialized
DEBUG - 2020-07-29 07:23:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:23:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:23:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-29 07:23:53 --> Final output sent to browser
DEBUG - 2020-07-29 07:23:53 --> Total execution time: 0.0207
INFO - 2020-07-29 07:23:55 --> Config Class Initialized
INFO - 2020-07-29 07:23:55 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:23:55 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:23:55 --> Utf8 Class Initialized
INFO - 2020-07-29 07:23:55 --> URI Class Initialized
INFO - 2020-07-29 07:23:55 --> Router Class Initialized
INFO - 2020-07-29 07:23:55 --> Output Class Initialized
INFO - 2020-07-29 07:23:55 --> Security Class Initialized
DEBUG - 2020-07-29 07:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:23:55 --> Input Class Initialized
INFO - 2020-07-29 07:23:55 --> Language Class Initialized
INFO - 2020-07-29 07:23:55 --> Loader Class Initialized
INFO - 2020-07-29 07:23:55 --> Helper loaded: url_helper
INFO - 2020-07-29 07:23:55 --> Database Driver Class Initialized
INFO - 2020-07-29 07:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:23:55 --> Email Class Initialized
INFO - 2020-07-29 07:23:55 --> Controller Class Initialized
DEBUG - 2020-07-29 07:23:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:23:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:23:55 --> Model Class Initialized
INFO - 2020-07-29 07:23:55 --> Model Class Initialized
ERROR - 2020-07-29 07:23:55 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
INFO - 2020-07-29 07:23:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 07:23:55 --> Final output sent to browser
DEBUG - 2020-07-29 07:23:55 --> Total execution time: 0.0287
INFO - 2020-07-29 07:24:36 --> Config Class Initialized
INFO - 2020-07-29 07:24:36 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:24:36 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:24:36 --> Utf8 Class Initialized
INFO - 2020-07-29 07:24:36 --> URI Class Initialized
INFO - 2020-07-29 07:24:36 --> Router Class Initialized
INFO - 2020-07-29 07:24:36 --> Output Class Initialized
INFO - 2020-07-29 07:24:36 --> Security Class Initialized
DEBUG - 2020-07-29 07:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:24:36 --> Input Class Initialized
INFO - 2020-07-29 07:24:36 --> Language Class Initialized
INFO - 2020-07-29 07:24:36 --> Loader Class Initialized
INFO - 2020-07-29 07:24:36 --> Helper loaded: url_helper
INFO - 2020-07-29 07:24:36 --> Database Driver Class Initialized
INFO - 2020-07-29 07:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:24:36 --> Email Class Initialized
INFO - 2020-07-29 07:24:36 --> Controller Class Initialized
DEBUG - 2020-07-29 07:24:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:24:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:24:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-29 07:24:36 --> Final output sent to browser
DEBUG - 2020-07-29 07:24:36 --> Total execution time: 0.0229
INFO - 2020-07-29 07:24:46 --> Config Class Initialized
INFO - 2020-07-29 07:24:46 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:24:46 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:24:46 --> Utf8 Class Initialized
INFO - 2020-07-29 07:24:46 --> URI Class Initialized
INFO - 2020-07-29 07:24:46 --> Router Class Initialized
INFO - 2020-07-29 07:24:46 --> Output Class Initialized
INFO - 2020-07-29 07:24:46 --> Security Class Initialized
DEBUG - 2020-07-29 07:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:24:46 --> Input Class Initialized
INFO - 2020-07-29 07:24:46 --> Language Class Initialized
INFO - 2020-07-29 07:24:46 --> Loader Class Initialized
INFO - 2020-07-29 07:24:46 --> Helper loaded: url_helper
INFO - 2020-07-29 07:24:46 --> Database Driver Class Initialized
INFO - 2020-07-29 07:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:24:46 --> Email Class Initialized
INFO - 2020-07-29 07:24:46 --> Controller Class Initialized
DEBUG - 2020-07-29 07:24:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:24:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:24:46 --> Model Class Initialized
INFO - 2020-07-29 07:24:46 --> Model Class Initialized
INFO - 2020-07-29 07:24:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 07:24:46 --> Final output sent to browser
DEBUG - 2020-07-29 07:24:46 --> Total execution time: 0.0305
INFO - 2020-07-29 07:24:59 --> Config Class Initialized
INFO - 2020-07-29 07:24:59 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:24:59 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:24:59 --> Utf8 Class Initialized
INFO - 2020-07-29 07:24:59 --> URI Class Initialized
DEBUG - 2020-07-29 07:24:59 --> No URI present. Default controller set.
INFO - 2020-07-29 07:24:59 --> Router Class Initialized
INFO - 2020-07-29 07:24:59 --> Output Class Initialized
INFO - 2020-07-29 07:24:59 --> Security Class Initialized
DEBUG - 2020-07-29 07:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:24:59 --> Input Class Initialized
INFO - 2020-07-29 07:24:59 --> Language Class Initialized
INFO - 2020-07-29 07:24:59 --> Loader Class Initialized
INFO - 2020-07-29 07:24:59 --> Helper loaded: url_helper
INFO - 2020-07-29 07:24:59 --> Database Driver Class Initialized
INFO - 2020-07-29 07:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:24:59 --> Email Class Initialized
INFO - 2020-07-29 07:24:59 --> Controller Class Initialized
INFO - 2020-07-29 07:24:59 --> Model Class Initialized
INFO - 2020-07-29 07:24:59 --> Model Class Initialized
DEBUG - 2020-07-29 07:24:59 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:24:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 07:24:59 --> Final output sent to browser
DEBUG - 2020-07-29 07:24:59 --> Total execution time: 0.0234
INFO - 2020-07-29 07:25:05 --> Config Class Initialized
INFO - 2020-07-29 07:25:05 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:25:05 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:25:05 --> Utf8 Class Initialized
INFO - 2020-07-29 07:25:05 --> URI Class Initialized
INFO - 2020-07-29 07:25:05 --> Router Class Initialized
INFO - 2020-07-29 07:25:05 --> Output Class Initialized
INFO - 2020-07-29 07:25:05 --> Security Class Initialized
DEBUG - 2020-07-29 07:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:25:05 --> Input Class Initialized
INFO - 2020-07-29 07:25:05 --> Language Class Initialized
INFO - 2020-07-29 07:25:05 --> Loader Class Initialized
INFO - 2020-07-29 07:25:05 --> Helper loaded: url_helper
INFO - 2020-07-29 07:25:05 --> Database Driver Class Initialized
INFO - 2020-07-29 07:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:25:05 --> Email Class Initialized
INFO - 2020-07-29 07:25:05 --> Controller Class Initialized
INFO - 2020-07-29 07:25:05 --> Model Class Initialized
INFO - 2020-07-29 07:25:05 --> Model Class Initialized
DEBUG - 2020-07-29 07:25:05 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:25:05 --> Config Class Initialized
INFO - 2020-07-29 07:25:05 --> Hooks Class Initialized
DEBUG - 2020-07-29 07:25:05 --> UTF-8 Support Enabled
INFO - 2020-07-29 07:25:05 --> Utf8 Class Initialized
INFO - 2020-07-29 07:25:05 --> URI Class Initialized
INFO - 2020-07-29 07:25:05 --> Router Class Initialized
INFO - 2020-07-29 07:25:05 --> Output Class Initialized
INFO - 2020-07-29 07:25:05 --> Security Class Initialized
DEBUG - 2020-07-29 07:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 07:25:05 --> Input Class Initialized
INFO - 2020-07-29 07:25:05 --> Language Class Initialized
INFO - 2020-07-29 07:25:05 --> Loader Class Initialized
INFO - 2020-07-29 07:25:05 --> Helper loaded: url_helper
INFO - 2020-07-29 07:25:05 --> Database Driver Class Initialized
INFO - 2020-07-29 07:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 07:25:05 --> Email Class Initialized
INFO - 2020-07-29 07:25:05 --> Controller Class Initialized
DEBUG - 2020-07-29 07:25:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 07:25:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 07:25:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 07:25:05 --> Final output sent to browser
DEBUG - 2020-07-29 07:25:05 --> Total execution time: 0.0217
INFO - 2020-07-29 13:38:51 --> Config Class Initialized
INFO - 2020-07-29 13:38:51 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:38:51 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:38:51 --> Utf8 Class Initialized
INFO - 2020-07-29 13:38:51 --> URI Class Initialized
DEBUG - 2020-07-29 13:38:51 --> No URI present. Default controller set.
INFO - 2020-07-29 13:38:51 --> Router Class Initialized
INFO - 2020-07-29 13:38:51 --> Output Class Initialized
INFO - 2020-07-29 13:38:51 --> Security Class Initialized
DEBUG - 2020-07-29 13:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:38:51 --> Input Class Initialized
INFO - 2020-07-29 13:38:51 --> Language Class Initialized
INFO - 2020-07-29 13:38:51 --> Loader Class Initialized
INFO - 2020-07-29 13:38:51 --> Helper loaded: url_helper
INFO - 2020-07-29 13:38:52 --> Database Driver Class Initialized
INFO - 2020-07-29 13:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:38:52 --> Email Class Initialized
INFO - 2020-07-29 13:38:52 --> Controller Class Initialized
INFO - 2020-07-29 13:38:52 --> Model Class Initialized
INFO - 2020-07-29 13:38:52 --> Model Class Initialized
DEBUG - 2020-07-29 13:38:52 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:38:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 13:38:52 --> Final output sent to browser
DEBUG - 2020-07-29 13:38:52 --> Total execution time: 0.0947
INFO - 2020-07-29 13:38:56 --> Config Class Initialized
INFO - 2020-07-29 13:38:56 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:38:56 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:38:56 --> Utf8 Class Initialized
INFO - 2020-07-29 13:38:56 --> URI Class Initialized
INFO - 2020-07-29 13:38:56 --> Router Class Initialized
INFO - 2020-07-29 13:38:56 --> Output Class Initialized
INFO - 2020-07-29 13:38:56 --> Security Class Initialized
DEBUG - 2020-07-29 13:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:38:56 --> Input Class Initialized
INFO - 2020-07-29 13:38:56 --> Language Class Initialized
INFO - 2020-07-29 13:38:56 --> Loader Class Initialized
INFO - 2020-07-29 13:38:56 --> Helper loaded: url_helper
INFO - 2020-07-29 13:38:56 --> Database Driver Class Initialized
INFO - 2020-07-29 13:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:38:57 --> Email Class Initialized
INFO - 2020-07-29 13:38:57 --> Controller Class Initialized
INFO - 2020-07-29 13:38:57 --> Model Class Initialized
INFO - 2020-07-29 13:38:57 --> Model Class Initialized
DEBUG - 2020-07-29 13:38:57 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:38:57 --> Config Class Initialized
INFO - 2020-07-29 13:38:57 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:38:57 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:38:57 --> Utf8 Class Initialized
INFO - 2020-07-29 13:38:57 --> URI Class Initialized
INFO - 2020-07-29 13:38:57 --> Router Class Initialized
INFO - 2020-07-29 13:38:57 --> Output Class Initialized
INFO - 2020-07-29 13:38:57 --> Security Class Initialized
DEBUG - 2020-07-29 13:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:38:57 --> Input Class Initialized
INFO - 2020-07-29 13:38:57 --> Language Class Initialized
INFO - 2020-07-29 13:38:57 --> Loader Class Initialized
INFO - 2020-07-29 13:38:57 --> Helper loaded: url_helper
INFO - 2020-07-29 13:38:57 --> Database Driver Class Initialized
INFO - 2020-07-29 13:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:38:57 --> Email Class Initialized
INFO - 2020-07-29 13:38:57 --> Controller Class Initialized
DEBUG - 2020-07-29 13:38:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:38:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:38:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 13:38:57 --> Final output sent to browser
DEBUG - 2020-07-29 13:38:57 --> Total execution time: 0.0467
INFO - 2020-07-29 13:39:02 --> Config Class Initialized
INFO - 2020-07-29 13:39:02 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:39:02 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:39:02 --> Utf8 Class Initialized
INFO - 2020-07-29 13:39:02 --> URI Class Initialized
INFO - 2020-07-29 13:39:02 --> Router Class Initialized
INFO - 2020-07-29 13:39:02 --> Output Class Initialized
INFO - 2020-07-29 13:39:02 --> Security Class Initialized
DEBUG - 2020-07-29 13:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:39:02 --> Input Class Initialized
INFO - 2020-07-29 13:39:02 --> Language Class Initialized
INFO - 2020-07-29 13:39:02 --> Loader Class Initialized
INFO - 2020-07-29 13:39:02 --> Helper loaded: url_helper
INFO - 2020-07-29 13:39:02 --> Database Driver Class Initialized
INFO - 2020-07-29 13:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:39:02 --> Email Class Initialized
INFO - 2020-07-29 13:39:02 --> Controller Class Initialized
DEBUG - 2020-07-29 13:39:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:39:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:39:02 --> Model Class Initialized
INFO - 2020-07-29 13:39:02 --> Model Class Initialized
INFO - 2020-07-29 13:39:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 13:39:02 --> Final output sent to browser
DEBUG - 2020-07-29 13:39:02 --> Total execution time: 0.0539
INFO - 2020-07-29 13:39:22 --> Config Class Initialized
INFO - 2020-07-29 13:39:22 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:39:22 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:39:22 --> Utf8 Class Initialized
INFO - 2020-07-29 13:39:22 --> URI Class Initialized
INFO - 2020-07-29 13:39:22 --> Router Class Initialized
INFO - 2020-07-29 13:39:22 --> Output Class Initialized
INFO - 2020-07-29 13:39:22 --> Security Class Initialized
DEBUG - 2020-07-29 13:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:39:22 --> Input Class Initialized
INFO - 2020-07-29 13:39:22 --> Language Class Initialized
INFO - 2020-07-29 13:39:22 --> Loader Class Initialized
INFO - 2020-07-29 13:39:22 --> Helper loaded: url_helper
INFO - 2020-07-29 13:39:22 --> Database Driver Class Initialized
INFO - 2020-07-29 13:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:39:22 --> Email Class Initialized
INFO - 2020-07-29 13:39:22 --> Controller Class Initialized
DEBUG - 2020-07-29 13:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:39:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:39:22 --> Model Class Initialized
INFO - 2020-07-29 13:39:22 --> Model Class Initialized
INFO - 2020-07-29 13:39:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-07-29 13:39:22 --> Final output sent to browser
DEBUG - 2020-07-29 13:39:22 --> Total execution time: 0.0343
INFO - 2020-07-29 13:39:29 --> Config Class Initialized
INFO - 2020-07-29 13:39:29 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:39:29 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:39:29 --> Utf8 Class Initialized
INFO - 2020-07-29 13:39:29 --> URI Class Initialized
INFO - 2020-07-29 13:39:29 --> Router Class Initialized
INFO - 2020-07-29 13:39:29 --> Output Class Initialized
INFO - 2020-07-29 13:39:29 --> Security Class Initialized
DEBUG - 2020-07-29 13:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:39:29 --> Input Class Initialized
INFO - 2020-07-29 13:39:29 --> Language Class Initialized
INFO - 2020-07-29 13:39:29 --> Loader Class Initialized
INFO - 2020-07-29 13:39:29 --> Helper loaded: url_helper
INFO - 2020-07-29 13:39:29 --> Database Driver Class Initialized
INFO - 2020-07-29 13:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:39:29 --> Email Class Initialized
INFO - 2020-07-29 13:39:29 --> Controller Class Initialized
DEBUG - 2020-07-29 13:39:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:39:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:39:29 --> Model Class Initialized
INFO - 2020-07-29 13:39:29 --> Model Class Initialized
INFO - 2020-07-29 13:39:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 13:39:29 --> Final output sent to browser
DEBUG - 2020-07-29 13:39:29 --> Total execution time: 0.0265
INFO - 2020-07-29 13:39:32 --> Config Class Initialized
INFO - 2020-07-29 13:39:32 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:39:32 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:39:32 --> Utf8 Class Initialized
INFO - 2020-07-29 13:39:32 --> URI Class Initialized
INFO - 2020-07-29 13:39:32 --> Router Class Initialized
INFO - 2020-07-29 13:39:32 --> Output Class Initialized
INFO - 2020-07-29 13:39:32 --> Security Class Initialized
DEBUG - 2020-07-29 13:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:39:32 --> Input Class Initialized
INFO - 2020-07-29 13:39:32 --> Language Class Initialized
INFO - 2020-07-29 13:39:32 --> Loader Class Initialized
INFO - 2020-07-29 13:39:32 --> Helper loaded: url_helper
INFO - 2020-07-29 13:39:32 --> Database Driver Class Initialized
INFO - 2020-07-29 13:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:39:32 --> Email Class Initialized
INFO - 2020-07-29 13:39:32 --> Controller Class Initialized
DEBUG - 2020-07-29 13:39:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:39:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:39:32 --> Model Class Initialized
INFO - 2020-07-29 13:39:32 --> Model Class Initialized
INFO - 2020-07-29 13:39:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 13:39:32 --> Final output sent to browser
DEBUG - 2020-07-29 13:39:32 --> Total execution time: 0.0319
INFO - 2020-07-29 13:39:35 --> Config Class Initialized
INFO - 2020-07-29 13:39:35 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:39:35 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:39:35 --> Utf8 Class Initialized
INFO - 2020-07-29 13:39:35 --> URI Class Initialized
INFO - 2020-07-29 13:39:35 --> Router Class Initialized
INFO - 2020-07-29 13:39:35 --> Output Class Initialized
INFO - 2020-07-29 13:39:35 --> Security Class Initialized
DEBUG - 2020-07-29 13:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:39:35 --> Input Class Initialized
INFO - 2020-07-29 13:39:35 --> Language Class Initialized
INFO - 2020-07-29 13:39:35 --> Loader Class Initialized
INFO - 2020-07-29 13:39:35 --> Helper loaded: url_helper
INFO - 2020-07-29 13:39:35 --> Database Driver Class Initialized
INFO - 2020-07-29 13:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:39:35 --> Email Class Initialized
INFO - 2020-07-29 13:39:35 --> Controller Class Initialized
DEBUG - 2020-07-29 13:39:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:39:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:39:35 --> Model Class Initialized
INFO - 2020-07-29 13:39:35 --> Model Class Initialized
ERROR - 2020-07-29 13:39:35 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
INFO - 2020-07-29 13:39:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 13:39:35 --> Final output sent to browser
DEBUG - 2020-07-29 13:39:35 --> Total execution time: 0.0312
INFO - 2020-07-29 13:42:13 --> Config Class Initialized
INFO - 2020-07-29 13:42:13 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:42:13 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:42:13 --> Utf8 Class Initialized
INFO - 2020-07-29 13:42:13 --> URI Class Initialized
INFO - 2020-07-29 13:42:13 --> Router Class Initialized
INFO - 2020-07-29 13:42:13 --> Output Class Initialized
INFO - 2020-07-29 13:42:13 --> Security Class Initialized
DEBUG - 2020-07-29 13:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:42:13 --> Input Class Initialized
INFO - 2020-07-29 13:42:13 --> Language Class Initialized
INFO - 2020-07-29 13:42:13 --> Loader Class Initialized
INFO - 2020-07-29 13:42:13 --> Helper loaded: url_helper
INFO - 2020-07-29 13:42:13 --> Database Driver Class Initialized
INFO - 2020-07-29 13:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:42:13 --> Email Class Initialized
INFO - 2020-07-29 13:42:13 --> Controller Class Initialized
DEBUG - 2020-07-29 13:42:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:42:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:42:13 --> Model Class Initialized
INFO - 2020-07-29 13:42:13 --> Model Class Initialized
INFO - 2020-07-29 13:42:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 13:42:13 --> Final output sent to browser
DEBUG - 2020-07-29 13:42:13 --> Total execution time: 0.0231
INFO - 2020-07-29 13:43:58 --> Config Class Initialized
INFO - 2020-07-29 13:43:58 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:43:58 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:43:58 --> Utf8 Class Initialized
INFO - 2020-07-29 13:43:58 --> URI Class Initialized
INFO - 2020-07-29 13:43:58 --> Router Class Initialized
INFO - 2020-07-29 13:43:58 --> Output Class Initialized
INFO - 2020-07-29 13:43:58 --> Security Class Initialized
DEBUG - 2020-07-29 13:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:43:58 --> Input Class Initialized
INFO - 2020-07-29 13:43:58 --> Language Class Initialized
INFO - 2020-07-29 13:43:58 --> Loader Class Initialized
INFO - 2020-07-29 13:43:58 --> Helper loaded: url_helper
INFO - 2020-07-29 13:43:58 --> Database Driver Class Initialized
INFO - 2020-07-29 13:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:43:58 --> Email Class Initialized
INFO - 2020-07-29 13:43:58 --> Controller Class Initialized
DEBUG - 2020-07-29 13:43:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:43:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:43:58 --> Model Class Initialized
INFO - 2020-07-29 13:43:58 --> Model Class Initialized
INFO - 2020-07-29 13:43:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 13:43:58 --> Final output sent to browser
DEBUG - 2020-07-29 13:43:58 --> Total execution time: 0.0236
INFO - 2020-07-29 13:44:00 --> Config Class Initialized
INFO - 2020-07-29 13:44:00 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:44:00 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:44:00 --> Utf8 Class Initialized
INFO - 2020-07-29 13:44:00 --> URI Class Initialized
INFO - 2020-07-29 13:44:00 --> Router Class Initialized
INFO - 2020-07-29 13:44:00 --> Output Class Initialized
INFO - 2020-07-29 13:44:00 --> Security Class Initialized
DEBUG - 2020-07-29 13:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:44:00 --> Input Class Initialized
INFO - 2020-07-29 13:44:00 --> Language Class Initialized
INFO - 2020-07-29 13:44:00 --> Loader Class Initialized
INFO - 2020-07-29 13:44:00 --> Helper loaded: url_helper
INFO - 2020-07-29 13:44:00 --> Database Driver Class Initialized
INFO - 2020-07-29 13:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:44:00 --> Email Class Initialized
INFO - 2020-07-29 13:44:00 --> Controller Class Initialized
DEBUG - 2020-07-29 13:44:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:44:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:44:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-29 13:44:00 --> Final output sent to browser
DEBUG - 2020-07-29 13:44:00 --> Total execution time: 0.0300
INFO - 2020-07-29 13:45:16 --> Config Class Initialized
INFO - 2020-07-29 13:45:16 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:45:16 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:45:16 --> Utf8 Class Initialized
INFO - 2020-07-29 13:45:16 --> URI Class Initialized
DEBUG - 2020-07-29 13:45:16 --> No URI present. Default controller set.
INFO - 2020-07-29 13:45:16 --> Router Class Initialized
INFO - 2020-07-29 13:45:16 --> Output Class Initialized
INFO - 2020-07-29 13:45:16 --> Security Class Initialized
DEBUG - 2020-07-29 13:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:45:16 --> Input Class Initialized
INFO - 2020-07-29 13:45:16 --> Language Class Initialized
INFO - 2020-07-29 13:45:16 --> Loader Class Initialized
INFO - 2020-07-29 13:45:16 --> Helper loaded: url_helper
INFO - 2020-07-29 13:45:16 --> Database Driver Class Initialized
INFO - 2020-07-29 13:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:45:16 --> Email Class Initialized
INFO - 2020-07-29 13:45:16 --> Controller Class Initialized
INFO - 2020-07-29 13:45:16 --> Model Class Initialized
INFO - 2020-07-29 13:45:16 --> Model Class Initialized
DEBUG - 2020-07-29 13:45:16 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:45:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 13:45:16 --> Final output sent to browser
DEBUG - 2020-07-29 13:45:16 --> Total execution time: 0.0228
INFO - 2020-07-29 13:45:18 --> Config Class Initialized
INFO - 2020-07-29 13:45:18 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:45:18 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:45:18 --> Utf8 Class Initialized
INFO - 2020-07-29 13:45:18 --> URI Class Initialized
INFO - 2020-07-29 13:45:18 --> Router Class Initialized
INFO - 2020-07-29 13:45:18 --> Output Class Initialized
INFO - 2020-07-29 13:45:18 --> Security Class Initialized
DEBUG - 2020-07-29 13:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:45:18 --> Input Class Initialized
INFO - 2020-07-29 13:45:18 --> Language Class Initialized
INFO - 2020-07-29 13:45:18 --> Loader Class Initialized
INFO - 2020-07-29 13:45:18 --> Helper loaded: url_helper
INFO - 2020-07-29 13:45:18 --> Database Driver Class Initialized
INFO - 2020-07-29 13:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:45:18 --> Email Class Initialized
INFO - 2020-07-29 13:45:18 --> Controller Class Initialized
INFO - 2020-07-29 13:45:18 --> Model Class Initialized
INFO - 2020-07-29 13:45:18 --> Model Class Initialized
DEBUG - 2020-07-29 13:45:18 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:45:19 --> Config Class Initialized
INFO - 2020-07-29 13:45:19 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:45:19 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:45:19 --> Utf8 Class Initialized
INFO - 2020-07-29 13:45:19 --> URI Class Initialized
INFO - 2020-07-29 13:45:19 --> Router Class Initialized
INFO - 2020-07-29 13:45:19 --> Output Class Initialized
INFO - 2020-07-29 13:45:19 --> Security Class Initialized
DEBUG - 2020-07-29 13:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:45:19 --> Input Class Initialized
INFO - 2020-07-29 13:45:19 --> Language Class Initialized
INFO - 2020-07-29 13:45:19 --> Loader Class Initialized
INFO - 2020-07-29 13:45:19 --> Helper loaded: url_helper
INFO - 2020-07-29 13:45:19 --> Database Driver Class Initialized
INFO - 2020-07-29 13:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:45:19 --> Email Class Initialized
INFO - 2020-07-29 13:45:19 --> Controller Class Initialized
DEBUG - 2020-07-29 13:45:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:45:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:45:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 13:45:19 --> Final output sent to browser
DEBUG - 2020-07-29 13:45:19 --> Total execution time: 0.0208
INFO - 2020-07-29 13:45:23 --> Config Class Initialized
INFO - 2020-07-29 13:45:23 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:45:23 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:45:23 --> Utf8 Class Initialized
INFO - 2020-07-29 13:45:23 --> URI Class Initialized
INFO - 2020-07-29 13:45:23 --> Router Class Initialized
INFO - 2020-07-29 13:45:23 --> Output Class Initialized
INFO - 2020-07-29 13:45:23 --> Security Class Initialized
DEBUG - 2020-07-29 13:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:45:23 --> Input Class Initialized
INFO - 2020-07-29 13:45:23 --> Language Class Initialized
INFO - 2020-07-29 13:45:23 --> Loader Class Initialized
INFO - 2020-07-29 13:45:23 --> Helper loaded: url_helper
INFO - 2020-07-29 13:45:23 --> Database Driver Class Initialized
INFO - 2020-07-29 13:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:45:23 --> Email Class Initialized
INFO - 2020-07-29 13:45:23 --> Controller Class Initialized
DEBUG - 2020-07-29 13:45:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:45:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:45:23 --> Model Class Initialized
INFO - 2020-07-29 13:45:23 --> Model Class Initialized
INFO - 2020-07-29 13:45:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 13:45:23 --> Final output sent to browser
DEBUG - 2020-07-29 13:45:23 --> Total execution time: 0.0259
INFO - 2020-07-29 13:45:32 --> Config Class Initialized
INFO - 2020-07-29 13:45:32 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:45:32 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:45:32 --> Utf8 Class Initialized
INFO - 2020-07-29 13:45:32 --> URI Class Initialized
INFO - 2020-07-29 13:45:32 --> Router Class Initialized
INFO - 2020-07-29 13:45:32 --> Output Class Initialized
INFO - 2020-07-29 13:45:32 --> Security Class Initialized
DEBUG - 2020-07-29 13:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:45:32 --> Input Class Initialized
INFO - 2020-07-29 13:45:32 --> Language Class Initialized
INFO - 2020-07-29 13:45:32 --> Loader Class Initialized
INFO - 2020-07-29 13:45:32 --> Helper loaded: url_helper
INFO - 2020-07-29 13:45:32 --> Database Driver Class Initialized
INFO - 2020-07-29 13:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:45:32 --> Email Class Initialized
INFO - 2020-07-29 13:45:32 --> Controller Class Initialized
DEBUG - 2020-07-29 13:45:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:45:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:45:32 --> Model Class Initialized
INFO - 2020-07-29 13:45:32 --> Model Class Initialized
INFO - 2020-07-29 13:45:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-07-29 13:45:32 --> Final output sent to browser
DEBUG - 2020-07-29 13:45:32 --> Total execution time: 0.0221
INFO - 2020-07-29 13:45:35 --> Config Class Initialized
INFO - 2020-07-29 13:45:35 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:45:35 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:45:35 --> Utf8 Class Initialized
INFO - 2020-07-29 13:45:35 --> URI Class Initialized
INFO - 2020-07-29 13:45:35 --> Router Class Initialized
INFO - 2020-07-29 13:45:35 --> Output Class Initialized
INFO - 2020-07-29 13:45:35 --> Security Class Initialized
DEBUG - 2020-07-29 13:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:45:35 --> Input Class Initialized
INFO - 2020-07-29 13:45:35 --> Language Class Initialized
INFO - 2020-07-29 13:45:35 --> Loader Class Initialized
INFO - 2020-07-29 13:45:35 --> Helper loaded: url_helper
INFO - 2020-07-29 13:45:35 --> Database Driver Class Initialized
INFO - 2020-07-29 13:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:45:35 --> Email Class Initialized
INFO - 2020-07-29 13:45:35 --> Controller Class Initialized
DEBUG - 2020-07-29 13:45:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:45:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:45:35 --> Model Class Initialized
INFO - 2020-07-29 13:45:35 --> Model Class Initialized
INFO - 2020-07-29 13:45:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 13:45:35 --> Final output sent to browser
DEBUG - 2020-07-29 13:45:35 --> Total execution time: 0.0206
INFO - 2020-07-29 13:45:37 --> Config Class Initialized
INFO - 2020-07-29 13:45:37 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:45:37 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:45:37 --> Utf8 Class Initialized
INFO - 2020-07-29 13:45:37 --> URI Class Initialized
INFO - 2020-07-29 13:45:37 --> Router Class Initialized
INFO - 2020-07-29 13:45:37 --> Output Class Initialized
INFO - 2020-07-29 13:45:37 --> Security Class Initialized
DEBUG - 2020-07-29 13:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:45:37 --> Input Class Initialized
INFO - 2020-07-29 13:45:37 --> Language Class Initialized
INFO - 2020-07-29 13:45:37 --> Loader Class Initialized
INFO - 2020-07-29 13:45:37 --> Helper loaded: url_helper
INFO - 2020-07-29 13:45:37 --> Database Driver Class Initialized
INFO - 2020-07-29 13:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:45:37 --> Email Class Initialized
INFO - 2020-07-29 13:45:37 --> Controller Class Initialized
DEBUG - 2020-07-29 13:45:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:45:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:45:37 --> Model Class Initialized
INFO - 2020-07-29 13:45:37 --> Model Class Initialized
INFO - 2020-07-29 13:45:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 13:45:37 --> Final output sent to browser
DEBUG - 2020-07-29 13:45:37 --> Total execution time: 0.0224
INFO - 2020-07-29 13:45:45 --> Config Class Initialized
INFO - 2020-07-29 13:45:45 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:45:45 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:45:45 --> Utf8 Class Initialized
INFO - 2020-07-29 13:45:45 --> URI Class Initialized
INFO - 2020-07-29 13:45:45 --> Router Class Initialized
INFO - 2020-07-29 13:45:45 --> Output Class Initialized
INFO - 2020-07-29 13:45:45 --> Security Class Initialized
DEBUG - 2020-07-29 13:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:45:45 --> Input Class Initialized
INFO - 2020-07-29 13:45:45 --> Language Class Initialized
INFO - 2020-07-29 13:45:45 --> Loader Class Initialized
INFO - 2020-07-29 13:45:45 --> Helper loaded: url_helper
INFO - 2020-07-29 13:45:45 --> Database Driver Class Initialized
INFO - 2020-07-29 13:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:45:45 --> Email Class Initialized
INFO - 2020-07-29 13:45:45 --> Controller Class Initialized
DEBUG - 2020-07-29 13:45:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:45:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:45:45 --> Model Class Initialized
INFO - 2020-07-29 13:45:45 --> Model Class Initialized
ERROR - 2020-07-29 13:45:45 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
INFO - 2020-07-29 13:45:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 13:45:45 --> Final output sent to browser
DEBUG - 2020-07-29 13:45:45 --> Total execution time: 0.0385
INFO - 2020-07-29 13:45:55 --> Config Class Initialized
INFO - 2020-07-29 13:45:55 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:45:55 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:45:55 --> Utf8 Class Initialized
INFO - 2020-07-29 13:45:55 --> URI Class Initialized
INFO - 2020-07-29 13:45:55 --> Router Class Initialized
INFO - 2020-07-29 13:45:55 --> Output Class Initialized
INFO - 2020-07-29 13:45:55 --> Security Class Initialized
DEBUG - 2020-07-29 13:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:45:55 --> Input Class Initialized
INFO - 2020-07-29 13:45:55 --> Language Class Initialized
INFO - 2020-07-29 13:45:55 --> Loader Class Initialized
INFO - 2020-07-29 13:45:55 --> Helper loaded: url_helper
INFO - 2020-07-29 13:45:55 --> Database Driver Class Initialized
INFO - 2020-07-29 13:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:45:55 --> Email Class Initialized
INFO - 2020-07-29 13:45:55 --> Controller Class Initialized
DEBUG - 2020-07-29 13:45:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:45:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:45:55 --> Model Class Initialized
INFO - 2020-07-29 13:45:55 --> Model Class Initialized
INFO - 2020-07-29 13:45:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 13:45:55 --> Final output sent to browser
DEBUG - 2020-07-29 13:45:55 --> Total execution time: 0.0241
INFO - 2020-07-29 13:46:01 --> Config Class Initialized
INFO - 2020-07-29 13:46:01 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:46:01 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:46:01 --> Utf8 Class Initialized
INFO - 2020-07-29 13:46:01 --> URI Class Initialized
INFO - 2020-07-29 13:46:01 --> Router Class Initialized
INFO - 2020-07-29 13:46:01 --> Output Class Initialized
INFO - 2020-07-29 13:46:01 --> Security Class Initialized
DEBUG - 2020-07-29 13:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:46:01 --> Input Class Initialized
INFO - 2020-07-29 13:46:01 --> Language Class Initialized
INFO - 2020-07-29 13:46:01 --> Loader Class Initialized
INFO - 2020-07-29 13:46:01 --> Helper loaded: url_helper
INFO - 2020-07-29 13:46:01 --> Database Driver Class Initialized
INFO - 2020-07-29 13:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:46:01 --> Email Class Initialized
INFO - 2020-07-29 13:46:01 --> Controller Class Initialized
DEBUG - 2020-07-29 13:46:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:46:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:46:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-29 13:46:01 --> Final output sent to browser
DEBUG - 2020-07-29 13:46:01 --> Total execution time: 0.0230
INFO - 2020-07-29 13:46:38 --> Config Class Initialized
INFO - 2020-07-29 13:46:38 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:46:38 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:46:38 --> Utf8 Class Initialized
INFO - 2020-07-29 13:46:38 --> URI Class Initialized
DEBUG - 2020-07-29 13:46:38 --> No URI present. Default controller set.
INFO - 2020-07-29 13:46:38 --> Router Class Initialized
INFO - 2020-07-29 13:46:38 --> Output Class Initialized
INFO - 2020-07-29 13:46:38 --> Security Class Initialized
DEBUG - 2020-07-29 13:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:46:38 --> Input Class Initialized
INFO - 2020-07-29 13:46:38 --> Language Class Initialized
INFO - 2020-07-29 13:46:38 --> Loader Class Initialized
INFO - 2020-07-29 13:46:38 --> Helper loaded: url_helper
INFO - 2020-07-29 13:46:38 --> Database Driver Class Initialized
INFO - 2020-07-29 13:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:46:38 --> Email Class Initialized
INFO - 2020-07-29 13:46:38 --> Controller Class Initialized
INFO - 2020-07-29 13:46:38 --> Model Class Initialized
INFO - 2020-07-29 13:46:38 --> Model Class Initialized
DEBUG - 2020-07-29 13:46:38 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:46:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 13:46:38 --> Final output sent to browser
DEBUG - 2020-07-29 13:46:38 --> Total execution time: 0.0213
INFO - 2020-07-29 13:46:40 --> Config Class Initialized
INFO - 2020-07-29 13:46:40 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:46:40 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:46:40 --> Utf8 Class Initialized
INFO - 2020-07-29 13:46:40 --> URI Class Initialized
INFO - 2020-07-29 13:46:40 --> Router Class Initialized
INFO - 2020-07-29 13:46:40 --> Output Class Initialized
INFO - 2020-07-29 13:46:40 --> Security Class Initialized
DEBUG - 2020-07-29 13:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:46:40 --> Input Class Initialized
INFO - 2020-07-29 13:46:40 --> Language Class Initialized
INFO - 2020-07-29 13:46:40 --> Loader Class Initialized
INFO - 2020-07-29 13:46:40 --> Helper loaded: url_helper
INFO - 2020-07-29 13:46:40 --> Database Driver Class Initialized
INFO - 2020-07-29 13:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:46:40 --> Email Class Initialized
INFO - 2020-07-29 13:46:40 --> Controller Class Initialized
INFO - 2020-07-29 13:46:40 --> Model Class Initialized
INFO - 2020-07-29 13:46:40 --> Model Class Initialized
DEBUG - 2020-07-29 13:46:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:46:41 --> Config Class Initialized
INFO - 2020-07-29 13:46:41 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:46:41 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:46:41 --> Utf8 Class Initialized
INFO - 2020-07-29 13:46:41 --> URI Class Initialized
INFO - 2020-07-29 13:46:41 --> Router Class Initialized
INFO - 2020-07-29 13:46:41 --> Output Class Initialized
INFO - 2020-07-29 13:46:41 --> Security Class Initialized
DEBUG - 2020-07-29 13:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:46:41 --> Input Class Initialized
INFO - 2020-07-29 13:46:41 --> Language Class Initialized
INFO - 2020-07-29 13:46:41 --> Loader Class Initialized
INFO - 2020-07-29 13:46:41 --> Helper loaded: url_helper
INFO - 2020-07-29 13:46:41 --> Database Driver Class Initialized
INFO - 2020-07-29 13:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:46:41 --> Email Class Initialized
INFO - 2020-07-29 13:46:41 --> Controller Class Initialized
DEBUG - 2020-07-29 13:46:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:46:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:46:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 13:46:41 --> Final output sent to browser
DEBUG - 2020-07-29 13:46:41 --> Total execution time: 0.0209
INFO - 2020-07-29 13:47:13 --> Config Class Initialized
INFO - 2020-07-29 13:47:13 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:47:13 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:47:13 --> Utf8 Class Initialized
INFO - 2020-07-29 13:47:13 --> URI Class Initialized
INFO - 2020-07-29 13:47:13 --> Router Class Initialized
INFO - 2020-07-29 13:47:13 --> Output Class Initialized
INFO - 2020-07-29 13:47:13 --> Security Class Initialized
DEBUG - 2020-07-29 13:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:47:13 --> Input Class Initialized
INFO - 2020-07-29 13:47:13 --> Config Class Initialized
INFO - 2020-07-29 13:47:13 --> Hooks Class Initialized
INFO - 2020-07-29 13:47:13 --> Language Class Initialized
DEBUG - 2020-07-29 13:47:13 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:47:13 --> Utf8 Class Initialized
INFO - 2020-07-29 13:47:13 --> Loader Class Initialized
INFO - 2020-07-29 13:47:13 --> URI Class Initialized
INFO - 2020-07-29 13:47:13 --> Helper loaded: url_helper
INFO - 2020-07-29 13:47:13 --> Router Class Initialized
INFO - 2020-07-29 13:47:13 --> Output Class Initialized
INFO - 2020-07-29 13:47:13 --> Security Class Initialized
DEBUG - 2020-07-29 13:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:47:13 --> Input Class Initialized
INFO - 2020-07-29 13:47:13 --> Language Class Initialized
INFO - 2020-07-29 13:47:13 --> Database Driver Class Initialized
INFO - 2020-07-29 13:47:13 --> Loader Class Initialized
INFO - 2020-07-29 13:47:13 --> Helper loaded: url_helper
INFO - 2020-07-29 13:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:47:13 --> Email Class Initialized
INFO - 2020-07-29 13:47:13 --> Controller Class Initialized
DEBUG - 2020-07-29 13:47:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:47:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:47:13 --> Model Class Initialized
INFO - 2020-07-29 13:47:13 --> Model Class Initialized
INFO - 2020-07-29 13:47:13 --> Database Driver Class Initialized
INFO - 2020-07-29 13:47:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 13:47:13 --> Final output sent to browser
DEBUG - 2020-07-29 13:47:13 --> Total execution time: 0.0272
INFO - 2020-07-29 13:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:47:13 --> Email Class Initialized
INFO - 2020-07-29 13:47:13 --> Controller Class Initialized
DEBUG - 2020-07-29 13:47:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:47:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:47:13 --> Model Class Initialized
INFO - 2020-07-29 13:47:13 --> Model Class Initialized
INFO - 2020-07-29 13:47:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 13:47:13 --> Final output sent to browser
DEBUG - 2020-07-29 13:47:13 --> Total execution time: 0.0305
INFO - 2020-07-29 13:47:16 --> Config Class Initialized
INFO - 2020-07-29 13:47:16 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:47:16 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:47:16 --> Utf8 Class Initialized
INFO - 2020-07-29 13:47:16 --> URI Class Initialized
INFO - 2020-07-29 13:47:16 --> Router Class Initialized
INFO - 2020-07-29 13:47:16 --> Output Class Initialized
INFO - 2020-07-29 13:47:16 --> Security Class Initialized
DEBUG - 2020-07-29 13:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:47:16 --> Input Class Initialized
INFO - 2020-07-29 13:47:16 --> Language Class Initialized
INFO - 2020-07-29 13:47:16 --> Loader Class Initialized
INFO - 2020-07-29 13:47:16 --> Helper loaded: url_helper
INFO - 2020-07-29 13:47:16 --> Database Driver Class Initialized
INFO - 2020-07-29 13:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:47:16 --> Email Class Initialized
INFO - 2020-07-29 13:47:16 --> Controller Class Initialized
DEBUG - 2020-07-29 13:47:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:47:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:47:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-29 13:47:16 --> Final output sent to browser
DEBUG - 2020-07-29 13:47:16 --> Total execution time: 0.0232
INFO - 2020-07-29 13:47:42 --> Config Class Initialized
INFO - 2020-07-29 13:47:42 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:47:42 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:47:42 --> Utf8 Class Initialized
INFO - 2020-07-29 13:47:42 --> URI Class Initialized
INFO - 2020-07-29 13:47:42 --> Router Class Initialized
INFO - 2020-07-29 13:47:42 --> Output Class Initialized
INFO - 2020-07-29 13:47:42 --> Security Class Initialized
DEBUG - 2020-07-29 13:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:47:42 --> Input Class Initialized
INFO - 2020-07-29 13:47:42 --> Language Class Initialized
INFO - 2020-07-29 13:47:42 --> Loader Class Initialized
INFO - 2020-07-29 13:47:42 --> Helper loaded: url_helper
INFO - 2020-07-29 13:47:42 --> Database Driver Class Initialized
INFO - 2020-07-29 13:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:47:42 --> Email Class Initialized
INFO - 2020-07-29 13:47:42 --> Controller Class Initialized
DEBUG - 2020-07-29 13:47:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:47:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:47:42 --> Model Class Initialized
INFO - 2020-07-29 13:47:42 --> Model Class Initialized
ERROR - 2020-07-29 13:47:42 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
INFO - 2020-07-29 13:47:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 13:47:42 --> Final output sent to browser
DEBUG - 2020-07-29 13:47:42 --> Total execution time: 0.0265
INFO - 2020-07-29 13:48:43 --> Config Class Initialized
INFO - 2020-07-29 13:48:43 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:48:43 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:48:43 --> Utf8 Class Initialized
INFO - 2020-07-29 13:48:43 --> URI Class Initialized
INFO - 2020-07-29 13:48:43 --> Router Class Initialized
INFO - 2020-07-29 13:48:43 --> Output Class Initialized
INFO - 2020-07-29 13:48:43 --> Security Class Initialized
DEBUG - 2020-07-29 13:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:48:43 --> Input Class Initialized
INFO - 2020-07-29 13:48:43 --> Language Class Initialized
INFO - 2020-07-29 13:48:43 --> Loader Class Initialized
INFO - 2020-07-29 13:48:43 --> Helper loaded: url_helper
INFO - 2020-07-29 13:48:43 --> Database Driver Class Initialized
INFO - 2020-07-29 13:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:48:43 --> Email Class Initialized
INFO - 2020-07-29 13:48:43 --> Controller Class Initialized
DEBUG - 2020-07-29 13:48:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:48:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:48:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-29 13:48:43 --> Final output sent to browser
DEBUG - 2020-07-29 13:48:43 --> Total execution time: 0.0223
INFO - 2020-07-29 13:48:49 --> Config Class Initialized
INFO - 2020-07-29 13:48:49 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:48:49 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:48:49 --> Utf8 Class Initialized
INFO - 2020-07-29 13:48:49 --> URI Class Initialized
INFO - 2020-07-29 13:48:49 --> Router Class Initialized
INFO - 2020-07-29 13:48:49 --> Output Class Initialized
INFO - 2020-07-29 13:48:49 --> Security Class Initialized
DEBUG - 2020-07-29 13:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:48:49 --> Input Class Initialized
INFO - 2020-07-29 13:48:49 --> Language Class Initialized
INFO - 2020-07-29 13:48:49 --> Loader Class Initialized
INFO - 2020-07-29 13:48:49 --> Helper loaded: url_helper
INFO - 2020-07-29 13:48:49 --> Database Driver Class Initialized
INFO - 2020-07-29 13:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:48:49 --> Email Class Initialized
INFO - 2020-07-29 13:48:49 --> Controller Class Initialized
DEBUG - 2020-07-29 13:48:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:48:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:48:49 --> Model Class Initialized
INFO - 2020-07-29 13:48:49 --> Model Class Initialized
ERROR - 2020-07-29 13:48:49 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
INFO - 2020-07-29 13:48:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 13:48:49 --> Final output sent to browser
DEBUG - 2020-07-29 13:48:49 --> Total execution time: 0.0265
INFO - 2020-07-29 13:50:37 --> Config Class Initialized
INFO - 2020-07-29 13:50:37 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:50:37 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:50:37 --> Utf8 Class Initialized
INFO - 2020-07-29 13:50:37 --> URI Class Initialized
INFO - 2020-07-29 13:50:37 --> Router Class Initialized
INFO - 2020-07-29 13:50:37 --> Output Class Initialized
INFO - 2020-07-29 13:50:37 --> Security Class Initialized
DEBUG - 2020-07-29 13:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:50:37 --> Input Class Initialized
INFO - 2020-07-29 13:50:37 --> Language Class Initialized
INFO - 2020-07-29 13:50:37 --> Loader Class Initialized
INFO - 2020-07-29 13:50:37 --> Helper loaded: url_helper
INFO - 2020-07-29 13:50:37 --> Database Driver Class Initialized
INFO - 2020-07-29 13:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:50:37 --> Email Class Initialized
INFO - 2020-07-29 13:50:37 --> Controller Class Initialized
DEBUG - 2020-07-29 13:50:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:50:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:50:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-29 13:50:37 --> Final output sent to browser
DEBUG - 2020-07-29 13:50:37 --> Total execution time: 0.0217
INFO - 2020-07-29 13:50:41 --> Config Class Initialized
INFO - 2020-07-29 13:50:41 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:50:41 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:50:41 --> Utf8 Class Initialized
INFO - 2020-07-29 13:50:41 --> URI Class Initialized
INFO - 2020-07-29 13:50:41 --> Router Class Initialized
INFO - 2020-07-29 13:50:41 --> Output Class Initialized
INFO - 2020-07-29 13:50:41 --> Security Class Initialized
DEBUG - 2020-07-29 13:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:50:41 --> Input Class Initialized
INFO - 2020-07-29 13:50:41 --> Language Class Initialized
INFO - 2020-07-29 13:50:41 --> Loader Class Initialized
INFO - 2020-07-29 13:50:41 --> Helper loaded: url_helper
INFO - 2020-07-29 13:50:41 --> Database Driver Class Initialized
INFO - 2020-07-29 13:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:50:41 --> Email Class Initialized
INFO - 2020-07-29 13:50:41 --> Controller Class Initialized
DEBUG - 2020-07-29 13:50:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:50:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:50:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-29 13:50:41 --> Final output sent to browser
DEBUG - 2020-07-29 13:50:41 --> Total execution time: 0.0220
INFO - 2020-07-29 13:50:58 --> Config Class Initialized
INFO - 2020-07-29 13:50:58 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:50:58 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:50:58 --> Utf8 Class Initialized
INFO - 2020-07-29 13:50:58 --> URI Class Initialized
INFO - 2020-07-29 13:50:58 --> Router Class Initialized
INFO - 2020-07-29 13:50:58 --> Output Class Initialized
INFO - 2020-07-29 13:50:58 --> Security Class Initialized
DEBUG - 2020-07-29 13:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:50:58 --> Input Class Initialized
INFO - 2020-07-29 13:50:58 --> Language Class Initialized
INFO - 2020-07-29 13:50:58 --> Loader Class Initialized
INFO - 2020-07-29 13:50:58 --> Helper loaded: url_helper
INFO - 2020-07-29 13:50:58 --> Database Driver Class Initialized
INFO - 2020-07-29 13:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:50:58 --> Email Class Initialized
INFO - 2020-07-29 13:50:58 --> Controller Class Initialized
DEBUG - 2020-07-29 13:50:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:50:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:50:58 --> Model Class Initialized
INFO - 2020-07-29 13:50:58 --> Model Class Initialized
ERROR - 2020-07-29 13:50:58 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2020-07-29 13:50:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 13:50:58 --> Severity: Error --> Call to undefined method CI_DB_mysql_result::next_result() /home/purpu1ex/public_html/carsm/application/models/Admin_model.php 26
INFO - 2020-07-29 13:51:28 --> Config Class Initialized
INFO - 2020-07-29 13:51:28 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:51:28 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:51:28 --> Utf8 Class Initialized
INFO - 2020-07-29 13:51:28 --> URI Class Initialized
INFO - 2020-07-29 13:51:28 --> Router Class Initialized
INFO - 2020-07-29 13:51:28 --> Output Class Initialized
INFO - 2020-07-29 13:51:28 --> Security Class Initialized
DEBUG - 2020-07-29 13:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:51:28 --> Input Class Initialized
INFO - 2020-07-29 13:51:28 --> Language Class Initialized
INFO - 2020-07-29 13:51:28 --> Loader Class Initialized
INFO - 2020-07-29 13:51:28 --> Helper loaded: url_helper
INFO - 2020-07-29 13:51:28 --> Database Driver Class Initialized
INFO - 2020-07-29 13:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:51:28 --> Email Class Initialized
INFO - 2020-07-29 13:51:28 --> Controller Class Initialized
DEBUG - 2020-07-29 13:51:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:51:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:51:28 --> Model Class Initialized
INFO - 2020-07-29 13:51:28 --> Model Class Initialized
INFO - 2020-07-29 13:51:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 13:51:28 --> Final output sent to browser
DEBUG - 2020-07-29 13:51:28 --> Total execution time: 0.0270
INFO - 2020-07-29 13:52:34 --> Config Class Initialized
INFO - 2020-07-29 13:52:34 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:52:34 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:52:34 --> Utf8 Class Initialized
INFO - 2020-07-29 13:52:34 --> URI Class Initialized
INFO - 2020-07-29 13:52:34 --> Router Class Initialized
INFO - 2020-07-29 13:52:34 --> Output Class Initialized
INFO - 2020-07-29 13:52:34 --> Security Class Initialized
DEBUG - 2020-07-29 13:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:52:34 --> Input Class Initialized
INFO - 2020-07-29 13:52:34 --> Language Class Initialized
INFO - 2020-07-29 13:52:34 --> Loader Class Initialized
INFO - 2020-07-29 13:52:34 --> Helper loaded: url_helper
INFO - 2020-07-29 13:52:34 --> Database Driver Class Initialized
INFO - 2020-07-29 13:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:52:34 --> Email Class Initialized
INFO - 2020-07-29 13:52:34 --> Controller Class Initialized
DEBUG - 2020-07-29 13:52:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:52:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:52:34 --> Model Class Initialized
INFO - 2020-07-29 13:52:34 --> Model Class Initialized
ERROR - 2020-07-29 13:52:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/Admin_model.php:69) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 13:52:34 --> Severity: Error --> Call to undefined method CI_DB_mysql_result::next_result() /home/purpu1ex/public_html/carsm/application/models/Admin_model.php 69
INFO - 2020-07-29 13:52:37 --> Config Class Initialized
INFO - 2020-07-29 13:52:37 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:52:37 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:52:37 --> Utf8 Class Initialized
INFO - 2020-07-29 13:52:37 --> URI Class Initialized
INFO - 2020-07-29 13:52:37 --> Router Class Initialized
INFO - 2020-07-29 13:52:37 --> Output Class Initialized
INFO - 2020-07-29 13:52:37 --> Security Class Initialized
DEBUG - 2020-07-29 13:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:52:37 --> Input Class Initialized
INFO - 2020-07-29 13:52:37 --> Language Class Initialized
INFO - 2020-07-29 13:52:37 --> Loader Class Initialized
INFO - 2020-07-29 13:52:37 --> Helper loaded: url_helper
INFO - 2020-07-29 13:52:37 --> Database Driver Class Initialized
INFO - 2020-07-29 13:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:52:37 --> Email Class Initialized
INFO - 2020-07-29 13:52:37 --> Controller Class Initialized
DEBUG - 2020-07-29 13:52:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:52:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:52:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-29 13:52:37 --> Final output sent to browser
DEBUG - 2020-07-29 13:52:37 --> Total execution time: 0.0230
INFO - 2020-07-29 13:52:42 --> Config Class Initialized
INFO - 2020-07-29 13:52:42 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:52:42 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:52:42 --> Utf8 Class Initialized
INFO - 2020-07-29 13:52:42 --> URI Class Initialized
INFO - 2020-07-29 13:52:42 --> Router Class Initialized
INFO - 2020-07-29 13:52:42 --> Output Class Initialized
INFO - 2020-07-29 13:52:42 --> Security Class Initialized
DEBUG - 2020-07-29 13:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:52:42 --> Input Class Initialized
INFO - 2020-07-29 13:52:42 --> Language Class Initialized
INFO - 2020-07-29 13:52:42 --> Loader Class Initialized
INFO - 2020-07-29 13:52:42 --> Helper loaded: url_helper
INFO - 2020-07-29 13:52:42 --> Database Driver Class Initialized
INFO - 2020-07-29 13:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:52:42 --> Email Class Initialized
INFO - 2020-07-29 13:52:42 --> Controller Class Initialized
DEBUG - 2020-07-29 13:52:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:52:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:52:42 --> Model Class Initialized
INFO - 2020-07-29 13:52:42 --> Model Class Initialized
ERROR - 2020-07-29 13:52:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/Admin_model.php:69) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 13:52:42 --> Severity: Error --> Call to undefined method CI_DB_mysql_result::next_result() /home/purpu1ex/public_html/carsm/application/models/Admin_model.php 69
INFO - 2020-07-29 13:52:48 --> Config Class Initialized
INFO - 2020-07-29 13:52:48 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:52:48 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:52:48 --> Utf8 Class Initialized
INFO - 2020-07-29 13:52:48 --> URI Class Initialized
INFO - 2020-07-29 13:52:48 --> Router Class Initialized
INFO - 2020-07-29 13:52:48 --> Output Class Initialized
INFO - 2020-07-29 13:52:48 --> Security Class Initialized
DEBUG - 2020-07-29 13:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:52:48 --> Input Class Initialized
INFO - 2020-07-29 13:52:48 --> Language Class Initialized
INFO - 2020-07-29 13:52:48 --> Loader Class Initialized
INFO - 2020-07-29 13:52:48 --> Helper loaded: url_helper
INFO - 2020-07-29 13:52:48 --> Database Driver Class Initialized
INFO - 2020-07-29 13:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:52:48 --> Email Class Initialized
INFO - 2020-07-29 13:52:48 --> Controller Class Initialized
DEBUG - 2020-07-29 13:52:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:52:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:52:48 --> Model Class Initialized
INFO - 2020-07-29 13:52:48 --> Model Class Initialized
ERROR - 2020-07-29 13:52:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/Admin_model.php:69) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 13:52:48 --> Severity: Error --> Call to undefined method CI_DB_mysql_result::next_result() /home/purpu1ex/public_html/carsm/application/models/Admin_model.php 69
INFO - 2020-07-29 13:52:55 --> Config Class Initialized
INFO - 2020-07-29 13:52:55 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:52:55 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:52:55 --> Utf8 Class Initialized
INFO - 2020-07-29 13:52:55 --> URI Class Initialized
DEBUG - 2020-07-29 13:52:55 --> No URI present. Default controller set.
INFO - 2020-07-29 13:52:55 --> Router Class Initialized
INFO - 2020-07-29 13:52:55 --> Output Class Initialized
INFO - 2020-07-29 13:52:55 --> Security Class Initialized
DEBUG - 2020-07-29 13:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:52:55 --> Input Class Initialized
INFO - 2020-07-29 13:52:55 --> Language Class Initialized
INFO - 2020-07-29 13:52:55 --> Loader Class Initialized
INFO - 2020-07-29 13:52:55 --> Helper loaded: url_helper
INFO - 2020-07-29 13:52:55 --> Database Driver Class Initialized
INFO - 2020-07-29 13:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:52:55 --> Email Class Initialized
INFO - 2020-07-29 13:52:55 --> Controller Class Initialized
INFO - 2020-07-29 13:52:55 --> Model Class Initialized
INFO - 2020-07-29 13:52:55 --> Model Class Initialized
DEBUG - 2020-07-29 13:52:55 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:52:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 13:52:55 --> Final output sent to browser
DEBUG - 2020-07-29 13:52:55 --> Total execution time: 0.0193
INFO - 2020-07-29 13:52:56 --> Config Class Initialized
INFO - 2020-07-29 13:52:56 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:52:56 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:52:56 --> Utf8 Class Initialized
INFO - 2020-07-29 13:52:56 --> URI Class Initialized
DEBUG - 2020-07-29 13:52:56 --> No URI present. Default controller set.
INFO - 2020-07-29 13:52:56 --> Router Class Initialized
INFO - 2020-07-29 13:52:56 --> Output Class Initialized
INFO - 2020-07-29 13:52:56 --> Security Class Initialized
DEBUG - 2020-07-29 13:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:52:56 --> Input Class Initialized
INFO - 2020-07-29 13:52:56 --> Language Class Initialized
INFO - 2020-07-29 13:52:56 --> Loader Class Initialized
INFO - 2020-07-29 13:52:56 --> Helper loaded: url_helper
INFO - 2020-07-29 13:52:56 --> Database Driver Class Initialized
INFO - 2020-07-29 13:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:52:56 --> Email Class Initialized
INFO - 2020-07-29 13:52:56 --> Controller Class Initialized
INFO - 2020-07-29 13:52:56 --> Model Class Initialized
INFO - 2020-07-29 13:52:56 --> Model Class Initialized
DEBUG - 2020-07-29 13:52:56 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:52:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 13:52:56 --> Final output sent to browser
DEBUG - 2020-07-29 13:52:56 --> Total execution time: 0.0203
INFO - 2020-07-29 13:52:59 --> Config Class Initialized
INFO - 2020-07-29 13:52:59 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:52:59 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:52:59 --> Utf8 Class Initialized
INFO - 2020-07-29 13:52:59 --> URI Class Initialized
INFO - 2020-07-29 13:52:59 --> Router Class Initialized
INFO - 2020-07-29 13:52:59 --> Output Class Initialized
INFO - 2020-07-29 13:52:59 --> Security Class Initialized
DEBUG - 2020-07-29 13:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:52:59 --> Input Class Initialized
INFO - 2020-07-29 13:52:59 --> Language Class Initialized
INFO - 2020-07-29 13:52:59 --> Loader Class Initialized
INFO - 2020-07-29 13:52:59 --> Helper loaded: url_helper
INFO - 2020-07-29 13:52:59 --> Database Driver Class Initialized
INFO - 2020-07-29 13:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:52:59 --> Email Class Initialized
INFO - 2020-07-29 13:52:59 --> Controller Class Initialized
INFO - 2020-07-29 13:52:59 --> Model Class Initialized
INFO - 2020-07-29 13:52:59 --> Model Class Initialized
DEBUG - 2020-07-29 13:52:59 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:52:59 --> Config Class Initialized
INFO - 2020-07-29 13:52:59 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:52:59 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:52:59 --> Utf8 Class Initialized
INFO - 2020-07-29 13:52:59 --> URI Class Initialized
INFO - 2020-07-29 13:52:59 --> Router Class Initialized
INFO - 2020-07-29 13:52:59 --> Output Class Initialized
INFO - 2020-07-29 13:52:59 --> Security Class Initialized
DEBUG - 2020-07-29 13:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:52:59 --> Input Class Initialized
INFO - 2020-07-29 13:52:59 --> Language Class Initialized
INFO - 2020-07-29 13:52:59 --> Loader Class Initialized
INFO - 2020-07-29 13:52:59 --> Helper loaded: url_helper
INFO - 2020-07-29 13:52:59 --> Database Driver Class Initialized
INFO - 2020-07-29 13:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:52:59 --> Email Class Initialized
INFO - 2020-07-29 13:52:59 --> Controller Class Initialized
DEBUG - 2020-07-29 13:52:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:52:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:52:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 13:52:59 --> Final output sent to browser
DEBUG - 2020-07-29 13:52:59 --> Total execution time: 0.0215
INFO - 2020-07-29 13:53:03 --> Config Class Initialized
INFO - 2020-07-29 13:53:03 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:53:03 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:53:03 --> Utf8 Class Initialized
INFO - 2020-07-29 13:53:03 --> URI Class Initialized
INFO - 2020-07-29 13:53:03 --> Router Class Initialized
INFO - 2020-07-29 13:53:03 --> Output Class Initialized
INFO - 2020-07-29 13:53:03 --> Security Class Initialized
DEBUG - 2020-07-29 13:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:53:03 --> Input Class Initialized
INFO - 2020-07-29 13:53:03 --> Language Class Initialized
INFO - 2020-07-29 13:53:03 --> Loader Class Initialized
INFO - 2020-07-29 13:53:03 --> Helper loaded: url_helper
INFO - 2020-07-29 13:53:03 --> Database Driver Class Initialized
INFO - 2020-07-29 13:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:53:04 --> Email Class Initialized
INFO - 2020-07-29 13:53:04 --> Controller Class Initialized
DEBUG - 2020-07-29 13:53:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:53:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:53:04 --> Model Class Initialized
INFO - 2020-07-29 13:53:04 --> Model Class Initialized
ERROR - 2020-07-29 13:53:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/Admin_model.php:69) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 13:53:04 --> Severity: Error --> Call to undefined method CI_DB_mysql_result::next_result() /home/purpu1ex/public_html/carsm/application/models/Admin_model.php 69
INFO - 2020-07-29 13:54:11 --> Config Class Initialized
INFO - 2020-07-29 13:54:11 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:54:11 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:54:11 --> Utf8 Class Initialized
INFO - 2020-07-29 13:54:11 --> URI Class Initialized
INFO - 2020-07-29 13:54:11 --> Router Class Initialized
INFO - 2020-07-29 13:54:11 --> Output Class Initialized
INFO - 2020-07-29 13:54:11 --> Security Class Initialized
DEBUG - 2020-07-29 13:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:54:11 --> Input Class Initialized
INFO - 2020-07-29 13:54:11 --> Language Class Initialized
INFO - 2020-07-29 13:54:11 --> Loader Class Initialized
INFO - 2020-07-29 13:54:11 --> Helper loaded: url_helper
INFO - 2020-07-29 13:54:11 --> Database Driver Class Initialized
INFO - 2020-07-29 13:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:54:11 --> Email Class Initialized
INFO - 2020-07-29 13:54:11 --> Controller Class Initialized
DEBUG - 2020-07-29 13:54:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:54:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:54:11 --> Model Class Initialized
INFO - 2020-07-29 13:54:11 --> Model Class Initialized
INFO - 2020-07-29 13:54:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 13:54:11 --> Final output sent to browser
DEBUG - 2020-07-29 13:54:11 --> Total execution time: 0.0236
INFO - 2020-07-29 13:54:18 --> Config Class Initialized
INFO - 2020-07-29 13:54:18 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:54:18 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:54:18 --> Utf8 Class Initialized
INFO - 2020-07-29 13:54:18 --> URI Class Initialized
INFO - 2020-07-29 13:54:18 --> Router Class Initialized
INFO - 2020-07-29 13:54:18 --> Output Class Initialized
INFO - 2020-07-29 13:54:18 --> Security Class Initialized
DEBUG - 2020-07-29 13:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:54:18 --> Input Class Initialized
INFO - 2020-07-29 13:54:18 --> Language Class Initialized
INFO - 2020-07-29 13:54:18 --> Loader Class Initialized
INFO - 2020-07-29 13:54:18 --> Helper loaded: url_helper
INFO - 2020-07-29 13:54:18 --> Database Driver Class Initialized
INFO - 2020-07-29 13:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:54:18 --> Email Class Initialized
INFO - 2020-07-29 13:54:18 --> Controller Class Initialized
DEBUG - 2020-07-29 13:54:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:54:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:54:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-29 13:54:18 --> Final output sent to browser
DEBUG - 2020-07-29 13:54:18 --> Total execution time: 0.0185
INFO - 2020-07-29 13:54:48 --> Config Class Initialized
INFO - 2020-07-29 13:54:48 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:54:48 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:54:48 --> Utf8 Class Initialized
INFO - 2020-07-29 13:54:48 --> URI Class Initialized
INFO - 2020-07-29 13:54:48 --> Router Class Initialized
INFO - 2020-07-29 13:54:48 --> Output Class Initialized
INFO - 2020-07-29 13:54:48 --> Security Class Initialized
DEBUG - 2020-07-29 13:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:54:48 --> Input Class Initialized
INFO - 2020-07-29 13:54:48 --> Language Class Initialized
INFO - 2020-07-29 13:54:48 --> Loader Class Initialized
INFO - 2020-07-29 13:54:48 --> Helper loaded: url_helper
INFO - 2020-07-29 13:54:48 --> Database Driver Class Initialized
INFO - 2020-07-29 13:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:54:48 --> Email Class Initialized
INFO - 2020-07-29 13:54:48 --> Controller Class Initialized
DEBUG - 2020-07-29 13:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:54:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:54:48 --> Model Class Initialized
INFO - 2020-07-29 13:54:48 --> Model Class Initialized
ERROR - 2020-07-29 13:54:48 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
INFO - 2020-07-29 13:54:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 13:54:48 --> Final output sent to browser
DEBUG - 2020-07-29 13:54:48 --> Total execution time: 0.0261
INFO - 2020-07-29 13:55:07 --> Config Class Initialized
INFO - 2020-07-29 13:55:07 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:55:07 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:55:07 --> Utf8 Class Initialized
INFO - 2020-07-29 13:55:07 --> URI Class Initialized
INFO - 2020-07-29 13:55:07 --> Router Class Initialized
INFO - 2020-07-29 13:55:07 --> Output Class Initialized
INFO - 2020-07-29 13:55:07 --> Security Class Initialized
DEBUG - 2020-07-29 13:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:55:07 --> Input Class Initialized
INFO - 2020-07-29 13:55:07 --> Language Class Initialized
INFO - 2020-07-29 13:55:07 --> Loader Class Initialized
INFO - 2020-07-29 13:55:07 --> Helper loaded: url_helper
INFO - 2020-07-29 13:55:07 --> Database Driver Class Initialized
INFO - 2020-07-29 13:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:55:07 --> Email Class Initialized
INFO - 2020-07-29 13:55:07 --> Controller Class Initialized
DEBUG - 2020-07-29 13:55:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:55:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:55:07 --> Model Class Initialized
INFO - 2020-07-29 13:55:07 --> Model Class Initialized
INFO - 2020-07-29 13:55:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 13:55:07 --> Final output sent to browser
DEBUG - 2020-07-29 13:55:07 --> Total execution time: 0.0222
INFO - 2020-07-29 13:55:12 --> Config Class Initialized
INFO - 2020-07-29 13:55:12 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:55:12 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:55:12 --> Utf8 Class Initialized
INFO - 2020-07-29 13:55:12 --> URI Class Initialized
DEBUG - 2020-07-29 13:55:12 --> No URI present. Default controller set.
INFO - 2020-07-29 13:55:12 --> Router Class Initialized
INFO - 2020-07-29 13:55:12 --> Output Class Initialized
INFO - 2020-07-29 13:55:12 --> Security Class Initialized
DEBUG - 2020-07-29 13:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:55:12 --> Input Class Initialized
INFO - 2020-07-29 13:55:12 --> Language Class Initialized
INFO - 2020-07-29 13:55:12 --> Loader Class Initialized
INFO - 2020-07-29 13:55:12 --> Helper loaded: url_helper
INFO - 2020-07-29 13:55:12 --> Database Driver Class Initialized
INFO - 2020-07-29 13:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:55:12 --> Email Class Initialized
INFO - 2020-07-29 13:55:12 --> Controller Class Initialized
INFO - 2020-07-29 13:55:12 --> Model Class Initialized
INFO - 2020-07-29 13:55:12 --> Model Class Initialized
DEBUG - 2020-07-29 13:55:12 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:55:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 13:55:12 --> Final output sent to browser
DEBUG - 2020-07-29 13:55:12 --> Total execution time: 0.0247
INFO - 2020-07-29 13:55:15 --> Config Class Initialized
INFO - 2020-07-29 13:55:15 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:55:15 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:55:15 --> Utf8 Class Initialized
INFO - 2020-07-29 13:55:15 --> URI Class Initialized
INFO - 2020-07-29 13:55:15 --> Router Class Initialized
INFO - 2020-07-29 13:55:15 --> Output Class Initialized
INFO - 2020-07-29 13:55:15 --> Security Class Initialized
DEBUG - 2020-07-29 13:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:55:15 --> Input Class Initialized
INFO - 2020-07-29 13:55:15 --> Language Class Initialized
INFO - 2020-07-29 13:55:15 --> Loader Class Initialized
INFO - 2020-07-29 13:55:15 --> Helper loaded: url_helper
INFO - 2020-07-29 13:55:15 --> Database Driver Class Initialized
INFO - 2020-07-29 13:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:55:15 --> Email Class Initialized
INFO - 2020-07-29 13:55:15 --> Controller Class Initialized
INFO - 2020-07-29 13:55:15 --> Model Class Initialized
INFO - 2020-07-29 13:55:15 --> Model Class Initialized
DEBUG - 2020-07-29 13:55:15 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:55:15 --> Config Class Initialized
INFO - 2020-07-29 13:55:15 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:55:15 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:55:15 --> Utf8 Class Initialized
INFO - 2020-07-29 13:55:15 --> URI Class Initialized
INFO - 2020-07-29 13:55:15 --> Router Class Initialized
INFO - 2020-07-29 13:55:15 --> Output Class Initialized
INFO - 2020-07-29 13:55:15 --> Security Class Initialized
DEBUG - 2020-07-29 13:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:55:15 --> Input Class Initialized
INFO - 2020-07-29 13:55:15 --> Language Class Initialized
INFO - 2020-07-29 13:55:15 --> Loader Class Initialized
INFO - 2020-07-29 13:55:15 --> Helper loaded: url_helper
INFO - 2020-07-29 13:55:15 --> Database Driver Class Initialized
INFO - 2020-07-29 13:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:55:15 --> Email Class Initialized
INFO - 2020-07-29 13:55:15 --> Controller Class Initialized
DEBUG - 2020-07-29 13:55:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:55:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:55:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 13:55:15 --> Final output sent to browser
DEBUG - 2020-07-29 13:55:15 --> Total execution time: 0.0202
INFO - 2020-07-29 13:55:19 --> Config Class Initialized
INFO - 2020-07-29 13:55:19 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:55:19 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:55:19 --> Utf8 Class Initialized
INFO - 2020-07-29 13:55:19 --> URI Class Initialized
INFO - 2020-07-29 13:55:19 --> Router Class Initialized
INFO - 2020-07-29 13:55:19 --> Output Class Initialized
INFO - 2020-07-29 13:55:19 --> Security Class Initialized
DEBUG - 2020-07-29 13:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:55:19 --> Input Class Initialized
INFO - 2020-07-29 13:55:19 --> Language Class Initialized
INFO - 2020-07-29 13:55:19 --> Loader Class Initialized
INFO - 2020-07-29 13:55:19 --> Helper loaded: url_helper
INFO - 2020-07-29 13:55:19 --> Database Driver Class Initialized
INFO - 2020-07-29 13:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:55:19 --> Email Class Initialized
INFO - 2020-07-29 13:55:19 --> Controller Class Initialized
DEBUG - 2020-07-29 13:55:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:55:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:55:19 --> Model Class Initialized
INFO - 2020-07-29 13:55:19 --> Model Class Initialized
INFO - 2020-07-29 13:55:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 13:55:19 --> Final output sent to browser
DEBUG - 2020-07-29 13:55:19 --> Total execution time: 0.0205
INFO - 2020-07-29 13:55:42 --> Config Class Initialized
INFO - 2020-07-29 13:55:42 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:55:42 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:55:42 --> Utf8 Class Initialized
INFO - 2020-07-29 13:55:42 --> URI Class Initialized
INFO - 2020-07-29 13:55:42 --> Router Class Initialized
INFO - 2020-07-29 13:55:42 --> Output Class Initialized
INFO - 2020-07-29 13:55:42 --> Security Class Initialized
DEBUG - 2020-07-29 13:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:55:42 --> Input Class Initialized
INFO - 2020-07-29 13:55:42 --> Language Class Initialized
INFO - 2020-07-29 13:55:42 --> Loader Class Initialized
INFO - 2020-07-29 13:55:42 --> Helper loaded: url_helper
INFO - 2020-07-29 13:55:42 --> Database Driver Class Initialized
INFO - 2020-07-29 13:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:55:42 --> Email Class Initialized
INFO - 2020-07-29 13:55:42 --> Controller Class Initialized
DEBUG - 2020-07-29 13:55:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:55:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:55:42 --> Model Class Initialized
INFO - 2020-07-29 13:55:42 --> Model Class Initialized
INFO - 2020-07-29 13:55:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-07-29 13:55:42 --> Final output sent to browser
DEBUG - 2020-07-29 13:55:42 --> Total execution time: 0.0253
INFO - 2020-07-29 13:55:44 --> Config Class Initialized
INFO - 2020-07-29 13:55:44 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:55:44 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:55:44 --> Utf8 Class Initialized
INFO - 2020-07-29 13:55:44 --> URI Class Initialized
INFO - 2020-07-29 13:55:44 --> Router Class Initialized
INFO - 2020-07-29 13:55:44 --> Output Class Initialized
INFO - 2020-07-29 13:55:44 --> Security Class Initialized
DEBUG - 2020-07-29 13:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:55:44 --> Input Class Initialized
INFO - 2020-07-29 13:55:44 --> Language Class Initialized
INFO - 2020-07-29 13:55:44 --> Loader Class Initialized
INFO - 2020-07-29 13:55:44 --> Helper loaded: url_helper
INFO - 2020-07-29 13:55:44 --> Database Driver Class Initialized
INFO - 2020-07-29 13:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:55:44 --> Email Class Initialized
INFO - 2020-07-29 13:55:44 --> Controller Class Initialized
DEBUG - 2020-07-29 13:55:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:55:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:55:44 --> Model Class Initialized
INFO - 2020-07-29 13:55:44 --> Model Class Initialized
INFO - 2020-07-29 13:55:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 13:55:44 --> Final output sent to browser
DEBUG - 2020-07-29 13:55:44 --> Total execution time: 0.0269
INFO - 2020-07-29 13:55:46 --> Config Class Initialized
INFO - 2020-07-29 13:55:46 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:55:46 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:55:46 --> Utf8 Class Initialized
INFO - 2020-07-29 13:55:46 --> URI Class Initialized
INFO - 2020-07-29 13:55:46 --> Router Class Initialized
INFO - 2020-07-29 13:55:46 --> Output Class Initialized
INFO - 2020-07-29 13:55:46 --> Security Class Initialized
DEBUG - 2020-07-29 13:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:55:46 --> Input Class Initialized
INFO - 2020-07-29 13:55:46 --> Language Class Initialized
INFO - 2020-07-29 13:55:46 --> Loader Class Initialized
INFO - 2020-07-29 13:55:46 --> Helper loaded: url_helper
INFO - 2020-07-29 13:55:46 --> Database Driver Class Initialized
INFO - 2020-07-29 13:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:55:46 --> Email Class Initialized
INFO - 2020-07-29 13:55:46 --> Controller Class Initialized
DEBUG - 2020-07-29 13:55:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:55:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:55:46 --> Model Class Initialized
INFO - 2020-07-29 13:55:46 --> Model Class Initialized
INFO - 2020-07-29 13:55:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 13:55:46 --> Final output sent to browser
DEBUG - 2020-07-29 13:55:46 --> Total execution time: 0.0251
INFO - 2020-07-29 13:55:48 --> Config Class Initialized
INFO - 2020-07-29 13:55:48 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:55:48 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:55:48 --> Utf8 Class Initialized
INFO - 2020-07-29 13:55:48 --> URI Class Initialized
INFO - 2020-07-29 13:55:48 --> Router Class Initialized
INFO - 2020-07-29 13:55:48 --> Output Class Initialized
INFO - 2020-07-29 13:55:48 --> Security Class Initialized
DEBUG - 2020-07-29 13:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:55:48 --> Input Class Initialized
INFO - 2020-07-29 13:55:48 --> Language Class Initialized
INFO - 2020-07-29 13:55:48 --> Loader Class Initialized
INFO - 2020-07-29 13:55:48 --> Helper loaded: url_helper
INFO - 2020-07-29 13:55:48 --> Database Driver Class Initialized
INFO - 2020-07-29 13:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:55:48 --> Email Class Initialized
INFO - 2020-07-29 13:55:48 --> Controller Class Initialized
DEBUG - 2020-07-29 13:55:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:55:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:55:48 --> Model Class Initialized
INFO - 2020-07-29 13:55:48 --> Model Class Initialized
ERROR - 2020-07-29 13:55:48 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
INFO - 2020-07-29 13:55:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 13:55:48 --> Final output sent to browser
DEBUG - 2020-07-29 13:55:48 --> Total execution time: 0.0266
INFO - 2020-07-29 13:55:54 --> Config Class Initialized
INFO - 2020-07-29 13:55:54 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:55:54 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:55:54 --> Utf8 Class Initialized
INFO - 2020-07-29 13:55:54 --> URI Class Initialized
INFO - 2020-07-29 13:55:54 --> Router Class Initialized
INFO - 2020-07-29 13:55:54 --> Output Class Initialized
INFO - 2020-07-29 13:55:54 --> Security Class Initialized
DEBUG - 2020-07-29 13:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:55:54 --> Input Class Initialized
INFO - 2020-07-29 13:55:54 --> Language Class Initialized
INFO - 2020-07-29 13:55:54 --> Loader Class Initialized
INFO - 2020-07-29 13:55:54 --> Helper loaded: url_helper
INFO - 2020-07-29 13:55:54 --> Database Driver Class Initialized
INFO - 2020-07-29 13:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:55:54 --> Email Class Initialized
INFO - 2020-07-29 13:55:54 --> Controller Class Initialized
DEBUG - 2020-07-29 13:55:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:55:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:55:54 --> Model Class Initialized
INFO - 2020-07-29 13:55:54 --> Model Class Initialized
INFO - 2020-07-29 13:55:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 13:55:54 --> Final output sent to browser
DEBUG - 2020-07-29 13:55:54 --> Total execution time: 0.0202
INFO - 2020-07-29 13:57:45 --> Config Class Initialized
INFO - 2020-07-29 13:57:45 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:57:45 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:57:45 --> Utf8 Class Initialized
INFO - 2020-07-29 13:57:45 --> URI Class Initialized
INFO - 2020-07-29 13:57:45 --> Router Class Initialized
INFO - 2020-07-29 13:57:45 --> Output Class Initialized
INFO - 2020-07-29 13:57:45 --> Security Class Initialized
DEBUG - 2020-07-29 13:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:57:45 --> Input Class Initialized
INFO - 2020-07-29 13:57:45 --> Language Class Initialized
INFO - 2020-07-29 13:57:45 --> Loader Class Initialized
INFO - 2020-07-29 13:57:45 --> Helper loaded: url_helper
INFO - 2020-07-29 13:57:45 --> Database Driver Class Initialized
INFO - 2020-07-29 13:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:57:45 --> Email Class Initialized
INFO - 2020-07-29 13:57:45 --> Controller Class Initialized
DEBUG - 2020-07-29 13:57:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:57:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:57:45 --> Model Class Initialized
INFO - 2020-07-29 13:57:45 --> Model Class Initialized
INFO - 2020-07-29 13:57:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 13:57:45 --> Final output sent to browser
DEBUG - 2020-07-29 13:57:45 --> Total execution time: 0.0254
INFO - 2020-07-29 13:57:49 --> Config Class Initialized
INFO - 2020-07-29 13:57:49 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:57:49 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:57:49 --> Utf8 Class Initialized
INFO - 2020-07-29 13:57:49 --> URI Class Initialized
INFO - 2020-07-29 13:57:49 --> Router Class Initialized
INFO - 2020-07-29 13:57:49 --> Output Class Initialized
INFO - 2020-07-29 13:57:49 --> Security Class Initialized
DEBUG - 2020-07-29 13:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:57:49 --> Input Class Initialized
INFO - 2020-07-29 13:57:49 --> Language Class Initialized
INFO - 2020-07-29 13:57:49 --> Loader Class Initialized
INFO - 2020-07-29 13:57:49 --> Helper loaded: url_helper
INFO - 2020-07-29 13:57:49 --> Database Driver Class Initialized
INFO - 2020-07-29 13:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:57:49 --> Email Class Initialized
INFO - 2020-07-29 13:57:49 --> Controller Class Initialized
DEBUG - 2020-07-29 13:57:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:57:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:57:49 --> Model Class Initialized
INFO - 2020-07-29 13:57:49 --> Model Class Initialized
INFO - 2020-07-29 13:57:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-07-29 13:57:49 --> Final output sent to browser
DEBUG - 2020-07-29 13:57:49 --> Total execution time: 0.0203
INFO - 2020-07-29 13:57:52 --> Config Class Initialized
INFO - 2020-07-29 13:57:52 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:57:52 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:57:52 --> Utf8 Class Initialized
INFO - 2020-07-29 13:57:52 --> URI Class Initialized
INFO - 2020-07-29 13:57:52 --> Router Class Initialized
INFO - 2020-07-29 13:57:52 --> Output Class Initialized
INFO - 2020-07-29 13:57:52 --> Security Class Initialized
DEBUG - 2020-07-29 13:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:57:52 --> Input Class Initialized
INFO - 2020-07-29 13:57:52 --> Language Class Initialized
INFO - 2020-07-29 13:57:52 --> Loader Class Initialized
INFO - 2020-07-29 13:57:52 --> Helper loaded: url_helper
INFO - 2020-07-29 13:57:52 --> Database Driver Class Initialized
INFO - 2020-07-29 13:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:57:52 --> Email Class Initialized
INFO - 2020-07-29 13:57:52 --> Controller Class Initialized
DEBUG - 2020-07-29 13:57:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:57:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:57:52 --> Model Class Initialized
INFO - 2020-07-29 13:57:52 --> Model Class Initialized
INFO - 2020-07-29 13:57:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 13:57:52 --> Final output sent to browser
DEBUG - 2020-07-29 13:57:52 --> Total execution time: 0.0233
INFO - 2020-07-29 13:57:53 --> Config Class Initialized
INFO - 2020-07-29 13:57:53 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:57:53 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:57:53 --> Utf8 Class Initialized
INFO - 2020-07-29 13:57:53 --> URI Class Initialized
INFO - 2020-07-29 13:57:53 --> Router Class Initialized
INFO - 2020-07-29 13:57:53 --> Output Class Initialized
INFO - 2020-07-29 13:57:53 --> Security Class Initialized
DEBUG - 2020-07-29 13:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:57:53 --> Input Class Initialized
INFO - 2020-07-29 13:57:53 --> Language Class Initialized
INFO - 2020-07-29 13:57:53 --> Loader Class Initialized
INFO - 2020-07-29 13:57:53 --> Helper loaded: url_helper
INFO - 2020-07-29 13:57:53 --> Database Driver Class Initialized
INFO - 2020-07-29 13:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:57:53 --> Email Class Initialized
INFO - 2020-07-29 13:57:53 --> Controller Class Initialized
DEBUG - 2020-07-29 13:57:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:57:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:57:53 --> Model Class Initialized
INFO - 2020-07-29 13:57:53 --> Model Class Initialized
INFO - 2020-07-29 13:57:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 13:57:53 --> Final output sent to browser
DEBUG - 2020-07-29 13:57:53 --> Total execution time: 0.0214
INFO - 2020-07-29 13:57:55 --> Config Class Initialized
INFO - 2020-07-29 13:57:55 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:57:55 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:57:55 --> Utf8 Class Initialized
INFO - 2020-07-29 13:57:55 --> URI Class Initialized
INFO - 2020-07-29 13:57:55 --> Router Class Initialized
INFO - 2020-07-29 13:57:56 --> Output Class Initialized
INFO - 2020-07-29 13:57:56 --> Security Class Initialized
DEBUG - 2020-07-29 13:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:57:56 --> Input Class Initialized
INFO - 2020-07-29 13:57:56 --> Language Class Initialized
INFO - 2020-07-29 13:57:56 --> Loader Class Initialized
INFO - 2020-07-29 13:57:56 --> Helper loaded: url_helper
INFO - 2020-07-29 13:57:56 --> Database Driver Class Initialized
INFO - 2020-07-29 13:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:57:56 --> Email Class Initialized
INFO - 2020-07-29 13:57:56 --> Controller Class Initialized
DEBUG - 2020-07-29 13:57:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:57:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:57:56 --> Model Class Initialized
INFO - 2020-07-29 13:57:56 --> Model Class Initialized
ERROR - 2020-07-29 13:57:56 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2020-07-29 13:57:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 13:57:56 --> Severity: Error --> Call to a member function dealer_list() on a non-object /home/purpu1ex/public_html/carsm/application/controllers/Admin.php 162
INFO - 2020-07-29 13:58:39 --> Config Class Initialized
INFO - 2020-07-29 13:58:39 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:58:39 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:58:39 --> Utf8 Class Initialized
INFO - 2020-07-29 13:58:39 --> URI Class Initialized
INFO - 2020-07-29 13:58:39 --> Router Class Initialized
INFO - 2020-07-29 13:58:39 --> Output Class Initialized
INFO - 2020-07-29 13:58:39 --> Security Class Initialized
DEBUG - 2020-07-29 13:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:58:39 --> Input Class Initialized
INFO - 2020-07-29 13:58:39 --> Language Class Initialized
INFO - 2020-07-29 13:58:39 --> Loader Class Initialized
INFO - 2020-07-29 13:58:39 --> Helper loaded: url_helper
INFO - 2020-07-29 13:58:39 --> Database Driver Class Initialized
INFO - 2020-07-29 13:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:58:39 --> Email Class Initialized
INFO - 2020-07-29 13:58:39 --> Controller Class Initialized
DEBUG - 2020-07-29 13:58:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:58:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:58:39 --> Model Class Initialized
INFO - 2020-07-29 13:58:39 --> Model Class Initialized
INFO - 2020-07-29 13:58:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 13:58:39 --> Final output sent to browser
DEBUG - 2020-07-29 13:58:39 --> Total execution time: 0.0224
INFO - 2020-07-29 13:58:42 --> Config Class Initialized
INFO - 2020-07-29 13:58:42 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:58:42 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:58:42 --> Utf8 Class Initialized
INFO - 2020-07-29 13:58:42 --> URI Class Initialized
INFO - 2020-07-29 13:58:42 --> Router Class Initialized
INFO - 2020-07-29 13:58:42 --> Output Class Initialized
INFO - 2020-07-29 13:58:42 --> Security Class Initialized
DEBUG - 2020-07-29 13:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:58:42 --> Input Class Initialized
INFO - 2020-07-29 13:58:42 --> Language Class Initialized
INFO - 2020-07-29 13:58:42 --> Loader Class Initialized
INFO - 2020-07-29 13:58:42 --> Helper loaded: url_helper
INFO - 2020-07-29 13:58:42 --> Database Driver Class Initialized
INFO - 2020-07-29 13:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:58:42 --> Email Class Initialized
INFO - 2020-07-29 13:58:42 --> Controller Class Initialized
DEBUG - 2020-07-29 13:58:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:58:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:58:42 --> Model Class Initialized
INFO - 2020-07-29 13:58:42 --> Model Class Initialized
INFO - 2020-07-29 13:58:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 13:58:42 --> Final output sent to browser
DEBUG - 2020-07-29 13:58:42 --> Total execution time: 0.0249
INFO - 2020-07-29 13:58:44 --> Config Class Initialized
INFO - 2020-07-29 13:58:44 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:58:44 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:58:44 --> Utf8 Class Initialized
INFO - 2020-07-29 13:58:44 --> URI Class Initialized
INFO - 2020-07-29 13:58:44 --> Router Class Initialized
INFO - 2020-07-29 13:58:44 --> Output Class Initialized
INFO - 2020-07-29 13:58:44 --> Security Class Initialized
DEBUG - 2020-07-29 13:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:58:44 --> Input Class Initialized
INFO - 2020-07-29 13:58:44 --> Language Class Initialized
INFO - 2020-07-29 13:58:44 --> Loader Class Initialized
INFO - 2020-07-29 13:58:44 --> Helper loaded: url_helper
INFO - 2020-07-29 13:58:44 --> Database Driver Class Initialized
INFO - 2020-07-29 13:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:58:44 --> Email Class Initialized
INFO - 2020-07-29 13:58:44 --> Controller Class Initialized
DEBUG - 2020-07-29 13:58:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:58:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:58:44 --> Model Class Initialized
INFO - 2020-07-29 13:58:44 --> Model Class Initialized
ERROR - 2020-07-29 13:58:44 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
INFO - 2020-07-29 13:58:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 13:58:44 --> Final output sent to browser
DEBUG - 2020-07-29 13:58:44 --> Total execution time: 0.0244
INFO - 2020-07-29 13:58:53 --> Config Class Initialized
INFO - 2020-07-29 13:58:53 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:58:53 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:58:53 --> Utf8 Class Initialized
INFO - 2020-07-29 13:58:53 --> URI Class Initialized
INFO - 2020-07-29 13:58:53 --> Router Class Initialized
INFO - 2020-07-29 13:58:53 --> Output Class Initialized
INFO - 2020-07-29 13:58:53 --> Security Class Initialized
DEBUG - 2020-07-29 13:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:58:53 --> Input Class Initialized
INFO - 2020-07-29 13:58:53 --> Language Class Initialized
INFO - 2020-07-29 13:58:53 --> Loader Class Initialized
INFO - 2020-07-29 13:58:53 --> Helper loaded: url_helper
INFO - 2020-07-29 13:58:53 --> Database Driver Class Initialized
INFO - 2020-07-29 13:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:58:53 --> Email Class Initialized
INFO - 2020-07-29 13:58:53 --> Controller Class Initialized
DEBUG - 2020-07-29 13:58:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:58:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:58:53 --> Model Class Initialized
INFO - 2020-07-29 13:58:53 --> Model Class Initialized
INFO - 2020-07-29 13:58:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 13:58:53 --> Final output sent to browser
DEBUG - 2020-07-29 13:58:53 --> Total execution time: 0.0225
INFO - 2020-07-29 13:58:59 --> Config Class Initialized
INFO - 2020-07-29 13:58:59 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:58:59 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:58:59 --> Utf8 Class Initialized
INFO - 2020-07-29 13:58:59 --> URI Class Initialized
INFO - 2020-07-29 13:58:59 --> Router Class Initialized
INFO - 2020-07-29 13:58:59 --> Output Class Initialized
INFO - 2020-07-29 13:58:59 --> Security Class Initialized
DEBUG - 2020-07-29 13:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:58:59 --> Input Class Initialized
INFO - 2020-07-29 13:58:59 --> Language Class Initialized
INFO - 2020-07-29 13:58:59 --> Loader Class Initialized
INFO - 2020-07-29 13:58:59 --> Helper loaded: url_helper
INFO - 2020-07-29 13:58:59 --> Database Driver Class Initialized
INFO - 2020-07-29 13:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:58:59 --> Email Class Initialized
INFO - 2020-07-29 13:58:59 --> Controller Class Initialized
DEBUG - 2020-07-29 13:58:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:58:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:58:59 --> Model Class Initialized
INFO - 2020-07-29 13:58:59 --> Model Class Initialized
INFO - 2020-07-29 13:58:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-29 13:58:59 --> Final output sent to browser
DEBUG - 2020-07-29 13:58:59 --> Total execution time: 0.0245
INFO - 2020-07-29 13:59:07 --> Config Class Initialized
INFO - 2020-07-29 13:59:07 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:59:07 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:59:07 --> Utf8 Class Initialized
INFO - 2020-07-29 13:59:07 --> URI Class Initialized
INFO - 2020-07-29 13:59:07 --> Router Class Initialized
INFO - 2020-07-29 13:59:07 --> Output Class Initialized
INFO - 2020-07-29 13:59:07 --> Security Class Initialized
DEBUG - 2020-07-29 13:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:59:07 --> Input Class Initialized
INFO - 2020-07-29 13:59:07 --> Language Class Initialized
INFO - 2020-07-29 13:59:07 --> Loader Class Initialized
INFO - 2020-07-29 13:59:07 --> Helper loaded: url_helper
INFO - 2020-07-29 13:59:07 --> Database Driver Class Initialized
INFO - 2020-07-29 13:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:59:07 --> Email Class Initialized
INFO - 2020-07-29 13:59:07 --> Controller Class Initialized
DEBUG - 2020-07-29 13:59:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:59:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:59:07 --> Model Class Initialized
INFO - 2020-07-29 13:59:07 --> Model Class Initialized
INFO - 2020-07-29 13:59:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 13:59:07 --> Final output sent to browser
DEBUG - 2020-07-29 13:59:07 --> Total execution time: 0.0237
INFO - 2020-07-29 13:59:09 --> Config Class Initialized
INFO - 2020-07-29 13:59:09 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:59:09 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:59:09 --> Utf8 Class Initialized
INFO - 2020-07-29 13:59:09 --> URI Class Initialized
INFO - 2020-07-29 13:59:09 --> Router Class Initialized
INFO - 2020-07-29 13:59:09 --> Output Class Initialized
INFO - 2020-07-29 13:59:09 --> Security Class Initialized
DEBUG - 2020-07-29 13:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:59:09 --> Input Class Initialized
INFO - 2020-07-29 13:59:09 --> Language Class Initialized
INFO - 2020-07-29 13:59:09 --> Loader Class Initialized
INFO - 2020-07-29 13:59:09 --> Helper loaded: url_helper
INFO - 2020-07-29 13:59:09 --> Database Driver Class Initialized
INFO - 2020-07-29 13:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:59:09 --> Email Class Initialized
INFO - 2020-07-29 13:59:09 --> Controller Class Initialized
DEBUG - 2020-07-29 13:59:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:59:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:59:09 --> Model Class Initialized
INFO - 2020-07-29 13:59:09 --> Model Class Initialized
INFO - 2020-07-29 13:59:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 13:59:09 --> Final output sent to browser
DEBUG - 2020-07-29 13:59:09 --> Total execution time: 0.0237
INFO - 2020-07-29 13:59:12 --> Config Class Initialized
INFO - 2020-07-29 13:59:12 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:59:12 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:59:12 --> Utf8 Class Initialized
INFO - 2020-07-29 13:59:12 --> URI Class Initialized
INFO - 2020-07-29 13:59:12 --> Router Class Initialized
INFO - 2020-07-29 13:59:12 --> Output Class Initialized
INFO - 2020-07-29 13:59:12 --> Security Class Initialized
DEBUG - 2020-07-29 13:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:59:12 --> Input Class Initialized
INFO - 2020-07-29 13:59:12 --> Language Class Initialized
INFO - 2020-07-29 13:59:12 --> Loader Class Initialized
INFO - 2020-07-29 13:59:12 --> Helper loaded: url_helper
INFO - 2020-07-29 13:59:12 --> Database Driver Class Initialized
INFO - 2020-07-29 13:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:59:12 --> Email Class Initialized
INFO - 2020-07-29 13:59:12 --> Controller Class Initialized
DEBUG - 2020-07-29 13:59:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:59:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:59:12 --> Model Class Initialized
INFO - 2020-07-29 13:59:12 --> Model Class Initialized
INFO - 2020-07-29 13:59:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 13:59:12 --> Final output sent to browser
DEBUG - 2020-07-29 13:59:12 --> Total execution time: 0.0253
INFO - 2020-07-29 13:59:17 --> Config Class Initialized
INFO - 2020-07-29 13:59:17 --> Hooks Class Initialized
DEBUG - 2020-07-29 13:59:17 --> UTF-8 Support Enabled
INFO - 2020-07-29 13:59:17 --> Utf8 Class Initialized
INFO - 2020-07-29 13:59:17 --> URI Class Initialized
INFO - 2020-07-29 13:59:17 --> Router Class Initialized
INFO - 2020-07-29 13:59:17 --> Output Class Initialized
INFO - 2020-07-29 13:59:17 --> Security Class Initialized
DEBUG - 2020-07-29 13:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 13:59:17 --> Input Class Initialized
INFO - 2020-07-29 13:59:17 --> Language Class Initialized
INFO - 2020-07-29 13:59:17 --> Loader Class Initialized
INFO - 2020-07-29 13:59:17 --> Helper loaded: url_helper
INFO - 2020-07-29 13:59:17 --> Database Driver Class Initialized
INFO - 2020-07-29 13:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 13:59:17 --> Email Class Initialized
INFO - 2020-07-29 13:59:17 --> Controller Class Initialized
DEBUG - 2020-07-29 13:59:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 13:59:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 13:59:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 13:59:17 --> Final output sent to browser
DEBUG - 2020-07-29 13:59:17 --> Total execution time: 0.0236
INFO - 2020-07-29 14:02:26 --> Config Class Initialized
INFO - 2020-07-29 14:02:26 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:02:26 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:02:26 --> Utf8 Class Initialized
INFO - 2020-07-29 14:02:26 --> URI Class Initialized
INFO - 2020-07-29 14:02:26 --> Router Class Initialized
INFO - 2020-07-29 14:02:26 --> Output Class Initialized
INFO - 2020-07-29 14:02:26 --> Security Class Initialized
DEBUG - 2020-07-29 14:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:02:26 --> Input Class Initialized
INFO - 2020-07-29 14:02:26 --> Language Class Initialized
INFO - 2020-07-29 14:02:26 --> Loader Class Initialized
INFO - 2020-07-29 14:02:26 --> Helper loaded: url_helper
INFO - 2020-07-29 14:02:26 --> Database Driver Class Initialized
INFO - 2020-07-29 14:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:02:26 --> Email Class Initialized
INFO - 2020-07-29 14:02:26 --> Controller Class Initialized
DEBUG - 2020-07-29 14:02:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 14:02:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:02:26 --> Model Class Initialized
INFO - 2020-07-29 14:02:26 --> Model Class Initialized
INFO - 2020-07-29 14:02:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 14:02:26 --> Final output sent to browser
DEBUG - 2020-07-29 14:02:26 --> Total execution time: 0.0348
INFO - 2020-07-29 14:02:27 --> Config Class Initialized
INFO - 2020-07-29 14:02:27 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:02:27 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:02:27 --> Utf8 Class Initialized
INFO - 2020-07-29 14:02:27 --> URI Class Initialized
INFO - 2020-07-29 14:02:27 --> Router Class Initialized
INFO - 2020-07-29 14:02:27 --> Output Class Initialized
INFO - 2020-07-29 14:02:27 --> Security Class Initialized
DEBUG - 2020-07-29 14:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:02:27 --> Input Class Initialized
INFO - 2020-07-29 14:02:27 --> Language Class Initialized
INFO - 2020-07-29 14:02:27 --> Loader Class Initialized
INFO - 2020-07-29 14:02:27 --> Helper loaded: url_helper
INFO - 2020-07-29 14:02:27 --> Database Driver Class Initialized
INFO - 2020-07-29 14:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:02:27 --> Email Class Initialized
INFO - 2020-07-29 14:02:27 --> Controller Class Initialized
DEBUG - 2020-07-29 14:02:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 14:02:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:02:27 --> Model Class Initialized
INFO - 2020-07-29 14:02:27 --> Model Class Initialized
INFO - 2020-07-29 14:02:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-29 14:02:27 --> Final output sent to browser
DEBUG - 2020-07-29 14:02:27 --> Total execution time: 0.0208
INFO - 2020-07-29 14:02:31 --> Config Class Initialized
INFO - 2020-07-29 14:02:31 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:02:31 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:02:31 --> Utf8 Class Initialized
INFO - 2020-07-29 14:02:31 --> URI Class Initialized
INFO - 2020-07-29 14:02:31 --> Router Class Initialized
INFO - 2020-07-29 14:02:31 --> Output Class Initialized
INFO - 2020-07-29 14:02:31 --> Security Class Initialized
DEBUG - 2020-07-29 14:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:02:31 --> Input Class Initialized
INFO - 2020-07-29 14:02:31 --> Language Class Initialized
INFO - 2020-07-29 14:02:31 --> Loader Class Initialized
INFO - 2020-07-29 14:02:31 --> Helper loaded: url_helper
INFO - 2020-07-29 14:02:31 --> Database Driver Class Initialized
INFO - 2020-07-29 14:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:02:31 --> Email Class Initialized
INFO - 2020-07-29 14:02:31 --> Controller Class Initialized
DEBUG - 2020-07-29 14:02:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 14:02:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:02:31 --> Model Class Initialized
INFO - 2020-07-29 14:02:31 --> Model Class Initialized
INFO - 2020-07-29 14:02:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 14:02:31 --> Final output sent to browser
DEBUG - 2020-07-29 14:02:31 --> Total execution time: 0.0209
INFO - 2020-07-29 14:02:35 --> Config Class Initialized
INFO - 2020-07-29 14:02:35 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:02:35 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:02:35 --> Utf8 Class Initialized
INFO - 2020-07-29 14:02:35 --> URI Class Initialized
INFO - 2020-07-29 14:02:35 --> Router Class Initialized
INFO - 2020-07-29 14:02:35 --> Output Class Initialized
INFO - 2020-07-29 14:02:35 --> Security Class Initialized
DEBUG - 2020-07-29 14:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:02:35 --> Input Class Initialized
INFO - 2020-07-29 14:02:35 --> Language Class Initialized
INFO - 2020-07-29 14:02:35 --> Loader Class Initialized
INFO - 2020-07-29 14:02:35 --> Helper loaded: url_helper
INFO - 2020-07-29 14:02:35 --> Database Driver Class Initialized
INFO - 2020-07-29 14:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:02:35 --> Email Class Initialized
INFO - 2020-07-29 14:02:35 --> Controller Class Initialized
DEBUG - 2020-07-29 14:02:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 14:02:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:02:35 --> Model Class Initialized
INFO - 2020-07-29 14:02:35 --> Model Class Initialized
INFO - 2020-07-29 14:02:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 14:02:35 --> Final output sent to browser
DEBUG - 2020-07-29 14:02:35 --> Total execution time: 0.0264
INFO - 2020-07-29 14:02:37 --> Config Class Initialized
INFO - 2020-07-29 14:02:37 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:02:37 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:02:37 --> Utf8 Class Initialized
INFO - 2020-07-29 14:02:37 --> URI Class Initialized
INFO - 2020-07-29 14:02:37 --> Router Class Initialized
INFO - 2020-07-29 14:02:37 --> Output Class Initialized
INFO - 2020-07-29 14:02:37 --> Security Class Initialized
DEBUG - 2020-07-29 14:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:02:37 --> Input Class Initialized
INFO - 2020-07-29 14:02:37 --> Language Class Initialized
INFO - 2020-07-29 14:02:37 --> Loader Class Initialized
INFO - 2020-07-29 14:02:37 --> Helper loaded: url_helper
INFO - 2020-07-29 14:02:37 --> Database Driver Class Initialized
INFO - 2020-07-29 14:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:02:37 --> Email Class Initialized
INFO - 2020-07-29 14:02:37 --> Controller Class Initialized
DEBUG - 2020-07-29 14:02:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 14:02:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:02:37 --> Model Class Initialized
INFO - 2020-07-29 14:02:37 --> Model Class Initialized
ERROR - 2020-07-29 14:02:37 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
INFO - 2020-07-29 14:02:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 14:02:37 --> Final output sent to browser
DEBUG - 2020-07-29 14:02:37 --> Total execution time: 0.0224
INFO - 2020-07-29 14:06:50 --> Config Class Initialized
INFO - 2020-07-29 14:06:50 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:06:50 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:06:50 --> Utf8 Class Initialized
INFO - 2020-07-29 14:06:50 --> URI Class Initialized
INFO - 2020-07-29 14:06:50 --> Router Class Initialized
INFO - 2020-07-29 14:06:50 --> Output Class Initialized
INFO - 2020-07-29 14:06:50 --> Security Class Initialized
DEBUG - 2020-07-29 14:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:06:50 --> Input Class Initialized
INFO - 2020-07-29 14:06:50 --> Language Class Initialized
INFO - 2020-07-29 14:06:50 --> Loader Class Initialized
INFO - 2020-07-29 14:06:50 --> Helper loaded: url_helper
INFO - 2020-07-29 14:06:50 --> Database Driver Class Initialized
INFO - 2020-07-29 14:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:06:50 --> Email Class Initialized
INFO - 2020-07-29 14:06:50 --> Controller Class Initialized
DEBUG - 2020-07-29 14:06:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 14:06:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:06:50 --> Model Class Initialized
INFO - 2020-07-29 14:06:50 --> Model Class Initialized
INFO - 2020-07-29 14:06:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 14:06:50 --> Final output sent to browser
DEBUG - 2020-07-29 14:06:50 --> Total execution time: 0.0429
INFO - 2020-07-29 14:06:54 --> Config Class Initialized
INFO - 2020-07-29 14:06:54 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:06:54 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:06:54 --> Utf8 Class Initialized
INFO - 2020-07-29 14:06:54 --> URI Class Initialized
INFO - 2020-07-29 14:06:54 --> Router Class Initialized
INFO - 2020-07-29 14:06:54 --> Output Class Initialized
INFO - 2020-07-29 14:06:54 --> Security Class Initialized
DEBUG - 2020-07-29 14:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:06:54 --> Input Class Initialized
INFO - 2020-07-29 14:06:54 --> Language Class Initialized
INFO - 2020-07-29 14:06:54 --> Loader Class Initialized
INFO - 2020-07-29 14:06:54 --> Helper loaded: url_helper
INFO - 2020-07-29 14:06:54 --> Database Driver Class Initialized
INFO - 2020-07-29 14:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:06:54 --> Email Class Initialized
INFO - 2020-07-29 14:06:54 --> Controller Class Initialized
DEBUG - 2020-07-29 14:06:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 14:06:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:06:54 --> Model Class Initialized
INFO - 2020-07-29 14:06:54 --> Model Class Initialized
INFO - 2020-07-29 14:06:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 14:06:54 --> Final output sent to browser
DEBUG - 2020-07-29 14:06:54 --> Total execution time: 0.0242
INFO - 2020-07-29 14:07:11 --> Config Class Initialized
INFO - 2020-07-29 14:07:11 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:07:11 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:07:11 --> Utf8 Class Initialized
INFO - 2020-07-29 14:07:11 --> URI Class Initialized
DEBUG - 2020-07-29 14:07:11 --> No URI present. Default controller set.
INFO - 2020-07-29 14:07:11 --> Router Class Initialized
INFO - 2020-07-29 14:07:11 --> Output Class Initialized
INFO - 2020-07-29 14:07:11 --> Security Class Initialized
DEBUG - 2020-07-29 14:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:07:11 --> Input Class Initialized
INFO - 2020-07-29 14:07:11 --> Language Class Initialized
INFO - 2020-07-29 14:07:11 --> Loader Class Initialized
INFO - 2020-07-29 14:07:11 --> Helper loaded: url_helper
INFO - 2020-07-29 14:07:11 --> Database Driver Class Initialized
INFO - 2020-07-29 14:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:07:11 --> Email Class Initialized
INFO - 2020-07-29 14:07:11 --> Controller Class Initialized
INFO - 2020-07-29 14:07:11 --> Model Class Initialized
INFO - 2020-07-29 14:07:11 --> Model Class Initialized
DEBUG - 2020-07-29 14:07:11 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:07:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 14:07:11 --> Final output sent to browser
DEBUG - 2020-07-29 14:07:11 --> Total execution time: 0.0209
INFO - 2020-07-29 14:07:14 --> Config Class Initialized
INFO - 2020-07-29 14:07:14 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:07:14 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:07:14 --> Utf8 Class Initialized
INFO - 2020-07-29 14:07:14 --> URI Class Initialized
INFO - 2020-07-29 14:07:14 --> Router Class Initialized
INFO - 2020-07-29 14:07:14 --> Output Class Initialized
INFO - 2020-07-29 14:07:14 --> Security Class Initialized
DEBUG - 2020-07-29 14:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:07:14 --> Input Class Initialized
INFO - 2020-07-29 14:07:14 --> Language Class Initialized
INFO - 2020-07-29 14:07:14 --> Loader Class Initialized
INFO - 2020-07-29 14:07:14 --> Helper loaded: url_helper
INFO - 2020-07-29 14:07:14 --> Database Driver Class Initialized
INFO - 2020-07-29 14:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:07:14 --> Email Class Initialized
INFO - 2020-07-29 14:07:14 --> Controller Class Initialized
INFO - 2020-07-29 14:07:14 --> Model Class Initialized
INFO - 2020-07-29 14:07:14 --> Model Class Initialized
DEBUG - 2020-07-29 14:07:14 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:07:14 --> Config Class Initialized
INFO - 2020-07-29 14:07:14 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:07:14 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:07:14 --> Utf8 Class Initialized
INFO - 2020-07-29 14:07:14 --> URI Class Initialized
INFO - 2020-07-29 14:07:14 --> Router Class Initialized
INFO - 2020-07-29 14:07:14 --> Output Class Initialized
INFO - 2020-07-29 14:07:14 --> Security Class Initialized
DEBUG - 2020-07-29 14:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:07:14 --> Input Class Initialized
INFO - 2020-07-29 14:07:14 --> Language Class Initialized
INFO - 2020-07-29 14:07:14 --> Loader Class Initialized
INFO - 2020-07-29 14:07:14 --> Helper loaded: url_helper
INFO - 2020-07-29 14:07:14 --> Database Driver Class Initialized
INFO - 2020-07-29 14:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:07:14 --> Email Class Initialized
INFO - 2020-07-29 14:07:14 --> Controller Class Initialized
DEBUG - 2020-07-29 14:07:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 14:07:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:07:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 14:07:14 --> Final output sent to browser
DEBUG - 2020-07-29 14:07:14 --> Total execution time: 0.0214
INFO - 2020-07-29 14:07:17 --> Config Class Initialized
INFO - 2020-07-29 14:07:17 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:07:17 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:07:17 --> Utf8 Class Initialized
INFO - 2020-07-29 14:07:17 --> URI Class Initialized
INFO - 2020-07-29 14:07:17 --> Router Class Initialized
INFO - 2020-07-29 14:07:17 --> Output Class Initialized
INFO - 2020-07-29 14:07:17 --> Security Class Initialized
DEBUG - 2020-07-29 14:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:07:17 --> Input Class Initialized
INFO - 2020-07-29 14:07:17 --> Language Class Initialized
INFO - 2020-07-29 14:07:17 --> Loader Class Initialized
INFO - 2020-07-29 14:07:17 --> Helper loaded: url_helper
INFO - 2020-07-29 14:07:17 --> Database Driver Class Initialized
INFO - 2020-07-29 14:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:07:17 --> Email Class Initialized
INFO - 2020-07-29 14:07:17 --> Controller Class Initialized
DEBUG - 2020-07-29 14:07:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 14:07:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:07:17 --> Model Class Initialized
INFO - 2020-07-29 14:07:17 --> Model Class Initialized
INFO - 2020-07-29 14:07:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 14:07:17 --> Final output sent to browser
DEBUG - 2020-07-29 14:07:17 --> Total execution time: 0.0234
INFO - 2020-07-29 14:07:20 --> Config Class Initialized
INFO - 2020-07-29 14:07:20 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:07:20 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:07:20 --> Utf8 Class Initialized
INFO - 2020-07-29 14:07:20 --> URI Class Initialized
INFO - 2020-07-29 14:07:20 --> Router Class Initialized
INFO - 2020-07-29 14:07:20 --> Output Class Initialized
INFO - 2020-07-29 14:07:20 --> Security Class Initialized
DEBUG - 2020-07-29 14:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:07:20 --> Input Class Initialized
INFO - 2020-07-29 14:07:20 --> Language Class Initialized
INFO - 2020-07-29 14:07:20 --> Loader Class Initialized
INFO - 2020-07-29 14:07:20 --> Helper loaded: url_helper
INFO - 2020-07-29 14:07:20 --> Database Driver Class Initialized
INFO - 2020-07-29 14:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:07:20 --> Email Class Initialized
INFO - 2020-07-29 14:07:20 --> Controller Class Initialized
DEBUG - 2020-07-29 14:07:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 14:07:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:07:20 --> Model Class Initialized
INFO - 2020-07-29 14:07:20 --> Model Class Initialized
INFO - 2020-07-29 14:07:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 14:07:20 --> Final output sent to browser
DEBUG - 2020-07-29 14:07:20 --> Total execution time: 0.0241
INFO - 2020-07-29 14:07:22 --> Config Class Initialized
INFO - 2020-07-29 14:07:22 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:07:22 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:07:22 --> Utf8 Class Initialized
INFO - 2020-07-29 14:07:22 --> URI Class Initialized
INFO - 2020-07-29 14:07:22 --> Router Class Initialized
INFO - 2020-07-29 14:07:22 --> Output Class Initialized
INFO - 2020-07-29 14:07:22 --> Security Class Initialized
DEBUG - 2020-07-29 14:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:07:22 --> Input Class Initialized
INFO - 2020-07-29 14:07:22 --> Language Class Initialized
INFO - 2020-07-29 14:07:22 --> Loader Class Initialized
INFO - 2020-07-29 14:07:22 --> Helper loaded: url_helper
INFO - 2020-07-29 14:07:22 --> Database Driver Class Initialized
INFO - 2020-07-29 14:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:07:22 --> Email Class Initialized
INFO - 2020-07-29 14:07:22 --> Controller Class Initialized
DEBUG - 2020-07-29 14:07:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 14:07:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:07:22 --> Model Class Initialized
INFO - 2020-07-29 14:07:22 --> Model Class Initialized
INFO - 2020-07-29 14:07:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 14:07:22 --> Final output sent to browser
DEBUG - 2020-07-29 14:07:22 --> Total execution time: 0.0266
INFO - 2020-07-29 14:07:59 --> Config Class Initialized
INFO - 2020-07-29 14:07:59 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:07:59 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:07:59 --> Utf8 Class Initialized
INFO - 2020-07-29 14:07:59 --> URI Class Initialized
INFO - 2020-07-29 14:07:59 --> Router Class Initialized
INFO - 2020-07-29 14:07:59 --> Output Class Initialized
INFO - 2020-07-29 14:07:59 --> Security Class Initialized
DEBUG - 2020-07-29 14:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:07:59 --> Input Class Initialized
INFO - 2020-07-29 14:07:59 --> Language Class Initialized
INFO - 2020-07-29 14:07:59 --> Loader Class Initialized
INFO - 2020-07-29 14:07:59 --> Helper loaded: url_helper
INFO - 2020-07-29 14:07:59 --> Database Driver Class Initialized
INFO - 2020-07-29 14:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:07:59 --> Email Class Initialized
INFO - 2020-07-29 14:07:59 --> Controller Class Initialized
DEBUG - 2020-07-29 14:07:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 14:07:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:07:59 --> Model Class Initialized
INFO - 2020-07-29 14:07:59 --> Model Class Initialized
INFO - 2020-07-29 14:07:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 14:07:59 --> Final output sent to browser
DEBUG - 2020-07-29 14:07:59 --> Total execution time: 0.0217
INFO - 2020-07-29 14:08:01 --> Config Class Initialized
INFO - 2020-07-29 14:08:01 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:08:01 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:08:01 --> Utf8 Class Initialized
INFO - 2020-07-29 14:08:01 --> URI Class Initialized
INFO - 2020-07-29 14:08:01 --> Router Class Initialized
INFO - 2020-07-29 14:08:01 --> Output Class Initialized
INFO - 2020-07-29 14:08:01 --> Security Class Initialized
DEBUG - 2020-07-29 14:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:08:01 --> Input Class Initialized
INFO - 2020-07-29 14:08:01 --> Language Class Initialized
INFO - 2020-07-29 14:08:01 --> Loader Class Initialized
INFO - 2020-07-29 14:08:01 --> Helper loaded: url_helper
INFO - 2020-07-29 14:08:01 --> Database Driver Class Initialized
INFO - 2020-07-29 14:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:08:01 --> Email Class Initialized
INFO - 2020-07-29 14:08:01 --> Controller Class Initialized
DEBUG - 2020-07-29 14:08:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 14:08:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:08:01 --> Model Class Initialized
INFO - 2020-07-29 14:08:01 --> Model Class Initialized
INFO - 2020-07-29 14:08:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 14:08:01 --> Final output sent to browser
DEBUG - 2020-07-29 14:08:01 --> Total execution time: 0.0236
INFO - 2020-07-29 14:08:03 --> Config Class Initialized
INFO - 2020-07-29 14:08:03 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:08:03 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:08:03 --> Utf8 Class Initialized
INFO - 2020-07-29 14:08:03 --> URI Class Initialized
INFO - 2020-07-29 14:08:03 --> Router Class Initialized
INFO - 2020-07-29 14:08:03 --> Output Class Initialized
INFO - 2020-07-29 14:08:03 --> Security Class Initialized
DEBUG - 2020-07-29 14:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:08:03 --> Input Class Initialized
INFO - 2020-07-29 14:08:03 --> Language Class Initialized
INFO - 2020-07-29 14:08:03 --> Loader Class Initialized
INFO - 2020-07-29 14:08:03 --> Helper loaded: url_helper
INFO - 2020-07-29 14:08:03 --> Database Driver Class Initialized
INFO - 2020-07-29 14:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:08:03 --> Email Class Initialized
INFO - 2020-07-29 14:08:03 --> Controller Class Initialized
DEBUG - 2020-07-29 14:08:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 14:08:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:08:03 --> Model Class Initialized
INFO - 2020-07-29 14:08:03 --> Model Class Initialized
ERROR - 2020-07-29 14:08:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/Admin_model.php:47) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 14:08:03 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::next_result() /home/purpu1ex/public_html/carsm/application/models/Admin_model.php 47
INFO - 2020-07-29 14:08:48 --> Config Class Initialized
INFO - 2020-07-29 14:08:48 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:08:48 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:08:48 --> Utf8 Class Initialized
INFO - 2020-07-29 14:08:48 --> URI Class Initialized
INFO - 2020-07-29 14:08:48 --> Router Class Initialized
INFO - 2020-07-29 14:08:48 --> Output Class Initialized
INFO - 2020-07-29 14:08:48 --> Security Class Initialized
DEBUG - 2020-07-29 14:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:08:48 --> Input Class Initialized
INFO - 2020-07-29 14:08:48 --> Language Class Initialized
INFO - 2020-07-29 14:08:48 --> Loader Class Initialized
INFO - 2020-07-29 14:08:48 --> Helper loaded: url_helper
INFO - 2020-07-29 14:08:48 --> Database Driver Class Initialized
INFO - 2020-07-29 14:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:08:48 --> Email Class Initialized
INFO - 2020-07-29 14:08:48 --> Controller Class Initialized
DEBUG - 2020-07-29 14:08:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 14:08:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:08:48 --> Model Class Initialized
INFO - 2020-07-29 14:08:48 --> Model Class Initialized
INFO - 2020-07-29 14:08:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 14:08:48 --> Final output sent to browser
DEBUG - 2020-07-29 14:08:48 --> Total execution time: 0.0236
INFO - 2020-07-29 14:08:51 --> Config Class Initialized
INFO - 2020-07-29 14:08:51 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:08:51 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:08:51 --> Utf8 Class Initialized
INFO - 2020-07-29 14:08:51 --> URI Class Initialized
INFO - 2020-07-29 14:08:51 --> Router Class Initialized
INFO - 2020-07-29 14:08:51 --> Output Class Initialized
INFO - 2020-07-29 14:08:51 --> Security Class Initialized
DEBUG - 2020-07-29 14:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:08:51 --> Input Class Initialized
INFO - 2020-07-29 14:08:51 --> Language Class Initialized
INFO - 2020-07-29 14:08:51 --> Loader Class Initialized
INFO - 2020-07-29 14:08:51 --> Helper loaded: url_helper
INFO - 2020-07-29 14:08:51 --> Database Driver Class Initialized
INFO - 2020-07-29 14:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:08:51 --> Email Class Initialized
INFO - 2020-07-29 14:08:51 --> Controller Class Initialized
DEBUG - 2020-07-29 14:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 14:08:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:08:51 --> Model Class Initialized
INFO - 2020-07-29 14:08:51 --> Model Class Initialized
INFO - 2020-07-29 14:08:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 14:08:51 --> Final output sent to browser
DEBUG - 2020-07-29 14:08:51 --> Total execution time: 0.0214
INFO - 2020-07-29 14:08:53 --> Config Class Initialized
INFO - 2020-07-29 14:08:53 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:08:53 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:08:53 --> Utf8 Class Initialized
INFO - 2020-07-29 14:08:53 --> URI Class Initialized
INFO - 2020-07-29 14:08:53 --> Router Class Initialized
INFO - 2020-07-29 14:08:53 --> Output Class Initialized
INFO - 2020-07-29 14:08:53 --> Security Class Initialized
DEBUG - 2020-07-29 14:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:08:53 --> Input Class Initialized
INFO - 2020-07-29 14:08:53 --> Language Class Initialized
INFO - 2020-07-29 14:08:53 --> Loader Class Initialized
INFO - 2020-07-29 14:08:53 --> Helper loaded: url_helper
INFO - 2020-07-29 14:08:53 --> Database Driver Class Initialized
INFO - 2020-07-29 14:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:08:53 --> Email Class Initialized
INFO - 2020-07-29 14:08:53 --> Controller Class Initialized
DEBUG - 2020-07-29 14:08:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 14:08:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:08:53 --> Model Class Initialized
INFO - 2020-07-29 14:08:53 --> Model Class Initialized
INFO - 2020-07-29 14:08:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 14:08:53 --> Final output sent to browser
DEBUG - 2020-07-29 14:08:53 --> Total execution time: 0.0232
INFO - 2020-07-29 14:08:59 --> Config Class Initialized
INFO - 2020-07-29 14:08:59 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:08:59 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:08:59 --> Utf8 Class Initialized
INFO - 2020-07-29 14:08:59 --> URI Class Initialized
INFO - 2020-07-29 14:08:59 --> Router Class Initialized
INFO - 2020-07-29 14:08:59 --> Output Class Initialized
INFO - 2020-07-29 14:08:59 --> Security Class Initialized
DEBUG - 2020-07-29 14:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:08:59 --> Input Class Initialized
INFO - 2020-07-29 14:08:59 --> Language Class Initialized
INFO - 2020-07-29 14:08:59 --> Loader Class Initialized
INFO - 2020-07-29 14:08:59 --> Helper loaded: url_helper
INFO - 2020-07-29 14:08:59 --> Database Driver Class Initialized
INFO - 2020-07-29 14:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:08:59 --> Email Class Initialized
INFO - 2020-07-29 14:08:59 --> Controller Class Initialized
DEBUG - 2020-07-29 14:08:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 14:08:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:08:59 --> Model Class Initialized
INFO - 2020-07-29 14:08:59 --> Model Class Initialized
INFO - 2020-07-29 14:08:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-29 14:08:59 --> Final output sent to browser
DEBUG - 2020-07-29 14:08:59 --> Total execution time: 0.0219
INFO - 2020-07-29 14:09:23 --> Config Class Initialized
INFO - 2020-07-29 14:09:23 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:09:23 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:09:23 --> Utf8 Class Initialized
INFO - 2020-07-29 14:09:23 --> URI Class Initialized
INFO - 2020-07-29 14:09:23 --> Router Class Initialized
INFO - 2020-07-29 14:09:23 --> Output Class Initialized
INFO - 2020-07-29 14:09:23 --> Security Class Initialized
DEBUG - 2020-07-29 14:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:09:23 --> Input Class Initialized
INFO - 2020-07-29 14:09:23 --> Language Class Initialized
INFO - 2020-07-29 14:09:23 --> Loader Class Initialized
INFO - 2020-07-29 14:09:23 --> Helper loaded: url_helper
INFO - 2020-07-29 14:09:23 --> Database Driver Class Initialized
INFO - 2020-07-29 14:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:09:23 --> Email Class Initialized
INFO - 2020-07-29 14:09:23 --> Controller Class Initialized
DEBUG - 2020-07-29 14:09:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 14:09:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:09:23 --> Model Class Initialized
INFO - 2020-07-29 14:09:23 --> Model Class Initialized
INFO - 2020-07-29 14:09:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 14:09:23 --> Final output sent to browser
DEBUG - 2020-07-29 14:09:23 --> Total execution time: 0.0225
INFO - 2020-07-29 14:09:48 --> Config Class Initialized
INFO - 2020-07-29 14:09:48 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:09:48 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:09:48 --> Utf8 Class Initialized
INFO - 2020-07-29 14:09:48 --> URI Class Initialized
INFO - 2020-07-29 14:09:48 --> Router Class Initialized
INFO - 2020-07-29 14:09:48 --> Output Class Initialized
INFO - 2020-07-29 14:09:48 --> Security Class Initialized
DEBUG - 2020-07-29 14:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:09:48 --> Input Class Initialized
INFO - 2020-07-29 14:09:48 --> Language Class Initialized
INFO - 2020-07-29 14:09:48 --> Loader Class Initialized
INFO - 2020-07-29 14:09:48 --> Helper loaded: url_helper
INFO - 2020-07-29 14:09:48 --> Database Driver Class Initialized
INFO - 2020-07-29 14:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:09:48 --> Email Class Initialized
INFO - 2020-07-29 14:09:48 --> Controller Class Initialized
DEBUG - 2020-07-29 14:09:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 14:09:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:09:48 --> Model Class Initialized
INFO - 2020-07-29 14:09:48 --> Model Class Initialized
INFO - 2020-07-29 14:09:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-07-29 14:09:48 --> Final output sent to browser
DEBUG - 2020-07-29 14:09:48 --> Total execution time: 0.0229
INFO - 2020-07-29 14:09:51 --> Config Class Initialized
INFO - 2020-07-29 14:09:51 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:09:51 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:09:51 --> Utf8 Class Initialized
INFO - 2020-07-29 14:09:51 --> URI Class Initialized
INFO - 2020-07-29 14:09:51 --> Router Class Initialized
INFO - 2020-07-29 14:09:51 --> Output Class Initialized
INFO - 2020-07-29 14:09:51 --> Security Class Initialized
DEBUG - 2020-07-29 14:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:09:51 --> Input Class Initialized
INFO - 2020-07-29 14:09:51 --> Language Class Initialized
INFO - 2020-07-29 14:09:51 --> Loader Class Initialized
INFO - 2020-07-29 14:09:51 --> Helper loaded: url_helper
INFO - 2020-07-29 14:09:51 --> Database Driver Class Initialized
INFO - 2020-07-29 14:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:09:51 --> Email Class Initialized
INFO - 2020-07-29 14:09:51 --> Controller Class Initialized
DEBUG - 2020-07-29 14:09:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 14:09:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:09:51 --> Model Class Initialized
INFO - 2020-07-29 14:09:51 --> Model Class Initialized
INFO - 2020-07-29 14:09:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 14:09:51 --> Final output sent to browser
DEBUG - 2020-07-29 14:09:51 --> Total execution time: 0.0216
INFO - 2020-07-29 14:10:09 --> Config Class Initialized
INFO - 2020-07-29 14:10:09 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:10:09 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:10:09 --> Utf8 Class Initialized
INFO - 2020-07-29 14:10:09 --> URI Class Initialized
DEBUG - 2020-07-29 14:10:09 --> No URI present. Default controller set.
INFO - 2020-07-29 14:10:09 --> Router Class Initialized
INFO - 2020-07-29 14:10:09 --> Output Class Initialized
INFO - 2020-07-29 14:10:09 --> Security Class Initialized
DEBUG - 2020-07-29 14:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:10:09 --> Input Class Initialized
INFO - 2020-07-29 14:10:09 --> Language Class Initialized
INFO - 2020-07-29 14:10:09 --> Loader Class Initialized
INFO - 2020-07-29 14:10:09 --> Helper loaded: url_helper
INFO - 2020-07-29 14:10:09 --> Database Driver Class Initialized
INFO - 2020-07-29 14:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:10:09 --> Email Class Initialized
INFO - 2020-07-29 14:10:09 --> Controller Class Initialized
INFO - 2020-07-29 14:10:09 --> Model Class Initialized
INFO - 2020-07-29 14:10:09 --> Model Class Initialized
DEBUG - 2020-07-29 14:10:09 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:10:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 14:10:09 --> Final output sent to browser
DEBUG - 2020-07-29 14:10:09 --> Total execution time: 0.0218
INFO - 2020-07-29 14:13:11 --> Config Class Initialized
INFO - 2020-07-29 14:13:11 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:13:11 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:13:11 --> Utf8 Class Initialized
INFO - 2020-07-29 14:13:11 --> URI Class Initialized
DEBUG - 2020-07-29 14:13:11 --> No URI present. Default controller set.
INFO - 2020-07-29 14:13:11 --> Router Class Initialized
INFO - 2020-07-29 14:13:11 --> Output Class Initialized
INFO - 2020-07-29 14:13:11 --> Security Class Initialized
DEBUG - 2020-07-29 14:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:13:11 --> Input Class Initialized
INFO - 2020-07-29 14:13:11 --> Language Class Initialized
INFO - 2020-07-29 14:13:11 --> Loader Class Initialized
INFO - 2020-07-29 14:13:11 --> Helper loaded: url_helper
INFO - 2020-07-29 14:13:11 --> Database Driver Class Initialized
INFO - 2020-07-29 14:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:13:11 --> Email Class Initialized
INFO - 2020-07-29 14:13:11 --> Controller Class Initialized
INFO - 2020-07-29 14:13:11 --> Model Class Initialized
INFO - 2020-07-29 14:13:11 --> Model Class Initialized
DEBUG - 2020-07-29 14:13:11 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:13:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 14:13:11 --> Final output sent to browser
DEBUG - 2020-07-29 14:13:11 --> Total execution time: 0.0278
INFO - 2020-07-29 14:13:14 --> Config Class Initialized
INFO - 2020-07-29 14:13:14 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:13:14 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:13:14 --> Utf8 Class Initialized
INFO - 2020-07-29 14:13:14 --> URI Class Initialized
INFO - 2020-07-29 14:13:14 --> Router Class Initialized
INFO - 2020-07-29 14:13:14 --> Output Class Initialized
INFO - 2020-07-29 14:13:14 --> Security Class Initialized
DEBUG - 2020-07-29 14:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:13:14 --> Input Class Initialized
INFO - 2020-07-29 14:13:14 --> Language Class Initialized
INFO - 2020-07-29 14:13:14 --> Loader Class Initialized
INFO - 2020-07-29 14:13:14 --> Helper loaded: url_helper
INFO - 2020-07-29 14:13:14 --> Database Driver Class Initialized
INFO - 2020-07-29 14:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:13:14 --> Email Class Initialized
INFO - 2020-07-29 14:13:14 --> Controller Class Initialized
INFO - 2020-07-29 14:13:14 --> Model Class Initialized
INFO - 2020-07-29 14:13:14 --> Model Class Initialized
DEBUG - 2020-07-29 14:13:14 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:13:15 --> Config Class Initialized
INFO - 2020-07-29 14:13:15 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:13:15 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:13:15 --> Utf8 Class Initialized
INFO - 2020-07-29 14:13:15 --> URI Class Initialized
INFO - 2020-07-29 14:13:15 --> Router Class Initialized
INFO - 2020-07-29 14:13:15 --> Output Class Initialized
INFO - 2020-07-29 14:13:15 --> Security Class Initialized
DEBUG - 2020-07-29 14:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:13:15 --> Input Class Initialized
INFO - 2020-07-29 14:13:15 --> Language Class Initialized
INFO - 2020-07-29 14:13:15 --> Loader Class Initialized
INFO - 2020-07-29 14:13:15 --> Helper loaded: url_helper
INFO - 2020-07-29 14:13:15 --> Database Driver Class Initialized
INFO - 2020-07-29 14:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:13:15 --> Email Class Initialized
INFO - 2020-07-29 14:13:15 --> Controller Class Initialized
DEBUG - 2020-07-29 14:13:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 14:13:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:13:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 14:13:15 --> Final output sent to browser
DEBUG - 2020-07-29 14:13:15 --> Total execution time: 0.0211
INFO - 2020-07-29 14:15:26 --> Config Class Initialized
INFO - 2020-07-29 14:15:26 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:15:26 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:15:26 --> Utf8 Class Initialized
INFO - 2020-07-29 14:15:26 --> URI Class Initialized
INFO - 2020-07-29 14:15:26 --> Router Class Initialized
INFO - 2020-07-29 14:15:26 --> Output Class Initialized
INFO - 2020-07-29 14:15:26 --> Security Class Initialized
DEBUG - 2020-07-29 14:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:15:26 --> Input Class Initialized
INFO - 2020-07-29 14:15:26 --> Language Class Initialized
INFO - 2020-07-29 14:15:26 --> Loader Class Initialized
INFO - 2020-07-29 14:15:26 --> Helper loaded: url_helper
INFO - 2020-07-29 14:15:26 --> Database Driver Class Initialized
INFO - 2020-07-29 14:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:15:26 --> Email Class Initialized
INFO - 2020-07-29 14:15:26 --> Controller Class Initialized
DEBUG - 2020-07-29 14:15:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 14:15:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:15:26 --> Config Class Initialized
INFO - 2020-07-29 14:15:26 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:15:26 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:15:26 --> Utf8 Class Initialized
INFO - 2020-07-29 14:15:26 --> URI Class Initialized
DEBUG - 2020-07-29 14:15:26 --> No URI present. Default controller set.
INFO - 2020-07-29 14:15:26 --> Router Class Initialized
INFO - 2020-07-29 14:15:26 --> Output Class Initialized
INFO - 2020-07-29 14:15:26 --> Security Class Initialized
DEBUG - 2020-07-29 14:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:15:26 --> Input Class Initialized
INFO - 2020-07-29 14:15:26 --> Language Class Initialized
INFO - 2020-07-29 14:15:26 --> Loader Class Initialized
INFO - 2020-07-29 14:15:26 --> Helper loaded: url_helper
INFO - 2020-07-29 14:15:26 --> Database Driver Class Initialized
INFO - 2020-07-29 14:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:15:26 --> Email Class Initialized
INFO - 2020-07-29 14:15:26 --> Controller Class Initialized
INFO - 2020-07-29 14:15:26 --> Model Class Initialized
INFO - 2020-07-29 14:15:26 --> Model Class Initialized
DEBUG - 2020-07-29 14:15:26 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:15:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 14:15:26 --> Final output sent to browser
DEBUG - 2020-07-29 14:15:26 --> Total execution time: 0.0215
INFO - 2020-07-29 14:16:17 --> Config Class Initialized
INFO - 2020-07-29 14:16:17 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:16:17 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:16:17 --> Utf8 Class Initialized
INFO - 2020-07-29 14:16:17 --> URI Class Initialized
INFO - 2020-07-29 14:16:17 --> Router Class Initialized
INFO - 2020-07-29 14:16:17 --> Output Class Initialized
INFO - 2020-07-29 14:16:17 --> Security Class Initialized
DEBUG - 2020-07-29 14:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:16:17 --> Input Class Initialized
INFO - 2020-07-29 14:16:17 --> Language Class Initialized
INFO - 2020-07-29 14:16:17 --> Loader Class Initialized
INFO - 2020-07-29 14:16:17 --> Helper loaded: url_helper
INFO - 2020-07-29 14:16:17 --> Database Driver Class Initialized
INFO - 2020-07-29 14:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:16:17 --> Email Class Initialized
INFO - 2020-07-29 14:16:17 --> Controller Class Initialized
INFO - 2020-07-29 14:16:17 --> Model Class Initialized
INFO - 2020-07-29 14:16:17 --> Model Class Initialized
DEBUG - 2020-07-29 14:16:17 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:16:18 --> Config Class Initialized
INFO - 2020-07-29 14:16:18 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:16:18 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:16:18 --> Utf8 Class Initialized
INFO - 2020-07-29 14:16:18 --> URI Class Initialized
INFO - 2020-07-29 14:16:18 --> Router Class Initialized
INFO - 2020-07-29 14:16:18 --> Output Class Initialized
INFO - 2020-07-29 14:16:18 --> Security Class Initialized
DEBUG - 2020-07-29 14:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:16:18 --> Input Class Initialized
INFO - 2020-07-29 14:16:18 --> Language Class Initialized
INFO - 2020-07-29 14:16:18 --> Loader Class Initialized
INFO - 2020-07-29 14:16:18 --> Helper loaded: url_helper
INFO - 2020-07-29 14:16:18 --> Database Driver Class Initialized
INFO - 2020-07-29 14:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:16:18 --> Email Class Initialized
INFO - 2020-07-29 14:16:18 --> Controller Class Initialized
DEBUG - 2020-07-29 14:16:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 14:16:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:16:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 14:16:18 --> Final output sent to browser
DEBUG - 2020-07-29 14:16:18 --> Total execution time: 0.0216
INFO - 2020-07-29 14:16:47 --> Config Class Initialized
INFO - 2020-07-29 14:16:47 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:16:47 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:16:47 --> Utf8 Class Initialized
INFO - 2020-07-29 14:16:47 --> URI Class Initialized
INFO - 2020-07-29 14:16:47 --> Router Class Initialized
INFO - 2020-07-29 14:16:47 --> Output Class Initialized
INFO - 2020-07-29 14:16:47 --> Security Class Initialized
DEBUG - 2020-07-29 14:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:16:47 --> Input Class Initialized
INFO - 2020-07-29 14:16:47 --> Language Class Initialized
INFO - 2020-07-29 14:16:47 --> Loader Class Initialized
INFO - 2020-07-29 14:16:47 --> Helper loaded: url_helper
INFO - 2020-07-29 14:16:47 --> Database Driver Class Initialized
INFO - 2020-07-29 14:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:16:47 --> Email Class Initialized
INFO - 2020-07-29 14:16:47 --> Controller Class Initialized
DEBUG - 2020-07-29 14:16:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 14:16:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:16:47 --> Model Class Initialized
INFO - 2020-07-29 14:16:47 --> Model Class Initialized
INFO - 2020-07-29 14:16:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 14:16:47 --> Final output sent to browser
DEBUG - 2020-07-29 14:16:47 --> Total execution time: 0.0252
INFO - 2020-07-29 14:16:50 --> Config Class Initialized
INFO - 2020-07-29 14:16:50 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:16:50 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:16:50 --> Utf8 Class Initialized
INFO - 2020-07-29 14:16:50 --> URI Class Initialized
INFO - 2020-07-29 14:16:50 --> Router Class Initialized
INFO - 2020-07-29 14:16:50 --> Output Class Initialized
INFO - 2020-07-29 14:16:50 --> Security Class Initialized
DEBUG - 2020-07-29 14:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:16:50 --> Input Class Initialized
INFO - 2020-07-29 14:16:50 --> Language Class Initialized
INFO - 2020-07-29 14:16:50 --> Loader Class Initialized
INFO - 2020-07-29 14:16:50 --> Helper loaded: url_helper
INFO - 2020-07-29 14:16:50 --> Database Driver Class Initialized
INFO - 2020-07-29 14:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:16:50 --> Email Class Initialized
INFO - 2020-07-29 14:16:50 --> Controller Class Initialized
DEBUG - 2020-07-29 14:16:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 14:16:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:16:50 --> Model Class Initialized
INFO - 2020-07-29 14:16:50 --> Model Class Initialized
INFO - 2020-07-29 14:16:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-29 14:16:50 --> Final output sent to browser
DEBUG - 2020-07-29 14:16:50 --> Total execution time: 0.0185
INFO - 2020-07-29 14:16:56 --> Config Class Initialized
INFO - 2020-07-29 14:16:56 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:16:56 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:16:56 --> Utf8 Class Initialized
INFO - 2020-07-29 14:16:56 --> URI Class Initialized
INFO - 2020-07-29 14:16:56 --> Router Class Initialized
INFO - 2020-07-29 14:16:56 --> Output Class Initialized
INFO - 2020-07-29 14:16:56 --> Security Class Initialized
DEBUG - 2020-07-29 14:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:16:56 --> Input Class Initialized
INFO - 2020-07-29 14:16:56 --> Language Class Initialized
INFO - 2020-07-29 14:16:56 --> Loader Class Initialized
INFO - 2020-07-29 14:16:56 --> Helper loaded: url_helper
INFO - 2020-07-29 14:16:56 --> Database Driver Class Initialized
INFO - 2020-07-29 14:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:16:56 --> Email Class Initialized
INFO - 2020-07-29 14:16:56 --> Controller Class Initialized
DEBUG - 2020-07-29 14:16:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 14:16:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:16:56 --> Model Class Initialized
INFO - 2020-07-29 14:16:56 --> Model Class Initialized
INFO - 2020-07-29 14:16:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 14:16:56 --> Final output sent to browser
DEBUG - 2020-07-29 14:16:56 --> Total execution time: 0.0328
INFO - 2020-07-29 14:16:58 --> Config Class Initialized
INFO - 2020-07-29 14:16:58 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:16:58 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:16:58 --> Utf8 Class Initialized
INFO - 2020-07-29 14:16:58 --> URI Class Initialized
INFO - 2020-07-29 14:16:58 --> Router Class Initialized
INFO - 2020-07-29 14:16:58 --> Output Class Initialized
INFO - 2020-07-29 14:16:58 --> Security Class Initialized
DEBUG - 2020-07-29 14:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:16:58 --> Input Class Initialized
INFO - 2020-07-29 14:16:58 --> Language Class Initialized
INFO - 2020-07-29 14:16:58 --> Loader Class Initialized
INFO - 2020-07-29 14:16:58 --> Helper loaded: url_helper
INFO - 2020-07-29 14:16:58 --> Database Driver Class Initialized
INFO - 2020-07-29 14:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:16:58 --> Email Class Initialized
INFO - 2020-07-29 14:16:58 --> Controller Class Initialized
DEBUG - 2020-07-29 14:16:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 14:16:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:16:58 --> Model Class Initialized
INFO - 2020-07-29 14:16:58 --> Model Class Initialized
INFO - 2020-07-29 14:16:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-07-29 14:16:58 --> Final output sent to browser
DEBUG - 2020-07-29 14:16:58 --> Total execution time: 0.0228
INFO - 2020-07-29 14:17:01 --> Config Class Initialized
INFO - 2020-07-29 14:17:01 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:17:01 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:17:01 --> Utf8 Class Initialized
INFO - 2020-07-29 14:17:01 --> URI Class Initialized
INFO - 2020-07-29 14:17:01 --> Router Class Initialized
INFO - 2020-07-29 14:17:01 --> Output Class Initialized
INFO - 2020-07-29 14:17:01 --> Security Class Initialized
DEBUG - 2020-07-29 14:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:17:01 --> Input Class Initialized
INFO - 2020-07-29 14:17:01 --> Language Class Initialized
INFO - 2020-07-29 14:17:01 --> Loader Class Initialized
INFO - 2020-07-29 14:17:01 --> Helper loaded: url_helper
INFO - 2020-07-29 14:17:01 --> Database Driver Class Initialized
INFO - 2020-07-29 14:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:17:01 --> Email Class Initialized
INFO - 2020-07-29 14:17:01 --> Controller Class Initialized
DEBUG - 2020-07-29 14:17:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 14:17:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:17:01 --> Model Class Initialized
INFO - 2020-07-29 14:17:01 --> Model Class Initialized
INFO - 2020-07-29 14:17:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 14:17:01 --> Final output sent to browser
DEBUG - 2020-07-29 14:17:01 --> Total execution time: 0.0260
INFO - 2020-07-29 14:17:03 --> Config Class Initialized
INFO - 2020-07-29 14:17:03 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:17:03 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:17:03 --> Utf8 Class Initialized
INFO - 2020-07-29 14:17:03 --> URI Class Initialized
INFO - 2020-07-29 14:17:03 --> Router Class Initialized
INFO - 2020-07-29 14:17:03 --> Output Class Initialized
INFO - 2020-07-29 14:17:03 --> Security Class Initialized
DEBUG - 2020-07-29 14:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:17:03 --> Input Class Initialized
INFO - 2020-07-29 14:17:03 --> Language Class Initialized
INFO - 2020-07-29 14:17:03 --> Loader Class Initialized
INFO - 2020-07-29 14:17:03 --> Helper loaded: url_helper
INFO - 2020-07-29 14:17:03 --> Database Driver Class Initialized
INFO - 2020-07-29 14:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:17:03 --> Email Class Initialized
INFO - 2020-07-29 14:17:03 --> Controller Class Initialized
DEBUG - 2020-07-29 14:17:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 14:17:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:17:03 --> Model Class Initialized
INFO - 2020-07-29 14:17:03 --> Model Class Initialized
INFO - 2020-07-29 14:17:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 14:17:03 --> Final output sent to browser
DEBUG - 2020-07-29 14:17:03 --> Total execution time: 0.0234
INFO - 2020-07-29 14:17:06 --> Config Class Initialized
INFO - 2020-07-29 14:17:06 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:17:06 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:17:06 --> Utf8 Class Initialized
INFO - 2020-07-29 14:17:06 --> URI Class Initialized
INFO - 2020-07-29 14:17:06 --> Router Class Initialized
INFO - 2020-07-29 14:17:06 --> Output Class Initialized
INFO - 2020-07-29 14:17:06 --> Security Class Initialized
DEBUG - 2020-07-29 14:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:17:06 --> Input Class Initialized
INFO - 2020-07-29 14:17:06 --> Language Class Initialized
INFO - 2020-07-29 14:17:06 --> Loader Class Initialized
INFO - 2020-07-29 14:17:06 --> Helper loaded: url_helper
INFO - 2020-07-29 14:17:06 --> Database Driver Class Initialized
INFO - 2020-07-29 14:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:17:06 --> Email Class Initialized
INFO - 2020-07-29 14:17:06 --> Controller Class Initialized
DEBUG - 2020-07-29 14:17:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 14:17:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:17:06 --> Model Class Initialized
INFO - 2020-07-29 14:17:06 --> Model Class Initialized
INFO - 2020-07-29 14:17:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 14:17:06 --> Final output sent to browser
DEBUG - 2020-07-29 14:17:06 --> Total execution time: 0.0237
INFO - 2020-07-29 14:22:13 --> Config Class Initialized
INFO - 2020-07-29 14:22:13 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:22:13 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:22:13 --> Utf8 Class Initialized
INFO - 2020-07-29 14:22:13 --> URI Class Initialized
DEBUG - 2020-07-29 14:22:13 --> No URI present. Default controller set.
INFO - 2020-07-29 14:22:13 --> Router Class Initialized
INFO - 2020-07-29 14:22:13 --> Output Class Initialized
INFO - 2020-07-29 14:22:13 --> Security Class Initialized
DEBUG - 2020-07-29 14:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:22:13 --> Input Class Initialized
INFO - 2020-07-29 14:22:13 --> Language Class Initialized
INFO - 2020-07-29 14:22:13 --> Loader Class Initialized
INFO - 2020-07-29 14:22:13 --> Helper loaded: url_helper
INFO - 2020-07-29 14:22:13 --> Database Driver Class Initialized
INFO - 2020-07-29 14:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:22:13 --> Email Class Initialized
INFO - 2020-07-29 14:22:13 --> Controller Class Initialized
INFO - 2020-07-29 14:22:13 --> Model Class Initialized
INFO - 2020-07-29 14:22:13 --> Model Class Initialized
DEBUG - 2020-07-29 14:22:13 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:22:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 14:22:13 --> Final output sent to browser
DEBUG - 2020-07-29 14:22:13 --> Total execution time: 0.0237
INFO - 2020-07-29 14:55:58 --> Config Class Initialized
INFO - 2020-07-29 14:55:58 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:55:58 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:55:58 --> Utf8 Class Initialized
INFO - 2020-07-29 14:55:58 --> URI Class Initialized
DEBUG - 2020-07-29 14:55:58 --> No URI present. Default controller set.
INFO - 2020-07-29 14:55:58 --> Router Class Initialized
INFO - 2020-07-29 14:55:58 --> Output Class Initialized
INFO - 2020-07-29 14:55:58 --> Security Class Initialized
DEBUG - 2020-07-29 14:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:55:58 --> Input Class Initialized
INFO - 2020-07-29 14:55:58 --> Language Class Initialized
INFO - 2020-07-29 14:55:58 --> Loader Class Initialized
INFO - 2020-07-29 14:55:58 --> Helper loaded: url_helper
INFO - 2020-07-29 14:55:58 --> Database Driver Class Initialized
INFO - 2020-07-29 14:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:55:58 --> Email Class Initialized
INFO - 2020-07-29 14:55:58 --> Controller Class Initialized
INFO - 2020-07-29 14:55:58 --> Model Class Initialized
INFO - 2020-07-29 14:55:58 --> Model Class Initialized
DEBUG - 2020-07-29 14:55:58 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:55:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 14:55:58 --> Final output sent to browser
DEBUG - 2020-07-29 14:55:58 --> Total execution time: 0.0438
INFO - 2020-07-29 14:56:00 --> Config Class Initialized
INFO - 2020-07-29 14:56:00 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:56:00 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:56:00 --> Utf8 Class Initialized
INFO - 2020-07-29 14:56:00 --> URI Class Initialized
INFO - 2020-07-29 14:56:00 --> Router Class Initialized
INFO - 2020-07-29 14:56:00 --> Output Class Initialized
INFO - 2020-07-29 14:56:00 --> Security Class Initialized
DEBUG - 2020-07-29 14:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:56:00 --> Input Class Initialized
INFO - 2020-07-29 14:56:00 --> Language Class Initialized
INFO - 2020-07-29 14:56:00 --> Loader Class Initialized
INFO - 2020-07-29 14:56:00 --> Helper loaded: url_helper
INFO - 2020-07-29 14:56:00 --> Database Driver Class Initialized
INFO - 2020-07-29 14:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:56:00 --> Email Class Initialized
INFO - 2020-07-29 14:56:00 --> Controller Class Initialized
INFO - 2020-07-29 14:56:00 --> Model Class Initialized
INFO - 2020-07-29 14:56:00 --> Model Class Initialized
DEBUG - 2020-07-29 14:56:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:56:01 --> Config Class Initialized
INFO - 2020-07-29 14:56:01 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:56:01 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:56:01 --> Utf8 Class Initialized
INFO - 2020-07-29 14:56:01 --> URI Class Initialized
DEBUG - 2020-07-29 14:56:01 --> No URI present. Default controller set.
INFO - 2020-07-29 14:56:01 --> Router Class Initialized
INFO - 2020-07-29 14:56:01 --> Output Class Initialized
INFO - 2020-07-29 14:56:01 --> Security Class Initialized
DEBUG - 2020-07-29 14:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:56:01 --> Input Class Initialized
INFO - 2020-07-29 14:56:01 --> Language Class Initialized
INFO - 2020-07-29 14:56:01 --> Loader Class Initialized
INFO - 2020-07-29 14:56:01 --> Helper loaded: url_helper
INFO - 2020-07-29 14:56:01 --> Database Driver Class Initialized
INFO - 2020-07-29 14:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:56:01 --> Email Class Initialized
INFO - 2020-07-29 14:56:01 --> Controller Class Initialized
INFO - 2020-07-29 14:56:01 --> Model Class Initialized
INFO - 2020-07-29 14:56:01 --> Model Class Initialized
DEBUG - 2020-07-29 14:56:01 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:56:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 14:56:01 --> Final output sent to browser
DEBUG - 2020-07-29 14:56:01 --> Total execution time: 0.0197
INFO - 2020-07-29 14:56:04 --> Config Class Initialized
INFO - 2020-07-29 14:56:04 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:56:04 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:56:04 --> Utf8 Class Initialized
INFO - 2020-07-29 14:56:04 --> URI Class Initialized
INFO - 2020-07-29 14:56:04 --> Router Class Initialized
INFO - 2020-07-29 14:56:04 --> Output Class Initialized
INFO - 2020-07-29 14:56:04 --> Security Class Initialized
DEBUG - 2020-07-29 14:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:56:04 --> Input Class Initialized
INFO - 2020-07-29 14:56:04 --> Language Class Initialized
INFO - 2020-07-29 14:56:04 --> Loader Class Initialized
INFO - 2020-07-29 14:56:04 --> Helper loaded: url_helper
INFO - 2020-07-29 14:56:04 --> Database Driver Class Initialized
INFO - 2020-07-29 14:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:56:04 --> Email Class Initialized
INFO - 2020-07-29 14:56:04 --> Controller Class Initialized
INFO - 2020-07-29 14:56:04 --> Model Class Initialized
INFO - 2020-07-29 14:56:04 --> Model Class Initialized
DEBUG - 2020-07-29 14:56:04 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:56:05 --> Config Class Initialized
INFO - 2020-07-29 14:56:05 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:56:05 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:56:05 --> Utf8 Class Initialized
INFO - 2020-07-29 14:56:05 --> URI Class Initialized
DEBUG - 2020-07-29 14:56:05 --> No URI present. Default controller set.
INFO - 2020-07-29 14:56:05 --> Router Class Initialized
INFO - 2020-07-29 14:56:05 --> Output Class Initialized
INFO - 2020-07-29 14:56:05 --> Security Class Initialized
DEBUG - 2020-07-29 14:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:56:05 --> Input Class Initialized
INFO - 2020-07-29 14:56:05 --> Language Class Initialized
INFO - 2020-07-29 14:56:05 --> Loader Class Initialized
INFO - 2020-07-29 14:56:05 --> Helper loaded: url_helper
INFO - 2020-07-29 14:56:05 --> Database Driver Class Initialized
INFO - 2020-07-29 14:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:56:05 --> Email Class Initialized
INFO - 2020-07-29 14:56:05 --> Controller Class Initialized
INFO - 2020-07-29 14:56:05 --> Model Class Initialized
INFO - 2020-07-29 14:56:05 --> Model Class Initialized
DEBUG - 2020-07-29 14:56:05 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:56:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 14:56:05 --> Final output sent to browser
DEBUG - 2020-07-29 14:56:05 --> Total execution time: 0.0227
INFO - 2020-07-29 14:56:35 --> Config Class Initialized
INFO - 2020-07-29 14:56:35 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:56:35 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:56:35 --> Utf8 Class Initialized
INFO - 2020-07-29 14:56:35 --> URI Class Initialized
INFO - 2020-07-29 14:56:35 --> Router Class Initialized
INFO - 2020-07-29 14:56:35 --> Output Class Initialized
INFO - 2020-07-29 14:56:35 --> Security Class Initialized
DEBUG - 2020-07-29 14:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:56:35 --> Input Class Initialized
INFO - 2020-07-29 14:56:35 --> Language Class Initialized
INFO - 2020-07-29 14:56:35 --> Loader Class Initialized
INFO - 2020-07-29 14:56:35 --> Helper loaded: url_helper
INFO - 2020-07-29 14:56:35 --> Database Driver Class Initialized
INFO - 2020-07-29 14:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:56:35 --> Email Class Initialized
INFO - 2020-07-29 14:56:35 --> Controller Class Initialized
INFO - 2020-07-29 14:56:35 --> Model Class Initialized
INFO - 2020-07-29 14:56:35 --> Model Class Initialized
DEBUG - 2020-07-29 14:56:35 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:56:36 --> Config Class Initialized
INFO - 2020-07-29 14:56:36 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:56:36 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:56:36 --> Utf8 Class Initialized
INFO - 2020-07-29 14:56:36 --> URI Class Initialized
INFO - 2020-07-29 14:56:36 --> Router Class Initialized
INFO - 2020-07-29 14:56:36 --> Output Class Initialized
INFO - 2020-07-29 14:56:36 --> Security Class Initialized
DEBUG - 2020-07-29 14:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:56:36 --> Input Class Initialized
INFO - 2020-07-29 14:56:36 --> Language Class Initialized
INFO - 2020-07-29 14:56:36 --> Loader Class Initialized
INFO - 2020-07-29 14:56:36 --> Helper loaded: url_helper
INFO - 2020-07-29 14:56:36 --> Database Driver Class Initialized
INFO - 2020-07-29 14:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:56:36 --> Email Class Initialized
INFO - 2020-07-29 14:56:36 --> Controller Class Initialized
DEBUG - 2020-07-29 14:56:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 14:56:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:56:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 14:56:36 --> Final output sent to browser
DEBUG - 2020-07-29 14:56:36 --> Total execution time: 0.0213
INFO - 2020-07-29 14:56:40 --> Config Class Initialized
INFO - 2020-07-29 14:56:40 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:56:40 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:56:40 --> Utf8 Class Initialized
INFO - 2020-07-29 14:56:40 --> URI Class Initialized
DEBUG - 2020-07-29 14:56:40 --> No URI present. Default controller set.
INFO - 2020-07-29 14:56:40 --> Router Class Initialized
INFO - 2020-07-29 14:56:40 --> Output Class Initialized
INFO - 2020-07-29 14:56:40 --> Security Class Initialized
DEBUG - 2020-07-29 14:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:56:40 --> Input Class Initialized
INFO - 2020-07-29 14:56:40 --> Language Class Initialized
INFO - 2020-07-29 14:56:40 --> Loader Class Initialized
INFO - 2020-07-29 14:56:40 --> Helper loaded: url_helper
INFO - 2020-07-29 14:56:40 --> Database Driver Class Initialized
INFO - 2020-07-29 14:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:56:40 --> Email Class Initialized
INFO - 2020-07-29 14:56:40 --> Controller Class Initialized
INFO - 2020-07-29 14:56:40 --> Model Class Initialized
INFO - 2020-07-29 14:56:40 --> Model Class Initialized
DEBUG - 2020-07-29 14:56:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:56:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 14:56:40 --> Final output sent to browser
DEBUG - 2020-07-29 14:56:40 --> Total execution time: 0.0266
INFO - 2020-07-29 14:56:43 --> Config Class Initialized
INFO - 2020-07-29 14:56:43 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:56:43 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:56:43 --> Utf8 Class Initialized
INFO - 2020-07-29 14:56:43 --> URI Class Initialized
INFO - 2020-07-29 14:56:43 --> Router Class Initialized
INFO - 2020-07-29 14:56:43 --> Output Class Initialized
INFO - 2020-07-29 14:56:43 --> Security Class Initialized
DEBUG - 2020-07-29 14:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:56:43 --> Input Class Initialized
INFO - 2020-07-29 14:56:43 --> Language Class Initialized
INFO - 2020-07-29 14:56:43 --> Loader Class Initialized
INFO - 2020-07-29 14:56:43 --> Helper loaded: url_helper
INFO - 2020-07-29 14:56:43 --> Database Driver Class Initialized
INFO - 2020-07-29 14:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:56:43 --> Email Class Initialized
INFO - 2020-07-29 14:56:43 --> Controller Class Initialized
INFO - 2020-07-29 14:56:43 --> Model Class Initialized
INFO - 2020-07-29 14:56:43 --> Model Class Initialized
DEBUG - 2020-07-29 14:56:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:56:43 --> Model Class Initialized
INFO - 2020-07-29 14:56:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-29 14:56:43 --> Final output sent to browser
DEBUG - 2020-07-29 14:56:43 --> Total execution time: 0.0208
INFO - 2020-07-29 14:56:44 --> Config Class Initialized
INFO - 2020-07-29 14:56:44 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:56:44 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:56:44 --> Utf8 Class Initialized
INFO - 2020-07-29 14:56:44 --> URI Class Initialized
INFO - 2020-07-29 14:56:44 --> Router Class Initialized
INFO - 2020-07-29 14:56:44 --> Output Class Initialized
INFO - 2020-07-29 14:56:44 --> Security Class Initialized
DEBUG - 2020-07-29 14:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:56:44 --> Input Class Initialized
INFO - 2020-07-29 14:56:44 --> Language Class Initialized
ERROR - 2020-07-29 14:56:44 --> 404 Page Not Found: User_reg/font-awesome
INFO - 2020-07-29 14:56:44 --> Config Class Initialized
INFO - 2020-07-29 14:56:44 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:56:44 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:56:44 --> Utf8 Class Initialized
INFO - 2020-07-29 14:56:44 --> URI Class Initialized
INFO - 2020-07-29 14:56:44 --> Router Class Initialized
INFO - 2020-07-29 14:56:44 --> Output Class Initialized
INFO - 2020-07-29 14:56:44 --> Security Class Initialized
DEBUG - 2020-07-29 14:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:56:44 --> Input Class Initialized
INFO - 2020-07-29 14:56:44 --> Language Class Initialized
ERROR - 2020-07-29 14:56:44 --> 404 Page Not Found: User_reg/css
INFO - 2020-07-29 14:56:44 --> Config Class Initialized
INFO - 2020-07-29 14:56:44 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:56:44 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:56:44 --> Utf8 Class Initialized
INFO - 2020-07-29 14:56:44 --> URI Class Initialized
INFO - 2020-07-29 14:56:44 --> Router Class Initialized
INFO - 2020-07-29 14:56:44 --> Output Class Initialized
INFO - 2020-07-29 14:56:44 --> Security Class Initialized
DEBUG - 2020-07-29 14:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:56:44 --> Input Class Initialized
INFO - 2020-07-29 14:56:44 --> Language Class Initialized
ERROR - 2020-07-29 14:56:44 --> 404 Page Not Found: User_reg/css
INFO - 2020-07-29 14:56:44 --> Config Class Initialized
INFO - 2020-07-29 14:56:44 --> Hooks Class Initialized
INFO - 2020-07-29 14:56:44 --> Config Class Initialized
DEBUG - 2020-07-29 14:56:44 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:56:44 --> Hooks Class Initialized
INFO - 2020-07-29 14:56:44 --> Utf8 Class Initialized
INFO - 2020-07-29 14:56:44 --> URI Class Initialized
INFO - 2020-07-29 14:56:44 --> Router Class Initialized
DEBUG - 2020-07-29 14:56:44 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:56:44 --> Utf8 Class Initialized
INFO - 2020-07-29 14:56:44 --> Output Class Initialized
INFO - 2020-07-29 14:56:44 --> URI Class Initialized
INFO - 2020-07-29 14:56:44 --> Security Class Initialized
INFO - 2020-07-29 14:56:44 --> Router Class Initialized
DEBUG - 2020-07-29 14:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:56:44 --> Input Class Initialized
INFO - 2020-07-29 14:56:44 --> Language Class Initialized
INFO - 2020-07-29 14:56:44 --> Output Class Initialized
ERROR - 2020-07-29 14:56:44 --> 404 Page Not Found: User_reg/js
INFO - 2020-07-29 14:56:44 --> Security Class Initialized
DEBUG - 2020-07-29 14:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:56:44 --> Input Class Initialized
INFO - 2020-07-29 14:56:44 --> Language Class Initialized
ERROR - 2020-07-29 14:56:44 --> 404 Page Not Found: User_reg/js
INFO - 2020-07-29 14:56:44 --> Config Class Initialized
INFO - 2020-07-29 14:56:44 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:56:44 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:56:44 --> Utf8 Class Initialized
INFO - 2020-07-29 14:56:44 --> URI Class Initialized
INFO - 2020-07-29 14:56:44 --> Router Class Initialized
INFO - 2020-07-29 14:56:44 --> Output Class Initialized
INFO - 2020-07-29 14:56:44 --> Security Class Initialized
DEBUG - 2020-07-29 14:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:56:44 --> Input Class Initialized
INFO - 2020-07-29 14:56:44 --> Language Class Initialized
ERROR - 2020-07-29 14:56:44 --> 404 Page Not Found: User_reg/css
INFO - 2020-07-29 14:56:44 --> Config Class Initialized
INFO - 2020-07-29 14:56:44 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:56:44 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:56:44 --> Utf8 Class Initialized
INFO - 2020-07-29 14:56:44 --> URI Class Initialized
INFO - 2020-07-29 14:56:44 --> Router Class Initialized
INFO - 2020-07-29 14:56:44 --> Output Class Initialized
INFO - 2020-07-29 14:56:44 --> Security Class Initialized
DEBUG - 2020-07-29 14:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:56:44 --> Input Class Initialized
INFO - 2020-07-29 14:56:44 --> Language Class Initialized
ERROR - 2020-07-29 14:56:44 --> 404 Page Not Found: User_reg/js
INFO - 2020-07-29 14:56:45 --> Config Class Initialized
INFO - 2020-07-29 14:56:45 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:56:45 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:56:45 --> Utf8 Class Initialized
INFO - 2020-07-29 14:56:45 --> URI Class Initialized
INFO - 2020-07-29 14:56:45 --> Router Class Initialized
INFO - 2020-07-29 14:56:45 --> Output Class Initialized
INFO - 2020-07-29 14:56:45 --> Security Class Initialized
DEBUG - 2020-07-29 14:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:56:45 --> Input Class Initialized
INFO - 2020-07-29 14:56:45 --> Language Class Initialized
ERROR - 2020-07-29 14:56:45 --> 404 Page Not Found: User_reg/js
INFO - 2020-07-29 14:56:45 --> Config Class Initialized
INFO - 2020-07-29 14:56:45 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:56:45 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:56:45 --> Utf8 Class Initialized
INFO - 2020-07-29 14:56:45 --> URI Class Initialized
INFO - 2020-07-29 14:56:45 --> Router Class Initialized
INFO - 2020-07-29 14:56:45 --> Output Class Initialized
INFO - 2020-07-29 14:56:45 --> Security Class Initialized
DEBUG - 2020-07-29 14:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:56:45 --> Input Class Initialized
INFO - 2020-07-29 14:56:45 --> Language Class Initialized
ERROR - 2020-07-29 14:56:45 --> 404 Page Not Found: User_reg/js
INFO - 2020-07-29 14:56:45 --> Config Class Initialized
INFO - 2020-07-29 14:56:45 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:56:45 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:56:45 --> Utf8 Class Initialized
INFO - 2020-07-29 14:56:45 --> URI Class Initialized
INFO - 2020-07-29 14:56:45 --> Router Class Initialized
INFO - 2020-07-29 14:56:45 --> Output Class Initialized
INFO - 2020-07-29 14:56:45 --> Security Class Initialized
DEBUG - 2020-07-29 14:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:56:45 --> Input Class Initialized
INFO - 2020-07-29 14:56:45 --> Language Class Initialized
ERROR - 2020-07-29 14:56:45 --> 404 Page Not Found: User_reg/js
INFO - 2020-07-29 14:58:11 --> Config Class Initialized
INFO - 2020-07-29 14:58:11 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:58:11 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:58:11 --> Utf8 Class Initialized
INFO - 2020-07-29 14:58:11 --> URI Class Initialized
INFO - 2020-07-29 14:58:11 --> Router Class Initialized
INFO - 2020-07-29 14:58:11 --> Output Class Initialized
INFO - 2020-07-29 14:58:11 --> Security Class Initialized
DEBUG - 2020-07-29 14:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:58:11 --> Input Class Initialized
INFO - 2020-07-29 14:58:11 --> Language Class Initialized
INFO - 2020-07-29 14:58:11 --> Loader Class Initialized
INFO - 2020-07-29 14:58:11 --> Helper loaded: url_helper
INFO - 2020-07-29 14:58:11 --> Database Driver Class Initialized
INFO - 2020-07-29 14:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:58:11 --> Email Class Initialized
INFO - 2020-07-29 14:58:11 --> Controller Class Initialized
INFO - 2020-07-29 14:58:11 --> Model Class Initialized
INFO - 2020-07-29 14:58:11 --> Model Class Initialized
DEBUG - 2020-07-29 14:58:11 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:58:11 --> Model Class Initialized
INFO - 2020-07-29 14:58:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-29 14:58:11 --> Final output sent to browser
DEBUG - 2020-07-29 14:58:11 --> Total execution time: 0.0195
INFO - 2020-07-29 14:58:20 --> Config Class Initialized
INFO - 2020-07-29 14:58:20 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:58:20 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:58:20 --> Utf8 Class Initialized
INFO - 2020-07-29 14:58:20 --> URI Class Initialized
DEBUG - 2020-07-29 14:58:20 --> No URI present. Default controller set.
INFO - 2020-07-29 14:58:20 --> Router Class Initialized
INFO - 2020-07-29 14:58:20 --> Output Class Initialized
INFO - 2020-07-29 14:58:20 --> Security Class Initialized
DEBUG - 2020-07-29 14:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:58:20 --> Input Class Initialized
INFO - 2020-07-29 14:58:20 --> Language Class Initialized
INFO - 2020-07-29 14:58:20 --> Loader Class Initialized
INFO - 2020-07-29 14:58:20 --> Helper loaded: url_helper
INFO - 2020-07-29 14:58:20 --> Database Driver Class Initialized
INFO - 2020-07-29 14:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:58:20 --> Email Class Initialized
INFO - 2020-07-29 14:58:20 --> Controller Class Initialized
INFO - 2020-07-29 14:58:20 --> Model Class Initialized
INFO - 2020-07-29 14:58:20 --> Model Class Initialized
DEBUG - 2020-07-29 14:58:20 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:58:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 14:58:20 --> Final output sent to browser
DEBUG - 2020-07-29 14:58:20 --> Total execution time: 0.0224
INFO - 2020-07-29 14:58:23 --> Config Class Initialized
INFO - 2020-07-29 14:58:23 --> Hooks Class Initialized
DEBUG - 2020-07-29 14:58:23 --> UTF-8 Support Enabled
INFO - 2020-07-29 14:58:23 --> Utf8 Class Initialized
INFO - 2020-07-29 14:58:23 --> URI Class Initialized
INFO - 2020-07-29 14:58:23 --> Router Class Initialized
INFO - 2020-07-29 14:58:23 --> Output Class Initialized
INFO - 2020-07-29 14:58:23 --> Security Class Initialized
DEBUG - 2020-07-29 14:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 14:58:23 --> Input Class Initialized
INFO - 2020-07-29 14:58:23 --> Language Class Initialized
INFO - 2020-07-29 14:58:23 --> Loader Class Initialized
INFO - 2020-07-29 14:58:23 --> Helper loaded: url_helper
INFO - 2020-07-29 14:58:23 --> Database Driver Class Initialized
INFO - 2020-07-29 14:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 14:58:23 --> Email Class Initialized
INFO - 2020-07-29 14:58:23 --> Controller Class Initialized
INFO - 2020-07-29 14:58:23 --> Model Class Initialized
INFO - 2020-07-29 14:58:23 --> Model Class Initialized
DEBUG - 2020-07-29 14:58:23 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 14:58:23 --> Model Class Initialized
INFO - 2020-07-29 14:58:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-29 14:58:23 --> Final output sent to browser
DEBUG - 2020-07-29 14:58:23 --> Total execution time: 0.0250
INFO - 2020-07-29 15:04:08 --> Config Class Initialized
INFO - 2020-07-29 15:04:08 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:04:08 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:04:08 --> Utf8 Class Initialized
INFO - 2020-07-29 15:04:08 --> URI Class Initialized
INFO - 2020-07-29 15:04:08 --> Router Class Initialized
INFO - 2020-07-29 15:04:08 --> Output Class Initialized
INFO - 2020-07-29 15:04:08 --> Security Class Initialized
DEBUG - 2020-07-29 15:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:04:08 --> Input Class Initialized
INFO - 2020-07-29 15:04:08 --> Language Class Initialized
INFO - 2020-07-29 15:04:08 --> Loader Class Initialized
INFO - 2020-07-29 15:04:08 --> Helper loaded: url_helper
INFO - 2020-07-29 15:04:08 --> Database Driver Class Initialized
INFO - 2020-07-29 15:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:04:08 --> Email Class Initialized
INFO - 2020-07-29 15:04:08 --> Controller Class Initialized
INFO - 2020-07-29 15:04:08 --> Model Class Initialized
INFO - 2020-07-29 15:04:08 --> Model Class Initialized
DEBUG - 2020-07-29 15:04:08 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:04:08 --> Model Class Initialized
INFO - 2020-07-29 15:04:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-29 15:04:08 --> Final output sent to browser
DEBUG - 2020-07-29 15:04:08 --> Total execution time: 0.0213
INFO - 2020-07-29 15:04:26 --> Config Class Initialized
INFO - 2020-07-29 15:04:26 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:04:26 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:04:26 --> Utf8 Class Initialized
INFO - 2020-07-29 15:04:26 --> URI Class Initialized
INFO - 2020-07-29 15:04:26 --> Router Class Initialized
INFO - 2020-07-29 15:04:26 --> Output Class Initialized
INFO - 2020-07-29 15:04:26 --> Security Class Initialized
DEBUG - 2020-07-29 15:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:04:26 --> Input Class Initialized
INFO - 2020-07-29 15:04:26 --> Language Class Initialized
INFO - 2020-07-29 15:04:26 --> Loader Class Initialized
INFO - 2020-07-29 15:04:26 --> Helper loaded: url_helper
INFO - 2020-07-29 15:04:26 --> Database Driver Class Initialized
INFO - 2020-07-29 15:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:04:26 --> Email Class Initialized
INFO - 2020-07-29 15:04:26 --> Controller Class Initialized
INFO - 2020-07-29 15:04:26 --> Model Class Initialized
INFO - 2020-07-29 15:04:26 --> Model Class Initialized
DEBUG - 2020-07-29 15:04:26 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:04:26 --> Model Class Initialized
INFO - 2020-07-29 15:04:26 --> Final output sent to browser
DEBUG - 2020-07-29 15:04:26 --> Total execution time: 0.0206
INFO - 2020-07-29 15:05:29 --> Config Class Initialized
INFO - 2020-07-29 15:05:29 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:05:29 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:05:29 --> Utf8 Class Initialized
INFO - 2020-07-29 15:05:29 --> URI Class Initialized
INFO - 2020-07-29 15:05:29 --> Router Class Initialized
INFO - 2020-07-29 15:05:29 --> Output Class Initialized
INFO - 2020-07-29 15:05:29 --> Security Class Initialized
DEBUG - 2020-07-29 15:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:05:29 --> Input Class Initialized
INFO - 2020-07-29 15:05:29 --> Language Class Initialized
INFO - 2020-07-29 15:05:29 --> Loader Class Initialized
INFO - 2020-07-29 15:05:29 --> Helper loaded: url_helper
INFO - 2020-07-29 15:05:29 --> Database Driver Class Initialized
INFO - 2020-07-29 15:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:05:29 --> Email Class Initialized
INFO - 2020-07-29 15:05:29 --> Controller Class Initialized
INFO - 2020-07-29 15:05:29 --> Model Class Initialized
INFO - 2020-07-29 15:05:29 --> Model Class Initialized
DEBUG - 2020-07-29 15:05:29 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:05:29 --> Model Class Initialized
INFO - 2020-07-29 15:05:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-29 15:05:29 --> Final output sent to browser
DEBUG - 2020-07-29 15:05:29 --> Total execution time: 0.0215
INFO - 2020-07-29 15:05:47 --> Config Class Initialized
INFO - 2020-07-29 15:05:47 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:05:47 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:05:47 --> Utf8 Class Initialized
INFO - 2020-07-29 15:05:47 --> URI Class Initialized
INFO - 2020-07-29 15:05:47 --> Router Class Initialized
INFO - 2020-07-29 15:05:47 --> Output Class Initialized
INFO - 2020-07-29 15:05:47 --> Security Class Initialized
DEBUG - 2020-07-29 15:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:05:47 --> Input Class Initialized
INFO - 2020-07-29 15:05:47 --> Language Class Initialized
INFO - 2020-07-29 15:05:47 --> Loader Class Initialized
INFO - 2020-07-29 15:05:47 --> Helper loaded: url_helper
INFO - 2020-07-29 15:05:47 --> Database Driver Class Initialized
INFO - 2020-07-29 15:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:05:47 --> Email Class Initialized
INFO - 2020-07-29 15:05:47 --> Controller Class Initialized
INFO - 2020-07-29 15:05:47 --> Model Class Initialized
INFO - 2020-07-29 15:05:47 --> Model Class Initialized
DEBUG - 2020-07-29 15:05:47 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:05:47 --> Model Class Initialized
INFO - 2020-07-29 15:05:47 --> Final output sent to browser
DEBUG - 2020-07-29 15:05:47 --> Total execution time: 0.0209
INFO - 2020-07-29 15:07:38 --> Config Class Initialized
INFO - 2020-07-29 15:07:38 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:07:38 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:07:38 --> Utf8 Class Initialized
INFO - 2020-07-29 15:07:38 --> URI Class Initialized
INFO - 2020-07-29 15:07:38 --> Router Class Initialized
INFO - 2020-07-29 15:07:38 --> Output Class Initialized
INFO - 2020-07-29 15:07:38 --> Security Class Initialized
DEBUG - 2020-07-29 15:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:07:38 --> Input Class Initialized
INFO - 2020-07-29 15:07:38 --> Language Class Initialized
INFO - 2020-07-29 15:07:38 --> Loader Class Initialized
INFO - 2020-07-29 15:07:38 --> Helper loaded: url_helper
INFO - 2020-07-29 15:07:38 --> Database Driver Class Initialized
INFO - 2020-07-29 15:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:07:38 --> Email Class Initialized
INFO - 2020-07-29 15:07:38 --> Controller Class Initialized
INFO - 2020-07-29 15:07:38 --> Model Class Initialized
INFO - 2020-07-29 15:07:38 --> Model Class Initialized
DEBUG - 2020-07-29 15:07:38 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:07:38 --> Model Class Initialized
INFO - 2020-07-29 15:07:38 --> Final output sent to browser
DEBUG - 2020-07-29 15:07:38 --> Total execution time: 0.0215
INFO - 2020-07-29 15:08:37 --> Config Class Initialized
INFO - 2020-07-29 15:08:37 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:08:37 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:08:37 --> Utf8 Class Initialized
INFO - 2020-07-29 15:08:37 --> URI Class Initialized
INFO - 2020-07-29 15:08:37 --> Router Class Initialized
INFO - 2020-07-29 15:08:37 --> Output Class Initialized
INFO - 2020-07-29 15:08:37 --> Security Class Initialized
DEBUG - 2020-07-29 15:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:08:37 --> Input Class Initialized
INFO - 2020-07-29 15:08:37 --> Language Class Initialized
INFO - 2020-07-29 15:08:37 --> Loader Class Initialized
INFO - 2020-07-29 15:08:37 --> Helper loaded: url_helper
INFO - 2020-07-29 15:08:37 --> Database Driver Class Initialized
INFO - 2020-07-29 15:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:08:37 --> Email Class Initialized
INFO - 2020-07-29 15:08:37 --> Controller Class Initialized
INFO - 2020-07-29 15:08:37 --> Model Class Initialized
INFO - 2020-07-29 15:08:37 --> Model Class Initialized
DEBUG - 2020-07-29 15:08:37 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:08:37 --> Model Class Initialized
INFO - 2020-07-29 15:08:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-29 15:08:37 --> Final output sent to browser
DEBUG - 2020-07-29 15:08:37 --> Total execution time: 0.0225
INFO - 2020-07-29 15:08:42 --> Config Class Initialized
INFO - 2020-07-29 15:08:42 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:08:42 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:08:42 --> Utf8 Class Initialized
INFO - 2020-07-29 15:08:42 --> URI Class Initialized
INFO - 2020-07-29 15:08:42 --> Router Class Initialized
INFO - 2020-07-29 15:08:42 --> Output Class Initialized
INFO - 2020-07-29 15:08:42 --> Security Class Initialized
DEBUG - 2020-07-29 15:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:08:42 --> Input Class Initialized
INFO - 2020-07-29 15:08:42 --> Language Class Initialized
INFO - 2020-07-29 15:08:42 --> Loader Class Initialized
INFO - 2020-07-29 15:08:42 --> Helper loaded: url_helper
INFO - 2020-07-29 15:08:42 --> Database Driver Class Initialized
INFO - 2020-07-29 15:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:08:42 --> Email Class Initialized
INFO - 2020-07-29 15:08:42 --> Controller Class Initialized
INFO - 2020-07-29 15:08:42 --> Model Class Initialized
INFO - 2020-07-29 15:08:42 --> Model Class Initialized
DEBUG - 2020-07-29 15:08:42 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:08:42 --> Model Class Initialized
INFO - 2020-07-29 15:08:42 --> Final output sent to browser
DEBUG - 2020-07-29 15:08:42 --> Total execution time: 0.0186
INFO - 2020-07-29 15:08:49 --> Config Class Initialized
INFO - 2020-07-29 15:08:49 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:08:49 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:08:49 --> Utf8 Class Initialized
INFO - 2020-07-29 15:08:49 --> URI Class Initialized
INFO - 2020-07-29 15:08:49 --> Router Class Initialized
INFO - 2020-07-29 15:08:49 --> Output Class Initialized
INFO - 2020-07-29 15:08:49 --> Security Class Initialized
DEBUG - 2020-07-29 15:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:08:49 --> Input Class Initialized
INFO - 2020-07-29 15:08:49 --> Language Class Initialized
INFO - 2020-07-29 15:08:49 --> Loader Class Initialized
INFO - 2020-07-29 15:08:49 --> Helper loaded: url_helper
INFO - 2020-07-29 15:08:49 --> Database Driver Class Initialized
INFO - 2020-07-29 15:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:08:49 --> Email Class Initialized
INFO - 2020-07-29 15:08:49 --> Controller Class Initialized
INFO - 2020-07-29 15:08:49 --> Model Class Initialized
INFO - 2020-07-29 15:08:49 --> Model Class Initialized
DEBUG - 2020-07-29 15:08:49 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:08:49 --> Model Class Initialized
INFO - 2020-07-29 15:08:49 --> Final output sent to browser
DEBUG - 2020-07-29 15:08:49 --> Total execution time: 0.0226
INFO - 2020-07-29 15:09:39 --> Config Class Initialized
INFO - 2020-07-29 15:09:39 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:09:39 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:09:39 --> Utf8 Class Initialized
INFO - 2020-07-29 15:09:39 --> URI Class Initialized
INFO - 2020-07-29 15:09:39 --> Router Class Initialized
INFO - 2020-07-29 15:09:39 --> Output Class Initialized
INFO - 2020-07-29 15:09:39 --> Security Class Initialized
DEBUG - 2020-07-29 15:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:09:39 --> Input Class Initialized
INFO - 2020-07-29 15:09:39 --> Language Class Initialized
INFO - 2020-07-29 15:09:39 --> Loader Class Initialized
INFO - 2020-07-29 15:09:39 --> Helper loaded: url_helper
INFO - 2020-07-29 15:09:39 --> Database Driver Class Initialized
INFO - 2020-07-29 15:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:09:39 --> Email Class Initialized
INFO - 2020-07-29 15:09:39 --> Controller Class Initialized
INFO - 2020-07-29 15:09:39 --> Model Class Initialized
INFO - 2020-07-29 15:09:39 --> Model Class Initialized
DEBUG - 2020-07-29 15:09:39 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:09:39 --> Model Class Initialized
INFO - 2020-07-29 15:09:40 --> Config Class Initialized
INFO - 2020-07-29 15:09:40 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:09:40 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:09:40 --> Utf8 Class Initialized
INFO - 2020-07-29 15:09:40 --> URI Class Initialized
DEBUG - 2020-07-29 15:09:40 --> No URI present. Default controller set.
INFO - 2020-07-29 15:09:40 --> Router Class Initialized
INFO - 2020-07-29 15:09:40 --> Output Class Initialized
INFO - 2020-07-29 15:09:40 --> Security Class Initialized
DEBUG - 2020-07-29 15:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:09:40 --> Input Class Initialized
INFO - 2020-07-29 15:09:40 --> Language Class Initialized
INFO - 2020-07-29 15:09:40 --> Loader Class Initialized
INFO - 2020-07-29 15:09:40 --> Helper loaded: url_helper
INFO - 2020-07-29 15:09:40 --> Database Driver Class Initialized
INFO - 2020-07-29 15:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:09:40 --> Email Class Initialized
INFO - 2020-07-29 15:09:40 --> Controller Class Initialized
INFO - 2020-07-29 15:09:40 --> Model Class Initialized
INFO - 2020-07-29 15:09:40 --> Model Class Initialized
DEBUG - 2020-07-29 15:09:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:09:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:09:40 --> Final output sent to browser
DEBUG - 2020-07-29 15:09:40 --> Total execution time: 0.0215
INFO - 2020-07-29 15:12:20 --> Config Class Initialized
INFO - 2020-07-29 15:12:20 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:12:20 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:12:20 --> Utf8 Class Initialized
INFO - 2020-07-29 15:12:20 --> URI Class Initialized
INFO - 2020-07-29 15:12:20 --> Router Class Initialized
INFO - 2020-07-29 15:12:20 --> Output Class Initialized
INFO - 2020-07-29 15:12:20 --> Security Class Initialized
DEBUG - 2020-07-29 15:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:12:20 --> Input Class Initialized
INFO - 2020-07-29 15:12:20 --> Language Class Initialized
INFO - 2020-07-29 15:12:20 --> Loader Class Initialized
INFO - 2020-07-29 15:12:20 --> Helper loaded: url_helper
INFO - 2020-07-29 15:12:20 --> Database Driver Class Initialized
INFO - 2020-07-29 15:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:12:20 --> Email Class Initialized
INFO - 2020-07-29 15:12:20 --> Controller Class Initialized
INFO - 2020-07-29 15:12:20 --> Model Class Initialized
INFO - 2020-07-29 15:12:20 --> Model Class Initialized
DEBUG - 2020-07-29 15:12:20 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:12:20 --> Model Class Initialized
INFO - 2020-07-29 15:12:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-29 15:12:20 --> Final output sent to browser
DEBUG - 2020-07-29 15:12:20 --> Total execution time: 0.0232
INFO - 2020-07-29 15:12:37 --> Config Class Initialized
INFO - 2020-07-29 15:12:37 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:12:37 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:12:37 --> Utf8 Class Initialized
INFO - 2020-07-29 15:12:37 --> URI Class Initialized
INFO - 2020-07-29 15:12:37 --> Router Class Initialized
INFO - 2020-07-29 15:12:37 --> Output Class Initialized
INFO - 2020-07-29 15:12:37 --> Security Class Initialized
DEBUG - 2020-07-29 15:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:12:37 --> Input Class Initialized
INFO - 2020-07-29 15:12:37 --> Language Class Initialized
INFO - 2020-07-29 15:12:37 --> Loader Class Initialized
INFO - 2020-07-29 15:12:37 --> Helper loaded: url_helper
INFO - 2020-07-29 15:12:37 --> Database Driver Class Initialized
INFO - 2020-07-29 15:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:12:37 --> Email Class Initialized
INFO - 2020-07-29 15:12:37 --> Controller Class Initialized
INFO - 2020-07-29 15:12:37 --> Model Class Initialized
INFO - 2020-07-29 15:12:37 --> Model Class Initialized
DEBUG - 2020-07-29 15:12:37 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:12:37 --> Model Class Initialized
INFO - 2020-07-29 15:12:37 --> Config Class Initialized
INFO - 2020-07-29 15:12:37 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:12:37 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:12:37 --> Utf8 Class Initialized
INFO - 2020-07-29 15:12:37 --> URI Class Initialized
DEBUG - 2020-07-29 15:12:37 --> No URI present. Default controller set.
INFO - 2020-07-29 15:12:37 --> Router Class Initialized
INFO - 2020-07-29 15:12:37 --> Output Class Initialized
INFO - 2020-07-29 15:12:37 --> Security Class Initialized
DEBUG - 2020-07-29 15:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:12:37 --> Input Class Initialized
INFO - 2020-07-29 15:12:37 --> Language Class Initialized
INFO - 2020-07-29 15:12:37 --> Loader Class Initialized
INFO - 2020-07-29 15:12:37 --> Helper loaded: url_helper
INFO - 2020-07-29 15:12:37 --> Database Driver Class Initialized
INFO - 2020-07-29 15:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:12:37 --> Email Class Initialized
INFO - 2020-07-29 15:12:37 --> Controller Class Initialized
INFO - 2020-07-29 15:12:37 --> Model Class Initialized
INFO - 2020-07-29 15:12:37 --> Model Class Initialized
DEBUG - 2020-07-29 15:12:37 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:12:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:12:37 --> Final output sent to browser
DEBUG - 2020-07-29 15:12:37 --> Total execution time: 0.0212
INFO - 2020-07-29 15:15:10 --> Config Class Initialized
INFO - 2020-07-29 15:15:10 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:15:10 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:15:10 --> Utf8 Class Initialized
INFO - 2020-07-29 15:15:10 --> URI Class Initialized
INFO - 2020-07-29 15:15:10 --> Router Class Initialized
INFO - 2020-07-29 15:15:10 --> Output Class Initialized
INFO - 2020-07-29 15:15:10 --> Security Class Initialized
DEBUG - 2020-07-29 15:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:15:10 --> Input Class Initialized
INFO - 2020-07-29 15:15:10 --> Language Class Initialized
INFO - 2020-07-29 15:15:10 --> Loader Class Initialized
INFO - 2020-07-29 15:15:10 --> Helper loaded: url_helper
INFO - 2020-07-29 15:15:10 --> Database Driver Class Initialized
INFO - 2020-07-29 15:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:15:10 --> Email Class Initialized
INFO - 2020-07-29 15:15:10 --> Controller Class Initialized
INFO - 2020-07-29 15:15:10 --> Model Class Initialized
INFO - 2020-07-29 15:15:10 --> Model Class Initialized
DEBUG - 2020-07-29 15:15:10 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:15:10 --> Model Class Initialized
INFO - 2020-07-29 15:15:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-29 15:15:10 --> Final output sent to browser
DEBUG - 2020-07-29 15:15:10 --> Total execution time: 0.0214
INFO - 2020-07-29 15:15:25 --> Config Class Initialized
INFO - 2020-07-29 15:15:25 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:15:25 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:15:25 --> Utf8 Class Initialized
INFO - 2020-07-29 15:15:25 --> URI Class Initialized
INFO - 2020-07-29 15:15:25 --> Router Class Initialized
INFO - 2020-07-29 15:15:25 --> Output Class Initialized
INFO - 2020-07-29 15:15:25 --> Security Class Initialized
DEBUG - 2020-07-29 15:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:15:25 --> Input Class Initialized
INFO - 2020-07-29 15:15:25 --> Language Class Initialized
INFO - 2020-07-29 15:15:25 --> Loader Class Initialized
INFO - 2020-07-29 15:15:25 --> Helper loaded: url_helper
INFO - 2020-07-29 15:15:25 --> Database Driver Class Initialized
INFO - 2020-07-29 15:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:15:25 --> Email Class Initialized
INFO - 2020-07-29 15:15:25 --> Controller Class Initialized
INFO - 2020-07-29 15:15:25 --> Model Class Initialized
INFO - 2020-07-29 15:15:25 --> Model Class Initialized
DEBUG - 2020-07-29 15:15:25 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:15:25 --> Model Class Initialized
INFO - 2020-07-29 15:15:26 --> Config Class Initialized
INFO - 2020-07-29 15:15:26 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:15:26 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:15:26 --> Utf8 Class Initialized
INFO - 2020-07-29 15:15:26 --> URI Class Initialized
DEBUG - 2020-07-29 15:15:26 --> No URI present. Default controller set.
INFO - 2020-07-29 15:15:26 --> Router Class Initialized
INFO - 2020-07-29 15:15:26 --> Output Class Initialized
INFO - 2020-07-29 15:15:26 --> Security Class Initialized
DEBUG - 2020-07-29 15:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:15:26 --> Input Class Initialized
INFO - 2020-07-29 15:15:26 --> Language Class Initialized
INFO - 2020-07-29 15:15:26 --> Loader Class Initialized
INFO - 2020-07-29 15:15:26 --> Helper loaded: url_helper
INFO - 2020-07-29 15:15:26 --> Database Driver Class Initialized
INFO - 2020-07-29 15:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:15:26 --> Email Class Initialized
INFO - 2020-07-29 15:15:26 --> Controller Class Initialized
INFO - 2020-07-29 15:15:26 --> Model Class Initialized
INFO - 2020-07-29 15:15:26 --> Model Class Initialized
DEBUG - 2020-07-29 15:15:26 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:15:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:15:26 --> Final output sent to browser
DEBUG - 2020-07-29 15:15:26 --> Total execution time: 0.0272
INFO - 2020-07-29 15:15:55 --> Config Class Initialized
INFO - 2020-07-29 15:15:55 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:15:55 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:15:55 --> Utf8 Class Initialized
INFO - 2020-07-29 15:15:55 --> URI Class Initialized
INFO - 2020-07-29 15:15:55 --> Router Class Initialized
INFO - 2020-07-29 15:15:55 --> Output Class Initialized
INFO - 2020-07-29 15:15:55 --> Security Class Initialized
DEBUG - 2020-07-29 15:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:15:55 --> Input Class Initialized
INFO - 2020-07-29 15:15:55 --> Language Class Initialized
INFO - 2020-07-29 15:15:55 --> Loader Class Initialized
INFO - 2020-07-29 15:15:55 --> Helper loaded: url_helper
INFO - 2020-07-29 15:15:55 --> Database Driver Class Initialized
INFO - 2020-07-29 15:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:15:55 --> Email Class Initialized
INFO - 2020-07-29 15:15:55 --> Controller Class Initialized
INFO - 2020-07-29 15:15:55 --> Model Class Initialized
INFO - 2020-07-29 15:15:55 --> Model Class Initialized
DEBUG - 2020-07-29 15:15:55 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:15:55 --> Model Class Initialized
INFO - 2020-07-29 15:15:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-29 15:15:55 --> Final output sent to browser
DEBUG - 2020-07-29 15:15:55 --> Total execution time: 0.0207
INFO - 2020-07-29 15:16:00 --> Config Class Initialized
INFO - 2020-07-29 15:16:00 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:16:00 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:16:00 --> Utf8 Class Initialized
INFO - 2020-07-29 15:16:00 --> URI Class Initialized
INFO - 2020-07-29 15:16:00 --> Router Class Initialized
INFO - 2020-07-29 15:16:00 --> Output Class Initialized
INFO - 2020-07-29 15:16:00 --> Security Class Initialized
DEBUG - 2020-07-29 15:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:16:00 --> Input Class Initialized
INFO - 2020-07-29 15:16:00 --> Language Class Initialized
INFO - 2020-07-29 15:16:00 --> Loader Class Initialized
INFO - 2020-07-29 15:16:00 --> Helper loaded: url_helper
INFO - 2020-07-29 15:16:00 --> Database Driver Class Initialized
INFO - 2020-07-29 15:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:16:00 --> Email Class Initialized
INFO - 2020-07-29 15:16:00 --> Controller Class Initialized
INFO - 2020-07-29 15:16:00 --> Model Class Initialized
INFO - 2020-07-29 15:16:00 --> Model Class Initialized
DEBUG - 2020-07-29 15:16:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:16:00 --> Model Class Initialized
INFO - 2020-07-29 15:16:00 --> Final output sent to browser
DEBUG - 2020-07-29 15:16:00 --> Total execution time: 0.0220
INFO - 2020-07-29 15:17:45 --> Config Class Initialized
INFO - 2020-07-29 15:17:45 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:17:45 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:17:45 --> Utf8 Class Initialized
INFO - 2020-07-29 15:17:45 --> URI Class Initialized
INFO - 2020-07-29 15:17:45 --> Router Class Initialized
INFO - 2020-07-29 15:17:45 --> Output Class Initialized
INFO - 2020-07-29 15:17:45 --> Security Class Initialized
DEBUG - 2020-07-29 15:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:17:45 --> Input Class Initialized
INFO - 2020-07-29 15:17:45 --> Language Class Initialized
INFO - 2020-07-29 15:17:45 --> Loader Class Initialized
INFO - 2020-07-29 15:17:45 --> Helper loaded: url_helper
INFO - 2020-07-29 15:17:45 --> Database Driver Class Initialized
INFO - 2020-07-29 15:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:17:45 --> Email Class Initialized
INFO - 2020-07-29 15:17:45 --> Controller Class Initialized
INFO - 2020-07-29 15:17:45 --> Model Class Initialized
INFO - 2020-07-29 15:17:45 --> Model Class Initialized
DEBUG - 2020-07-29 15:17:45 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:17:45 --> Model Class Initialized
INFO - 2020-07-29 15:17:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-29 15:17:45 --> Final output sent to browser
DEBUG - 2020-07-29 15:17:45 --> Total execution time: 0.0247
INFO - 2020-07-29 15:17:48 --> Config Class Initialized
INFO - 2020-07-29 15:17:48 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:17:48 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:17:48 --> Utf8 Class Initialized
INFO - 2020-07-29 15:17:48 --> URI Class Initialized
INFO - 2020-07-29 15:17:48 --> Router Class Initialized
INFO - 2020-07-29 15:17:48 --> Output Class Initialized
INFO - 2020-07-29 15:17:48 --> Security Class Initialized
DEBUG - 2020-07-29 15:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:17:48 --> Input Class Initialized
INFO - 2020-07-29 15:17:48 --> Language Class Initialized
INFO - 2020-07-29 15:17:48 --> Loader Class Initialized
INFO - 2020-07-29 15:17:48 --> Helper loaded: url_helper
INFO - 2020-07-29 15:17:48 --> Database Driver Class Initialized
INFO - 2020-07-29 15:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:17:48 --> Email Class Initialized
INFO - 2020-07-29 15:17:48 --> Controller Class Initialized
INFO - 2020-07-29 15:17:48 --> Model Class Initialized
INFO - 2020-07-29 15:17:48 --> Model Class Initialized
DEBUG - 2020-07-29 15:17:48 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:17:48 --> Model Class Initialized
ERROR - 2020-07-29 15:17:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/User_reg.php:57) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 15:17:48 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::next_result() /home/purpu1ex/public_html/carsm/application/models/User.php 144
INFO - 2020-07-29 15:18:18 --> Config Class Initialized
INFO - 2020-07-29 15:18:18 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:18:18 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:18:18 --> Utf8 Class Initialized
INFO - 2020-07-29 15:18:18 --> URI Class Initialized
INFO - 2020-07-29 15:18:18 --> Router Class Initialized
INFO - 2020-07-29 15:18:18 --> Output Class Initialized
INFO - 2020-07-29 15:18:18 --> Security Class Initialized
DEBUG - 2020-07-29 15:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:18:18 --> Input Class Initialized
INFO - 2020-07-29 15:18:18 --> Language Class Initialized
INFO - 2020-07-29 15:18:18 --> Loader Class Initialized
INFO - 2020-07-29 15:18:18 --> Helper loaded: url_helper
INFO - 2020-07-29 15:18:18 --> Database Driver Class Initialized
INFO - 2020-07-29 15:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:18:18 --> Email Class Initialized
INFO - 2020-07-29 15:18:18 --> Controller Class Initialized
INFO - 2020-07-29 15:18:18 --> Model Class Initialized
INFO - 2020-07-29 15:18:18 --> Model Class Initialized
DEBUG - 2020-07-29 15:18:18 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:18:18 --> Model Class Initialized
INFO - 2020-07-29 15:18:18 --> Final output sent to browser
DEBUG - 2020-07-29 15:18:18 --> Total execution time: 0.0853
INFO - 2020-07-29 15:19:30 --> Config Class Initialized
INFO - 2020-07-29 15:19:30 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:19:30 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:19:30 --> Utf8 Class Initialized
INFO - 2020-07-29 15:19:30 --> URI Class Initialized
INFO - 2020-07-29 15:19:30 --> Router Class Initialized
INFO - 2020-07-29 15:19:30 --> Output Class Initialized
INFO - 2020-07-29 15:19:30 --> Security Class Initialized
DEBUG - 2020-07-29 15:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:19:30 --> Input Class Initialized
INFO - 2020-07-29 15:19:30 --> Language Class Initialized
INFO - 2020-07-29 15:19:30 --> Loader Class Initialized
INFO - 2020-07-29 15:19:30 --> Helper loaded: url_helper
INFO - 2020-07-29 15:19:30 --> Database Driver Class Initialized
INFO - 2020-07-29 15:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:19:30 --> Email Class Initialized
INFO - 2020-07-29 15:19:30 --> Controller Class Initialized
INFO - 2020-07-29 15:19:30 --> Model Class Initialized
INFO - 2020-07-29 15:19:30 --> Model Class Initialized
DEBUG - 2020-07-29 15:19:30 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:19:30 --> Model Class Initialized
INFO - 2020-07-29 15:19:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-29 15:19:30 --> Final output sent to browser
DEBUG - 2020-07-29 15:19:30 --> Total execution time: 0.0239
INFO - 2020-07-29 15:19:34 --> Config Class Initialized
INFO - 2020-07-29 15:19:34 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:19:34 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:19:34 --> Utf8 Class Initialized
INFO - 2020-07-29 15:19:34 --> URI Class Initialized
INFO - 2020-07-29 15:19:34 --> Router Class Initialized
INFO - 2020-07-29 15:19:34 --> Output Class Initialized
INFO - 2020-07-29 15:19:34 --> Security Class Initialized
DEBUG - 2020-07-29 15:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:19:34 --> Input Class Initialized
INFO - 2020-07-29 15:19:34 --> Language Class Initialized
INFO - 2020-07-29 15:19:34 --> Loader Class Initialized
INFO - 2020-07-29 15:19:34 --> Helper loaded: url_helper
INFO - 2020-07-29 15:19:34 --> Database Driver Class Initialized
INFO - 2020-07-29 15:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:19:34 --> Email Class Initialized
INFO - 2020-07-29 15:19:34 --> Controller Class Initialized
INFO - 2020-07-29 15:19:34 --> Model Class Initialized
INFO - 2020-07-29 15:19:34 --> Model Class Initialized
DEBUG - 2020-07-29 15:19:34 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:19:34 --> Model Class Initialized
ERROR - 2020-07-29 15:19:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/User_reg.php:57) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-29 15:20:26 --> Config Class Initialized
INFO - 2020-07-29 15:20:26 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:20:26 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:20:26 --> Utf8 Class Initialized
INFO - 2020-07-29 15:20:26 --> URI Class Initialized
INFO - 2020-07-29 15:20:26 --> Router Class Initialized
INFO - 2020-07-29 15:20:26 --> Output Class Initialized
INFO - 2020-07-29 15:20:26 --> Security Class Initialized
DEBUG - 2020-07-29 15:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:20:26 --> Input Class Initialized
INFO - 2020-07-29 15:20:26 --> Language Class Initialized
INFO - 2020-07-29 15:20:26 --> Loader Class Initialized
INFO - 2020-07-29 15:20:26 --> Helper loaded: url_helper
INFO - 2020-07-29 15:20:26 --> Database Driver Class Initialized
INFO - 2020-07-29 15:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:20:26 --> Email Class Initialized
INFO - 2020-07-29 15:20:26 --> Controller Class Initialized
INFO - 2020-07-29 15:20:26 --> Model Class Initialized
INFO - 2020-07-29 15:20:26 --> Model Class Initialized
DEBUG - 2020-07-29 15:20:26 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:20:26 --> Model Class Initialized
ERROR - 2020-07-29 15:20:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/User_reg.php:89) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-29 15:20:48 --> Config Class Initialized
INFO - 2020-07-29 15:20:48 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:20:48 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:20:48 --> Utf8 Class Initialized
INFO - 2020-07-29 15:20:48 --> URI Class Initialized
INFO - 2020-07-29 15:20:48 --> Router Class Initialized
INFO - 2020-07-29 15:20:48 --> Output Class Initialized
INFO - 2020-07-29 15:20:48 --> Security Class Initialized
DEBUG - 2020-07-29 15:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:20:48 --> Input Class Initialized
INFO - 2020-07-29 15:20:48 --> Language Class Initialized
INFO - 2020-07-29 15:20:48 --> Loader Class Initialized
INFO - 2020-07-29 15:20:48 --> Helper loaded: url_helper
INFO - 2020-07-29 15:20:48 --> Database Driver Class Initialized
INFO - 2020-07-29 15:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:20:48 --> Email Class Initialized
INFO - 2020-07-29 15:20:48 --> Controller Class Initialized
INFO - 2020-07-29 15:20:48 --> Model Class Initialized
INFO - 2020-07-29 15:20:48 --> Model Class Initialized
DEBUG - 2020-07-29 15:20:48 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:20:48 --> Model Class Initialized
INFO - 2020-07-29 15:20:48 --> Config Class Initialized
INFO - 2020-07-29 15:20:48 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:20:48 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:20:48 --> Utf8 Class Initialized
INFO - 2020-07-29 15:20:48 --> URI Class Initialized
DEBUG - 2020-07-29 15:20:48 --> No URI present. Default controller set.
INFO - 2020-07-29 15:20:48 --> Router Class Initialized
INFO - 2020-07-29 15:20:48 --> Output Class Initialized
INFO - 2020-07-29 15:20:49 --> Security Class Initialized
DEBUG - 2020-07-29 15:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:20:49 --> Input Class Initialized
INFO - 2020-07-29 15:20:49 --> Language Class Initialized
INFO - 2020-07-29 15:20:49 --> Loader Class Initialized
INFO - 2020-07-29 15:20:49 --> Helper loaded: url_helper
INFO - 2020-07-29 15:20:49 --> Database Driver Class Initialized
INFO - 2020-07-29 15:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:20:49 --> Email Class Initialized
INFO - 2020-07-29 15:20:49 --> Controller Class Initialized
INFO - 2020-07-29 15:20:49 --> Model Class Initialized
INFO - 2020-07-29 15:20:49 --> Model Class Initialized
DEBUG - 2020-07-29 15:20:49 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:20:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:20:49 --> Final output sent to browser
DEBUG - 2020-07-29 15:20:49 --> Total execution time: 0.0222
INFO - 2020-07-29 15:20:54 --> Config Class Initialized
INFO - 2020-07-29 15:20:54 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:20:54 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:20:54 --> Utf8 Class Initialized
INFO - 2020-07-29 15:20:54 --> URI Class Initialized
INFO - 2020-07-29 15:20:54 --> Router Class Initialized
INFO - 2020-07-29 15:20:54 --> Output Class Initialized
INFO - 2020-07-29 15:20:54 --> Security Class Initialized
DEBUG - 2020-07-29 15:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:20:54 --> Input Class Initialized
INFO - 2020-07-29 15:20:54 --> Language Class Initialized
INFO - 2020-07-29 15:20:54 --> Loader Class Initialized
INFO - 2020-07-29 15:20:54 --> Helper loaded: url_helper
INFO - 2020-07-29 15:20:54 --> Database Driver Class Initialized
INFO - 2020-07-29 15:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:20:54 --> Email Class Initialized
INFO - 2020-07-29 15:20:54 --> Controller Class Initialized
INFO - 2020-07-29 15:20:54 --> Model Class Initialized
INFO - 2020-07-29 15:20:54 --> Model Class Initialized
DEBUG - 2020-07-29 15:20:54 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:20:54 --> Model Class Initialized
INFO - 2020-07-29 15:20:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-29 15:20:54 --> Final output sent to browser
DEBUG - 2020-07-29 15:20:54 --> Total execution time: 0.0224
INFO - 2020-07-29 15:21:05 --> Config Class Initialized
INFO - 2020-07-29 15:21:05 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:21:05 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:21:05 --> Utf8 Class Initialized
INFO - 2020-07-29 15:21:05 --> URI Class Initialized
INFO - 2020-07-29 15:21:05 --> Router Class Initialized
INFO - 2020-07-29 15:21:05 --> Output Class Initialized
INFO - 2020-07-29 15:21:05 --> Security Class Initialized
DEBUG - 2020-07-29 15:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:21:05 --> Input Class Initialized
INFO - 2020-07-29 15:21:05 --> Language Class Initialized
INFO - 2020-07-29 15:21:05 --> Loader Class Initialized
INFO - 2020-07-29 15:21:05 --> Helper loaded: url_helper
INFO - 2020-07-29 15:21:05 --> Database Driver Class Initialized
INFO - 2020-07-29 15:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:21:05 --> Email Class Initialized
INFO - 2020-07-29 15:21:05 --> Controller Class Initialized
INFO - 2020-07-29 15:21:05 --> Model Class Initialized
INFO - 2020-07-29 15:21:05 --> Model Class Initialized
DEBUG - 2020-07-29 15:21:05 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:21:05 --> Model Class Initialized
INFO - 2020-07-29 15:21:06 --> Config Class Initialized
INFO - 2020-07-29 15:21:06 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:21:06 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:21:06 --> Utf8 Class Initialized
INFO - 2020-07-29 15:21:06 --> URI Class Initialized
DEBUG - 2020-07-29 15:21:06 --> No URI present. Default controller set.
INFO - 2020-07-29 15:21:06 --> Router Class Initialized
INFO - 2020-07-29 15:21:06 --> Output Class Initialized
INFO - 2020-07-29 15:21:06 --> Security Class Initialized
DEBUG - 2020-07-29 15:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:21:06 --> Input Class Initialized
INFO - 2020-07-29 15:21:06 --> Language Class Initialized
INFO - 2020-07-29 15:21:06 --> Loader Class Initialized
INFO - 2020-07-29 15:21:06 --> Helper loaded: url_helper
INFO - 2020-07-29 15:21:06 --> Database Driver Class Initialized
INFO - 2020-07-29 15:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:21:06 --> Email Class Initialized
INFO - 2020-07-29 15:21:06 --> Controller Class Initialized
INFO - 2020-07-29 15:21:06 --> Model Class Initialized
INFO - 2020-07-29 15:21:06 --> Model Class Initialized
DEBUG - 2020-07-29 15:21:06 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:21:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:21:06 --> Final output sent to browser
DEBUG - 2020-07-29 15:21:06 --> Total execution time: 0.0230
INFO - 2020-07-29 15:22:39 --> Config Class Initialized
INFO - 2020-07-29 15:22:39 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:22:39 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:22:39 --> Utf8 Class Initialized
INFO - 2020-07-29 15:22:39 --> URI Class Initialized
INFO - 2020-07-29 15:22:39 --> Router Class Initialized
INFO - 2020-07-29 15:22:39 --> Output Class Initialized
INFO - 2020-07-29 15:22:39 --> Security Class Initialized
DEBUG - 2020-07-29 15:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:22:39 --> Input Class Initialized
INFO - 2020-07-29 15:22:39 --> Language Class Initialized
INFO - 2020-07-29 15:22:39 --> Loader Class Initialized
INFO - 2020-07-29 15:22:39 --> Helper loaded: url_helper
INFO - 2020-07-29 15:22:39 --> Database Driver Class Initialized
INFO - 2020-07-29 15:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:22:39 --> Email Class Initialized
INFO - 2020-07-29 15:22:39 --> Controller Class Initialized
INFO - 2020-07-29 15:22:39 --> Model Class Initialized
INFO - 2020-07-29 15:22:39 --> Model Class Initialized
DEBUG - 2020-07-29 15:22:39 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:22:39 --> Config Class Initialized
INFO - 2020-07-29 15:22:39 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:22:39 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:22:39 --> Utf8 Class Initialized
INFO - 2020-07-29 15:22:39 --> URI Class Initialized
INFO - 2020-07-29 15:22:39 --> Router Class Initialized
INFO - 2020-07-29 15:22:39 --> Output Class Initialized
INFO - 2020-07-29 15:22:39 --> Security Class Initialized
DEBUG - 2020-07-29 15:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:22:39 --> Input Class Initialized
INFO - 2020-07-29 15:22:39 --> Language Class Initialized
INFO - 2020-07-29 15:22:39 --> Loader Class Initialized
INFO - 2020-07-29 15:22:39 --> Helper loaded: url_helper
INFO - 2020-07-29 15:22:39 --> Database Driver Class Initialized
INFO - 2020-07-29 15:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:22:39 --> Email Class Initialized
INFO - 2020-07-29 15:22:39 --> Controller Class Initialized
DEBUG - 2020-07-29 15:22:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 15:22:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:22:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 15:22:39 --> Final output sent to browser
DEBUG - 2020-07-29 15:22:39 --> Total execution time: 0.0246
INFO - 2020-07-29 15:22:44 --> Config Class Initialized
INFO - 2020-07-29 15:22:44 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:22:44 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:22:44 --> Utf8 Class Initialized
INFO - 2020-07-29 15:22:44 --> URI Class Initialized
DEBUG - 2020-07-29 15:22:44 --> No URI present. Default controller set.
INFO - 2020-07-29 15:22:44 --> Router Class Initialized
INFO - 2020-07-29 15:22:44 --> Output Class Initialized
INFO - 2020-07-29 15:22:44 --> Security Class Initialized
DEBUG - 2020-07-29 15:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:22:44 --> Input Class Initialized
INFO - 2020-07-29 15:22:44 --> Language Class Initialized
INFO - 2020-07-29 15:22:44 --> Loader Class Initialized
INFO - 2020-07-29 15:22:44 --> Helper loaded: url_helper
INFO - 2020-07-29 15:22:44 --> Database Driver Class Initialized
INFO - 2020-07-29 15:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:22:44 --> Email Class Initialized
INFO - 2020-07-29 15:22:44 --> Controller Class Initialized
INFO - 2020-07-29 15:22:44 --> Model Class Initialized
INFO - 2020-07-29 15:22:44 --> Model Class Initialized
DEBUG - 2020-07-29 15:22:44 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:22:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:22:44 --> Final output sent to browser
DEBUG - 2020-07-29 15:22:44 --> Total execution time: 0.0257
INFO - 2020-07-29 15:22:47 --> Config Class Initialized
INFO - 2020-07-29 15:22:47 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:22:47 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:22:47 --> Utf8 Class Initialized
INFO - 2020-07-29 15:22:47 --> URI Class Initialized
INFO - 2020-07-29 15:22:47 --> Router Class Initialized
INFO - 2020-07-29 15:22:47 --> Output Class Initialized
INFO - 2020-07-29 15:22:47 --> Security Class Initialized
DEBUG - 2020-07-29 15:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:22:47 --> Input Class Initialized
INFO - 2020-07-29 15:22:47 --> Language Class Initialized
INFO - 2020-07-29 15:22:47 --> Loader Class Initialized
INFO - 2020-07-29 15:22:47 --> Helper loaded: url_helper
INFO - 2020-07-29 15:22:47 --> Database Driver Class Initialized
INFO - 2020-07-29 15:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:22:47 --> Email Class Initialized
INFO - 2020-07-29 15:22:47 --> Controller Class Initialized
INFO - 2020-07-29 15:22:47 --> Model Class Initialized
INFO - 2020-07-29 15:22:47 --> Model Class Initialized
DEBUG - 2020-07-29 15:22:47 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:22:47 --> Model Class Initialized
INFO - 2020-07-29 15:22:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-29 15:22:47 --> Final output sent to browser
DEBUG - 2020-07-29 15:22:47 --> Total execution time: 0.0232
INFO - 2020-07-29 15:22:59 --> Config Class Initialized
INFO - 2020-07-29 15:22:59 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:22:59 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:22:59 --> Utf8 Class Initialized
INFO - 2020-07-29 15:22:59 --> URI Class Initialized
DEBUG - 2020-07-29 15:22:59 --> No URI present. Default controller set.
INFO - 2020-07-29 15:22:59 --> Router Class Initialized
INFO - 2020-07-29 15:22:59 --> Output Class Initialized
INFO - 2020-07-29 15:22:59 --> Security Class Initialized
DEBUG - 2020-07-29 15:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:22:59 --> Input Class Initialized
INFO - 2020-07-29 15:22:59 --> Language Class Initialized
INFO - 2020-07-29 15:22:59 --> Loader Class Initialized
INFO - 2020-07-29 15:22:59 --> Helper loaded: url_helper
INFO - 2020-07-29 15:22:59 --> Database Driver Class Initialized
INFO - 2020-07-29 15:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:22:59 --> Email Class Initialized
INFO - 2020-07-29 15:22:59 --> Controller Class Initialized
INFO - 2020-07-29 15:22:59 --> Model Class Initialized
INFO - 2020-07-29 15:22:59 --> Model Class Initialized
DEBUG - 2020-07-29 15:22:59 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:22:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:22:59 --> Final output sent to browser
DEBUG - 2020-07-29 15:22:59 --> Total execution time: 0.0221
INFO - 2020-07-29 15:24:21 --> Config Class Initialized
INFO - 2020-07-29 15:24:21 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:24:21 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:24:21 --> Utf8 Class Initialized
INFO - 2020-07-29 15:24:21 --> URI Class Initialized
INFO - 2020-07-29 15:24:21 --> Router Class Initialized
INFO - 2020-07-29 15:24:21 --> Output Class Initialized
INFO - 2020-07-29 15:24:21 --> Security Class Initialized
DEBUG - 2020-07-29 15:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:24:21 --> Input Class Initialized
INFO - 2020-07-29 15:24:21 --> Language Class Initialized
INFO - 2020-07-29 15:24:21 --> Loader Class Initialized
INFO - 2020-07-29 15:24:21 --> Helper loaded: url_helper
INFO - 2020-07-29 15:24:21 --> Database Driver Class Initialized
INFO - 2020-07-29 15:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:24:21 --> Email Class Initialized
INFO - 2020-07-29 15:24:21 --> Controller Class Initialized
INFO - 2020-07-29 15:24:21 --> Model Class Initialized
INFO - 2020-07-29 15:24:21 --> Model Class Initialized
DEBUG - 2020-07-29 15:24:21 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:24:21 --> Model Class Initialized
INFO - 2020-07-29 15:24:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-29 15:24:21 --> Final output sent to browser
DEBUG - 2020-07-29 15:24:21 --> Total execution time: 0.0213
INFO - 2020-07-29 15:31:25 --> Config Class Initialized
INFO - 2020-07-29 15:31:25 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:31:25 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:31:25 --> Utf8 Class Initialized
INFO - 2020-07-29 15:31:25 --> URI Class Initialized
INFO - 2020-07-29 15:31:25 --> Router Class Initialized
INFO - 2020-07-29 15:31:25 --> Output Class Initialized
INFO - 2020-07-29 15:31:25 --> Security Class Initialized
DEBUG - 2020-07-29 15:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:31:25 --> Input Class Initialized
INFO - 2020-07-29 15:31:25 --> Language Class Initialized
INFO - 2020-07-29 15:31:25 --> Loader Class Initialized
INFO - 2020-07-29 15:31:25 --> Helper loaded: url_helper
INFO - 2020-07-29 15:31:25 --> Database Driver Class Initialized
INFO - 2020-07-29 15:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:31:25 --> Email Class Initialized
INFO - 2020-07-29 15:31:25 --> Controller Class Initialized
INFO - 2020-07-29 15:31:25 --> Model Class Initialized
INFO - 2020-07-29 15:31:25 --> Model Class Initialized
DEBUG - 2020-07-29 15:31:25 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:31:26 --> Config Class Initialized
INFO - 2020-07-29 15:31:26 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:31:26 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:31:26 --> Utf8 Class Initialized
INFO - 2020-07-29 15:31:26 --> URI Class Initialized
DEBUG - 2020-07-29 15:31:26 --> No URI present. Default controller set.
INFO - 2020-07-29 15:31:26 --> Router Class Initialized
INFO - 2020-07-29 15:31:26 --> Output Class Initialized
INFO - 2020-07-29 15:31:26 --> Security Class Initialized
DEBUG - 2020-07-29 15:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:31:26 --> Input Class Initialized
INFO - 2020-07-29 15:31:26 --> Language Class Initialized
INFO - 2020-07-29 15:31:26 --> Loader Class Initialized
INFO - 2020-07-29 15:31:26 --> Helper loaded: url_helper
INFO - 2020-07-29 15:31:26 --> Database Driver Class Initialized
INFO - 2020-07-29 15:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:31:26 --> Email Class Initialized
INFO - 2020-07-29 15:31:26 --> Controller Class Initialized
INFO - 2020-07-29 15:31:26 --> Model Class Initialized
INFO - 2020-07-29 15:31:26 --> Model Class Initialized
DEBUG - 2020-07-29 15:31:26 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:31:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:31:26 --> Final output sent to browser
DEBUG - 2020-07-29 15:31:26 --> Total execution time: 0.0224
INFO - 2020-07-29 15:34:30 --> Config Class Initialized
INFO - 2020-07-29 15:34:30 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:34:30 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:34:30 --> Utf8 Class Initialized
INFO - 2020-07-29 15:34:30 --> URI Class Initialized
INFO - 2020-07-29 15:34:30 --> Router Class Initialized
INFO - 2020-07-29 15:34:30 --> Output Class Initialized
INFO - 2020-07-29 15:34:30 --> Security Class Initialized
DEBUG - 2020-07-29 15:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:34:30 --> Input Class Initialized
INFO - 2020-07-29 15:34:30 --> Language Class Initialized
INFO - 2020-07-29 15:34:30 --> Loader Class Initialized
INFO - 2020-07-29 15:34:30 --> Helper loaded: url_helper
INFO - 2020-07-29 15:34:30 --> Database Driver Class Initialized
INFO - 2020-07-29 15:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:34:30 --> Email Class Initialized
INFO - 2020-07-29 15:34:30 --> Controller Class Initialized
INFO - 2020-07-29 15:34:30 --> Model Class Initialized
INFO - 2020-07-29 15:34:30 --> Model Class Initialized
DEBUG - 2020-07-29 15:34:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 15:34:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:34:31 --> Config Class Initialized
INFO - 2020-07-29 15:34:31 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:34:31 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:34:31 --> Utf8 Class Initialized
INFO - 2020-07-29 15:34:31 --> URI Class Initialized
DEBUG - 2020-07-29 15:34:31 --> No URI present. Default controller set.
INFO - 2020-07-29 15:34:31 --> Router Class Initialized
INFO - 2020-07-29 15:34:31 --> Output Class Initialized
INFO - 2020-07-29 15:34:31 --> Security Class Initialized
DEBUG - 2020-07-29 15:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:34:31 --> Input Class Initialized
INFO - 2020-07-29 15:34:31 --> Language Class Initialized
INFO - 2020-07-29 15:34:31 --> Loader Class Initialized
INFO - 2020-07-29 15:34:31 --> Helper loaded: url_helper
INFO - 2020-07-29 15:34:31 --> Database Driver Class Initialized
INFO - 2020-07-29 15:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:34:31 --> Email Class Initialized
INFO - 2020-07-29 15:34:31 --> Controller Class Initialized
INFO - 2020-07-29 15:34:31 --> Model Class Initialized
INFO - 2020-07-29 15:34:31 --> Model Class Initialized
DEBUG - 2020-07-29 15:34:31 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:34:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:34:31 --> Final output sent to browser
DEBUG - 2020-07-29 15:34:31 --> Total execution time: 0.0233
INFO - 2020-07-29 15:34:33 --> Config Class Initialized
INFO - 2020-07-29 15:34:33 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:34:33 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:34:33 --> Utf8 Class Initialized
INFO - 2020-07-29 15:34:33 --> URI Class Initialized
INFO - 2020-07-29 15:34:33 --> Router Class Initialized
INFO - 2020-07-29 15:34:33 --> Output Class Initialized
INFO - 2020-07-29 15:34:33 --> Security Class Initialized
DEBUG - 2020-07-29 15:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:34:33 --> Input Class Initialized
INFO - 2020-07-29 15:34:33 --> Language Class Initialized
INFO - 2020-07-29 15:34:33 --> Loader Class Initialized
INFO - 2020-07-29 15:34:33 --> Helper loaded: url_helper
INFO - 2020-07-29 15:34:33 --> Database Driver Class Initialized
INFO - 2020-07-29 15:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:34:33 --> Email Class Initialized
INFO - 2020-07-29 15:34:33 --> Controller Class Initialized
INFO - 2020-07-29 15:34:33 --> Model Class Initialized
INFO - 2020-07-29 15:34:33 --> Model Class Initialized
DEBUG - 2020-07-29 15:34:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 15:34:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:34:34 --> Config Class Initialized
INFO - 2020-07-29 15:34:34 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:34:34 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:34:34 --> Utf8 Class Initialized
INFO - 2020-07-29 15:34:34 --> URI Class Initialized
DEBUG - 2020-07-29 15:34:34 --> No URI present. Default controller set.
INFO - 2020-07-29 15:34:34 --> Router Class Initialized
INFO - 2020-07-29 15:34:34 --> Output Class Initialized
INFO - 2020-07-29 15:34:34 --> Security Class Initialized
DEBUG - 2020-07-29 15:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:34:34 --> Input Class Initialized
INFO - 2020-07-29 15:34:34 --> Language Class Initialized
INFO - 2020-07-29 15:34:34 --> Loader Class Initialized
INFO - 2020-07-29 15:34:34 --> Helper loaded: url_helper
INFO - 2020-07-29 15:34:34 --> Database Driver Class Initialized
INFO - 2020-07-29 15:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:34:34 --> Email Class Initialized
INFO - 2020-07-29 15:34:34 --> Controller Class Initialized
INFO - 2020-07-29 15:34:34 --> Model Class Initialized
INFO - 2020-07-29 15:34:34 --> Model Class Initialized
DEBUG - 2020-07-29 15:34:34 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:34:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:34:34 --> Final output sent to browser
DEBUG - 2020-07-29 15:34:34 --> Total execution time: 0.0216
INFO - 2020-07-29 15:34:36 --> Config Class Initialized
INFO - 2020-07-29 15:34:36 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:34:36 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:34:36 --> Utf8 Class Initialized
INFO - 2020-07-29 15:34:36 --> URI Class Initialized
INFO - 2020-07-29 15:34:36 --> Router Class Initialized
INFO - 2020-07-29 15:34:36 --> Output Class Initialized
INFO - 2020-07-29 15:34:36 --> Security Class Initialized
DEBUG - 2020-07-29 15:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:34:36 --> Input Class Initialized
INFO - 2020-07-29 15:34:36 --> Language Class Initialized
INFO - 2020-07-29 15:34:36 --> Loader Class Initialized
INFO - 2020-07-29 15:34:36 --> Helper loaded: url_helper
INFO - 2020-07-29 15:34:36 --> Database Driver Class Initialized
INFO - 2020-07-29 15:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:34:36 --> Email Class Initialized
INFO - 2020-07-29 15:34:36 --> Controller Class Initialized
INFO - 2020-07-29 15:34:36 --> Model Class Initialized
INFO - 2020-07-29 15:34:36 --> Model Class Initialized
DEBUG - 2020-07-29 15:34:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 15:34:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:34:36 --> Config Class Initialized
INFO - 2020-07-29 15:34:36 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:34:36 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:34:36 --> Utf8 Class Initialized
INFO - 2020-07-29 15:34:36 --> URI Class Initialized
DEBUG - 2020-07-29 15:34:36 --> No URI present. Default controller set.
INFO - 2020-07-29 15:34:36 --> Router Class Initialized
INFO - 2020-07-29 15:34:36 --> Output Class Initialized
INFO - 2020-07-29 15:34:36 --> Security Class Initialized
DEBUG - 2020-07-29 15:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:34:36 --> Input Class Initialized
INFO - 2020-07-29 15:34:36 --> Language Class Initialized
INFO - 2020-07-29 15:34:36 --> Loader Class Initialized
INFO - 2020-07-29 15:34:36 --> Helper loaded: url_helper
INFO - 2020-07-29 15:34:36 --> Database Driver Class Initialized
INFO - 2020-07-29 15:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:34:36 --> Email Class Initialized
INFO - 2020-07-29 15:34:36 --> Controller Class Initialized
INFO - 2020-07-29 15:34:36 --> Model Class Initialized
INFO - 2020-07-29 15:34:36 --> Model Class Initialized
DEBUG - 2020-07-29 15:34:36 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:34:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:34:36 --> Final output sent to browser
DEBUG - 2020-07-29 15:34:36 --> Total execution time: 0.0233
INFO - 2020-07-29 15:34:40 --> Config Class Initialized
INFO - 2020-07-29 15:34:40 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:34:40 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:34:40 --> Utf8 Class Initialized
INFO - 2020-07-29 15:34:40 --> URI Class Initialized
INFO - 2020-07-29 15:34:40 --> Router Class Initialized
INFO - 2020-07-29 15:34:40 --> Output Class Initialized
INFO - 2020-07-29 15:34:40 --> Security Class Initialized
DEBUG - 2020-07-29 15:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:34:40 --> Input Class Initialized
INFO - 2020-07-29 15:34:40 --> Language Class Initialized
INFO - 2020-07-29 15:34:40 --> Loader Class Initialized
INFO - 2020-07-29 15:34:40 --> Helper loaded: url_helper
INFO - 2020-07-29 15:34:40 --> Database Driver Class Initialized
INFO - 2020-07-29 15:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:34:40 --> Email Class Initialized
INFO - 2020-07-29 15:34:40 --> Controller Class Initialized
INFO - 2020-07-29 15:34:40 --> Model Class Initialized
INFO - 2020-07-29 15:34:40 --> Model Class Initialized
DEBUG - 2020-07-29 15:34:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 15:34:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:34:40 --> Config Class Initialized
INFO - 2020-07-29 15:34:40 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:34:40 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:34:40 --> Utf8 Class Initialized
INFO - 2020-07-29 15:34:40 --> URI Class Initialized
DEBUG - 2020-07-29 15:34:40 --> No URI present. Default controller set.
INFO - 2020-07-29 15:34:40 --> Router Class Initialized
INFO - 2020-07-29 15:34:40 --> Output Class Initialized
INFO - 2020-07-29 15:34:40 --> Security Class Initialized
DEBUG - 2020-07-29 15:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:34:40 --> Input Class Initialized
INFO - 2020-07-29 15:34:40 --> Language Class Initialized
INFO - 2020-07-29 15:34:40 --> Loader Class Initialized
INFO - 2020-07-29 15:34:40 --> Helper loaded: url_helper
INFO - 2020-07-29 15:34:40 --> Database Driver Class Initialized
INFO - 2020-07-29 15:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:34:40 --> Email Class Initialized
INFO - 2020-07-29 15:34:40 --> Controller Class Initialized
INFO - 2020-07-29 15:34:40 --> Model Class Initialized
INFO - 2020-07-29 15:34:40 --> Model Class Initialized
DEBUG - 2020-07-29 15:34:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:34:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:34:40 --> Final output sent to browser
DEBUG - 2020-07-29 15:34:40 --> Total execution time: 0.0235
INFO - 2020-07-29 15:34:57 --> Config Class Initialized
INFO - 2020-07-29 15:34:57 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:34:57 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:34:57 --> Utf8 Class Initialized
INFO - 2020-07-29 15:34:57 --> URI Class Initialized
DEBUG - 2020-07-29 15:34:57 --> No URI present. Default controller set.
INFO - 2020-07-29 15:34:57 --> Router Class Initialized
INFO - 2020-07-29 15:34:57 --> Output Class Initialized
INFO - 2020-07-29 15:34:57 --> Security Class Initialized
DEBUG - 2020-07-29 15:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:34:57 --> Input Class Initialized
INFO - 2020-07-29 15:34:57 --> Language Class Initialized
INFO - 2020-07-29 15:34:57 --> Loader Class Initialized
INFO - 2020-07-29 15:34:57 --> Helper loaded: url_helper
INFO - 2020-07-29 15:34:57 --> Database Driver Class Initialized
INFO - 2020-07-29 15:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:34:57 --> Email Class Initialized
INFO - 2020-07-29 15:34:57 --> Controller Class Initialized
INFO - 2020-07-29 15:34:57 --> Model Class Initialized
INFO - 2020-07-29 15:34:57 --> Model Class Initialized
DEBUG - 2020-07-29 15:34:57 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:34:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:34:57 --> Final output sent to browser
DEBUG - 2020-07-29 15:34:57 --> Total execution time: 0.0228
INFO - 2020-07-29 15:34:59 --> Config Class Initialized
INFO - 2020-07-29 15:34:59 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:34:59 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:34:59 --> Utf8 Class Initialized
INFO - 2020-07-29 15:34:59 --> URI Class Initialized
INFO - 2020-07-29 15:34:59 --> Router Class Initialized
INFO - 2020-07-29 15:34:59 --> Output Class Initialized
INFO - 2020-07-29 15:34:59 --> Security Class Initialized
DEBUG - 2020-07-29 15:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:34:59 --> Input Class Initialized
INFO - 2020-07-29 15:34:59 --> Language Class Initialized
INFO - 2020-07-29 15:34:59 --> Loader Class Initialized
INFO - 2020-07-29 15:34:59 --> Helper loaded: url_helper
INFO - 2020-07-29 15:34:59 --> Database Driver Class Initialized
INFO - 2020-07-29 15:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:34:59 --> Email Class Initialized
INFO - 2020-07-29 15:34:59 --> Controller Class Initialized
INFO - 2020-07-29 15:34:59 --> Model Class Initialized
INFO - 2020-07-29 15:34:59 --> Model Class Initialized
DEBUG - 2020-07-29 15:34:59 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:34:59 --> Config Class Initialized
INFO - 2020-07-29 15:34:59 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:34:59 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:34:59 --> Utf8 Class Initialized
INFO - 2020-07-29 15:34:59 --> URI Class Initialized
DEBUG - 2020-07-29 15:34:59 --> No URI present. Default controller set.
INFO - 2020-07-29 15:34:59 --> Router Class Initialized
INFO - 2020-07-29 15:34:59 --> Output Class Initialized
INFO - 2020-07-29 15:34:59 --> Security Class Initialized
DEBUG - 2020-07-29 15:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:34:59 --> Input Class Initialized
INFO - 2020-07-29 15:34:59 --> Language Class Initialized
INFO - 2020-07-29 15:34:59 --> Loader Class Initialized
INFO - 2020-07-29 15:34:59 --> Helper loaded: url_helper
INFO - 2020-07-29 15:34:59 --> Database Driver Class Initialized
INFO - 2020-07-29 15:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:34:59 --> Email Class Initialized
INFO - 2020-07-29 15:34:59 --> Controller Class Initialized
INFO - 2020-07-29 15:34:59 --> Model Class Initialized
INFO - 2020-07-29 15:34:59 --> Model Class Initialized
DEBUG - 2020-07-29 15:34:59 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:34:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:34:59 --> Final output sent to browser
DEBUG - 2020-07-29 15:34:59 --> Total execution time: 0.0224
INFO - 2020-07-29 15:35:00 --> Config Class Initialized
INFO - 2020-07-29 15:35:00 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:35:00 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:35:00 --> Utf8 Class Initialized
INFO - 2020-07-29 15:35:00 --> URI Class Initialized
INFO - 2020-07-29 15:35:00 --> Router Class Initialized
INFO - 2020-07-29 15:35:00 --> Output Class Initialized
INFO - 2020-07-29 15:35:00 --> Security Class Initialized
DEBUG - 2020-07-29 15:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:35:00 --> Input Class Initialized
INFO - 2020-07-29 15:35:00 --> Language Class Initialized
INFO - 2020-07-29 15:35:00 --> Loader Class Initialized
INFO - 2020-07-29 15:35:00 --> Helper loaded: url_helper
INFO - 2020-07-29 15:35:00 --> Database Driver Class Initialized
INFO - 2020-07-29 15:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:35:00 --> Email Class Initialized
INFO - 2020-07-29 15:35:00 --> Controller Class Initialized
INFO - 2020-07-29 15:35:00 --> Model Class Initialized
INFO - 2020-07-29 15:35:00 --> Model Class Initialized
DEBUG - 2020-07-29 15:35:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:35:01 --> Config Class Initialized
INFO - 2020-07-29 15:35:01 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:35:01 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:35:01 --> Utf8 Class Initialized
INFO - 2020-07-29 15:35:01 --> URI Class Initialized
DEBUG - 2020-07-29 15:35:01 --> No URI present. Default controller set.
INFO - 2020-07-29 15:35:01 --> Router Class Initialized
INFO - 2020-07-29 15:35:01 --> Output Class Initialized
INFO - 2020-07-29 15:35:01 --> Security Class Initialized
DEBUG - 2020-07-29 15:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:35:01 --> Input Class Initialized
INFO - 2020-07-29 15:35:01 --> Language Class Initialized
INFO - 2020-07-29 15:35:01 --> Loader Class Initialized
INFO - 2020-07-29 15:35:01 --> Helper loaded: url_helper
INFO - 2020-07-29 15:35:01 --> Database Driver Class Initialized
INFO - 2020-07-29 15:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:35:01 --> Email Class Initialized
INFO - 2020-07-29 15:35:01 --> Controller Class Initialized
INFO - 2020-07-29 15:35:01 --> Model Class Initialized
INFO - 2020-07-29 15:35:01 --> Model Class Initialized
DEBUG - 2020-07-29 15:35:01 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:35:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:35:01 --> Final output sent to browser
DEBUG - 2020-07-29 15:35:01 --> Total execution time: 0.0234
INFO - 2020-07-29 15:35:16 --> Config Class Initialized
INFO - 2020-07-29 15:35:16 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:35:16 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:35:16 --> Utf8 Class Initialized
INFO - 2020-07-29 15:35:16 --> URI Class Initialized
INFO - 2020-07-29 15:35:16 --> Router Class Initialized
INFO - 2020-07-29 15:35:16 --> Output Class Initialized
INFO - 2020-07-29 15:35:16 --> Security Class Initialized
DEBUG - 2020-07-29 15:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:35:16 --> Input Class Initialized
INFO - 2020-07-29 15:35:16 --> Language Class Initialized
INFO - 2020-07-29 15:35:16 --> Loader Class Initialized
INFO - 2020-07-29 15:35:16 --> Helper loaded: url_helper
INFO - 2020-07-29 15:35:16 --> Database Driver Class Initialized
INFO - 2020-07-29 15:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:35:16 --> Email Class Initialized
INFO - 2020-07-29 15:35:16 --> Controller Class Initialized
INFO - 2020-07-29 15:35:16 --> Model Class Initialized
INFO - 2020-07-29 15:35:16 --> Model Class Initialized
DEBUG - 2020-07-29 15:35:16 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:35:17 --> Config Class Initialized
INFO - 2020-07-29 15:35:17 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:35:17 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:35:17 --> Utf8 Class Initialized
INFO - 2020-07-29 15:35:17 --> URI Class Initialized
DEBUG - 2020-07-29 15:35:17 --> No URI present. Default controller set.
INFO - 2020-07-29 15:35:17 --> Router Class Initialized
INFO - 2020-07-29 15:35:17 --> Output Class Initialized
INFO - 2020-07-29 15:35:17 --> Security Class Initialized
DEBUG - 2020-07-29 15:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:35:17 --> Input Class Initialized
INFO - 2020-07-29 15:35:17 --> Language Class Initialized
INFO - 2020-07-29 15:35:17 --> Loader Class Initialized
INFO - 2020-07-29 15:35:17 --> Helper loaded: url_helper
INFO - 2020-07-29 15:35:17 --> Database Driver Class Initialized
INFO - 2020-07-29 15:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:35:17 --> Email Class Initialized
INFO - 2020-07-29 15:35:17 --> Controller Class Initialized
INFO - 2020-07-29 15:35:17 --> Model Class Initialized
INFO - 2020-07-29 15:35:17 --> Model Class Initialized
DEBUG - 2020-07-29 15:35:17 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:35:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:35:17 --> Final output sent to browser
DEBUG - 2020-07-29 15:35:17 --> Total execution time: 0.0185
INFO - 2020-07-29 15:35:20 --> Config Class Initialized
INFO - 2020-07-29 15:35:20 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:35:20 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:35:20 --> Utf8 Class Initialized
INFO - 2020-07-29 15:35:20 --> URI Class Initialized
INFO - 2020-07-29 15:35:20 --> Router Class Initialized
INFO - 2020-07-29 15:35:20 --> Output Class Initialized
INFO - 2020-07-29 15:35:20 --> Security Class Initialized
DEBUG - 2020-07-29 15:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:35:20 --> Input Class Initialized
INFO - 2020-07-29 15:35:20 --> Language Class Initialized
INFO - 2020-07-29 15:35:20 --> Loader Class Initialized
INFO - 2020-07-29 15:35:20 --> Helper loaded: url_helper
INFO - 2020-07-29 15:35:20 --> Database Driver Class Initialized
INFO - 2020-07-29 15:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:35:20 --> Email Class Initialized
INFO - 2020-07-29 15:35:20 --> Controller Class Initialized
INFO - 2020-07-29 15:35:20 --> Model Class Initialized
INFO - 2020-07-29 15:35:20 --> Model Class Initialized
DEBUG - 2020-07-29 15:35:20 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:35:21 --> Config Class Initialized
INFO - 2020-07-29 15:35:21 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:35:21 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:35:21 --> Utf8 Class Initialized
INFO - 2020-07-29 15:35:21 --> URI Class Initialized
INFO - 2020-07-29 15:35:21 --> Router Class Initialized
INFO - 2020-07-29 15:35:21 --> Output Class Initialized
INFO - 2020-07-29 15:35:21 --> Security Class Initialized
DEBUG - 2020-07-29 15:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:35:21 --> Input Class Initialized
INFO - 2020-07-29 15:35:21 --> Language Class Initialized
INFO - 2020-07-29 15:35:21 --> Loader Class Initialized
INFO - 2020-07-29 15:35:21 --> Helper loaded: url_helper
INFO - 2020-07-29 15:35:21 --> Database Driver Class Initialized
INFO - 2020-07-29 15:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:35:21 --> Email Class Initialized
INFO - 2020-07-29 15:35:21 --> Controller Class Initialized
DEBUG - 2020-07-29 15:35:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 15:35:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:35:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 15:35:21 --> Final output sent to browser
DEBUG - 2020-07-29 15:35:21 --> Total execution time: 0.0216
INFO - 2020-07-29 15:35:26 --> Config Class Initialized
INFO - 2020-07-29 15:35:26 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:35:26 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:35:26 --> Utf8 Class Initialized
INFO - 2020-07-29 15:35:26 --> URI Class Initialized
DEBUG - 2020-07-29 15:35:26 --> No URI present. Default controller set.
INFO - 2020-07-29 15:35:26 --> Router Class Initialized
INFO - 2020-07-29 15:35:26 --> Output Class Initialized
INFO - 2020-07-29 15:35:26 --> Security Class Initialized
DEBUG - 2020-07-29 15:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:35:26 --> Input Class Initialized
INFO - 2020-07-29 15:35:26 --> Language Class Initialized
INFO - 2020-07-29 15:35:26 --> Loader Class Initialized
INFO - 2020-07-29 15:35:26 --> Helper loaded: url_helper
INFO - 2020-07-29 15:35:26 --> Database Driver Class Initialized
INFO - 2020-07-29 15:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:35:26 --> Email Class Initialized
INFO - 2020-07-29 15:35:26 --> Controller Class Initialized
INFO - 2020-07-29 15:35:26 --> Model Class Initialized
INFO - 2020-07-29 15:35:26 --> Model Class Initialized
DEBUG - 2020-07-29 15:35:26 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:35:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:35:26 --> Final output sent to browser
DEBUG - 2020-07-29 15:35:26 --> Total execution time: 0.0231
INFO - 2020-07-29 15:35:28 --> Config Class Initialized
INFO - 2020-07-29 15:35:28 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:35:28 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:35:28 --> Utf8 Class Initialized
INFO - 2020-07-29 15:35:28 --> URI Class Initialized
INFO - 2020-07-29 15:35:28 --> Router Class Initialized
INFO - 2020-07-29 15:35:28 --> Output Class Initialized
INFO - 2020-07-29 15:35:28 --> Security Class Initialized
DEBUG - 2020-07-29 15:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:35:28 --> Input Class Initialized
INFO - 2020-07-29 15:35:28 --> Language Class Initialized
INFO - 2020-07-29 15:35:28 --> Loader Class Initialized
INFO - 2020-07-29 15:35:28 --> Helper loaded: url_helper
INFO - 2020-07-29 15:35:28 --> Database Driver Class Initialized
INFO - 2020-07-29 15:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:35:28 --> Email Class Initialized
INFO - 2020-07-29 15:35:28 --> Controller Class Initialized
INFO - 2020-07-29 15:35:28 --> Model Class Initialized
INFO - 2020-07-29 15:35:28 --> Model Class Initialized
DEBUG - 2020-07-29 15:35:28 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:35:28 --> Model Class Initialized
INFO - 2020-07-29 15:35:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-29 15:35:28 --> Final output sent to browser
DEBUG - 2020-07-29 15:35:28 --> Total execution time: 0.0216
INFO - 2020-07-29 15:35:43 --> Config Class Initialized
INFO - 2020-07-29 15:35:43 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:35:43 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:35:43 --> Utf8 Class Initialized
INFO - 2020-07-29 15:35:43 --> URI Class Initialized
INFO - 2020-07-29 15:35:43 --> Router Class Initialized
INFO - 2020-07-29 15:35:43 --> Output Class Initialized
INFO - 2020-07-29 15:35:43 --> Security Class Initialized
DEBUG - 2020-07-29 15:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:35:43 --> Input Class Initialized
INFO - 2020-07-29 15:35:43 --> Language Class Initialized
INFO - 2020-07-29 15:35:43 --> Loader Class Initialized
INFO - 2020-07-29 15:35:43 --> Helper loaded: url_helper
INFO - 2020-07-29 15:35:43 --> Database Driver Class Initialized
INFO - 2020-07-29 15:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:35:43 --> Email Class Initialized
INFO - 2020-07-29 15:35:43 --> Controller Class Initialized
INFO - 2020-07-29 15:35:43 --> Model Class Initialized
INFO - 2020-07-29 15:35:43 --> Model Class Initialized
DEBUG - 2020-07-29 15:35:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:35:43 --> Model Class Initialized
INFO - 2020-07-29 15:35:44 --> Config Class Initialized
INFO - 2020-07-29 15:35:44 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:35:44 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:35:44 --> Utf8 Class Initialized
INFO - 2020-07-29 15:35:44 --> URI Class Initialized
DEBUG - 2020-07-29 15:35:44 --> No URI present. Default controller set.
INFO - 2020-07-29 15:35:44 --> Router Class Initialized
INFO - 2020-07-29 15:35:44 --> Output Class Initialized
INFO - 2020-07-29 15:35:44 --> Security Class Initialized
DEBUG - 2020-07-29 15:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:35:44 --> Input Class Initialized
INFO - 2020-07-29 15:35:44 --> Language Class Initialized
INFO - 2020-07-29 15:35:44 --> Loader Class Initialized
INFO - 2020-07-29 15:35:44 --> Helper loaded: url_helper
INFO - 2020-07-29 15:35:44 --> Database Driver Class Initialized
INFO - 2020-07-29 15:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:35:44 --> Email Class Initialized
INFO - 2020-07-29 15:35:44 --> Controller Class Initialized
INFO - 2020-07-29 15:35:44 --> Model Class Initialized
INFO - 2020-07-29 15:35:44 --> Model Class Initialized
DEBUG - 2020-07-29 15:35:44 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:35:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:35:44 --> Final output sent to browser
DEBUG - 2020-07-29 15:35:44 --> Total execution time: 0.0213
INFO - 2020-07-29 15:36:09 --> Config Class Initialized
INFO - 2020-07-29 15:36:09 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:36:09 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:36:09 --> Utf8 Class Initialized
INFO - 2020-07-29 15:36:09 --> URI Class Initialized
INFO - 2020-07-29 15:36:09 --> Router Class Initialized
INFO - 2020-07-29 15:36:09 --> Output Class Initialized
INFO - 2020-07-29 15:36:09 --> Security Class Initialized
DEBUG - 2020-07-29 15:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:36:09 --> Input Class Initialized
INFO - 2020-07-29 15:36:09 --> Language Class Initialized
INFO - 2020-07-29 15:36:09 --> Loader Class Initialized
INFO - 2020-07-29 15:36:09 --> Helper loaded: url_helper
INFO - 2020-07-29 15:36:09 --> Database Driver Class Initialized
INFO - 2020-07-29 15:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:36:09 --> Email Class Initialized
INFO - 2020-07-29 15:36:09 --> Controller Class Initialized
INFO - 2020-07-29 15:36:09 --> Model Class Initialized
INFO - 2020-07-29 15:36:09 --> Model Class Initialized
DEBUG - 2020-07-29 15:36:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 15:36:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:36:09 --> Model Class Initialized
INFO - 2020-07-29 15:36:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-29 15:36:09 --> Final output sent to browser
DEBUG - 2020-07-29 15:36:09 --> Total execution time: 0.0248
INFO - 2020-07-29 15:36:39 --> Config Class Initialized
INFO - 2020-07-29 15:36:39 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:36:39 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:36:39 --> Utf8 Class Initialized
INFO - 2020-07-29 15:36:39 --> URI Class Initialized
INFO - 2020-07-29 15:36:39 --> Router Class Initialized
INFO - 2020-07-29 15:36:39 --> Output Class Initialized
INFO - 2020-07-29 15:36:39 --> Security Class Initialized
DEBUG - 2020-07-29 15:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:36:39 --> Input Class Initialized
INFO - 2020-07-29 15:36:39 --> Language Class Initialized
INFO - 2020-07-29 15:36:39 --> Loader Class Initialized
INFO - 2020-07-29 15:36:39 --> Helper loaded: url_helper
INFO - 2020-07-29 15:36:39 --> Database Driver Class Initialized
INFO - 2020-07-29 15:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:36:39 --> Email Class Initialized
INFO - 2020-07-29 15:36:39 --> Controller Class Initialized
INFO - 2020-07-29 15:36:39 --> Model Class Initialized
INFO - 2020-07-29 15:36:39 --> Model Class Initialized
DEBUG - 2020-07-29 15:36:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 15:36:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:36:39 --> Model Class Initialized
INFO - 2020-07-29 15:36:40 --> Config Class Initialized
INFO - 2020-07-29 15:36:40 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:36:40 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:36:40 --> Utf8 Class Initialized
INFO - 2020-07-29 15:36:40 --> URI Class Initialized
DEBUG - 2020-07-29 15:36:40 --> No URI present. Default controller set.
INFO - 2020-07-29 15:36:40 --> Router Class Initialized
INFO - 2020-07-29 15:36:40 --> Output Class Initialized
INFO - 2020-07-29 15:36:40 --> Security Class Initialized
DEBUG - 2020-07-29 15:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:36:40 --> Input Class Initialized
INFO - 2020-07-29 15:36:40 --> Language Class Initialized
INFO - 2020-07-29 15:36:40 --> Loader Class Initialized
INFO - 2020-07-29 15:36:40 --> Helper loaded: url_helper
INFO - 2020-07-29 15:36:40 --> Database Driver Class Initialized
INFO - 2020-07-29 15:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:36:40 --> Email Class Initialized
INFO - 2020-07-29 15:36:40 --> Controller Class Initialized
INFO - 2020-07-29 15:36:40 --> Model Class Initialized
INFO - 2020-07-29 15:36:40 --> Model Class Initialized
DEBUG - 2020-07-29 15:36:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:36:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:36:40 --> Final output sent to browser
DEBUG - 2020-07-29 15:36:40 --> Total execution time: 0.0203
INFO - 2020-07-29 15:38:07 --> Config Class Initialized
INFO - 2020-07-29 15:38:07 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:38:07 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:38:07 --> Utf8 Class Initialized
INFO - 2020-07-29 15:38:07 --> URI Class Initialized
INFO - 2020-07-29 15:38:07 --> Router Class Initialized
INFO - 2020-07-29 15:38:07 --> Output Class Initialized
INFO - 2020-07-29 15:38:07 --> Security Class Initialized
DEBUG - 2020-07-29 15:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:38:07 --> Input Class Initialized
INFO - 2020-07-29 15:38:07 --> Language Class Initialized
INFO - 2020-07-29 15:38:07 --> Loader Class Initialized
INFO - 2020-07-29 15:38:07 --> Helper loaded: url_helper
INFO - 2020-07-29 15:38:07 --> Database Driver Class Initialized
INFO - 2020-07-29 15:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:38:07 --> Email Class Initialized
INFO - 2020-07-29 15:38:07 --> Controller Class Initialized
INFO - 2020-07-29 15:38:07 --> Model Class Initialized
INFO - 2020-07-29 15:38:07 --> Model Class Initialized
DEBUG - 2020-07-29 15:38:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 15:38:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:38:07 --> Model Class Initialized
INFO - 2020-07-29 15:38:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-29 15:38:07 --> Final output sent to browser
DEBUG - 2020-07-29 15:38:07 --> Total execution time: 0.0219
INFO - 2020-07-29 15:38:37 --> Config Class Initialized
INFO - 2020-07-29 15:38:37 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:38:37 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:38:37 --> Utf8 Class Initialized
INFO - 2020-07-29 15:38:37 --> URI Class Initialized
DEBUG - 2020-07-29 15:38:37 --> No URI present. Default controller set.
INFO - 2020-07-29 15:38:37 --> Router Class Initialized
INFO - 2020-07-29 15:38:37 --> Output Class Initialized
INFO - 2020-07-29 15:38:37 --> Security Class Initialized
DEBUG - 2020-07-29 15:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:38:37 --> Input Class Initialized
INFO - 2020-07-29 15:38:37 --> Language Class Initialized
INFO - 2020-07-29 15:38:37 --> Loader Class Initialized
INFO - 2020-07-29 15:38:37 --> Helper loaded: url_helper
INFO - 2020-07-29 15:38:37 --> Database Driver Class Initialized
INFO - 2020-07-29 15:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:38:37 --> Email Class Initialized
INFO - 2020-07-29 15:38:37 --> Controller Class Initialized
INFO - 2020-07-29 15:38:37 --> Model Class Initialized
INFO - 2020-07-29 15:38:37 --> Model Class Initialized
DEBUG - 2020-07-29 15:38:37 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:38:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:38:37 --> Final output sent to browser
DEBUG - 2020-07-29 15:38:37 --> Total execution time: 0.0270
INFO - 2020-07-29 15:50:09 --> Config Class Initialized
INFO - 2020-07-29 15:50:09 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:50:09 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:50:09 --> Utf8 Class Initialized
INFO - 2020-07-29 15:50:09 --> URI Class Initialized
INFO - 2020-07-29 15:50:09 --> Router Class Initialized
INFO - 2020-07-29 15:50:09 --> Output Class Initialized
INFO - 2020-07-29 15:50:09 --> Security Class Initialized
DEBUG - 2020-07-29 15:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:50:09 --> Input Class Initialized
INFO - 2020-07-29 15:50:09 --> Language Class Initialized
INFO - 2020-07-29 15:50:09 --> Loader Class Initialized
INFO - 2020-07-29 15:50:09 --> Helper loaded: url_helper
INFO - 2020-07-29 15:50:09 --> Database Driver Class Initialized
INFO - 2020-07-29 15:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:50:09 --> Email Class Initialized
INFO - 2020-07-29 15:50:09 --> Controller Class Initialized
INFO - 2020-07-29 15:50:09 --> Model Class Initialized
INFO - 2020-07-29 15:50:09 --> Model Class Initialized
DEBUG - 2020-07-29 15:50:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 15:50:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:50:09 --> Config Class Initialized
INFO - 2020-07-29 15:50:09 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:50:09 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:50:09 --> Utf8 Class Initialized
INFO - 2020-07-29 15:50:09 --> URI Class Initialized
DEBUG - 2020-07-29 15:50:09 --> No URI present. Default controller set.
INFO - 2020-07-29 15:50:09 --> Router Class Initialized
INFO - 2020-07-29 15:50:09 --> Output Class Initialized
INFO - 2020-07-29 15:50:09 --> Security Class Initialized
DEBUG - 2020-07-29 15:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:50:09 --> Input Class Initialized
INFO - 2020-07-29 15:50:09 --> Language Class Initialized
INFO - 2020-07-29 15:50:09 --> Loader Class Initialized
INFO - 2020-07-29 15:50:09 --> Helper loaded: url_helper
INFO - 2020-07-29 15:50:09 --> Database Driver Class Initialized
INFO - 2020-07-29 15:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:50:09 --> Email Class Initialized
INFO - 2020-07-29 15:50:09 --> Controller Class Initialized
INFO - 2020-07-29 15:50:09 --> Model Class Initialized
INFO - 2020-07-29 15:50:09 --> Model Class Initialized
DEBUG - 2020-07-29 15:50:09 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:50:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:50:09 --> Final output sent to browser
DEBUG - 2020-07-29 15:50:09 --> Total execution time: 0.0239
INFO - 2020-07-29 15:50:11 --> Config Class Initialized
INFO - 2020-07-29 15:50:11 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:50:11 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:50:11 --> Utf8 Class Initialized
INFO - 2020-07-29 15:50:11 --> URI Class Initialized
INFO - 2020-07-29 15:50:11 --> Router Class Initialized
INFO - 2020-07-29 15:50:11 --> Output Class Initialized
INFO - 2020-07-29 15:50:11 --> Security Class Initialized
DEBUG - 2020-07-29 15:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:50:11 --> Input Class Initialized
INFO - 2020-07-29 15:50:11 --> Language Class Initialized
INFO - 2020-07-29 15:50:11 --> Loader Class Initialized
INFO - 2020-07-29 15:50:11 --> Helper loaded: url_helper
INFO - 2020-07-29 15:50:11 --> Database Driver Class Initialized
INFO - 2020-07-29 15:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:50:11 --> Email Class Initialized
INFO - 2020-07-29 15:50:11 --> Controller Class Initialized
INFO - 2020-07-29 15:50:11 --> Model Class Initialized
INFO - 2020-07-29 15:50:11 --> Model Class Initialized
DEBUG - 2020-07-29 15:50:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 15:50:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:50:12 --> Config Class Initialized
INFO - 2020-07-29 15:50:12 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:50:12 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:50:12 --> Utf8 Class Initialized
INFO - 2020-07-29 15:50:12 --> URI Class Initialized
DEBUG - 2020-07-29 15:50:12 --> No URI present. Default controller set.
INFO - 2020-07-29 15:50:12 --> Router Class Initialized
INFO - 2020-07-29 15:50:12 --> Output Class Initialized
INFO - 2020-07-29 15:50:12 --> Security Class Initialized
DEBUG - 2020-07-29 15:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:50:12 --> Input Class Initialized
INFO - 2020-07-29 15:50:12 --> Language Class Initialized
INFO - 2020-07-29 15:50:12 --> Loader Class Initialized
INFO - 2020-07-29 15:50:12 --> Helper loaded: url_helper
INFO - 2020-07-29 15:50:12 --> Database Driver Class Initialized
INFO - 2020-07-29 15:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:50:12 --> Email Class Initialized
INFO - 2020-07-29 15:50:12 --> Controller Class Initialized
INFO - 2020-07-29 15:50:12 --> Model Class Initialized
INFO - 2020-07-29 15:50:12 --> Model Class Initialized
DEBUG - 2020-07-29 15:50:12 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:50:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:50:12 --> Final output sent to browser
DEBUG - 2020-07-29 15:50:12 --> Total execution time: 0.0316
INFO - 2020-07-29 15:50:14 --> Config Class Initialized
INFO - 2020-07-29 15:50:14 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:50:14 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:50:14 --> Utf8 Class Initialized
INFO - 2020-07-29 15:50:14 --> URI Class Initialized
INFO - 2020-07-29 15:50:14 --> Router Class Initialized
INFO - 2020-07-29 15:50:14 --> Output Class Initialized
INFO - 2020-07-29 15:50:14 --> Security Class Initialized
DEBUG - 2020-07-29 15:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:50:14 --> Input Class Initialized
INFO - 2020-07-29 15:50:14 --> Language Class Initialized
INFO - 2020-07-29 15:50:14 --> Loader Class Initialized
INFO - 2020-07-29 15:50:14 --> Helper loaded: url_helper
INFO - 2020-07-29 15:50:14 --> Database Driver Class Initialized
INFO - 2020-07-29 15:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:50:14 --> Email Class Initialized
INFO - 2020-07-29 15:50:14 --> Controller Class Initialized
INFO - 2020-07-29 15:50:14 --> Model Class Initialized
INFO - 2020-07-29 15:50:14 --> Model Class Initialized
DEBUG - 2020-07-29 15:50:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 15:50:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:50:15 --> Config Class Initialized
INFO - 2020-07-29 15:50:15 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:50:15 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:50:15 --> Utf8 Class Initialized
INFO - 2020-07-29 15:50:15 --> URI Class Initialized
DEBUG - 2020-07-29 15:50:15 --> No URI present. Default controller set.
INFO - 2020-07-29 15:50:15 --> Router Class Initialized
INFO - 2020-07-29 15:50:15 --> Output Class Initialized
INFO - 2020-07-29 15:50:15 --> Security Class Initialized
DEBUG - 2020-07-29 15:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:50:15 --> Input Class Initialized
INFO - 2020-07-29 15:50:15 --> Language Class Initialized
INFO - 2020-07-29 15:50:15 --> Loader Class Initialized
INFO - 2020-07-29 15:50:15 --> Helper loaded: url_helper
INFO - 2020-07-29 15:50:15 --> Database Driver Class Initialized
INFO - 2020-07-29 15:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:50:15 --> Email Class Initialized
INFO - 2020-07-29 15:50:15 --> Controller Class Initialized
INFO - 2020-07-29 15:50:15 --> Model Class Initialized
INFO - 2020-07-29 15:50:15 --> Model Class Initialized
DEBUG - 2020-07-29 15:50:15 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:50:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:50:15 --> Final output sent to browser
DEBUG - 2020-07-29 15:50:15 --> Total execution time: 0.0214
INFO - 2020-07-29 15:50:18 --> Config Class Initialized
INFO - 2020-07-29 15:50:18 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:50:18 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:50:18 --> Utf8 Class Initialized
INFO - 2020-07-29 15:50:18 --> URI Class Initialized
DEBUG - 2020-07-29 15:50:18 --> No URI present. Default controller set.
INFO - 2020-07-29 15:50:18 --> Router Class Initialized
INFO - 2020-07-29 15:50:18 --> Output Class Initialized
INFO - 2020-07-29 15:50:18 --> Security Class Initialized
DEBUG - 2020-07-29 15:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:50:18 --> Input Class Initialized
INFO - 2020-07-29 15:50:18 --> Language Class Initialized
INFO - 2020-07-29 15:50:18 --> Loader Class Initialized
INFO - 2020-07-29 15:50:18 --> Helper loaded: url_helper
INFO - 2020-07-29 15:50:18 --> Database Driver Class Initialized
INFO - 2020-07-29 15:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:50:18 --> Email Class Initialized
INFO - 2020-07-29 15:50:18 --> Controller Class Initialized
INFO - 2020-07-29 15:50:18 --> Model Class Initialized
INFO - 2020-07-29 15:50:18 --> Model Class Initialized
DEBUG - 2020-07-29 15:50:18 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:50:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:50:18 --> Final output sent to browser
DEBUG - 2020-07-29 15:50:18 --> Total execution time: 0.0239
INFO - 2020-07-29 15:50:22 --> Config Class Initialized
INFO - 2020-07-29 15:50:22 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:50:22 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:50:22 --> Utf8 Class Initialized
INFO - 2020-07-29 15:50:22 --> URI Class Initialized
DEBUG - 2020-07-29 15:50:22 --> No URI present. Default controller set.
INFO - 2020-07-29 15:50:22 --> Router Class Initialized
INFO - 2020-07-29 15:50:22 --> Output Class Initialized
INFO - 2020-07-29 15:50:22 --> Security Class Initialized
DEBUG - 2020-07-29 15:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:50:22 --> Input Class Initialized
INFO - 2020-07-29 15:50:22 --> Language Class Initialized
INFO - 2020-07-29 15:50:22 --> Loader Class Initialized
INFO - 2020-07-29 15:50:22 --> Helper loaded: url_helper
INFO - 2020-07-29 15:50:22 --> Database Driver Class Initialized
INFO - 2020-07-29 15:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:50:22 --> Email Class Initialized
INFO - 2020-07-29 15:50:22 --> Controller Class Initialized
INFO - 2020-07-29 15:50:22 --> Model Class Initialized
INFO - 2020-07-29 15:50:22 --> Model Class Initialized
DEBUG - 2020-07-29 15:50:22 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:50:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:50:22 --> Final output sent to browser
DEBUG - 2020-07-29 15:50:22 --> Total execution time: 0.0259
INFO - 2020-07-29 15:50:22 --> Config Class Initialized
INFO - 2020-07-29 15:50:22 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:50:22 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:50:22 --> Utf8 Class Initialized
INFO - 2020-07-29 15:50:22 --> URI Class Initialized
DEBUG - 2020-07-29 15:50:22 --> No URI present. Default controller set.
INFO - 2020-07-29 15:50:22 --> Router Class Initialized
INFO - 2020-07-29 15:50:22 --> Output Class Initialized
INFO - 2020-07-29 15:50:22 --> Security Class Initialized
DEBUG - 2020-07-29 15:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:50:22 --> Input Class Initialized
INFO - 2020-07-29 15:50:22 --> Language Class Initialized
INFO - 2020-07-29 15:50:22 --> Loader Class Initialized
INFO - 2020-07-29 15:50:22 --> Helper loaded: url_helper
INFO - 2020-07-29 15:50:22 --> Database Driver Class Initialized
INFO - 2020-07-29 15:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:50:23 --> Email Class Initialized
INFO - 2020-07-29 15:50:23 --> Controller Class Initialized
INFO - 2020-07-29 15:50:23 --> Model Class Initialized
INFO - 2020-07-29 15:50:23 --> Model Class Initialized
DEBUG - 2020-07-29 15:50:23 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:50:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:50:23 --> Final output sent to browser
DEBUG - 2020-07-29 15:50:23 --> Total execution time: 0.0246
INFO - 2020-07-29 15:50:25 --> Config Class Initialized
INFO - 2020-07-29 15:50:25 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:50:25 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:50:25 --> Utf8 Class Initialized
INFO - 2020-07-29 15:50:25 --> URI Class Initialized
INFO - 2020-07-29 15:50:25 --> Router Class Initialized
INFO - 2020-07-29 15:50:25 --> Output Class Initialized
INFO - 2020-07-29 15:50:25 --> Security Class Initialized
DEBUG - 2020-07-29 15:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:50:25 --> Input Class Initialized
INFO - 2020-07-29 15:50:25 --> Language Class Initialized
INFO - 2020-07-29 15:50:25 --> Loader Class Initialized
INFO - 2020-07-29 15:50:25 --> Helper loaded: url_helper
INFO - 2020-07-29 15:50:25 --> Database Driver Class Initialized
INFO - 2020-07-29 15:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:50:25 --> Email Class Initialized
INFO - 2020-07-29 15:50:25 --> Controller Class Initialized
INFO - 2020-07-29 15:50:25 --> Model Class Initialized
INFO - 2020-07-29 15:50:25 --> Model Class Initialized
DEBUG - 2020-07-29 15:50:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 15:50:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:50:26 --> Config Class Initialized
INFO - 2020-07-29 15:50:26 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:50:26 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:50:26 --> Utf8 Class Initialized
INFO - 2020-07-29 15:50:26 --> URI Class Initialized
DEBUG - 2020-07-29 15:50:26 --> No URI present. Default controller set.
INFO - 2020-07-29 15:50:26 --> Router Class Initialized
INFO - 2020-07-29 15:50:26 --> Output Class Initialized
INFO - 2020-07-29 15:50:26 --> Security Class Initialized
DEBUG - 2020-07-29 15:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:50:26 --> Input Class Initialized
INFO - 2020-07-29 15:50:26 --> Language Class Initialized
INFO - 2020-07-29 15:50:26 --> Loader Class Initialized
INFO - 2020-07-29 15:50:26 --> Helper loaded: url_helper
INFO - 2020-07-29 15:50:26 --> Database Driver Class Initialized
INFO - 2020-07-29 15:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:50:26 --> Email Class Initialized
INFO - 2020-07-29 15:50:26 --> Controller Class Initialized
INFO - 2020-07-29 15:50:26 --> Model Class Initialized
INFO - 2020-07-29 15:50:26 --> Model Class Initialized
DEBUG - 2020-07-29 15:50:26 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:50:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:50:26 --> Final output sent to browser
DEBUG - 2020-07-29 15:50:26 --> Total execution time: 0.0716
INFO - 2020-07-29 15:50:28 --> Config Class Initialized
INFO - 2020-07-29 15:50:28 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:50:28 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:50:28 --> Utf8 Class Initialized
INFO - 2020-07-29 15:50:28 --> URI Class Initialized
INFO - 2020-07-29 15:50:28 --> Router Class Initialized
INFO - 2020-07-29 15:50:28 --> Output Class Initialized
INFO - 2020-07-29 15:50:28 --> Security Class Initialized
DEBUG - 2020-07-29 15:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:50:28 --> Input Class Initialized
INFO - 2020-07-29 15:50:28 --> Language Class Initialized
INFO - 2020-07-29 15:50:28 --> Loader Class Initialized
INFO - 2020-07-29 15:50:28 --> Helper loaded: url_helper
INFO - 2020-07-29 15:50:28 --> Database Driver Class Initialized
INFO - 2020-07-29 15:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:50:28 --> Email Class Initialized
INFO - 2020-07-29 15:50:28 --> Controller Class Initialized
INFO - 2020-07-29 15:50:28 --> Model Class Initialized
INFO - 2020-07-29 15:50:28 --> Model Class Initialized
DEBUG - 2020-07-29 15:50:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 15:50:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:50:29 --> Config Class Initialized
INFO - 2020-07-29 15:50:29 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:50:29 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:50:29 --> Utf8 Class Initialized
INFO - 2020-07-29 15:50:29 --> URI Class Initialized
DEBUG - 2020-07-29 15:50:29 --> No URI present. Default controller set.
INFO - 2020-07-29 15:50:29 --> Router Class Initialized
INFO - 2020-07-29 15:50:29 --> Output Class Initialized
INFO - 2020-07-29 15:50:29 --> Security Class Initialized
DEBUG - 2020-07-29 15:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:50:29 --> Input Class Initialized
INFO - 2020-07-29 15:50:29 --> Language Class Initialized
INFO - 2020-07-29 15:50:29 --> Loader Class Initialized
INFO - 2020-07-29 15:50:29 --> Helper loaded: url_helper
INFO - 2020-07-29 15:50:29 --> Database Driver Class Initialized
INFO - 2020-07-29 15:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:50:29 --> Email Class Initialized
INFO - 2020-07-29 15:50:29 --> Controller Class Initialized
INFO - 2020-07-29 15:50:29 --> Model Class Initialized
INFO - 2020-07-29 15:50:29 --> Model Class Initialized
DEBUG - 2020-07-29 15:50:29 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:50:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:50:29 --> Final output sent to browser
DEBUG - 2020-07-29 15:50:29 --> Total execution time: 0.0252
INFO - 2020-07-29 15:50:31 --> Config Class Initialized
INFO - 2020-07-29 15:50:31 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:50:31 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:50:31 --> Utf8 Class Initialized
INFO - 2020-07-29 15:50:31 --> URI Class Initialized
INFO - 2020-07-29 15:50:31 --> Router Class Initialized
INFO - 2020-07-29 15:50:31 --> Output Class Initialized
INFO - 2020-07-29 15:50:31 --> Security Class Initialized
DEBUG - 2020-07-29 15:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:50:31 --> Input Class Initialized
INFO - 2020-07-29 15:50:31 --> Language Class Initialized
INFO - 2020-07-29 15:50:31 --> Loader Class Initialized
INFO - 2020-07-29 15:50:31 --> Helper loaded: url_helper
INFO - 2020-07-29 15:50:31 --> Database Driver Class Initialized
INFO - 2020-07-29 15:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:50:31 --> Email Class Initialized
INFO - 2020-07-29 15:50:31 --> Controller Class Initialized
INFO - 2020-07-29 15:50:31 --> Model Class Initialized
INFO - 2020-07-29 15:50:31 --> Model Class Initialized
DEBUG - 2020-07-29 15:50:31 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:50:31 --> Config Class Initialized
INFO - 2020-07-29 15:50:31 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:50:31 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:50:31 --> Utf8 Class Initialized
INFO - 2020-07-29 15:50:31 --> URI Class Initialized
INFO - 2020-07-29 15:50:31 --> Router Class Initialized
INFO - 2020-07-29 15:50:31 --> Output Class Initialized
INFO - 2020-07-29 15:50:31 --> Security Class Initialized
DEBUG - 2020-07-29 15:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:50:31 --> Input Class Initialized
INFO - 2020-07-29 15:50:31 --> Language Class Initialized
INFO - 2020-07-29 15:50:31 --> Loader Class Initialized
INFO - 2020-07-29 15:50:31 --> Helper loaded: url_helper
INFO - 2020-07-29 15:50:31 --> Database Driver Class Initialized
INFO - 2020-07-29 15:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:50:31 --> Email Class Initialized
INFO - 2020-07-29 15:50:31 --> Controller Class Initialized
DEBUG - 2020-07-29 15:50:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 15:50:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:50:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 15:50:31 --> Final output sent to browser
DEBUG - 2020-07-29 15:50:31 --> Total execution time: 0.0226
INFO - 2020-07-29 15:50:35 --> Config Class Initialized
INFO - 2020-07-29 15:50:35 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:50:35 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:50:35 --> Utf8 Class Initialized
INFO - 2020-07-29 15:50:35 --> URI Class Initialized
DEBUG - 2020-07-29 15:50:35 --> No URI present. Default controller set.
INFO - 2020-07-29 15:50:35 --> Router Class Initialized
INFO - 2020-07-29 15:50:35 --> Output Class Initialized
INFO - 2020-07-29 15:50:35 --> Security Class Initialized
DEBUG - 2020-07-29 15:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:50:35 --> Input Class Initialized
INFO - 2020-07-29 15:50:35 --> Language Class Initialized
INFO - 2020-07-29 15:50:35 --> Loader Class Initialized
INFO - 2020-07-29 15:50:35 --> Helper loaded: url_helper
INFO - 2020-07-29 15:50:35 --> Database Driver Class Initialized
INFO - 2020-07-29 15:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:50:35 --> Email Class Initialized
INFO - 2020-07-29 15:50:35 --> Controller Class Initialized
INFO - 2020-07-29 15:50:35 --> Model Class Initialized
INFO - 2020-07-29 15:50:35 --> Model Class Initialized
DEBUG - 2020-07-29 15:50:35 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:50:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:50:35 --> Final output sent to browser
DEBUG - 2020-07-29 15:50:35 --> Total execution time: 0.0230
INFO - 2020-07-29 15:50:38 --> Config Class Initialized
INFO - 2020-07-29 15:50:38 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:50:38 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:50:38 --> Utf8 Class Initialized
INFO - 2020-07-29 15:50:38 --> URI Class Initialized
INFO - 2020-07-29 15:50:38 --> Router Class Initialized
INFO - 2020-07-29 15:50:38 --> Output Class Initialized
INFO - 2020-07-29 15:50:38 --> Security Class Initialized
DEBUG - 2020-07-29 15:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:50:38 --> Input Class Initialized
INFO - 2020-07-29 15:50:38 --> Language Class Initialized
INFO - 2020-07-29 15:50:38 --> Loader Class Initialized
INFO - 2020-07-29 15:50:38 --> Helper loaded: url_helper
INFO - 2020-07-29 15:50:38 --> Database Driver Class Initialized
INFO - 2020-07-29 15:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:50:38 --> Email Class Initialized
INFO - 2020-07-29 15:50:38 --> Controller Class Initialized
INFO - 2020-07-29 15:50:38 --> Model Class Initialized
INFO - 2020-07-29 15:50:38 --> Model Class Initialized
DEBUG - 2020-07-29 15:50:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 15:50:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:50:38 --> Model Class Initialized
INFO - 2020-07-29 15:50:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-29 15:50:38 --> Final output sent to browser
DEBUG - 2020-07-29 15:50:38 --> Total execution time: 0.0216
INFO - 2020-07-29 15:50:54 --> Config Class Initialized
INFO - 2020-07-29 15:50:54 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:50:54 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:50:54 --> Utf8 Class Initialized
INFO - 2020-07-29 15:50:54 --> URI Class Initialized
INFO - 2020-07-29 15:50:54 --> Router Class Initialized
INFO - 2020-07-29 15:50:54 --> Output Class Initialized
INFO - 2020-07-29 15:50:54 --> Security Class Initialized
DEBUG - 2020-07-29 15:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:50:54 --> Input Class Initialized
INFO - 2020-07-29 15:50:54 --> Language Class Initialized
INFO - 2020-07-29 15:50:54 --> Loader Class Initialized
INFO - 2020-07-29 15:50:54 --> Helper loaded: url_helper
INFO - 2020-07-29 15:50:54 --> Database Driver Class Initialized
INFO - 2020-07-29 15:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:50:54 --> Email Class Initialized
INFO - 2020-07-29 15:50:54 --> Controller Class Initialized
INFO - 2020-07-29 15:50:54 --> Model Class Initialized
INFO - 2020-07-29 15:50:54 --> Model Class Initialized
DEBUG - 2020-07-29 15:50:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 15:50:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:50:54 --> Model Class Initialized
INFO - 2020-07-29 15:50:54 --> Config Class Initialized
INFO - 2020-07-29 15:50:54 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:50:54 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:50:54 --> Utf8 Class Initialized
INFO - 2020-07-29 15:50:54 --> URI Class Initialized
INFO - 2020-07-29 15:50:54 --> Router Class Initialized
INFO - 2020-07-29 15:50:54 --> Output Class Initialized
INFO - 2020-07-29 15:50:54 --> Security Class Initialized
DEBUG - 2020-07-29 15:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:50:54 --> Input Class Initialized
INFO - 2020-07-29 15:50:54 --> Language Class Initialized
INFO - 2020-07-29 15:50:54 --> Loader Class Initialized
INFO - 2020-07-29 15:50:54 --> Helper loaded: url_helper
INFO - 2020-07-29 15:50:54 --> Database Driver Class Initialized
INFO - 2020-07-29 15:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:50:54 --> Email Class Initialized
INFO - 2020-07-29 15:50:54 --> Controller Class Initialized
INFO - 2020-07-29 15:50:54 --> Model Class Initialized
INFO - 2020-07-29 15:50:54 --> Model Class Initialized
DEBUG - 2020-07-29 15:50:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 15:50:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:50:54 --> Model Class Initialized
INFO - 2020-07-29 15:50:55 --> Config Class Initialized
INFO - 2020-07-29 15:50:55 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:50:55 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:50:55 --> Utf8 Class Initialized
INFO - 2020-07-29 15:50:55 --> URI Class Initialized
DEBUG - 2020-07-29 15:50:55 --> No URI present. Default controller set.
INFO - 2020-07-29 15:50:55 --> Router Class Initialized
INFO - 2020-07-29 15:50:55 --> Output Class Initialized
INFO - 2020-07-29 15:50:55 --> Security Class Initialized
DEBUG - 2020-07-29 15:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:50:55 --> Input Class Initialized
INFO - 2020-07-29 15:50:55 --> Language Class Initialized
INFO - 2020-07-29 15:50:55 --> Loader Class Initialized
INFO - 2020-07-29 15:50:55 --> Helper loaded: url_helper
INFO - 2020-07-29 15:50:55 --> Database Driver Class Initialized
INFO - 2020-07-29 15:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:50:55 --> Email Class Initialized
INFO - 2020-07-29 15:50:55 --> Controller Class Initialized
INFO - 2020-07-29 15:50:55 --> Model Class Initialized
INFO - 2020-07-29 15:50:55 --> Model Class Initialized
DEBUG - 2020-07-29 15:50:55 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:50:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:50:55 --> Final output sent to browser
DEBUG - 2020-07-29 15:50:55 --> Total execution time: 0.0268
INFO - 2020-07-29 15:50:55 --> Config Class Initialized
INFO - 2020-07-29 15:50:55 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:50:55 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:50:55 --> Utf8 Class Initialized
INFO - 2020-07-29 15:50:55 --> URI Class Initialized
DEBUG - 2020-07-29 15:50:55 --> No URI present. Default controller set.
INFO - 2020-07-29 15:50:55 --> Router Class Initialized
INFO - 2020-07-29 15:50:55 --> Output Class Initialized
INFO - 2020-07-29 15:50:55 --> Security Class Initialized
DEBUG - 2020-07-29 15:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:50:55 --> Input Class Initialized
INFO - 2020-07-29 15:50:55 --> Language Class Initialized
INFO - 2020-07-29 15:50:55 --> Loader Class Initialized
INFO - 2020-07-29 15:50:55 --> Helper loaded: url_helper
INFO - 2020-07-29 15:50:55 --> Database Driver Class Initialized
INFO - 2020-07-29 15:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:50:55 --> Email Class Initialized
INFO - 2020-07-29 15:50:55 --> Controller Class Initialized
INFO - 2020-07-29 15:50:55 --> Model Class Initialized
INFO - 2020-07-29 15:50:55 --> Model Class Initialized
DEBUG - 2020-07-29 15:50:55 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:50:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:50:55 --> Final output sent to browser
DEBUG - 2020-07-29 15:50:55 --> Total execution time: 0.0232
INFO - 2020-07-29 15:51:57 --> Config Class Initialized
INFO - 2020-07-29 15:51:57 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:51:57 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:51:57 --> Utf8 Class Initialized
INFO - 2020-07-29 15:51:57 --> URI Class Initialized
INFO - 2020-07-29 15:51:57 --> Router Class Initialized
INFO - 2020-07-29 15:51:57 --> Output Class Initialized
INFO - 2020-07-29 15:51:57 --> Security Class Initialized
DEBUG - 2020-07-29 15:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:51:57 --> Input Class Initialized
INFO - 2020-07-29 15:51:57 --> Language Class Initialized
INFO - 2020-07-29 15:51:57 --> Loader Class Initialized
INFO - 2020-07-29 15:51:57 --> Helper loaded: url_helper
INFO - 2020-07-29 15:51:57 --> Database Driver Class Initialized
INFO - 2020-07-29 15:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:51:57 --> Email Class Initialized
INFO - 2020-07-29 15:51:57 --> Controller Class Initialized
INFO - 2020-07-29 15:51:57 --> Model Class Initialized
INFO - 2020-07-29 15:51:57 --> Model Class Initialized
DEBUG - 2020-07-29 15:51:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 15:51:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:51:57 --> Model Class Initialized
INFO - 2020-07-29 15:51:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-29 15:51:57 --> Final output sent to browser
DEBUG - 2020-07-29 15:51:57 --> Total execution time: 0.0226
INFO - 2020-07-29 15:53:20 --> Config Class Initialized
INFO - 2020-07-29 15:53:20 --> Config Class Initialized
INFO - 2020-07-29 15:53:20 --> Hooks Class Initialized
INFO - 2020-07-29 15:53:20 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:53:20 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:53:20 --> Utf8 Class Initialized
DEBUG - 2020-07-29 15:53:20 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:53:20 --> Utf8 Class Initialized
INFO - 2020-07-29 15:53:20 --> URI Class Initialized
INFO - 2020-07-29 15:53:20 --> URI Class Initialized
INFO - 2020-07-29 15:53:20 --> Router Class Initialized
INFO - 2020-07-29 15:53:20 --> Router Class Initialized
INFO - 2020-07-29 15:53:20 --> Output Class Initialized
INFO - 2020-07-29 15:53:20 --> Output Class Initialized
INFO - 2020-07-29 15:53:20 --> Security Class Initialized
INFO - 2020-07-29 15:53:20 --> Security Class Initialized
DEBUG - 2020-07-29 15:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:53:20 --> Input Class Initialized
DEBUG - 2020-07-29 15:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:53:20 --> Input Class Initialized
INFO - 2020-07-29 15:53:20 --> Language Class Initialized
INFO - 2020-07-29 15:53:20 --> Language Class Initialized
INFO - 2020-07-29 15:53:20 --> Loader Class Initialized
INFO - 2020-07-29 15:53:20 --> Loader Class Initialized
INFO - 2020-07-29 15:53:20 --> Helper loaded: url_helper
INFO - 2020-07-29 15:53:20 --> Helper loaded: url_helper
INFO - 2020-07-29 15:53:20 --> Database Driver Class Initialized
INFO - 2020-07-29 15:53:20 --> Database Driver Class Initialized
INFO - 2020-07-29 15:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:53:20 --> Email Class Initialized
INFO - 2020-07-29 15:53:20 --> Controller Class Initialized
INFO - 2020-07-29 15:53:20 --> Model Class Initialized
INFO - 2020-07-29 15:53:20 --> Model Class Initialized
DEBUG - 2020-07-29 15:53:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 15:53:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:53:20 --> Model Class Initialized
INFO - 2020-07-29 15:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:53:20 --> Email Class Initialized
INFO - 2020-07-29 15:53:20 --> Controller Class Initialized
INFO - 2020-07-29 15:53:20 --> Model Class Initialized
INFO - 2020-07-29 15:53:20 --> Model Class Initialized
DEBUG - 2020-07-29 15:53:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 15:53:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:53:20 --> Model Class Initialized
INFO - 2020-07-29 15:53:21 --> Config Class Initialized
INFO - 2020-07-29 15:53:21 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:53:21 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:53:21 --> Utf8 Class Initialized
INFO - 2020-07-29 15:53:21 --> URI Class Initialized
DEBUG - 2020-07-29 15:53:21 --> No URI present. Default controller set.
INFO - 2020-07-29 15:53:21 --> Router Class Initialized
INFO - 2020-07-29 15:53:21 --> Output Class Initialized
INFO - 2020-07-29 15:53:21 --> Security Class Initialized
DEBUG - 2020-07-29 15:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:53:21 --> Input Class Initialized
INFO - 2020-07-29 15:53:21 --> Language Class Initialized
INFO - 2020-07-29 15:53:21 --> Loader Class Initialized
INFO - 2020-07-29 15:53:21 --> Helper loaded: url_helper
INFO - 2020-07-29 15:53:21 --> Database Driver Class Initialized
INFO - 2020-07-29 15:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:53:21 --> Email Class Initialized
INFO - 2020-07-29 15:53:21 --> Controller Class Initialized
INFO - 2020-07-29 15:53:21 --> Model Class Initialized
INFO - 2020-07-29 15:53:21 --> Model Class Initialized
DEBUG - 2020-07-29 15:53:21 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:53:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:53:21 --> Final output sent to browser
DEBUG - 2020-07-29 15:53:21 --> Total execution time: 0.0246
INFO - 2020-07-29 15:53:21 --> Config Class Initialized
INFO - 2020-07-29 15:53:21 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:53:21 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:53:21 --> Utf8 Class Initialized
INFO - 2020-07-29 15:53:21 --> URI Class Initialized
DEBUG - 2020-07-29 15:53:21 --> No URI present. Default controller set.
INFO - 2020-07-29 15:53:21 --> Router Class Initialized
INFO - 2020-07-29 15:53:21 --> Output Class Initialized
INFO - 2020-07-29 15:53:21 --> Security Class Initialized
DEBUG - 2020-07-29 15:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:53:21 --> Input Class Initialized
INFO - 2020-07-29 15:53:21 --> Language Class Initialized
INFO - 2020-07-29 15:53:21 --> Loader Class Initialized
INFO - 2020-07-29 15:53:21 --> Helper loaded: url_helper
INFO - 2020-07-29 15:53:21 --> Database Driver Class Initialized
INFO - 2020-07-29 15:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:53:21 --> Email Class Initialized
INFO - 2020-07-29 15:53:21 --> Controller Class Initialized
INFO - 2020-07-29 15:53:21 --> Model Class Initialized
INFO - 2020-07-29 15:53:21 --> Model Class Initialized
DEBUG - 2020-07-29 15:53:21 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:53:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:53:21 --> Final output sent to browser
DEBUG - 2020-07-29 15:53:21 --> Total execution time: 0.0251
INFO - 2020-07-29 15:54:48 --> Config Class Initialized
INFO - 2020-07-29 15:54:48 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:54:48 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:54:48 --> Utf8 Class Initialized
INFO - 2020-07-29 15:54:48 --> URI Class Initialized
INFO - 2020-07-29 15:54:48 --> Router Class Initialized
INFO - 2020-07-29 15:54:48 --> Output Class Initialized
INFO - 2020-07-29 15:54:48 --> Security Class Initialized
DEBUG - 2020-07-29 15:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:54:48 --> Input Class Initialized
INFO - 2020-07-29 15:54:48 --> Language Class Initialized
INFO - 2020-07-29 15:54:48 --> Loader Class Initialized
INFO - 2020-07-29 15:54:48 --> Helper loaded: url_helper
INFO - 2020-07-29 15:54:48 --> Database Driver Class Initialized
INFO - 2020-07-29 15:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:54:48 --> Email Class Initialized
INFO - 2020-07-29 15:54:48 --> Controller Class Initialized
INFO - 2020-07-29 15:54:48 --> Model Class Initialized
INFO - 2020-07-29 15:54:48 --> Model Class Initialized
DEBUG - 2020-07-29 15:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 15:54:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:54:48 --> Config Class Initialized
INFO - 2020-07-29 15:54:48 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:54:48 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:54:48 --> Utf8 Class Initialized
INFO - 2020-07-29 15:54:48 --> URI Class Initialized
DEBUG - 2020-07-29 15:54:48 --> No URI present. Default controller set.
INFO - 2020-07-29 15:54:48 --> Router Class Initialized
INFO - 2020-07-29 15:54:48 --> Output Class Initialized
INFO - 2020-07-29 15:54:48 --> Security Class Initialized
DEBUG - 2020-07-29 15:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:54:48 --> Input Class Initialized
INFO - 2020-07-29 15:54:48 --> Language Class Initialized
INFO - 2020-07-29 15:54:48 --> Loader Class Initialized
INFO - 2020-07-29 15:54:48 --> Helper loaded: url_helper
INFO - 2020-07-29 15:54:48 --> Database Driver Class Initialized
INFO - 2020-07-29 15:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:54:48 --> Email Class Initialized
INFO - 2020-07-29 15:54:48 --> Controller Class Initialized
INFO - 2020-07-29 15:54:48 --> Model Class Initialized
INFO - 2020-07-29 15:54:48 --> Model Class Initialized
DEBUG - 2020-07-29 15:54:48 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:54:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:54:48 --> Final output sent to browser
DEBUG - 2020-07-29 15:54:48 --> Total execution time: 0.0222
INFO - 2020-07-29 15:54:50 --> Config Class Initialized
INFO - 2020-07-29 15:54:50 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:54:50 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:54:50 --> Utf8 Class Initialized
INFO - 2020-07-29 15:54:50 --> URI Class Initialized
INFO - 2020-07-29 15:54:50 --> Router Class Initialized
INFO - 2020-07-29 15:54:50 --> Output Class Initialized
INFO - 2020-07-29 15:54:50 --> Security Class Initialized
DEBUG - 2020-07-29 15:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:54:50 --> Input Class Initialized
INFO - 2020-07-29 15:54:50 --> Language Class Initialized
INFO - 2020-07-29 15:54:50 --> Loader Class Initialized
INFO - 2020-07-29 15:54:50 --> Helper loaded: url_helper
INFO - 2020-07-29 15:54:50 --> Database Driver Class Initialized
INFO - 2020-07-29 15:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:54:50 --> Email Class Initialized
INFO - 2020-07-29 15:54:50 --> Controller Class Initialized
INFO - 2020-07-29 15:54:50 --> Model Class Initialized
INFO - 2020-07-29 15:54:50 --> Model Class Initialized
DEBUG - 2020-07-29 15:54:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 15:54:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:54:51 --> Config Class Initialized
INFO - 2020-07-29 15:54:51 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:54:51 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:54:51 --> Utf8 Class Initialized
INFO - 2020-07-29 15:54:51 --> URI Class Initialized
DEBUG - 2020-07-29 15:54:51 --> No URI present. Default controller set.
INFO - 2020-07-29 15:54:51 --> Router Class Initialized
INFO - 2020-07-29 15:54:51 --> Output Class Initialized
INFO - 2020-07-29 15:54:51 --> Security Class Initialized
DEBUG - 2020-07-29 15:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:54:51 --> Input Class Initialized
INFO - 2020-07-29 15:54:51 --> Language Class Initialized
INFO - 2020-07-29 15:54:51 --> Loader Class Initialized
INFO - 2020-07-29 15:54:51 --> Helper loaded: url_helper
INFO - 2020-07-29 15:54:51 --> Database Driver Class Initialized
INFO - 2020-07-29 15:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:54:51 --> Email Class Initialized
INFO - 2020-07-29 15:54:51 --> Controller Class Initialized
INFO - 2020-07-29 15:54:51 --> Model Class Initialized
INFO - 2020-07-29 15:54:51 --> Model Class Initialized
DEBUG - 2020-07-29 15:54:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:54:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:54:51 --> Final output sent to browser
DEBUG - 2020-07-29 15:54:51 --> Total execution time: 0.0227
INFO - 2020-07-29 15:54:53 --> Config Class Initialized
INFO - 2020-07-29 15:54:53 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:54:53 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:54:53 --> Utf8 Class Initialized
INFO - 2020-07-29 15:54:53 --> URI Class Initialized
INFO - 2020-07-29 15:54:53 --> Router Class Initialized
INFO - 2020-07-29 15:54:53 --> Output Class Initialized
INFO - 2020-07-29 15:54:53 --> Security Class Initialized
DEBUG - 2020-07-29 15:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:54:53 --> Input Class Initialized
INFO - 2020-07-29 15:54:53 --> Language Class Initialized
INFO - 2020-07-29 15:54:53 --> Loader Class Initialized
INFO - 2020-07-29 15:54:53 --> Helper loaded: url_helper
INFO - 2020-07-29 15:54:53 --> Database Driver Class Initialized
INFO - 2020-07-29 15:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:54:53 --> Email Class Initialized
INFO - 2020-07-29 15:54:53 --> Controller Class Initialized
INFO - 2020-07-29 15:54:53 --> Model Class Initialized
INFO - 2020-07-29 15:54:53 --> Model Class Initialized
DEBUG - 2020-07-29 15:54:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 15:54:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:54:53 --> Config Class Initialized
INFO - 2020-07-29 15:54:53 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:54:53 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:54:53 --> Utf8 Class Initialized
INFO - 2020-07-29 15:54:53 --> URI Class Initialized
DEBUG - 2020-07-29 15:54:53 --> No URI present. Default controller set.
INFO - 2020-07-29 15:54:53 --> Router Class Initialized
INFO - 2020-07-29 15:54:53 --> Output Class Initialized
INFO - 2020-07-29 15:54:53 --> Security Class Initialized
DEBUG - 2020-07-29 15:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:54:53 --> Input Class Initialized
INFO - 2020-07-29 15:54:53 --> Language Class Initialized
INFO - 2020-07-29 15:54:53 --> Loader Class Initialized
INFO - 2020-07-29 15:54:53 --> Helper loaded: url_helper
INFO - 2020-07-29 15:54:53 --> Database Driver Class Initialized
INFO - 2020-07-29 15:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:54:53 --> Email Class Initialized
INFO - 2020-07-29 15:54:53 --> Controller Class Initialized
INFO - 2020-07-29 15:54:53 --> Model Class Initialized
INFO - 2020-07-29 15:54:53 --> Model Class Initialized
DEBUG - 2020-07-29 15:54:53 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:54:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:54:53 --> Final output sent to browser
DEBUG - 2020-07-29 15:54:53 --> Total execution time: 0.0238
INFO - 2020-07-29 15:55:01 --> Config Class Initialized
INFO - 2020-07-29 15:55:01 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:55:01 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:55:01 --> Utf8 Class Initialized
INFO - 2020-07-29 15:55:01 --> URI Class Initialized
INFO - 2020-07-29 15:55:01 --> Router Class Initialized
INFO - 2020-07-29 15:55:01 --> Output Class Initialized
INFO - 2020-07-29 15:55:01 --> Security Class Initialized
DEBUG - 2020-07-29 15:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:55:01 --> Input Class Initialized
INFO - 2020-07-29 15:55:01 --> Language Class Initialized
INFO - 2020-07-29 15:55:01 --> Loader Class Initialized
INFO - 2020-07-29 15:55:01 --> Helper loaded: url_helper
INFO - 2020-07-29 15:55:01 --> Database Driver Class Initialized
INFO - 2020-07-29 15:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:55:01 --> Email Class Initialized
INFO - 2020-07-29 15:55:01 --> Controller Class Initialized
INFO - 2020-07-29 15:55:01 --> Model Class Initialized
INFO - 2020-07-29 15:55:01 --> Model Class Initialized
DEBUG - 2020-07-29 15:55:01 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:55:02 --> Config Class Initialized
INFO - 2020-07-29 15:55:02 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:55:02 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:55:02 --> Utf8 Class Initialized
INFO - 2020-07-29 15:55:02 --> URI Class Initialized
INFO - 2020-07-29 15:55:02 --> Router Class Initialized
INFO - 2020-07-29 15:55:02 --> Output Class Initialized
INFO - 2020-07-29 15:55:02 --> Security Class Initialized
DEBUG - 2020-07-29 15:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:55:02 --> Input Class Initialized
INFO - 2020-07-29 15:55:02 --> Language Class Initialized
INFO - 2020-07-29 15:55:02 --> Loader Class Initialized
INFO - 2020-07-29 15:55:02 --> Helper loaded: url_helper
INFO - 2020-07-29 15:55:02 --> Database Driver Class Initialized
INFO - 2020-07-29 15:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:55:02 --> Email Class Initialized
INFO - 2020-07-29 15:55:02 --> Controller Class Initialized
DEBUG - 2020-07-29 15:55:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 15:55:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:55:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 15:55:02 --> Final output sent to browser
DEBUG - 2020-07-29 15:55:02 --> Total execution time: 0.0200
INFO - 2020-07-29 15:55:04 --> Config Class Initialized
INFO - 2020-07-29 15:55:04 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:55:04 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:55:04 --> Utf8 Class Initialized
INFO - 2020-07-29 15:55:04 --> URI Class Initialized
DEBUG - 2020-07-29 15:55:04 --> No URI present. Default controller set.
INFO - 2020-07-29 15:55:04 --> Router Class Initialized
INFO - 2020-07-29 15:55:04 --> Output Class Initialized
INFO - 2020-07-29 15:55:04 --> Security Class Initialized
DEBUG - 2020-07-29 15:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:55:04 --> Input Class Initialized
INFO - 2020-07-29 15:55:04 --> Language Class Initialized
INFO - 2020-07-29 15:55:04 --> Loader Class Initialized
INFO - 2020-07-29 15:55:04 --> Helper loaded: url_helper
INFO - 2020-07-29 15:55:04 --> Database Driver Class Initialized
INFO - 2020-07-29 15:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:55:04 --> Email Class Initialized
INFO - 2020-07-29 15:55:04 --> Controller Class Initialized
INFO - 2020-07-29 15:55:04 --> Model Class Initialized
INFO - 2020-07-29 15:55:04 --> Model Class Initialized
DEBUG - 2020-07-29 15:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:55:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:55:04 --> Final output sent to browser
DEBUG - 2020-07-29 15:55:04 --> Total execution time: 0.0208
INFO - 2020-07-29 15:55:07 --> Config Class Initialized
INFO - 2020-07-29 15:55:07 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:55:07 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:55:07 --> Utf8 Class Initialized
INFO - 2020-07-29 15:55:07 --> URI Class Initialized
INFO - 2020-07-29 15:55:07 --> Router Class Initialized
INFO - 2020-07-29 15:55:07 --> Output Class Initialized
INFO - 2020-07-29 15:55:07 --> Security Class Initialized
DEBUG - 2020-07-29 15:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:55:07 --> Input Class Initialized
INFO - 2020-07-29 15:55:07 --> Language Class Initialized
INFO - 2020-07-29 15:55:07 --> Loader Class Initialized
INFO - 2020-07-29 15:55:07 --> Helper loaded: url_helper
INFO - 2020-07-29 15:55:07 --> Database Driver Class Initialized
INFO - 2020-07-29 15:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:55:07 --> Email Class Initialized
INFO - 2020-07-29 15:55:07 --> Controller Class Initialized
INFO - 2020-07-29 15:55:07 --> Model Class Initialized
INFO - 2020-07-29 15:55:07 --> Model Class Initialized
DEBUG - 2020-07-29 15:55:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 15:55:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:55:07 --> Model Class Initialized
INFO - 2020-07-29 15:55:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-29 15:55:07 --> Final output sent to browser
DEBUG - 2020-07-29 15:55:07 --> Total execution time: 0.0223
INFO - 2020-07-29 15:55:13 --> Config Class Initialized
INFO - 2020-07-29 15:55:13 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:55:13 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:55:13 --> Utf8 Class Initialized
INFO - 2020-07-29 15:55:13 --> URI Class Initialized
INFO - 2020-07-29 15:55:13 --> Router Class Initialized
INFO - 2020-07-29 15:55:13 --> Output Class Initialized
INFO - 2020-07-29 15:55:13 --> Security Class Initialized
DEBUG - 2020-07-29 15:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:55:13 --> Input Class Initialized
INFO - 2020-07-29 15:55:13 --> Language Class Initialized
INFO - 2020-07-29 15:55:13 --> Loader Class Initialized
INFO - 2020-07-29 15:55:13 --> Helper loaded: url_helper
INFO - 2020-07-29 15:55:13 --> Database Driver Class Initialized
INFO - 2020-07-29 15:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:55:13 --> Email Class Initialized
INFO - 2020-07-29 15:55:13 --> Controller Class Initialized
INFO - 2020-07-29 15:55:13 --> Model Class Initialized
INFO - 2020-07-29 15:55:13 --> Model Class Initialized
DEBUG - 2020-07-29 15:55:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 15:55:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:55:13 --> Model Class Initialized
INFO - 2020-07-29 15:55:13 --> Config Class Initialized
INFO - 2020-07-29 15:55:13 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:55:13 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:55:13 --> Utf8 Class Initialized
INFO - 2020-07-29 15:55:13 --> URI Class Initialized
INFO - 2020-07-29 15:55:13 --> Router Class Initialized
INFO - 2020-07-29 15:55:13 --> Output Class Initialized
INFO - 2020-07-29 15:55:13 --> Security Class Initialized
DEBUG - 2020-07-29 15:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:55:13 --> Input Class Initialized
INFO - 2020-07-29 15:55:13 --> Language Class Initialized
INFO - 2020-07-29 15:55:13 --> Loader Class Initialized
INFO - 2020-07-29 15:55:13 --> Helper loaded: url_helper
INFO - 2020-07-29 15:55:13 --> Database Driver Class Initialized
INFO - 2020-07-29 15:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:55:13 --> Email Class Initialized
INFO - 2020-07-29 15:55:13 --> Controller Class Initialized
INFO - 2020-07-29 15:55:13 --> Model Class Initialized
INFO - 2020-07-29 15:55:13 --> Model Class Initialized
DEBUG - 2020-07-29 15:55:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 15:55:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:55:13 --> Model Class Initialized
INFO - 2020-07-29 15:55:14 --> Config Class Initialized
INFO - 2020-07-29 15:55:14 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:55:14 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:55:14 --> Utf8 Class Initialized
INFO - 2020-07-29 15:55:14 --> URI Class Initialized
DEBUG - 2020-07-29 15:55:14 --> No URI present. Default controller set.
INFO - 2020-07-29 15:55:14 --> Router Class Initialized
INFO - 2020-07-29 15:55:14 --> Output Class Initialized
INFO - 2020-07-29 15:55:14 --> Security Class Initialized
DEBUG - 2020-07-29 15:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:55:14 --> Input Class Initialized
INFO - 2020-07-29 15:55:14 --> Language Class Initialized
INFO - 2020-07-29 15:55:14 --> Loader Class Initialized
INFO - 2020-07-29 15:55:14 --> Helper loaded: url_helper
INFO - 2020-07-29 15:55:14 --> Database Driver Class Initialized
INFO - 2020-07-29 15:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:55:14 --> Email Class Initialized
INFO - 2020-07-29 15:55:14 --> Controller Class Initialized
INFO - 2020-07-29 15:55:14 --> Model Class Initialized
INFO - 2020-07-29 15:55:14 --> Model Class Initialized
DEBUG - 2020-07-29 15:55:14 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:55:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:55:14 --> Final output sent to browser
DEBUG - 2020-07-29 15:55:14 --> Total execution time: 0.0251
INFO - 2020-07-29 15:55:14 --> Config Class Initialized
INFO - 2020-07-29 15:55:14 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:55:14 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:55:14 --> Utf8 Class Initialized
INFO - 2020-07-29 15:55:14 --> URI Class Initialized
DEBUG - 2020-07-29 15:55:14 --> No URI present. Default controller set.
INFO - 2020-07-29 15:55:14 --> Router Class Initialized
INFO - 2020-07-29 15:55:14 --> Output Class Initialized
INFO - 2020-07-29 15:55:14 --> Security Class Initialized
DEBUG - 2020-07-29 15:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:55:14 --> Input Class Initialized
INFO - 2020-07-29 15:55:14 --> Language Class Initialized
INFO - 2020-07-29 15:55:14 --> Loader Class Initialized
INFO - 2020-07-29 15:55:14 --> Helper loaded: url_helper
INFO - 2020-07-29 15:55:14 --> Database Driver Class Initialized
INFO - 2020-07-29 15:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:55:14 --> Email Class Initialized
INFO - 2020-07-29 15:55:14 --> Controller Class Initialized
INFO - 2020-07-29 15:55:14 --> Model Class Initialized
INFO - 2020-07-29 15:55:14 --> Model Class Initialized
DEBUG - 2020-07-29 15:55:14 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:55:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:55:14 --> Final output sent to browser
DEBUG - 2020-07-29 15:55:14 --> Total execution time: 0.0223
INFO - 2020-07-29 15:56:05 --> Config Class Initialized
INFO - 2020-07-29 15:56:05 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:56:05 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:56:05 --> Utf8 Class Initialized
INFO - 2020-07-29 15:56:05 --> URI Class Initialized
INFO - 2020-07-29 15:56:05 --> Router Class Initialized
INFO - 2020-07-29 15:56:05 --> Output Class Initialized
INFO - 2020-07-29 15:56:05 --> Security Class Initialized
DEBUG - 2020-07-29 15:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:56:05 --> Input Class Initialized
INFO - 2020-07-29 15:56:05 --> Language Class Initialized
INFO - 2020-07-29 15:56:05 --> Loader Class Initialized
INFO - 2020-07-29 15:56:05 --> Helper loaded: url_helper
INFO - 2020-07-29 15:56:05 --> Database Driver Class Initialized
INFO - 2020-07-29 15:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:56:05 --> Email Class Initialized
INFO - 2020-07-29 15:56:05 --> Controller Class Initialized
INFO - 2020-07-29 15:56:05 --> Model Class Initialized
INFO - 2020-07-29 15:56:05 --> Model Class Initialized
DEBUG - 2020-07-29 15:56:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 15:56:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:56:05 --> Model Class Initialized
INFO - 2020-07-29 15:56:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-29 15:56:05 --> Final output sent to browser
DEBUG - 2020-07-29 15:56:05 --> Total execution time: 0.0247
INFO - 2020-07-29 15:56:10 --> Config Class Initialized
INFO - 2020-07-29 15:56:10 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:56:10 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:56:10 --> Utf8 Class Initialized
INFO - 2020-07-29 15:56:10 --> URI Class Initialized
INFO - 2020-07-29 15:56:10 --> Router Class Initialized
INFO - 2020-07-29 15:56:10 --> Output Class Initialized
INFO - 2020-07-29 15:56:10 --> Security Class Initialized
DEBUG - 2020-07-29 15:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:56:10 --> Input Class Initialized
INFO - 2020-07-29 15:56:10 --> Language Class Initialized
INFO - 2020-07-29 15:56:10 --> Loader Class Initialized
INFO - 2020-07-29 15:56:10 --> Helper loaded: url_helper
INFO - 2020-07-29 15:56:10 --> Database Driver Class Initialized
INFO - 2020-07-29 15:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:56:10 --> Email Class Initialized
INFO - 2020-07-29 15:56:10 --> Controller Class Initialized
INFO - 2020-07-29 15:56:10 --> Model Class Initialized
INFO - 2020-07-29 15:56:10 --> Model Class Initialized
DEBUG - 2020-07-29 15:56:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 15:56:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:56:10 --> Model Class Initialized
INFO - 2020-07-29 15:56:10 --> Config Class Initialized
INFO - 2020-07-29 15:56:10 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:56:10 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:56:10 --> Utf8 Class Initialized
INFO - 2020-07-29 15:56:10 --> URI Class Initialized
INFO - 2020-07-29 15:56:10 --> Router Class Initialized
INFO - 2020-07-29 15:56:10 --> Output Class Initialized
INFO - 2020-07-29 15:56:10 --> Security Class Initialized
DEBUG - 2020-07-29 15:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:56:10 --> Input Class Initialized
INFO - 2020-07-29 15:56:10 --> Language Class Initialized
INFO - 2020-07-29 15:56:10 --> Loader Class Initialized
INFO - 2020-07-29 15:56:10 --> Helper loaded: url_helper
INFO - 2020-07-29 15:56:10 --> Database Driver Class Initialized
INFO - 2020-07-29 15:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:56:10 --> Email Class Initialized
INFO - 2020-07-29 15:56:10 --> Controller Class Initialized
INFO - 2020-07-29 15:56:10 --> Model Class Initialized
INFO - 2020-07-29 15:56:10 --> Model Class Initialized
DEBUG - 2020-07-29 15:56:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 15:56:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:56:10 --> Model Class Initialized
INFO - 2020-07-29 15:56:10 --> Config Class Initialized
INFO - 2020-07-29 15:56:10 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:56:10 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:56:10 --> Utf8 Class Initialized
INFO - 2020-07-29 15:56:10 --> URI Class Initialized
DEBUG - 2020-07-29 15:56:10 --> No URI present. Default controller set.
INFO - 2020-07-29 15:56:10 --> Router Class Initialized
INFO - 2020-07-29 15:56:10 --> Output Class Initialized
INFO - 2020-07-29 15:56:10 --> Security Class Initialized
DEBUG - 2020-07-29 15:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:56:10 --> Input Class Initialized
INFO - 2020-07-29 15:56:10 --> Language Class Initialized
INFO - 2020-07-29 15:56:10 --> Loader Class Initialized
INFO - 2020-07-29 15:56:10 --> Helper loaded: url_helper
INFO - 2020-07-29 15:56:10 --> Database Driver Class Initialized
INFO - 2020-07-29 15:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:56:10 --> Email Class Initialized
INFO - 2020-07-29 15:56:10 --> Controller Class Initialized
INFO - 2020-07-29 15:56:10 --> Model Class Initialized
INFO - 2020-07-29 15:56:10 --> Model Class Initialized
DEBUG - 2020-07-29 15:56:10 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:56:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:56:10 --> Final output sent to browser
DEBUG - 2020-07-29 15:56:10 --> Total execution time: 0.0240
INFO - 2020-07-29 15:56:11 --> Config Class Initialized
INFO - 2020-07-29 15:56:11 --> Hooks Class Initialized
DEBUG - 2020-07-29 15:56:11 --> UTF-8 Support Enabled
INFO - 2020-07-29 15:56:11 --> Utf8 Class Initialized
INFO - 2020-07-29 15:56:11 --> URI Class Initialized
DEBUG - 2020-07-29 15:56:11 --> No URI present. Default controller set.
INFO - 2020-07-29 15:56:11 --> Router Class Initialized
INFO - 2020-07-29 15:56:11 --> Output Class Initialized
INFO - 2020-07-29 15:56:11 --> Security Class Initialized
DEBUG - 2020-07-29 15:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 15:56:11 --> Input Class Initialized
INFO - 2020-07-29 15:56:11 --> Language Class Initialized
INFO - 2020-07-29 15:56:11 --> Loader Class Initialized
INFO - 2020-07-29 15:56:11 --> Helper loaded: url_helper
INFO - 2020-07-29 15:56:11 --> Database Driver Class Initialized
INFO - 2020-07-29 15:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 15:56:11 --> Email Class Initialized
INFO - 2020-07-29 15:56:11 --> Controller Class Initialized
INFO - 2020-07-29 15:56:11 --> Model Class Initialized
INFO - 2020-07-29 15:56:11 --> Model Class Initialized
DEBUG - 2020-07-29 15:56:11 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 15:56:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 15:56:11 --> Final output sent to browser
DEBUG - 2020-07-29 15:56:11 --> Total execution time: 0.0220
INFO - 2020-07-29 16:13:14 --> Config Class Initialized
INFO - 2020-07-29 16:13:14 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:13:14 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:13:14 --> Utf8 Class Initialized
INFO - 2020-07-29 16:13:14 --> URI Class Initialized
DEBUG - 2020-07-29 16:13:14 --> No URI present. Default controller set.
INFO - 2020-07-29 16:13:14 --> Router Class Initialized
INFO - 2020-07-29 16:13:14 --> Output Class Initialized
INFO - 2020-07-29 16:13:14 --> Security Class Initialized
DEBUG - 2020-07-29 16:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:13:14 --> Input Class Initialized
INFO - 2020-07-29 16:13:14 --> Language Class Initialized
INFO - 2020-07-29 16:13:14 --> Loader Class Initialized
INFO - 2020-07-29 16:13:14 --> Helper loaded: url_helper
INFO - 2020-07-29 16:13:14 --> Database Driver Class Initialized
INFO - 2020-07-29 16:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:13:14 --> Email Class Initialized
INFO - 2020-07-29 16:13:14 --> Controller Class Initialized
INFO - 2020-07-29 16:13:14 --> Model Class Initialized
INFO - 2020-07-29 16:13:14 --> Model Class Initialized
DEBUG - 2020-07-29 16:13:14 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:13:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:13:14 --> Final output sent to browser
DEBUG - 2020-07-29 16:13:14 --> Total execution time: 0.0224
INFO - 2020-07-29 16:13:22 --> Config Class Initialized
INFO - 2020-07-29 16:13:22 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:13:22 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:13:22 --> Utf8 Class Initialized
INFO - 2020-07-29 16:13:22 --> URI Class Initialized
INFO - 2020-07-29 16:13:22 --> Router Class Initialized
INFO - 2020-07-29 16:13:22 --> Output Class Initialized
INFO - 2020-07-29 16:13:22 --> Security Class Initialized
DEBUG - 2020-07-29 16:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:13:22 --> Input Class Initialized
INFO - 2020-07-29 16:13:22 --> Language Class Initialized
INFO - 2020-07-29 16:13:22 --> Loader Class Initialized
INFO - 2020-07-29 16:13:22 --> Helper loaded: url_helper
INFO - 2020-07-29 16:13:22 --> Database Driver Class Initialized
INFO - 2020-07-29 16:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:13:22 --> Email Class Initialized
INFO - 2020-07-29 16:13:22 --> Controller Class Initialized
INFO - 2020-07-29 16:13:22 --> Model Class Initialized
INFO - 2020-07-29 16:13:22 --> Model Class Initialized
DEBUG - 2020-07-29 16:13:22 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:13:23 --> Config Class Initialized
INFO - 2020-07-29 16:13:23 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:13:23 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:13:23 --> Utf8 Class Initialized
INFO - 2020-07-29 16:13:23 --> URI Class Initialized
DEBUG - 2020-07-29 16:13:23 --> No URI present. Default controller set.
INFO - 2020-07-29 16:13:23 --> Router Class Initialized
INFO - 2020-07-29 16:13:23 --> Output Class Initialized
INFO - 2020-07-29 16:13:23 --> Security Class Initialized
DEBUG - 2020-07-29 16:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:13:23 --> Input Class Initialized
INFO - 2020-07-29 16:13:23 --> Language Class Initialized
INFO - 2020-07-29 16:13:23 --> Loader Class Initialized
INFO - 2020-07-29 16:13:23 --> Helper loaded: url_helper
INFO - 2020-07-29 16:13:23 --> Database Driver Class Initialized
INFO - 2020-07-29 16:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:13:23 --> Email Class Initialized
INFO - 2020-07-29 16:13:23 --> Controller Class Initialized
INFO - 2020-07-29 16:13:23 --> Model Class Initialized
INFO - 2020-07-29 16:13:23 --> Model Class Initialized
DEBUG - 2020-07-29 16:13:23 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:13:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:13:23 --> Final output sent to browser
DEBUG - 2020-07-29 16:13:23 --> Total execution time: 0.0215
INFO - 2020-07-29 16:13:34 --> Config Class Initialized
INFO - 2020-07-29 16:13:34 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:13:34 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:13:34 --> Utf8 Class Initialized
INFO - 2020-07-29 16:13:34 --> URI Class Initialized
DEBUG - 2020-07-29 16:13:34 --> No URI present. Default controller set.
INFO - 2020-07-29 16:13:34 --> Router Class Initialized
INFO - 2020-07-29 16:13:34 --> Output Class Initialized
INFO - 2020-07-29 16:13:34 --> Security Class Initialized
DEBUG - 2020-07-29 16:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:13:34 --> Input Class Initialized
INFO - 2020-07-29 16:13:34 --> Language Class Initialized
INFO - 2020-07-29 16:13:34 --> Loader Class Initialized
INFO - 2020-07-29 16:13:34 --> Helper loaded: url_helper
INFO - 2020-07-29 16:13:34 --> Database Driver Class Initialized
INFO - 2020-07-29 16:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:13:34 --> Email Class Initialized
INFO - 2020-07-29 16:13:34 --> Controller Class Initialized
INFO - 2020-07-29 16:13:34 --> Model Class Initialized
INFO - 2020-07-29 16:13:34 --> Model Class Initialized
DEBUG - 2020-07-29 16:13:34 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:13:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:13:34 --> Final output sent to browser
DEBUG - 2020-07-29 16:13:34 --> Total execution time: 0.0232
INFO - 2020-07-29 16:13:37 --> Config Class Initialized
INFO - 2020-07-29 16:13:37 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:13:37 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:13:37 --> Utf8 Class Initialized
INFO - 2020-07-29 16:13:37 --> URI Class Initialized
INFO - 2020-07-29 16:13:37 --> Router Class Initialized
INFO - 2020-07-29 16:13:37 --> Output Class Initialized
INFO - 2020-07-29 16:13:37 --> Security Class Initialized
DEBUG - 2020-07-29 16:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:13:37 --> Input Class Initialized
INFO - 2020-07-29 16:13:37 --> Language Class Initialized
INFO - 2020-07-29 16:13:37 --> Loader Class Initialized
INFO - 2020-07-29 16:13:37 --> Helper loaded: url_helper
INFO - 2020-07-29 16:13:37 --> Database Driver Class Initialized
INFO - 2020-07-29 16:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:13:37 --> Email Class Initialized
INFO - 2020-07-29 16:13:37 --> Controller Class Initialized
INFO - 2020-07-29 16:13:37 --> Model Class Initialized
INFO - 2020-07-29 16:13:37 --> Model Class Initialized
DEBUG - 2020-07-29 16:13:37 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:13:38 --> Config Class Initialized
INFO - 2020-07-29 16:13:38 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:13:38 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:13:38 --> Utf8 Class Initialized
INFO - 2020-07-29 16:13:38 --> URI Class Initialized
INFO - 2020-07-29 16:13:38 --> Router Class Initialized
INFO - 2020-07-29 16:13:38 --> Output Class Initialized
INFO - 2020-07-29 16:13:38 --> Security Class Initialized
DEBUG - 2020-07-29 16:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:13:38 --> Input Class Initialized
INFO - 2020-07-29 16:13:38 --> Language Class Initialized
INFO - 2020-07-29 16:13:38 --> Loader Class Initialized
INFO - 2020-07-29 16:13:38 --> Helper loaded: url_helper
INFO - 2020-07-29 16:13:38 --> Database Driver Class Initialized
INFO - 2020-07-29 16:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:13:38 --> Email Class Initialized
INFO - 2020-07-29 16:13:38 --> Controller Class Initialized
DEBUG - 2020-07-29 16:13:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 16:13:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:13:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 16:13:38 --> Final output sent to browser
DEBUG - 2020-07-29 16:13:38 --> Total execution time: 0.0208
INFO - 2020-07-29 16:13:42 --> Config Class Initialized
INFO - 2020-07-29 16:13:42 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:13:42 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:13:42 --> Utf8 Class Initialized
INFO - 2020-07-29 16:13:42 --> URI Class Initialized
DEBUG - 2020-07-29 16:13:42 --> No URI present. Default controller set.
INFO - 2020-07-29 16:13:42 --> Router Class Initialized
INFO - 2020-07-29 16:13:42 --> Output Class Initialized
INFO - 2020-07-29 16:13:42 --> Security Class Initialized
DEBUG - 2020-07-29 16:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:13:42 --> Input Class Initialized
INFO - 2020-07-29 16:13:42 --> Language Class Initialized
INFO - 2020-07-29 16:13:42 --> Loader Class Initialized
INFO - 2020-07-29 16:13:42 --> Helper loaded: url_helper
INFO - 2020-07-29 16:13:42 --> Database Driver Class Initialized
INFO - 2020-07-29 16:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:13:42 --> Email Class Initialized
INFO - 2020-07-29 16:13:42 --> Controller Class Initialized
INFO - 2020-07-29 16:13:42 --> Model Class Initialized
INFO - 2020-07-29 16:13:42 --> Model Class Initialized
DEBUG - 2020-07-29 16:13:42 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:13:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:13:42 --> Final output sent to browser
DEBUG - 2020-07-29 16:13:42 --> Total execution time: 0.0221
INFO - 2020-07-29 16:14:01 --> Config Class Initialized
INFO - 2020-07-29 16:14:01 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:14:01 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:14:01 --> Utf8 Class Initialized
INFO - 2020-07-29 16:14:01 --> URI Class Initialized
INFO - 2020-07-29 16:14:01 --> Router Class Initialized
INFO - 2020-07-29 16:14:01 --> Output Class Initialized
INFO - 2020-07-29 16:14:01 --> Security Class Initialized
DEBUG - 2020-07-29 16:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:14:01 --> Input Class Initialized
INFO - 2020-07-29 16:14:01 --> Language Class Initialized
INFO - 2020-07-29 16:14:01 --> Loader Class Initialized
INFO - 2020-07-29 16:14:01 --> Helper loaded: url_helper
INFO - 2020-07-29 16:14:01 --> Database Driver Class Initialized
INFO - 2020-07-29 16:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:14:01 --> Email Class Initialized
INFO - 2020-07-29 16:14:01 --> Controller Class Initialized
INFO - 2020-07-29 16:14:01 --> Model Class Initialized
INFO - 2020-07-29 16:14:01 --> Model Class Initialized
DEBUG - 2020-07-29 16:14:01 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:14:01 --> Config Class Initialized
INFO - 2020-07-29 16:14:01 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:14:01 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:14:01 --> Utf8 Class Initialized
INFO - 2020-07-29 16:14:01 --> URI Class Initialized
DEBUG - 2020-07-29 16:14:01 --> No URI present. Default controller set.
INFO - 2020-07-29 16:14:01 --> Router Class Initialized
INFO - 2020-07-29 16:14:01 --> Output Class Initialized
INFO - 2020-07-29 16:14:01 --> Security Class Initialized
DEBUG - 2020-07-29 16:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:14:01 --> Input Class Initialized
INFO - 2020-07-29 16:14:01 --> Language Class Initialized
INFO - 2020-07-29 16:14:01 --> Loader Class Initialized
INFO - 2020-07-29 16:14:01 --> Helper loaded: url_helper
INFO - 2020-07-29 16:14:01 --> Database Driver Class Initialized
INFO - 2020-07-29 16:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:14:01 --> Email Class Initialized
INFO - 2020-07-29 16:14:01 --> Controller Class Initialized
INFO - 2020-07-29 16:14:01 --> Model Class Initialized
INFO - 2020-07-29 16:14:01 --> Model Class Initialized
DEBUG - 2020-07-29 16:14:01 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:14:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:14:01 --> Final output sent to browser
DEBUG - 2020-07-29 16:14:01 --> Total execution time: 0.0250
INFO - 2020-07-29 16:14:06 --> Config Class Initialized
INFO - 2020-07-29 16:14:06 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:14:06 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:14:06 --> Utf8 Class Initialized
INFO - 2020-07-29 16:14:06 --> URI Class Initialized
DEBUG - 2020-07-29 16:14:06 --> No URI present. Default controller set.
INFO - 2020-07-29 16:14:06 --> Router Class Initialized
INFO - 2020-07-29 16:14:06 --> Output Class Initialized
INFO - 2020-07-29 16:14:06 --> Security Class Initialized
DEBUG - 2020-07-29 16:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:14:06 --> Input Class Initialized
INFO - 2020-07-29 16:14:13 --> Language Class Initialized
INFO - 2020-07-29 16:14:13 --> Loader Class Initialized
INFO - 2020-07-29 16:14:13 --> Helper loaded: url_helper
INFO - 2020-07-29 16:14:13 --> Database Driver Class Initialized
INFO - 2020-07-29 16:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:14:13 --> Email Class Initialized
INFO - 2020-07-29 16:14:13 --> Controller Class Initialized
INFO - 2020-07-29 16:14:13 --> Model Class Initialized
INFO - 2020-07-29 16:14:13 --> Model Class Initialized
DEBUG - 2020-07-29 16:14:13 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:14:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:14:13 --> Final output sent to browser
DEBUG - 2020-07-29 16:14:13 --> Total execution time: 6.9448
INFO - 2020-07-29 16:14:16 --> Config Class Initialized
INFO - 2020-07-29 16:14:16 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:14:16 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:14:16 --> Utf8 Class Initialized
INFO - 2020-07-29 16:14:16 --> URI Class Initialized
DEBUG - 2020-07-29 16:14:16 --> No URI present. Default controller set.
INFO - 2020-07-29 16:14:16 --> Router Class Initialized
INFO - 2020-07-29 16:14:16 --> Output Class Initialized
INFO - 2020-07-29 16:14:16 --> Security Class Initialized
DEBUG - 2020-07-29 16:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:14:16 --> Input Class Initialized
INFO - 2020-07-29 16:14:16 --> Language Class Initialized
INFO - 2020-07-29 16:14:16 --> Loader Class Initialized
INFO - 2020-07-29 16:14:16 --> Helper loaded: url_helper
INFO - 2020-07-29 16:14:16 --> Database Driver Class Initialized
INFO - 2020-07-29 16:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:14:16 --> Email Class Initialized
INFO - 2020-07-29 16:14:16 --> Controller Class Initialized
INFO - 2020-07-29 16:14:16 --> Model Class Initialized
INFO - 2020-07-29 16:14:16 --> Model Class Initialized
DEBUG - 2020-07-29 16:14:16 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:14:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:14:16 --> Final output sent to browser
DEBUG - 2020-07-29 16:14:16 --> Total execution time: 0.0236
INFO - 2020-07-29 16:14:17 --> Config Class Initialized
INFO - 2020-07-29 16:14:17 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:14:17 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:14:17 --> Utf8 Class Initialized
INFO - 2020-07-29 16:14:17 --> URI Class Initialized
DEBUG - 2020-07-29 16:14:17 --> No URI present. Default controller set.
INFO - 2020-07-29 16:14:17 --> Router Class Initialized
INFO - 2020-07-29 16:14:17 --> Output Class Initialized
INFO - 2020-07-29 16:14:17 --> Security Class Initialized
DEBUG - 2020-07-29 16:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:14:17 --> Input Class Initialized
INFO - 2020-07-29 16:14:17 --> Language Class Initialized
INFO - 2020-07-29 16:14:17 --> Loader Class Initialized
INFO - 2020-07-29 16:14:17 --> Helper loaded: url_helper
INFO - 2020-07-29 16:14:17 --> Database Driver Class Initialized
INFO - 2020-07-29 16:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:14:17 --> Email Class Initialized
INFO - 2020-07-29 16:14:17 --> Controller Class Initialized
INFO - 2020-07-29 16:14:17 --> Model Class Initialized
INFO - 2020-07-29 16:14:17 --> Model Class Initialized
DEBUG - 2020-07-29 16:14:17 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:14:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:14:17 --> Final output sent to browser
DEBUG - 2020-07-29 16:14:17 --> Total execution time: 0.0248
INFO - 2020-07-29 16:14:22 --> Config Class Initialized
INFO - 2020-07-29 16:14:22 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:14:22 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:14:22 --> Utf8 Class Initialized
INFO - 2020-07-29 16:14:22 --> URI Class Initialized
INFO - 2020-07-29 16:14:22 --> Router Class Initialized
INFO - 2020-07-29 16:14:22 --> Output Class Initialized
INFO - 2020-07-29 16:14:22 --> Security Class Initialized
DEBUG - 2020-07-29 16:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:14:22 --> Input Class Initialized
INFO - 2020-07-29 16:14:22 --> Language Class Initialized
INFO - 2020-07-29 16:14:22 --> Loader Class Initialized
INFO - 2020-07-29 16:14:22 --> Helper loaded: url_helper
INFO - 2020-07-29 16:14:22 --> Database Driver Class Initialized
INFO - 2020-07-29 16:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:14:22 --> Email Class Initialized
INFO - 2020-07-29 16:14:22 --> Controller Class Initialized
INFO - 2020-07-29 16:14:22 --> Model Class Initialized
INFO - 2020-07-29 16:14:22 --> Model Class Initialized
DEBUG - 2020-07-29 16:14:22 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:14:23 --> Config Class Initialized
INFO - 2020-07-29 16:14:23 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:14:23 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:14:23 --> Utf8 Class Initialized
INFO - 2020-07-29 16:14:23 --> URI Class Initialized
INFO - 2020-07-29 16:14:23 --> Router Class Initialized
INFO - 2020-07-29 16:14:23 --> Output Class Initialized
INFO - 2020-07-29 16:14:23 --> Security Class Initialized
DEBUG - 2020-07-29 16:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:14:23 --> Input Class Initialized
INFO - 2020-07-29 16:14:23 --> Language Class Initialized
INFO - 2020-07-29 16:14:23 --> Loader Class Initialized
INFO - 2020-07-29 16:14:23 --> Helper loaded: url_helper
INFO - 2020-07-29 16:14:23 --> Database Driver Class Initialized
INFO - 2020-07-29 16:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:14:23 --> Email Class Initialized
INFO - 2020-07-29 16:14:23 --> Controller Class Initialized
DEBUG - 2020-07-29 16:14:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 16:14:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:14:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 16:14:23 --> Final output sent to browser
DEBUG - 2020-07-29 16:14:23 --> Total execution time: 0.0241
INFO - 2020-07-29 16:14:31 --> Config Class Initialized
INFO - 2020-07-29 16:14:31 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:14:31 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:14:31 --> Utf8 Class Initialized
INFO - 2020-07-29 16:14:31 --> URI Class Initialized
DEBUG - 2020-07-29 16:14:31 --> No URI present. Default controller set.
INFO - 2020-07-29 16:14:31 --> Router Class Initialized
INFO - 2020-07-29 16:14:31 --> Output Class Initialized
INFO - 2020-07-29 16:14:31 --> Security Class Initialized
DEBUG - 2020-07-29 16:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:14:31 --> Input Class Initialized
INFO - 2020-07-29 16:14:31 --> Language Class Initialized
INFO - 2020-07-29 16:14:31 --> Loader Class Initialized
INFO - 2020-07-29 16:14:31 --> Helper loaded: url_helper
INFO - 2020-07-29 16:14:31 --> Database Driver Class Initialized
INFO - 2020-07-29 16:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:14:31 --> Email Class Initialized
INFO - 2020-07-29 16:14:31 --> Controller Class Initialized
INFO - 2020-07-29 16:14:31 --> Model Class Initialized
INFO - 2020-07-29 16:14:31 --> Model Class Initialized
DEBUG - 2020-07-29 16:14:31 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:14:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:14:31 --> Final output sent to browser
DEBUG - 2020-07-29 16:14:31 --> Total execution time: 0.0249
INFO - 2020-07-29 16:14:41 --> Config Class Initialized
INFO - 2020-07-29 16:14:41 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:14:41 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:14:41 --> Utf8 Class Initialized
INFO - 2020-07-29 16:14:41 --> URI Class Initialized
INFO - 2020-07-29 16:14:41 --> Router Class Initialized
INFO - 2020-07-29 16:14:41 --> Output Class Initialized
INFO - 2020-07-29 16:14:41 --> Security Class Initialized
DEBUG - 2020-07-29 16:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:14:41 --> Input Class Initialized
INFO - 2020-07-29 16:14:41 --> Language Class Initialized
INFO - 2020-07-29 16:14:41 --> Loader Class Initialized
INFO - 2020-07-29 16:14:41 --> Helper loaded: url_helper
INFO - 2020-07-29 16:14:41 --> Database Driver Class Initialized
INFO - 2020-07-29 16:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:14:41 --> Email Class Initialized
INFO - 2020-07-29 16:14:41 --> Controller Class Initialized
INFO - 2020-07-29 16:14:41 --> Model Class Initialized
INFO - 2020-07-29 16:14:41 --> Model Class Initialized
DEBUG - 2020-07-29 16:14:41 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:14:42 --> Config Class Initialized
INFO - 2020-07-29 16:14:42 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:14:42 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:14:42 --> Utf8 Class Initialized
INFO - 2020-07-29 16:14:42 --> URI Class Initialized
DEBUG - 2020-07-29 16:14:42 --> No URI present. Default controller set.
INFO - 2020-07-29 16:14:42 --> Router Class Initialized
INFO - 2020-07-29 16:14:42 --> Output Class Initialized
INFO - 2020-07-29 16:14:42 --> Security Class Initialized
DEBUG - 2020-07-29 16:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:14:42 --> Input Class Initialized
INFO - 2020-07-29 16:14:42 --> Language Class Initialized
INFO - 2020-07-29 16:14:42 --> Loader Class Initialized
INFO - 2020-07-29 16:14:42 --> Helper loaded: url_helper
INFO - 2020-07-29 16:14:42 --> Database Driver Class Initialized
INFO - 2020-07-29 16:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:14:42 --> Email Class Initialized
INFO - 2020-07-29 16:14:42 --> Controller Class Initialized
INFO - 2020-07-29 16:14:42 --> Model Class Initialized
INFO - 2020-07-29 16:14:42 --> Model Class Initialized
DEBUG - 2020-07-29 16:14:42 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:14:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:14:42 --> Final output sent to browser
DEBUG - 2020-07-29 16:14:42 --> Total execution time: 0.0208
INFO - 2020-07-29 16:15:48 --> Config Class Initialized
INFO - 2020-07-29 16:15:48 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:15:48 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:15:48 --> Utf8 Class Initialized
INFO - 2020-07-29 16:15:48 --> URI Class Initialized
DEBUG - 2020-07-29 16:15:48 --> No URI present. Default controller set.
INFO - 2020-07-29 16:15:48 --> Router Class Initialized
INFO - 2020-07-29 16:15:48 --> Output Class Initialized
INFO - 2020-07-29 16:15:48 --> Security Class Initialized
DEBUG - 2020-07-29 16:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:15:48 --> Input Class Initialized
INFO - 2020-07-29 16:15:48 --> Language Class Initialized
INFO - 2020-07-29 16:15:48 --> Loader Class Initialized
INFO - 2020-07-29 16:15:48 --> Helper loaded: url_helper
INFO - 2020-07-29 16:15:48 --> Database Driver Class Initialized
INFO - 2020-07-29 16:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:15:48 --> Email Class Initialized
INFO - 2020-07-29 16:15:48 --> Controller Class Initialized
INFO - 2020-07-29 16:15:48 --> Model Class Initialized
INFO - 2020-07-29 16:15:48 --> Model Class Initialized
DEBUG - 2020-07-29 16:15:48 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:15:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:15:48 --> Final output sent to browser
DEBUG - 2020-07-29 16:15:48 --> Total execution time: 0.0218
INFO - 2020-07-29 16:15:53 --> Config Class Initialized
INFO - 2020-07-29 16:15:53 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:15:53 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:15:53 --> Utf8 Class Initialized
INFO - 2020-07-29 16:15:53 --> URI Class Initialized
INFO - 2020-07-29 16:15:53 --> Router Class Initialized
INFO - 2020-07-29 16:15:53 --> Output Class Initialized
INFO - 2020-07-29 16:15:53 --> Security Class Initialized
DEBUG - 2020-07-29 16:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:15:53 --> Input Class Initialized
INFO - 2020-07-29 16:15:53 --> Language Class Initialized
INFO - 2020-07-29 16:15:53 --> Loader Class Initialized
INFO - 2020-07-29 16:15:53 --> Helper loaded: url_helper
INFO - 2020-07-29 16:15:53 --> Database Driver Class Initialized
INFO - 2020-07-29 16:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:15:53 --> Email Class Initialized
INFO - 2020-07-29 16:15:53 --> Controller Class Initialized
INFO - 2020-07-29 16:15:53 --> Model Class Initialized
INFO - 2020-07-29 16:15:53 --> Model Class Initialized
DEBUG - 2020-07-29 16:15:53 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:15:54 --> Config Class Initialized
INFO - 2020-07-29 16:15:54 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:15:54 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:15:54 --> Utf8 Class Initialized
INFO - 2020-07-29 16:15:54 --> URI Class Initialized
DEBUG - 2020-07-29 16:15:54 --> No URI present. Default controller set.
INFO - 2020-07-29 16:15:54 --> Router Class Initialized
INFO - 2020-07-29 16:15:54 --> Output Class Initialized
INFO - 2020-07-29 16:15:54 --> Security Class Initialized
DEBUG - 2020-07-29 16:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:15:54 --> Input Class Initialized
INFO - 2020-07-29 16:15:54 --> Language Class Initialized
INFO - 2020-07-29 16:15:54 --> Loader Class Initialized
INFO - 2020-07-29 16:15:54 --> Helper loaded: url_helper
INFO - 2020-07-29 16:15:54 --> Database Driver Class Initialized
INFO - 2020-07-29 16:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:15:54 --> Email Class Initialized
INFO - 2020-07-29 16:15:54 --> Controller Class Initialized
INFO - 2020-07-29 16:15:54 --> Model Class Initialized
INFO - 2020-07-29 16:15:54 --> Model Class Initialized
DEBUG - 2020-07-29 16:15:54 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:15:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:15:54 --> Final output sent to browser
DEBUG - 2020-07-29 16:15:54 --> Total execution time: 0.0228
INFO - 2020-07-29 16:15:56 --> Config Class Initialized
INFO - 2020-07-29 16:15:56 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:15:56 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:15:56 --> Utf8 Class Initialized
INFO - 2020-07-29 16:15:56 --> URI Class Initialized
INFO - 2020-07-29 16:15:56 --> Router Class Initialized
INFO - 2020-07-29 16:15:56 --> Output Class Initialized
INFO - 2020-07-29 16:15:56 --> Security Class Initialized
DEBUG - 2020-07-29 16:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:15:56 --> Input Class Initialized
INFO - 2020-07-29 16:15:56 --> Language Class Initialized
INFO - 2020-07-29 16:15:56 --> Loader Class Initialized
INFO - 2020-07-29 16:15:56 --> Helper loaded: url_helper
INFO - 2020-07-29 16:15:56 --> Database Driver Class Initialized
INFO - 2020-07-29 16:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:15:56 --> Email Class Initialized
INFO - 2020-07-29 16:15:56 --> Controller Class Initialized
INFO - 2020-07-29 16:15:56 --> Model Class Initialized
INFO - 2020-07-29 16:15:56 --> Model Class Initialized
DEBUG - 2020-07-29 16:15:56 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:15:57 --> Config Class Initialized
INFO - 2020-07-29 16:15:57 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:15:57 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:15:57 --> Utf8 Class Initialized
INFO - 2020-07-29 16:15:57 --> URI Class Initialized
INFO - 2020-07-29 16:15:57 --> Router Class Initialized
INFO - 2020-07-29 16:15:57 --> Output Class Initialized
INFO - 2020-07-29 16:15:57 --> Security Class Initialized
DEBUG - 2020-07-29 16:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:15:57 --> Input Class Initialized
INFO - 2020-07-29 16:15:57 --> Language Class Initialized
INFO - 2020-07-29 16:15:57 --> Loader Class Initialized
INFO - 2020-07-29 16:15:57 --> Helper loaded: url_helper
INFO - 2020-07-29 16:15:57 --> Database Driver Class Initialized
INFO - 2020-07-29 16:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:15:57 --> Email Class Initialized
INFO - 2020-07-29 16:15:57 --> Controller Class Initialized
DEBUG - 2020-07-29 16:15:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 16:15:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:15:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 16:15:57 --> Final output sent to browser
DEBUG - 2020-07-29 16:15:57 --> Total execution time: 0.0210
INFO - 2020-07-29 16:16:04 --> Config Class Initialized
INFO - 2020-07-29 16:16:04 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:16:04 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:16:04 --> Utf8 Class Initialized
INFO - 2020-07-29 16:16:04 --> URI Class Initialized
DEBUG - 2020-07-29 16:16:04 --> No URI present. Default controller set.
INFO - 2020-07-29 16:16:04 --> Router Class Initialized
INFO - 2020-07-29 16:16:04 --> Output Class Initialized
INFO - 2020-07-29 16:16:04 --> Security Class Initialized
DEBUG - 2020-07-29 16:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:16:04 --> Input Class Initialized
INFO - 2020-07-29 16:16:04 --> Language Class Initialized
INFO - 2020-07-29 16:16:04 --> Loader Class Initialized
INFO - 2020-07-29 16:16:04 --> Helper loaded: url_helper
INFO - 2020-07-29 16:16:04 --> Database Driver Class Initialized
INFO - 2020-07-29 16:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:16:04 --> Email Class Initialized
INFO - 2020-07-29 16:16:04 --> Controller Class Initialized
INFO - 2020-07-29 16:16:04 --> Model Class Initialized
INFO - 2020-07-29 16:16:04 --> Model Class Initialized
DEBUG - 2020-07-29 16:16:04 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:16:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:16:04 --> Final output sent to browser
DEBUG - 2020-07-29 16:16:04 --> Total execution time: 0.0248
INFO - 2020-07-29 16:16:13 --> Config Class Initialized
INFO - 2020-07-29 16:16:13 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:16:13 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:16:13 --> Utf8 Class Initialized
INFO - 2020-07-29 16:16:13 --> URI Class Initialized
INFO - 2020-07-29 16:16:13 --> Router Class Initialized
INFO - 2020-07-29 16:16:13 --> Output Class Initialized
INFO - 2020-07-29 16:16:13 --> Security Class Initialized
DEBUG - 2020-07-29 16:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:16:13 --> Input Class Initialized
INFO - 2020-07-29 16:16:13 --> Language Class Initialized
INFO - 2020-07-29 16:16:13 --> Loader Class Initialized
INFO - 2020-07-29 16:16:13 --> Helper loaded: url_helper
INFO - 2020-07-29 16:16:13 --> Database Driver Class Initialized
INFO - 2020-07-29 16:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:16:13 --> Email Class Initialized
INFO - 2020-07-29 16:16:13 --> Controller Class Initialized
INFO - 2020-07-29 16:16:13 --> Model Class Initialized
INFO - 2020-07-29 16:16:13 --> Model Class Initialized
DEBUG - 2020-07-29 16:16:13 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:16:13 --> Config Class Initialized
INFO - 2020-07-29 16:16:13 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:16:13 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:16:13 --> Utf8 Class Initialized
INFO - 2020-07-29 16:16:13 --> URI Class Initialized
DEBUG - 2020-07-29 16:16:13 --> No URI present. Default controller set.
INFO - 2020-07-29 16:16:13 --> Router Class Initialized
INFO - 2020-07-29 16:16:13 --> Output Class Initialized
INFO - 2020-07-29 16:16:13 --> Security Class Initialized
DEBUG - 2020-07-29 16:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:16:13 --> Input Class Initialized
INFO - 2020-07-29 16:16:13 --> Language Class Initialized
INFO - 2020-07-29 16:16:13 --> Loader Class Initialized
INFO - 2020-07-29 16:16:13 --> Helper loaded: url_helper
INFO - 2020-07-29 16:16:13 --> Database Driver Class Initialized
INFO - 2020-07-29 16:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:16:13 --> Email Class Initialized
INFO - 2020-07-29 16:16:13 --> Controller Class Initialized
INFO - 2020-07-29 16:16:13 --> Model Class Initialized
INFO - 2020-07-29 16:16:13 --> Model Class Initialized
DEBUG - 2020-07-29 16:16:13 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:16:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:16:13 --> Final output sent to browser
DEBUG - 2020-07-29 16:16:13 --> Total execution time: 0.0252
INFO - 2020-07-29 16:18:35 --> Config Class Initialized
INFO - 2020-07-29 16:18:35 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:35 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:35 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:35 --> URI Class Initialized
DEBUG - 2020-07-29 16:18:35 --> No URI present. Default controller set.
INFO - 2020-07-29 16:18:35 --> Router Class Initialized
INFO - 2020-07-29 16:18:35 --> Output Class Initialized
INFO - 2020-07-29 16:18:35 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:35 --> Input Class Initialized
INFO - 2020-07-29 16:18:35 --> Language Class Initialized
INFO - 2020-07-29 16:18:35 --> Loader Class Initialized
INFO - 2020-07-29 16:18:35 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:35 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:35 --> Email Class Initialized
INFO - 2020-07-29 16:18:35 --> Controller Class Initialized
INFO - 2020-07-29 16:18:35 --> Model Class Initialized
INFO - 2020-07-29 16:18:35 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:35 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:18:35 --> Final output sent to browser
DEBUG - 2020-07-29 16:18:35 --> Total execution time: 0.0236
INFO - 2020-07-29 16:18:35 --> Config Class Initialized
INFO - 2020-07-29 16:18:35 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:35 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:35 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:35 --> URI Class Initialized
INFO - 2020-07-29 16:18:35 --> Router Class Initialized
INFO - 2020-07-29 16:18:35 --> Output Class Initialized
INFO - 2020-07-29 16:18:35 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:35 --> Input Class Initialized
INFO - 2020-07-29 16:18:35 --> Language Class Initialized
INFO - 2020-07-29 16:18:35 --> Loader Class Initialized
INFO - 2020-07-29 16:18:35 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:35 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:35 --> Email Class Initialized
INFO - 2020-07-29 16:18:35 --> Controller Class Initialized
INFO - 2020-07-29 16:18:35 --> Model Class Initialized
INFO - 2020-07-29 16:18:35 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:35 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:36 --> Config Class Initialized
INFO - 2020-07-29 16:18:36 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:36 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:36 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:36 --> URI Class Initialized
DEBUG - 2020-07-29 16:18:36 --> No URI present. Default controller set.
INFO - 2020-07-29 16:18:36 --> Router Class Initialized
INFO - 2020-07-29 16:18:36 --> Output Class Initialized
INFO - 2020-07-29 16:18:36 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:36 --> Input Class Initialized
INFO - 2020-07-29 16:18:36 --> Language Class Initialized
INFO - 2020-07-29 16:18:36 --> Loader Class Initialized
INFO - 2020-07-29 16:18:36 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:36 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:36 --> Email Class Initialized
INFO - 2020-07-29 16:18:36 --> Controller Class Initialized
INFO - 2020-07-29 16:18:36 --> Model Class Initialized
INFO - 2020-07-29 16:18:36 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:36 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:18:36 --> Final output sent to browser
DEBUG - 2020-07-29 16:18:36 --> Total execution time: 0.0236
INFO - 2020-07-29 16:18:37 --> Config Class Initialized
INFO - 2020-07-29 16:18:37 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:37 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:37 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:37 --> URI Class Initialized
INFO - 2020-07-29 16:18:37 --> Router Class Initialized
INFO - 2020-07-29 16:18:37 --> Output Class Initialized
INFO - 2020-07-29 16:18:37 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:37 --> Input Class Initialized
INFO - 2020-07-29 16:18:37 --> Language Class Initialized
INFO - 2020-07-29 16:18:37 --> Loader Class Initialized
INFO - 2020-07-29 16:18:37 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:37 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:37 --> Email Class Initialized
INFO - 2020-07-29 16:18:37 --> Controller Class Initialized
INFO - 2020-07-29 16:18:37 --> Model Class Initialized
INFO - 2020-07-29 16:18:37 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:37 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:37 --> Config Class Initialized
INFO - 2020-07-29 16:18:37 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:37 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:37 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:37 --> URI Class Initialized
DEBUG - 2020-07-29 16:18:37 --> No URI present. Default controller set.
INFO - 2020-07-29 16:18:37 --> Router Class Initialized
INFO - 2020-07-29 16:18:37 --> Output Class Initialized
INFO - 2020-07-29 16:18:37 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:37 --> Input Class Initialized
INFO - 2020-07-29 16:18:37 --> Language Class Initialized
INFO - 2020-07-29 16:18:37 --> Loader Class Initialized
INFO - 2020-07-29 16:18:37 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:37 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:37 --> Email Class Initialized
INFO - 2020-07-29 16:18:37 --> Controller Class Initialized
INFO - 2020-07-29 16:18:37 --> Model Class Initialized
INFO - 2020-07-29 16:18:37 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:37 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:18:37 --> Final output sent to browser
DEBUG - 2020-07-29 16:18:37 --> Total execution time: 0.0267
INFO - 2020-07-29 16:18:38 --> Config Class Initialized
INFO - 2020-07-29 16:18:38 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:38 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:38 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:38 --> URI Class Initialized
INFO - 2020-07-29 16:18:38 --> Router Class Initialized
INFO - 2020-07-29 16:18:38 --> Output Class Initialized
INFO - 2020-07-29 16:18:38 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:38 --> Input Class Initialized
INFO - 2020-07-29 16:18:38 --> Language Class Initialized
INFO - 2020-07-29 16:18:38 --> Loader Class Initialized
INFO - 2020-07-29 16:18:38 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:38 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:38 --> Email Class Initialized
INFO - 2020-07-29 16:18:38 --> Controller Class Initialized
INFO - 2020-07-29 16:18:38 --> Model Class Initialized
INFO - 2020-07-29 16:18:38 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:38 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:38 --> Config Class Initialized
INFO - 2020-07-29 16:18:38 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:38 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:38 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:38 --> URI Class Initialized
DEBUG - 2020-07-29 16:18:38 --> No URI present. Default controller set.
INFO - 2020-07-29 16:18:38 --> Router Class Initialized
INFO - 2020-07-29 16:18:38 --> Output Class Initialized
INFO - 2020-07-29 16:18:38 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:38 --> Input Class Initialized
INFO - 2020-07-29 16:18:38 --> Language Class Initialized
INFO - 2020-07-29 16:18:38 --> Loader Class Initialized
INFO - 2020-07-29 16:18:38 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:38 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:38 --> Email Class Initialized
INFO - 2020-07-29 16:18:38 --> Controller Class Initialized
INFO - 2020-07-29 16:18:38 --> Model Class Initialized
INFO - 2020-07-29 16:18:38 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:38 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:18:38 --> Final output sent to browser
DEBUG - 2020-07-29 16:18:38 --> Total execution time: 0.0378
INFO - 2020-07-29 16:18:39 --> Config Class Initialized
INFO - 2020-07-29 16:18:39 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:39 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:39 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:39 --> URI Class Initialized
INFO - 2020-07-29 16:18:39 --> Router Class Initialized
INFO - 2020-07-29 16:18:39 --> Output Class Initialized
INFO - 2020-07-29 16:18:39 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:39 --> Input Class Initialized
INFO - 2020-07-29 16:18:39 --> Language Class Initialized
INFO - 2020-07-29 16:18:39 --> Loader Class Initialized
INFO - 2020-07-29 16:18:39 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:39 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:39 --> Email Class Initialized
INFO - 2020-07-29 16:18:39 --> Controller Class Initialized
INFO - 2020-07-29 16:18:39 --> Model Class Initialized
INFO - 2020-07-29 16:18:39 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:39 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:40 --> Config Class Initialized
INFO - 2020-07-29 16:18:40 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:40 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:40 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:40 --> URI Class Initialized
DEBUG - 2020-07-29 16:18:40 --> No URI present. Default controller set.
INFO - 2020-07-29 16:18:40 --> Router Class Initialized
INFO - 2020-07-29 16:18:40 --> Output Class Initialized
INFO - 2020-07-29 16:18:40 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:40 --> Input Class Initialized
INFO - 2020-07-29 16:18:40 --> Language Class Initialized
INFO - 2020-07-29 16:18:40 --> Loader Class Initialized
INFO - 2020-07-29 16:18:40 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:40 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:40 --> Email Class Initialized
INFO - 2020-07-29 16:18:40 --> Controller Class Initialized
INFO - 2020-07-29 16:18:40 --> Model Class Initialized
INFO - 2020-07-29 16:18:40 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:18:40 --> Final output sent to browser
DEBUG - 2020-07-29 16:18:40 --> Total execution time: 0.0398
INFO - 2020-07-29 16:18:40 --> Config Class Initialized
INFO - 2020-07-29 16:18:40 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:40 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:40 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:40 --> URI Class Initialized
INFO - 2020-07-29 16:18:40 --> Router Class Initialized
INFO - 2020-07-29 16:18:40 --> Output Class Initialized
INFO - 2020-07-29 16:18:40 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:40 --> Input Class Initialized
INFO - 2020-07-29 16:18:40 --> Language Class Initialized
INFO - 2020-07-29 16:18:40 --> Loader Class Initialized
INFO - 2020-07-29 16:18:40 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:40 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:40 --> Email Class Initialized
INFO - 2020-07-29 16:18:40 --> Controller Class Initialized
INFO - 2020-07-29 16:18:40 --> Model Class Initialized
INFO - 2020-07-29 16:18:40 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:41 --> Config Class Initialized
INFO - 2020-07-29 16:18:41 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:41 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:41 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:41 --> URI Class Initialized
DEBUG - 2020-07-29 16:18:41 --> No URI present. Default controller set.
INFO - 2020-07-29 16:18:41 --> Router Class Initialized
INFO - 2020-07-29 16:18:41 --> Output Class Initialized
INFO - 2020-07-29 16:18:41 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:41 --> Input Class Initialized
INFO - 2020-07-29 16:18:41 --> Language Class Initialized
INFO - 2020-07-29 16:18:41 --> Loader Class Initialized
INFO - 2020-07-29 16:18:41 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:41 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:41 --> Email Class Initialized
INFO - 2020-07-29 16:18:41 --> Controller Class Initialized
INFO - 2020-07-29 16:18:41 --> Model Class Initialized
INFO - 2020-07-29 16:18:41 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:41 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:18:41 --> Final output sent to browser
DEBUG - 2020-07-29 16:18:41 --> Total execution time: 0.0252
INFO - 2020-07-29 16:18:42 --> Config Class Initialized
INFO - 2020-07-29 16:18:42 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:42 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:42 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:42 --> URI Class Initialized
INFO - 2020-07-29 16:18:42 --> Router Class Initialized
INFO - 2020-07-29 16:18:42 --> Output Class Initialized
INFO - 2020-07-29 16:18:42 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:42 --> Input Class Initialized
INFO - 2020-07-29 16:18:42 --> Language Class Initialized
INFO - 2020-07-29 16:18:42 --> Loader Class Initialized
INFO - 2020-07-29 16:18:42 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:42 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:42 --> Email Class Initialized
INFO - 2020-07-29 16:18:42 --> Controller Class Initialized
INFO - 2020-07-29 16:18:42 --> Model Class Initialized
INFO - 2020-07-29 16:18:42 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:42 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:42 --> Config Class Initialized
INFO - 2020-07-29 16:18:42 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:42 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:42 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:42 --> URI Class Initialized
DEBUG - 2020-07-29 16:18:42 --> No URI present. Default controller set.
INFO - 2020-07-29 16:18:42 --> Router Class Initialized
INFO - 2020-07-29 16:18:42 --> Output Class Initialized
INFO - 2020-07-29 16:18:42 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:42 --> Input Class Initialized
INFO - 2020-07-29 16:18:42 --> Language Class Initialized
INFO - 2020-07-29 16:18:42 --> Loader Class Initialized
INFO - 2020-07-29 16:18:42 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:42 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:42 --> Email Class Initialized
INFO - 2020-07-29 16:18:42 --> Controller Class Initialized
INFO - 2020-07-29 16:18:42 --> Model Class Initialized
INFO - 2020-07-29 16:18:42 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:42 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:18:42 --> Final output sent to browser
DEBUG - 2020-07-29 16:18:42 --> Total execution time: 0.0212
INFO - 2020-07-29 16:18:43 --> Config Class Initialized
INFO - 2020-07-29 16:18:43 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:43 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:43 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:43 --> URI Class Initialized
INFO - 2020-07-29 16:18:43 --> Router Class Initialized
INFO - 2020-07-29 16:18:43 --> Output Class Initialized
INFO - 2020-07-29 16:18:43 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:43 --> Input Class Initialized
INFO - 2020-07-29 16:18:43 --> Language Class Initialized
INFO - 2020-07-29 16:18:43 --> Loader Class Initialized
INFO - 2020-07-29 16:18:43 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:43 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:43 --> Email Class Initialized
INFO - 2020-07-29 16:18:43 --> Controller Class Initialized
INFO - 2020-07-29 16:18:43 --> Model Class Initialized
INFO - 2020-07-29 16:18:43 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:43 --> Config Class Initialized
INFO - 2020-07-29 16:18:43 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:43 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:43 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:43 --> URI Class Initialized
DEBUG - 2020-07-29 16:18:43 --> No URI present. Default controller set.
INFO - 2020-07-29 16:18:43 --> Router Class Initialized
INFO - 2020-07-29 16:18:43 --> Output Class Initialized
INFO - 2020-07-29 16:18:43 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:43 --> Input Class Initialized
INFO - 2020-07-29 16:18:43 --> Language Class Initialized
INFO - 2020-07-29 16:18:43 --> Loader Class Initialized
INFO - 2020-07-29 16:18:43 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:43 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:43 --> Email Class Initialized
INFO - 2020-07-29 16:18:43 --> Controller Class Initialized
INFO - 2020-07-29 16:18:43 --> Model Class Initialized
INFO - 2020-07-29 16:18:43 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:18:43 --> Final output sent to browser
DEBUG - 2020-07-29 16:18:43 --> Total execution time: 0.0227
INFO - 2020-07-29 16:18:44 --> Config Class Initialized
INFO - 2020-07-29 16:18:44 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:44 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:44 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:44 --> URI Class Initialized
INFO - 2020-07-29 16:18:44 --> Router Class Initialized
INFO - 2020-07-29 16:18:44 --> Output Class Initialized
INFO - 2020-07-29 16:18:44 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:44 --> Input Class Initialized
INFO - 2020-07-29 16:18:44 --> Language Class Initialized
INFO - 2020-07-29 16:18:44 --> Loader Class Initialized
INFO - 2020-07-29 16:18:44 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:44 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:44 --> Email Class Initialized
INFO - 2020-07-29 16:18:44 --> Controller Class Initialized
INFO - 2020-07-29 16:18:44 --> Model Class Initialized
INFO - 2020-07-29 16:18:44 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:44 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:44 --> Config Class Initialized
INFO - 2020-07-29 16:18:44 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:44 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:44 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:44 --> URI Class Initialized
DEBUG - 2020-07-29 16:18:44 --> No URI present. Default controller set.
INFO - 2020-07-29 16:18:44 --> Router Class Initialized
INFO - 2020-07-29 16:18:44 --> Output Class Initialized
INFO - 2020-07-29 16:18:44 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:44 --> Input Class Initialized
INFO - 2020-07-29 16:18:44 --> Language Class Initialized
INFO - 2020-07-29 16:18:44 --> Loader Class Initialized
INFO - 2020-07-29 16:18:44 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:44 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:44 --> Email Class Initialized
INFO - 2020-07-29 16:18:44 --> Controller Class Initialized
INFO - 2020-07-29 16:18:44 --> Model Class Initialized
INFO - 2020-07-29 16:18:44 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:44 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:18:44 --> Final output sent to browser
DEBUG - 2020-07-29 16:18:44 --> Total execution time: 0.0240
INFO - 2020-07-29 16:18:45 --> Config Class Initialized
INFO - 2020-07-29 16:18:45 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:45 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:45 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:45 --> URI Class Initialized
INFO - 2020-07-29 16:18:45 --> Router Class Initialized
INFO - 2020-07-29 16:18:45 --> Output Class Initialized
INFO - 2020-07-29 16:18:45 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:45 --> Input Class Initialized
INFO - 2020-07-29 16:18:45 --> Language Class Initialized
INFO - 2020-07-29 16:18:45 --> Loader Class Initialized
INFO - 2020-07-29 16:18:45 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:45 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:45 --> Email Class Initialized
INFO - 2020-07-29 16:18:45 --> Controller Class Initialized
INFO - 2020-07-29 16:18:45 --> Model Class Initialized
INFO - 2020-07-29 16:18:45 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:45 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:46 --> Config Class Initialized
INFO - 2020-07-29 16:18:46 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:46 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:46 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:46 --> URI Class Initialized
DEBUG - 2020-07-29 16:18:46 --> No URI present. Default controller set.
INFO - 2020-07-29 16:18:46 --> Router Class Initialized
INFO - 2020-07-29 16:18:46 --> Output Class Initialized
INFO - 2020-07-29 16:18:46 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:46 --> Input Class Initialized
INFO - 2020-07-29 16:18:46 --> Language Class Initialized
INFO - 2020-07-29 16:18:46 --> Loader Class Initialized
INFO - 2020-07-29 16:18:46 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:46 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:46 --> Email Class Initialized
INFO - 2020-07-29 16:18:46 --> Controller Class Initialized
INFO - 2020-07-29 16:18:46 --> Model Class Initialized
INFO - 2020-07-29 16:18:46 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:46 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:18:46 --> Final output sent to browser
DEBUG - 2020-07-29 16:18:46 --> Total execution time: 0.0270
INFO - 2020-07-29 16:18:46 --> Config Class Initialized
INFO - 2020-07-29 16:18:46 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:46 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:46 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:46 --> URI Class Initialized
INFO - 2020-07-29 16:18:46 --> Router Class Initialized
INFO - 2020-07-29 16:18:46 --> Output Class Initialized
INFO - 2020-07-29 16:18:46 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:46 --> Input Class Initialized
INFO - 2020-07-29 16:18:46 --> Language Class Initialized
INFO - 2020-07-29 16:18:46 --> Loader Class Initialized
INFO - 2020-07-29 16:18:46 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:46 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:46 --> Email Class Initialized
INFO - 2020-07-29 16:18:46 --> Controller Class Initialized
INFO - 2020-07-29 16:18:46 --> Model Class Initialized
INFO - 2020-07-29 16:18:46 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:46 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:47 --> Config Class Initialized
INFO - 2020-07-29 16:18:47 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:47 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:47 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:47 --> URI Class Initialized
DEBUG - 2020-07-29 16:18:47 --> No URI present. Default controller set.
INFO - 2020-07-29 16:18:47 --> Router Class Initialized
INFO - 2020-07-29 16:18:47 --> Output Class Initialized
INFO - 2020-07-29 16:18:47 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:47 --> Input Class Initialized
INFO - 2020-07-29 16:18:47 --> Language Class Initialized
INFO - 2020-07-29 16:18:47 --> Loader Class Initialized
INFO - 2020-07-29 16:18:47 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:47 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:47 --> Email Class Initialized
INFO - 2020-07-29 16:18:47 --> Controller Class Initialized
INFO - 2020-07-29 16:18:47 --> Model Class Initialized
INFO - 2020-07-29 16:18:47 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:47 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:18:47 --> Final output sent to browser
DEBUG - 2020-07-29 16:18:47 --> Total execution time: 0.0212
INFO - 2020-07-29 16:18:47 --> Config Class Initialized
INFO - 2020-07-29 16:18:47 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:47 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:47 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:47 --> URI Class Initialized
INFO - 2020-07-29 16:18:47 --> Router Class Initialized
INFO - 2020-07-29 16:18:47 --> Output Class Initialized
INFO - 2020-07-29 16:18:47 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:47 --> Input Class Initialized
INFO - 2020-07-29 16:18:47 --> Language Class Initialized
INFO - 2020-07-29 16:18:47 --> Loader Class Initialized
INFO - 2020-07-29 16:18:47 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:47 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:47 --> Email Class Initialized
INFO - 2020-07-29 16:18:47 --> Controller Class Initialized
INFO - 2020-07-29 16:18:47 --> Model Class Initialized
INFO - 2020-07-29 16:18:47 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:47 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:48 --> Config Class Initialized
INFO - 2020-07-29 16:18:48 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:48 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:48 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:48 --> URI Class Initialized
DEBUG - 2020-07-29 16:18:48 --> No URI present. Default controller set.
INFO - 2020-07-29 16:18:48 --> Router Class Initialized
INFO - 2020-07-29 16:18:48 --> Output Class Initialized
INFO - 2020-07-29 16:18:48 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:48 --> Input Class Initialized
INFO - 2020-07-29 16:18:48 --> Language Class Initialized
INFO - 2020-07-29 16:18:48 --> Loader Class Initialized
INFO - 2020-07-29 16:18:48 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:48 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:48 --> Email Class Initialized
INFO - 2020-07-29 16:18:48 --> Controller Class Initialized
INFO - 2020-07-29 16:18:48 --> Model Class Initialized
INFO - 2020-07-29 16:18:48 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:48 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:18:48 --> Final output sent to browser
DEBUG - 2020-07-29 16:18:48 --> Total execution time: 0.0217
INFO - 2020-07-29 16:18:49 --> Config Class Initialized
INFO - 2020-07-29 16:18:49 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:49 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:49 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:49 --> URI Class Initialized
INFO - 2020-07-29 16:18:49 --> Router Class Initialized
INFO - 2020-07-29 16:18:49 --> Output Class Initialized
INFO - 2020-07-29 16:18:49 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:49 --> Input Class Initialized
INFO - 2020-07-29 16:18:49 --> Language Class Initialized
INFO - 2020-07-29 16:18:49 --> Loader Class Initialized
INFO - 2020-07-29 16:18:49 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:49 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:49 --> Email Class Initialized
INFO - 2020-07-29 16:18:49 --> Controller Class Initialized
INFO - 2020-07-29 16:18:49 --> Model Class Initialized
INFO - 2020-07-29 16:18:49 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:49 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:49 --> Config Class Initialized
INFO - 2020-07-29 16:18:49 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:49 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:49 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:49 --> URI Class Initialized
DEBUG - 2020-07-29 16:18:49 --> No URI present. Default controller set.
INFO - 2020-07-29 16:18:49 --> Router Class Initialized
INFO - 2020-07-29 16:18:49 --> Output Class Initialized
INFO - 2020-07-29 16:18:49 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:49 --> Input Class Initialized
INFO - 2020-07-29 16:18:49 --> Language Class Initialized
INFO - 2020-07-29 16:18:49 --> Loader Class Initialized
INFO - 2020-07-29 16:18:49 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:49 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:49 --> Email Class Initialized
INFO - 2020-07-29 16:18:49 --> Controller Class Initialized
INFO - 2020-07-29 16:18:49 --> Model Class Initialized
INFO - 2020-07-29 16:18:49 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:49 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:18:49 --> Final output sent to browser
DEBUG - 2020-07-29 16:18:49 --> Total execution time: 0.0212
INFO - 2020-07-29 16:18:49 --> Config Class Initialized
INFO - 2020-07-29 16:18:49 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:49 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:49 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:49 --> URI Class Initialized
INFO - 2020-07-29 16:18:49 --> Router Class Initialized
INFO - 2020-07-29 16:18:49 --> Output Class Initialized
INFO - 2020-07-29 16:18:49 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:49 --> Input Class Initialized
INFO - 2020-07-29 16:18:49 --> Language Class Initialized
INFO - 2020-07-29 16:18:49 --> Loader Class Initialized
INFO - 2020-07-29 16:18:49 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:49 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:49 --> Email Class Initialized
INFO - 2020-07-29 16:18:49 --> Controller Class Initialized
INFO - 2020-07-29 16:18:49 --> Model Class Initialized
INFO - 2020-07-29 16:18:49 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:49 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:50 --> Config Class Initialized
INFO - 2020-07-29 16:18:50 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:50 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:50 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:50 --> URI Class Initialized
DEBUG - 2020-07-29 16:18:50 --> No URI present. Default controller set.
INFO - 2020-07-29 16:18:50 --> Router Class Initialized
INFO - 2020-07-29 16:18:50 --> Output Class Initialized
INFO - 2020-07-29 16:18:50 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:50 --> Input Class Initialized
INFO - 2020-07-29 16:18:50 --> Language Class Initialized
INFO - 2020-07-29 16:18:50 --> Loader Class Initialized
INFO - 2020-07-29 16:18:50 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:50 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:50 --> Email Class Initialized
INFO - 2020-07-29 16:18:50 --> Controller Class Initialized
INFO - 2020-07-29 16:18:50 --> Model Class Initialized
INFO - 2020-07-29 16:18:50 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:18:50 --> Final output sent to browser
DEBUG - 2020-07-29 16:18:50 --> Total execution time: 0.0221
INFO - 2020-07-29 16:18:51 --> Config Class Initialized
INFO - 2020-07-29 16:18:51 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:51 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:51 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:51 --> URI Class Initialized
INFO - 2020-07-29 16:18:51 --> Router Class Initialized
INFO - 2020-07-29 16:18:51 --> Output Class Initialized
INFO - 2020-07-29 16:18:51 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:51 --> Input Class Initialized
INFO - 2020-07-29 16:18:51 --> Language Class Initialized
INFO - 2020-07-29 16:18:51 --> Loader Class Initialized
INFO - 2020-07-29 16:18:51 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:51 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:51 --> Email Class Initialized
INFO - 2020-07-29 16:18:51 --> Controller Class Initialized
INFO - 2020-07-29 16:18:51 --> Model Class Initialized
INFO - 2020-07-29 16:18:51 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:51 --> Config Class Initialized
INFO - 2020-07-29 16:18:51 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:51 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:51 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:51 --> URI Class Initialized
DEBUG - 2020-07-29 16:18:51 --> No URI present. Default controller set.
INFO - 2020-07-29 16:18:51 --> Router Class Initialized
INFO - 2020-07-29 16:18:51 --> Output Class Initialized
INFO - 2020-07-29 16:18:51 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:51 --> Input Class Initialized
INFO - 2020-07-29 16:18:51 --> Language Class Initialized
INFO - 2020-07-29 16:18:51 --> Loader Class Initialized
INFO - 2020-07-29 16:18:51 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:51 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:51 --> Email Class Initialized
INFO - 2020-07-29 16:18:51 --> Controller Class Initialized
INFO - 2020-07-29 16:18:51 --> Model Class Initialized
INFO - 2020-07-29 16:18:51 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:18:51 --> Final output sent to browser
DEBUG - 2020-07-29 16:18:51 --> Total execution time: 0.0211
INFO - 2020-07-29 16:18:52 --> Config Class Initialized
INFO - 2020-07-29 16:18:52 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:52 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:52 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:52 --> URI Class Initialized
INFO - 2020-07-29 16:18:52 --> Router Class Initialized
INFO - 2020-07-29 16:18:52 --> Output Class Initialized
INFO - 2020-07-29 16:18:52 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:52 --> Input Class Initialized
INFO - 2020-07-29 16:18:52 --> Language Class Initialized
INFO - 2020-07-29 16:18:52 --> Loader Class Initialized
INFO - 2020-07-29 16:18:52 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:52 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:52 --> Email Class Initialized
INFO - 2020-07-29 16:18:52 --> Controller Class Initialized
INFO - 2020-07-29 16:18:52 --> Model Class Initialized
INFO - 2020-07-29 16:18:52 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:52 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:52 --> Config Class Initialized
INFO - 2020-07-29 16:18:52 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:52 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:52 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:52 --> URI Class Initialized
DEBUG - 2020-07-29 16:18:52 --> No URI present. Default controller set.
INFO - 2020-07-29 16:18:52 --> Router Class Initialized
INFO - 2020-07-29 16:18:52 --> Output Class Initialized
INFO - 2020-07-29 16:18:52 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:52 --> Input Class Initialized
INFO - 2020-07-29 16:18:52 --> Language Class Initialized
INFO - 2020-07-29 16:18:52 --> Loader Class Initialized
INFO - 2020-07-29 16:18:52 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:52 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:53 --> Email Class Initialized
INFO - 2020-07-29 16:18:53 --> Controller Class Initialized
INFO - 2020-07-29 16:18:53 --> Model Class Initialized
INFO - 2020-07-29 16:18:53 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:53 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:18:53 --> Final output sent to browser
DEBUG - 2020-07-29 16:18:53 --> Total execution time: 0.0227
INFO - 2020-07-29 16:18:53 --> Config Class Initialized
INFO - 2020-07-29 16:18:53 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:53 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:53 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:53 --> URI Class Initialized
INFO - 2020-07-29 16:18:53 --> Router Class Initialized
INFO - 2020-07-29 16:18:53 --> Output Class Initialized
INFO - 2020-07-29 16:18:53 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:53 --> Input Class Initialized
INFO - 2020-07-29 16:18:53 --> Language Class Initialized
INFO - 2020-07-29 16:18:53 --> Loader Class Initialized
INFO - 2020-07-29 16:18:53 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:53 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:53 --> Email Class Initialized
INFO - 2020-07-29 16:18:53 --> Controller Class Initialized
INFO - 2020-07-29 16:18:53 --> Model Class Initialized
INFO - 2020-07-29 16:18:53 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:53 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:54 --> Config Class Initialized
INFO - 2020-07-29 16:18:54 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:54 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:54 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:54 --> URI Class Initialized
DEBUG - 2020-07-29 16:18:54 --> No URI present. Default controller set.
INFO - 2020-07-29 16:18:54 --> Router Class Initialized
INFO - 2020-07-29 16:18:54 --> Output Class Initialized
INFO - 2020-07-29 16:18:54 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:54 --> Input Class Initialized
INFO - 2020-07-29 16:18:54 --> Language Class Initialized
INFO - 2020-07-29 16:18:54 --> Loader Class Initialized
INFO - 2020-07-29 16:18:54 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:54 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:54 --> Email Class Initialized
INFO - 2020-07-29 16:18:54 --> Controller Class Initialized
INFO - 2020-07-29 16:18:54 --> Model Class Initialized
INFO - 2020-07-29 16:18:54 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:54 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:18:54 --> Final output sent to browser
DEBUG - 2020-07-29 16:18:54 --> Total execution time: 0.0227
INFO - 2020-07-29 16:18:54 --> Config Class Initialized
INFO - 2020-07-29 16:18:54 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:54 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:54 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:54 --> URI Class Initialized
INFO - 2020-07-29 16:18:54 --> Router Class Initialized
INFO - 2020-07-29 16:18:54 --> Output Class Initialized
INFO - 2020-07-29 16:18:54 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:54 --> Input Class Initialized
INFO - 2020-07-29 16:18:54 --> Language Class Initialized
INFO - 2020-07-29 16:18:54 --> Loader Class Initialized
INFO - 2020-07-29 16:18:54 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:54 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:54 --> Email Class Initialized
INFO - 2020-07-29 16:18:54 --> Controller Class Initialized
INFO - 2020-07-29 16:18:54 --> Model Class Initialized
INFO - 2020-07-29 16:18:54 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:54 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:55 --> Config Class Initialized
INFO - 2020-07-29 16:18:55 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:55 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:55 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:55 --> URI Class Initialized
DEBUG - 2020-07-29 16:18:55 --> No URI present. Default controller set.
INFO - 2020-07-29 16:18:55 --> Router Class Initialized
INFO - 2020-07-29 16:18:55 --> Output Class Initialized
INFO - 2020-07-29 16:18:55 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:55 --> Input Class Initialized
INFO - 2020-07-29 16:18:55 --> Language Class Initialized
INFO - 2020-07-29 16:18:55 --> Loader Class Initialized
INFO - 2020-07-29 16:18:55 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:55 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:55 --> Email Class Initialized
INFO - 2020-07-29 16:18:55 --> Controller Class Initialized
INFO - 2020-07-29 16:18:55 --> Model Class Initialized
INFO - 2020-07-29 16:18:55 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:55 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:18:55 --> Final output sent to browser
DEBUG - 2020-07-29 16:18:55 --> Total execution time: 0.0214
INFO - 2020-07-29 16:18:56 --> Config Class Initialized
INFO - 2020-07-29 16:18:56 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:56 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:56 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:56 --> URI Class Initialized
INFO - 2020-07-29 16:18:56 --> Router Class Initialized
INFO - 2020-07-29 16:18:56 --> Output Class Initialized
INFO - 2020-07-29 16:18:56 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:56 --> Input Class Initialized
INFO - 2020-07-29 16:18:56 --> Language Class Initialized
INFO - 2020-07-29 16:18:56 --> Loader Class Initialized
INFO - 2020-07-29 16:18:56 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:56 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:56 --> Email Class Initialized
INFO - 2020-07-29 16:18:56 --> Controller Class Initialized
INFO - 2020-07-29 16:18:56 --> Model Class Initialized
INFO - 2020-07-29 16:18:56 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:56 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:56 --> Config Class Initialized
INFO - 2020-07-29 16:18:56 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:56 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:56 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:56 --> URI Class Initialized
DEBUG - 2020-07-29 16:18:56 --> No URI present. Default controller set.
INFO - 2020-07-29 16:18:56 --> Router Class Initialized
INFO - 2020-07-29 16:18:56 --> Output Class Initialized
INFO - 2020-07-29 16:18:56 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:56 --> Input Class Initialized
INFO - 2020-07-29 16:18:56 --> Language Class Initialized
INFO - 2020-07-29 16:18:56 --> Loader Class Initialized
INFO - 2020-07-29 16:18:56 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:56 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:56 --> Email Class Initialized
INFO - 2020-07-29 16:18:56 --> Controller Class Initialized
INFO - 2020-07-29 16:18:56 --> Model Class Initialized
INFO - 2020-07-29 16:18:56 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:56 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:18:56 --> Final output sent to browser
DEBUG - 2020-07-29 16:18:56 --> Total execution time: 0.0234
INFO - 2020-07-29 16:18:57 --> Config Class Initialized
INFO - 2020-07-29 16:18:57 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:57 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:57 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:57 --> URI Class Initialized
INFO - 2020-07-29 16:18:57 --> Router Class Initialized
INFO - 2020-07-29 16:18:57 --> Output Class Initialized
INFO - 2020-07-29 16:18:57 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:57 --> Input Class Initialized
INFO - 2020-07-29 16:18:57 --> Language Class Initialized
INFO - 2020-07-29 16:18:57 --> Loader Class Initialized
INFO - 2020-07-29 16:18:57 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:57 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:57 --> Email Class Initialized
INFO - 2020-07-29 16:18:57 --> Controller Class Initialized
INFO - 2020-07-29 16:18:57 --> Model Class Initialized
INFO - 2020-07-29 16:18:57 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:57 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:58 --> Config Class Initialized
INFO - 2020-07-29 16:18:58 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:58 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:58 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:58 --> URI Class Initialized
DEBUG - 2020-07-29 16:18:58 --> No URI present. Default controller set.
INFO - 2020-07-29 16:18:58 --> Router Class Initialized
INFO - 2020-07-29 16:18:58 --> Output Class Initialized
INFO - 2020-07-29 16:18:58 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:58 --> Input Class Initialized
INFO - 2020-07-29 16:18:58 --> Language Class Initialized
INFO - 2020-07-29 16:18:58 --> Loader Class Initialized
INFO - 2020-07-29 16:18:58 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:58 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:58 --> Email Class Initialized
INFO - 2020-07-29 16:18:58 --> Controller Class Initialized
INFO - 2020-07-29 16:18:58 --> Model Class Initialized
INFO - 2020-07-29 16:18:58 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:58 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:18:58 --> Final output sent to browser
DEBUG - 2020-07-29 16:18:58 --> Total execution time: 0.0204
INFO - 2020-07-29 16:18:58 --> Config Class Initialized
INFO - 2020-07-29 16:18:58 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:58 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:58 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:58 --> URI Class Initialized
INFO - 2020-07-29 16:18:58 --> Router Class Initialized
INFO - 2020-07-29 16:18:58 --> Output Class Initialized
INFO - 2020-07-29 16:18:58 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:58 --> Input Class Initialized
INFO - 2020-07-29 16:18:58 --> Language Class Initialized
INFO - 2020-07-29 16:18:58 --> Loader Class Initialized
INFO - 2020-07-29 16:18:58 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:58 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:58 --> Email Class Initialized
INFO - 2020-07-29 16:18:58 --> Controller Class Initialized
INFO - 2020-07-29 16:18:58 --> Model Class Initialized
INFO - 2020-07-29 16:18:58 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:58 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:59 --> Config Class Initialized
INFO - 2020-07-29 16:18:59 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:59 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:59 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:59 --> URI Class Initialized
DEBUG - 2020-07-29 16:18:59 --> No URI present. Default controller set.
INFO - 2020-07-29 16:18:59 --> Router Class Initialized
INFO - 2020-07-29 16:18:59 --> Output Class Initialized
INFO - 2020-07-29 16:18:59 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:59 --> Input Class Initialized
INFO - 2020-07-29 16:18:59 --> Language Class Initialized
INFO - 2020-07-29 16:18:59 --> Loader Class Initialized
INFO - 2020-07-29 16:18:59 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:59 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:59 --> Email Class Initialized
INFO - 2020-07-29 16:18:59 --> Controller Class Initialized
INFO - 2020-07-29 16:18:59 --> Model Class Initialized
INFO - 2020-07-29 16:18:59 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:59 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:18:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:18:59 --> Final output sent to browser
DEBUG - 2020-07-29 16:18:59 --> Total execution time: 0.0226
INFO - 2020-07-29 16:18:59 --> Config Class Initialized
INFO - 2020-07-29 16:18:59 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:18:59 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:18:59 --> Utf8 Class Initialized
INFO - 2020-07-29 16:18:59 --> URI Class Initialized
INFO - 2020-07-29 16:18:59 --> Router Class Initialized
INFO - 2020-07-29 16:18:59 --> Output Class Initialized
INFO - 2020-07-29 16:18:59 --> Security Class Initialized
DEBUG - 2020-07-29 16:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:18:59 --> Input Class Initialized
INFO - 2020-07-29 16:18:59 --> Language Class Initialized
INFO - 2020-07-29 16:18:59 --> Loader Class Initialized
INFO - 2020-07-29 16:18:59 --> Helper loaded: url_helper
INFO - 2020-07-29 16:18:59 --> Database Driver Class Initialized
INFO - 2020-07-29 16:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:18:59 --> Email Class Initialized
INFO - 2020-07-29 16:18:59 --> Controller Class Initialized
INFO - 2020-07-29 16:18:59 --> Model Class Initialized
INFO - 2020-07-29 16:18:59 --> Model Class Initialized
DEBUG - 2020-07-29 16:18:59 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:19:00 --> Config Class Initialized
INFO - 2020-07-29 16:19:00 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:19:00 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:19:00 --> Utf8 Class Initialized
INFO - 2020-07-29 16:19:00 --> URI Class Initialized
DEBUG - 2020-07-29 16:19:00 --> No URI present. Default controller set.
INFO - 2020-07-29 16:19:00 --> Router Class Initialized
INFO - 2020-07-29 16:19:00 --> Output Class Initialized
INFO - 2020-07-29 16:19:00 --> Security Class Initialized
DEBUG - 2020-07-29 16:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:19:00 --> Input Class Initialized
INFO - 2020-07-29 16:19:00 --> Language Class Initialized
INFO - 2020-07-29 16:19:00 --> Loader Class Initialized
INFO - 2020-07-29 16:19:00 --> Helper loaded: url_helper
INFO - 2020-07-29 16:19:00 --> Database Driver Class Initialized
INFO - 2020-07-29 16:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:19:00 --> Email Class Initialized
INFO - 2020-07-29 16:19:00 --> Controller Class Initialized
INFO - 2020-07-29 16:19:00 --> Model Class Initialized
INFO - 2020-07-29 16:19:00 --> Model Class Initialized
DEBUG - 2020-07-29 16:19:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:19:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:19:00 --> Final output sent to browser
DEBUG - 2020-07-29 16:19:00 --> Total execution time: 0.0256
INFO - 2020-07-29 16:19:00 --> Config Class Initialized
INFO - 2020-07-29 16:19:00 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:19:00 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:19:00 --> Utf8 Class Initialized
INFO - 2020-07-29 16:19:00 --> URI Class Initialized
INFO - 2020-07-29 16:19:00 --> Router Class Initialized
INFO - 2020-07-29 16:19:00 --> Output Class Initialized
INFO - 2020-07-29 16:19:00 --> Security Class Initialized
DEBUG - 2020-07-29 16:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:19:00 --> Input Class Initialized
INFO - 2020-07-29 16:19:00 --> Language Class Initialized
INFO - 2020-07-29 16:19:00 --> Loader Class Initialized
INFO - 2020-07-29 16:19:00 --> Helper loaded: url_helper
INFO - 2020-07-29 16:19:00 --> Database Driver Class Initialized
INFO - 2020-07-29 16:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:19:00 --> Email Class Initialized
INFO - 2020-07-29 16:19:00 --> Controller Class Initialized
INFO - 2020-07-29 16:19:00 --> Model Class Initialized
INFO - 2020-07-29 16:19:00 --> Model Class Initialized
DEBUG - 2020-07-29 16:19:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:19:01 --> Config Class Initialized
INFO - 2020-07-29 16:19:01 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:19:01 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:19:01 --> Utf8 Class Initialized
INFO - 2020-07-29 16:19:01 --> URI Class Initialized
DEBUG - 2020-07-29 16:19:01 --> No URI present. Default controller set.
INFO - 2020-07-29 16:19:01 --> Router Class Initialized
INFO - 2020-07-29 16:19:01 --> Output Class Initialized
INFO - 2020-07-29 16:19:01 --> Security Class Initialized
DEBUG - 2020-07-29 16:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:19:01 --> Input Class Initialized
INFO - 2020-07-29 16:19:01 --> Language Class Initialized
INFO - 2020-07-29 16:19:01 --> Loader Class Initialized
INFO - 2020-07-29 16:19:01 --> Helper loaded: url_helper
INFO - 2020-07-29 16:19:01 --> Database Driver Class Initialized
INFO - 2020-07-29 16:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:19:01 --> Email Class Initialized
INFO - 2020-07-29 16:19:01 --> Controller Class Initialized
INFO - 2020-07-29 16:19:01 --> Model Class Initialized
INFO - 2020-07-29 16:19:01 --> Model Class Initialized
DEBUG - 2020-07-29 16:19:01 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:19:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:19:01 --> Final output sent to browser
DEBUG - 2020-07-29 16:19:01 --> Total execution time: 0.0364
INFO - 2020-07-29 16:19:01 --> Config Class Initialized
INFO - 2020-07-29 16:19:01 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:19:01 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:19:01 --> Utf8 Class Initialized
INFO - 2020-07-29 16:19:01 --> URI Class Initialized
INFO - 2020-07-29 16:19:01 --> Router Class Initialized
INFO - 2020-07-29 16:19:01 --> Output Class Initialized
INFO - 2020-07-29 16:19:01 --> Security Class Initialized
DEBUG - 2020-07-29 16:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:19:01 --> Input Class Initialized
INFO - 2020-07-29 16:19:01 --> Language Class Initialized
INFO - 2020-07-29 16:19:01 --> Loader Class Initialized
INFO - 2020-07-29 16:19:01 --> Helper loaded: url_helper
INFO - 2020-07-29 16:19:01 --> Database Driver Class Initialized
INFO - 2020-07-29 16:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:19:01 --> Email Class Initialized
INFO - 2020-07-29 16:19:01 --> Controller Class Initialized
INFO - 2020-07-29 16:19:01 --> Model Class Initialized
INFO - 2020-07-29 16:19:01 --> Model Class Initialized
DEBUG - 2020-07-29 16:19:01 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:19:02 --> Config Class Initialized
INFO - 2020-07-29 16:19:02 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:19:02 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:19:02 --> Utf8 Class Initialized
INFO - 2020-07-29 16:19:02 --> URI Class Initialized
DEBUG - 2020-07-29 16:19:02 --> No URI present. Default controller set.
INFO - 2020-07-29 16:19:02 --> Router Class Initialized
INFO - 2020-07-29 16:19:02 --> Output Class Initialized
INFO - 2020-07-29 16:19:02 --> Security Class Initialized
DEBUG - 2020-07-29 16:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:19:02 --> Input Class Initialized
INFO - 2020-07-29 16:19:02 --> Language Class Initialized
INFO - 2020-07-29 16:19:02 --> Loader Class Initialized
INFO - 2020-07-29 16:19:02 --> Helper loaded: url_helper
INFO - 2020-07-29 16:19:02 --> Database Driver Class Initialized
INFO - 2020-07-29 16:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:19:02 --> Email Class Initialized
INFO - 2020-07-29 16:19:02 --> Controller Class Initialized
INFO - 2020-07-29 16:19:02 --> Model Class Initialized
INFO - 2020-07-29 16:19:02 --> Model Class Initialized
DEBUG - 2020-07-29 16:19:02 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:19:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:19:02 --> Final output sent to browser
DEBUG - 2020-07-29 16:19:02 --> Total execution time: 0.0229
INFO - 2020-07-29 16:19:02 --> Config Class Initialized
INFO - 2020-07-29 16:19:02 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:19:02 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:19:02 --> Utf8 Class Initialized
INFO - 2020-07-29 16:19:02 --> URI Class Initialized
INFO - 2020-07-29 16:19:02 --> Router Class Initialized
INFO - 2020-07-29 16:19:02 --> Output Class Initialized
INFO - 2020-07-29 16:19:02 --> Security Class Initialized
DEBUG - 2020-07-29 16:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:19:02 --> Input Class Initialized
INFO - 2020-07-29 16:19:02 --> Language Class Initialized
INFO - 2020-07-29 16:19:02 --> Loader Class Initialized
INFO - 2020-07-29 16:19:02 --> Helper loaded: url_helper
INFO - 2020-07-29 16:19:02 --> Database Driver Class Initialized
INFO - 2020-07-29 16:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:19:02 --> Email Class Initialized
INFO - 2020-07-29 16:19:02 --> Controller Class Initialized
INFO - 2020-07-29 16:19:02 --> Model Class Initialized
INFO - 2020-07-29 16:19:02 --> Model Class Initialized
DEBUG - 2020-07-29 16:19:02 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:25:36 --> Config Class Initialized
INFO - 2020-07-29 16:25:36 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:25:36 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:25:36 --> Utf8 Class Initialized
INFO - 2020-07-29 16:25:36 --> URI Class Initialized
DEBUG - 2020-07-29 16:25:36 --> No URI present. Default controller set.
INFO - 2020-07-29 16:25:36 --> Router Class Initialized
INFO - 2020-07-29 16:25:36 --> Output Class Initialized
INFO - 2020-07-29 16:25:36 --> Security Class Initialized
DEBUG - 2020-07-29 16:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:25:36 --> Input Class Initialized
INFO - 2020-07-29 16:25:36 --> Language Class Initialized
INFO - 2020-07-29 16:25:36 --> Loader Class Initialized
INFO - 2020-07-29 16:25:36 --> Helper loaded: url_helper
INFO - 2020-07-29 16:25:36 --> Database Driver Class Initialized
INFO - 2020-07-29 16:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:25:36 --> Email Class Initialized
INFO - 2020-07-29 16:25:36 --> Controller Class Initialized
INFO - 2020-07-29 16:25:36 --> Model Class Initialized
INFO - 2020-07-29 16:25:36 --> Model Class Initialized
DEBUG - 2020-07-29 16:25:36 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:25:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:25:36 --> Final output sent to browser
DEBUG - 2020-07-29 16:25:36 --> Total execution time: 0.0232
INFO - 2020-07-29 16:25:38 --> Config Class Initialized
INFO - 2020-07-29 16:25:38 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:25:38 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:25:38 --> Utf8 Class Initialized
INFO - 2020-07-29 16:25:38 --> URI Class Initialized
INFO - 2020-07-29 16:25:38 --> Router Class Initialized
INFO - 2020-07-29 16:25:38 --> Output Class Initialized
INFO - 2020-07-29 16:25:38 --> Security Class Initialized
DEBUG - 2020-07-29 16:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:25:38 --> Input Class Initialized
INFO - 2020-07-29 16:25:38 --> Language Class Initialized
INFO - 2020-07-29 16:25:38 --> Loader Class Initialized
INFO - 2020-07-29 16:25:38 --> Helper loaded: url_helper
INFO - 2020-07-29 16:25:38 --> Database Driver Class Initialized
INFO - 2020-07-29 16:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:25:38 --> Email Class Initialized
INFO - 2020-07-29 16:25:38 --> Controller Class Initialized
INFO - 2020-07-29 16:25:38 --> Model Class Initialized
INFO - 2020-07-29 16:25:38 --> Model Class Initialized
DEBUG - 2020-07-29 16:25:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 16:25:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:25:38 --> Model Class Initialized
ERROR - 2020-07-29 16:25:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:546) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 16:25:38 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::next_result() /home/purpu1ex/public_html/carsm/application/models/User.php 546
INFO - 2020-07-29 16:25:38 --> Config Class Initialized
INFO - 2020-07-29 16:25:38 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:25:38 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:25:38 --> Utf8 Class Initialized
INFO - 2020-07-29 16:25:38 --> URI Class Initialized
INFO - 2020-07-29 16:25:38 --> Router Class Initialized
INFO - 2020-07-29 16:25:38 --> Output Class Initialized
INFO - 2020-07-29 16:25:38 --> Security Class Initialized
DEBUG - 2020-07-29 16:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:25:38 --> Input Class Initialized
INFO - 2020-07-29 16:25:38 --> Language Class Initialized
INFO - 2020-07-29 16:25:38 --> Loader Class Initialized
INFO - 2020-07-29 16:25:38 --> Helper loaded: url_helper
INFO - 2020-07-29 16:25:38 --> Database Driver Class Initialized
INFO - 2020-07-29 16:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:25:38 --> Email Class Initialized
INFO - 2020-07-29 16:25:38 --> Controller Class Initialized
INFO - 2020-07-29 16:25:38 --> Model Class Initialized
INFO - 2020-07-29 16:25:38 --> Model Class Initialized
DEBUG - 2020-07-29 16:25:38 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:25:39 --> Config Class Initialized
INFO - 2020-07-29 16:25:39 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:25:39 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:25:39 --> Utf8 Class Initialized
INFO - 2020-07-29 16:25:39 --> URI Class Initialized
INFO - 2020-07-29 16:25:39 --> Router Class Initialized
INFO - 2020-07-29 16:25:39 --> Output Class Initialized
INFO - 2020-07-29 16:25:39 --> Security Class Initialized
DEBUG - 2020-07-29 16:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:25:39 --> Input Class Initialized
INFO - 2020-07-29 16:25:39 --> Language Class Initialized
INFO - 2020-07-29 16:25:39 --> Loader Class Initialized
INFO - 2020-07-29 16:25:39 --> Helper loaded: url_helper
INFO - 2020-07-29 16:25:39 --> Database Driver Class Initialized
INFO - 2020-07-29 16:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:25:39 --> Email Class Initialized
INFO - 2020-07-29 16:25:39 --> Controller Class Initialized
DEBUG - 2020-07-29 16:25:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 16:25:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:25:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 16:25:39 --> Final output sent to browser
DEBUG - 2020-07-29 16:25:39 --> Total execution time: 0.0186
INFO - 2020-07-29 16:25:41 --> Config Class Initialized
INFO - 2020-07-29 16:25:41 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:25:41 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:25:41 --> Utf8 Class Initialized
INFO - 2020-07-29 16:25:41 --> URI Class Initialized
DEBUG - 2020-07-29 16:25:41 --> No URI present. Default controller set.
INFO - 2020-07-29 16:25:41 --> Router Class Initialized
INFO - 2020-07-29 16:25:41 --> Output Class Initialized
INFO - 2020-07-29 16:25:41 --> Security Class Initialized
DEBUG - 2020-07-29 16:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:25:41 --> Input Class Initialized
INFO - 2020-07-29 16:25:41 --> Language Class Initialized
INFO - 2020-07-29 16:25:41 --> Loader Class Initialized
INFO - 2020-07-29 16:25:41 --> Helper loaded: url_helper
INFO - 2020-07-29 16:25:41 --> Database Driver Class Initialized
INFO - 2020-07-29 16:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:25:41 --> Email Class Initialized
INFO - 2020-07-29 16:25:41 --> Controller Class Initialized
INFO - 2020-07-29 16:25:41 --> Model Class Initialized
INFO - 2020-07-29 16:25:41 --> Model Class Initialized
DEBUG - 2020-07-29 16:25:41 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:25:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:25:41 --> Final output sent to browser
DEBUG - 2020-07-29 16:25:41 --> Total execution time: 0.0224
INFO - 2020-07-29 16:25:47 --> Config Class Initialized
INFO - 2020-07-29 16:25:47 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:25:47 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:25:47 --> Utf8 Class Initialized
INFO - 2020-07-29 16:25:47 --> URI Class Initialized
INFO - 2020-07-29 16:25:47 --> Router Class Initialized
INFO - 2020-07-29 16:25:47 --> Output Class Initialized
INFO - 2020-07-29 16:25:47 --> Security Class Initialized
DEBUG - 2020-07-29 16:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:25:47 --> Input Class Initialized
INFO - 2020-07-29 16:25:47 --> Language Class Initialized
INFO - 2020-07-29 16:25:47 --> Loader Class Initialized
INFO - 2020-07-29 16:25:47 --> Helper loaded: url_helper
INFO - 2020-07-29 16:25:47 --> Database Driver Class Initialized
INFO - 2020-07-29 16:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:25:47 --> Email Class Initialized
INFO - 2020-07-29 16:25:47 --> Controller Class Initialized
INFO - 2020-07-29 16:25:47 --> Model Class Initialized
INFO - 2020-07-29 16:25:47 --> Model Class Initialized
DEBUG - 2020-07-29 16:25:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 16:25:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:25:47 --> Model Class Initialized
ERROR - 2020-07-29 16:25:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:546) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 16:25:47 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::next_result() /home/purpu1ex/public_html/carsm/application/models/User.php 546
INFO - 2020-07-29 16:25:47 --> Config Class Initialized
INFO - 2020-07-29 16:25:47 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:25:47 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:25:47 --> Utf8 Class Initialized
INFO - 2020-07-29 16:25:47 --> URI Class Initialized
INFO - 2020-07-29 16:25:47 --> Router Class Initialized
INFO - 2020-07-29 16:25:47 --> Output Class Initialized
INFO - 2020-07-29 16:25:47 --> Security Class Initialized
DEBUG - 2020-07-29 16:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:25:47 --> Input Class Initialized
INFO - 2020-07-29 16:25:47 --> Language Class Initialized
INFO - 2020-07-29 16:25:47 --> Loader Class Initialized
INFO - 2020-07-29 16:25:47 --> Helper loaded: url_helper
INFO - 2020-07-29 16:25:47 --> Database Driver Class Initialized
INFO - 2020-07-29 16:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:25:47 --> Email Class Initialized
INFO - 2020-07-29 16:25:47 --> Controller Class Initialized
INFO - 2020-07-29 16:25:47 --> Model Class Initialized
INFO - 2020-07-29 16:25:47 --> Model Class Initialized
DEBUG - 2020-07-29 16:25:47 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:25:47 --> Config Class Initialized
INFO - 2020-07-29 16:25:47 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:25:47 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:25:47 --> Utf8 Class Initialized
INFO - 2020-07-29 16:25:47 --> URI Class Initialized
DEBUG - 2020-07-29 16:25:47 --> No URI present. Default controller set.
INFO - 2020-07-29 16:25:47 --> Router Class Initialized
INFO - 2020-07-29 16:25:47 --> Output Class Initialized
INFO - 2020-07-29 16:25:47 --> Security Class Initialized
DEBUG - 2020-07-29 16:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:25:47 --> Input Class Initialized
INFO - 2020-07-29 16:25:47 --> Language Class Initialized
INFO - 2020-07-29 16:25:47 --> Loader Class Initialized
INFO - 2020-07-29 16:25:47 --> Helper loaded: url_helper
INFO - 2020-07-29 16:25:47 --> Database Driver Class Initialized
INFO - 2020-07-29 16:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:25:47 --> Email Class Initialized
INFO - 2020-07-29 16:25:47 --> Controller Class Initialized
INFO - 2020-07-29 16:25:47 --> Model Class Initialized
INFO - 2020-07-29 16:25:47 --> Model Class Initialized
DEBUG - 2020-07-29 16:25:47 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:25:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:25:47 --> Final output sent to browser
DEBUG - 2020-07-29 16:25:47 --> Total execution time: 0.0249
INFO - 2020-07-29 16:25:56 --> Config Class Initialized
INFO - 2020-07-29 16:25:56 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:25:56 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:25:56 --> Utf8 Class Initialized
INFO - 2020-07-29 16:25:56 --> URI Class Initialized
INFO - 2020-07-29 16:25:56 --> Router Class Initialized
INFO - 2020-07-29 16:25:56 --> Output Class Initialized
INFO - 2020-07-29 16:25:56 --> Security Class Initialized
DEBUG - 2020-07-29 16:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:25:56 --> Input Class Initialized
INFO - 2020-07-29 16:25:56 --> Language Class Initialized
INFO - 2020-07-29 16:25:56 --> Loader Class Initialized
INFO - 2020-07-29 16:25:56 --> Helper loaded: url_helper
INFO - 2020-07-29 16:25:56 --> Config Class Initialized
INFO - 2020-07-29 16:25:56 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:25:56 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:25:56 --> Utf8 Class Initialized
INFO - 2020-07-29 16:25:56 --> URI Class Initialized
INFO - 2020-07-29 16:25:56 --> Router Class Initialized
INFO - 2020-07-29 16:25:56 --> Database Driver Class Initialized
INFO - 2020-07-29 16:25:56 --> Output Class Initialized
INFO - 2020-07-29 16:25:56 --> Security Class Initialized
DEBUG - 2020-07-29 16:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:25:56 --> Input Class Initialized
INFO - 2020-07-29 16:25:56 --> Language Class Initialized
INFO - 2020-07-29 16:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:25:56 --> Loader Class Initialized
INFO - 2020-07-29 16:25:56 --> Helper loaded: url_helper
INFO - 2020-07-29 16:25:56 --> Email Class Initialized
INFO - 2020-07-29 16:25:56 --> Controller Class Initialized
INFO - 2020-07-29 16:25:56 --> Model Class Initialized
INFO - 2020-07-29 16:25:56 --> Model Class Initialized
DEBUG - 2020-07-29 16:25:56 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:25:56 --> Database Driver Class Initialized
INFO - 2020-07-29 16:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:25:56 --> Email Class Initialized
INFO - 2020-07-29 16:25:56 --> Controller Class Initialized
INFO - 2020-07-29 16:25:56 --> Model Class Initialized
INFO - 2020-07-29 16:25:56 --> Model Class Initialized
DEBUG - 2020-07-29 16:25:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 16:25:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:25:56 --> Model Class Initialized
ERROR - 2020-07-29 16:25:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:546) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 16:25:56 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::next_result() /home/purpu1ex/public_html/carsm/application/models/User.php 546
INFO - 2020-07-29 16:25:57 --> Config Class Initialized
INFO - 2020-07-29 16:25:57 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:25:57 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:25:57 --> Utf8 Class Initialized
INFO - 2020-07-29 16:25:57 --> URI Class Initialized
DEBUG - 2020-07-29 16:25:57 --> No URI present. Default controller set.
INFO - 2020-07-29 16:25:57 --> Router Class Initialized
INFO - 2020-07-29 16:25:57 --> Output Class Initialized
INFO - 2020-07-29 16:25:57 --> Security Class Initialized
DEBUG - 2020-07-29 16:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:25:57 --> Input Class Initialized
INFO - 2020-07-29 16:25:57 --> Language Class Initialized
INFO - 2020-07-29 16:25:57 --> Loader Class Initialized
INFO - 2020-07-29 16:25:57 --> Helper loaded: url_helper
INFO - 2020-07-29 16:25:57 --> Database Driver Class Initialized
INFO - 2020-07-29 16:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:25:57 --> Email Class Initialized
INFO - 2020-07-29 16:25:57 --> Controller Class Initialized
INFO - 2020-07-29 16:25:57 --> Model Class Initialized
INFO - 2020-07-29 16:25:57 --> Model Class Initialized
DEBUG - 2020-07-29 16:25:57 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:25:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:25:57 --> Final output sent to browser
DEBUG - 2020-07-29 16:25:57 --> Total execution time: 0.0209
INFO - 2020-07-29 16:28:41 --> Config Class Initialized
INFO - 2020-07-29 16:28:41 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:28:41 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:28:41 --> Utf8 Class Initialized
INFO - 2020-07-29 16:28:41 --> URI Class Initialized
INFO - 2020-07-29 16:28:41 --> Router Class Initialized
INFO - 2020-07-29 16:28:41 --> Output Class Initialized
INFO - 2020-07-29 16:28:41 --> Security Class Initialized
DEBUG - 2020-07-29 16:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:28:41 --> Input Class Initialized
INFO - 2020-07-29 16:28:41 --> Language Class Initialized
INFO - 2020-07-29 16:28:41 --> Loader Class Initialized
INFO - 2020-07-29 16:28:41 --> Helper loaded: url_helper
INFO - 2020-07-29 16:28:41 --> Database Driver Class Initialized
INFO - 2020-07-29 16:28:41 --> Config Class Initialized
INFO - 2020-07-29 16:28:41 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:28:41 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:28:41 --> Utf8 Class Initialized
INFO - 2020-07-29 16:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:28:41 --> URI Class Initialized
INFO - 2020-07-29 16:28:41 --> Router Class Initialized
INFO - 2020-07-29 16:28:41 --> Email Class Initialized
INFO - 2020-07-29 16:28:41 --> Controller Class Initialized
INFO - 2020-07-29 16:28:41 --> Output Class Initialized
INFO - 2020-07-29 16:28:41 --> Model Class Initialized
INFO - 2020-07-29 16:28:41 --> Model Class Initialized
DEBUG - 2020-07-29 16:28:41 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:28:41 --> Security Class Initialized
DEBUG - 2020-07-29 16:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:28:41 --> Input Class Initialized
INFO - 2020-07-29 16:28:41 --> Language Class Initialized
INFO - 2020-07-29 16:28:41 --> Loader Class Initialized
INFO - 2020-07-29 16:28:41 --> Helper loaded: url_helper
INFO - 2020-07-29 16:28:41 --> Database Driver Class Initialized
INFO - 2020-07-29 16:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:28:41 --> Email Class Initialized
INFO - 2020-07-29 16:28:41 --> Controller Class Initialized
INFO - 2020-07-29 16:28:41 --> Model Class Initialized
INFO - 2020-07-29 16:28:41 --> Model Class Initialized
DEBUG - 2020-07-29 16:28:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 16:28:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:28:41 --> Model Class Initialized
ERROR - 2020-07-29 16:28:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:546) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 16:28:41 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::next_result() /home/purpu1ex/public_html/carsm/application/models/User.php 546
INFO - 2020-07-29 16:28:42 --> Config Class Initialized
INFO - 2020-07-29 16:28:42 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:28:42 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:28:42 --> Utf8 Class Initialized
INFO - 2020-07-29 16:28:42 --> URI Class Initialized
DEBUG - 2020-07-29 16:28:42 --> No URI present. Default controller set.
INFO - 2020-07-29 16:28:42 --> Router Class Initialized
INFO - 2020-07-29 16:28:42 --> Output Class Initialized
INFO - 2020-07-29 16:28:42 --> Security Class Initialized
DEBUG - 2020-07-29 16:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:28:42 --> Input Class Initialized
INFO - 2020-07-29 16:28:42 --> Language Class Initialized
INFO - 2020-07-29 16:28:42 --> Loader Class Initialized
INFO - 2020-07-29 16:28:42 --> Helper loaded: url_helper
INFO - 2020-07-29 16:28:42 --> Database Driver Class Initialized
INFO - 2020-07-29 16:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:28:42 --> Email Class Initialized
INFO - 2020-07-29 16:28:42 --> Controller Class Initialized
INFO - 2020-07-29 16:28:42 --> Model Class Initialized
INFO - 2020-07-29 16:28:42 --> Model Class Initialized
DEBUG - 2020-07-29 16:28:42 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:28:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:28:42 --> Final output sent to browser
DEBUG - 2020-07-29 16:28:42 --> Total execution time: 0.0196
INFO - 2020-07-29 16:29:23 --> Config Class Initialized
INFO - 2020-07-29 16:29:23 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:29:23 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:29:23 --> Utf8 Class Initialized
INFO - 2020-07-29 16:29:23 --> URI Class Initialized
INFO - 2020-07-29 16:29:23 --> Router Class Initialized
INFO - 2020-07-29 16:29:23 --> Config Class Initialized
INFO - 2020-07-29 16:29:23 --> Hooks Class Initialized
INFO - 2020-07-29 16:29:23 --> Output Class Initialized
INFO - 2020-07-29 16:29:23 --> Security Class Initialized
DEBUG - 2020-07-29 16:29:23 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:29:23 --> Utf8 Class Initialized
DEBUG - 2020-07-29 16:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:29:23 --> Input Class Initialized
INFO - 2020-07-29 16:29:23 --> Language Class Initialized
INFO - 2020-07-29 16:29:23 --> URI Class Initialized
INFO - 2020-07-29 16:29:23 --> Router Class Initialized
INFO - 2020-07-29 16:29:23 --> Loader Class Initialized
INFO - 2020-07-29 16:29:23 --> Output Class Initialized
INFO - 2020-07-29 16:29:23 --> Helper loaded: url_helper
INFO - 2020-07-29 16:29:23 --> Security Class Initialized
DEBUG - 2020-07-29 16:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:29:23 --> Input Class Initialized
INFO - 2020-07-29 16:29:23 --> Language Class Initialized
INFO - 2020-07-29 16:29:23 --> Loader Class Initialized
INFO - 2020-07-29 16:29:23 --> Helper loaded: url_helper
INFO - 2020-07-29 16:29:23 --> Database Driver Class Initialized
INFO - 2020-07-29 16:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:29:23 --> Database Driver Class Initialized
INFO - 2020-07-29 16:29:23 --> Email Class Initialized
INFO - 2020-07-29 16:29:23 --> Controller Class Initialized
INFO - 2020-07-29 16:29:23 --> Model Class Initialized
INFO - 2020-07-29 16:29:23 --> Model Class Initialized
DEBUG - 2020-07-29 16:29:23 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:29:23 --> Email Class Initialized
INFO - 2020-07-29 16:29:23 --> Controller Class Initialized
INFO - 2020-07-29 16:29:23 --> Model Class Initialized
INFO - 2020-07-29 16:29:23 --> Model Class Initialized
DEBUG - 2020-07-29 16:29:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 16:29:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:29:23 --> Model Class Initialized
ERROR - 2020-07-29 16:29:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:546) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 16:29:23 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::next_result() /home/purpu1ex/public_html/carsm/application/models/User.php 546
INFO - 2020-07-29 16:29:24 --> Config Class Initialized
INFO - 2020-07-29 16:29:24 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:29:24 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:29:24 --> Utf8 Class Initialized
INFO - 2020-07-29 16:29:24 --> URI Class Initialized
DEBUG - 2020-07-29 16:29:24 --> No URI present. Default controller set.
INFO - 2020-07-29 16:29:24 --> Router Class Initialized
INFO - 2020-07-29 16:29:24 --> Output Class Initialized
INFO - 2020-07-29 16:29:24 --> Security Class Initialized
DEBUG - 2020-07-29 16:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:29:24 --> Input Class Initialized
INFO - 2020-07-29 16:29:24 --> Language Class Initialized
INFO - 2020-07-29 16:29:24 --> Loader Class Initialized
INFO - 2020-07-29 16:29:24 --> Helper loaded: url_helper
INFO - 2020-07-29 16:29:24 --> Database Driver Class Initialized
INFO - 2020-07-29 16:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:29:24 --> Email Class Initialized
INFO - 2020-07-29 16:29:24 --> Controller Class Initialized
INFO - 2020-07-29 16:29:24 --> Model Class Initialized
INFO - 2020-07-29 16:29:24 --> Model Class Initialized
DEBUG - 2020-07-29 16:29:24 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:29:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:29:24 --> Final output sent to browser
DEBUG - 2020-07-29 16:29:24 --> Total execution time: 0.0251
INFO - 2020-07-29 16:32:36 --> Config Class Initialized
INFO - 2020-07-29 16:32:36 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:32:36 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:32:36 --> Utf8 Class Initialized
INFO - 2020-07-29 16:32:36 --> URI Class Initialized
DEBUG - 2020-07-29 16:32:36 --> No URI present. Default controller set.
INFO - 2020-07-29 16:32:36 --> Router Class Initialized
INFO - 2020-07-29 16:32:36 --> Output Class Initialized
INFO - 2020-07-29 16:32:36 --> Security Class Initialized
DEBUG - 2020-07-29 16:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:32:36 --> Input Class Initialized
INFO - 2020-07-29 16:32:36 --> Language Class Initialized
INFO - 2020-07-29 16:32:36 --> Loader Class Initialized
INFO - 2020-07-29 16:32:36 --> Helper loaded: url_helper
INFO - 2020-07-29 16:32:36 --> Database Driver Class Initialized
INFO - 2020-07-29 16:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:32:36 --> Email Class Initialized
INFO - 2020-07-29 16:32:36 --> Controller Class Initialized
INFO - 2020-07-29 16:32:36 --> Model Class Initialized
INFO - 2020-07-29 16:32:36 --> Model Class Initialized
DEBUG - 2020-07-29 16:32:36 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:32:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:32:36 --> Final output sent to browser
DEBUG - 2020-07-29 16:32:36 --> Total execution time: 0.0213
INFO - 2020-07-29 16:32:44 --> Config Class Initialized
INFO - 2020-07-29 16:32:44 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:32:44 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:32:44 --> Utf8 Class Initialized
INFO - 2020-07-29 16:32:44 --> URI Class Initialized
INFO - 2020-07-29 16:32:44 --> Router Class Initialized
INFO - 2020-07-29 16:32:44 --> Output Class Initialized
INFO - 2020-07-29 16:32:44 --> Security Class Initialized
DEBUG - 2020-07-29 16:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:32:44 --> Input Class Initialized
INFO - 2020-07-29 16:32:44 --> Language Class Initialized
INFO - 2020-07-29 16:32:44 --> Loader Class Initialized
INFO - 2020-07-29 16:32:44 --> Helper loaded: url_helper
INFO - 2020-07-29 16:32:44 --> Database Driver Class Initialized
INFO - 2020-07-29 16:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:32:44 --> Email Class Initialized
INFO - 2020-07-29 16:32:44 --> Controller Class Initialized
INFO - 2020-07-29 16:32:44 --> Model Class Initialized
INFO - 2020-07-29 16:32:44 --> Model Class Initialized
DEBUG - 2020-07-29 16:32:44 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:32:44 --> Config Class Initialized
INFO - 2020-07-29 16:32:44 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:32:44 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:32:44 --> Utf8 Class Initialized
INFO - 2020-07-29 16:32:44 --> URI Class Initialized
INFO - 2020-07-29 16:32:44 --> Router Class Initialized
INFO - 2020-07-29 16:32:44 --> Output Class Initialized
INFO - 2020-07-29 16:32:44 --> Security Class Initialized
DEBUG - 2020-07-29 16:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:32:44 --> Input Class Initialized
INFO - 2020-07-29 16:32:44 --> Language Class Initialized
INFO - 2020-07-29 16:32:44 --> Loader Class Initialized
INFO - 2020-07-29 16:32:44 --> Helper loaded: url_helper
INFO - 2020-07-29 16:32:44 --> Database Driver Class Initialized
INFO - 2020-07-29 16:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:32:44 --> Email Class Initialized
INFO - 2020-07-29 16:32:44 --> Controller Class Initialized
INFO - 2020-07-29 16:32:44 --> Model Class Initialized
INFO - 2020-07-29 16:32:44 --> Model Class Initialized
DEBUG - 2020-07-29 16:32:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 16:32:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:32:44 --> Model Class Initialized
ERROR - 2020-07-29 16:32:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:546) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 16:32:44 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::next_result() /home/purpu1ex/public_html/carsm/application/models/User.php 546
INFO - 2020-07-29 16:32:45 --> Config Class Initialized
INFO - 2020-07-29 16:32:45 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:32:45 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:32:45 --> Utf8 Class Initialized
INFO - 2020-07-29 16:32:45 --> URI Class Initialized
DEBUG - 2020-07-29 16:32:45 --> No URI present. Default controller set.
INFO - 2020-07-29 16:32:45 --> Router Class Initialized
INFO - 2020-07-29 16:32:45 --> Output Class Initialized
INFO - 2020-07-29 16:32:45 --> Security Class Initialized
DEBUG - 2020-07-29 16:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:32:45 --> Input Class Initialized
INFO - 2020-07-29 16:32:45 --> Language Class Initialized
INFO - 2020-07-29 16:32:45 --> Loader Class Initialized
INFO - 2020-07-29 16:32:45 --> Helper loaded: url_helper
INFO - 2020-07-29 16:32:45 --> Database Driver Class Initialized
INFO - 2020-07-29 16:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:32:45 --> Email Class Initialized
INFO - 2020-07-29 16:32:45 --> Controller Class Initialized
INFO - 2020-07-29 16:32:45 --> Model Class Initialized
INFO - 2020-07-29 16:32:45 --> Model Class Initialized
DEBUG - 2020-07-29 16:32:45 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:32:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:32:45 --> Final output sent to browser
DEBUG - 2020-07-29 16:32:45 --> Total execution time: 0.0239
INFO - 2020-07-29 16:33:20 --> Config Class Initialized
INFO - 2020-07-29 16:33:20 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:33:20 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:33:20 --> Utf8 Class Initialized
INFO - 2020-07-29 16:33:20 --> URI Class Initialized
INFO - 2020-07-29 16:33:20 --> Router Class Initialized
INFO - 2020-07-29 16:33:20 --> Output Class Initialized
INFO - 2020-07-29 16:33:20 --> Security Class Initialized
DEBUG - 2020-07-29 16:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:33:20 --> Input Class Initialized
INFO - 2020-07-29 16:33:20 --> Language Class Initialized
INFO - 2020-07-29 16:33:20 --> Loader Class Initialized
INFO - 2020-07-29 16:33:20 --> Helper loaded: url_helper
INFO - 2020-07-29 16:33:20 --> Database Driver Class Initialized
INFO - 2020-07-29 16:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:33:20 --> Email Class Initialized
INFO - 2020-07-29 16:33:20 --> Controller Class Initialized
INFO - 2020-07-29 16:33:20 --> Model Class Initialized
INFO - 2020-07-29 16:33:20 --> Model Class Initialized
DEBUG - 2020-07-29 16:33:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 16:33:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:33:20 --> Model Class Initialized
ERROR - 2020-07-29 16:33:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:546) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 16:33:20 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::next_result() /home/purpu1ex/public_html/carsm/application/models/User.php 546
INFO - 2020-07-29 16:33:20 --> Config Class Initialized
INFO - 2020-07-29 16:33:20 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:33:20 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:33:20 --> Utf8 Class Initialized
INFO - 2020-07-29 16:33:20 --> URI Class Initialized
INFO - 2020-07-29 16:33:20 --> Router Class Initialized
INFO - 2020-07-29 16:33:20 --> Output Class Initialized
INFO - 2020-07-29 16:33:20 --> Security Class Initialized
DEBUG - 2020-07-29 16:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:33:20 --> Input Class Initialized
INFO - 2020-07-29 16:33:20 --> Language Class Initialized
INFO - 2020-07-29 16:33:20 --> Loader Class Initialized
INFO - 2020-07-29 16:33:20 --> Helper loaded: url_helper
INFO - 2020-07-29 16:33:20 --> Database Driver Class Initialized
INFO - 2020-07-29 16:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:33:20 --> Email Class Initialized
INFO - 2020-07-29 16:33:20 --> Controller Class Initialized
INFO - 2020-07-29 16:33:20 --> Model Class Initialized
INFO - 2020-07-29 16:33:20 --> Model Class Initialized
DEBUG - 2020-07-29 16:33:20 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:33:20 --> Config Class Initialized
INFO - 2020-07-29 16:33:20 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:33:20 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:33:20 --> Utf8 Class Initialized
INFO - 2020-07-29 16:33:20 --> URI Class Initialized
INFO - 2020-07-29 16:33:20 --> Router Class Initialized
INFO - 2020-07-29 16:33:20 --> Output Class Initialized
INFO - 2020-07-29 16:33:20 --> Security Class Initialized
DEBUG - 2020-07-29 16:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:33:20 --> Input Class Initialized
INFO - 2020-07-29 16:33:20 --> Language Class Initialized
INFO - 2020-07-29 16:33:20 --> Loader Class Initialized
INFO - 2020-07-29 16:33:20 --> Helper loaded: url_helper
INFO - 2020-07-29 16:33:20 --> Database Driver Class Initialized
INFO - 2020-07-29 16:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:33:20 --> Email Class Initialized
INFO - 2020-07-29 16:33:20 --> Controller Class Initialized
DEBUG - 2020-07-29 16:33:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 16:33:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:33:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 16:33:20 --> Final output sent to browser
DEBUG - 2020-07-29 16:33:20 --> Total execution time: 0.0219
INFO - 2020-07-29 16:33:26 --> Config Class Initialized
INFO - 2020-07-29 16:33:26 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:33:26 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:33:26 --> Utf8 Class Initialized
INFO - 2020-07-29 16:33:26 --> URI Class Initialized
INFO - 2020-07-29 16:33:26 --> Router Class Initialized
INFO - 2020-07-29 16:33:26 --> Output Class Initialized
INFO - 2020-07-29 16:33:26 --> Security Class Initialized
DEBUG - 2020-07-29 16:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:33:26 --> Input Class Initialized
INFO - 2020-07-29 16:33:26 --> Language Class Initialized
INFO - 2020-07-29 16:33:26 --> Loader Class Initialized
INFO - 2020-07-29 16:33:26 --> Helper loaded: url_helper
INFO - 2020-07-29 16:33:26 --> Database Driver Class Initialized
INFO - 2020-07-29 16:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:33:26 --> Email Class Initialized
INFO - 2020-07-29 16:33:26 --> Controller Class Initialized
DEBUG - 2020-07-29 16:33:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 16:33:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:33:26 --> Model Class Initialized
INFO - 2020-07-29 16:33:26 --> Model Class Initialized
INFO - 2020-07-29 16:33:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 16:33:26 --> Final output sent to browser
DEBUG - 2020-07-29 16:33:26 --> Total execution time: 0.0222
INFO - 2020-07-29 16:33:29 --> Config Class Initialized
INFO - 2020-07-29 16:33:29 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:33:29 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:33:29 --> Utf8 Class Initialized
INFO - 2020-07-29 16:33:29 --> URI Class Initialized
INFO - 2020-07-29 16:33:29 --> Router Class Initialized
INFO - 2020-07-29 16:33:29 --> Output Class Initialized
INFO - 2020-07-29 16:33:29 --> Security Class Initialized
DEBUG - 2020-07-29 16:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:33:29 --> Input Class Initialized
INFO - 2020-07-29 16:33:29 --> Language Class Initialized
INFO - 2020-07-29 16:33:29 --> Loader Class Initialized
INFO - 2020-07-29 16:33:29 --> Helper loaded: url_helper
INFO - 2020-07-29 16:33:29 --> Database Driver Class Initialized
INFO - 2020-07-29 16:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:33:29 --> Email Class Initialized
INFO - 2020-07-29 16:33:29 --> Controller Class Initialized
DEBUG - 2020-07-29 16:33:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 16:33:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:33:29 --> Model Class Initialized
INFO - 2020-07-29 16:33:29 --> Model Class Initialized
INFO - 2020-07-29 16:33:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-29 16:33:29 --> Final output sent to browser
DEBUG - 2020-07-29 16:33:29 --> Total execution time: 0.0203
INFO - 2020-07-29 16:33:33 --> Config Class Initialized
INFO - 2020-07-29 16:33:33 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:33:33 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:33:33 --> Utf8 Class Initialized
INFO - 2020-07-29 16:33:33 --> URI Class Initialized
INFO - 2020-07-29 16:33:33 --> Router Class Initialized
INFO - 2020-07-29 16:33:33 --> Output Class Initialized
INFO - 2020-07-29 16:33:33 --> Security Class Initialized
DEBUG - 2020-07-29 16:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:33:33 --> Input Class Initialized
INFO - 2020-07-29 16:33:33 --> Language Class Initialized
INFO - 2020-07-29 16:33:33 --> Loader Class Initialized
INFO - 2020-07-29 16:33:33 --> Helper loaded: url_helper
INFO - 2020-07-29 16:33:33 --> Database Driver Class Initialized
INFO - 2020-07-29 16:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:33:33 --> Email Class Initialized
INFO - 2020-07-29 16:33:33 --> Controller Class Initialized
DEBUG - 2020-07-29 16:33:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 16:33:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:33:33 --> Model Class Initialized
INFO - 2020-07-29 16:33:33 --> Model Class Initialized
INFO - 2020-07-29 16:33:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 16:33:33 --> Final output sent to browser
DEBUG - 2020-07-29 16:33:33 --> Total execution time: 0.0245
INFO - 2020-07-29 16:33:36 --> Config Class Initialized
INFO - 2020-07-29 16:33:36 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:33:36 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:33:36 --> Utf8 Class Initialized
INFO - 2020-07-29 16:33:36 --> URI Class Initialized
INFO - 2020-07-29 16:33:36 --> Router Class Initialized
INFO - 2020-07-29 16:33:36 --> Output Class Initialized
INFO - 2020-07-29 16:33:36 --> Security Class Initialized
DEBUG - 2020-07-29 16:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:33:36 --> Input Class Initialized
INFO - 2020-07-29 16:33:36 --> Language Class Initialized
INFO - 2020-07-29 16:33:36 --> Loader Class Initialized
INFO - 2020-07-29 16:33:36 --> Helper loaded: url_helper
INFO - 2020-07-29 16:33:36 --> Database Driver Class Initialized
INFO - 2020-07-29 16:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:33:36 --> Email Class Initialized
INFO - 2020-07-29 16:33:36 --> Controller Class Initialized
DEBUG - 2020-07-29 16:33:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 16:33:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:33:36 --> Model Class Initialized
INFO - 2020-07-29 16:33:36 --> Model Class Initialized
INFO - 2020-07-29 16:33:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-07-29 16:33:36 --> Final output sent to browser
DEBUG - 2020-07-29 16:33:36 --> Total execution time: 0.0245
INFO - 2020-07-29 16:33:39 --> Config Class Initialized
INFO - 2020-07-29 16:33:39 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:33:39 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:33:39 --> Utf8 Class Initialized
INFO - 2020-07-29 16:33:39 --> URI Class Initialized
INFO - 2020-07-29 16:33:39 --> Router Class Initialized
INFO - 2020-07-29 16:33:39 --> Output Class Initialized
INFO - 2020-07-29 16:33:39 --> Security Class Initialized
DEBUG - 2020-07-29 16:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:33:39 --> Input Class Initialized
INFO - 2020-07-29 16:33:39 --> Language Class Initialized
INFO - 2020-07-29 16:33:39 --> Loader Class Initialized
INFO - 2020-07-29 16:33:39 --> Helper loaded: url_helper
INFO - 2020-07-29 16:33:39 --> Database Driver Class Initialized
INFO - 2020-07-29 16:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:33:39 --> Email Class Initialized
INFO - 2020-07-29 16:33:39 --> Controller Class Initialized
DEBUG - 2020-07-29 16:33:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 16:33:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:33:39 --> Model Class Initialized
INFO - 2020-07-29 16:33:39 --> Model Class Initialized
INFO - 2020-07-29 16:33:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 16:33:39 --> Final output sent to browser
DEBUG - 2020-07-29 16:33:39 --> Total execution time: 0.0242
INFO - 2020-07-29 16:33:40 --> Config Class Initialized
INFO - 2020-07-29 16:33:40 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:33:40 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:33:40 --> Utf8 Class Initialized
INFO - 2020-07-29 16:33:40 --> URI Class Initialized
INFO - 2020-07-29 16:33:40 --> Router Class Initialized
INFO - 2020-07-29 16:33:40 --> Output Class Initialized
INFO - 2020-07-29 16:33:40 --> Security Class Initialized
DEBUG - 2020-07-29 16:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:33:40 --> Input Class Initialized
INFO - 2020-07-29 16:33:40 --> Language Class Initialized
INFO - 2020-07-29 16:33:40 --> Loader Class Initialized
INFO - 2020-07-29 16:33:40 --> Helper loaded: url_helper
INFO - 2020-07-29 16:33:40 --> Database Driver Class Initialized
INFO - 2020-07-29 16:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:33:40 --> Email Class Initialized
INFO - 2020-07-29 16:33:40 --> Controller Class Initialized
DEBUG - 2020-07-29 16:33:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 16:33:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:33:40 --> Model Class Initialized
INFO - 2020-07-29 16:33:40 --> Model Class Initialized
INFO - 2020-07-29 16:33:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 16:33:40 --> Final output sent to browser
DEBUG - 2020-07-29 16:33:40 --> Total execution time: 0.0219
INFO - 2020-07-29 16:33:43 --> Config Class Initialized
INFO - 2020-07-29 16:33:43 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:33:43 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:33:43 --> Utf8 Class Initialized
INFO - 2020-07-29 16:33:43 --> URI Class Initialized
INFO - 2020-07-29 16:33:43 --> Router Class Initialized
INFO - 2020-07-29 16:33:43 --> Output Class Initialized
INFO - 2020-07-29 16:33:43 --> Security Class Initialized
DEBUG - 2020-07-29 16:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:33:43 --> Input Class Initialized
INFO - 2020-07-29 16:33:43 --> Language Class Initialized
INFO - 2020-07-29 16:33:43 --> Loader Class Initialized
INFO - 2020-07-29 16:33:43 --> Helper loaded: url_helper
INFO - 2020-07-29 16:33:43 --> Database Driver Class Initialized
INFO - 2020-07-29 16:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:33:43 --> Email Class Initialized
INFO - 2020-07-29 16:33:43 --> Controller Class Initialized
DEBUG - 2020-07-29 16:33:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 16:33:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:33:43 --> Model Class Initialized
INFO - 2020-07-29 16:33:43 --> Model Class Initialized
INFO - 2020-07-29 16:33:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 16:33:43 --> Final output sent to browser
DEBUG - 2020-07-29 16:33:43 --> Total execution time: 0.0231
INFO - 2020-07-29 16:33:47 --> Config Class Initialized
INFO - 2020-07-29 16:33:47 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:33:47 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:33:47 --> Utf8 Class Initialized
INFO - 2020-07-29 16:33:47 --> URI Class Initialized
DEBUG - 2020-07-29 16:33:47 --> No URI present. Default controller set.
INFO - 2020-07-29 16:33:47 --> Router Class Initialized
INFO - 2020-07-29 16:33:47 --> Output Class Initialized
INFO - 2020-07-29 16:33:47 --> Security Class Initialized
DEBUG - 2020-07-29 16:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:33:47 --> Input Class Initialized
INFO - 2020-07-29 16:33:47 --> Language Class Initialized
INFO - 2020-07-29 16:33:47 --> Loader Class Initialized
INFO - 2020-07-29 16:33:47 --> Helper loaded: url_helper
INFO - 2020-07-29 16:33:47 --> Database Driver Class Initialized
INFO - 2020-07-29 16:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:33:47 --> Email Class Initialized
INFO - 2020-07-29 16:33:47 --> Controller Class Initialized
INFO - 2020-07-29 16:33:47 --> Model Class Initialized
INFO - 2020-07-29 16:33:47 --> Model Class Initialized
DEBUG - 2020-07-29 16:33:47 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:33:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:33:47 --> Final output sent to browser
DEBUG - 2020-07-29 16:33:47 --> Total execution time: 0.0269
INFO - 2020-07-29 16:35:48 --> Config Class Initialized
INFO - 2020-07-29 16:35:48 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:35:48 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:35:48 --> Utf8 Class Initialized
INFO - 2020-07-29 16:35:48 --> URI Class Initialized
INFO - 2020-07-29 16:35:48 --> Router Class Initialized
INFO - 2020-07-29 16:35:48 --> Output Class Initialized
INFO - 2020-07-29 16:35:48 --> Security Class Initialized
DEBUG - 2020-07-29 16:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:35:48 --> Input Class Initialized
INFO - 2020-07-29 16:35:48 --> Language Class Initialized
INFO - 2020-07-29 16:35:48 --> Loader Class Initialized
INFO - 2020-07-29 16:35:48 --> Helper loaded: url_helper
INFO - 2020-07-29 16:35:48 --> Database Driver Class Initialized
INFO - 2020-07-29 16:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:35:48 --> Email Class Initialized
INFO - 2020-07-29 16:35:48 --> Controller Class Initialized
INFO - 2020-07-29 16:35:48 --> Model Class Initialized
INFO - 2020-07-29 16:35:48 --> Model Class Initialized
DEBUG - 2020-07-29 16:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:35:49 --> Config Class Initialized
INFO - 2020-07-29 16:35:49 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:35:49 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:35:49 --> Utf8 Class Initialized
INFO - 2020-07-29 16:35:49 --> URI Class Initialized
INFO - 2020-07-29 16:35:49 --> Router Class Initialized
INFO - 2020-07-29 16:35:49 --> Output Class Initialized
INFO - 2020-07-29 16:35:49 --> Security Class Initialized
DEBUG - 2020-07-29 16:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:35:49 --> Input Class Initialized
INFO - 2020-07-29 16:35:49 --> Language Class Initialized
INFO - 2020-07-29 16:35:49 --> Loader Class Initialized
INFO - 2020-07-29 16:35:49 --> Helper loaded: url_helper
INFO - 2020-07-29 16:35:49 --> Database Driver Class Initialized
INFO - 2020-07-29 16:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:35:49 --> Email Class Initialized
INFO - 2020-07-29 16:35:49 --> Controller Class Initialized
INFO - 2020-07-29 16:35:49 --> Model Class Initialized
INFO - 2020-07-29 16:35:49 --> Model Class Initialized
DEBUG - 2020-07-29 16:35:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 16:35:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:35:49 --> Model Class Initialized
ERROR - 2020-07-29 16:35:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:546) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 16:35:49 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::next_result() /home/purpu1ex/public_html/carsm/application/models/User.php 546
INFO - 2020-07-29 16:35:49 --> Config Class Initialized
INFO - 2020-07-29 16:35:49 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:35:49 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:35:49 --> Utf8 Class Initialized
INFO - 2020-07-29 16:35:49 --> URI Class Initialized
INFO - 2020-07-29 16:35:49 --> Router Class Initialized
INFO - 2020-07-29 16:35:49 --> Output Class Initialized
INFO - 2020-07-29 16:35:49 --> Security Class Initialized
DEBUG - 2020-07-29 16:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:35:49 --> Input Class Initialized
INFO - 2020-07-29 16:35:49 --> Language Class Initialized
INFO - 2020-07-29 16:35:49 --> Loader Class Initialized
INFO - 2020-07-29 16:35:49 --> Helper loaded: url_helper
INFO - 2020-07-29 16:35:49 --> Database Driver Class Initialized
INFO - 2020-07-29 16:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:35:49 --> Email Class Initialized
INFO - 2020-07-29 16:35:49 --> Controller Class Initialized
DEBUG - 2020-07-29 16:35:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 16:35:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:35:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 16:35:49 --> Final output sent to browser
DEBUG - 2020-07-29 16:35:49 --> Total execution time: 0.0219
INFO - 2020-07-29 16:45:00 --> Config Class Initialized
INFO - 2020-07-29 16:45:00 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:45:00 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:45:00 --> Utf8 Class Initialized
INFO - 2020-07-29 16:45:00 --> URI Class Initialized
DEBUG - 2020-07-29 16:45:00 --> No URI present. Default controller set.
INFO - 2020-07-29 16:45:00 --> Router Class Initialized
INFO - 2020-07-29 16:45:00 --> Output Class Initialized
INFO - 2020-07-29 16:45:00 --> Security Class Initialized
DEBUG - 2020-07-29 16:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:45:00 --> Input Class Initialized
INFO - 2020-07-29 16:45:00 --> Language Class Initialized
INFO - 2020-07-29 16:45:00 --> Loader Class Initialized
INFO - 2020-07-29 16:45:00 --> Helper loaded: url_helper
INFO - 2020-07-29 16:45:00 --> Database Driver Class Initialized
INFO - 2020-07-29 16:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:45:00 --> Email Class Initialized
INFO - 2020-07-29 16:45:00 --> Controller Class Initialized
INFO - 2020-07-29 16:45:00 --> Model Class Initialized
INFO - 2020-07-29 16:45:00 --> Model Class Initialized
DEBUG - 2020-07-29 16:45:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:45:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:45:00 --> Final output sent to browser
DEBUG - 2020-07-29 16:45:00 --> Total execution time: 0.0199
INFO - 2020-07-29 16:45:07 --> Config Class Initialized
INFO - 2020-07-29 16:45:07 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:45:07 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:45:07 --> Utf8 Class Initialized
INFO - 2020-07-29 16:45:07 --> URI Class Initialized
INFO - 2020-07-29 16:45:07 --> Router Class Initialized
INFO - 2020-07-29 16:45:07 --> Output Class Initialized
INFO - 2020-07-29 16:45:07 --> Security Class Initialized
DEBUG - 2020-07-29 16:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:45:07 --> Input Class Initialized
INFO - 2020-07-29 16:45:07 --> Language Class Initialized
INFO - 2020-07-29 16:45:07 --> Loader Class Initialized
INFO - 2020-07-29 16:45:07 --> Helper loaded: url_helper
INFO - 2020-07-29 16:45:07 --> Database Driver Class Initialized
INFO - 2020-07-29 16:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:45:07 --> Email Class Initialized
INFO - 2020-07-29 16:45:07 --> Controller Class Initialized
INFO - 2020-07-29 16:45:07 --> Model Class Initialized
INFO - 2020-07-29 16:45:07 --> Model Class Initialized
DEBUG - 2020-07-29 16:45:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 16:45:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:45:07 --> Model Class Initialized
ERROR - 2020-07-29 16:45:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:546) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 16:45:07 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::next_result() /home/purpu1ex/public_html/carsm/application/models/User.php 546
INFO - 2020-07-29 16:45:07 --> Config Class Initialized
INFO - 2020-07-29 16:45:07 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:45:07 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:45:07 --> Utf8 Class Initialized
INFO - 2020-07-29 16:45:07 --> URI Class Initialized
INFO - 2020-07-29 16:45:07 --> Router Class Initialized
INFO - 2020-07-29 16:45:07 --> Output Class Initialized
INFO - 2020-07-29 16:45:07 --> Security Class Initialized
DEBUG - 2020-07-29 16:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:45:07 --> Input Class Initialized
INFO - 2020-07-29 16:45:07 --> Language Class Initialized
INFO - 2020-07-29 16:45:07 --> Loader Class Initialized
INFO - 2020-07-29 16:45:07 --> Helper loaded: url_helper
INFO - 2020-07-29 16:45:07 --> Database Driver Class Initialized
INFO - 2020-07-29 16:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:45:07 --> Email Class Initialized
INFO - 2020-07-29 16:45:07 --> Controller Class Initialized
INFO - 2020-07-29 16:45:07 --> Model Class Initialized
INFO - 2020-07-29 16:45:07 --> Model Class Initialized
DEBUG - 2020-07-29 16:45:07 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:45:07 --> Config Class Initialized
INFO - 2020-07-29 16:45:07 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:45:07 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:45:07 --> Utf8 Class Initialized
INFO - 2020-07-29 16:45:07 --> URI Class Initialized
DEBUG - 2020-07-29 16:45:07 --> No URI present. Default controller set.
INFO - 2020-07-29 16:45:07 --> Router Class Initialized
INFO - 2020-07-29 16:45:07 --> Output Class Initialized
INFO - 2020-07-29 16:45:07 --> Security Class Initialized
DEBUG - 2020-07-29 16:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:45:07 --> Input Class Initialized
INFO - 2020-07-29 16:45:07 --> Language Class Initialized
INFO - 2020-07-29 16:45:07 --> Loader Class Initialized
INFO - 2020-07-29 16:45:07 --> Helper loaded: url_helper
INFO - 2020-07-29 16:45:07 --> Database Driver Class Initialized
INFO - 2020-07-29 16:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:45:07 --> Email Class Initialized
INFO - 2020-07-29 16:45:07 --> Controller Class Initialized
INFO - 2020-07-29 16:45:07 --> Model Class Initialized
INFO - 2020-07-29 16:45:07 --> Model Class Initialized
DEBUG - 2020-07-29 16:45:07 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:45:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:45:07 --> Final output sent to browser
DEBUG - 2020-07-29 16:45:07 --> Total execution time: 0.0248
INFO - 2020-07-29 16:45:20 --> Config Class Initialized
INFO - 2020-07-29 16:45:20 --> Config Class Initialized
INFO - 2020-07-29 16:45:20 --> Hooks Class Initialized
INFO - 2020-07-29 16:45:20 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:45:20 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:45:20 --> Utf8 Class Initialized
DEBUG - 2020-07-29 16:45:20 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:45:20 --> Utf8 Class Initialized
INFO - 2020-07-29 16:45:20 --> URI Class Initialized
INFO - 2020-07-29 16:45:20 --> URI Class Initialized
INFO - 2020-07-29 16:45:20 --> Router Class Initialized
INFO - 2020-07-29 16:45:20 --> Router Class Initialized
INFO - 2020-07-29 16:45:20 --> Output Class Initialized
INFO - 2020-07-29 16:45:20 --> Output Class Initialized
INFO - 2020-07-29 16:45:20 --> Security Class Initialized
INFO - 2020-07-29 16:45:20 --> Security Class Initialized
DEBUG - 2020-07-29 16:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:45:20 --> Input Class Initialized
DEBUG - 2020-07-29 16:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:45:20 --> Input Class Initialized
INFO - 2020-07-29 16:45:20 --> Language Class Initialized
INFO - 2020-07-29 16:45:20 --> Language Class Initialized
INFO - 2020-07-29 16:45:20 --> Loader Class Initialized
INFO - 2020-07-29 16:45:20 --> Loader Class Initialized
INFO - 2020-07-29 16:45:20 --> Helper loaded: url_helper
INFO - 2020-07-29 16:45:20 --> Helper loaded: url_helper
INFO - 2020-07-29 16:45:20 --> Database Driver Class Initialized
INFO - 2020-07-29 16:45:20 --> Database Driver Class Initialized
INFO - 2020-07-29 16:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:45:20 --> Email Class Initialized
INFO - 2020-07-29 16:45:20 --> Controller Class Initialized
INFO - 2020-07-29 16:45:20 --> Model Class Initialized
INFO - 2020-07-29 16:45:20 --> Model Class Initialized
DEBUG - 2020-07-29 16:45:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 16:45:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:45:20 --> Model Class Initialized
ERROR - 2020-07-29 16:45:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:546) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 16:45:20 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::next_result() /home/purpu1ex/public_html/carsm/application/models/User.php 546
INFO - 2020-07-29 16:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:45:20 --> Email Class Initialized
INFO - 2020-07-29 16:45:20 --> Controller Class Initialized
INFO - 2020-07-29 16:45:20 --> Model Class Initialized
INFO - 2020-07-29 16:45:20 --> Model Class Initialized
DEBUG - 2020-07-29 16:45:20 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:45:21 --> Config Class Initialized
INFO - 2020-07-29 16:45:21 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:45:21 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:45:21 --> Utf8 Class Initialized
INFO - 2020-07-29 16:45:21 --> URI Class Initialized
DEBUG - 2020-07-29 16:45:21 --> No URI present. Default controller set.
INFO - 2020-07-29 16:45:21 --> Router Class Initialized
INFO - 2020-07-29 16:45:21 --> Output Class Initialized
INFO - 2020-07-29 16:45:21 --> Security Class Initialized
DEBUG - 2020-07-29 16:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:45:21 --> Input Class Initialized
INFO - 2020-07-29 16:45:21 --> Language Class Initialized
INFO - 2020-07-29 16:45:21 --> Loader Class Initialized
INFO - 2020-07-29 16:45:21 --> Helper loaded: url_helper
INFO - 2020-07-29 16:45:21 --> Database Driver Class Initialized
INFO - 2020-07-29 16:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:45:21 --> Email Class Initialized
INFO - 2020-07-29 16:45:21 --> Controller Class Initialized
INFO - 2020-07-29 16:45:21 --> Model Class Initialized
INFO - 2020-07-29 16:45:21 --> Model Class Initialized
DEBUG - 2020-07-29 16:45:21 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:45:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:45:21 --> Final output sent to browser
DEBUG - 2020-07-29 16:45:21 --> Total execution time: 0.0236
INFO - 2020-07-29 16:45:53 --> Config Class Initialized
INFO - 2020-07-29 16:45:53 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:45:53 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:45:53 --> Utf8 Class Initialized
INFO - 2020-07-29 16:45:53 --> URI Class Initialized
INFO - 2020-07-29 16:45:53 --> Router Class Initialized
INFO - 2020-07-29 16:45:53 --> Output Class Initialized
INFO - 2020-07-29 16:45:53 --> Security Class Initialized
DEBUG - 2020-07-29 16:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:45:53 --> Input Class Initialized
INFO - 2020-07-29 16:45:53 --> Language Class Initialized
INFO - 2020-07-29 16:45:53 --> Loader Class Initialized
INFO - 2020-07-29 16:45:53 --> Helper loaded: url_helper
INFO - 2020-07-29 16:45:53 --> Database Driver Class Initialized
INFO - 2020-07-29 16:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:45:53 --> Email Class Initialized
INFO - 2020-07-29 16:45:53 --> Controller Class Initialized
INFO - 2020-07-29 16:45:53 --> Model Class Initialized
INFO - 2020-07-29 16:45:53 --> Model Class Initialized
DEBUG - 2020-07-29 16:45:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 16:45:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:45:53 --> Model Class Initialized
INFO - 2020-07-29 16:45:53 --> Config Class Initialized
INFO - 2020-07-29 16:45:53 --> Hooks Class Initialized
ERROR - 2020-07-29 16:45:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:546) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
DEBUG - 2020-07-29 16:45:53 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:45:53 --> Utf8 Class Initialized
ERROR - 2020-07-29 16:45:53 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::next_result() /home/purpu1ex/public_html/carsm/application/models/User.php 546
INFO - 2020-07-29 16:45:53 --> URI Class Initialized
INFO - 2020-07-29 16:45:53 --> Router Class Initialized
INFO - 2020-07-29 16:45:53 --> Output Class Initialized
INFO - 2020-07-29 16:45:53 --> Security Class Initialized
DEBUG - 2020-07-29 16:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:45:53 --> Input Class Initialized
INFO - 2020-07-29 16:45:53 --> Language Class Initialized
INFO - 2020-07-29 16:45:53 --> Loader Class Initialized
INFO - 2020-07-29 16:45:53 --> Helper loaded: url_helper
INFO - 2020-07-29 16:45:53 --> Database Driver Class Initialized
INFO - 2020-07-29 16:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:45:53 --> Email Class Initialized
INFO - 2020-07-29 16:45:53 --> Controller Class Initialized
INFO - 2020-07-29 16:45:53 --> Model Class Initialized
INFO - 2020-07-29 16:45:53 --> Model Class Initialized
DEBUG - 2020-07-29 16:45:53 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:45:53 --> Config Class Initialized
INFO - 2020-07-29 16:45:53 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:45:53 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:45:53 --> Utf8 Class Initialized
INFO - 2020-07-29 16:45:53 --> URI Class Initialized
DEBUG - 2020-07-29 16:45:53 --> No URI present. Default controller set.
INFO - 2020-07-29 16:45:53 --> Router Class Initialized
INFO - 2020-07-29 16:45:53 --> Output Class Initialized
INFO - 2020-07-29 16:45:53 --> Security Class Initialized
DEBUG - 2020-07-29 16:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:45:53 --> Input Class Initialized
INFO - 2020-07-29 16:45:53 --> Language Class Initialized
INFO - 2020-07-29 16:45:53 --> Loader Class Initialized
INFO - 2020-07-29 16:45:53 --> Helper loaded: url_helper
INFO - 2020-07-29 16:45:53 --> Database Driver Class Initialized
INFO - 2020-07-29 16:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:45:53 --> Email Class Initialized
INFO - 2020-07-29 16:45:53 --> Controller Class Initialized
INFO - 2020-07-29 16:45:53 --> Model Class Initialized
INFO - 2020-07-29 16:45:53 --> Model Class Initialized
DEBUG - 2020-07-29 16:45:53 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:45:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:45:53 --> Final output sent to browser
DEBUG - 2020-07-29 16:45:53 --> Total execution time: 0.0229
INFO - 2020-07-29 16:49:26 --> Config Class Initialized
INFO - 2020-07-29 16:49:26 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:49:26 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:49:26 --> Utf8 Class Initialized
INFO - 2020-07-29 16:49:26 --> URI Class Initialized
DEBUG - 2020-07-29 16:49:26 --> No URI present. Default controller set.
INFO - 2020-07-29 16:49:26 --> Router Class Initialized
INFO - 2020-07-29 16:49:26 --> Output Class Initialized
INFO - 2020-07-29 16:49:26 --> Security Class Initialized
DEBUG - 2020-07-29 16:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:49:26 --> Input Class Initialized
INFO - 2020-07-29 16:49:26 --> Language Class Initialized
INFO - 2020-07-29 16:49:26 --> Loader Class Initialized
INFO - 2020-07-29 16:49:26 --> Helper loaded: url_helper
INFO - 2020-07-29 16:49:26 --> Database Driver Class Initialized
INFO - 2020-07-29 16:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:49:26 --> Email Class Initialized
INFO - 2020-07-29 16:49:26 --> Controller Class Initialized
INFO - 2020-07-29 16:49:26 --> Model Class Initialized
INFO - 2020-07-29 16:49:26 --> Model Class Initialized
DEBUG - 2020-07-29 16:49:26 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:49:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:49:26 --> Final output sent to browser
DEBUG - 2020-07-29 16:49:26 --> Total execution time: 0.0234
INFO - 2020-07-29 16:49:34 --> Config Class Initialized
INFO - 2020-07-29 16:49:34 --> Config Class Initialized
INFO - 2020-07-29 16:49:34 --> Hooks Class Initialized
INFO - 2020-07-29 16:49:34 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:49:34 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:49:34 --> Utf8 Class Initialized
DEBUG - 2020-07-29 16:49:34 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:49:34 --> Utf8 Class Initialized
INFO - 2020-07-29 16:49:34 --> URI Class Initialized
INFO - 2020-07-29 16:49:34 --> URI Class Initialized
INFO - 2020-07-29 16:49:34 --> Router Class Initialized
INFO - 2020-07-29 16:49:34 --> Router Class Initialized
INFO - 2020-07-29 16:49:34 --> Output Class Initialized
INFO - 2020-07-29 16:49:34 --> Output Class Initialized
INFO - 2020-07-29 16:49:34 --> Security Class Initialized
INFO - 2020-07-29 16:49:34 --> Security Class Initialized
DEBUG - 2020-07-29 16:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:49:34 --> Input Class Initialized
DEBUG - 2020-07-29 16:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:49:34 --> Input Class Initialized
INFO - 2020-07-29 16:49:34 --> Language Class Initialized
INFO - 2020-07-29 16:49:34 --> Language Class Initialized
INFO - 2020-07-29 16:49:34 --> Loader Class Initialized
INFO - 2020-07-29 16:49:34 --> Loader Class Initialized
INFO - 2020-07-29 16:49:34 --> Helper loaded: url_helper
INFO - 2020-07-29 16:49:34 --> Helper loaded: url_helper
INFO - 2020-07-29 16:49:34 --> Database Driver Class Initialized
INFO - 2020-07-29 16:49:34 --> Database Driver Class Initialized
INFO - 2020-07-29 16:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:49:34 --> Email Class Initialized
INFO - 2020-07-29 16:49:34 --> Controller Class Initialized
INFO - 2020-07-29 16:49:34 --> Model Class Initialized
INFO - 2020-07-29 16:49:34 --> Model Class Initialized
DEBUG - 2020-07-29 16:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 16:49:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:49:34 --> Model Class Initialized
ERROR - 2020-07-29 16:49:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:546) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 16:49:34 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::next_result() /home/purpu1ex/public_html/carsm/application/models/User.php 546
INFO - 2020-07-29 16:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:49:34 --> Email Class Initialized
INFO - 2020-07-29 16:49:34 --> Controller Class Initialized
INFO - 2020-07-29 16:49:34 --> Model Class Initialized
INFO - 2020-07-29 16:49:34 --> Model Class Initialized
DEBUG - 2020-07-29 16:49:34 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:49:35 --> Config Class Initialized
INFO - 2020-07-29 16:49:35 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:49:35 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:49:35 --> Utf8 Class Initialized
INFO - 2020-07-29 16:49:35 --> URI Class Initialized
DEBUG - 2020-07-29 16:49:35 --> No URI present. Default controller set.
INFO - 2020-07-29 16:49:35 --> Router Class Initialized
INFO - 2020-07-29 16:49:35 --> Output Class Initialized
INFO - 2020-07-29 16:49:35 --> Security Class Initialized
DEBUG - 2020-07-29 16:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:49:35 --> Input Class Initialized
INFO - 2020-07-29 16:49:35 --> Language Class Initialized
INFO - 2020-07-29 16:49:35 --> Loader Class Initialized
INFO - 2020-07-29 16:49:35 --> Helper loaded: url_helper
INFO - 2020-07-29 16:49:35 --> Database Driver Class Initialized
INFO - 2020-07-29 16:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:49:35 --> Email Class Initialized
INFO - 2020-07-29 16:49:35 --> Controller Class Initialized
INFO - 2020-07-29 16:49:35 --> Model Class Initialized
INFO - 2020-07-29 16:49:35 --> Model Class Initialized
DEBUG - 2020-07-29 16:49:35 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:49:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:49:35 --> Final output sent to browser
DEBUG - 2020-07-29 16:49:35 --> Total execution time: 0.0213
INFO - 2020-07-29 16:49:45 --> Config Class Initialized
INFO - 2020-07-29 16:49:45 --> Hooks Class Initialized
INFO - 2020-07-29 16:49:45 --> Config Class Initialized
INFO - 2020-07-29 16:49:45 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:49:45 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:49:45 --> Utf8 Class Initialized
DEBUG - 2020-07-29 16:49:45 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:49:45 --> Utf8 Class Initialized
INFO - 2020-07-29 16:49:45 --> URI Class Initialized
INFO - 2020-07-29 16:49:45 --> URI Class Initialized
INFO - 2020-07-29 16:49:45 --> Router Class Initialized
INFO - 2020-07-29 16:49:45 --> Router Class Initialized
INFO - 2020-07-29 16:49:45 --> Output Class Initialized
INFO - 2020-07-29 16:49:45 --> Output Class Initialized
INFO - 2020-07-29 16:49:45 --> Security Class Initialized
INFO - 2020-07-29 16:49:45 --> Security Class Initialized
DEBUG - 2020-07-29 16:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:49:45 --> Input Class Initialized
DEBUG - 2020-07-29 16:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:49:45 --> Input Class Initialized
INFO - 2020-07-29 16:49:45 --> Language Class Initialized
INFO - 2020-07-29 16:49:45 --> Language Class Initialized
INFO - 2020-07-29 16:49:45 --> Loader Class Initialized
INFO - 2020-07-29 16:49:45 --> Loader Class Initialized
INFO - 2020-07-29 16:49:45 --> Helper loaded: url_helper
INFO - 2020-07-29 16:49:45 --> Helper loaded: url_helper
INFO - 2020-07-29 16:49:45 --> Database Driver Class Initialized
INFO - 2020-07-29 16:49:45 --> Database Driver Class Initialized
INFO - 2020-07-29 16:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:49:45 --> Email Class Initialized
INFO - 2020-07-29 16:49:45 --> Controller Class Initialized
INFO - 2020-07-29 16:49:45 --> Model Class Initialized
INFO - 2020-07-29 16:49:45 --> Model Class Initialized
DEBUG - 2020-07-29 16:49:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 16:49:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:49:45 --> Model Class Initialized
ERROR - 2020-07-29 16:49:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:546) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 16:49:45 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::next_result() /home/purpu1ex/public_html/carsm/application/models/User.php 546
INFO - 2020-07-29 16:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:49:45 --> Email Class Initialized
INFO - 2020-07-29 16:49:45 --> Controller Class Initialized
INFO - 2020-07-29 16:49:45 --> Model Class Initialized
INFO - 2020-07-29 16:49:45 --> Model Class Initialized
DEBUG - 2020-07-29 16:49:45 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:49:46 --> Config Class Initialized
INFO - 2020-07-29 16:49:46 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:49:46 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:49:46 --> Utf8 Class Initialized
INFO - 2020-07-29 16:49:46 --> URI Class Initialized
DEBUG - 2020-07-29 16:49:46 --> No URI present. Default controller set.
INFO - 2020-07-29 16:49:46 --> Router Class Initialized
INFO - 2020-07-29 16:49:46 --> Output Class Initialized
INFO - 2020-07-29 16:49:46 --> Security Class Initialized
DEBUG - 2020-07-29 16:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:49:46 --> Input Class Initialized
INFO - 2020-07-29 16:49:46 --> Language Class Initialized
INFO - 2020-07-29 16:49:46 --> Loader Class Initialized
INFO - 2020-07-29 16:49:46 --> Helper loaded: url_helper
INFO - 2020-07-29 16:49:46 --> Database Driver Class Initialized
INFO - 2020-07-29 16:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:49:46 --> Email Class Initialized
INFO - 2020-07-29 16:49:46 --> Controller Class Initialized
INFO - 2020-07-29 16:49:46 --> Model Class Initialized
INFO - 2020-07-29 16:49:46 --> Model Class Initialized
DEBUG - 2020-07-29 16:49:46 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:49:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:49:46 --> Final output sent to browser
DEBUG - 2020-07-29 16:49:46 --> Total execution time: 0.0208
INFO - 2020-07-29 16:49:50 --> Config Class Initialized
INFO - 2020-07-29 16:49:50 --> Config Class Initialized
INFO - 2020-07-29 16:49:50 --> Hooks Class Initialized
INFO - 2020-07-29 16:49:50 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:49:50 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:49:50 --> Utf8 Class Initialized
DEBUG - 2020-07-29 16:49:50 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:49:50 --> Utf8 Class Initialized
INFO - 2020-07-29 16:49:50 --> URI Class Initialized
INFO - 2020-07-29 16:49:50 --> URI Class Initialized
INFO - 2020-07-29 16:49:50 --> Router Class Initialized
INFO - 2020-07-29 16:49:50 --> Router Class Initialized
INFO - 2020-07-29 16:49:50 --> Output Class Initialized
INFO - 2020-07-29 16:49:50 --> Output Class Initialized
INFO - 2020-07-29 16:49:50 --> Security Class Initialized
INFO - 2020-07-29 16:49:50 --> Security Class Initialized
DEBUG - 2020-07-29 16:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:49:50 --> Input Class Initialized
DEBUG - 2020-07-29 16:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:49:50 --> Input Class Initialized
INFO - 2020-07-29 16:49:50 --> Language Class Initialized
INFO - 2020-07-29 16:49:50 --> Language Class Initialized
INFO - 2020-07-29 16:49:50 --> Loader Class Initialized
INFO - 2020-07-29 16:49:50 --> Loader Class Initialized
INFO - 2020-07-29 16:49:50 --> Helper loaded: url_helper
INFO - 2020-07-29 16:49:50 --> Helper loaded: url_helper
INFO - 2020-07-29 16:49:50 --> Database Driver Class Initialized
INFO - 2020-07-29 16:49:50 --> Database Driver Class Initialized
INFO - 2020-07-29 16:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:49:50 --> Email Class Initialized
INFO - 2020-07-29 16:49:50 --> Controller Class Initialized
INFO - 2020-07-29 16:49:50 --> Model Class Initialized
INFO - 2020-07-29 16:49:50 --> Model Class Initialized
DEBUG - 2020-07-29 16:49:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 16:49:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:49:50 --> Model Class Initialized
ERROR - 2020-07-29 16:49:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:546) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 16:49:50 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::next_result() /home/purpu1ex/public_html/carsm/application/models/User.php 546
INFO - 2020-07-29 16:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:49:50 --> Email Class Initialized
INFO - 2020-07-29 16:49:50 --> Controller Class Initialized
INFO - 2020-07-29 16:49:50 --> Model Class Initialized
INFO - 2020-07-29 16:49:50 --> Model Class Initialized
DEBUG - 2020-07-29 16:49:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:49:51 --> Config Class Initialized
INFO - 2020-07-29 16:49:51 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:49:51 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:49:51 --> Utf8 Class Initialized
INFO - 2020-07-29 16:49:51 --> URI Class Initialized
INFO - 2020-07-29 16:49:51 --> Router Class Initialized
INFO - 2020-07-29 16:49:51 --> Output Class Initialized
INFO - 2020-07-29 16:49:51 --> Security Class Initialized
DEBUG - 2020-07-29 16:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:49:51 --> Input Class Initialized
INFO - 2020-07-29 16:49:51 --> Language Class Initialized
INFO - 2020-07-29 16:49:51 --> Loader Class Initialized
INFO - 2020-07-29 16:49:51 --> Helper loaded: url_helper
INFO - 2020-07-29 16:49:51 --> Database Driver Class Initialized
INFO - 2020-07-29 16:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:49:51 --> Email Class Initialized
INFO - 2020-07-29 16:49:51 --> Controller Class Initialized
DEBUG - 2020-07-29 16:49:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 16:49:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:49:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 16:49:51 --> Final output sent to browser
DEBUG - 2020-07-29 16:49:51 --> Total execution time: 0.0178
INFO - 2020-07-29 16:50:13 --> Config Class Initialized
INFO - 2020-07-29 16:50:13 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:50:13 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:50:13 --> Utf8 Class Initialized
INFO - 2020-07-29 16:50:13 --> URI Class Initialized
DEBUG - 2020-07-29 16:50:13 --> No URI present. Default controller set.
INFO - 2020-07-29 16:50:13 --> Router Class Initialized
INFO - 2020-07-29 16:50:13 --> Output Class Initialized
INFO - 2020-07-29 16:50:13 --> Security Class Initialized
DEBUG - 2020-07-29 16:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:50:13 --> Input Class Initialized
INFO - 2020-07-29 16:50:13 --> Language Class Initialized
INFO - 2020-07-29 16:50:13 --> Loader Class Initialized
INFO - 2020-07-29 16:50:13 --> Helper loaded: url_helper
INFO - 2020-07-29 16:50:13 --> Database Driver Class Initialized
INFO - 2020-07-29 16:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:50:13 --> Email Class Initialized
INFO - 2020-07-29 16:50:13 --> Controller Class Initialized
INFO - 2020-07-29 16:50:13 --> Model Class Initialized
INFO - 2020-07-29 16:50:13 --> Model Class Initialized
DEBUG - 2020-07-29 16:50:13 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:50:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:50:13 --> Final output sent to browser
DEBUG - 2020-07-29 16:50:13 --> Total execution time: 0.0260
INFO - 2020-07-29 16:50:27 --> Config Class Initialized
INFO - 2020-07-29 16:50:27 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:50:27 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:50:27 --> Utf8 Class Initialized
INFO - 2020-07-29 16:50:27 --> URI Class Initialized
INFO - 2020-07-29 16:50:27 --> Router Class Initialized
INFO - 2020-07-29 16:50:27 --> Output Class Initialized
INFO - 2020-07-29 16:50:27 --> Config Class Initialized
INFO - 2020-07-29 16:50:27 --> Hooks Class Initialized
INFO - 2020-07-29 16:50:27 --> Security Class Initialized
DEBUG - 2020-07-29 16:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:50:27 --> Input Class Initialized
INFO - 2020-07-29 16:50:27 --> Language Class Initialized
DEBUG - 2020-07-29 16:50:27 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:50:27 --> Utf8 Class Initialized
INFO - 2020-07-29 16:50:27 --> URI Class Initialized
INFO - 2020-07-29 16:50:27 --> Router Class Initialized
INFO - 2020-07-29 16:50:27 --> Loader Class Initialized
INFO - 2020-07-29 16:50:27 --> Helper loaded: url_helper
INFO - 2020-07-29 16:50:27 --> Output Class Initialized
INFO - 2020-07-29 16:50:27 --> Security Class Initialized
DEBUG - 2020-07-29 16:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:50:27 --> Input Class Initialized
INFO - 2020-07-29 16:50:27 --> Language Class Initialized
INFO - 2020-07-29 16:50:27 --> Database Driver Class Initialized
INFO - 2020-07-29 16:50:27 --> Loader Class Initialized
INFO - 2020-07-29 16:50:27 --> Helper loaded: url_helper
INFO - 2020-07-29 16:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:50:27 --> Email Class Initialized
INFO - 2020-07-29 16:50:27 --> Controller Class Initialized
INFO - 2020-07-29 16:50:27 --> Model Class Initialized
INFO - 2020-07-29 16:50:27 --> Model Class Initialized
DEBUG - 2020-07-29 16:50:27 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:50:27 --> Database Driver Class Initialized
INFO - 2020-07-29 16:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:50:27 --> Email Class Initialized
INFO - 2020-07-29 16:50:27 --> Controller Class Initialized
INFO - 2020-07-29 16:50:27 --> Model Class Initialized
INFO - 2020-07-29 16:50:27 --> Model Class Initialized
DEBUG - 2020-07-29 16:50:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 16:50:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:50:27 --> Model Class Initialized
ERROR - 2020-07-29 16:50:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:546) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 16:50:27 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::next_result() /home/purpu1ex/public_html/carsm/application/models/User.php 546
INFO - 2020-07-29 16:50:27 --> Config Class Initialized
INFO - 2020-07-29 16:50:27 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:50:27 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:50:27 --> Utf8 Class Initialized
INFO - 2020-07-29 16:50:27 --> URI Class Initialized
DEBUG - 2020-07-29 16:50:27 --> No URI present. Default controller set.
INFO - 2020-07-29 16:50:27 --> Router Class Initialized
INFO - 2020-07-29 16:50:27 --> Output Class Initialized
INFO - 2020-07-29 16:50:27 --> Security Class Initialized
DEBUG - 2020-07-29 16:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:50:28 --> Input Class Initialized
INFO - 2020-07-29 16:50:28 --> Language Class Initialized
INFO - 2020-07-29 16:50:28 --> Loader Class Initialized
INFO - 2020-07-29 16:50:28 --> Helper loaded: url_helper
INFO - 2020-07-29 16:50:28 --> Database Driver Class Initialized
INFO - 2020-07-29 16:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:50:28 --> Email Class Initialized
INFO - 2020-07-29 16:50:28 --> Controller Class Initialized
INFO - 2020-07-29 16:50:28 --> Model Class Initialized
INFO - 2020-07-29 16:50:28 --> Model Class Initialized
DEBUG - 2020-07-29 16:50:28 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:50:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:50:28 --> Final output sent to browser
DEBUG - 2020-07-29 16:50:28 --> Total execution time: 0.0221
INFO - 2020-07-29 16:51:29 --> Config Class Initialized
INFO - 2020-07-29 16:51:29 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:51:29 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:51:29 --> Utf8 Class Initialized
INFO - 2020-07-29 16:51:29 --> URI Class Initialized
DEBUG - 2020-07-29 16:51:29 --> No URI present. Default controller set.
INFO - 2020-07-29 16:51:29 --> Router Class Initialized
INFO - 2020-07-29 16:51:29 --> Output Class Initialized
INFO - 2020-07-29 16:51:29 --> Security Class Initialized
DEBUG - 2020-07-29 16:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:51:29 --> Input Class Initialized
INFO - 2020-07-29 16:51:29 --> Language Class Initialized
INFO - 2020-07-29 16:51:29 --> Loader Class Initialized
INFO - 2020-07-29 16:51:29 --> Helper loaded: url_helper
INFO - 2020-07-29 16:51:29 --> Database Driver Class Initialized
INFO - 2020-07-29 16:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:51:29 --> Email Class Initialized
INFO - 2020-07-29 16:51:29 --> Controller Class Initialized
INFO - 2020-07-29 16:51:29 --> Model Class Initialized
INFO - 2020-07-29 16:51:29 --> Model Class Initialized
DEBUG - 2020-07-29 16:51:29 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:51:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:51:29 --> Final output sent to browser
DEBUG - 2020-07-29 16:51:29 --> Total execution time: 0.0214
INFO - 2020-07-29 16:51:37 --> Config Class Initialized
INFO - 2020-07-29 16:51:37 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:51:37 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:51:37 --> Utf8 Class Initialized
INFO - 2020-07-29 16:51:37 --> URI Class Initialized
INFO - 2020-07-29 16:51:37 --> Router Class Initialized
INFO - 2020-07-29 16:51:37 --> Output Class Initialized
INFO - 2020-07-29 16:51:37 --> Security Class Initialized
DEBUG - 2020-07-29 16:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:51:37 --> Input Class Initialized
INFO - 2020-07-29 16:51:37 --> Language Class Initialized
INFO - 2020-07-29 16:51:37 --> Loader Class Initialized
INFO - 2020-07-29 16:51:37 --> Helper loaded: url_helper
INFO - 2020-07-29 16:51:37 --> Database Driver Class Initialized
INFO - 2020-07-29 16:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:51:37 --> Email Class Initialized
INFO - 2020-07-29 16:51:37 --> Controller Class Initialized
INFO - 2020-07-29 16:51:37 --> Model Class Initialized
INFO - 2020-07-29 16:51:37 --> Model Class Initialized
DEBUG - 2020-07-29 16:51:37 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:51:37 --> Config Class Initialized
INFO - 2020-07-29 16:51:37 --> Hooks Class Initialized
DEBUG - 2020-07-29 16:51:37 --> UTF-8 Support Enabled
INFO - 2020-07-29 16:51:37 --> Utf8 Class Initialized
INFO - 2020-07-29 16:51:37 --> URI Class Initialized
DEBUG - 2020-07-29 16:51:37 --> No URI present. Default controller set.
INFO - 2020-07-29 16:51:37 --> Router Class Initialized
INFO - 2020-07-29 16:51:37 --> Output Class Initialized
INFO - 2020-07-29 16:51:37 --> Security Class Initialized
DEBUG - 2020-07-29 16:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 16:51:37 --> Input Class Initialized
INFO - 2020-07-29 16:51:37 --> Language Class Initialized
INFO - 2020-07-29 16:51:37 --> Loader Class Initialized
INFO - 2020-07-29 16:51:37 --> Helper loaded: url_helper
INFO - 2020-07-29 16:51:37 --> Database Driver Class Initialized
INFO - 2020-07-29 16:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 16:51:37 --> Email Class Initialized
INFO - 2020-07-29 16:51:37 --> Controller Class Initialized
INFO - 2020-07-29 16:51:37 --> Model Class Initialized
INFO - 2020-07-29 16:51:37 --> Model Class Initialized
DEBUG - 2020-07-29 16:51:37 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 16:51:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 16:51:37 --> Final output sent to browser
DEBUG - 2020-07-29 16:51:37 --> Total execution time: 0.0225
INFO - 2020-07-29 17:02:56 --> Config Class Initialized
INFO - 2020-07-29 17:02:56 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:02:56 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:02:56 --> Utf8 Class Initialized
INFO - 2020-07-29 17:02:56 --> URI Class Initialized
INFO - 2020-07-29 17:02:56 --> Router Class Initialized
INFO - 2020-07-29 17:02:56 --> Output Class Initialized
INFO - 2020-07-29 17:02:56 --> Security Class Initialized
DEBUG - 2020-07-29 17:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:02:56 --> Input Class Initialized
INFO - 2020-07-29 17:02:56 --> Language Class Initialized
INFO - 2020-07-29 17:02:56 --> Loader Class Initialized
INFO - 2020-07-29 17:02:56 --> Helper loaded: url_helper
INFO - 2020-07-29 17:02:56 --> Database Driver Class Initialized
INFO - 2020-07-29 17:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:02:56 --> Email Class Initialized
INFO - 2020-07-29 17:02:56 --> Controller Class Initialized
INFO - 2020-07-29 17:02:56 --> Model Class Initialized
INFO - 2020-07-29 17:02:56 --> Model Class Initialized
DEBUG - 2020-07-29 17:02:56 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:02:57 --> Config Class Initialized
INFO - 2020-07-29 17:02:57 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:02:57 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:02:57 --> Utf8 Class Initialized
INFO - 2020-07-29 17:02:57 --> URI Class Initialized
DEBUG - 2020-07-29 17:02:57 --> No URI present. Default controller set.
INFO - 2020-07-29 17:02:57 --> Router Class Initialized
INFO - 2020-07-29 17:02:57 --> Output Class Initialized
INFO - 2020-07-29 17:02:57 --> Security Class Initialized
DEBUG - 2020-07-29 17:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:02:57 --> Input Class Initialized
INFO - 2020-07-29 17:02:57 --> Language Class Initialized
INFO - 2020-07-29 17:02:57 --> Loader Class Initialized
INFO - 2020-07-29 17:02:57 --> Helper loaded: url_helper
INFO - 2020-07-29 17:02:57 --> Database Driver Class Initialized
INFO - 2020-07-29 17:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:02:57 --> Email Class Initialized
INFO - 2020-07-29 17:02:57 --> Controller Class Initialized
INFO - 2020-07-29 17:02:57 --> Model Class Initialized
INFO - 2020-07-29 17:02:57 --> Model Class Initialized
DEBUG - 2020-07-29 17:02:57 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:02:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:02:57 --> Final output sent to browser
DEBUG - 2020-07-29 17:02:57 --> Total execution time: 0.0219
INFO - 2020-07-29 17:03:13 --> Config Class Initialized
INFO - 2020-07-29 17:03:13 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:03:13 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:03:13 --> Utf8 Class Initialized
INFO - 2020-07-29 17:03:13 --> URI Class Initialized
INFO - 2020-07-29 17:03:13 --> Router Class Initialized
INFO - 2020-07-29 17:03:13 --> Output Class Initialized
INFO - 2020-07-29 17:03:13 --> Security Class Initialized
DEBUG - 2020-07-29 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:03:13 --> Input Class Initialized
INFO - 2020-07-29 17:03:13 --> Language Class Initialized
INFO - 2020-07-29 17:03:13 --> Loader Class Initialized
INFO - 2020-07-29 17:03:13 --> Helper loaded: url_helper
INFO - 2020-07-29 17:03:13 --> Database Driver Class Initialized
INFO - 2020-07-29 17:03:13 --> Config Class Initialized
INFO - 2020-07-29 17:03:13 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:03:13 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:03:13 --> Utf8 Class Initialized
INFO - 2020-07-29 17:03:13 --> URI Class Initialized
INFO - 2020-07-29 17:03:13 --> Router Class Initialized
INFO - 2020-07-29 17:03:13 --> Output Class Initialized
INFO - 2020-07-29 17:03:13 --> Security Class Initialized
DEBUG - 2020-07-29 17:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:03:13 --> Input Class Initialized
INFO - 2020-07-29 17:03:13 --> Language Class Initialized
INFO - 2020-07-29 17:03:13 --> Loader Class Initialized
INFO - 2020-07-29 17:03:13 --> Helper loaded: url_helper
INFO - 2020-07-29 17:03:13 --> Database Driver Class Initialized
INFO - 2020-07-29 17:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:03:13 --> Email Class Initialized
INFO - 2020-07-29 17:03:13 --> Controller Class Initialized
INFO - 2020-07-29 17:03:13 --> Model Class Initialized
INFO - 2020-07-29 17:03:13 --> Model Class Initialized
DEBUG - 2020-07-29 17:03:13 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:03:13 --> Email Class Initialized
INFO - 2020-07-29 17:03:13 --> Controller Class Initialized
INFO - 2020-07-29 17:03:13 --> Model Class Initialized
INFO - 2020-07-29 17:03:13 --> Model Class Initialized
DEBUG - 2020-07-29 17:03:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:03:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:03:13 --> Model Class Initialized
ERROR - 2020-07-29 17:03:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:546) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 17:03:13 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::next_result() /home/purpu1ex/public_html/carsm/application/models/User.php 546
INFO - 2020-07-29 17:03:14 --> Config Class Initialized
INFO - 2020-07-29 17:03:14 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:03:14 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:03:14 --> Utf8 Class Initialized
INFO - 2020-07-29 17:03:14 --> URI Class Initialized
DEBUG - 2020-07-29 17:03:14 --> No URI present. Default controller set.
INFO - 2020-07-29 17:03:14 --> Router Class Initialized
INFO - 2020-07-29 17:03:14 --> Output Class Initialized
INFO - 2020-07-29 17:03:14 --> Security Class Initialized
DEBUG - 2020-07-29 17:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:03:14 --> Input Class Initialized
INFO - 2020-07-29 17:03:14 --> Language Class Initialized
INFO - 2020-07-29 17:03:14 --> Loader Class Initialized
INFO - 2020-07-29 17:03:14 --> Helper loaded: url_helper
INFO - 2020-07-29 17:03:14 --> Database Driver Class Initialized
INFO - 2020-07-29 17:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:03:14 --> Email Class Initialized
INFO - 2020-07-29 17:03:14 --> Controller Class Initialized
INFO - 2020-07-29 17:03:14 --> Model Class Initialized
INFO - 2020-07-29 17:03:14 --> Model Class Initialized
DEBUG - 2020-07-29 17:03:14 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:03:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:03:14 --> Final output sent to browser
DEBUG - 2020-07-29 17:03:14 --> Total execution time: 0.0228
INFO - 2020-07-29 17:03:23 --> Config Class Initialized
INFO - 2020-07-29 17:03:23 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:03:23 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:03:23 --> Utf8 Class Initialized
INFO - 2020-07-29 17:03:23 --> URI Class Initialized
DEBUG - 2020-07-29 17:03:23 --> No URI present. Default controller set.
INFO - 2020-07-29 17:03:23 --> Router Class Initialized
INFO - 2020-07-29 17:03:23 --> Output Class Initialized
INFO - 2020-07-29 17:03:23 --> Security Class Initialized
DEBUG - 2020-07-29 17:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:03:23 --> Input Class Initialized
INFO - 2020-07-29 17:03:23 --> Language Class Initialized
INFO - 2020-07-29 17:03:23 --> Loader Class Initialized
INFO - 2020-07-29 17:03:23 --> Helper loaded: url_helper
INFO - 2020-07-29 17:03:23 --> Database Driver Class Initialized
INFO - 2020-07-29 17:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:03:23 --> Email Class Initialized
INFO - 2020-07-29 17:03:23 --> Controller Class Initialized
INFO - 2020-07-29 17:03:23 --> Model Class Initialized
INFO - 2020-07-29 17:03:23 --> Model Class Initialized
DEBUG - 2020-07-29 17:03:23 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:03:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:03:23 --> Final output sent to browser
DEBUG - 2020-07-29 17:03:23 --> Total execution time: 0.0205
INFO - 2020-07-29 17:03:26 --> Config Class Initialized
INFO - 2020-07-29 17:03:26 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:03:26 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:03:26 --> Utf8 Class Initialized
INFO - 2020-07-29 17:03:26 --> URI Class Initialized
DEBUG - 2020-07-29 17:03:26 --> No URI present. Default controller set.
INFO - 2020-07-29 17:03:26 --> Router Class Initialized
INFO - 2020-07-29 17:03:26 --> Output Class Initialized
INFO - 2020-07-29 17:03:26 --> Security Class Initialized
DEBUG - 2020-07-29 17:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:03:26 --> Input Class Initialized
INFO - 2020-07-29 17:03:26 --> Language Class Initialized
INFO - 2020-07-29 17:03:26 --> Loader Class Initialized
INFO - 2020-07-29 17:03:26 --> Helper loaded: url_helper
INFO - 2020-07-29 17:03:26 --> Database Driver Class Initialized
INFO - 2020-07-29 17:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:03:26 --> Email Class Initialized
INFO - 2020-07-29 17:03:26 --> Controller Class Initialized
INFO - 2020-07-29 17:03:26 --> Model Class Initialized
INFO - 2020-07-29 17:03:26 --> Model Class Initialized
DEBUG - 2020-07-29 17:03:26 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:03:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:03:26 --> Final output sent to browser
DEBUG - 2020-07-29 17:03:26 --> Total execution time: 0.0223
INFO - 2020-07-29 17:03:29 --> Config Class Initialized
INFO - 2020-07-29 17:03:29 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:03:29 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:03:29 --> Utf8 Class Initialized
INFO - 2020-07-29 17:03:29 --> URI Class Initialized
DEBUG - 2020-07-29 17:03:29 --> No URI present. Default controller set.
INFO - 2020-07-29 17:03:29 --> Router Class Initialized
INFO - 2020-07-29 17:03:29 --> Output Class Initialized
INFO - 2020-07-29 17:03:29 --> Security Class Initialized
DEBUG - 2020-07-29 17:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:03:29 --> Input Class Initialized
INFO - 2020-07-29 17:03:29 --> Language Class Initialized
INFO - 2020-07-29 17:03:29 --> Loader Class Initialized
INFO - 2020-07-29 17:03:29 --> Helper loaded: url_helper
INFO - 2020-07-29 17:03:29 --> Database Driver Class Initialized
INFO - 2020-07-29 17:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:03:29 --> Email Class Initialized
INFO - 2020-07-29 17:03:29 --> Controller Class Initialized
INFO - 2020-07-29 17:03:29 --> Model Class Initialized
INFO - 2020-07-29 17:03:29 --> Model Class Initialized
DEBUG - 2020-07-29 17:03:29 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:03:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:03:29 --> Final output sent to browser
DEBUG - 2020-07-29 17:03:29 --> Total execution time: 0.0194
INFO - 2020-07-29 17:03:38 --> Config Class Initialized
INFO - 2020-07-29 17:03:38 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:03:38 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:03:38 --> Utf8 Class Initialized
INFO - 2020-07-29 17:03:38 --> URI Class Initialized
DEBUG - 2020-07-29 17:03:38 --> No URI present. Default controller set.
INFO - 2020-07-29 17:03:38 --> Router Class Initialized
INFO - 2020-07-29 17:03:38 --> Output Class Initialized
INFO - 2020-07-29 17:03:38 --> Security Class Initialized
DEBUG - 2020-07-29 17:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:03:38 --> Input Class Initialized
INFO - 2020-07-29 17:03:38 --> Language Class Initialized
INFO - 2020-07-29 17:03:38 --> Loader Class Initialized
INFO - 2020-07-29 17:03:38 --> Helper loaded: url_helper
INFO - 2020-07-29 17:03:38 --> Database Driver Class Initialized
INFO - 2020-07-29 17:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:03:38 --> Email Class Initialized
INFO - 2020-07-29 17:03:38 --> Controller Class Initialized
INFO - 2020-07-29 17:03:38 --> Model Class Initialized
INFO - 2020-07-29 17:03:38 --> Model Class Initialized
DEBUG - 2020-07-29 17:03:38 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:03:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:03:38 --> Final output sent to browser
DEBUG - 2020-07-29 17:03:38 --> Total execution time: 0.0196
INFO - 2020-07-29 17:03:55 --> Config Class Initialized
INFO - 2020-07-29 17:03:55 --> Hooks Class Initialized
INFO - 2020-07-29 17:03:55 --> Config Class Initialized
INFO - 2020-07-29 17:03:55 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:03:55 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:03:55 --> Utf8 Class Initialized
DEBUG - 2020-07-29 17:03:55 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:03:55 --> Utf8 Class Initialized
INFO - 2020-07-29 17:03:55 --> URI Class Initialized
INFO - 2020-07-29 17:03:55 --> URI Class Initialized
INFO - 2020-07-29 17:03:55 --> Router Class Initialized
INFO - 2020-07-29 17:03:55 --> Router Class Initialized
INFO - 2020-07-29 17:03:55 --> Output Class Initialized
INFO - 2020-07-29 17:03:55 --> Security Class Initialized
INFO - 2020-07-29 17:03:55 --> Output Class Initialized
DEBUG - 2020-07-29 17:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:03:55 --> Input Class Initialized
INFO - 2020-07-29 17:03:55 --> Security Class Initialized
INFO - 2020-07-29 17:03:55 --> Language Class Initialized
DEBUG - 2020-07-29 17:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:03:55 --> Input Class Initialized
INFO - 2020-07-29 17:03:55 --> Language Class Initialized
INFO - 2020-07-29 17:03:55 --> Loader Class Initialized
INFO - 2020-07-29 17:03:55 --> Helper loaded: url_helper
INFO - 2020-07-29 17:03:55 --> Loader Class Initialized
INFO - 2020-07-29 17:03:55 --> Helper loaded: url_helper
INFO - 2020-07-29 17:03:55 --> Database Driver Class Initialized
INFO - 2020-07-29 17:03:55 --> Database Driver Class Initialized
INFO - 2020-07-29 17:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:03:55 --> Email Class Initialized
INFO - 2020-07-29 17:03:55 --> Controller Class Initialized
INFO - 2020-07-29 17:03:55 --> Model Class Initialized
INFO - 2020-07-29 17:03:55 --> Model Class Initialized
DEBUG - 2020-07-29 17:03:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:03:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:03:55 --> Model Class Initialized
ERROR - 2020-07-29 17:03:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:546) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 17:03:55 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::next_result() /home/purpu1ex/public_html/carsm/application/models/User.php 546
INFO - 2020-07-29 17:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:03:55 --> Email Class Initialized
INFO - 2020-07-29 17:03:55 --> Controller Class Initialized
INFO - 2020-07-29 17:03:55 --> Model Class Initialized
INFO - 2020-07-29 17:03:55 --> Model Class Initialized
DEBUG - 2020-07-29 17:03:55 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:03:56 --> Config Class Initialized
INFO - 2020-07-29 17:03:56 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:03:56 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:03:56 --> Utf8 Class Initialized
INFO - 2020-07-29 17:03:56 --> URI Class Initialized
DEBUG - 2020-07-29 17:03:56 --> No URI present. Default controller set.
INFO - 2020-07-29 17:03:56 --> Router Class Initialized
INFO - 2020-07-29 17:03:56 --> Output Class Initialized
INFO - 2020-07-29 17:03:56 --> Security Class Initialized
DEBUG - 2020-07-29 17:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:03:56 --> Input Class Initialized
INFO - 2020-07-29 17:03:56 --> Language Class Initialized
INFO - 2020-07-29 17:03:56 --> Loader Class Initialized
INFO - 2020-07-29 17:03:56 --> Helper loaded: url_helper
INFO - 2020-07-29 17:03:56 --> Database Driver Class Initialized
INFO - 2020-07-29 17:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:03:56 --> Email Class Initialized
INFO - 2020-07-29 17:03:56 --> Controller Class Initialized
INFO - 2020-07-29 17:03:56 --> Model Class Initialized
INFO - 2020-07-29 17:03:56 --> Model Class Initialized
DEBUG - 2020-07-29 17:03:56 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:03:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:03:56 --> Final output sent to browser
DEBUG - 2020-07-29 17:03:56 --> Total execution time: 0.0222
INFO - 2020-07-29 17:06:31 --> Config Class Initialized
INFO - 2020-07-29 17:06:31 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:06:31 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:06:31 --> Utf8 Class Initialized
INFO - 2020-07-29 17:06:31 --> URI Class Initialized
INFO - 2020-07-29 17:06:31 --> Router Class Initialized
INFO - 2020-07-29 17:06:31 --> Output Class Initialized
INFO - 2020-07-29 17:06:31 --> Security Class Initialized
DEBUG - 2020-07-29 17:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:06:31 --> Input Class Initialized
INFO - 2020-07-29 17:06:31 --> Language Class Initialized
INFO - 2020-07-29 17:06:31 --> Loader Class Initialized
INFO - 2020-07-29 17:06:31 --> Helper loaded: url_helper
INFO - 2020-07-29 17:06:31 --> Database Driver Class Initialized
INFO - 2020-07-29 17:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:06:31 --> Email Class Initialized
INFO - 2020-07-29 17:06:31 --> Controller Class Initialized
INFO - 2020-07-29 17:06:31 --> Model Class Initialized
INFO - 2020-07-29 17:06:31 --> Model Class Initialized
DEBUG - 2020-07-29 17:06:31 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:06:31 --> Config Class Initialized
INFO - 2020-07-29 17:06:31 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:06:31 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:06:31 --> Utf8 Class Initialized
INFO - 2020-07-29 17:06:31 --> URI Class Initialized
INFO - 2020-07-29 17:06:31 --> Router Class Initialized
INFO - 2020-07-29 17:06:31 --> Output Class Initialized
INFO - 2020-07-29 17:06:31 --> Security Class Initialized
DEBUG - 2020-07-29 17:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:06:31 --> Input Class Initialized
INFO - 2020-07-29 17:06:31 --> Language Class Initialized
INFO - 2020-07-29 17:06:31 --> Loader Class Initialized
INFO - 2020-07-29 17:06:31 --> Helper loaded: url_helper
INFO - 2020-07-29 17:06:31 --> Database Driver Class Initialized
INFO - 2020-07-29 17:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:06:31 --> Email Class Initialized
INFO - 2020-07-29 17:06:31 --> Controller Class Initialized
INFO - 2020-07-29 17:06:31 --> Model Class Initialized
INFO - 2020-07-29 17:06:31 --> Model Class Initialized
DEBUG - 2020-07-29 17:06:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:06:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:06:31 --> Model Class Initialized
ERROR - 2020-07-29 17:06:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:546) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 17:06:31 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::next_result() /home/purpu1ex/public_html/carsm/application/models/User.php 546
INFO - 2020-07-29 17:06:32 --> Config Class Initialized
INFO - 2020-07-29 17:06:32 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:06:32 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:06:32 --> Utf8 Class Initialized
INFO - 2020-07-29 17:06:32 --> URI Class Initialized
DEBUG - 2020-07-29 17:06:32 --> No URI present. Default controller set.
INFO - 2020-07-29 17:06:32 --> Router Class Initialized
INFO - 2020-07-29 17:06:32 --> Output Class Initialized
INFO - 2020-07-29 17:06:32 --> Security Class Initialized
DEBUG - 2020-07-29 17:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:06:32 --> Input Class Initialized
INFO - 2020-07-29 17:06:32 --> Language Class Initialized
INFO - 2020-07-29 17:06:32 --> Loader Class Initialized
INFO - 2020-07-29 17:06:32 --> Helper loaded: url_helper
INFO - 2020-07-29 17:06:32 --> Database Driver Class Initialized
INFO - 2020-07-29 17:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:06:32 --> Email Class Initialized
INFO - 2020-07-29 17:06:32 --> Controller Class Initialized
INFO - 2020-07-29 17:06:32 --> Model Class Initialized
INFO - 2020-07-29 17:06:32 --> Model Class Initialized
DEBUG - 2020-07-29 17:06:32 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:06:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:06:32 --> Final output sent to browser
DEBUG - 2020-07-29 17:06:32 --> Total execution time: 0.0216
INFO - 2020-07-29 17:06:39 --> Config Class Initialized
INFO - 2020-07-29 17:06:39 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:06:39 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:06:39 --> Utf8 Class Initialized
INFO - 2020-07-29 17:06:39 --> URI Class Initialized
INFO - 2020-07-29 17:06:39 --> Router Class Initialized
INFO - 2020-07-29 17:06:39 --> Output Class Initialized
INFO - 2020-07-29 17:06:39 --> Security Class Initialized
DEBUG - 2020-07-29 17:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:06:39 --> Input Class Initialized
INFO - 2020-07-29 17:06:39 --> Language Class Initialized
INFO - 2020-07-29 17:06:39 --> Loader Class Initialized
INFO - 2020-07-29 17:06:39 --> Helper loaded: url_helper
INFO - 2020-07-29 17:06:39 --> Database Driver Class Initialized
INFO - 2020-07-29 17:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:06:39 --> Email Class Initialized
INFO - 2020-07-29 17:06:39 --> Controller Class Initialized
INFO - 2020-07-29 17:06:39 --> Model Class Initialized
INFO - 2020-07-29 17:06:39 --> Model Class Initialized
DEBUG - 2020-07-29 17:06:39 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:06:39 --> Config Class Initialized
INFO - 2020-07-29 17:06:39 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:06:39 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:06:39 --> Utf8 Class Initialized
INFO - 2020-07-29 17:06:39 --> URI Class Initialized
INFO - 2020-07-29 17:06:39 --> Router Class Initialized
INFO - 2020-07-29 17:06:39 --> Output Class Initialized
INFO - 2020-07-29 17:06:39 --> Security Class Initialized
DEBUG - 2020-07-29 17:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:06:39 --> Input Class Initialized
INFO - 2020-07-29 17:06:39 --> Language Class Initialized
INFO - 2020-07-29 17:06:39 --> Loader Class Initialized
INFO - 2020-07-29 17:06:39 --> Helper loaded: url_helper
INFO - 2020-07-29 17:06:39 --> Database Driver Class Initialized
INFO - 2020-07-29 17:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:06:39 --> Email Class Initialized
INFO - 2020-07-29 17:06:39 --> Controller Class Initialized
INFO - 2020-07-29 17:06:39 --> Model Class Initialized
INFO - 2020-07-29 17:06:39 --> Model Class Initialized
DEBUG - 2020-07-29 17:06:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:06:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:06:39 --> Model Class Initialized
ERROR - 2020-07-29 17:06:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:546) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 17:06:39 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::next_result() /home/purpu1ex/public_html/carsm/application/models/User.php 546
INFO - 2020-07-29 17:06:40 --> Config Class Initialized
INFO - 2020-07-29 17:06:40 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:06:40 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:06:40 --> Utf8 Class Initialized
INFO - 2020-07-29 17:06:40 --> URI Class Initialized
DEBUG - 2020-07-29 17:06:40 --> No URI present. Default controller set.
INFO - 2020-07-29 17:06:40 --> Router Class Initialized
INFO - 2020-07-29 17:06:40 --> Output Class Initialized
INFO - 2020-07-29 17:06:40 --> Security Class Initialized
DEBUG - 2020-07-29 17:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:06:40 --> Input Class Initialized
INFO - 2020-07-29 17:06:40 --> Language Class Initialized
INFO - 2020-07-29 17:06:40 --> Loader Class Initialized
INFO - 2020-07-29 17:06:40 --> Helper loaded: url_helper
INFO - 2020-07-29 17:06:40 --> Database Driver Class Initialized
INFO - 2020-07-29 17:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:06:40 --> Email Class Initialized
INFO - 2020-07-29 17:06:40 --> Controller Class Initialized
INFO - 2020-07-29 17:06:40 --> Model Class Initialized
INFO - 2020-07-29 17:06:40 --> Model Class Initialized
DEBUG - 2020-07-29 17:06:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:06:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:06:40 --> Final output sent to browser
DEBUG - 2020-07-29 17:06:40 --> Total execution time: 0.0223
INFO - 2020-07-29 17:18:13 --> Config Class Initialized
INFO - 2020-07-29 17:18:13 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:18:13 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:18:13 --> Utf8 Class Initialized
INFO - 2020-07-29 17:18:13 --> URI Class Initialized
INFO - 2020-07-29 17:18:13 --> Router Class Initialized
INFO - 2020-07-29 17:18:13 --> Output Class Initialized
INFO - 2020-07-29 17:18:13 --> Security Class Initialized
DEBUG - 2020-07-29 17:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:18:13 --> Input Class Initialized
INFO - 2020-07-29 17:18:13 --> Language Class Initialized
INFO - 2020-07-29 17:18:13 --> Loader Class Initialized
INFO - 2020-07-29 17:18:13 --> Helper loaded: url_helper
INFO - 2020-07-29 17:18:13 --> Database Driver Class Initialized
INFO - 2020-07-29 17:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:18:13 --> Email Class Initialized
INFO - 2020-07-29 17:18:13 --> Controller Class Initialized
INFO - 2020-07-29 17:18:13 --> Model Class Initialized
INFO - 2020-07-29 17:18:13 --> Model Class Initialized
DEBUG - 2020-07-29 17:18:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:18:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:18:14 --> Config Class Initialized
INFO - 2020-07-29 17:18:14 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:18:14 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:18:14 --> Utf8 Class Initialized
INFO - 2020-07-29 17:18:14 --> URI Class Initialized
DEBUG - 2020-07-29 17:18:14 --> No URI present. Default controller set.
INFO - 2020-07-29 17:18:14 --> Router Class Initialized
INFO - 2020-07-29 17:18:14 --> Output Class Initialized
INFO - 2020-07-29 17:18:14 --> Security Class Initialized
DEBUG - 2020-07-29 17:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:18:14 --> Input Class Initialized
INFO - 2020-07-29 17:18:14 --> Language Class Initialized
INFO - 2020-07-29 17:18:14 --> Loader Class Initialized
INFO - 2020-07-29 17:18:14 --> Helper loaded: url_helper
INFO - 2020-07-29 17:18:14 --> Database Driver Class Initialized
INFO - 2020-07-29 17:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:18:14 --> Email Class Initialized
INFO - 2020-07-29 17:18:14 --> Controller Class Initialized
INFO - 2020-07-29 17:18:14 --> Model Class Initialized
INFO - 2020-07-29 17:18:14 --> Model Class Initialized
DEBUG - 2020-07-29 17:18:14 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:18:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:18:14 --> Final output sent to browser
DEBUG - 2020-07-29 17:18:14 --> Total execution time: 0.0236
INFO - 2020-07-29 17:18:17 --> Config Class Initialized
INFO - 2020-07-29 17:18:17 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:18:17 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:18:17 --> Utf8 Class Initialized
INFO - 2020-07-29 17:18:17 --> URI Class Initialized
INFO - 2020-07-29 17:18:17 --> Router Class Initialized
INFO - 2020-07-29 17:18:17 --> Output Class Initialized
INFO - 2020-07-29 17:18:17 --> Security Class Initialized
DEBUG - 2020-07-29 17:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:18:17 --> Input Class Initialized
INFO - 2020-07-29 17:18:17 --> Language Class Initialized
INFO - 2020-07-29 17:18:17 --> Loader Class Initialized
INFO - 2020-07-29 17:18:17 --> Helper loaded: url_helper
INFO - 2020-07-29 17:18:17 --> Database Driver Class Initialized
INFO - 2020-07-29 17:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:18:17 --> Email Class Initialized
INFO - 2020-07-29 17:18:17 --> Controller Class Initialized
INFO - 2020-07-29 17:18:17 --> Model Class Initialized
INFO - 2020-07-29 17:18:17 --> Model Class Initialized
DEBUG - 2020-07-29 17:18:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:18:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:18:17 --> Config Class Initialized
INFO - 2020-07-29 17:18:17 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:18:17 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:18:17 --> Utf8 Class Initialized
INFO - 2020-07-29 17:18:17 --> URI Class Initialized
DEBUG - 2020-07-29 17:18:17 --> No URI present. Default controller set.
INFO - 2020-07-29 17:18:17 --> Router Class Initialized
INFO - 2020-07-29 17:18:17 --> Output Class Initialized
INFO - 2020-07-29 17:18:17 --> Security Class Initialized
DEBUG - 2020-07-29 17:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:18:17 --> Input Class Initialized
INFO - 2020-07-29 17:18:17 --> Language Class Initialized
INFO - 2020-07-29 17:18:17 --> Loader Class Initialized
INFO - 2020-07-29 17:18:17 --> Helper loaded: url_helper
INFO - 2020-07-29 17:18:17 --> Database Driver Class Initialized
INFO - 2020-07-29 17:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:18:17 --> Email Class Initialized
INFO - 2020-07-29 17:18:17 --> Controller Class Initialized
INFO - 2020-07-29 17:18:17 --> Model Class Initialized
INFO - 2020-07-29 17:18:17 --> Model Class Initialized
DEBUG - 2020-07-29 17:18:17 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:18:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:18:17 --> Final output sent to browser
DEBUG - 2020-07-29 17:18:17 --> Total execution time: 0.0240
INFO - 2020-07-29 17:18:23 --> Config Class Initialized
INFO - 2020-07-29 17:18:23 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:18:23 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:18:23 --> Utf8 Class Initialized
INFO - 2020-07-29 17:18:23 --> URI Class Initialized
DEBUG - 2020-07-29 17:18:23 --> No URI present. Default controller set.
INFO - 2020-07-29 17:18:23 --> Router Class Initialized
INFO - 2020-07-29 17:18:23 --> Output Class Initialized
INFO - 2020-07-29 17:18:23 --> Security Class Initialized
DEBUG - 2020-07-29 17:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:18:23 --> Input Class Initialized
INFO - 2020-07-29 17:18:23 --> Language Class Initialized
INFO - 2020-07-29 17:18:23 --> Loader Class Initialized
INFO - 2020-07-29 17:18:23 --> Helper loaded: url_helper
INFO - 2020-07-29 17:18:23 --> Database Driver Class Initialized
INFO - 2020-07-29 17:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:18:23 --> Email Class Initialized
INFO - 2020-07-29 17:18:23 --> Controller Class Initialized
INFO - 2020-07-29 17:18:23 --> Model Class Initialized
INFO - 2020-07-29 17:18:23 --> Model Class Initialized
DEBUG - 2020-07-29 17:18:23 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:18:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:18:23 --> Final output sent to browser
DEBUG - 2020-07-29 17:18:23 --> Total execution time: 0.0229
INFO - 2020-07-29 17:18:24 --> Config Class Initialized
INFO - 2020-07-29 17:18:24 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:18:24 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:18:24 --> Utf8 Class Initialized
INFO - 2020-07-29 17:18:24 --> URI Class Initialized
DEBUG - 2020-07-29 17:18:24 --> No URI present. Default controller set.
INFO - 2020-07-29 17:18:24 --> Router Class Initialized
INFO - 2020-07-29 17:18:24 --> Output Class Initialized
INFO - 2020-07-29 17:18:24 --> Security Class Initialized
DEBUG - 2020-07-29 17:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:18:24 --> Input Class Initialized
INFO - 2020-07-29 17:18:24 --> Language Class Initialized
INFO - 2020-07-29 17:18:24 --> Loader Class Initialized
INFO - 2020-07-29 17:18:24 --> Helper loaded: url_helper
INFO - 2020-07-29 17:18:24 --> Database Driver Class Initialized
INFO - 2020-07-29 17:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:18:24 --> Email Class Initialized
INFO - 2020-07-29 17:18:24 --> Controller Class Initialized
INFO - 2020-07-29 17:18:24 --> Model Class Initialized
INFO - 2020-07-29 17:18:24 --> Model Class Initialized
DEBUG - 2020-07-29 17:18:24 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:18:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:18:24 --> Final output sent to browser
DEBUG - 2020-07-29 17:18:24 --> Total execution time: 0.0269
INFO - 2020-07-29 17:18:27 --> Config Class Initialized
INFO - 2020-07-29 17:18:27 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:18:27 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:18:27 --> Utf8 Class Initialized
INFO - 2020-07-29 17:18:27 --> URI Class Initialized
INFO - 2020-07-29 17:18:27 --> Router Class Initialized
INFO - 2020-07-29 17:18:27 --> Output Class Initialized
INFO - 2020-07-29 17:18:27 --> Security Class Initialized
DEBUG - 2020-07-29 17:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:18:27 --> Input Class Initialized
INFO - 2020-07-29 17:18:27 --> Language Class Initialized
INFO - 2020-07-29 17:18:27 --> Loader Class Initialized
INFO - 2020-07-29 17:18:27 --> Helper loaded: url_helper
INFO - 2020-07-29 17:18:27 --> Database Driver Class Initialized
INFO - 2020-07-29 17:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:18:27 --> Email Class Initialized
INFO - 2020-07-29 17:18:27 --> Controller Class Initialized
INFO - 2020-07-29 17:18:27 --> Model Class Initialized
INFO - 2020-07-29 17:18:27 --> Model Class Initialized
DEBUG - 2020-07-29 17:18:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:18:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:18:27 --> Config Class Initialized
INFO - 2020-07-29 17:18:27 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:18:27 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:18:27 --> Utf8 Class Initialized
INFO - 2020-07-29 17:18:27 --> URI Class Initialized
DEBUG - 2020-07-29 17:18:27 --> No URI present. Default controller set.
INFO - 2020-07-29 17:18:27 --> Router Class Initialized
INFO - 2020-07-29 17:18:27 --> Output Class Initialized
INFO - 2020-07-29 17:18:27 --> Security Class Initialized
DEBUG - 2020-07-29 17:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:18:27 --> Input Class Initialized
INFO - 2020-07-29 17:18:27 --> Language Class Initialized
INFO - 2020-07-29 17:18:27 --> Loader Class Initialized
INFO - 2020-07-29 17:18:27 --> Helper loaded: url_helper
INFO - 2020-07-29 17:18:27 --> Database Driver Class Initialized
INFO - 2020-07-29 17:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:18:27 --> Email Class Initialized
INFO - 2020-07-29 17:18:27 --> Controller Class Initialized
INFO - 2020-07-29 17:18:27 --> Model Class Initialized
INFO - 2020-07-29 17:18:27 --> Model Class Initialized
DEBUG - 2020-07-29 17:18:27 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:18:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:18:27 --> Final output sent to browser
DEBUG - 2020-07-29 17:18:27 --> Total execution time: 0.0205
INFO - 2020-07-29 17:18:30 --> Config Class Initialized
INFO - 2020-07-29 17:18:30 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:18:30 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:18:30 --> Utf8 Class Initialized
INFO - 2020-07-29 17:18:30 --> URI Class Initialized
INFO - 2020-07-29 17:18:30 --> Router Class Initialized
INFO - 2020-07-29 17:18:30 --> Output Class Initialized
INFO - 2020-07-29 17:18:30 --> Security Class Initialized
DEBUG - 2020-07-29 17:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:18:30 --> Input Class Initialized
INFO - 2020-07-29 17:18:30 --> Language Class Initialized
INFO - 2020-07-29 17:18:30 --> Loader Class Initialized
INFO - 2020-07-29 17:18:30 --> Helper loaded: url_helper
INFO - 2020-07-29 17:18:30 --> Database Driver Class Initialized
INFO - 2020-07-29 17:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:18:30 --> Email Class Initialized
INFO - 2020-07-29 17:18:30 --> Controller Class Initialized
INFO - 2020-07-29 17:18:30 --> Model Class Initialized
INFO - 2020-07-29 17:18:30 --> Model Class Initialized
DEBUG - 2020-07-29 17:18:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:18:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:18:30 --> Config Class Initialized
INFO - 2020-07-29 17:18:30 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:18:30 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:18:30 --> Utf8 Class Initialized
INFO - 2020-07-29 17:18:30 --> URI Class Initialized
INFO - 2020-07-29 17:18:30 --> Router Class Initialized
INFO - 2020-07-29 17:18:30 --> Output Class Initialized
INFO - 2020-07-29 17:18:30 --> Security Class Initialized
DEBUG - 2020-07-29 17:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:18:30 --> Input Class Initialized
INFO - 2020-07-29 17:18:30 --> Language Class Initialized
INFO - 2020-07-29 17:18:30 --> Loader Class Initialized
INFO - 2020-07-29 17:18:30 --> Helper loaded: url_helper
INFO - 2020-07-29 17:18:30 --> Database Driver Class Initialized
INFO - 2020-07-29 17:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:18:30 --> Email Class Initialized
INFO - 2020-07-29 17:18:30 --> Controller Class Initialized
INFO - 2020-07-29 17:18:30 --> Model Class Initialized
INFO - 2020-07-29 17:18:30 --> Model Class Initialized
DEBUG - 2020-07-29 17:18:30 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:18:30 --> Config Class Initialized
INFO - 2020-07-29 17:18:30 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:18:30 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:18:30 --> Utf8 Class Initialized
INFO - 2020-07-29 17:18:30 --> URI Class Initialized
DEBUG - 2020-07-29 17:18:30 --> No URI present. Default controller set.
INFO - 2020-07-29 17:18:30 --> Router Class Initialized
INFO - 2020-07-29 17:18:30 --> Output Class Initialized
INFO - 2020-07-29 17:18:30 --> Security Class Initialized
DEBUG - 2020-07-29 17:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:18:30 --> Input Class Initialized
INFO - 2020-07-29 17:18:30 --> Language Class Initialized
INFO - 2020-07-29 17:18:30 --> Loader Class Initialized
INFO - 2020-07-29 17:18:30 --> Helper loaded: url_helper
INFO - 2020-07-29 17:18:30 --> Database Driver Class Initialized
INFO - 2020-07-29 17:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:18:30 --> Email Class Initialized
INFO - 2020-07-29 17:18:30 --> Controller Class Initialized
INFO - 2020-07-29 17:18:30 --> Model Class Initialized
INFO - 2020-07-29 17:18:30 --> Model Class Initialized
DEBUG - 2020-07-29 17:18:30 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:18:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:18:30 --> Final output sent to browser
DEBUG - 2020-07-29 17:18:30 --> Total execution time: 0.0198
INFO - 2020-07-29 17:18:30 --> Config Class Initialized
INFO - 2020-07-29 17:18:30 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:18:30 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:18:30 --> Utf8 Class Initialized
INFO - 2020-07-29 17:18:30 --> URI Class Initialized
DEBUG - 2020-07-29 17:18:30 --> No URI present. Default controller set.
INFO - 2020-07-29 17:18:30 --> Router Class Initialized
INFO - 2020-07-29 17:18:30 --> Output Class Initialized
INFO - 2020-07-29 17:18:30 --> Security Class Initialized
DEBUG - 2020-07-29 17:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:18:30 --> Input Class Initialized
INFO - 2020-07-29 17:18:30 --> Language Class Initialized
INFO - 2020-07-29 17:18:30 --> Loader Class Initialized
INFO - 2020-07-29 17:18:30 --> Helper loaded: url_helper
INFO - 2020-07-29 17:18:30 --> Database Driver Class Initialized
INFO - 2020-07-29 17:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:18:30 --> Email Class Initialized
INFO - 2020-07-29 17:18:30 --> Controller Class Initialized
INFO - 2020-07-29 17:18:30 --> Model Class Initialized
INFO - 2020-07-29 17:18:30 --> Model Class Initialized
DEBUG - 2020-07-29 17:18:30 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:18:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:18:30 --> Final output sent to browser
DEBUG - 2020-07-29 17:18:30 --> Total execution time: 0.0223
INFO - 2020-07-29 17:18:37 --> Config Class Initialized
INFO - 2020-07-29 17:18:37 --> Config Class Initialized
INFO - 2020-07-29 17:18:37 --> Hooks Class Initialized
INFO - 2020-07-29 17:18:37 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:18:37 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:18:37 --> Utf8 Class Initialized
DEBUG - 2020-07-29 17:18:37 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:18:37 --> Utf8 Class Initialized
INFO - 2020-07-29 17:18:37 --> URI Class Initialized
INFO - 2020-07-29 17:18:37 --> URI Class Initialized
INFO - 2020-07-29 17:18:37 --> Router Class Initialized
INFO - 2020-07-29 17:18:37 --> Router Class Initialized
INFO - 2020-07-29 17:18:37 --> Output Class Initialized
INFO - 2020-07-29 17:18:37 --> Output Class Initialized
INFO - 2020-07-29 17:18:37 --> Security Class Initialized
INFO - 2020-07-29 17:18:37 --> Security Class Initialized
DEBUG - 2020-07-29 17:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:18:37 --> Input Class Initialized
DEBUG - 2020-07-29 17:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:18:37 --> Input Class Initialized
INFO - 2020-07-29 17:18:37 --> Language Class Initialized
INFO - 2020-07-29 17:18:37 --> Language Class Initialized
INFO - 2020-07-29 17:18:37 --> Loader Class Initialized
INFO - 2020-07-29 17:18:37 --> Loader Class Initialized
INFO - 2020-07-29 17:18:37 --> Helper loaded: url_helper
INFO - 2020-07-29 17:18:37 --> Helper loaded: url_helper
INFO - 2020-07-29 17:18:37 --> Database Driver Class Initialized
INFO - 2020-07-29 17:18:37 --> Database Driver Class Initialized
INFO - 2020-07-29 17:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:18:37 --> Email Class Initialized
INFO - 2020-07-29 17:18:37 --> Controller Class Initialized
INFO - 2020-07-29 17:18:37 --> Model Class Initialized
INFO - 2020-07-29 17:18:37 --> Model Class Initialized
DEBUG - 2020-07-29 17:18:37 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:18:37 --> Email Class Initialized
INFO - 2020-07-29 17:18:37 --> Controller Class Initialized
INFO - 2020-07-29 17:18:37 --> Model Class Initialized
INFO - 2020-07-29 17:18:37 --> Model Class Initialized
DEBUG - 2020-07-29 17:18:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:18:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:18:37 --> Model Class Initialized
ERROR - 2020-07-29 17:18:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:546) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 17:18:37 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::next_result() /home/purpu1ex/public_html/carsm/application/models/User.php 546
INFO - 2020-07-29 17:18:38 --> Config Class Initialized
INFO - 2020-07-29 17:18:38 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:18:38 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:18:38 --> Utf8 Class Initialized
INFO - 2020-07-29 17:18:38 --> URI Class Initialized
INFO - 2020-07-29 17:18:38 --> Router Class Initialized
INFO - 2020-07-29 17:18:38 --> Output Class Initialized
INFO - 2020-07-29 17:18:38 --> Security Class Initialized
DEBUG - 2020-07-29 17:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:18:38 --> Input Class Initialized
INFO - 2020-07-29 17:18:38 --> Language Class Initialized
INFO - 2020-07-29 17:18:38 --> Loader Class Initialized
INFO - 2020-07-29 17:18:38 --> Helper loaded: url_helper
INFO - 2020-07-29 17:18:38 --> Database Driver Class Initialized
INFO - 2020-07-29 17:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:18:38 --> Email Class Initialized
INFO - 2020-07-29 17:18:38 --> Controller Class Initialized
DEBUG - 2020-07-29 17:18:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:18:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:18:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 17:18:38 --> Final output sent to browser
DEBUG - 2020-07-29 17:18:38 --> Total execution time: 0.0208
INFO - 2020-07-29 17:18:40 --> Config Class Initialized
INFO - 2020-07-29 17:18:40 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:18:40 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:18:40 --> Utf8 Class Initialized
INFO - 2020-07-29 17:18:40 --> URI Class Initialized
DEBUG - 2020-07-29 17:18:40 --> No URI present. Default controller set.
INFO - 2020-07-29 17:18:40 --> Router Class Initialized
INFO - 2020-07-29 17:18:40 --> Output Class Initialized
INFO - 2020-07-29 17:18:40 --> Security Class Initialized
DEBUG - 2020-07-29 17:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:18:40 --> Input Class Initialized
INFO - 2020-07-29 17:18:40 --> Language Class Initialized
INFO - 2020-07-29 17:18:40 --> Loader Class Initialized
INFO - 2020-07-29 17:18:40 --> Helper loaded: url_helper
INFO - 2020-07-29 17:18:40 --> Database Driver Class Initialized
INFO - 2020-07-29 17:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:18:40 --> Email Class Initialized
INFO - 2020-07-29 17:18:40 --> Controller Class Initialized
INFO - 2020-07-29 17:18:40 --> Model Class Initialized
INFO - 2020-07-29 17:18:40 --> Model Class Initialized
DEBUG - 2020-07-29 17:18:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:18:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:18:40 --> Final output sent to browser
DEBUG - 2020-07-29 17:18:40 --> Total execution time: 0.0228
INFO - 2020-07-29 17:18:44 --> Config Class Initialized
INFO - 2020-07-29 17:18:44 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:18:44 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:18:44 --> Utf8 Class Initialized
INFO - 2020-07-29 17:18:44 --> URI Class Initialized
INFO - 2020-07-29 17:18:44 --> Router Class Initialized
INFO - 2020-07-29 17:18:44 --> Output Class Initialized
INFO - 2020-07-29 17:18:44 --> Security Class Initialized
DEBUG - 2020-07-29 17:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:18:44 --> Input Class Initialized
INFO - 2020-07-29 17:18:44 --> Language Class Initialized
INFO - 2020-07-29 17:18:44 --> Loader Class Initialized
INFO - 2020-07-29 17:18:44 --> Helper loaded: url_helper
INFO - 2020-07-29 17:18:44 --> Database Driver Class Initialized
INFO - 2020-07-29 17:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:18:44 --> Email Class Initialized
INFO - 2020-07-29 17:18:44 --> Controller Class Initialized
INFO - 2020-07-29 17:18:44 --> Model Class Initialized
INFO - 2020-07-29 17:18:44 --> Model Class Initialized
DEBUG - 2020-07-29 17:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:18:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:18:44 --> Model Class Initialized
INFO - 2020-07-29 17:18:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-29 17:18:44 --> Final output sent to browser
DEBUG - 2020-07-29 17:18:44 --> Total execution time: 0.0214
INFO - 2020-07-29 17:18:50 --> Config Class Initialized
INFO - 2020-07-29 17:18:50 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:18:50 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:18:50 --> Utf8 Class Initialized
INFO - 2020-07-29 17:18:50 --> URI Class Initialized
INFO - 2020-07-29 17:18:50 --> Router Class Initialized
INFO - 2020-07-29 17:18:50 --> Output Class Initialized
INFO - 2020-07-29 17:18:50 --> Security Class Initialized
DEBUG - 2020-07-29 17:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:18:50 --> Input Class Initialized
INFO - 2020-07-29 17:18:50 --> Language Class Initialized
INFO - 2020-07-29 17:18:50 --> Loader Class Initialized
INFO - 2020-07-29 17:18:50 --> Helper loaded: url_helper
INFO - 2020-07-29 17:18:50 --> Database Driver Class Initialized
INFO - 2020-07-29 17:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:18:50 --> Email Class Initialized
INFO - 2020-07-29 17:18:50 --> Controller Class Initialized
INFO - 2020-07-29 17:18:50 --> Model Class Initialized
INFO - 2020-07-29 17:18:50 --> Model Class Initialized
DEBUG - 2020-07-29 17:18:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:18:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:18:50 --> Model Class Initialized
INFO - 2020-07-29 17:18:50 --> Config Class Initialized
INFO - 2020-07-29 17:18:50 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:18:50 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:18:50 --> Utf8 Class Initialized
INFO - 2020-07-29 17:18:50 --> URI Class Initialized
INFO - 2020-07-29 17:18:50 --> Router Class Initialized
INFO - 2020-07-29 17:18:50 --> Output Class Initialized
INFO - 2020-07-29 17:18:50 --> Security Class Initialized
DEBUG - 2020-07-29 17:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:18:50 --> Input Class Initialized
INFO - 2020-07-29 17:18:50 --> Language Class Initialized
INFO - 2020-07-29 17:18:50 --> Loader Class Initialized
INFO - 2020-07-29 17:18:50 --> Helper loaded: url_helper
INFO - 2020-07-29 17:18:50 --> Database Driver Class Initialized
INFO - 2020-07-29 17:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:18:50 --> Email Class Initialized
INFO - 2020-07-29 17:18:50 --> Controller Class Initialized
INFO - 2020-07-29 17:18:50 --> Model Class Initialized
INFO - 2020-07-29 17:18:50 --> Model Class Initialized
DEBUG - 2020-07-29 17:18:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:18:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:18:50 --> Model Class Initialized
INFO - 2020-07-29 17:18:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-29 17:18:50 --> Final output sent to browser
DEBUG - 2020-07-29 17:18:50 --> Total execution time: 0.0211
INFO - 2020-07-29 17:18:50 --> Config Class Initialized
INFO - 2020-07-29 17:18:50 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:18:50 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:18:50 --> Utf8 Class Initialized
INFO - 2020-07-29 17:18:50 --> URI Class Initialized
DEBUG - 2020-07-29 17:18:50 --> No URI present. Default controller set.
INFO - 2020-07-29 17:18:50 --> Router Class Initialized
INFO - 2020-07-29 17:18:50 --> Output Class Initialized
INFO - 2020-07-29 17:18:50 --> Security Class Initialized
DEBUG - 2020-07-29 17:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:18:50 --> Input Class Initialized
INFO - 2020-07-29 17:18:50 --> Language Class Initialized
INFO - 2020-07-29 17:18:50 --> Loader Class Initialized
INFO - 2020-07-29 17:18:50 --> Helper loaded: url_helper
INFO - 2020-07-29 17:18:51 --> Database Driver Class Initialized
INFO - 2020-07-29 17:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:18:51 --> Email Class Initialized
INFO - 2020-07-29 17:18:51 --> Controller Class Initialized
INFO - 2020-07-29 17:18:51 --> Model Class Initialized
INFO - 2020-07-29 17:18:51 --> Model Class Initialized
DEBUG - 2020-07-29 17:18:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:18:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:18:51 --> Final output sent to browser
DEBUG - 2020-07-29 17:18:51 --> Total execution time: 0.0225
INFO - 2020-07-29 17:20:31 --> Config Class Initialized
INFO - 2020-07-29 17:20:31 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:20:31 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:20:31 --> Utf8 Class Initialized
INFO - 2020-07-29 17:20:31 --> URI Class Initialized
DEBUG - 2020-07-29 17:20:31 --> No URI present. Default controller set.
INFO - 2020-07-29 17:20:31 --> Router Class Initialized
INFO - 2020-07-29 17:20:31 --> Output Class Initialized
INFO - 2020-07-29 17:20:31 --> Security Class Initialized
DEBUG - 2020-07-29 17:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:20:31 --> Input Class Initialized
INFO - 2020-07-29 17:20:31 --> Language Class Initialized
INFO - 2020-07-29 17:20:31 --> Loader Class Initialized
INFO - 2020-07-29 17:20:31 --> Helper loaded: url_helper
INFO - 2020-07-29 17:20:31 --> Database Driver Class Initialized
INFO - 2020-07-29 17:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:20:31 --> Email Class Initialized
INFO - 2020-07-29 17:20:31 --> Controller Class Initialized
INFO - 2020-07-29 17:20:31 --> Model Class Initialized
INFO - 2020-07-29 17:20:31 --> Model Class Initialized
DEBUG - 2020-07-29 17:20:31 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:20:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:20:31 --> Final output sent to browser
DEBUG - 2020-07-29 17:20:31 --> Total execution time: 0.0228
INFO - 2020-07-29 17:20:34 --> Config Class Initialized
INFO - 2020-07-29 17:20:34 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:20:34 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:20:34 --> Utf8 Class Initialized
INFO - 2020-07-29 17:20:34 --> URI Class Initialized
INFO - 2020-07-29 17:20:34 --> Router Class Initialized
INFO - 2020-07-29 17:20:34 --> Output Class Initialized
INFO - 2020-07-29 17:20:34 --> Security Class Initialized
DEBUG - 2020-07-29 17:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:20:34 --> Input Class Initialized
INFO - 2020-07-29 17:20:34 --> Language Class Initialized
INFO - 2020-07-29 17:20:34 --> Loader Class Initialized
INFO - 2020-07-29 17:20:34 --> Helper loaded: url_helper
INFO - 2020-07-29 17:20:34 --> Database Driver Class Initialized
INFO - 2020-07-29 17:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:20:34 --> Email Class Initialized
INFO - 2020-07-29 17:20:34 --> Controller Class Initialized
INFO - 2020-07-29 17:20:34 --> Model Class Initialized
INFO - 2020-07-29 17:20:34 --> Model Class Initialized
DEBUG - 2020-07-29 17:20:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:20:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:20:34 --> Model Class Initialized
ERROR - 2020-07-29 17:20:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:546) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 17:20:34 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::next_result() /home/purpu1ex/public_html/carsm/application/models/User.php 546
INFO - 2020-07-29 17:20:34 --> Config Class Initialized
INFO - 2020-07-29 17:20:34 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:20:34 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:20:34 --> Utf8 Class Initialized
INFO - 2020-07-29 17:20:34 --> URI Class Initialized
INFO - 2020-07-29 17:20:34 --> Router Class Initialized
INFO - 2020-07-29 17:20:34 --> Output Class Initialized
INFO - 2020-07-29 17:20:34 --> Security Class Initialized
DEBUG - 2020-07-29 17:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:20:34 --> Input Class Initialized
INFO - 2020-07-29 17:20:34 --> Language Class Initialized
INFO - 2020-07-29 17:20:34 --> Loader Class Initialized
INFO - 2020-07-29 17:20:34 --> Helper loaded: url_helper
INFO - 2020-07-29 17:20:34 --> Database Driver Class Initialized
INFO - 2020-07-29 17:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:20:34 --> Email Class Initialized
INFO - 2020-07-29 17:20:34 --> Controller Class Initialized
INFO - 2020-07-29 17:20:34 --> Model Class Initialized
INFO - 2020-07-29 17:20:34 --> Model Class Initialized
DEBUG - 2020-07-29 17:20:34 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:20:34 --> Config Class Initialized
INFO - 2020-07-29 17:20:34 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:20:34 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:20:34 --> Utf8 Class Initialized
INFO - 2020-07-29 17:20:34 --> URI Class Initialized
INFO - 2020-07-29 17:20:34 --> Router Class Initialized
INFO - 2020-07-29 17:20:34 --> Output Class Initialized
INFO - 2020-07-29 17:20:34 --> Security Class Initialized
DEBUG - 2020-07-29 17:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:20:34 --> Input Class Initialized
INFO - 2020-07-29 17:20:34 --> Language Class Initialized
INFO - 2020-07-29 17:20:34 --> Loader Class Initialized
INFO - 2020-07-29 17:20:34 --> Helper loaded: url_helper
INFO - 2020-07-29 17:20:34 --> Database Driver Class Initialized
INFO - 2020-07-29 17:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:20:34 --> Email Class Initialized
INFO - 2020-07-29 17:20:34 --> Controller Class Initialized
DEBUG - 2020-07-29 17:20:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:20:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:20:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 17:20:34 --> Final output sent to browser
DEBUG - 2020-07-29 17:20:34 --> Total execution time: 0.0218
INFO - 2020-07-29 17:20:39 --> Config Class Initialized
INFO - 2020-07-29 17:20:39 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:20:39 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:20:39 --> Utf8 Class Initialized
INFO - 2020-07-29 17:20:39 --> URI Class Initialized
DEBUG - 2020-07-29 17:20:39 --> No URI present. Default controller set.
INFO - 2020-07-29 17:20:39 --> Router Class Initialized
INFO - 2020-07-29 17:20:39 --> Output Class Initialized
INFO - 2020-07-29 17:20:39 --> Security Class Initialized
DEBUG - 2020-07-29 17:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:20:39 --> Input Class Initialized
INFO - 2020-07-29 17:20:39 --> Language Class Initialized
INFO - 2020-07-29 17:20:39 --> Loader Class Initialized
INFO - 2020-07-29 17:20:40 --> Helper loaded: url_helper
INFO - 2020-07-29 17:20:40 --> Database Driver Class Initialized
INFO - 2020-07-29 17:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:20:40 --> Email Class Initialized
INFO - 2020-07-29 17:20:40 --> Controller Class Initialized
INFO - 2020-07-29 17:20:40 --> Model Class Initialized
INFO - 2020-07-29 17:20:40 --> Model Class Initialized
DEBUG - 2020-07-29 17:20:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:20:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:20:40 --> Final output sent to browser
DEBUG - 2020-07-29 17:20:40 --> Total execution time: 0.0218
INFO - 2020-07-29 17:20:43 --> Config Class Initialized
INFO - 2020-07-29 17:20:43 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:20:43 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:20:43 --> Utf8 Class Initialized
INFO - 2020-07-29 17:20:43 --> URI Class Initialized
INFO - 2020-07-29 17:20:43 --> Router Class Initialized
INFO - 2020-07-29 17:20:43 --> Output Class Initialized
INFO - 2020-07-29 17:20:43 --> Security Class Initialized
DEBUG - 2020-07-29 17:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:20:43 --> Input Class Initialized
INFO - 2020-07-29 17:20:43 --> Language Class Initialized
INFO - 2020-07-29 17:20:43 --> Loader Class Initialized
INFO - 2020-07-29 17:20:43 --> Helper loaded: url_helper
INFO - 2020-07-29 17:20:43 --> Database Driver Class Initialized
INFO - 2020-07-29 17:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:20:43 --> Email Class Initialized
INFO - 2020-07-29 17:20:43 --> Controller Class Initialized
INFO - 2020-07-29 17:20:43 --> Model Class Initialized
INFO - 2020-07-29 17:20:43 --> Model Class Initialized
DEBUG - 2020-07-29 17:20:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:20:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:20:43 --> Model Class Initialized
INFO - 2020-07-29 17:20:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-29 17:20:43 --> Final output sent to browser
DEBUG - 2020-07-29 17:20:43 --> Total execution time: 0.0191
INFO - 2020-07-29 17:20:53 --> Config Class Initialized
INFO - 2020-07-29 17:20:53 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:20:53 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:20:53 --> Utf8 Class Initialized
INFO - 2020-07-29 17:20:53 --> URI Class Initialized
INFO - 2020-07-29 17:20:53 --> Router Class Initialized
INFO - 2020-07-29 17:20:53 --> Output Class Initialized
INFO - 2020-07-29 17:20:53 --> Security Class Initialized
DEBUG - 2020-07-29 17:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:20:53 --> Input Class Initialized
INFO - 2020-07-29 17:20:53 --> Language Class Initialized
INFO - 2020-07-29 17:20:53 --> Loader Class Initialized
INFO - 2020-07-29 17:20:53 --> Helper loaded: url_helper
INFO - 2020-07-29 17:20:53 --> Database Driver Class Initialized
INFO - 2020-07-29 17:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:20:53 --> Email Class Initialized
INFO - 2020-07-29 17:20:53 --> Controller Class Initialized
INFO - 2020-07-29 17:20:53 --> Model Class Initialized
INFO - 2020-07-29 17:20:53 --> Model Class Initialized
DEBUG - 2020-07-29 17:20:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:20:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:20:53 --> Model Class Initialized
INFO - 2020-07-29 17:20:53 --> Config Class Initialized
INFO - 2020-07-29 17:20:53 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:20:53 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:20:53 --> Utf8 Class Initialized
INFO - 2020-07-29 17:20:53 --> URI Class Initialized
INFO - 2020-07-29 17:20:53 --> Router Class Initialized
INFO - 2020-07-29 17:20:53 --> Output Class Initialized
INFO - 2020-07-29 17:20:53 --> Security Class Initialized
DEBUG - 2020-07-29 17:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:20:53 --> Input Class Initialized
INFO - 2020-07-29 17:20:53 --> Language Class Initialized
INFO - 2020-07-29 17:20:53 --> Loader Class Initialized
INFO - 2020-07-29 17:20:53 --> Helper loaded: url_helper
INFO - 2020-07-29 17:20:53 --> Database Driver Class Initialized
INFO - 2020-07-29 17:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:20:53 --> Email Class Initialized
INFO - 2020-07-29 17:20:53 --> Controller Class Initialized
INFO - 2020-07-29 17:20:53 --> Model Class Initialized
INFO - 2020-07-29 17:20:53 --> Model Class Initialized
DEBUG - 2020-07-29 17:20:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:20:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:20:53 --> Model Class Initialized
INFO - 2020-07-29 17:20:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-29 17:20:53 --> Final output sent to browser
DEBUG - 2020-07-29 17:20:53 --> Total execution time: 0.0240
INFO - 2020-07-29 17:20:53 --> Config Class Initialized
INFO - 2020-07-29 17:20:53 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:20:53 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:20:53 --> Utf8 Class Initialized
INFO - 2020-07-29 17:20:53 --> URI Class Initialized
DEBUG - 2020-07-29 17:20:53 --> No URI present. Default controller set.
INFO - 2020-07-29 17:20:53 --> Router Class Initialized
INFO - 2020-07-29 17:20:53 --> Output Class Initialized
INFO - 2020-07-29 17:20:53 --> Security Class Initialized
DEBUG - 2020-07-29 17:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:20:53 --> Input Class Initialized
INFO - 2020-07-29 17:20:53 --> Language Class Initialized
INFO - 2020-07-29 17:20:53 --> Loader Class Initialized
INFO - 2020-07-29 17:20:53 --> Helper loaded: url_helper
INFO - 2020-07-29 17:20:53 --> Database Driver Class Initialized
INFO - 2020-07-29 17:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:20:53 --> Email Class Initialized
INFO - 2020-07-29 17:20:53 --> Controller Class Initialized
INFO - 2020-07-29 17:20:53 --> Model Class Initialized
INFO - 2020-07-29 17:20:53 --> Model Class Initialized
DEBUG - 2020-07-29 17:20:53 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:20:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:20:53 --> Final output sent to browser
DEBUG - 2020-07-29 17:20:53 --> Total execution time: 0.0228
INFO - 2020-07-29 17:26:10 --> Config Class Initialized
INFO - 2020-07-29 17:26:10 --> Hooks Class Initialized
INFO - 2020-07-29 17:26:10 --> Config Class Initialized
INFO - 2020-07-29 17:26:10 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:26:10 --> UTF-8 Support Enabled
DEBUG - 2020-07-29 17:26:10 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:26:10 --> Utf8 Class Initialized
INFO - 2020-07-29 17:26:10 --> Utf8 Class Initialized
INFO - 2020-07-29 17:26:10 --> URI Class Initialized
INFO - 2020-07-29 17:26:10 --> URI Class Initialized
INFO - 2020-07-29 17:26:10 --> Router Class Initialized
INFO - 2020-07-29 17:26:10 --> Router Class Initialized
INFO - 2020-07-29 17:26:10 --> Output Class Initialized
INFO - 2020-07-29 17:26:10 --> Output Class Initialized
INFO - 2020-07-29 17:26:10 --> Security Class Initialized
INFO - 2020-07-29 17:26:10 --> Security Class Initialized
DEBUG - 2020-07-29 17:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:26:10 --> Input Class Initialized
DEBUG - 2020-07-29 17:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:26:10 --> Input Class Initialized
INFO - 2020-07-29 17:26:10 --> Language Class Initialized
INFO - 2020-07-29 17:26:10 --> Language Class Initialized
INFO - 2020-07-29 17:26:10 --> Loader Class Initialized
INFO - 2020-07-29 17:26:10 --> Loader Class Initialized
INFO - 2020-07-29 17:26:10 --> Helper loaded: url_helper
INFO - 2020-07-29 17:26:10 --> Helper loaded: url_helper
INFO - 2020-07-29 17:26:10 --> Database Driver Class Initialized
INFO - 2020-07-29 17:26:10 --> Database Driver Class Initialized
INFO - 2020-07-29 17:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:26:10 --> Email Class Initialized
INFO - 2020-07-29 17:26:10 --> Controller Class Initialized
INFO - 2020-07-29 17:26:10 --> Model Class Initialized
INFO - 2020-07-29 17:26:10 --> Model Class Initialized
DEBUG - 2020-07-29 17:26:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:26:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:26:10 --> Model Class Initialized
INFO - 2020-07-29 17:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:26:10 --> Email Class Initialized
INFO - 2020-07-29 17:26:10 --> Controller Class Initialized
INFO - 2020-07-29 17:26:10 --> Model Class Initialized
INFO - 2020-07-29 17:26:10 --> Model Class Initialized
DEBUG - 2020-07-29 17:26:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:26:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:26:10 --> Model Class Initialized
INFO - 2020-07-29 17:26:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-29 17:26:10 --> Final output sent to browser
DEBUG - 2020-07-29 17:26:10 --> Total execution time: 0.0728
INFO - 2020-07-29 17:26:22 --> Config Class Initialized
INFO - 2020-07-29 17:26:22 --> Hooks Class Initialized
INFO - 2020-07-29 17:26:22 --> Config Class Initialized
INFO - 2020-07-29 17:26:22 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:26:22 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:26:22 --> Utf8 Class Initialized
INFO - 2020-07-29 17:26:22 --> URI Class Initialized
DEBUG - 2020-07-29 17:26:22 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:26:22 --> Utf8 Class Initialized
INFO - 2020-07-29 17:26:22 --> Router Class Initialized
INFO - 2020-07-29 17:26:22 --> URI Class Initialized
INFO - 2020-07-29 17:26:22 --> Router Class Initialized
INFO - 2020-07-29 17:26:22 --> Output Class Initialized
INFO - 2020-07-29 17:26:22 --> Output Class Initialized
INFO - 2020-07-29 17:26:22 --> Security Class Initialized
INFO - 2020-07-29 17:26:22 --> Security Class Initialized
DEBUG - 2020-07-29 17:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:26:22 --> Input Class Initialized
INFO - 2020-07-29 17:26:22 --> Language Class Initialized
DEBUG - 2020-07-29 17:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:26:22 --> Input Class Initialized
INFO - 2020-07-29 17:26:22 --> Language Class Initialized
INFO - 2020-07-29 17:26:22 --> Loader Class Initialized
INFO - 2020-07-29 17:26:22 --> Loader Class Initialized
INFO - 2020-07-29 17:26:22 --> Helper loaded: url_helper
INFO - 2020-07-29 17:26:22 --> Helper loaded: url_helper
INFO - 2020-07-29 17:26:22 --> Database Driver Class Initialized
INFO - 2020-07-29 17:26:22 --> Database Driver Class Initialized
INFO - 2020-07-29 17:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:26:22 --> Email Class Initialized
INFO - 2020-07-29 17:26:22 --> Controller Class Initialized
INFO - 2020-07-29 17:26:22 --> Model Class Initialized
INFO - 2020-07-29 17:26:22 --> Model Class Initialized
DEBUG - 2020-07-29 17:26:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:26:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:26:22 --> Model Class Initialized
INFO - 2020-07-29 17:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:26:23 --> Email Class Initialized
INFO - 2020-07-29 17:26:23 --> Controller Class Initialized
INFO - 2020-07-29 17:26:23 --> Model Class Initialized
INFO - 2020-07-29 17:26:23 --> Model Class Initialized
DEBUG - 2020-07-29 17:26:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:26:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:26:23 --> Model Class Initialized
INFO - 2020-07-29 17:26:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-29 17:26:23 --> Final output sent to browser
DEBUG - 2020-07-29 17:26:23 --> Total execution time: 0.0752
INFO - 2020-07-29 17:28:05 --> Config Class Initialized
INFO - 2020-07-29 17:28:05 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:28:05 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:28:05 --> Utf8 Class Initialized
INFO - 2020-07-29 17:28:05 --> URI Class Initialized
DEBUG - 2020-07-29 17:28:05 --> No URI present. Default controller set.
INFO - 2020-07-29 17:28:05 --> Router Class Initialized
INFO - 2020-07-29 17:28:05 --> Output Class Initialized
INFO - 2020-07-29 17:28:05 --> Security Class Initialized
DEBUG - 2020-07-29 17:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:28:05 --> Input Class Initialized
INFO - 2020-07-29 17:28:05 --> Language Class Initialized
INFO - 2020-07-29 17:28:05 --> Loader Class Initialized
INFO - 2020-07-29 17:28:05 --> Helper loaded: url_helper
INFO - 2020-07-29 17:28:05 --> Database Driver Class Initialized
INFO - 2020-07-29 17:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:28:05 --> Email Class Initialized
INFO - 2020-07-29 17:28:05 --> Controller Class Initialized
INFO - 2020-07-29 17:28:05 --> Model Class Initialized
INFO - 2020-07-29 17:28:05 --> Model Class Initialized
DEBUG - 2020-07-29 17:28:05 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:28:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:28:05 --> Final output sent to browser
DEBUG - 2020-07-29 17:28:05 --> Total execution time: 0.0230
INFO - 2020-07-29 17:28:11 --> Config Class Initialized
INFO - 2020-07-29 17:28:11 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:28:11 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:28:11 --> Utf8 Class Initialized
INFO - 2020-07-29 17:28:11 --> URI Class Initialized
INFO - 2020-07-29 17:28:11 --> Router Class Initialized
INFO - 2020-07-29 17:28:11 --> Output Class Initialized
INFO - 2020-07-29 17:28:11 --> Security Class Initialized
DEBUG - 2020-07-29 17:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:28:11 --> Input Class Initialized
INFO - 2020-07-29 17:28:11 --> Language Class Initialized
INFO - 2020-07-29 17:28:11 --> Loader Class Initialized
INFO - 2020-07-29 17:28:11 --> Helper loaded: url_helper
INFO - 2020-07-29 17:28:11 --> Database Driver Class Initialized
INFO - 2020-07-29 17:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:28:11 --> Email Class Initialized
INFO - 2020-07-29 17:28:11 --> Controller Class Initialized
INFO - 2020-07-29 17:28:11 --> Model Class Initialized
INFO - 2020-07-29 17:28:11 --> Model Class Initialized
DEBUG - 2020-07-29 17:28:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:28:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:28:11 --> Model Class Initialized
ERROR - 2020-07-29 17:28:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:546) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 17:28:11 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::next_result() /home/purpu1ex/public_html/carsm/application/models/User.php 546
INFO - 2020-07-29 17:28:12 --> Config Class Initialized
INFO - 2020-07-29 17:28:12 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:28:12 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:28:12 --> Utf8 Class Initialized
INFO - 2020-07-29 17:28:12 --> URI Class Initialized
INFO - 2020-07-29 17:28:12 --> Router Class Initialized
INFO - 2020-07-29 17:28:12 --> Output Class Initialized
INFO - 2020-07-29 17:28:12 --> Security Class Initialized
DEBUG - 2020-07-29 17:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:28:12 --> Input Class Initialized
INFO - 2020-07-29 17:28:12 --> Language Class Initialized
INFO - 2020-07-29 17:28:12 --> Loader Class Initialized
INFO - 2020-07-29 17:28:12 --> Helper loaded: url_helper
INFO - 2020-07-29 17:28:12 --> Database Driver Class Initialized
INFO - 2020-07-29 17:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:28:12 --> Email Class Initialized
INFO - 2020-07-29 17:28:12 --> Controller Class Initialized
INFO - 2020-07-29 17:28:12 --> Model Class Initialized
INFO - 2020-07-29 17:28:12 --> Model Class Initialized
DEBUG - 2020-07-29 17:28:12 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:28:12 --> Config Class Initialized
INFO - 2020-07-29 17:28:12 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:28:12 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:28:12 --> Utf8 Class Initialized
INFO - 2020-07-29 17:28:12 --> URI Class Initialized
DEBUG - 2020-07-29 17:28:12 --> No URI present. Default controller set.
INFO - 2020-07-29 17:28:12 --> Router Class Initialized
INFO - 2020-07-29 17:28:12 --> Output Class Initialized
INFO - 2020-07-29 17:28:12 --> Security Class Initialized
DEBUG - 2020-07-29 17:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:28:12 --> Input Class Initialized
INFO - 2020-07-29 17:28:12 --> Language Class Initialized
INFO - 2020-07-29 17:28:12 --> Loader Class Initialized
INFO - 2020-07-29 17:28:12 --> Helper loaded: url_helper
INFO - 2020-07-29 17:28:12 --> Database Driver Class Initialized
INFO - 2020-07-29 17:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:28:12 --> Email Class Initialized
INFO - 2020-07-29 17:28:12 --> Controller Class Initialized
INFO - 2020-07-29 17:28:12 --> Model Class Initialized
INFO - 2020-07-29 17:28:12 --> Model Class Initialized
DEBUG - 2020-07-29 17:28:12 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:28:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:28:12 --> Final output sent to browser
DEBUG - 2020-07-29 17:28:12 --> Total execution time: 0.0224
INFO - 2020-07-29 17:29:57 --> Config Class Initialized
INFO - 2020-07-29 17:29:57 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:29:57 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:29:57 --> Utf8 Class Initialized
INFO - 2020-07-29 17:29:57 --> URI Class Initialized
INFO - 2020-07-29 17:29:57 --> Router Class Initialized
INFO - 2020-07-29 17:29:57 --> Output Class Initialized
INFO - 2020-07-29 17:29:57 --> Security Class Initialized
DEBUG - 2020-07-29 17:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:29:57 --> Input Class Initialized
INFO - 2020-07-29 17:29:57 --> Language Class Initialized
INFO - 2020-07-29 17:29:57 --> Loader Class Initialized
INFO - 2020-07-29 17:29:57 --> Helper loaded: url_helper
INFO - 2020-07-29 17:29:57 --> Database Driver Class Initialized
INFO - 2020-07-29 17:29:57 --> Config Class Initialized
INFO - 2020-07-29 17:29:57 --> Hooks Class Initialized
INFO - 2020-07-29 17:29:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-07-29 17:29:57 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:29:57 --> Utf8 Class Initialized
INFO - 2020-07-29 17:29:57 --> URI Class Initialized
INFO - 2020-07-29 17:29:57 --> Router Class Initialized
INFO - 2020-07-29 17:29:57 --> Email Class Initialized
INFO - 2020-07-29 17:29:57 --> Controller Class Initialized
INFO - 2020-07-29 17:29:57 --> Model Class Initialized
INFO - 2020-07-29 17:29:57 --> Model Class Initialized
INFO - 2020-07-29 17:29:57 --> Output Class Initialized
DEBUG - 2020-07-29 17:29:57 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:29:57 --> Security Class Initialized
DEBUG - 2020-07-29 17:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:29:57 --> Input Class Initialized
INFO - 2020-07-29 17:29:57 --> Language Class Initialized
INFO - 2020-07-29 17:29:57 --> Loader Class Initialized
INFO - 2020-07-29 17:29:57 --> Helper loaded: url_helper
INFO - 2020-07-29 17:29:57 --> Database Driver Class Initialized
INFO - 2020-07-29 17:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:29:57 --> Email Class Initialized
INFO - 2020-07-29 17:29:57 --> Controller Class Initialized
INFO - 2020-07-29 17:29:57 --> Model Class Initialized
INFO - 2020-07-29 17:29:57 --> Model Class Initialized
DEBUG - 2020-07-29 17:29:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:29:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:29:57 --> Model Class Initialized
ERROR - 2020-07-29 17:29:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:546) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 17:29:57 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::next_result() /home/purpu1ex/public_html/carsm/application/models/User.php 546
INFO - 2020-07-29 17:29:58 --> Config Class Initialized
INFO - 2020-07-29 17:29:58 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:29:58 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:29:58 --> Utf8 Class Initialized
INFO - 2020-07-29 17:29:58 --> URI Class Initialized
INFO - 2020-07-29 17:29:58 --> Router Class Initialized
INFO - 2020-07-29 17:29:58 --> Output Class Initialized
INFO - 2020-07-29 17:29:58 --> Security Class Initialized
DEBUG - 2020-07-29 17:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:29:58 --> Input Class Initialized
INFO - 2020-07-29 17:29:58 --> Language Class Initialized
INFO - 2020-07-29 17:29:58 --> Loader Class Initialized
INFO - 2020-07-29 17:29:58 --> Helper loaded: url_helper
INFO - 2020-07-29 17:29:58 --> Database Driver Class Initialized
INFO - 2020-07-29 17:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:29:58 --> Email Class Initialized
INFO - 2020-07-29 17:29:58 --> Controller Class Initialized
DEBUG - 2020-07-29 17:29:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:29:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:29:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 17:29:58 --> Final output sent to browser
DEBUG - 2020-07-29 17:29:58 --> Total execution time: 0.0194
INFO - 2020-07-29 17:30:02 --> Config Class Initialized
INFO - 2020-07-29 17:30:02 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:30:02 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:30:02 --> Utf8 Class Initialized
INFO - 2020-07-29 17:30:02 --> URI Class Initialized
DEBUG - 2020-07-29 17:30:02 --> No URI present. Default controller set.
INFO - 2020-07-29 17:30:02 --> Router Class Initialized
INFO - 2020-07-29 17:30:02 --> Output Class Initialized
INFO - 2020-07-29 17:30:02 --> Security Class Initialized
DEBUG - 2020-07-29 17:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:30:02 --> Input Class Initialized
INFO - 2020-07-29 17:30:02 --> Language Class Initialized
INFO - 2020-07-29 17:30:02 --> Loader Class Initialized
INFO - 2020-07-29 17:30:02 --> Helper loaded: url_helper
INFO - 2020-07-29 17:30:02 --> Database Driver Class Initialized
INFO - 2020-07-29 17:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:30:02 --> Email Class Initialized
INFO - 2020-07-29 17:30:02 --> Controller Class Initialized
INFO - 2020-07-29 17:30:02 --> Model Class Initialized
INFO - 2020-07-29 17:30:02 --> Model Class Initialized
DEBUG - 2020-07-29 17:30:02 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:30:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:30:02 --> Final output sent to browser
DEBUG - 2020-07-29 17:30:02 --> Total execution time: 0.0230
INFO - 2020-07-29 17:32:41 --> Config Class Initialized
INFO - 2020-07-29 17:32:41 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:32:41 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:32:41 --> Utf8 Class Initialized
INFO - 2020-07-29 17:32:41 --> URI Class Initialized
INFO - 2020-07-29 17:32:41 --> Router Class Initialized
INFO - 2020-07-29 17:32:41 --> Output Class Initialized
INFO - 2020-07-29 17:32:41 --> Security Class Initialized
DEBUG - 2020-07-29 17:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:32:41 --> Input Class Initialized
INFO - 2020-07-29 17:32:41 --> Language Class Initialized
INFO - 2020-07-29 17:32:41 --> Loader Class Initialized
INFO - 2020-07-29 17:32:41 --> Helper loaded: url_helper
INFO - 2020-07-29 17:32:41 --> Database Driver Class Initialized
INFO - 2020-07-29 17:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:32:41 --> Email Class Initialized
INFO - 2020-07-29 17:32:41 --> Controller Class Initialized
INFO - 2020-07-29 17:32:41 --> Model Class Initialized
INFO - 2020-07-29 17:32:41 --> Model Class Initialized
DEBUG - 2020-07-29 17:32:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:32:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:32:41 --> Config Class Initialized
INFO - 2020-07-29 17:32:41 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:32:41 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:32:41 --> Utf8 Class Initialized
INFO - 2020-07-29 17:32:41 --> URI Class Initialized
DEBUG - 2020-07-29 17:32:41 --> No URI present. Default controller set.
INFO - 2020-07-29 17:32:41 --> Router Class Initialized
INFO - 2020-07-29 17:32:41 --> Output Class Initialized
INFO - 2020-07-29 17:32:41 --> Security Class Initialized
DEBUG - 2020-07-29 17:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:32:41 --> Input Class Initialized
INFO - 2020-07-29 17:32:41 --> Language Class Initialized
INFO - 2020-07-29 17:32:41 --> Loader Class Initialized
INFO - 2020-07-29 17:32:41 --> Helper loaded: url_helper
INFO - 2020-07-29 17:32:41 --> Database Driver Class Initialized
INFO - 2020-07-29 17:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:32:41 --> Email Class Initialized
INFO - 2020-07-29 17:32:41 --> Controller Class Initialized
INFO - 2020-07-29 17:32:41 --> Model Class Initialized
INFO - 2020-07-29 17:32:41 --> Model Class Initialized
DEBUG - 2020-07-29 17:32:41 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:32:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:32:41 --> Final output sent to browser
DEBUG - 2020-07-29 17:32:41 --> Total execution time: 0.0231
INFO - 2020-07-29 17:32:44 --> Config Class Initialized
INFO - 2020-07-29 17:32:44 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:32:44 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:32:44 --> Utf8 Class Initialized
INFO - 2020-07-29 17:32:44 --> URI Class Initialized
INFO - 2020-07-29 17:32:44 --> Router Class Initialized
INFO - 2020-07-29 17:32:44 --> Output Class Initialized
INFO - 2020-07-29 17:32:44 --> Security Class Initialized
DEBUG - 2020-07-29 17:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:32:44 --> Input Class Initialized
INFO - 2020-07-29 17:32:44 --> Language Class Initialized
INFO - 2020-07-29 17:32:44 --> Loader Class Initialized
INFO - 2020-07-29 17:32:44 --> Helper loaded: url_helper
INFO - 2020-07-29 17:32:44 --> Database Driver Class Initialized
INFO - 2020-07-29 17:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:32:44 --> Email Class Initialized
INFO - 2020-07-29 17:32:44 --> Controller Class Initialized
INFO - 2020-07-29 17:32:44 --> Model Class Initialized
INFO - 2020-07-29 17:32:44 --> Model Class Initialized
DEBUG - 2020-07-29 17:32:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:32:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:32:44 --> Config Class Initialized
INFO - 2020-07-29 17:32:44 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:32:44 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:32:44 --> Utf8 Class Initialized
INFO - 2020-07-29 17:32:44 --> URI Class Initialized
DEBUG - 2020-07-29 17:32:44 --> No URI present. Default controller set.
INFO - 2020-07-29 17:32:44 --> Router Class Initialized
INFO - 2020-07-29 17:32:44 --> Output Class Initialized
INFO - 2020-07-29 17:32:44 --> Security Class Initialized
DEBUG - 2020-07-29 17:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:32:44 --> Input Class Initialized
INFO - 2020-07-29 17:32:44 --> Language Class Initialized
INFO - 2020-07-29 17:32:44 --> Loader Class Initialized
INFO - 2020-07-29 17:32:44 --> Helper loaded: url_helper
INFO - 2020-07-29 17:32:44 --> Database Driver Class Initialized
INFO - 2020-07-29 17:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:32:44 --> Email Class Initialized
INFO - 2020-07-29 17:32:44 --> Controller Class Initialized
INFO - 2020-07-29 17:32:44 --> Model Class Initialized
INFO - 2020-07-29 17:32:44 --> Model Class Initialized
DEBUG - 2020-07-29 17:32:44 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:32:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:32:44 --> Final output sent to browser
DEBUG - 2020-07-29 17:32:44 --> Total execution time: 0.0242
INFO - 2020-07-29 17:32:47 --> Config Class Initialized
INFO - 2020-07-29 17:32:47 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:32:47 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:32:47 --> Utf8 Class Initialized
INFO - 2020-07-29 17:32:47 --> URI Class Initialized
INFO - 2020-07-29 17:32:47 --> Router Class Initialized
INFO - 2020-07-29 17:32:47 --> Output Class Initialized
INFO - 2020-07-29 17:32:47 --> Security Class Initialized
DEBUG - 2020-07-29 17:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:32:47 --> Input Class Initialized
INFO - 2020-07-29 17:32:47 --> Language Class Initialized
INFO - 2020-07-29 17:32:47 --> Loader Class Initialized
INFO - 2020-07-29 17:32:47 --> Helper loaded: url_helper
INFO - 2020-07-29 17:32:47 --> Database Driver Class Initialized
INFO - 2020-07-29 17:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:32:47 --> Email Class Initialized
INFO - 2020-07-29 17:32:47 --> Controller Class Initialized
INFO - 2020-07-29 17:32:47 --> Model Class Initialized
INFO - 2020-07-29 17:32:47 --> Model Class Initialized
DEBUG - 2020-07-29 17:32:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:32:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:32:47 --> Config Class Initialized
INFO - 2020-07-29 17:32:47 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:32:47 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:32:47 --> Utf8 Class Initialized
INFO - 2020-07-29 17:32:47 --> URI Class Initialized
DEBUG - 2020-07-29 17:32:47 --> No URI present. Default controller set.
INFO - 2020-07-29 17:32:47 --> Router Class Initialized
INFO - 2020-07-29 17:32:47 --> Output Class Initialized
INFO - 2020-07-29 17:32:47 --> Security Class Initialized
DEBUG - 2020-07-29 17:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:32:47 --> Input Class Initialized
INFO - 2020-07-29 17:32:47 --> Language Class Initialized
INFO - 2020-07-29 17:32:47 --> Loader Class Initialized
INFO - 2020-07-29 17:32:47 --> Helper loaded: url_helper
INFO - 2020-07-29 17:32:47 --> Database Driver Class Initialized
INFO - 2020-07-29 17:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:32:47 --> Email Class Initialized
INFO - 2020-07-29 17:32:47 --> Controller Class Initialized
INFO - 2020-07-29 17:32:47 --> Model Class Initialized
INFO - 2020-07-29 17:32:47 --> Model Class Initialized
DEBUG - 2020-07-29 17:32:47 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:32:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:32:47 --> Final output sent to browser
DEBUG - 2020-07-29 17:32:47 --> Total execution time: 0.0215
INFO - 2020-07-29 17:32:49 --> Config Class Initialized
INFO - 2020-07-29 17:32:49 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:32:49 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:32:49 --> Utf8 Class Initialized
INFO - 2020-07-29 17:32:49 --> URI Class Initialized
INFO - 2020-07-29 17:32:49 --> Router Class Initialized
INFO - 2020-07-29 17:32:49 --> Output Class Initialized
INFO - 2020-07-29 17:32:49 --> Security Class Initialized
DEBUG - 2020-07-29 17:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:32:49 --> Input Class Initialized
INFO - 2020-07-29 17:32:49 --> Language Class Initialized
INFO - 2020-07-29 17:32:49 --> Loader Class Initialized
INFO - 2020-07-29 17:32:49 --> Helper loaded: url_helper
INFO - 2020-07-29 17:32:49 --> Database Driver Class Initialized
INFO - 2020-07-29 17:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:32:49 --> Email Class Initialized
INFO - 2020-07-29 17:32:49 --> Controller Class Initialized
INFO - 2020-07-29 17:32:49 --> Model Class Initialized
INFO - 2020-07-29 17:32:49 --> Model Class Initialized
DEBUG - 2020-07-29 17:32:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:32:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:32:49 --> Config Class Initialized
INFO - 2020-07-29 17:32:49 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:32:49 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:32:49 --> Utf8 Class Initialized
INFO - 2020-07-29 17:32:49 --> URI Class Initialized
DEBUG - 2020-07-29 17:32:49 --> No URI present. Default controller set.
INFO - 2020-07-29 17:32:49 --> Router Class Initialized
INFO - 2020-07-29 17:32:49 --> Output Class Initialized
INFO - 2020-07-29 17:32:49 --> Security Class Initialized
DEBUG - 2020-07-29 17:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:32:49 --> Input Class Initialized
INFO - 2020-07-29 17:32:49 --> Language Class Initialized
INFO - 2020-07-29 17:32:49 --> Loader Class Initialized
INFO - 2020-07-29 17:32:49 --> Helper loaded: url_helper
INFO - 2020-07-29 17:32:49 --> Database Driver Class Initialized
INFO - 2020-07-29 17:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:32:49 --> Email Class Initialized
INFO - 2020-07-29 17:32:49 --> Controller Class Initialized
INFO - 2020-07-29 17:32:49 --> Model Class Initialized
INFO - 2020-07-29 17:32:49 --> Model Class Initialized
DEBUG - 2020-07-29 17:32:49 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:32:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:32:49 --> Final output sent to browser
DEBUG - 2020-07-29 17:32:49 --> Total execution time: 0.0209
INFO - 2020-07-29 17:32:49 --> Config Class Initialized
INFO - 2020-07-29 17:32:49 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:32:49 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:32:49 --> Utf8 Class Initialized
INFO - 2020-07-29 17:32:49 --> URI Class Initialized
INFO - 2020-07-29 17:32:49 --> Router Class Initialized
INFO - 2020-07-29 17:32:49 --> Output Class Initialized
INFO - 2020-07-29 17:32:49 --> Security Class Initialized
DEBUG - 2020-07-29 17:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:32:49 --> Input Class Initialized
INFO - 2020-07-29 17:32:49 --> Language Class Initialized
INFO - 2020-07-29 17:32:49 --> Loader Class Initialized
INFO - 2020-07-29 17:32:49 --> Helper loaded: url_helper
INFO - 2020-07-29 17:32:49 --> Database Driver Class Initialized
INFO - 2020-07-29 17:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:32:49 --> Email Class Initialized
INFO - 2020-07-29 17:32:49 --> Controller Class Initialized
INFO - 2020-07-29 17:32:49 --> Model Class Initialized
INFO - 2020-07-29 17:32:49 --> Model Class Initialized
DEBUG - 2020-07-29 17:32:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:32:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:32:50 --> Config Class Initialized
INFO - 2020-07-29 17:32:50 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:32:50 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:32:50 --> Utf8 Class Initialized
INFO - 2020-07-29 17:32:50 --> URI Class Initialized
DEBUG - 2020-07-29 17:32:50 --> No URI present. Default controller set.
INFO - 2020-07-29 17:32:50 --> Router Class Initialized
INFO - 2020-07-29 17:32:50 --> Output Class Initialized
INFO - 2020-07-29 17:32:50 --> Security Class Initialized
DEBUG - 2020-07-29 17:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:32:50 --> Input Class Initialized
INFO - 2020-07-29 17:32:50 --> Language Class Initialized
INFO - 2020-07-29 17:32:50 --> Loader Class Initialized
INFO - 2020-07-29 17:32:50 --> Helper loaded: url_helper
INFO - 2020-07-29 17:32:50 --> Database Driver Class Initialized
INFO - 2020-07-29 17:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:32:50 --> Email Class Initialized
INFO - 2020-07-29 17:32:50 --> Controller Class Initialized
INFO - 2020-07-29 17:32:50 --> Model Class Initialized
INFO - 2020-07-29 17:32:50 --> Model Class Initialized
DEBUG - 2020-07-29 17:32:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:32:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:32:50 --> Final output sent to browser
DEBUG - 2020-07-29 17:32:50 --> Total execution time: 0.0214
INFO - 2020-07-29 17:32:52 --> Config Class Initialized
INFO - 2020-07-29 17:32:52 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:32:52 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:32:52 --> Utf8 Class Initialized
INFO - 2020-07-29 17:32:52 --> URI Class Initialized
INFO - 2020-07-29 17:32:52 --> Router Class Initialized
INFO - 2020-07-29 17:32:52 --> Output Class Initialized
INFO - 2020-07-29 17:32:52 --> Security Class Initialized
DEBUG - 2020-07-29 17:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:32:52 --> Input Class Initialized
INFO - 2020-07-29 17:32:52 --> Language Class Initialized
INFO - 2020-07-29 17:32:52 --> Loader Class Initialized
INFO - 2020-07-29 17:32:52 --> Helper loaded: url_helper
INFO - 2020-07-29 17:32:52 --> Database Driver Class Initialized
INFO - 2020-07-29 17:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:32:52 --> Email Class Initialized
INFO - 2020-07-29 17:32:52 --> Controller Class Initialized
INFO - 2020-07-29 17:32:52 --> Model Class Initialized
INFO - 2020-07-29 17:32:52 --> Model Class Initialized
DEBUG - 2020-07-29 17:32:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:32:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:32:52 --> Config Class Initialized
INFO - 2020-07-29 17:32:52 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:32:52 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:32:52 --> Utf8 Class Initialized
INFO - 2020-07-29 17:32:52 --> URI Class Initialized
DEBUG - 2020-07-29 17:32:52 --> No URI present. Default controller set.
INFO - 2020-07-29 17:32:52 --> Router Class Initialized
INFO - 2020-07-29 17:32:52 --> Output Class Initialized
INFO - 2020-07-29 17:32:52 --> Security Class Initialized
DEBUG - 2020-07-29 17:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:32:52 --> Input Class Initialized
INFO - 2020-07-29 17:32:52 --> Language Class Initialized
INFO - 2020-07-29 17:32:52 --> Loader Class Initialized
INFO - 2020-07-29 17:32:52 --> Helper loaded: url_helper
INFO - 2020-07-29 17:32:52 --> Database Driver Class Initialized
INFO - 2020-07-29 17:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:32:52 --> Email Class Initialized
INFO - 2020-07-29 17:32:52 --> Controller Class Initialized
INFO - 2020-07-29 17:32:52 --> Model Class Initialized
INFO - 2020-07-29 17:32:52 --> Model Class Initialized
DEBUG - 2020-07-29 17:32:52 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:32:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:32:52 --> Final output sent to browser
DEBUG - 2020-07-29 17:32:52 --> Total execution time: 0.0197
INFO - 2020-07-29 17:32:54 --> Config Class Initialized
INFO - 2020-07-29 17:32:54 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:32:54 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:32:54 --> Utf8 Class Initialized
INFO - 2020-07-29 17:32:54 --> URI Class Initialized
INFO - 2020-07-29 17:32:54 --> Router Class Initialized
INFO - 2020-07-29 17:32:54 --> Output Class Initialized
INFO - 2020-07-29 17:32:54 --> Security Class Initialized
DEBUG - 2020-07-29 17:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:32:54 --> Input Class Initialized
INFO - 2020-07-29 17:32:54 --> Language Class Initialized
INFO - 2020-07-29 17:32:54 --> Loader Class Initialized
INFO - 2020-07-29 17:32:54 --> Helper loaded: url_helper
INFO - 2020-07-29 17:32:54 --> Database Driver Class Initialized
INFO - 2020-07-29 17:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:32:54 --> Email Class Initialized
INFO - 2020-07-29 17:32:54 --> Controller Class Initialized
INFO - 2020-07-29 17:32:54 --> Model Class Initialized
INFO - 2020-07-29 17:32:54 --> Model Class Initialized
DEBUG - 2020-07-29 17:32:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:32:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:32:55 --> Config Class Initialized
INFO - 2020-07-29 17:32:55 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:32:55 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:32:55 --> Utf8 Class Initialized
INFO - 2020-07-29 17:32:55 --> URI Class Initialized
DEBUG - 2020-07-29 17:32:55 --> No URI present. Default controller set.
INFO - 2020-07-29 17:32:55 --> Router Class Initialized
INFO - 2020-07-29 17:32:55 --> Output Class Initialized
INFO - 2020-07-29 17:32:55 --> Security Class Initialized
DEBUG - 2020-07-29 17:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:32:55 --> Input Class Initialized
INFO - 2020-07-29 17:32:55 --> Language Class Initialized
INFO - 2020-07-29 17:32:55 --> Loader Class Initialized
INFO - 2020-07-29 17:32:55 --> Helper loaded: url_helper
INFO - 2020-07-29 17:32:55 --> Database Driver Class Initialized
INFO - 2020-07-29 17:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:32:55 --> Email Class Initialized
INFO - 2020-07-29 17:32:55 --> Controller Class Initialized
INFO - 2020-07-29 17:32:55 --> Model Class Initialized
INFO - 2020-07-29 17:32:55 --> Model Class Initialized
DEBUG - 2020-07-29 17:32:55 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:32:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:32:55 --> Final output sent to browser
DEBUG - 2020-07-29 17:32:55 --> Total execution time: 0.0204
INFO - 2020-07-29 17:33:00 --> Config Class Initialized
INFO - 2020-07-29 17:33:00 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:33:00 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:33:00 --> Utf8 Class Initialized
INFO - 2020-07-29 17:33:00 --> URI Class Initialized
DEBUG - 2020-07-29 17:33:00 --> No URI present. Default controller set.
INFO - 2020-07-29 17:33:00 --> Router Class Initialized
INFO - 2020-07-29 17:33:00 --> Output Class Initialized
INFO - 2020-07-29 17:33:00 --> Security Class Initialized
DEBUG - 2020-07-29 17:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:33:00 --> Input Class Initialized
INFO - 2020-07-29 17:33:00 --> Language Class Initialized
INFO - 2020-07-29 17:33:00 --> Loader Class Initialized
INFO - 2020-07-29 17:33:00 --> Helper loaded: url_helper
INFO - 2020-07-29 17:33:00 --> Database Driver Class Initialized
INFO - 2020-07-29 17:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:33:00 --> Email Class Initialized
INFO - 2020-07-29 17:33:00 --> Controller Class Initialized
INFO - 2020-07-29 17:33:00 --> Model Class Initialized
INFO - 2020-07-29 17:33:00 --> Model Class Initialized
DEBUG - 2020-07-29 17:33:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:33:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:33:00 --> Final output sent to browser
DEBUG - 2020-07-29 17:33:00 --> Total execution time: 0.0223
INFO - 2020-07-29 17:33:01 --> Config Class Initialized
INFO - 2020-07-29 17:33:01 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:33:01 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:33:01 --> Utf8 Class Initialized
INFO - 2020-07-29 17:33:01 --> URI Class Initialized
DEBUG - 2020-07-29 17:33:01 --> No URI present. Default controller set.
INFO - 2020-07-29 17:33:01 --> Router Class Initialized
INFO - 2020-07-29 17:33:01 --> Output Class Initialized
INFO - 2020-07-29 17:33:01 --> Security Class Initialized
DEBUG - 2020-07-29 17:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:33:01 --> Input Class Initialized
INFO - 2020-07-29 17:33:01 --> Language Class Initialized
INFO - 2020-07-29 17:33:01 --> Loader Class Initialized
INFO - 2020-07-29 17:33:01 --> Helper loaded: url_helper
INFO - 2020-07-29 17:33:01 --> Database Driver Class Initialized
INFO - 2020-07-29 17:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:33:01 --> Email Class Initialized
INFO - 2020-07-29 17:33:01 --> Controller Class Initialized
INFO - 2020-07-29 17:33:01 --> Model Class Initialized
INFO - 2020-07-29 17:33:01 --> Model Class Initialized
DEBUG - 2020-07-29 17:33:01 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:33:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:33:01 --> Final output sent to browser
DEBUG - 2020-07-29 17:33:01 --> Total execution time: 0.0249
INFO - 2020-07-29 17:33:03 --> Config Class Initialized
INFO - 2020-07-29 17:33:03 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:33:03 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:33:03 --> Utf8 Class Initialized
INFO - 2020-07-29 17:33:03 --> URI Class Initialized
INFO - 2020-07-29 17:33:03 --> Router Class Initialized
INFO - 2020-07-29 17:33:03 --> Output Class Initialized
INFO - 2020-07-29 17:33:03 --> Security Class Initialized
DEBUG - 2020-07-29 17:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:33:03 --> Input Class Initialized
INFO - 2020-07-29 17:33:03 --> Language Class Initialized
INFO - 2020-07-29 17:33:03 --> Loader Class Initialized
INFO - 2020-07-29 17:33:03 --> Helper loaded: url_helper
INFO - 2020-07-29 17:33:03 --> Database Driver Class Initialized
INFO - 2020-07-29 17:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:33:03 --> Email Class Initialized
INFO - 2020-07-29 17:33:03 --> Controller Class Initialized
INFO - 2020-07-29 17:33:03 --> Model Class Initialized
INFO - 2020-07-29 17:33:03 --> Model Class Initialized
DEBUG - 2020-07-29 17:33:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:33:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:33:04 --> Config Class Initialized
INFO - 2020-07-29 17:33:04 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:33:04 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:33:04 --> Utf8 Class Initialized
INFO - 2020-07-29 17:33:04 --> URI Class Initialized
DEBUG - 2020-07-29 17:33:04 --> No URI present. Default controller set.
INFO - 2020-07-29 17:33:04 --> Router Class Initialized
INFO - 2020-07-29 17:33:04 --> Output Class Initialized
INFO - 2020-07-29 17:33:04 --> Security Class Initialized
DEBUG - 2020-07-29 17:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:33:04 --> Input Class Initialized
INFO - 2020-07-29 17:33:04 --> Language Class Initialized
INFO - 2020-07-29 17:33:04 --> Loader Class Initialized
INFO - 2020-07-29 17:33:04 --> Helper loaded: url_helper
INFO - 2020-07-29 17:33:04 --> Database Driver Class Initialized
INFO - 2020-07-29 17:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:33:04 --> Email Class Initialized
INFO - 2020-07-29 17:33:04 --> Controller Class Initialized
INFO - 2020-07-29 17:33:04 --> Model Class Initialized
INFO - 2020-07-29 17:33:04 --> Model Class Initialized
DEBUG - 2020-07-29 17:33:04 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:33:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:33:04 --> Final output sent to browser
DEBUG - 2020-07-29 17:33:04 --> Total execution time: 0.0193
INFO - 2020-07-29 17:33:06 --> Config Class Initialized
INFO - 2020-07-29 17:33:06 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:33:06 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:33:06 --> Utf8 Class Initialized
INFO - 2020-07-29 17:33:06 --> URI Class Initialized
INFO - 2020-07-29 17:33:06 --> Router Class Initialized
INFO - 2020-07-29 17:33:06 --> Output Class Initialized
INFO - 2020-07-29 17:33:06 --> Security Class Initialized
DEBUG - 2020-07-29 17:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:33:06 --> Input Class Initialized
INFO - 2020-07-29 17:33:06 --> Language Class Initialized
INFO - 2020-07-29 17:33:06 --> Loader Class Initialized
INFO - 2020-07-29 17:33:06 --> Helper loaded: url_helper
INFO - 2020-07-29 17:33:06 --> Database Driver Class Initialized
INFO - 2020-07-29 17:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:33:06 --> Email Class Initialized
INFO - 2020-07-29 17:33:06 --> Controller Class Initialized
INFO - 2020-07-29 17:33:06 --> Model Class Initialized
INFO - 2020-07-29 17:33:06 --> Model Class Initialized
DEBUG - 2020-07-29 17:33:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:33:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:33:07 --> Config Class Initialized
INFO - 2020-07-29 17:33:07 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:33:07 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:33:07 --> Utf8 Class Initialized
INFO - 2020-07-29 17:33:07 --> URI Class Initialized
DEBUG - 2020-07-29 17:33:07 --> No URI present. Default controller set.
INFO - 2020-07-29 17:33:07 --> Router Class Initialized
INFO - 2020-07-29 17:33:07 --> Output Class Initialized
INFO - 2020-07-29 17:33:07 --> Security Class Initialized
DEBUG - 2020-07-29 17:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:33:07 --> Input Class Initialized
INFO - 2020-07-29 17:33:07 --> Language Class Initialized
INFO - 2020-07-29 17:33:07 --> Loader Class Initialized
INFO - 2020-07-29 17:33:07 --> Helper loaded: url_helper
INFO - 2020-07-29 17:33:07 --> Database Driver Class Initialized
INFO - 2020-07-29 17:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:33:07 --> Email Class Initialized
INFO - 2020-07-29 17:33:07 --> Controller Class Initialized
INFO - 2020-07-29 17:33:07 --> Model Class Initialized
INFO - 2020-07-29 17:33:07 --> Model Class Initialized
DEBUG - 2020-07-29 17:33:07 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:33:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:33:07 --> Final output sent to browser
DEBUG - 2020-07-29 17:33:07 --> Total execution time: 0.0221
INFO - 2020-07-29 17:33:09 --> Config Class Initialized
INFO - 2020-07-29 17:33:09 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:33:09 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:33:09 --> Utf8 Class Initialized
INFO - 2020-07-29 17:33:09 --> URI Class Initialized
DEBUG - 2020-07-29 17:33:09 --> No URI present. Default controller set.
INFO - 2020-07-29 17:33:09 --> Router Class Initialized
INFO - 2020-07-29 17:33:09 --> Output Class Initialized
INFO - 2020-07-29 17:33:09 --> Security Class Initialized
DEBUG - 2020-07-29 17:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:33:09 --> Input Class Initialized
INFO - 2020-07-29 17:33:09 --> Language Class Initialized
INFO - 2020-07-29 17:33:09 --> Loader Class Initialized
INFO - 2020-07-29 17:33:09 --> Helper loaded: url_helper
INFO - 2020-07-29 17:33:09 --> Database Driver Class Initialized
INFO - 2020-07-29 17:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:33:09 --> Email Class Initialized
INFO - 2020-07-29 17:33:09 --> Controller Class Initialized
INFO - 2020-07-29 17:33:09 --> Model Class Initialized
INFO - 2020-07-29 17:33:09 --> Model Class Initialized
DEBUG - 2020-07-29 17:33:09 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:33:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:33:09 --> Final output sent to browser
DEBUG - 2020-07-29 17:33:09 --> Total execution time: 0.0215
INFO - 2020-07-29 17:33:13 --> Config Class Initialized
INFO - 2020-07-29 17:33:13 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:33:13 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:33:13 --> Utf8 Class Initialized
INFO - 2020-07-29 17:33:13 --> URI Class Initialized
DEBUG - 2020-07-29 17:33:13 --> No URI present. Default controller set.
INFO - 2020-07-29 17:33:13 --> Router Class Initialized
INFO - 2020-07-29 17:33:13 --> Output Class Initialized
INFO - 2020-07-29 17:33:13 --> Security Class Initialized
DEBUG - 2020-07-29 17:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:33:13 --> Input Class Initialized
INFO - 2020-07-29 17:33:13 --> Language Class Initialized
INFO - 2020-07-29 17:33:13 --> Loader Class Initialized
INFO - 2020-07-29 17:33:13 --> Helper loaded: url_helper
INFO - 2020-07-29 17:33:13 --> Database Driver Class Initialized
INFO - 2020-07-29 17:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:33:13 --> Email Class Initialized
INFO - 2020-07-29 17:33:14 --> Controller Class Initialized
INFO - 2020-07-29 17:33:14 --> Model Class Initialized
INFO - 2020-07-29 17:33:14 --> Model Class Initialized
DEBUG - 2020-07-29 17:33:14 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:33:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:33:14 --> Final output sent to browser
DEBUG - 2020-07-29 17:33:14 --> Total execution time: 0.0229
INFO - 2020-07-29 17:33:15 --> Config Class Initialized
INFO - 2020-07-29 17:33:15 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:33:15 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:33:15 --> Utf8 Class Initialized
INFO - 2020-07-29 17:33:15 --> URI Class Initialized
DEBUG - 2020-07-29 17:33:15 --> No URI present. Default controller set.
INFO - 2020-07-29 17:33:15 --> Router Class Initialized
INFO - 2020-07-29 17:33:15 --> Output Class Initialized
INFO - 2020-07-29 17:33:15 --> Security Class Initialized
DEBUG - 2020-07-29 17:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:33:15 --> Input Class Initialized
INFO - 2020-07-29 17:33:15 --> Language Class Initialized
INFO - 2020-07-29 17:33:15 --> Loader Class Initialized
INFO - 2020-07-29 17:33:15 --> Helper loaded: url_helper
INFO - 2020-07-29 17:33:15 --> Database Driver Class Initialized
INFO - 2020-07-29 17:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:33:15 --> Email Class Initialized
INFO - 2020-07-29 17:33:15 --> Controller Class Initialized
INFO - 2020-07-29 17:33:15 --> Model Class Initialized
INFO - 2020-07-29 17:33:15 --> Model Class Initialized
DEBUG - 2020-07-29 17:33:15 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:33:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:33:15 --> Final output sent to browser
DEBUG - 2020-07-29 17:33:15 --> Total execution time: 0.0234
INFO - 2020-07-29 17:33:17 --> Config Class Initialized
INFO - 2020-07-29 17:33:17 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:33:17 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:33:17 --> Utf8 Class Initialized
INFO - 2020-07-29 17:33:17 --> URI Class Initialized
INFO - 2020-07-29 17:33:17 --> Router Class Initialized
INFO - 2020-07-29 17:33:17 --> Output Class Initialized
INFO - 2020-07-29 17:33:17 --> Security Class Initialized
DEBUG - 2020-07-29 17:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:33:17 --> Input Class Initialized
INFO - 2020-07-29 17:33:17 --> Language Class Initialized
INFO - 2020-07-29 17:33:17 --> Loader Class Initialized
INFO - 2020-07-29 17:33:17 --> Helper loaded: url_helper
INFO - 2020-07-29 17:33:17 --> Database Driver Class Initialized
INFO - 2020-07-29 17:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:33:17 --> Email Class Initialized
INFO - 2020-07-29 17:33:17 --> Controller Class Initialized
INFO - 2020-07-29 17:33:17 --> Model Class Initialized
INFO - 2020-07-29 17:33:17 --> Model Class Initialized
DEBUG - 2020-07-29 17:33:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:33:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:33:18 --> Config Class Initialized
INFO - 2020-07-29 17:33:18 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:33:18 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:33:18 --> Utf8 Class Initialized
INFO - 2020-07-29 17:33:18 --> URI Class Initialized
DEBUG - 2020-07-29 17:33:18 --> No URI present. Default controller set.
INFO - 2020-07-29 17:33:18 --> Router Class Initialized
INFO - 2020-07-29 17:33:18 --> Output Class Initialized
INFO - 2020-07-29 17:33:18 --> Security Class Initialized
DEBUG - 2020-07-29 17:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:33:18 --> Input Class Initialized
INFO - 2020-07-29 17:33:18 --> Language Class Initialized
INFO - 2020-07-29 17:33:18 --> Loader Class Initialized
INFO - 2020-07-29 17:33:18 --> Helper loaded: url_helper
INFO - 2020-07-29 17:33:18 --> Database Driver Class Initialized
INFO - 2020-07-29 17:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:33:18 --> Email Class Initialized
INFO - 2020-07-29 17:33:18 --> Controller Class Initialized
INFO - 2020-07-29 17:33:18 --> Model Class Initialized
INFO - 2020-07-29 17:33:18 --> Model Class Initialized
DEBUG - 2020-07-29 17:33:18 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:33:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:33:18 --> Final output sent to browser
DEBUG - 2020-07-29 17:33:18 --> Total execution time: 0.0191
INFO - 2020-07-29 17:33:21 --> Config Class Initialized
INFO - 2020-07-29 17:33:21 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:33:21 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:33:21 --> Utf8 Class Initialized
INFO - 2020-07-29 17:33:21 --> URI Class Initialized
INFO - 2020-07-29 17:33:21 --> Router Class Initialized
INFO - 2020-07-29 17:33:21 --> Output Class Initialized
INFO - 2020-07-29 17:33:21 --> Security Class Initialized
DEBUG - 2020-07-29 17:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:33:21 --> Input Class Initialized
INFO - 2020-07-29 17:33:21 --> Language Class Initialized
INFO - 2020-07-29 17:33:21 --> Loader Class Initialized
INFO - 2020-07-29 17:33:21 --> Helper loaded: url_helper
INFO - 2020-07-29 17:33:21 --> Database Driver Class Initialized
INFO - 2020-07-29 17:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:33:21 --> Email Class Initialized
INFO - 2020-07-29 17:33:21 --> Controller Class Initialized
INFO - 2020-07-29 17:33:21 --> Model Class Initialized
INFO - 2020-07-29 17:33:21 --> Model Class Initialized
DEBUG - 2020-07-29 17:33:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:33:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:33:21 --> Config Class Initialized
INFO - 2020-07-29 17:33:21 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:33:21 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:33:21 --> Utf8 Class Initialized
INFO - 2020-07-29 17:33:21 --> URI Class Initialized
INFO - 2020-07-29 17:33:21 --> Router Class Initialized
INFO - 2020-07-29 17:33:21 --> Output Class Initialized
INFO - 2020-07-29 17:33:21 --> Security Class Initialized
DEBUG - 2020-07-29 17:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:33:21 --> Input Class Initialized
INFO - 2020-07-29 17:33:21 --> Language Class Initialized
INFO - 2020-07-29 17:33:21 --> Loader Class Initialized
INFO - 2020-07-29 17:33:21 --> Helper loaded: url_helper
INFO - 2020-07-29 17:33:21 --> Database Driver Class Initialized
INFO - 2020-07-29 17:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:33:21 --> Email Class Initialized
INFO - 2020-07-29 17:33:21 --> Controller Class Initialized
INFO - 2020-07-29 17:33:21 --> Model Class Initialized
INFO - 2020-07-29 17:33:21 --> Model Class Initialized
DEBUG - 2020-07-29 17:33:21 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:33:21 --> Config Class Initialized
INFO - 2020-07-29 17:33:21 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:33:21 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:33:21 --> Utf8 Class Initialized
INFO - 2020-07-29 17:33:21 --> URI Class Initialized
DEBUG - 2020-07-29 17:33:21 --> No URI present. Default controller set.
INFO - 2020-07-29 17:33:21 --> Router Class Initialized
INFO - 2020-07-29 17:33:21 --> Output Class Initialized
INFO - 2020-07-29 17:33:21 --> Security Class Initialized
DEBUG - 2020-07-29 17:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:33:21 --> Input Class Initialized
INFO - 2020-07-29 17:33:21 --> Language Class Initialized
INFO - 2020-07-29 17:33:21 --> Loader Class Initialized
INFO - 2020-07-29 17:33:21 --> Helper loaded: url_helper
INFO - 2020-07-29 17:33:21 --> Database Driver Class Initialized
INFO - 2020-07-29 17:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:33:21 --> Email Class Initialized
INFO - 2020-07-29 17:33:21 --> Controller Class Initialized
INFO - 2020-07-29 17:33:21 --> Model Class Initialized
INFO - 2020-07-29 17:33:21 --> Model Class Initialized
DEBUG - 2020-07-29 17:33:21 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:33:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:33:21 --> Final output sent to browser
DEBUG - 2020-07-29 17:33:21 --> Total execution time: 0.0268
INFO - 2020-07-29 17:33:21 --> Config Class Initialized
INFO - 2020-07-29 17:33:21 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:33:21 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:33:21 --> Utf8 Class Initialized
INFO - 2020-07-29 17:33:21 --> URI Class Initialized
INFO - 2020-07-29 17:33:21 --> Router Class Initialized
INFO - 2020-07-29 17:33:21 --> Output Class Initialized
INFO - 2020-07-29 17:33:21 --> Security Class Initialized
DEBUG - 2020-07-29 17:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:33:21 --> Input Class Initialized
INFO - 2020-07-29 17:33:21 --> Language Class Initialized
INFO - 2020-07-29 17:33:21 --> Loader Class Initialized
INFO - 2020-07-29 17:33:21 --> Helper loaded: url_helper
INFO - 2020-07-29 17:33:21 --> Database Driver Class Initialized
INFO - 2020-07-29 17:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:33:21 --> Email Class Initialized
INFO - 2020-07-29 17:33:21 --> Controller Class Initialized
DEBUG - 2020-07-29 17:33:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:33:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:33:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 17:33:21 --> Final output sent to browser
DEBUG - 2020-07-29 17:33:21 --> Total execution time: 0.0216
INFO - 2020-07-29 17:33:25 --> Config Class Initialized
INFO - 2020-07-29 17:33:25 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:33:25 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:33:25 --> Utf8 Class Initialized
INFO - 2020-07-29 17:33:25 --> URI Class Initialized
DEBUG - 2020-07-29 17:33:25 --> No URI present. Default controller set.
INFO - 2020-07-29 17:33:25 --> Router Class Initialized
INFO - 2020-07-29 17:33:25 --> Output Class Initialized
INFO - 2020-07-29 17:33:25 --> Security Class Initialized
DEBUG - 2020-07-29 17:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:33:25 --> Input Class Initialized
INFO - 2020-07-29 17:33:25 --> Language Class Initialized
INFO - 2020-07-29 17:33:25 --> Loader Class Initialized
INFO - 2020-07-29 17:33:25 --> Helper loaded: url_helper
INFO - 2020-07-29 17:33:25 --> Database Driver Class Initialized
INFO - 2020-07-29 17:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:33:25 --> Email Class Initialized
INFO - 2020-07-29 17:33:25 --> Controller Class Initialized
INFO - 2020-07-29 17:33:25 --> Model Class Initialized
INFO - 2020-07-29 17:33:25 --> Model Class Initialized
DEBUG - 2020-07-29 17:33:25 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:33:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:33:25 --> Final output sent to browser
DEBUG - 2020-07-29 17:33:25 --> Total execution time: 0.0256
INFO - 2020-07-29 17:33:27 --> Config Class Initialized
INFO - 2020-07-29 17:33:27 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:33:27 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:33:27 --> Utf8 Class Initialized
INFO - 2020-07-29 17:33:27 --> URI Class Initialized
INFO - 2020-07-29 17:33:27 --> Router Class Initialized
INFO - 2020-07-29 17:33:27 --> Output Class Initialized
INFO - 2020-07-29 17:33:27 --> Security Class Initialized
DEBUG - 2020-07-29 17:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:33:27 --> Input Class Initialized
INFO - 2020-07-29 17:33:27 --> Language Class Initialized
INFO - 2020-07-29 17:33:27 --> Loader Class Initialized
INFO - 2020-07-29 17:33:27 --> Helper loaded: url_helper
INFO - 2020-07-29 17:33:27 --> Database Driver Class Initialized
INFO - 2020-07-29 17:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:33:27 --> Email Class Initialized
INFO - 2020-07-29 17:33:27 --> Controller Class Initialized
INFO - 2020-07-29 17:33:27 --> Model Class Initialized
INFO - 2020-07-29 17:33:27 --> Model Class Initialized
DEBUG - 2020-07-29 17:33:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:33:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:33:27 --> Model Class Initialized
INFO - 2020-07-29 17:33:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-29 17:33:27 --> Final output sent to browser
DEBUG - 2020-07-29 17:33:27 --> Total execution time: 0.0247
INFO - 2020-07-29 17:35:58 --> Config Class Initialized
INFO - 2020-07-29 17:35:58 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:35:58 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:35:58 --> Utf8 Class Initialized
INFO - 2020-07-29 17:35:58 --> URI Class Initialized
INFO - 2020-07-29 17:35:58 --> Router Class Initialized
INFO - 2020-07-29 17:35:58 --> Output Class Initialized
INFO - 2020-07-29 17:35:58 --> Security Class Initialized
DEBUG - 2020-07-29 17:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:35:58 --> Input Class Initialized
INFO - 2020-07-29 17:35:58 --> Language Class Initialized
INFO - 2020-07-29 17:35:58 --> Loader Class Initialized
INFO - 2020-07-29 17:35:58 --> Helper loaded: url_helper
INFO - 2020-07-29 17:35:58 --> Database Driver Class Initialized
INFO - 2020-07-29 17:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:35:58 --> Email Class Initialized
INFO - 2020-07-29 17:35:58 --> Controller Class Initialized
INFO - 2020-07-29 17:35:58 --> Model Class Initialized
INFO - 2020-07-29 17:35:58 --> Model Class Initialized
DEBUG - 2020-07-29 17:35:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:35:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:35:58 --> Model Class Initialized
ERROR - 2020-07-29 17:35:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:418) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 17:35:58 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::next_result() /home/purpu1ex/public_html/carsm/application/models/User.php 418
INFO - 2020-07-29 17:42:49 --> Config Class Initialized
INFO - 2020-07-29 17:42:49 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:42:49 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:42:49 --> Utf8 Class Initialized
INFO - 2020-07-29 17:42:49 --> URI Class Initialized
DEBUG - 2020-07-29 17:42:49 --> No URI present. Default controller set.
INFO - 2020-07-29 17:42:49 --> Router Class Initialized
INFO - 2020-07-29 17:42:49 --> Output Class Initialized
INFO - 2020-07-29 17:42:49 --> Security Class Initialized
DEBUG - 2020-07-29 17:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:42:49 --> Input Class Initialized
INFO - 2020-07-29 17:42:49 --> Language Class Initialized
INFO - 2020-07-29 17:42:49 --> Loader Class Initialized
INFO - 2020-07-29 17:42:49 --> Helper loaded: url_helper
INFO - 2020-07-29 17:42:49 --> Database Driver Class Initialized
INFO - 2020-07-29 17:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:42:49 --> Email Class Initialized
INFO - 2020-07-29 17:42:49 --> Controller Class Initialized
INFO - 2020-07-29 17:42:49 --> Model Class Initialized
INFO - 2020-07-29 17:42:49 --> Model Class Initialized
DEBUG - 2020-07-29 17:42:49 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:42:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 17:42:49 --> Final output sent to browser
DEBUG - 2020-07-29 17:42:49 --> Total execution time: 0.0220
INFO - 2020-07-29 17:42:51 --> Config Class Initialized
INFO - 2020-07-29 17:42:51 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:42:51 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:42:51 --> Utf8 Class Initialized
INFO - 2020-07-29 17:42:51 --> URI Class Initialized
INFO - 2020-07-29 17:42:51 --> Router Class Initialized
INFO - 2020-07-29 17:42:51 --> Output Class Initialized
INFO - 2020-07-29 17:42:51 --> Security Class Initialized
DEBUG - 2020-07-29 17:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:42:51 --> Input Class Initialized
INFO - 2020-07-29 17:42:51 --> Language Class Initialized
INFO - 2020-07-29 17:42:51 --> Loader Class Initialized
INFO - 2020-07-29 17:42:51 --> Helper loaded: url_helper
INFO - 2020-07-29 17:42:51 --> Database Driver Class Initialized
INFO - 2020-07-29 17:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:42:51 --> Email Class Initialized
INFO - 2020-07-29 17:42:51 --> Controller Class Initialized
INFO - 2020-07-29 17:42:51 --> Model Class Initialized
INFO - 2020-07-29 17:42:51 --> Model Class Initialized
DEBUG - 2020-07-29 17:42:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:42:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:42:51 --> Model Class Initialized
ERROR - 2020-07-29 17:42:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:546) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
INFO - 2020-07-29 17:42:51 --> Config Class Initialized
INFO - 2020-07-29 17:42:51 --> Hooks Class Initialized
ERROR - 2020-07-29 17:42:51 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::next_result() /home/purpu1ex/public_html/carsm/application/models/User.php 546
DEBUG - 2020-07-29 17:42:51 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:42:51 --> Utf8 Class Initialized
INFO - 2020-07-29 17:42:51 --> URI Class Initialized
INFO - 2020-07-29 17:42:51 --> Router Class Initialized
INFO - 2020-07-29 17:42:51 --> Output Class Initialized
INFO - 2020-07-29 17:42:51 --> Security Class Initialized
DEBUG - 2020-07-29 17:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:42:51 --> Input Class Initialized
INFO - 2020-07-29 17:42:51 --> Language Class Initialized
INFO - 2020-07-29 17:42:51 --> Loader Class Initialized
INFO - 2020-07-29 17:42:51 --> Helper loaded: url_helper
INFO - 2020-07-29 17:42:51 --> Database Driver Class Initialized
INFO - 2020-07-29 17:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:42:51 --> Email Class Initialized
INFO - 2020-07-29 17:42:51 --> Controller Class Initialized
INFO - 2020-07-29 17:42:51 --> Model Class Initialized
INFO - 2020-07-29 17:42:51 --> Model Class Initialized
DEBUG - 2020-07-29 17:42:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:42:51 --> Config Class Initialized
INFO - 2020-07-29 17:42:51 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:42:51 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:42:51 --> Utf8 Class Initialized
INFO - 2020-07-29 17:42:51 --> URI Class Initialized
INFO - 2020-07-29 17:42:51 --> Router Class Initialized
INFO - 2020-07-29 17:42:51 --> Output Class Initialized
INFO - 2020-07-29 17:42:51 --> Security Class Initialized
DEBUG - 2020-07-29 17:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:42:51 --> Input Class Initialized
INFO - 2020-07-29 17:42:51 --> Language Class Initialized
INFO - 2020-07-29 17:42:51 --> Loader Class Initialized
INFO - 2020-07-29 17:42:51 --> Helper loaded: url_helper
INFO - 2020-07-29 17:42:51 --> Database Driver Class Initialized
INFO - 2020-07-29 17:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:42:51 --> Email Class Initialized
INFO - 2020-07-29 17:42:51 --> Controller Class Initialized
DEBUG - 2020-07-29 17:42:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:42:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:42:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 17:42:51 --> Final output sent to browser
DEBUG - 2020-07-29 17:42:51 --> Total execution time: 0.0222
INFO - 2020-07-29 17:43:16 --> Config Class Initialized
INFO - 2020-07-29 17:43:16 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:43:16 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:43:16 --> Utf8 Class Initialized
INFO - 2020-07-29 17:43:16 --> URI Class Initialized
INFO - 2020-07-29 17:43:16 --> Router Class Initialized
INFO - 2020-07-29 17:43:16 --> Output Class Initialized
INFO - 2020-07-29 17:43:16 --> Security Class Initialized
DEBUG - 2020-07-29 17:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:43:16 --> Input Class Initialized
INFO - 2020-07-29 17:43:16 --> Language Class Initialized
INFO - 2020-07-29 17:43:16 --> Loader Class Initialized
INFO - 2020-07-29 17:43:16 --> Helper loaded: url_helper
INFO - 2020-07-29 17:43:16 --> Database Driver Class Initialized
INFO - 2020-07-29 17:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:43:16 --> Email Class Initialized
INFO - 2020-07-29 17:43:16 --> Controller Class Initialized
INFO - 2020-07-29 17:43:16 --> Model Class Initialized
INFO - 2020-07-29 17:43:16 --> Model Class Initialized
DEBUG - 2020-07-29 17:43:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:43:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:43:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset.php
INFO - 2020-07-29 17:43:16 --> Final output sent to browser
DEBUG - 2020-07-29 17:43:16 --> Total execution time: 0.0191
INFO - 2020-07-29 17:46:51 --> Config Class Initialized
INFO - 2020-07-29 17:46:51 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:46:51 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:46:51 --> Utf8 Class Initialized
INFO - 2020-07-29 17:46:51 --> URI Class Initialized
INFO - 2020-07-29 17:46:51 --> Router Class Initialized
INFO - 2020-07-29 17:46:51 --> Output Class Initialized
INFO - 2020-07-29 17:46:51 --> Security Class Initialized
DEBUG - 2020-07-29 17:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:46:51 --> Input Class Initialized
INFO - 2020-07-29 17:46:51 --> Language Class Initialized
INFO - 2020-07-29 17:46:51 --> Loader Class Initialized
INFO - 2020-07-29 17:46:51 --> Helper loaded: url_helper
INFO - 2020-07-29 17:46:51 --> Database Driver Class Initialized
INFO - 2020-07-29 17:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:46:51 --> Email Class Initialized
INFO - 2020-07-29 17:46:51 --> Controller Class Initialized
INFO - 2020-07-29 17:46:51 --> Model Class Initialized
INFO - 2020-07-29 17:46:51 --> Model Class Initialized
DEBUG - 2020-07-29 17:46:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:46:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:46:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset.php
INFO - 2020-07-29 17:46:51 --> Final output sent to browser
DEBUG - 2020-07-29 17:46:51 --> Total execution time: 0.0235
INFO - 2020-07-29 17:49:17 --> Config Class Initialized
INFO - 2020-07-29 17:49:17 --> Hooks Class Initialized
DEBUG - 2020-07-29 17:49:17 --> UTF-8 Support Enabled
INFO - 2020-07-29 17:49:17 --> Utf8 Class Initialized
INFO - 2020-07-29 17:49:17 --> URI Class Initialized
INFO - 2020-07-29 17:49:17 --> Router Class Initialized
INFO - 2020-07-29 17:49:17 --> Output Class Initialized
INFO - 2020-07-29 17:49:17 --> Security Class Initialized
DEBUG - 2020-07-29 17:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 17:49:17 --> Input Class Initialized
INFO - 2020-07-29 17:49:17 --> Language Class Initialized
INFO - 2020-07-29 17:49:17 --> Loader Class Initialized
INFO - 2020-07-29 17:49:17 --> Helper loaded: url_helper
INFO - 2020-07-29 17:49:17 --> Database Driver Class Initialized
INFO - 2020-07-29 17:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 17:49:17 --> Email Class Initialized
INFO - 2020-07-29 17:49:17 --> Controller Class Initialized
INFO - 2020-07-29 17:49:17 --> Model Class Initialized
INFO - 2020-07-29 17:49:17 --> Model Class Initialized
DEBUG - 2020-07-29 17:49:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 17:49:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 17:49:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset.php
INFO - 2020-07-29 17:49:17 --> Final output sent to browser
DEBUG - 2020-07-29 17:49:17 --> Total execution time: 0.0228
INFO - 2020-07-29 18:16:23 --> Config Class Initialized
INFO - 2020-07-29 18:16:23 --> Hooks Class Initialized
DEBUG - 2020-07-29 18:16:23 --> UTF-8 Support Enabled
INFO - 2020-07-29 18:16:23 --> Utf8 Class Initialized
INFO - 2020-07-29 18:16:23 --> URI Class Initialized
INFO - 2020-07-29 18:16:23 --> Router Class Initialized
INFO - 2020-07-29 18:16:23 --> Output Class Initialized
INFO - 2020-07-29 18:16:23 --> Security Class Initialized
DEBUG - 2020-07-29 18:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 18:16:23 --> Input Class Initialized
INFO - 2020-07-29 18:16:23 --> Language Class Initialized
INFO - 2020-07-29 18:16:23 --> Loader Class Initialized
INFO - 2020-07-29 18:16:23 --> Helper loaded: url_helper
INFO - 2020-07-29 18:16:23 --> Database Driver Class Initialized
INFO - 2020-07-29 18:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 18:16:23 --> Email Class Initialized
INFO - 2020-07-29 18:16:23 --> Controller Class Initialized
INFO - 2020-07-29 18:16:23 --> Model Class Initialized
INFO - 2020-07-29 18:16:23 --> Model Class Initialized
DEBUG - 2020-07-29 18:16:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 18:16:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 18:16:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset1.php
INFO - 2020-07-29 18:16:23 --> Final output sent to browser
DEBUG - 2020-07-29 18:16:23 --> Total execution time: 0.0217
INFO - 2020-07-29 18:18:08 --> Config Class Initialized
INFO - 2020-07-29 18:18:08 --> Hooks Class Initialized
DEBUG - 2020-07-29 18:18:08 --> UTF-8 Support Enabled
INFO - 2020-07-29 18:18:08 --> Utf8 Class Initialized
INFO - 2020-07-29 18:18:08 --> URI Class Initialized
INFO - 2020-07-29 18:18:08 --> Router Class Initialized
INFO - 2020-07-29 18:18:08 --> Output Class Initialized
INFO - 2020-07-29 18:18:08 --> Security Class Initialized
DEBUG - 2020-07-29 18:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 18:18:08 --> Input Class Initialized
INFO - 2020-07-29 18:18:08 --> Language Class Initialized
INFO - 2020-07-29 18:18:08 --> Loader Class Initialized
INFO - 2020-07-29 18:18:08 --> Helper loaded: url_helper
INFO - 2020-07-29 18:18:08 --> Database Driver Class Initialized
INFO - 2020-07-29 18:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 18:18:08 --> Email Class Initialized
INFO - 2020-07-29 18:18:08 --> Controller Class Initialized
INFO - 2020-07-29 18:18:08 --> Model Class Initialized
INFO - 2020-07-29 18:18:08 --> Model Class Initialized
DEBUG - 2020-07-29 18:18:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 18:18:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 18:18:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset1.php
INFO - 2020-07-29 18:18:08 --> Final output sent to browser
DEBUG - 2020-07-29 18:18:08 --> Total execution time: 0.0226
INFO - 2020-07-29 18:19:09 --> Config Class Initialized
INFO - 2020-07-29 18:19:09 --> Hooks Class Initialized
DEBUG - 2020-07-29 18:19:09 --> UTF-8 Support Enabled
INFO - 2020-07-29 18:19:09 --> Utf8 Class Initialized
INFO - 2020-07-29 18:19:09 --> URI Class Initialized
INFO - 2020-07-29 18:19:09 --> Router Class Initialized
INFO - 2020-07-29 18:19:09 --> Output Class Initialized
INFO - 2020-07-29 18:19:09 --> Security Class Initialized
DEBUG - 2020-07-29 18:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 18:19:09 --> Input Class Initialized
INFO - 2020-07-29 18:19:09 --> Language Class Initialized
ERROR - 2020-07-29 18:19:09 --> 404 Page Not Found: User_reg/rass
INFO - 2020-07-29 18:19:16 --> Config Class Initialized
INFO - 2020-07-29 18:19:16 --> Hooks Class Initialized
DEBUG - 2020-07-29 18:19:16 --> UTF-8 Support Enabled
INFO - 2020-07-29 18:19:16 --> Utf8 Class Initialized
INFO - 2020-07-29 18:19:16 --> URI Class Initialized
DEBUG - 2020-07-29 18:19:16 --> No URI present. Default controller set.
INFO - 2020-07-29 18:19:16 --> Router Class Initialized
INFO - 2020-07-29 18:19:16 --> Output Class Initialized
INFO - 2020-07-29 18:19:16 --> Security Class Initialized
DEBUG - 2020-07-29 18:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 18:19:16 --> Input Class Initialized
INFO - 2020-07-29 18:19:16 --> Language Class Initialized
INFO - 2020-07-29 18:19:16 --> Loader Class Initialized
INFO - 2020-07-29 18:19:16 --> Helper loaded: url_helper
INFO - 2020-07-29 18:19:16 --> Database Driver Class Initialized
INFO - 2020-07-29 18:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 18:19:16 --> Email Class Initialized
INFO - 2020-07-29 18:19:16 --> Controller Class Initialized
INFO - 2020-07-29 18:19:16 --> Model Class Initialized
INFO - 2020-07-29 18:19:16 --> Model Class Initialized
DEBUG - 2020-07-29 18:19:16 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 18:19:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 18:19:16 --> Final output sent to browser
DEBUG - 2020-07-29 18:19:16 --> Total execution time: 0.0208
INFO - 2020-07-29 18:19:17 --> Config Class Initialized
INFO - 2020-07-29 18:19:17 --> Hooks Class Initialized
DEBUG - 2020-07-29 18:19:17 --> UTF-8 Support Enabled
INFO - 2020-07-29 18:19:17 --> Utf8 Class Initialized
INFO - 2020-07-29 18:19:17 --> URI Class Initialized
DEBUG - 2020-07-29 18:19:17 --> No URI present. Default controller set.
INFO - 2020-07-29 18:19:17 --> Router Class Initialized
INFO - 2020-07-29 18:19:17 --> Output Class Initialized
INFO - 2020-07-29 18:19:17 --> Security Class Initialized
DEBUG - 2020-07-29 18:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 18:19:17 --> Input Class Initialized
INFO - 2020-07-29 18:19:17 --> Language Class Initialized
INFO - 2020-07-29 18:19:17 --> Loader Class Initialized
INFO - 2020-07-29 18:19:17 --> Helper loaded: url_helper
INFO - 2020-07-29 18:19:17 --> Database Driver Class Initialized
INFO - 2020-07-29 18:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 18:19:17 --> Email Class Initialized
INFO - 2020-07-29 18:19:17 --> Controller Class Initialized
INFO - 2020-07-29 18:19:17 --> Model Class Initialized
INFO - 2020-07-29 18:19:17 --> Model Class Initialized
DEBUG - 2020-07-29 18:19:17 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 18:19:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 18:19:17 --> Final output sent to browser
DEBUG - 2020-07-29 18:19:17 --> Total execution time: 0.0200
INFO - 2020-07-29 18:19:19 --> Config Class Initialized
INFO - 2020-07-29 18:19:19 --> Hooks Class Initialized
DEBUG - 2020-07-29 18:19:19 --> UTF-8 Support Enabled
INFO - 2020-07-29 18:19:19 --> Utf8 Class Initialized
INFO - 2020-07-29 18:19:19 --> URI Class Initialized
INFO - 2020-07-29 18:19:19 --> Router Class Initialized
INFO - 2020-07-29 18:19:19 --> Output Class Initialized
INFO - 2020-07-29 18:19:19 --> Security Class Initialized
DEBUG - 2020-07-29 18:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 18:19:19 --> Input Class Initialized
INFO - 2020-07-29 18:19:19 --> Language Class Initialized
INFO - 2020-07-29 18:19:19 --> Loader Class Initialized
INFO - 2020-07-29 18:19:19 --> Helper loaded: url_helper
INFO - 2020-07-29 18:19:19 --> Database Driver Class Initialized
INFO - 2020-07-29 18:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 18:19:19 --> Email Class Initialized
INFO - 2020-07-29 18:19:19 --> Controller Class Initialized
INFO - 2020-07-29 18:19:19 --> Model Class Initialized
INFO - 2020-07-29 18:19:19 --> Model Class Initialized
DEBUG - 2020-07-29 18:19:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 18:19:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 18:19:19 --> Model Class Initialized
ERROR - 2020-07-29 18:19:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:546) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 18:19:19 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::next_result() /home/purpu1ex/public_html/carsm/application/models/User.php 546
INFO - 2020-07-29 18:19:19 --> Config Class Initialized
INFO - 2020-07-29 18:19:19 --> Hooks Class Initialized
DEBUG - 2020-07-29 18:19:19 --> UTF-8 Support Enabled
INFO - 2020-07-29 18:19:19 --> Utf8 Class Initialized
INFO - 2020-07-29 18:19:19 --> URI Class Initialized
INFO - 2020-07-29 18:19:19 --> Router Class Initialized
INFO - 2020-07-29 18:19:19 --> Output Class Initialized
INFO - 2020-07-29 18:19:19 --> Security Class Initialized
DEBUG - 2020-07-29 18:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 18:19:19 --> Input Class Initialized
INFO - 2020-07-29 18:19:19 --> Language Class Initialized
INFO - 2020-07-29 18:19:19 --> Loader Class Initialized
INFO - 2020-07-29 18:19:19 --> Helper loaded: url_helper
INFO - 2020-07-29 18:19:19 --> Database Driver Class Initialized
INFO - 2020-07-29 18:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 18:19:19 --> Email Class Initialized
INFO - 2020-07-29 18:19:19 --> Controller Class Initialized
INFO - 2020-07-29 18:19:19 --> Model Class Initialized
INFO - 2020-07-29 18:19:19 --> Model Class Initialized
DEBUG - 2020-07-29 18:19:19 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 18:19:19 --> Config Class Initialized
INFO - 2020-07-29 18:19:19 --> Hooks Class Initialized
DEBUG - 2020-07-29 18:19:19 --> UTF-8 Support Enabled
INFO - 2020-07-29 18:19:19 --> Utf8 Class Initialized
INFO - 2020-07-29 18:19:19 --> URI Class Initialized
INFO - 2020-07-29 18:19:19 --> Router Class Initialized
INFO - 2020-07-29 18:19:19 --> Output Class Initialized
INFO - 2020-07-29 18:19:19 --> Security Class Initialized
DEBUG - 2020-07-29 18:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 18:19:19 --> Input Class Initialized
INFO - 2020-07-29 18:19:19 --> Language Class Initialized
INFO - 2020-07-29 18:19:19 --> Loader Class Initialized
INFO - 2020-07-29 18:19:19 --> Helper loaded: url_helper
INFO - 2020-07-29 18:19:19 --> Database Driver Class Initialized
INFO - 2020-07-29 18:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 18:19:19 --> Email Class Initialized
INFO - 2020-07-29 18:19:19 --> Controller Class Initialized
DEBUG - 2020-07-29 18:19:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 18:19:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 18:19:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 18:19:19 --> Final output sent to browser
DEBUG - 2020-07-29 18:19:19 --> Total execution time: 0.0222
INFO - 2020-07-29 18:19:24 --> Config Class Initialized
INFO - 2020-07-29 18:19:24 --> Hooks Class Initialized
DEBUG - 2020-07-29 18:19:24 --> UTF-8 Support Enabled
INFO - 2020-07-29 18:19:24 --> Utf8 Class Initialized
INFO - 2020-07-29 18:19:24 --> URI Class Initialized
INFO - 2020-07-29 18:19:24 --> Router Class Initialized
INFO - 2020-07-29 18:19:24 --> Output Class Initialized
INFO - 2020-07-29 18:19:24 --> Security Class Initialized
DEBUG - 2020-07-29 18:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 18:19:24 --> Input Class Initialized
INFO - 2020-07-29 18:19:24 --> Language Class Initialized
INFO - 2020-07-29 18:19:24 --> Loader Class Initialized
INFO - 2020-07-29 18:19:24 --> Helper loaded: url_helper
INFO - 2020-07-29 18:19:24 --> Database Driver Class Initialized
INFO - 2020-07-29 18:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 18:19:24 --> Email Class Initialized
INFO - 2020-07-29 18:19:24 --> Controller Class Initialized
DEBUG - 2020-07-29 18:19:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 18:19:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 18:19:24 --> Model Class Initialized
INFO - 2020-07-29 18:19:24 --> Model Class Initialized
INFO - 2020-07-29 18:19:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 18:19:24 --> Final output sent to browser
DEBUG - 2020-07-29 18:19:24 --> Total execution time: 0.0235
INFO - 2020-07-29 18:19:28 --> Config Class Initialized
INFO - 2020-07-29 18:19:28 --> Hooks Class Initialized
DEBUG - 2020-07-29 18:19:28 --> UTF-8 Support Enabled
INFO - 2020-07-29 18:19:28 --> Utf8 Class Initialized
INFO - 2020-07-29 18:19:28 --> URI Class Initialized
INFO - 2020-07-29 18:19:28 --> Router Class Initialized
INFO - 2020-07-29 18:19:28 --> Output Class Initialized
INFO - 2020-07-29 18:19:28 --> Security Class Initialized
DEBUG - 2020-07-29 18:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 18:19:28 --> Input Class Initialized
INFO - 2020-07-29 18:19:28 --> Language Class Initialized
INFO - 2020-07-29 18:19:28 --> Loader Class Initialized
INFO - 2020-07-29 18:19:28 --> Helper loaded: url_helper
INFO - 2020-07-29 18:19:28 --> Database Driver Class Initialized
INFO - 2020-07-29 18:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 18:19:28 --> Email Class Initialized
INFO - 2020-07-29 18:19:28 --> Controller Class Initialized
DEBUG - 2020-07-29 18:19:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 18:19:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 18:19:28 --> Model Class Initialized
INFO - 2020-07-29 18:19:28 --> Model Class Initialized
INFO - 2020-07-29 18:19:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-07-29 18:19:28 --> Final output sent to browser
DEBUG - 2020-07-29 18:19:28 --> Total execution time: 0.0200
INFO - 2020-07-29 18:19:32 --> Config Class Initialized
INFO - 2020-07-29 18:19:32 --> Hooks Class Initialized
DEBUG - 2020-07-29 18:19:32 --> UTF-8 Support Enabled
INFO - 2020-07-29 18:19:32 --> Utf8 Class Initialized
INFO - 2020-07-29 18:19:32 --> URI Class Initialized
INFO - 2020-07-29 18:19:32 --> Router Class Initialized
INFO - 2020-07-29 18:19:32 --> Output Class Initialized
INFO - 2020-07-29 18:19:32 --> Security Class Initialized
DEBUG - 2020-07-29 18:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 18:19:32 --> Input Class Initialized
INFO - 2020-07-29 18:19:32 --> Language Class Initialized
INFO - 2020-07-29 18:19:32 --> Loader Class Initialized
INFO - 2020-07-29 18:19:32 --> Helper loaded: url_helper
INFO - 2020-07-29 18:19:32 --> Database Driver Class Initialized
INFO - 2020-07-29 18:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 18:19:32 --> Email Class Initialized
INFO - 2020-07-29 18:19:32 --> Controller Class Initialized
DEBUG - 2020-07-29 18:19:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 18:19:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 18:19:32 --> Model Class Initialized
INFO - 2020-07-29 18:19:32 --> Model Class Initialized
INFO - 2020-07-29 18:19:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 18:19:32 --> Final output sent to browser
DEBUG - 2020-07-29 18:19:32 --> Total execution time: 0.0221
INFO - 2020-07-29 18:19:35 --> Config Class Initialized
INFO - 2020-07-29 18:19:35 --> Hooks Class Initialized
DEBUG - 2020-07-29 18:19:35 --> UTF-8 Support Enabled
INFO - 2020-07-29 18:19:35 --> Utf8 Class Initialized
INFO - 2020-07-29 18:19:35 --> URI Class Initialized
INFO - 2020-07-29 18:19:35 --> Router Class Initialized
INFO - 2020-07-29 18:19:35 --> Output Class Initialized
INFO - 2020-07-29 18:19:35 --> Security Class Initialized
DEBUG - 2020-07-29 18:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 18:19:35 --> Input Class Initialized
INFO - 2020-07-29 18:19:35 --> Language Class Initialized
INFO - 2020-07-29 18:19:35 --> Loader Class Initialized
INFO - 2020-07-29 18:19:35 --> Helper loaded: url_helper
INFO - 2020-07-29 18:19:35 --> Database Driver Class Initialized
INFO - 2020-07-29 18:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 18:19:35 --> Email Class Initialized
INFO - 2020-07-29 18:19:35 --> Controller Class Initialized
DEBUG - 2020-07-29 18:19:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 18:19:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 18:19:35 --> Model Class Initialized
INFO - 2020-07-29 18:19:35 --> Model Class Initialized
INFO - 2020-07-29 18:19:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-29 18:19:35 --> Final output sent to browser
DEBUG - 2020-07-29 18:19:35 --> Total execution time: 0.0260
INFO - 2020-07-29 18:19:36 --> Config Class Initialized
INFO - 2020-07-29 18:19:36 --> Hooks Class Initialized
DEBUG - 2020-07-29 18:19:36 --> UTF-8 Support Enabled
INFO - 2020-07-29 18:19:36 --> Utf8 Class Initialized
INFO - 2020-07-29 18:19:36 --> URI Class Initialized
INFO - 2020-07-29 18:19:36 --> Router Class Initialized
INFO - 2020-07-29 18:19:36 --> Output Class Initialized
INFO - 2020-07-29 18:19:36 --> Security Class Initialized
DEBUG - 2020-07-29 18:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 18:19:36 --> Input Class Initialized
INFO - 2020-07-29 18:19:36 --> Language Class Initialized
INFO - 2020-07-29 18:19:36 --> Loader Class Initialized
INFO - 2020-07-29 18:19:36 --> Helper loaded: url_helper
INFO - 2020-07-29 18:19:36 --> Database Driver Class Initialized
INFO - 2020-07-29 18:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 18:19:36 --> Email Class Initialized
INFO - 2020-07-29 18:19:36 --> Controller Class Initialized
DEBUG - 2020-07-29 18:19:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 18:19:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 18:19:36 --> Model Class Initialized
INFO - 2020-07-29 18:19:36 --> Model Class Initialized
INFO - 2020-07-29 18:19:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-29 18:19:36 --> Final output sent to browser
DEBUG - 2020-07-29 18:19:36 --> Total execution time: 0.0277
INFO - 2020-07-29 18:19:42 --> Config Class Initialized
INFO - 2020-07-29 18:19:42 --> Hooks Class Initialized
DEBUG - 2020-07-29 18:19:42 --> UTF-8 Support Enabled
INFO - 2020-07-29 18:19:42 --> Utf8 Class Initialized
INFO - 2020-07-29 18:19:42 --> URI Class Initialized
DEBUG - 2020-07-29 18:19:42 --> No URI present. Default controller set.
INFO - 2020-07-29 18:19:42 --> Router Class Initialized
INFO - 2020-07-29 18:19:42 --> Output Class Initialized
INFO - 2020-07-29 18:19:42 --> Security Class Initialized
DEBUG - 2020-07-29 18:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 18:19:42 --> Input Class Initialized
INFO - 2020-07-29 18:19:42 --> Language Class Initialized
INFO - 2020-07-29 18:19:42 --> Loader Class Initialized
INFO - 2020-07-29 18:19:42 --> Helper loaded: url_helper
INFO - 2020-07-29 18:19:42 --> Database Driver Class Initialized
INFO - 2020-07-29 18:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 18:19:42 --> Email Class Initialized
INFO - 2020-07-29 18:19:42 --> Controller Class Initialized
INFO - 2020-07-29 18:19:42 --> Model Class Initialized
INFO - 2020-07-29 18:19:42 --> Model Class Initialized
DEBUG - 2020-07-29 18:19:42 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 18:19:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 18:19:42 --> Final output sent to browser
DEBUG - 2020-07-29 18:19:42 --> Total execution time: 0.0194
INFO - 2020-07-29 18:19:45 --> Config Class Initialized
INFO - 2020-07-29 18:19:45 --> Hooks Class Initialized
DEBUG - 2020-07-29 18:19:45 --> UTF-8 Support Enabled
INFO - 2020-07-29 18:19:45 --> Utf8 Class Initialized
INFO - 2020-07-29 18:19:45 --> URI Class Initialized
INFO - 2020-07-29 18:19:45 --> Router Class Initialized
INFO - 2020-07-29 18:19:45 --> Output Class Initialized
INFO - 2020-07-29 18:19:45 --> Security Class Initialized
DEBUG - 2020-07-29 18:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 18:19:45 --> Input Class Initialized
INFO - 2020-07-29 18:19:45 --> Language Class Initialized
INFO - 2020-07-29 18:19:45 --> Loader Class Initialized
INFO - 2020-07-29 18:19:45 --> Helper loaded: url_helper
INFO - 2020-07-29 18:19:45 --> Database Driver Class Initialized
INFO - 2020-07-29 18:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 18:19:45 --> Email Class Initialized
INFO - 2020-07-29 18:19:45 --> Controller Class Initialized
INFO - 2020-07-29 18:19:45 --> Model Class Initialized
INFO - 2020-07-29 18:19:45 --> Model Class Initialized
DEBUG - 2020-07-29 18:19:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 18:19:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 18:19:45 --> Model Class Initialized
ERROR - 2020-07-29 18:19:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:546) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-29 18:19:45 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::next_result() /home/purpu1ex/public_html/carsm/application/models/User.php 546
INFO - 2020-07-29 18:19:45 --> Config Class Initialized
INFO - 2020-07-29 18:19:45 --> Hooks Class Initialized
DEBUG - 2020-07-29 18:19:45 --> UTF-8 Support Enabled
INFO - 2020-07-29 18:19:45 --> Utf8 Class Initialized
INFO - 2020-07-29 18:19:45 --> URI Class Initialized
INFO - 2020-07-29 18:19:45 --> Router Class Initialized
INFO - 2020-07-29 18:19:45 --> Output Class Initialized
INFO - 2020-07-29 18:19:45 --> Security Class Initialized
DEBUG - 2020-07-29 18:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 18:19:45 --> Input Class Initialized
INFO - 2020-07-29 18:19:45 --> Language Class Initialized
INFO - 2020-07-29 18:19:45 --> Loader Class Initialized
INFO - 2020-07-29 18:19:45 --> Helper loaded: url_helper
INFO - 2020-07-29 18:19:45 --> Database Driver Class Initialized
INFO - 2020-07-29 18:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 18:19:45 --> Email Class Initialized
INFO - 2020-07-29 18:19:45 --> Controller Class Initialized
INFO - 2020-07-29 18:19:45 --> Model Class Initialized
INFO - 2020-07-29 18:19:45 --> Model Class Initialized
DEBUG - 2020-07-29 18:19:45 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 18:19:46 --> Config Class Initialized
INFO - 2020-07-29 18:19:46 --> Hooks Class Initialized
DEBUG - 2020-07-29 18:19:46 --> UTF-8 Support Enabled
INFO - 2020-07-29 18:19:46 --> Utf8 Class Initialized
INFO - 2020-07-29 18:19:46 --> URI Class Initialized
INFO - 2020-07-29 18:19:46 --> Router Class Initialized
INFO - 2020-07-29 18:19:46 --> Output Class Initialized
INFO - 2020-07-29 18:19:46 --> Security Class Initialized
DEBUG - 2020-07-29 18:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 18:19:46 --> Input Class Initialized
INFO - 2020-07-29 18:19:46 --> Language Class Initialized
INFO - 2020-07-29 18:19:46 --> Loader Class Initialized
INFO - 2020-07-29 18:19:46 --> Helper loaded: url_helper
INFO - 2020-07-29 18:19:46 --> Database Driver Class Initialized
INFO - 2020-07-29 18:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 18:19:46 --> Email Class Initialized
INFO - 2020-07-29 18:19:46 --> Controller Class Initialized
DEBUG - 2020-07-29 18:19:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 18:19:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 18:19:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-29 18:19:46 --> Final output sent to browser
DEBUG - 2020-07-29 18:19:46 --> Total execution time: 0.0226
INFO - 2020-07-29 18:19:50 --> Config Class Initialized
INFO - 2020-07-29 18:19:50 --> Hooks Class Initialized
DEBUG - 2020-07-29 18:19:50 --> UTF-8 Support Enabled
INFO - 2020-07-29 18:19:50 --> Utf8 Class Initialized
INFO - 2020-07-29 18:19:50 --> URI Class Initialized
DEBUG - 2020-07-29 18:19:50 --> No URI present. Default controller set.
INFO - 2020-07-29 18:19:50 --> Router Class Initialized
INFO - 2020-07-29 18:19:50 --> Output Class Initialized
INFO - 2020-07-29 18:19:50 --> Security Class Initialized
DEBUG - 2020-07-29 18:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 18:19:50 --> Input Class Initialized
INFO - 2020-07-29 18:19:50 --> Language Class Initialized
INFO - 2020-07-29 18:19:50 --> Loader Class Initialized
INFO - 2020-07-29 18:19:50 --> Helper loaded: url_helper
INFO - 2020-07-29 18:19:50 --> Database Driver Class Initialized
INFO - 2020-07-29 18:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 18:19:50 --> Email Class Initialized
INFO - 2020-07-29 18:19:50 --> Controller Class Initialized
INFO - 2020-07-29 18:19:50 --> Model Class Initialized
INFO - 2020-07-29 18:19:50 --> Model Class Initialized
DEBUG - 2020-07-29 18:19:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-29 18:19:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-29 18:19:50 --> Final output sent to browser
DEBUG - 2020-07-29 18:19:50 --> Total execution time: 0.0204
INFO - 2020-07-29 18:19:52 --> Config Class Initialized
INFO - 2020-07-29 18:19:52 --> Hooks Class Initialized
DEBUG - 2020-07-29 18:19:52 --> UTF-8 Support Enabled
INFO - 2020-07-29 18:19:52 --> Utf8 Class Initialized
INFO - 2020-07-29 18:19:52 --> URI Class Initialized
INFO - 2020-07-29 18:19:52 --> Router Class Initialized
INFO - 2020-07-29 18:19:52 --> Output Class Initialized
INFO - 2020-07-29 18:19:52 --> Security Class Initialized
DEBUG - 2020-07-29 18:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-29 18:19:52 --> Input Class Initialized
INFO - 2020-07-29 18:19:52 --> Language Class Initialized
INFO - 2020-07-29 18:19:52 --> Loader Class Initialized
INFO - 2020-07-29 18:19:52 --> Helper loaded: url_helper
INFO - 2020-07-29 18:19:52 --> Database Driver Class Initialized
INFO - 2020-07-29 18:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-29 18:19:52 --> Email Class Initialized
INFO - 2020-07-29 18:19:52 --> Controller Class Initialized
INFO - 2020-07-29 18:19:52 --> Model Class Initialized
INFO - 2020-07-29 18:19:52 --> Model Class Initialized
DEBUG - 2020-07-29 18:19:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-29 18:19:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-29 18:19:52 --> Model Class Initialized
INFO - 2020-07-29 18:19:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-29 18:19:52 --> Final output sent to browser
DEBUG - 2020-07-29 18:19:52 --> Total execution time: 0.0220
