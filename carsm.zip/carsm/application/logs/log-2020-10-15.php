<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-15 04:22:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-15 04:22:13 --> Config Class Initialized
INFO - 2020-10-15 04:22:13 --> Hooks Class Initialized
DEBUG - 2020-10-15 04:22:13 --> UTF-8 Support Enabled
INFO - 2020-10-15 04:22:13 --> Utf8 Class Initialized
INFO - 2020-10-15 04:22:13 --> URI Class Initialized
DEBUG - 2020-10-15 04:22:13 --> No URI present. Default controller set.
INFO - 2020-10-15 04:22:13 --> Router Class Initialized
INFO - 2020-10-15 04:22:13 --> Output Class Initialized
INFO - 2020-10-15 04:22:13 --> Security Class Initialized
DEBUG - 2020-10-15 04:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 04:22:13 --> Input Class Initialized
INFO - 2020-10-15 04:22:13 --> Language Class Initialized
INFO - 2020-10-15 04:22:13 --> Loader Class Initialized
INFO - 2020-10-15 04:22:13 --> Helper loaded: url_helper
INFO - 2020-10-15 04:22:13 --> Database Driver Class Initialized
INFO - 2020-10-15 04:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 04:22:13 --> Email Class Initialized
INFO - 2020-10-15 04:22:13 --> Controller Class Initialized
INFO - 2020-10-15 04:22:13 --> Model Class Initialized
INFO - 2020-10-15 04:22:13 --> Model Class Initialized
DEBUG - 2020-10-15 04:22:13 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-15 04:22:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-15 04:22:13 --> Final output sent to browser
DEBUG - 2020-10-15 04:22:13 --> Total execution time: 0.0203
ERROR - 2020-10-15 04:23:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-15 04:23:54 --> Config Class Initialized
INFO - 2020-10-15 04:23:54 --> Hooks Class Initialized
DEBUG - 2020-10-15 04:23:54 --> UTF-8 Support Enabled
INFO - 2020-10-15 04:23:54 --> Utf8 Class Initialized
INFO - 2020-10-15 04:23:54 --> URI Class Initialized
DEBUG - 2020-10-15 04:23:54 --> No URI present. Default controller set.
INFO - 2020-10-15 04:23:54 --> Router Class Initialized
INFO - 2020-10-15 04:23:54 --> Output Class Initialized
INFO - 2020-10-15 04:23:54 --> Security Class Initialized
DEBUG - 2020-10-15 04:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 04:23:55 --> Input Class Initialized
INFO - 2020-10-15 04:23:55 --> Language Class Initialized
INFO - 2020-10-15 04:23:55 --> Loader Class Initialized
INFO - 2020-10-15 04:23:55 --> Helper loaded: url_helper
INFO - 2020-10-15 04:23:55 --> Database Driver Class Initialized
INFO - 2020-10-15 04:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 04:23:55 --> Email Class Initialized
INFO - 2020-10-15 04:23:55 --> Controller Class Initialized
INFO - 2020-10-15 04:23:55 --> Model Class Initialized
INFO - 2020-10-15 04:23:55 --> Model Class Initialized
DEBUG - 2020-10-15 04:23:55 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-15 04:23:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-15 04:23:55 --> Final output sent to browser
DEBUG - 2020-10-15 04:23:55 --> Total execution time: 0.0260
ERROR - 2020-10-15 08:43:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-15 08:43:15 --> Config Class Initialized
INFO - 2020-10-15 08:43:15 --> Hooks Class Initialized
DEBUG - 2020-10-15 08:43:15 --> UTF-8 Support Enabled
INFO - 2020-10-15 08:43:15 --> Utf8 Class Initialized
INFO - 2020-10-15 08:43:15 --> URI Class Initialized
DEBUG - 2020-10-15 08:43:15 --> No URI present. Default controller set.
INFO - 2020-10-15 08:43:15 --> Router Class Initialized
INFO - 2020-10-15 08:43:15 --> Output Class Initialized
INFO - 2020-10-15 08:43:15 --> Security Class Initialized
DEBUG - 2020-10-15 08:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 08:43:15 --> Input Class Initialized
INFO - 2020-10-15 08:43:15 --> Language Class Initialized
INFO - 2020-10-15 08:43:15 --> Loader Class Initialized
INFO - 2020-10-15 08:43:15 --> Helper loaded: url_helper
INFO - 2020-10-15 08:43:15 --> Database Driver Class Initialized
INFO - 2020-10-15 08:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 08:43:15 --> Email Class Initialized
INFO - 2020-10-15 08:43:15 --> Controller Class Initialized
INFO - 2020-10-15 08:43:15 --> Model Class Initialized
INFO - 2020-10-15 08:43:15 --> Model Class Initialized
DEBUG - 2020-10-15 08:43:15 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-15 08:43:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-15 08:43:15 --> Final output sent to browser
DEBUG - 2020-10-15 08:43:15 --> Total execution time: 0.1341
ERROR - 2020-10-15 14:40:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-15 14:40:16 --> Config Class Initialized
INFO - 2020-10-15 14:40:16 --> Hooks Class Initialized
DEBUG - 2020-10-15 14:40:16 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:40:16 --> Utf8 Class Initialized
INFO - 2020-10-15 14:40:16 --> URI Class Initialized
DEBUG - 2020-10-15 14:40:16 --> No URI present. Default controller set.
INFO - 2020-10-15 14:40:16 --> Router Class Initialized
INFO - 2020-10-15 14:40:16 --> Output Class Initialized
INFO - 2020-10-15 14:40:16 --> Security Class Initialized
DEBUG - 2020-10-15 14:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:40:16 --> Input Class Initialized
INFO - 2020-10-15 14:40:16 --> Language Class Initialized
INFO - 2020-10-15 14:40:16 --> Loader Class Initialized
INFO - 2020-10-15 14:40:16 --> Helper loaded: url_helper
INFO - 2020-10-15 14:40:16 --> Database Driver Class Initialized
INFO - 2020-10-15 14:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 14:40:16 --> Email Class Initialized
INFO - 2020-10-15 14:40:16 --> Controller Class Initialized
INFO - 2020-10-15 14:40:16 --> Model Class Initialized
INFO - 2020-10-15 14:40:16 --> Model Class Initialized
DEBUG - 2020-10-15 14:40:16 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-15 14:40:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-15 14:40:16 --> Final output sent to browser
DEBUG - 2020-10-15 14:40:16 --> Total execution time: 0.0504
ERROR - 2020-10-15 17:16:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-15 17:16:21 --> Config Class Initialized
INFO - 2020-10-15 17:16:21 --> Hooks Class Initialized
DEBUG - 2020-10-15 17:16:21 --> UTF-8 Support Enabled
INFO - 2020-10-15 17:16:21 --> Utf8 Class Initialized
INFO - 2020-10-15 17:16:21 --> URI Class Initialized
DEBUG - 2020-10-15 17:16:21 --> No URI present. Default controller set.
INFO - 2020-10-15 17:16:21 --> Router Class Initialized
INFO - 2020-10-15 17:16:21 --> Output Class Initialized
INFO - 2020-10-15 17:16:21 --> Security Class Initialized
DEBUG - 2020-10-15 17:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 17:16:21 --> Input Class Initialized
INFO - 2020-10-15 17:16:21 --> Language Class Initialized
INFO - 2020-10-15 17:16:21 --> Loader Class Initialized
INFO - 2020-10-15 17:16:21 --> Helper loaded: url_helper
INFO - 2020-10-15 17:16:21 --> Database Driver Class Initialized
INFO - 2020-10-15 17:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 17:16:21 --> Email Class Initialized
INFO - 2020-10-15 17:16:21 --> Controller Class Initialized
INFO - 2020-10-15 17:16:21 --> Model Class Initialized
INFO - 2020-10-15 17:16:21 --> Model Class Initialized
DEBUG - 2020-10-15 17:16:21 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-15 17:16:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-15 17:16:21 --> Final output sent to browser
DEBUG - 2020-10-15 17:16:21 --> Total execution time: 0.0188
ERROR - 2020-10-15 17:16:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-15 17:16:25 --> Config Class Initialized
INFO - 2020-10-15 17:16:25 --> Hooks Class Initialized
DEBUG - 2020-10-15 17:16:25 --> UTF-8 Support Enabled
INFO - 2020-10-15 17:16:25 --> Utf8 Class Initialized
INFO - 2020-10-15 17:16:25 --> URI Class Initialized
INFO - 2020-10-15 17:16:25 --> Router Class Initialized
INFO - 2020-10-15 17:16:25 --> Output Class Initialized
INFO - 2020-10-15 17:16:25 --> Security Class Initialized
DEBUG - 2020-10-15 17:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 17:16:25 --> Input Class Initialized
INFO - 2020-10-15 17:16:25 --> Language Class Initialized
INFO - 2020-10-15 17:16:25 --> Loader Class Initialized
INFO - 2020-10-15 17:16:25 --> Helper loaded: url_helper
INFO - 2020-10-15 17:16:25 --> Database Driver Class Initialized
INFO - 2020-10-15 17:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 17:16:25 --> Email Class Initialized
INFO - 2020-10-15 17:16:25 --> Controller Class Initialized
INFO - 2020-10-15 17:16:25 --> Model Class Initialized
INFO - 2020-10-15 17:16:25 --> Model Class Initialized
DEBUG - 2020-10-15 17:16:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-15 17:16:25 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-10-15 17:16:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-15 17:16:25 --> Config Class Initialized
INFO - 2020-10-15 17:16:25 --> Hooks Class Initialized
DEBUG - 2020-10-15 17:16:25 --> UTF-8 Support Enabled
INFO - 2020-10-15 17:16:25 --> Utf8 Class Initialized
INFO - 2020-10-15 17:16:25 --> URI Class Initialized
INFO - 2020-10-15 17:16:25 --> Router Class Initialized
INFO - 2020-10-15 17:16:25 --> Output Class Initialized
INFO - 2020-10-15 17:16:25 --> Security Class Initialized
DEBUG - 2020-10-15 17:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 17:16:25 --> Input Class Initialized
INFO - 2020-10-15 17:16:25 --> Language Class Initialized
INFO - 2020-10-15 17:16:25 --> Loader Class Initialized
INFO - 2020-10-15 17:16:25 --> Helper loaded: url_helper
INFO - 2020-10-15 17:16:25 --> Database Driver Class Initialized
INFO - 2020-10-15 17:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 17:16:25 --> Email Class Initialized
INFO - 2020-10-15 17:16:25 --> Controller Class Initialized
INFO - 2020-10-15 17:16:25 --> Model Class Initialized
INFO - 2020-10-15 17:16:25 --> Model Class Initialized
DEBUG - 2020-10-15 17:16:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-15 17:16:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-15 17:16:25 --> Config Class Initialized
INFO - 2020-10-15 17:16:25 --> Hooks Class Initialized
DEBUG - 2020-10-15 17:16:25 --> UTF-8 Support Enabled
INFO - 2020-10-15 17:16:25 --> Utf8 Class Initialized
INFO - 2020-10-15 17:16:25 --> URI Class Initialized
DEBUG - 2020-10-15 17:16:25 --> No URI present. Default controller set.
INFO - 2020-10-15 17:16:25 --> Router Class Initialized
INFO - 2020-10-15 17:16:25 --> Output Class Initialized
INFO - 2020-10-15 17:16:25 --> Security Class Initialized
DEBUG - 2020-10-15 17:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 17:16:25 --> Input Class Initialized
INFO - 2020-10-15 17:16:25 --> Language Class Initialized
INFO - 2020-10-15 17:16:25 --> Loader Class Initialized
INFO - 2020-10-15 17:16:25 --> Helper loaded: url_helper
INFO - 2020-10-15 17:16:25 --> Database Driver Class Initialized
INFO - 2020-10-15 17:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 17:16:25 --> Email Class Initialized
INFO - 2020-10-15 17:16:25 --> Controller Class Initialized
INFO - 2020-10-15 17:16:25 --> Model Class Initialized
INFO - 2020-10-15 17:16:26 --> Model Class Initialized
DEBUG - 2020-10-15 17:16:26 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-15 17:16:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-15 17:16:26 --> Final output sent to browser
DEBUG - 2020-10-15 17:16:26 --> Total execution time: 0.0205
ERROR - 2020-10-15 17:16:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-15 17:16:26 --> Config Class Initialized
INFO - 2020-10-15 17:16:26 --> Hooks Class Initialized
DEBUG - 2020-10-15 17:16:26 --> UTF-8 Support Enabled
INFO - 2020-10-15 17:16:26 --> Utf8 Class Initialized
INFO - 2020-10-15 17:16:26 --> URI Class Initialized
INFO - 2020-10-15 17:16:26 --> Router Class Initialized
INFO - 2020-10-15 17:16:26 --> Output Class Initialized
INFO - 2020-10-15 17:16:26 --> Security Class Initialized
DEBUG - 2020-10-15 17:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 17:16:26 --> Input Class Initialized
INFO - 2020-10-15 17:16:26 --> Language Class Initialized
INFO - 2020-10-15 17:16:26 --> Loader Class Initialized
INFO - 2020-10-15 17:16:26 --> Helper loaded: url_helper
INFO - 2020-10-15 17:16:26 --> Database Driver Class Initialized
INFO - 2020-10-15 17:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 17:16:26 --> Email Class Initialized
INFO - 2020-10-15 17:16:26 --> Controller Class Initialized
DEBUG - 2020-10-15 17:16:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-15 17:16:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-15 17:16:26 --> Model Class Initialized
INFO - 2020-10-15 17:16:26 --> Model Class Initialized
INFO - 2020-10-15 17:16:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-15 17:16:26 --> Final output sent to browser
DEBUG - 2020-10-15 17:16:26 --> Total execution time: 0.0809
ERROR - 2020-10-15 17:16:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-15 17:16:56 --> Config Class Initialized
INFO - 2020-10-15 17:16:56 --> Hooks Class Initialized
DEBUG - 2020-10-15 17:16:56 --> UTF-8 Support Enabled
INFO - 2020-10-15 17:16:56 --> Utf8 Class Initialized
INFO - 2020-10-15 17:16:56 --> URI Class Initialized
INFO - 2020-10-15 17:16:56 --> Router Class Initialized
INFO - 2020-10-15 17:16:56 --> Output Class Initialized
INFO - 2020-10-15 17:16:56 --> Security Class Initialized
DEBUG - 2020-10-15 17:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 17:16:56 --> Input Class Initialized
INFO - 2020-10-15 17:16:56 --> Language Class Initialized
INFO - 2020-10-15 17:16:56 --> Loader Class Initialized
INFO - 2020-10-15 17:16:56 --> Helper loaded: url_helper
INFO - 2020-10-15 17:16:56 --> Database Driver Class Initialized
INFO - 2020-10-15 17:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 17:16:56 --> Email Class Initialized
INFO - 2020-10-15 17:16:56 --> Controller Class Initialized
DEBUG - 2020-10-15 17:16:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-15 17:16:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-15 17:16:56 --> Model Class Initialized
INFO - 2020-10-15 17:16:56 --> Model Class Initialized
INFO - 2020-10-15 17:16:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-15 17:16:56 --> Final output sent to browser
DEBUG - 2020-10-15 17:16:56 --> Total execution time: 0.0274
ERROR - 2020-10-15 17:17:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-15 17:17:18 --> Config Class Initialized
INFO - 2020-10-15 17:17:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 17:17:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 17:17:18 --> Utf8 Class Initialized
INFO - 2020-10-15 17:17:18 --> URI Class Initialized
INFO - 2020-10-15 17:17:18 --> Router Class Initialized
INFO - 2020-10-15 17:17:18 --> Output Class Initialized
INFO - 2020-10-15 17:17:18 --> Security Class Initialized
DEBUG - 2020-10-15 17:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 17:17:18 --> Input Class Initialized
INFO - 2020-10-15 17:17:18 --> Language Class Initialized
INFO - 2020-10-15 17:17:18 --> Loader Class Initialized
INFO - 2020-10-15 17:17:18 --> Helper loaded: url_helper
INFO - 2020-10-15 17:17:18 --> Database Driver Class Initialized
INFO - 2020-10-15 17:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 17:17:18 --> Email Class Initialized
INFO - 2020-10-15 17:17:18 --> Controller Class Initialized
DEBUG - 2020-10-15 17:17:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-15 17:17:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-15 17:17:18 --> Model Class Initialized
INFO - 2020-10-15 17:17:18 --> Model Class Initialized
INFO - 2020-10-15 17:17:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-15 17:17:18 --> Final output sent to browser
DEBUG - 2020-10-15 17:17:18 --> Total execution time: 0.0294
ERROR - 2020-10-15 17:17:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-15 17:17:27 --> Config Class Initialized
INFO - 2020-10-15 17:17:27 --> Hooks Class Initialized
DEBUG - 2020-10-15 17:17:27 --> UTF-8 Support Enabled
INFO - 2020-10-15 17:17:27 --> Utf8 Class Initialized
INFO - 2020-10-15 17:17:27 --> URI Class Initialized
INFO - 2020-10-15 17:17:27 --> Router Class Initialized
INFO - 2020-10-15 17:17:27 --> Output Class Initialized
INFO - 2020-10-15 17:17:27 --> Security Class Initialized
DEBUG - 2020-10-15 17:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 17:17:27 --> Input Class Initialized
INFO - 2020-10-15 17:17:27 --> Language Class Initialized
INFO - 2020-10-15 17:17:27 --> Loader Class Initialized
INFO - 2020-10-15 17:17:27 --> Helper loaded: url_helper
INFO - 2020-10-15 17:17:27 --> Database Driver Class Initialized
INFO - 2020-10-15 17:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 17:17:27 --> Email Class Initialized
INFO - 2020-10-15 17:17:27 --> Controller Class Initialized
DEBUG - 2020-10-15 17:17:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-15 17:17:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-15 17:17:27 --> Model Class Initialized
INFO - 2020-10-15 17:17:27 --> Model Class Initialized
INFO - 2020-10-15 17:17:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-15 17:17:27 --> Final output sent to browser
DEBUG - 2020-10-15 17:17:27 --> Total execution time: 0.0620
ERROR - 2020-10-15 17:17:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-15 17:17:29 --> Config Class Initialized
INFO - 2020-10-15 17:17:29 --> Hooks Class Initialized
DEBUG - 2020-10-15 17:17:29 --> UTF-8 Support Enabled
INFO - 2020-10-15 17:17:29 --> Utf8 Class Initialized
INFO - 2020-10-15 17:17:29 --> URI Class Initialized
INFO - 2020-10-15 17:17:29 --> Router Class Initialized
INFO - 2020-10-15 17:17:29 --> Output Class Initialized
INFO - 2020-10-15 17:17:29 --> Security Class Initialized
DEBUG - 2020-10-15 17:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 17:17:29 --> Input Class Initialized
INFO - 2020-10-15 17:17:29 --> Language Class Initialized
INFO - 2020-10-15 17:17:29 --> Loader Class Initialized
INFO - 2020-10-15 17:17:29 --> Helper loaded: url_helper
INFO - 2020-10-15 17:17:29 --> Database Driver Class Initialized
INFO - 2020-10-15 17:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 17:17:29 --> Email Class Initialized
INFO - 2020-10-15 17:17:29 --> Controller Class Initialized
DEBUG - 2020-10-15 17:17:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-15 17:17:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-15 17:17:29 --> Model Class Initialized
INFO - 2020-10-15 17:17:29 --> Model Class Initialized
INFO - 2020-10-15 17:17:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-10-15 17:17:29 --> Final output sent to browser
DEBUG - 2020-10-15 17:17:29 --> Total execution time: 0.0299
ERROR - 2020-10-15 17:18:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-15 17:18:23 --> Config Class Initialized
INFO - 2020-10-15 17:18:23 --> Hooks Class Initialized
DEBUG - 2020-10-15 17:18:23 --> UTF-8 Support Enabled
INFO - 2020-10-15 17:18:23 --> Utf8 Class Initialized
INFO - 2020-10-15 17:18:23 --> URI Class Initialized
INFO - 2020-10-15 17:18:23 --> Router Class Initialized
INFO - 2020-10-15 17:18:23 --> Output Class Initialized
INFO - 2020-10-15 17:18:23 --> Security Class Initialized
DEBUG - 2020-10-15 17:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 17:18:23 --> Input Class Initialized
INFO - 2020-10-15 17:18:23 --> Language Class Initialized
INFO - 2020-10-15 17:18:23 --> Loader Class Initialized
INFO - 2020-10-15 17:18:23 --> Helper loaded: url_helper
INFO - 2020-10-15 17:18:23 --> Database Driver Class Initialized
INFO - 2020-10-15 17:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 17:18:23 --> Email Class Initialized
INFO - 2020-10-15 17:18:23 --> Controller Class Initialized
DEBUG - 2020-10-15 17:18:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-15 17:18:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-15 17:18:23 --> Model Class Initialized
INFO - 2020-10-15 17:18:23 --> Model Class Initialized
INFO - 2020-10-15 17:18:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-15 17:18:23 --> Final output sent to browser
DEBUG - 2020-10-15 17:18:23 --> Total execution time: 0.0409
ERROR - 2020-10-15 17:18:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-15 17:18:23 --> Config Class Initialized
INFO - 2020-10-15 17:18:23 --> Hooks Class Initialized
DEBUG - 2020-10-15 17:18:23 --> UTF-8 Support Enabled
INFO - 2020-10-15 17:18:23 --> Utf8 Class Initialized
INFO - 2020-10-15 17:18:23 --> URI Class Initialized
INFO - 2020-10-15 17:18:23 --> Router Class Initialized
INFO - 2020-10-15 17:18:23 --> Output Class Initialized
INFO - 2020-10-15 17:18:23 --> Security Class Initialized
DEBUG - 2020-10-15 17:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 17:18:23 --> Input Class Initialized
INFO - 2020-10-15 17:18:23 --> Language Class Initialized
INFO - 2020-10-15 17:18:23 --> Loader Class Initialized
INFO - 2020-10-15 17:18:23 --> Helper loaded: url_helper
INFO - 2020-10-15 17:18:23 --> Database Driver Class Initialized
INFO - 2020-10-15 17:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 17:18:23 --> Email Class Initialized
INFO - 2020-10-15 17:18:23 --> Controller Class Initialized
DEBUG - 2020-10-15 17:18:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-15 17:18:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-15 17:18:23 --> Model Class Initialized
INFO - 2020-10-15 17:18:23 --> Model Class Initialized
INFO - 2020-10-15 17:18:23 --> Final output sent to browser
DEBUG - 2020-10-15 17:18:23 --> Total execution time: 0.0213
ERROR - 2020-10-15 17:18:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-15 17:18:41 --> Config Class Initialized
INFO - 2020-10-15 17:18:41 --> Hooks Class Initialized
DEBUG - 2020-10-15 17:18:41 --> UTF-8 Support Enabled
INFO - 2020-10-15 17:18:41 --> Utf8 Class Initialized
INFO - 2020-10-15 17:18:41 --> URI Class Initialized
INFO - 2020-10-15 17:18:41 --> Router Class Initialized
INFO - 2020-10-15 17:18:41 --> Output Class Initialized
INFO - 2020-10-15 17:18:41 --> Security Class Initialized
DEBUG - 2020-10-15 17:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 17:18:41 --> Input Class Initialized
INFO - 2020-10-15 17:18:41 --> Language Class Initialized
INFO - 2020-10-15 17:18:41 --> Loader Class Initialized
INFO - 2020-10-15 17:18:41 --> Helper loaded: url_helper
INFO - 2020-10-15 17:18:41 --> Database Driver Class Initialized
INFO - 2020-10-15 17:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 17:18:41 --> Email Class Initialized
INFO - 2020-10-15 17:18:41 --> Controller Class Initialized
DEBUG - 2020-10-15 17:18:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-15 17:18:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-15 17:18:41 --> Model Class Initialized
INFO - 2020-10-15 17:18:41 --> Model Class Initialized
INFO - 2020-10-15 17:18:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-15 17:18:41 --> Final output sent to browser
DEBUG - 2020-10-15 17:18:41 --> Total execution time: 0.0293
ERROR - 2020-10-15 17:18:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-15 17:18:42 --> Config Class Initialized
INFO - 2020-10-15 17:18:42 --> Hooks Class Initialized
DEBUG - 2020-10-15 17:18:42 --> UTF-8 Support Enabled
INFO - 2020-10-15 17:18:42 --> Utf8 Class Initialized
INFO - 2020-10-15 17:18:42 --> URI Class Initialized
INFO - 2020-10-15 17:18:42 --> Router Class Initialized
INFO - 2020-10-15 17:18:42 --> Output Class Initialized
INFO - 2020-10-15 17:18:42 --> Security Class Initialized
DEBUG - 2020-10-15 17:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 17:18:42 --> Input Class Initialized
INFO - 2020-10-15 17:18:42 --> Language Class Initialized
INFO - 2020-10-15 17:18:42 --> Loader Class Initialized
INFO - 2020-10-15 17:18:42 --> Helper loaded: url_helper
INFO - 2020-10-15 17:18:42 --> Database Driver Class Initialized
INFO - 2020-10-15 17:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 17:18:42 --> Email Class Initialized
INFO - 2020-10-15 17:18:42 --> Controller Class Initialized
DEBUG - 2020-10-15 17:18:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-15 17:18:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-15 17:18:42 --> Model Class Initialized
INFO - 2020-10-15 17:18:42 --> Model Class Initialized
INFO - 2020-10-15 17:18:42 --> Final output sent to browser
DEBUG - 2020-10-15 17:18:42 --> Total execution time: 0.0232
ERROR - 2020-10-15 17:18:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-15 17:18:55 --> Config Class Initialized
INFO - 2020-10-15 17:18:55 --> Hooks Class Initialized
DEBUG - 2020-10-15 17:18:55 --> UTF-8 Support Enabled
INFO - 2020-10-15 17:18:55 --> Utf8 Class Initialized
INFO - 2020-10-15 17:18:55 --> URI Class Initialized
DEBUG - 2020-10-15 17:18:55 --> No URI present. Default controller set.
INFO - 2020-10-15 17:18:55 --> Router Class Initialized
INFO - 2020-10-15 17:18:55 --> Output Class Initialized
INFO - 2020-10-15 17:18:55 --> Security Class Initialized
DEBUG - 2020-10-15 17:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 17:18:55 --> Input Class Initialized
INFO - 2020-10-15 17:18:55 --> Language Class Initialized
INFO - 2020-10-15 17:18:55 --> Loader Class Initialized
INFO - 2020-10-15 17:18:55 --> Helper loaded: url_helper
INFO - 2020-10-15 17:18:55 --> Database Driver Class Initialized
INFO - 2020-10-15 17:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 17:18:55 --> Email Class Initialized
INFO - 2020-10-15 17:18:55 --> Controller Class Initialized
INFO - 2020-10-15 17:18:55 --> Model Class Initialized
INFO - 2020-10-15 17:18:55 --> Model Class Initialized
DEBUG - 2020-10-15 17:18:55 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-15 17:18:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-15 17:18:55 --> Final output sent to browser
DEBUG - 2020-10-15 17:18:55 --> Total execution time: 0.0204
