<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-01 11:30:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-01 11:30:35 --> Config Class Initialized
INFO - 2020-09-01 11:30:35 --> Hooks Class Initialized
DEBUG - 2020-09-01 11:30:35 --> UTF-8 Support Enabled
INFO - 2020-09-01 11:30:35 --> Utf8 Class Initialized
INFO - 2020-09-01 11:30:35 --> URI Class Initialized
DEBUG - 2020-09-01 11:30:35 --> No URI present. Default controller set.
INFO - 2020-09-01 11:30:35 --> Router Class Initialized
INFO - 2020-09-01 11:30:35 --> Output Class Initialized
INFO - 2020-09-01 11:30:35 --> Security Class Initialized
DEBUG - 2020-09-01 11:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-01 11:30:35 --> Input Class Initialized
INFO - 2020-09-01 11:30:35 --> Language Class Initialized
INFO - 2020-09-01 11:30:35 --> Loader Class Initialized
INFO - 2020-09-01 11:30:35 --> Helper loaded: url_helper
INFO - 2020-09-01 11:30:36 --> Database Driver Class Initialized
INFO - 2020-09-01 11:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-01 11:30:36 --> Email Class Initialized
INFO - 2020-09-01 11:30:36 --> Controller Class Initialized
INFO - 2020-09-01 11:30:36 --> Model Class Initialized
INFO - 2020-09-01 11:30:36 --> Model Class Initialized
DEBUG - 2020-09-01 11:30:36 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-01 11:30:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-01 11:30:36 --> Final output sent to browser
DEBUG - 2020-09-01 11:30:36 --> Total execution time: 0.1329
