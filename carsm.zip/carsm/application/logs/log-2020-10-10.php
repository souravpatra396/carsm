<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-10 07:42:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-10 07:42:38 --> Config Class Initialized
INFO - 2020-10-10 07:42:38 --> Hooks Class Initialized
DEBUG - 2020-10-10 07:42:38 --> UTF-8 Support Enabled
INFO - 2020-10-10 07:42:38 --> Utf8 Class Initialized
INFO - 2020-10-10 07:42:38 --> URI Class Initialized
DEBUG - 2020-10-10 07:42:38 --> No URI present. Default controller set.
INFO - 2020-10-10 07:42:38 --> Router Class Initialized
INFO - 2020-10-10 07:42:38 --> Output Class Initialized
INFO - 2020-10-10 07:42:38 --> Security Class Initialized
DEBUG - 2020-10-10 07:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-10 07:42:38 --> Input Class Initialized
INFO - 2020-10-10 07:42:38 --> Language Class Initialized
INFO - 2020-10-10 07:42:38 --> Loader Class Initialized
INFO - 2020-10-10 07:42:38 --> Helper loaded: url_helper
INFO - 2020-10-10 07:42:38 --> Database Driver Class Initialized
INFO - 2020-10-10 07:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-10 07:42:38 --> Email Class Initialized
INFO - 2020-10-10 07:42:38 --> Controller Class Initialized
INFO - 2020-10-10 07:42:38 --> Model Class Initialized
INFO - 2020-10-10 07:42:38 --> Model Class Initialized
DEBUG - 2020-10-10 07:42:38 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-10 07:42:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-10 07:42:38 --> Final output sent to browser
DEBUG - 2020-10-10 07:42:38 --> Total execution time: 0.1539
ERROR - 2020-10-10 07:42:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-10 07:42:52 --> Config Class Initialized
INFO - 2020-10-10 07:42:52 --> Hooks Class Initialized
DEBUG - 2020-10-10 07:42:52 --> UTF-8 Support Enabled
INFO - 2020-10-10 07:42:52 --> Utf8 Class Initialized
INFO - 2020-10-10 07:42:52 --> URI Class Initialized
INFO - 2020-10-10 07:42:52 --> Router Class Initialized
INFO - 2020-10-10 07:42:52 --> Output Class Initialized
INFO - 2020-10-10 07:42:52 --> Security Class Initialized
DEBUG - 2020-10-10 07:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-10 07:42:52 --> Input Class Initialized
INFO - 2020-10-10 07:42:52 --> Language Class Initialized
ERROR - 2020-10-10 07:42:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-10 07:42:52 --> Config Class Initialized
INFO - 2020-10-10 07:42:52 --> Hooks Class Initialized
INFO - 2020-10-10 07:42:52 --> Loader Class Initialized
DEBUG - 2020-10-10 07:42:52 --> UTF-8 Support Enabled
INFO - 2020-10-10 07:42:52 --> Utf8 Class Initialized
INFO - 2020-10-10 07:42:52 --> Helper loaded: url_helper
INFO - 2020-10-10 07:42:52 --> URI Class Initialized
INFO - 2020-10-10 07:42:52 --> Router Class Initialized
INFO - 2020-10-10 07:42:52 --> Output Class Initialized
INFO - 2020-10-10 07:42:52 --> Security Class Initialized
INFO - 2020-10-10 07:42:52 --> Database Driver Class Initialized
DEBUG - 2020-10-10 07:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-10 07:42:52 --> Input Class Initialized
INFO - 2020-10-10 07:42:52 --> Language Class Initialized
INFO - 2020-10-10 07:42:52 --> Loader Class Initialized
INFO - 2020-10-10 07:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-10 07:42:52 --> Helper loaded: url_helper
INFO - 2020-10-10 07:42:52 --> Email Class Initialized
INFO - 2020-10-10 07:42:52 --> Controller Class Initialized
INFO - 2020-10-10 07:42:52 --> Model Class Initialized
INFO - 2020-10-10 07:42:52 --> Model Class Initialized
DEBUG - 2020-10-10 07:42:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-10 07:42:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-10 07:42:52 --> Database Driver Class Initialized
INFO - 2020-10-10 07:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-10 07:42:52 --> Email Class Initialized
INFO - 2020-10-10 07:42:52 --> Controller Class Initialized
INFO - 2020-10-10 07:42:52 --> Model Class Initialized
INFO - 2020-10-10 07:42:52 --> Model Class Initialized
DEBUG - 2020-10-10 07:42:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-10 07:42:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-10-10 07:42:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-10 07:42:53 --> Config Class Initialized
INFO - 2020-10-10 07:42:53 --> Config Class Initialized
INFO - 2020-10-10 07:42:53 --> Hooks Class Initialized
INFO - 2020-10-10 07:42:53 --> Hooks Class Initialized
DEBUG - 2020-10-10 07:42:53 --> UTF-8 Support Enabled
INFO - 2020-10-10 07:42:53 --> Utf8 Class Initialized
DEBUG - 2020-10-10 07:42:53 --> UTF-8 Support Enabled
INFO - 2020-10-10 07:42:53 --> Utf8 Class Initialized
INFO - 2020-10-10 07:42:53 --> URI Class Initialized
INFO - 2020-10-10 07:42:53 --> URI Class Initialized
INFO - 2020-10-10 07:42:53 --> Router Class Initialized
DEBUG - 2020-10-10 07:42:53 --> No URI present. Default controller set.
INFO - 2020-10-10 07:42:53 --> Router Class Initialized
INFO - 2020-10-10 07:42:53 --> Output Class Initialized
INFO - 2020-10-10 07:42:53 --> Output Class Initialized
INFO - 2020-10-10 07:42:53 --> Security Class Initialized
INFO - 2020-10-10 07:42:53 --> Security Class Initialized
DEBUG - 2020-10-10 07:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-10 07:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-10 07:42:53 --> Input Class Initialized
INFO - 2020-10-10 07:42:53 --> Input Class Initialized
INFO - 2020-10-10 07:42:53 --> Language Class Initialized
INFO - 2020-10-10 07:42:53 --> Language Class Initialized
INFO - 2020-10-10 07:42:53 --> Loader Class Initialized
INFO - 2020-10-10 07:42:53 --> Helper loaded: url_helper
INFO - 2020-10-10 07:42:53 --> Database Driver Class Initialized
INFO - 2020-10-10 07:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-10 07:42:53 --> Email Class Initialized
INFO - 2020-10-10 07:42:53 --> Controller Class Initialized
INFO - 2020-10-10 07:42:53 --> Model Class Initialized
INFO - 2020-10-10 07:42:53 --> Model Class Initialized
DEBUG - 2020-10-10 07:42:53 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-10 07:42:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-10 07:42:53 --> Final output sent to browser
DEBUG - 2020-10-10 07:42:53 --> Total execution time: 0.0219
INFO - 2020-10-10 07:42:53 --> Loader Class Initialized
INFO - 2020-10-10 07:42:53 --> Helper loaded: url_helper
INFO - 2020-10-10 07:42:53 --> Database Driver Class Initialized
INFO - 2020-10-10 07:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-10 07:42:53 --> Email Class Initialized
INFO - 2020-10-10 07:42:53 --> Controller Class Initialized
DEBUG - 2020-10-10 07:42:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-10 07:42:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-10 07:42:53 --> Model Class Initialized
INFO - 2020-10-10 07:42:53 --> Model Class Initialized
INFO - 2020-10-10 07:42:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-10 07:42:53 --> Final output sent to browser
DEBUG - 2020-10-10 07:42:53 --> Total execution time: 0.1058
ERROR - 2020-10-10 07:43:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-10 07:43:24 --> Config Class Initialized
INFO - 2020-10-10 07:43:24 --> Hooks Class Initialized
DEBUG - 2020-10-10 07:43:24 --> UTF-8 Support Enabled
INFO - 2020-10-10 07:43:24 --> Utf8 Class Initialized
INFO - 2020-10-10 07:43:24 --> URI Class Initialized
INFO - 2020-10-10 07:43:24 --> Router Class Initialized
INFO - 2020-10-10 07:43:24 --> Output Class Initialized
INFO - 2020-10-10 07:43:24 --> Security Class Initialized
DEBUG - 2020-10-10 07:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-10 07:43:24 --> Input Class Initialized
INFO - 2020-10-10 07:43:24 --> Language Class Initialized
INFO - 2020-10-10 07:43:24 --> Loader Class Initialized
INFO - 2020-10-10 07:43:24 --> Helper loaded: url_helper
INFO - 2020-10-10 07:43:24 --> Database Driver Class Initialized
INFO - 2020-10-10 07:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-10 07:43:24 --> Email Class Initialized
INFO - 2020-10-10 07:43:24 --> Controller Class Initialized
DEBUG - 2020-10-10 07:43:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-10 07:43:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-10 07:43:24 --> Model Class Initialized
INFO - 2020-10-10 07:43:24 --> Model Class Initialized
INFO - 2020-10-10 07:43:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-10 07:43:24 --> Final output sent to browser
DEBUG - 2020-10-10 07:43:24 --> Total execution time: 0.0435
ERROR - 2020-10-10 07:44:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-10 07:44:23 --> Config Class Initialized
INFO - 2020-10-10 07:44:23 --> Hooks Class Initialized
DEBUG - 2020-10-10 07:44:23 --> UTF-8 Support Enabled
INFO - 2020-10-10 07:44:23 --> Utf8 Class Initialized
INFO - 2020-10-10 07:44:23 --> URI Class Initialized
DEBUG - 2020-10-10 07:44:23 --> No URI present. Default controller set.
INFO - 2020-10-10 07:44:23 --> Router Class Initialized
INFO - 2020-10-10 07:44:23 --> Output Class Initialized
INFO - 2020-10-10 07:44:23 --> Security Class Initialized
DEBUG - 2020-10-10 07:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-10 07:44:23 --> Input Class Initialized
INFO - 2020-10-10 07:44:23 --> Language Class Initialized
INFO - 2020-10-10 07:44:23 --> Loader Class Initialized
INFO - 2020-10-10 07:44:23 --> Helper loaded: url_helper
INFO - 2020-10-10 07:44:23 --> Database Driver Class Initialized
INFO - 2020-10-10 07:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-10 07:44:23 --> Email Class Initialized
INFO - 2020-10-10 07:44:23 --> Controller Class Initialized
INFO - 2020-10-10 07:44:23 --> Model Class Initialized
INFO - 2020-10-10 07:44:23 --> Model Class Initialized
DEBUG - 2020-10-10 07:44:23 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-10 07:44:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-10 07:44:23 --> Final output sent to browser
DEBUG - 2020-10-10 07:44:23 --> Total execution time: 0.0217
ERROR - 2020-10-10 07:44:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-10 07:44:27 --> Config Class Initialized
INFO - 2020-10-10 07:44:27 --> Hooks Class Initialized
DEBUG - 2020-10-10 07:44:27 --> UTF-8 Support Enabled
INFO - 2020-10-10 07:44:27 --> Utf8 Class Initialized
INFO - 2020-10-10 07:44:27 --> URI Class Initialized
INFO - 2020-10-10 07:44:27 --> Router Class Initialized
INFO - 2020-10-10 07:44:27 --> Output Class Initialized
INFO - 2020-10-10 07:44:27 --> Security Class Initialized
DEBUG - 2020-10-10 07:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-10 07:44:27 --> Input Class Initialized
INFO - 2020-10-10 07:44:27 --> Language Class Initialized
INFO - 2020-10-10 07:44:27 --> Loader Class Initialized
INFO - 2020-10-10 07:44:27 --> Helper loaded: url_helper
INFO - 2020-10-10 07:44:27 --> Database Driver Class Initialized
INFO - 2020-10-10 07:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-10 07:44:27 --> Email Class Initialized
INFO - 2020-10-10 07:44:27 --> Controller Class Initialized
INFO - 2020-10-10 07:44:27 --> Model Class Initialized
INFO - 2020-10-10 07:44:27 --> Model Class Initialized
DEBUG - 2020-10-10 07:44:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-10 07:44:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-10 07:44:27 --> Model Class Initialized
INFO - 2020-10-10 07:44:27 --> Final output sent to browser
DEBUG - 2020-10-10 07:44:27 --> Total execution time: 0.0242
ERROR - 2020-10-10 07:44:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-10 07:44:27 --> Config Class Initialized
INFO - 2020-10-10 07:44:27 --> Hooks Class Initialized
DEBUG - 2020-10-10 07:44:27 --> UTF-8 Support Enabled
INFO - 2020-10-10 07:44:27 --> Utf8 Class Initialized
INFO - 2020-10-10 07:44:27 --> URI Class Initialized
INFO - 2020-10-10 07:44:27 --> Router Class Initialized
INFO - 2020-10-10 07:44:27 --> Output Class Initialized
INFO - 2020-10-10 07:44:27 --> Security Class Initialized
DEBUG - 2020-10-10 07:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-10 07:44:27 --> Input Class Initialized
INFO - 2020-10-10 07:44:27 --> Language Class Initialized
INFO - 2020-10-10 07:44:27 --> Loader Class Initialized
INFO - 2020-10-10 07:44:27 --> Helper loaded: url_helper
INFO - 2020-10-10 07:44:27 --> Database Driver Class Initialized
INFO - 2020-10-10 07:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-10 07:44:27 --> Email Class Initialized
INFO - 2020-10-10 07:44:27 --> Controller Class Initialized
INFO - 2020-10-10 07:44:27 --> Model Class Initialized
INFO - 2020-10-10 07:44:27 --> Model Class Initialized
DEBUG - 2020-10-10 07:44:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-10 07:44:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-10 07:44:28 --> Config Class Initialized
INFO - 2020-10-10 07:44:28 --> Hooks Class Initialized
DEBUG - 2020-10-10 07:44:28 --> UTF-8 Support Enabled
INFO - 2020-10-10 07:44:28 --> Utf8 Class Initialized
INFO - 2020-10-10 07:44:28 --> URI Class Initialized
INFO - 2020-10-10 07:44:28 --> Router Class Initialized
INFO - 2020-10-10 07:44:28 --> Output Class Initialized
INFO - 2020-10-10 07:44:28 --> Security Class Initialized
DEBUG - 2020-10-10 07:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-10 07:44:28 --> Input Class Initialized
INFO - 2020-10-10 07:44:28 --> Language Class Initialized
INFO - 2020-10-10 07:44:28 --> Loader Class Initialized
INFO - 2020-10-10 07:44:28 --> Helper loaded: url_helper
INFO - 2020-10-10 07:44:28 --> Database Driver Class Initialized
INFO - 2020-10-10 07:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-10 07:44:28 --> Email Class Initialized
INFO - 2020-10-10 07:44:28 --> Controller Class Initialized
DEBUG - 2020-10-10 07:44:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-10 07:44:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-10 07:44:28 --> Model Class Initialized
INFO - 2020-10-10 07:44:28 --> Model Class Initialized
INFO - 2020-10-10 07:44:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-10 07:44:28 --> Final output sent to browser
DEBUG - 2020-10-10 07:44:28 --> Total execution time: 0.0497
ERROR - 2020-10-10 07:44:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-10 07:44:33 --> Config Class Initialized
INFO - 2020-10-10 07:44:33 --> Hooks Class Initialized
DEBUG - 2020-10-10 07:44:33 --> UTF-8 Support Enabled
INFO - 2020-10-10 07:44:33 --> Utf8 Class Initialized
INFO - 2020-10-10 07:44:33 --> URI Class Initialized
INFO - 2020-10-10 07:44:33 --> Router Class Initialized
INFO - 2020-10-10 07:44:33 --> Output Class Initialized
INFO - 2020-10-10 07:44:33 --> Security Class Initialized
DEBUG - 2020-10-10 07:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-10 07:44:33 --> Input Class Initialized
INFO - 2020-10-10 07:44:33 --> Language Class Initialized
INFO - 2020-10-10 07:44:33 --> Loader Class Initialized
INFO - 2020-10-10 07:44:33 --> Helper loaded: url_helper
INFO - 2020-10-10 07:44:33 --> Database Driver Class Initialized
INFO - 2020-10-10 07:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-10 07:44:33 --> Email Class Initialized
INFO - 2020-10-10 07:44:33 --> Controller Class Initialized
DEBUG - 2020-10-10 07:44:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-10 07:44:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-10 07:44:33 --> Model Class Initialized
INFO - 2020-10-10 07:44:33 --> Model Class Initialized
INFO - 2020-10-10 07:44:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-10 07:44:33 --> Final output sent to browser
DEBUG - 2020-10-10 07:44:33 --> Total execution time: 0.0420
