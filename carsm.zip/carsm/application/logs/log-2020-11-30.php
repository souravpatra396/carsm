<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-30 10:03:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 10:03:36 --> Config Class Initialized
INFO - 2020-11-30 10:03:36 --> Hooks Class Initialized
DEBUG - 2020-11-30 10:03:36 --> UTF-8 Support Enabled
INFO - 2020-11-30 10:03:36 --> Utf8 Class Initialized
INFO - 2020-11-30 10:03:36 --> URI Class Initialized
DEBUG - 2020-11-30 10:03:36 --> No URI present. Default controller set.
INFO - 2020-11-30 10:03:36 --> Router Class Initialized
INFO - 2020-11-30 10:03:36 --> Output Class Initialized
INFO - 2020-11-30 10:03:36 --> Security Class Initialized
DEBUG - 2020-11-30 10:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 10:03:36 --> Input Class Initialized
INFO - 2020-11-30 10:03:36 --> Language Class Initialized
INFO - 2020-11-30 10:03:36 --> Loader Class Initialized
INFO - 2020-11-30 10:03:36 --> Helper loaded: url_helper
INFO - 2020-11-30 10:03:36 --> Database Driver Class Initialized
INFO - 2020-11-30 10:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 10:03:36 --> Email Class Initialized
INFO - 2020-11-30 10:03:36 --> Controller Class Initialized
INFO - 2020-11-30 10:03:36 --> Model Class Initialized
INFO - 2020-11-30 10:03:36 --> Model Class Initialized
DEBUG - 2020-11-30 10:03:36 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-30 10:03:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-30 10:03:36 --> Final output sent to browser
DEBUG - 2020-11-30 10:03:36 --> Total execution time: 0.2128
ERROR - 2020-11-30 10:03:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 10:03:43 --> Config Class Initialized
INFO - 2020-11-30 10:03:43 --> Hooks Class Initialized
DEBUG - 2020-11-30 10:03:43 --> UTF-8 Support Enabled
INFO - 2020-11-30 10:03:43 --> Utf8 Class Initialized
INFO - 2020-11-30 10:03:43 --> URI Class Initialized
INFO - 2020-11-30 10:03:43 --> Router Class Initialized
INFO - 2020-11-30 10:03:43 --> Output Class Initialized
INFO - 2020-11-30 10:03:43 --> Security Class Initialized
DEBUG - 2020-11-30 10:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 10:03:43 --> Input Class Initialized
INFO - 2020-11-30 10:03:43 --> Language Class Initialized
INFO - 2020-11-30 10:03:43 --> Loader Class Initialized
INFO - 2020-11-30 10:03:43 --> Helper loaded: url_helper
INFO - 2020-11-30 10:03:43 --> Database Driver Class Initialized
INFO - 2020-11-30 10:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 10:03:43 --> Email Class Initialized
INFO - 2020-11-30 10:03:43 --> Controller Class Initialized
INFO - 2020-11-30 10:03:43 --> Model Class Initialized
INFO - 2020-11-30 10:03:43 --> Model Class Initialized
DEBUG - 2020-11-30 10:03:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-30 10:03:43 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-30 10:03:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 10:03:43 --> Config Class Initialized
INFO - 2020-11-30 10:03:43 --> Hooks Class Initialized
DEBUG - 2020-11-30 10:03:43 --> UTF-8 Support Enabled
INFO - 2020-11-30 10:03:43 --> Utf8 Class Initialized
INFO - 2020-11-30 10:03:43 --> URI Class Initialized
INFO - 2020-11-30 10:03:43 --> Router Class Initialized
INFO - 2020-11-30 10:03:43 --> Output Class Initialized
INFO - 2020-11-30 10:03:43 --> Security Class Initialized
DEBUG - 2020-11-30 10:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 10:03:43 --> Input Class Initialized
INFO - 2020-11-30 10:03:43 --> Language Class Initialized
INFO - 2020-11-30 10:03:43 --> Loader Class Initialized
INFO - 2020-11-30 10:03:43 --> Helper loaded: url_helper
INFO - 2020-11-30 10:03:43 --> Database Driver Class Initialized
INFO - 2020-11-30 10:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 10:03:43 --> Email Class Initialized
INFO - 2020-11-30 10:03:43 --> Controller Class Initialized
INFO - 2020-11-30 10:03:43 --> Model Class Initialized
INFO - 2020-11-30 10:03:43 --> Model Class Initialized
DEBUG - 2020-11-30 10:03:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-11-30 10:03:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 10:03:43 --> Config Class Initialized
INFO - 2020-11-30 10:03:43 --> Hooks Class Initialized
DEBUG - 2020-11-30 10:03:43 --> UTF-8 Support Enabled
INFO - 2020-11-30 10:03:43 --> Utf8 Class Initialized
INFO - 2020-11-30 10:03:43 --> URI Class Initialized
DEBUG - 2020-11-30 10:03:43 --> No URI present. Default controller set.
INFO - 2020-11-30 10:03:43 --> Router Class Initialized
INFO - 2020-11-30 10:03:43 --> Output Class Initialized
INFO - 2020-11-30 10:03:43 --> Security Class Initialized
DEBUG - 2020-11-30 10:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 10:03:43 --> Input Class Initialized
INFO - 2020-11-30 10:03:43 --> Language Class Initialized
INFO - 2020-11-30 10:03:43 --> Loader Class Initialized
INFO - 2020-11-30 10:03:43 --> Helper loaded: url_helper
INFO - 2020-11-30 10:03:43 --> Database Driver Class Initialized
INFO - 2020-11-30 10:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 10:03:43 --> Email Class Initialized
INFO - 2020-11-30 10:03:43 --> Controller Class Initialized
INFO - 2020-11-30 10:03:43 --> Model Class Initialized
INFO - 2020-11-30 10:03:43 --> Model Class Initialized
DEBUG - 2020-11-30 10:03:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-30 10:03:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-30 10:03:43 --> Final output sent to browser
DEBUG - 2020-11-30 10:03:43 --> Total execution time: 0.0216
ERROR - 2020-11-30 10:03:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 10:03:44 --> Config Class Initialized
INFO - 2020-11-30 10:03:44 --> Hooks Class Initialized
DEBUG - 2020-11-30 10:03:44 --> UTF-8 Support Enabled
INFO - 2020-11-30 10:03:44 --> Utf8 Class Initialized
INFO - 2020-11-30 10:03:44 --> URI Class Initialized
INFO - 2020-11-30 10:03:44 --> Router Class Initialized
INFO - 2020-11-30 10:03:44 --> Output Class Initialized
INFO - 2020-11-30 10:03:44 --> Security Class Initialized
DEBUG - 2020-11-30 10:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 10:03:44 --> Input Class Initialized
INFO - 2020-11-30 10:03:44 --> Language Class Initialized
INFO - 2020-11-30 10:03:44 --> Loader Class Initialized
INFO - 2020-11-30 10:03:44 --> Helper loaded: url_helper
INFO - 2020-11-30 10:03:44 --> Database Driver Class Initialized
INFO - 2020-11-30 10:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 10:03:44 --> Email Class Initialized
INFO - 2020-11-30 10:03:44 --> Controller Class Initialized
DEBUG - 2020-11-30 10:03:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-30 10:03:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-30 10:03:44 --> Model Class Initialized
INFO - 2020-11-30 10:03:44 --> Model Class Initialized
INFO - 2020-11-30 10:03:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-11-30 10:03:44 --> Final output sent to browser
DEBUG - 2020-11-30 10:03:44 --> Total execution time: 0.0792
ERROR - 2020-11-30 10:03:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 10:03:52 --> Config Class Initialized
INFO - 2020-11-30 10:03:52 --> Hooks Class Initialized
DEBUG - 2020-11-30 10:03:52 --> UTF-8 Support Enabled
INFO - 2020-11-30 10:03:52 --> Utf8 Class Initialized
INFO - 2020-11-30 10:03:52 --> URI Class Initialized
INFO - 2020-11-30 10:03:52 --> Router Class Initialized
INFO - 2020-11-30 10:03:52 --> Output Class Initialized
INFO - 2020-11-30 10:03:52 --> Security Class Initialized
DEBUG - 2020-11-30 10:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 10:03:52 --> Input Class Initialized
INFO - 2020-11-30 10:03:52 --> Language Class Initialized
INFO - 2020-11-30 10:03:52 --> Loader Class Initialized
INFO - 2020-11-30 10:03:52 --> Helper loaded: url_helper
INFO - 2020-11-30 10:03:52 --> Database Driver Class Initialized
INFO - 2020-11-30 10:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 10:03:52 --> Email Class Initialized
INFO - 2020-11-30 10:03:52 --> Controller Class Initialized
DEBUG - 2020-11-30 10:03:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-30 10:03:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-30 10:03:52 --> Model Class Initialized
INFO - 2020-11-30 10:03:52 --> Model Class Initialized
INFO - 2020-11-30 10:03:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-11-30 10:03:52 --> Final output sent to browser
DEBUG - 2020-11-30 10:03:52 --> Total execution time: 0.0654
ERROR - 2020-11-30 10:03:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 10:03:55 --> Config Class Initialized
INFO - 2020-11-30 10:03:55 --> Hooks Class Initialized
DEBUG - 2020-11-30 10:03:55 --> UTF-8 Support Enabled
INFO - 2020-11-30 10:03:55 --> Utf8 Class Initialized
INFO - 2020-11-30 10:03:55 --> URI Class Initialized
INFO - 2020-11-30 10:03:55 --> Router Class Initialized
INFO - 2020-11-30 10:03:55 --> Output Class Initialized
INFO - 2020-11-30 10:03:55 --> Security Class Initialized
DEBUG - 2020-11-30 10:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 10:03:55 --> Input Class Initialized
INFO - 2020-11-30 10:03:55 --> Language Class Initialized
INFO - 2020-11-30 10:03:55 --> Loader Class Initialized
INFO - 2020-11-30 10:03:55 --> Helper loaded: url_helper
INFO - 2020-11-30 10:03:55 --> Database Driver Class Initialized
INFO - 2020-11-30 10:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 10:03:55 --> Email Class Initialized
INFO - 2020-11-30 10:03:55 --> Controller Class Initialized
DEBUG - 2020-11-30 10:03:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-30 10:03:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-30 10:03:55 --> Model Class Initialized
INFO - 2020-11-30 10:03:55 --> Model Class Initialized
INFO - 2020-11-30 10:03:55 --> Final output sent to browser
DEBUG - 2020-11-30 10:03:55 --> Total execution time: 0.0245
ERROR - 2020-11-30 10:04:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 10:04:46 --> Config Class Initialized
INFO - 2020-11-30 10:04:46 --> Hooks Class Initialized
DEBUG - 2020-11-30 10:04:46 --> UTF-8 Support Enabled
INFO - 2020-11-30 10:04:46 --> Utf8 Class Initialized
INFO - 2020-11-30 10:04:46 --> URI Class Initialized
INFO - 2020-11-30 10:04:46 --> Router Class Initialized
INFO - 2020-11-30 10:04:46 --> Output Class Initialized
INFO - 2020-11-30 10:04:46 --> Security Class Initialized
DEBUG - 2020-11-30 10:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 10:04:46 --> Input Class Initialized
INFO - 2020-11-30 10:04:46 --> Language Class Initialized
INFO - 2020-11-30 10:04:46 --> Loader Class Initialized
INFO - 2020-11-30 10:04:46 --> Helper loaded: url_helper
INFO - 2020-11-30 10:04:46 --> Database Driver Class Initialized
INFO - 2020-11-30 10:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 10:04:46 --> Email Class Initialized
INFO - 2020-11-30 10:04:46 --> Controller Class Initialized
DEBUG - 2020-11-30 10:04:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-30 10:04:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-30 10:04:46 --> Model Class Initialized
INFO - 2020-11-30 10:04:46 --> Model Class Initialized
INFO - 2020-11-30 10:04:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-11-30 10:04:46 --> Final output sent to browser
DEBUG - 2020-11-30 10:04:46 --> Total execution time: 0.0289
ERROR - 2020-11-30 10:04:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 10:04:47 --> Config Class Initialized
INFO - 2020-11-30 10:04:47 --> Hooks Class Initialized
DEBUG - 2020-11-30 10:04:47 --> UTF-8 Support Enabled
INFO - 2020-11-30 10:04:47 --> Utf8 Class Initialized
INFO - 2020-11-30 10:04:47 --> URI Class Initialized
INFO - 2020-11-30 10:04:47 --> Router Class Initialized
INFO - 2020-11-30 10:04:47 --> Output Class Initialized
INFO - 2020-11-30 10:04:47 --> Security Class Initialized
DEBUG - 2020-11-30 10:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 10:04:47 --> Input Class Initialized
INFO - 2020-11-30 10:04:47 --> Language Class Initialized
INFO - 2020-11-30 10:04:47 --> Loader Class Initialized
INFO - 2020-11-30 10:04:47 --> Helper loaded: url_helper
INFO - 2020-11-30 10:04:47 --> Database Driver Class Initialized
INFO - 2020-11-30 10:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 10:04:47 --> Email Class Initialized
INFO - 2020-11-30 10:04:47 --> Controller Class Initialized
DEBUG - 2020-11-30 10:04:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-30 10:04:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-30 10:04:47 --> Model Class Initialized
INFO - 2020-11-30 10:04:47 --> Model Class Initialized
INFO - 2020-11-30 10:04:47 --> Final output sent to browser
DEBUG - 2020-11-30 10:04:47 --> Total execution time: 0.0230
ERROR - 2020-11-30 10:05:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 10:05:56 --> Config Class Initialized
INFO - 2020-11-30 10:05:56 --> Hooks Class Initialized
DEBUG - 2020-11-30 10:05:56 --> UTF-8 Support Enabled
INFO - 2020-11-30 10:05:56 --> Utf8 Class Initialized
INFO - 2020-11-30 10:05:56 --> URI Class Initialized
INFO - 2020-11-30 10:05:56 --> Router Class Initialized
INFO - 2020-11-30 10:05:56 --> Output Class Initialized
INFO - 2020-11-30 10:05:56 --> Security Class Initialized
DEBUG - 2020-11-30 10:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 10:05:57 --> Input Class Initialized
INFO - 2020-11-30 10:05:57 --> Language Class Initialized
INFO - 2020-11-30 10:05:57 --> Loader Class Initialized
INFO - 2020-11-30 10:05:57 --> Helper loaded: url_helper
INFO - 2020-11-30 10:05:57 --> Database Driver Class Initialized
INFO - 2020-11-30 10:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 10:05:57 --> Email Class Initialized
INFO - 2020-11-30 10:05:57 --> Controller Class Initialized
DEBUG - 2020-11-30 10:05:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-30 10:05:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-30 10:05:57 --> Model Class Initialized
INFO - 2020-11-30 10:05:57 --> Model Class Initialized
INFO - 2020-11-30 10:05:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-11-30 10:05:57 --> Final output sent to browser
DEBUG - 2020-11-30 10:05:57 --> Total execution time: 0.0257
ERROR - 2020-11-30 10:05:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 10:05:57 --> Config Class Initialized
INFO - 2020-11-30 10:05:57 --> Hooks Class Initialized
DEBUG - 2020-11-30 10:05:57 --> UTF-8 Support Enabled
INFO - 2020-11-30 10:05:57 --> Utf8 Class Initialized
INFO - 2020-11-30 10:05:57 --> URI Class Initialized
INFO - 2020-11-30 10:05:57 --> Router Class Initialized
INFO - 2020-11-30 10:05:57 --> Output Class Initialized
INFO - 2020-11-30 10:05:57 --> Security Class Initialized
DEBUG - 2020-11-30 10:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 10:05:57 --> Input Class Initialized
INFO - 2020-11-30 10:05:57 --> Language Class Initialized
INFO - 2020-11-30 10:05:57 --> Loader Class Initialized
INFO - 2020-11-30 10:05:57 --> Helper loaded: url_helper
INFO - 2020-11-30 10:05:57 --> Database Driver Class Initialized
INFO - 2020-11-30 10:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 10:05:57 --> Email Class Initialized
INFO - 2020-11-30 10:05:57 --> Controller Class Initialized
DEBUG - 2020-11-30 10:05:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-30 10:05:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-30 10:05:57 --> Model Class Initialized
INFO - 2020-11-30 10:05:57 --> Model Class Initialized
INFO - 2020-11-30 10:05:57 --> Final output sent to browser
DEBUG - 2020-11-30 10:05:57 --> Total execution time: 0.0240
ERROR - 2020-11-30 10:06:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 10:06:27 --> Config Class Initialized
INFO - 2020-11-30 10:06:27 --> Hooks Class Initialized
DEBUG - 2020-11-30 10:06:27 --> UTF-8 Support Enabled
INFO - 2020-11-30 10:06:27 --> Utf8 Class Initialized
INFO - 2020-11-30 10:06:27 --> URI Class Initialized
INFO - 2020-11-30 10:06:28 --> Router Class Initialized
INFO - 2020-11-30 10:06:28 --> Output Class Initialized
INFO - 2020-11-30 10:06:28 --> Security Class Initialized
DEBUG - 2020-11-30 10:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 10:06:28 --> Input Class Initialized
INFO - 2020-11-30 10:06:28 --> Language Class Initialized
INFO - 2020-11-30 10:06:28 --> Loader Class Initialized
INFO - 2020-11-30 10:06:28 --> Helper loaded: url_helper
INFO - 2020-11-30 10:06:28 --> Database Driver Class Initialized
INFO - 2020-11-30 10:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 10:06:28 --> Email Class Initialized
INFO - 2020-11-30 10:06:28 --> Controller Class Initialized
DEBUG - 2020-11-30 10:06:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-30 10:06:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-30 10:06:28 --> Model Class Initialized
INFO - 2020-11-30 10:06:28 --> Model Class Initialized
INFO - 2020-11-30 10:06:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-11-30 10:06:28 --> Final output sent to browser
DEBUG - 2020-11-30 10:06:28 --> Total execution time: 0.0402
ERROR - 2020-11-30 10:06:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 10:06:29 --> Config Class Initialized
INFO - 2020-11-30 10:06:29 --> Hooks Class Initialized
DEBUG - 2020-11-30 10:06:29 --> UTF-8 Support Enabled
INFO - 2020-11-30 10:06:29 --> Utf8 Class Initialized
INFO - 2020-11-30 10:06:29 --> URI Class Initialized
INFO - 2020-11-30 10:06:29 --> Router Class Initialized
INFO - 2020-11-30 10:06:29 --> Output Class Initialized
INFO - 2020-11-30 10:06:29 --> Security Class Initialized
DEBUG - 2020-11-30 10:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 10:06:29 --> Input Class Initialized
INFO - 2020-11-30 10:06:29 --> Language Class Initialized
INFO - 2020-11-30 10:06:29 --> Loader Class Initialized
INFO - 2020-11-30 10:06:29 --> Helper loaded: url_helper
INFO - 2020-11-30 10:06:29 --> Database Driver Class Initialized
INFO - 2020-11-30 10:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 10:06:29 --> Email Class Initialized
INFO - 2020-11-30 10:06:29 --> Controller Class Initialized
DEBUG - 2020-11-30 10:06:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-30 10:06:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-30 10:06:29 --> Model Class Initialized
INFO - 2020-11-30 10:06:29 --> Model Class Initialized
INFO - 2020-11-30 10:06:29 --> Final output sent to browser
DEBUG - 2020-11-30 10:06:29 --> Total execution time: 0.0226
ERROR - 2020-11-30 10:06:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 10:06:31 --> Config Class Initialized
INFO - 2020-11-30 10:06:31 --> Hooks Class Initialized
DEBUG - 2020-11-30 10:06:31 --> UTF-8 Support Enabled
INFO - 2020-11-30 10:06:31 --> Utf8 Class Initialized
INFO - 2020-11-30 10:06:31 --> URI Class Initialized
INFO - 2020-11-30 10:06:31 --> Router Class Initialized
INFO - 2020-11-30 10:06:31 --> Output Class Initialized
INFO - 2020-11-30 10:06:31 --> Security Class Initialized
DEBUG - 2020-11-30 10:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 10:06:31 --> Input Class Initialized
INFO - 2020-11-30 10:06:31 --> Language Class Initialized
INFO - 2020-11-30 10:06:31 --> Loader Class Initialized
INFO - 2020-11-30 10:06:31 --> Helper loaded: url_helper
INFO - 2020-11-30 10:06:31 --> Database Driver Class Initialized
INFO - 2020-11-30 10:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 10:06:31 --> Email Class Initialized
INFO - 2020-11-30 10:06:31 --> Controller Class Initialized
DEBUG - 2020-11-30 10:06:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-30 10:06:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-30 10:06:31 --> Model Class Initialized
INFO - 2020-11-30 10:06:31 --> Model Class Initialized
INFO - 2020-11-30 10:06:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-11-30 10:06:31 --> Final output sent to browser
DEBUG - 2020-11-30 10:06:31 --> Total execution time: 0.0355
ERROR - 2020-11-30 10:06:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 10:06:35 --> Config Class Initialized
INFO - 2020-11-30 10:06:35 --> Hooks Class Initialized
DEBUG - 2020-11-30 10:06:35 --> UTF-8 Support Enabled
INFO - 2020-11-30 10:06:35 --> Utf8 Class Initialized
INFO - 2020-11-30 10:06:35 --> URI Class Initialized
INFO - 2020-11-30 10:06:35 --> Router Class Initialized
INFO - 2020-11-30 10:06:35 --> Output Class Initialized
INFO - 2020-11-30 10:06:35 --> Security Class Initialized
DEBUG - 2020-11-30 10:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 10:06:35 --> Input Class Initialized
INFO - 2020-11-30 10:06:35 --> Language Class Initialized
INFO - 2020-11-30 10:06:35 --> Loader Class Initialized
INFO - 2020-11-30 10:06:35 --> Helper loaded: url_helper
INFO - 2020-11-30 10:06:35 --> Database Driver Class Initialized
INFO - 2020-11-30 10:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 10:06:35 --> Email Class Initialized
INFO - 2020-11-30 10:06:35 --> Controller Class Initialized
DEBUG - 2020-11-30 10:06:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-30 10:06:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-30 10:06:35 --> Model Class Initialized
INFO - 2020-11-30 10:06:35 --> Model Class Initialized
INFO - 2020-11-30 10:06:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-11-30 10:06:35 --> Final output sent to browser
DEBUG - 2020-11-30 10:06:35 --> Total execution time: 0.0437
ERROR - 2020-11-30 10:06:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 10:06:40 --> Config Class Initialized
INFO - 2020-11-30 10:06:40 --> Hooks Class Initialized
DEBUG - 2020-11-30 10:06:40 --> UTF-8 Support Enabled
INFO - 2020-11-30 10:06:40 --> Utf8 Class Initialized
INFO - 2020-11-30 10:06:40 --> URI Class Initialized
DEBUG - 2020-11-30 10:06:40 --> No URI present. Default controller set.
INFO - 2020-11-30 10:06:40 --> Router Class Initialized
INFO - 2020-11-30 10:06:40 --> Output Class Initialized
INFO - 2020-11-30 10:06:40 --> Security Class Initialized
DEBUG - 2020-11-30 10:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 10:06:40 --> Input Class Initialized
INFO - 2020-11-30 10:06:40 --> Language Class Initialized
INFO - 2020-11-30 10:06:40 --> Loader Class Initialized
INFO - 2020-11-30 10:06:40 --> Helper loaded: url_helper
INFO - 2020-11-30 10:06:40 --> Database Driver Class Initialized
INFO - 2020-11-30 10:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 10:06:40 --> Email Class Initialized
INFO - 2020-11-30 10:06:40 --> Controller Class Initialized
INFO - 2020-11-30 10:06:40 --> Model Class Initialized
INFO - 2020-11-30 10:06:40 --> Model Class Initialized
DEBUG - 2020-11-30 10:06:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-30 10:06:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-30 10:06:40 --> Final output sent to browser
DEBUG - 2020-11-30 10:06:40 --> Total execution time: 0.0240
ERROR - 2020-11-30 10:11:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 10:11:21 --> Config Class Initialized
INFO - 2020-11-30 10:11:21 --> Hooks Class Initialized
DEBUG - 2020-11-30 10:11:21 --> UTF-8 Support Enabled
INFO - 2020-11-30 10:11:21 --> Utf8 Class Initialized
INFO - 2020-11-30 10:11:21 --> URI Class Initialized
DEBUG - 2020-11-30 10:11:21 --> No URI present. Default controller set.
INFO - 2020-11-30 10:11:21 --> Router Class Initialized
INFO - 2020-11-30 10:11:21 --> Output Class Initialized
INFO - 2020-11-30 10:11:21 --> Security Class Initialized
DEBUG - 2020-11-30 10:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 10:11:21 --> Input Class Initialized
INFO - 2020-11-30 10:11:21 --> Language Class Initialized
INFO - 2020-11-30 10:11:21 --> Loader Class Initialized
INFO - 2020-11-30 10:11:21 --> Helper loaded: url_helper
INFO - 2020-11-30 10:11:21 --> Database Driver Class Initialized
INFO - 2020-11-30 10:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 10:11:21 --> Email Class Initialized
INFO - 2020-11-30 10:11:21 --> Controller Class Initialized
INFO - 2020-11-30 10:11:21 --> Model Class Initialized
INFO - 2020-11-30 10:11:21 --> Model Class Initialized
DEBUG - 2020-11-30 10:11:21 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-30 10:11:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-30 10:11:21 --> Final output sent to browser
DEBUG - 2020-11-30 10:11:21 --> Total execution time: 0.0238
ERROR - 2020-11-30 11:21:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 11:21:44 --> Config Class Initialized
INFO - 2020-11-30 11:21:44 --> Hooks Class Initialized
DEBUG - 2020-11-30 11:21:44 --> UTF-8 Support Enabled
INFO - 2020-11-30 11:21:44 --> Utf8 Class Initialized
INFO - 2020-11-30 11:21:44 --> URI Class Initialized
DEBUG - 2020-11-30 11:21:44 --> No URI present. Default controller set.
INFO - 2020-11-30 11:21:44 --> Router Class Initialized
INFO - 2020-11-30 11:21:44 --> Output Class Initialized
INFO - 2020-11-30 11:21:44 --> Security Class Initialized
DEBUG - 2020-11-30 11:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 11:21:44 --> Input Class Initialized
INFO - 2020-11-30 11:21:44 --> Language Class Initialized
INFO - 2020-11-30 11:21:44 --> Loader Class Initialized
INFO - 2020-11-30 11:21:44 --> Helper loaded: url_helper
INFO - 2020-11-30 11:21:44 --> Database Driver Class Initialized
INFO - 2020-11-30 11:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 11:21:44 --> Email Class Initialized
INFO - 2020-11-30 11:21:44 --> Controller Class Initialized
INFO - 2020-11-30 11:21:44 --> Model Class Initialized
INFO - 2020-11-30 11:21:44 --> Model Class Initialized
DEBUG - 2020-11-30 11:21:44 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-30 11:21:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-30 11:21:44 --> Final output sent to browser
DEBUG - 2020-11-30 11:21:44 --> Total execution time: 0.0180
ERROR - 2020-11-30 11:21:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 11:21:47 --> Config Class Initialized
INFO - 2020-11-30 11:21:47 --> Hooks Class Initialized
DEBUG - 2020-11-30 11:21:47 --> UTF-8 Support Enabled
INFO - 2020-11-30 11:21:47 --> Utf8 Class Initialized
INFO - 2020-11-30 11:21:47 --> URI Class Initialized
INFO - 2020-11-30 11:21:47 --> Router Class Initialized
INFO - 2020-11-30 11:21:47 --> Output Class Initialized
INFO - 2020-11-30 11:21:47 --> Security Class Initialized
DEBUG - 2020-11-30 11:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 11:21:47 --> Input Class Initialized
INFO - 2020-11-30 11:21:47 --> Language Class Initialized
INFO - 2020-11-30 11:21:47 --> Loader Class Initialized
INFO - 2020-11-30 11:21:47 --> Helper loaded: url_helper
INFO - 2020-11-30 11:21:47 --> Database Driver Class Initialized
INFO - 2020-11-30 11:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 11:21:47 --> Email Class Initialized
INFO - 2020-11-30 11:21:47 --> Controller Class Initialized
INFO - 2020-11-30 11:21:47 --> Model Class Initialized
INFO - 2020-11-30 11:21:47 --> Model Class Initialized
DEBUG - 2020-11-30 11:21:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-30 11:21:47 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-30 11:21:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 11:21:47 --> Config Class Initialized
INFO - 2020-11-30 11:21:47 --> Hooks Class Initialized
DEBUG - 2020-11-30 11:21:47 --> UTF-8 Support Enabled
INFO - 2020-11-30 11:21:47 --> Utf8 Class Initialized
INFO - 2020-11-30 11:21:47 --> URI Class Initialized
INFO - 2020-11-30 11:21:47 --> Router Class Initialized
INFO - 2020-11-30 11:21:47 --> Output Class Initialized
INFO - 2020-11-30 11:21:47 --> Security Class Initialized
DEBUG - 2020-11-30 11:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 11:21:47 --> Input Class Initialized
INFO - 2020-11-30 11:21:47 --> Language Class Initialized
INFO - 2020-11-30 11:21:47 --> Loader Class Initialized
INFO - 2020-11-30 11:21:47 --> Helper loaded: url_helper
INFO - 2020-11-30 11:21:47 --> Database Driver Class Initialized
INFO - 2020-11-30 11:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 11:21:47 --> Email Class Initialized
INFO - 2020-11-30 11:21:47 --> Controller Class Initialized
INFO - 2020-11-30 11:21:47 --> Model Class Initialized
INFO - 2020-11-30 11:21:47 --> Model Class Initialized
DEBUG - 2020-11-30 11:21:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-11-30 11:21:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 11:21:47 --> Config Class Initialized
INFO - 2020-11-30 11:21:47 --> Hooks Class Initialized
DEBUG - 2020-11-30 11:21:47 --> UTF-8 Support Enabled
INFO - 2020-11-30 11:21:47 --> Utf8 Class Initialized
INFO - 2020-11-30 11:21:47 --> URI Class Initialized
DEBUG - 2020-11-30 11:21:47 --> No URI present. Default controller set.
INFO - 2020-11-30 11:21:47 --> Router Class Initialized
INFO - 2020-11-30 11:21:47 --> Output Class Initialized
INFO - 2020-11-30 11:21:47 --> Security Class Initialized
DEBUG - 2020-11-30 11:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 11:21:47 --> Input Class Initialized
INFO - 2020-11-30 11:21:47 --> Language Class Initialized
INFO - 2020-11-30 11:21:47 --> Loader Class Initialized
INFO - 2020-11-30 11:21:47 --> Helper loaded: url_helper
INFO - 2020-11-30 11:21:47 --> Database Driver Class Initialized
INFO - 2020-11-30 11:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 11:21:47 --> Email Class Initialized
INFO - 2020-11-30 11:21:47 --> Controller Class Initialized
INFO - 2020-11-30 11:21:47 --> Model Class Initialized
INFO - 2020-11-30 11:21:47 --> Model Class Initialized
DEBUG - 2020-11-30 11:21:47 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-30 11:21:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-30 11:21:47 --> Final output sent to browser
DEBUG - 2020-11-30 11:21:47 --> Total execution time: 0.0206
ERROR - 2020-11-30 11:21:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 11:21:47 --> Config Class Initialized
INFO - 2020-11-30 11:21:47 --> Hooks Class Initialized
DEBUG - 2020-11-30 11:21:47 --> UTF-8 Support Enabled
INFO - 2020-11-30 11:21:47 --> Utf8 Class Initialized
INFO - 2020-11-30 11:21:47 --> URI Class Initialized
INFO - 2020-11-30 11:21:47 --> Router Class Initialized
INFO - 2020-11-30 11:21:47 --> Output Class Initialized
INFO - 2020-11-30 11:21:47 --> Security Class Initialized
DEBUG - 2020-11-30 11:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 11:21:47 --> Input Class Initialized
INFO - 2020-11-30 11:21:47 --> Language Class Initialized
INFO - 2020-11-30 11:21:47 --> Loader Class Initialized
INFO - 2020-11-30 11:21:47 --> Helper loaded: url_helper
INFO - 2020-11-30 11:21:47 --> Database Driver Class Initialized
INFO - 2020-11-30 11:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 11:21:47 --> Email Class Initialized
INFO - 2020-11-30 11:21:47 --> Controller Class Initialized
DEBUG - 2020-11-30 11:21:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-30 11:21:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-30 11:21:47 --> Model Class Initialized
INFO - 2020-11-30 11:21:47 --> Model Class Initialized
INFO - 2020-11-30 11:21:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-11-30 11:21:47 --> Final output sent to browser
DEBUG - 2020-11-30 11:21:47 --> Total execution time: 0.0241
ERROR - 2020-11-30 11:22:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 11:22:01 --> Config Class Initialized
INFO - 2020-11-30 11:22:01 --> Hooks Class Initialized
DEBUG - 2020-11-30 11:22:01 --> UTF-8 Support Enabled
INFO - 2020-11-30 11:22:01 --> Utf8 Class Initialized
INFO - 2020-11-30 11:22:01 --> URI Class Initialized
INFO - 2020-11-30 11:22:01 --> Router Class Initialized
INFO - 2020-11-30 11:22:01 --> Output Class Initialized
INFO - 2020-11-30 11:22:01 --> Security Class Initialized
DEBUG - 2020-11-30 11:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 11:22:01 --> Input Class Initialized
INFO - 2020-11-30 11:22:01 --> Language Class Initialized
INFO - 2020-11-30 11:22:01 --> Loader Class Initialized
INFO - 2020-11-30 11:22:01 --> Helper loaded: url_helper
INFO - 2020-11-30 11:22:01 --> Database Driver Class Initialized
INFO - 2020-11-30 11:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 11:22:01 --> Email Class Initialized
INFO - 2020-11-30 11:22:01 --> Controller Class Initialized
DEBUG - 2020-11-30 11:22:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-30 11:22:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-30 11:22:01 --> Model Class Initialized
INFO - 2020-11-30 11:22:01 --> Model Class Initialized
INFO - 2020-11-30 11:22:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-11-30 11:22:01 --> Final output sent to browser
DEBUG - 2020-11-30 11:22:01 --> Total execution time: 0.0260
ERROR - 2020-11-30 11:22:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 11:22:01 --> Config Class Initialized
INFO - 2020-11-30 11:22:01 --> Hooks Class Initialized
DEBUG - 2020-11-30 11:22:01 --> UTF-8 Support Enabled
INFO - 2020-11-30 11:22:01 --> Utf8 Class Initialized
INFO - 2020-11-30 11:22:01 --> URI Class Initialized
INFO - 2020-11-30 11:22:01 --> Router Class Initialized
INFO - 2020-11-30 11:22:01 --> Output Class Initialized
INFO - 2020-11-30 11:22:01 --> Security Class Initialized
DEBUG - 2020-11-30 11:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 11:22:01 --> Input Class Initialized
INFO - 2020-11-30 11:22:01 --> Language Class Initialized
INFO - 2020-11-30 11:22:01 --> Loader Class Initialized
INFO - 2020-11-30 11:22:01 --> Helper loaded: url_helper
INFO - 2020-11-30 11:22:01 --> Database Driver Class Initialized
INFO - 2020-11-30 11:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 11:22:01 --> Email Class Initialized
INFO - 2020-11-30 11:22:01 --> Controller Class Initialized
DEBUG - 2020-11-30 11:22:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-30 11:22:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-30 11:22:01 --> Model Class Initialized
INFO - 2020-11-30 11:22:01 --> Model Class Initialized
INFO - 2020-11-30 11:22:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-11-30 11:22:01 --> Final output sent to browser
DEBUG - 2020-11-30 11:22:01 --> Total execution time: 0.0235
ERROR - 2020-11-30 11:22:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 11:22:03 --> Config Class Initialized
INFO - 2020-11-30 11:22:03 --> Hooks Class Initialized
DEBUG - 2020-11-30 11:22:03 --> UTF-8 Support Enabled
INFO - 2020-11-30 11:22:03 --> Utf8 Class Initialized
INFO - 2020-11-30 11:22:03 --> URI Class Initialized
INFO - 2020-11-30 11:22:03 --> Router Class Initialized
INFO - 2020-11-30 11:22:03 --> Output Class Initialized
INFO - 2020-11-30 11:22:03 --> Security Class Initialized
DEBUG - 2020-11-30 11:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 11:22:03 --> Input Class Initialized
INFO - 2020-11-30 11:22:03 --> Language Class Initialized
INFO - 2020-11-30 11:22:03 --> Loader Class Initialized
INFO - 2020-11-30 11:22:03 --> Helper loaded: url_helper
INFO - 2020-11-30 11:22:03 --> Database Driver Class Initialized
INFO - 2020-11-30 11:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 11:22:03 --> Email Class Initialized
INFO - 2020-11-30 11:22:03 --> Controller Class Initialized
DEBUG - 2020-11-30 11:22:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-30 11:22:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-30 11:22:03 --> Model Class Initialized
INFO - 2020-11-30 11:22:03 --> Model Class Initialized
INFO - 2020-11-30 11:22:03 --> Final output sent to browser
DEBUG - 2020-11-30 11:22:03 --> Total execution time: 0.0235
ERROR - 2020-11-30 11:22:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 11:22:07 --> Config Class Initialized
INFO - 2020-11-30 11:22:07 --> Hooks Class Initialized
DEBUG - 2020-11-30 11:22:07 --> UTF-8 Support Enabled
INFO - 2020-11-30 11:22:07 --> Utf8 Class Initialized
INFO - 2020-11-30 11:22:07 --> URI Class Initialized
INFO - 2020-11-30 11:22:07 --> Router Class Initialized
INFO - 2020-11-30 11:22:07 --> Output Class Initialized
INFO - 2020-11-30 11:22:07 --> Security Class Initialized
DEBUG - 2020-11-30 11:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 11:22:07 --> Input Class Initialized
INFO - 2020-11-30 11:22:07 --> Language Class Initialized
INFO - 2020-11-30 11:22:07 --> Loader Class Initialized
INFO - 2020-11-30 11:22:07 --> Helper loaded: url_helper
INFO - 2020-11-30 11:22:07 --> Database Driver Class Initialized
INFO - 2020-11-30 11:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 11:22:07 --> Email Class Initialized
INFO - 2020-11-30 11:22:07 --> Controller Class Initialized
DEBUG - 2020-11-30 11:22:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-30 11:22:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-30 11:22:07 --> Model Class Initialized
INFO - 2020-11-30 11:22:07 --> Model Class Initialized
INFO - 2020-11-30 11:22:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-11-30 11:22:07 --> Final output sent to browser
DEBUG - 2020-11-30 11:22:07 --> Total execution time: 0.0247
ERROR - 2020-11-30 11:22:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 11:22:08 --> Config Class Initialized
INFO - 2020-11-30 11:22:08 --> Hooks Class Initialized
DEBUG - 2020-11-30 11:22:08 --> UTF-8 Support Enabled
INFO - 2020-11-30 11:22:08 --> Utf8 Class Initialized
INFO - 2020-11-30 11:22:08 --> URI Class Initialized
INFO - 2020-11-30 11:22:08 --> Router Class Initialized
INFO - 2020-11-30 11:22:08 --> Output Class Initialized
INFO - 2020-11-30 11:22:08 --> Security Class Initialized
DEBUG - 2020-11-30 11:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 11:22:08 --> Input Class Initialized
INFO - 2020-11-30 11:22:08 --> Language Class Initialized
INFO - 2020-11-30 11:22:08 --> Loader Class Initialized
INFO - 2020-11-30 11:22:08 --> Helper loaded: url_helper
INFO - 2020-11-30 11:22:08 --> Database Driver Class Initialized
INFO - 2020-11-30 11:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 11:22:08 --> Email Class Initialized
INFO - 2020-11-30 11:22:08 --> Controller Class Initialized
DEBUG - 2020-11-30 11:22:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-30 11:22:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-30 11:22:08 --> Model Class Initialized
INFO - 2020-11-30 11:22:08 --> Model Class Initialized
INFO - 2020-11-30 11:22:08 --> Final output sent to browser
DEBUG - 2020-11-30 11:22:08 --> Total execution time: 0.0196
ERROR - 2020-11-30 11:22:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 11:22:11 --> Config Class Initialized
INFO - 2020-11-30 11:22:11 --> Hooks Class Initialized
DEBUG - 2020-11-30 11:22:11 --> UTF-8 Support Enabled
INFO - 2020-11-30 11:22:11 --> Utf8 Class Initialized
INFO - 2020-11-30 11:22:11 --> URI Class Initialized
INFO - 2020-11-30 11:22:11 --> Router Class Initialized
INFO - 2020-11-30 11:22:11 --> Output Class Initialized
INFO - 2020-11-30 11:22:11 --> Security Class Initialized
DEBUG - 2020-11-30 11:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 11:22:11 --> Input Class Initialized
INFO - 2020-11-30 11:22:11 --> Language Class Initialized
INFO - 2020-11-30 11:22:11 --> Loader Class Initialized
INFO - 2020-11-30 11:22:11 --> Helper loaded: url_helper
INFO - 2020-11-30 11:22:11 --> Database Driver Class Initialized
INFO - 2020-11-30 11:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 11:22:11 --> Email Class Initialized
INFO - 2020-11-30 11:22:11 --> Controller Class Initialized
DEBUG - 2020-11-30 11:22:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-30 11:22:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-30 11:22:11 --> Model Class Initialized
INFO - 2020-11-30 11:22:11 --> Model Class Initialized
INFO - 2020-11-30 11:22:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-11-30 11:22:11 --> Final output sent to browser
DEBUG - 2020-11-30 11:22:11 --> Total execution time: 0.0231
ERROR - 2020-11-30 11:22:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 11:22:12 --> Config Class Initialized
INFO - 2020-11-30 11:22:12 --> Hooks Class Initialized
DEBUG - 2020-11-30 11:22:12 --> UTF-8 Support Enabled
INFO - 2020-11-30 11:22:12 --> Utf8 Class Initialized
INFO - 2020-11-30 11:22:12 --> URI Class Initialized
INFO - 2020-11-30 11:22:12 --> Router Class Initialized
INFO - 2020-11-30 11:22:12 --> Output Class Initialized
INFO - 2020-11-30 11:22:12 --> Security Class Initialized
DEBUG - 2020-11-30 11:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 11:22:12 --> Input Class Initialized
INFO - 2020-11-30 11:22:12 --> Language Class Initialized
INFO - 2020-11-30 11:22:12 --> Loader Class Initialized
INFO - 2020-11-30 11:22:12 --> Helper loaded: url_helper
INFO - 2020-11-30 11:22:12 --> Database Driver Class Initialized
INFO - 2020-11-30 11:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 11:22:12 --> Email Class Initialized
INFO - 2020-11-30 11:22:12 --> Controller Class Initialized
DEBUG - 2020-11-30 11:22:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-30 11:22:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-30 11:22:12 --> Model Class Initialized
INFO - 2020-11-30 11:22:12 --> Model Class Initialized
INFO - 2020-11-30 11:22:12 --> Final output sent to browser
DEBUG - 2020-11-30 11:22:12 --> Total execution time: 0.0243
ERROR - 2020-11-30 11:23:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 11:23:14 --> Config Class Initialized
INFO - 2020-11-30 11:23:14 --> Hooks Class Initialized
DEBUG - 2020-11-30 11:23:14 --> UTF-8 Support Enabled
INFO - 2020-11-30 11:23:14 --> Utf8 Class Initialized
INFO - 2020-11-30 11:23:14 --> URI Class Initialized
INFO - 2020-11-30 11:23:14 --> Router Class Initialized
INFO - 2020-11-30 11:23:14 --> Output Class Initialized
INFO - 2020-11-30 11:23:14 --> Security Class Initialized
DEBUG - 2020-11-30 11:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 11:23:14 --> Input Class Initialized
INFO - 2020-11-30 11:23:14 --> Language Class Initialized
INFO - 2020-11-30 11:23:14 --> Loader Class Initialized
INFO - 2020-11-30 11:23:14 --> Helper loaded: url_helper
INFO - 2020-11-30 11:23:14 --> Database Driver Class Initialized
INFO - 2020-11-30 11:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 11:23:14 --> Email Class Initialized
INFO - 2020-11-30 11:23:14 --> Controller Class Initialized
DEBUG - 2020-11-30 11:23:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-30 11:23:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-30 11:23:14 --> Model Class Initialized
INFO - 2020-11-30 11:23:14 --> Model Class Initialized
INFO - 2020-11-30 11:23:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-11-30 11:23:14 --> Final output sent to browser
DEBUG - 2020-11-30 11:23:14 --> Total execution time: 0.0289
ERROR - 2020-11-30 11:23:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 11:23:16 --> Config Class Initialized
INFO - 2020-11-30 11:23:16 --> Hooks Class Initialized
DEBUG - 2020-11-30 11:23:16 --> UTF-8 Support Enabled
INFO - 2020-11-30 11:23:16 --> Utf8 Class Initialized
INFO - 2020-11-30 11:23:16 --> URI Class Initialized
INFO - 2020-11-30 11:23:16 --> Router Class Initialized
INFO - 2020-11-30 11:23:16 --> Output Class Initialized
INFO - 2020-11-30 11:23:16 --> Security Class Initialized
DEBUG - 2020-11-30 11:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 11:23:16 --> Input Class Initialized
INFO - 2020-11-30 11:23:16 --> Language Class Initialized
INFO - 2020-11-30 11:23:16 --> Loader Class Initialized
INFO - 2020-11-30 11:23:16 --> Helper loaded: url_helper
INFO - 2020-11-30 11:23:16 --> Database Driver Class Initialized
INFO - 2020-11-30 11:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 11:23:16 --> Email Class Initialized
INFO - 2020-11-30 11:23:16 --> Controller Class Initialized
DEBUG - 2020-11-30 11:23:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-30 11:23:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-30 11:23:16 --> Model Class Initialized
INFO - 2020-11-30 11:23:16 --> Model Class Initialized
INFO - 2020-11-30 11:23:16 --> Final output sent to browser
DEBUG - 2020-11-30 11:23:16 --> Total execution time: 0.0205
ERROR - 2020-11-30 11:31:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 11:31:32 --> Config Class Initialized
INFO - 2020-11-30 11:31:32 --> Hooks Class Initialized
DEBUG - 2020-11-30 11:31:32 --> UTF-8 Support Enabled
INFO - 2020-11-30 11:31:32 --> Utf8 Class Initialized
INFO - 2020-11-30 11:31:32 --> URI Class Initialized
INFO - 2020-11-30 11:31:32 --> Router Class Initialized
INFO - 2020-11-30 11:31:32 --> Output Class Initialized
INFO - 2020-11-30 11:31:32 --> Security Class Initialized
DEBUG - 2020-11-30 11:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 11:31:32 --> Input Class Initialized
INFO - 2020-11-30 11:31:32 --> Language Class Initialized
INFO - 2020-11-30 11:31:32 --> Loader Class Initialized
INFO - 2020-11-30 11:31:32 --> Helper loaded: url_helper
INFO - 2020-11-30 11:31:32 --> Database Driver Class Initialized
INFO - 2020-11-30 11:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 11:31:32 --> Email Class Initialized
INFO - 2020-11-30 11:31:32 --> Controller Class Initialized
DEBUG - 2020-11-30 11:31:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-30 11:31:32 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-30 11:31:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-30 11:31:33 --> Config Class Initialized
INFO - 2020-11-30 11:31:33 --> Hooks Class Initialized
DEBUG - 2020-11-30 11:31:33 --> UTF-8 Support Enabled
INFO - 2020-11-30 11:31:33 --> Utf8 Class Initialized
INFO - 2020-11-30 11:31:33 --> URI Class Initialized
DEBUG - 2020-11-30 11:31:33 --> No URI present. Default controller set.
INFO - 2020-11-30 11:31:33 --> Router Class Initialized
INFO - 2020-11-30 11:31:33 --> Output Class Initialized
INFO - 2020-11-30 11:31:33 --> Security Class Initialized
DEBUG - 2020-11-30 11:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-30 11:31:33 --> Input Class Initialized
INFO - 2020-11-30 11:31:33 --> Language Class Initialized
INFO - 2020-11-30 11:31:33 --> Loader Class Initialized
INFO - 2020-11-30 11:31:33 --> Helper loaded: url_helper
INFO - 2020-11-30 11:31:33 --> Database Driver Class Initialized
INFO - 2020-11-30 11:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-30 11:31:33 --> Email Class Initialized
INFO - 2020-11-30 11:31:33 --> Controller Class Initialized
INFO - 2020-11-30 11:31:33 --> Model Class Initialized
INFO - 2020-11-30 11:31:33 --> Model Class Initialized
DEBUG - 2020-11-30 11:31:33 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-30 11:31:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-30 11:31:33 --> Final output sent to browser
DEBUG - 2020-11-30 11:31:33 --> Total execution time: 0.0168
