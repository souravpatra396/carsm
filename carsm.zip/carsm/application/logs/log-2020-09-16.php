<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-16 09:34:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:34:00 --> Config Class Initialized
INFO - 2020-09-16 09:34:00 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:34:00 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:34:00 --> Utf8 Class Initialized
INFO - 2020-09-16 09:34:00 --> URI Class Initialized
DEBUG - 2020-09-16 09:34:00 --> No URI present. Default controller set.
INFO - 2020-09-16 09:34:00 --> Router Class Initialized
INFO - 2020-09-16 09:34:00 --> Output Class Initialized
INFO - 2020-09-16 09:34:00 --> Security Class Initialized
DEBUG - 2020-09-16 09:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:34:00 --> Input Class Initialized
INFO - 2020-09-16 09:34:00 --> Language Class Initialized
INFO - 2020-09-16 09:34:00 --> Loader Class Initialized
INFO - 2020-09-16 09:34:00 --> Helper loaded: url_helper
INFO - 2020-09-16 09:34:00 --> Database Driver Class Initialized
INFO - 2020-09-16 09:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:34:00 --> Email Class Initialized
INFO - 2020-09-16 09:34:00 --> Controller Class Initialized
INFO - 2020-09-16 09:34:00 --> Model Class Initialized
INFO - 2020-09-16 09:34:00 --> Model Class Initialized
DEBUG - 2020-09-16 09:34:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:34:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-16 09:34:00 --> Final output sent to browser
DEBUG - 2020-09-16 09:34:00 --> Total execution time: 0.1680
ERROR - 2020-09-16 09:34:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:34:21 --> Config Class Initialized
INFO - 2020-09-16 09:34:21 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:34:21 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:34:21 --> Utf8 Class Initialized
INFO - 2020-09-16 09:34:21 --> URI Class Initialized
INFO - 2020-09-16 09:34:21 --> Router Class Initialized
INFO - 2020-09-16 09:34:21 --> Output Class Initialized
INFO - 2020-09-16 09:34:21 --> Security Class Initialized
DEBUG - 2020-09-16 09:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:34:21 --> Input Class Initialized
INFO - 2020-09-16 09:34:21 --> Language Class Initialized
INFO - 2020-09-16 09:34:21 --> Loader Class Initialized
INFO - 2020-09-16 09:34:21 --> Helper loaded: url_helper
INFO - 2020-09-16 09:34:21 --> Database Driver Class Initialized
INFO - 2020-09-16 09:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:34:21 --> Email Class Initialized
INFO - 2020-09-16 09:34:21 --> Controller Class Initialized
INFO - 2020-09-16 09:34:21 --> Model Class Initialized
INFO - 2020-09-16 09:34:21 --> Model Class Initialized
DEBUG - 2020-09-16 09:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:34:21 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-16 09:34:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:34:21 --> Config Class Initialized
INFO - 2020-09-16 09:34:21 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:34:21 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:34:21 --> Utf8 Class Initialized
INFO - 2020-09-16 09:34:21 --> URI Class Initialized
INFO - 2020-09-16 09:34:21 --> Router Class Initialized
INFO - 2020-09-16 09:34:21 --> Output Class Initialized
INFO - 2020-09-16 09:34:21 --> Security Class Initialized
DEBUG - 2020-09-16 09:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:34:21 --> Input Class Initialized
INFO - 2020-09-16 09:34:21 --> Language Class Initialized
INFO - 2020-09-16 09:34:21 --> Loader Class Initialized
INFO - 2020-09-16 09:34:21 --> Helper loaded: url_helper
INFO - 2020-09-16 09:34:21 --> Database Driver Class Initialized
INFO - 2020-09-16 09:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:34:21 --> Email Class Initialized
INFO - 2020-09-16 09:34:21 --> Controller Class Initialized
INFO - 2020-09-16 09:34:21 --> Model Class Initialized
INFO - 2020-09-16 09:34:21 --> Model Class Initialized
DEBUG - 2020-09-16 09:34:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 09:34:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:34:22 --> Config Class Initialized
INFO - 2020-09-16 09:34:22 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:34:22 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:34:22 --> Utf8 Class Initialized
INFO - 2020-09-16 09:34:22 --> URI Class Initialized
DEBUG - 2020-09-16 09:34:22 --> No URI present. Default controller set.
INFO - 2020-09-16 09:34:22 --> Router Class Initialized
INFO - 2020-09-16 09:34:22 --> Output Class Initialized
INFO - 2020-09-16 09:34:22 --> Security Class Initialized
DEBUG - 2020-09-16 09:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:34:22 --> Input Class Initialized
INFO - 2020-09-16 09:34:22 --> Language Class Initialized
INFO - 2020-09-16 09:34:22 --> Loader Class Initialized
INFO - 2020-09-16 09:34:22 --> Helper loaded: url_helper
INFO - 2020-09-16 09:34:22 --> Database Driver Class Initialized
ERROR - 2020-09-16 09:34:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:34:22 --> Config Class Initialized
INFO - 2020-09-16 09:34:22 --> Hooks Class Initialized
INFO - 2020-09-16 09:34:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-09-16 09:34:22 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:34:22 --> Utf8 Class Initialized
INFO - 2020-09-16 09:34:22 --> Email Class Initialized
INFO - 2020-09-16 09:34:22 --> Controller Class Initialized
INFO - 2020-09-16 09:34:22 --> Model Class Initialized
INFO - 2020-09-16 09:34:22 --> Model Class Initialized
DEBUG - 2020-09-16 09:34:22 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:34:22 --> URI Class Initialized
INFO - 2020-09-16 09:34:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-16 09:34:22 --> Final output sent to browser
DEBUG - 2020-09-16 09:34:22 --> Total execution time: 0.0208
INFO - 2020-09-16 09:34:22 --> Router Class Initialized
INFO - 2020-09-16 09:34:22 --> Output Class Initialized
INFO - 2020-09-16 09:34:22 --> Security Class Initialized
DEBUG - 2020-09-16 09:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:34:22 --> Input Class Initialized
INFO - 2020-09-16 09:34:22 --> Language Class Initialized
INFO - 2020-09-16 09:34:22 --> Loader Class Initialized
INFO - 2020-09-16 09:34:22 --> Helper loaded: url_helper
INFO - 2020-09-16 09:34:22 --> Database Driver Class Initialized
INFO - 2020-09-16 09:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:34:22 --> Email Class Initialized
INFO - 2020-09-16 09:34:22 --> Controller Class Initialized
DEBUG - 2020-09-16 09:34:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:34:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:34:22 --> Model Class Initialized
INFO - 2020-09-16 09:34:22 --> Model Class Initialized
INFO - 2020-09-16 09:34:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-16 09:34:22 --> Final output sent to browser
DEBUG - 2020-09-16 09:34:22 --> Total execution time: 0.0750
ERROR - 2020-09-16 09:34:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:34:30 --> Config Class Initialized
INFO - 2020-09-16 09:34:30 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:34:30 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:34:30 --> Utf8 Class Initialized
INFO - 2020-09-16 09:34:30 --> URI Class Initialized
INFO - 2020-09-16 09:34:30 --> Router Class Initialized
INFO - 2020-09-16 09:34:30 --> Output Class Initialized
INFO - 2020-09-16 09:34:30 --> Security Class Initialized
DEBUG - 2020-09-16 09:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:34:30 --> Input Class Initialized
INFO - 2020-09-16 09:34:30 --> Language Class Initialized
INFO - 2020-09-16 09:34:31 --> Loader Class Initialized
INFO - 2020-09-16 09:34:31 --> Helper loaded: url_helper
INFO - 2020-09-16 09:34:31 --> Database Driver Class Initialized
INFO - 2020-09-16 09:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:34:31 --> Email Class Initialized
INFO - 2020-09-16 09:34:31 --> Controller Class Initialized
DEBUG - 2020-09-16 09:34:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:34:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:34:31 --> Model Class Initialized
INFO - 2020-09-16 09:34:31 --> Model Class Initialized
INFO - 2020-09-16 09:34:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 09:34:31 --> Final output sent to browser
DEBUG - 2020-09-16 09:34:31 --> Total execution time: 0.0609
ERROR - 2020-09-16 09:35:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:35:03 --> Config Class Initialized
INFO - 2020-09-16 09:35:03 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:35:03 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:35:03 --> Utf8 Class Initialized
INFO - 2020-09-16 09:35:03 --> URI Class Initialized
INFO - 2020-09-16 09:35:03 --> Router Class Initialized
INFO - 2020-09-16 09:35:03 --> Output Class Initialized
INFO - 2020-09-16 09:35:03 --> Security Class Initialized
DEBUG - 2020-09-16 09:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:35:03 --> Input Class Initialized
INFO - 2020-09-16 09:35:03 --> Language Class Initialized
INFO - 2020-09-16 09:35:03 --> Loader Class Initialized
INFO - 2020-09-16 09:35:03 --> Helper loaded: url_helper
INFO - 2020-09-16 09:35:03 --> Database Driver Class Initialized
INFO - 2020-09-16 09:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:35:03 --> Email Class Initialized
INFO - 2020-09-16 09:35:03 --> Controller Class Initialized
DEBUG - 2020-09-16 09:35:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:35:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:35:03 --> Model Class Initialized
INFO - 2020-09-16 09:35:03 --> Model Class Initialized
INFO - 2020-09-16 09:35:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-16 09:35:03 --> Final output sent to browser
DEBUG - 2020-09-16 09:35:03 --> Total execution time: 0.0331
ERROR - 2020-09-16 09:35:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:35:15 --> Config Class Initialized
INFO - 2020-09-16 09:35:15 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:35:15 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:35:15 --> Utf8 Class Initialized
INFO - 2020-09-16 09:35:15 --> URI Class Initialized
INFO - 2020-09-16 09:35:15 --> Router Class Initialized
INFO - 2020-09-16 09:35:15 --> Output Class Initialized
INFO - 2020-09-16 09:35:15 --> Security Class Initialized
DEBUG - 2020-09-16 09:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:35:15 --> Input Class Initialized
INFO - 2020-09-16 09:35:15 --> Language Class Initialized
INFO - 2020-09-16 09:35:15 --> Loader Class Initialized
INFO - 2020-09-16 09:35:15 --> Helper loaded: url_helper
INFO - 2020-09-16 09:35:15 --> Database Driver Class Initialized
INFO - 2020-09-16 09:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:35:15 --> Email Class Initialized
INFO - 2020-09-16 09:35:15 --> Controller Class Initialized
DEBUG - 2020-09-16 09:35:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:35:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:35:15 --> Model Class Initialized
INFO - 2020-09-16 09:35:15 --> Model Class Initialized
INFO - 2020-09-16 09:35:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 09:35:15 --> Final output sent to browser
DEBUG - 2020-09-16 09:35:15 --> Total execution time: 0.0234
ERROR - 2020-09-16 09:35:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:35:49 --> Config Class Initialized
INFO - 2020-09-16 09:35:49 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:35:49 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:35:49 --> Utf8 Class Initialized
INFO - 2020-09-16 09:35:49 --> URI Class Initialized
INFO - 2020-09-16 09:35:49 --> Router Class Initialized
INFO - 2020-09-16 09:35:49 --> Output Class Initialized
INFO - 2020-09-16 09:35:49 --> Security Class Initialized
DEBUG - 2020-09-16 09:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:35:49 --> Input Class Initialized
INFO - 2020-09-16 09:35:49 --> Language Class Initialized
INFO - 2020-09-16 09:35:49 --> Loader Class Initialized
INFO - 2020-09-16 09:35:49 --> Helper loaded: url_helper
INFO - 2020-09-16 09:35:49 --> Database Driver Class Initialized
INFO - 2020-09-16 09:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:35:49 --> Email Class Initialized
INFO - 2020-09-16 09:35:49 --> Controller Class Initialized
DEBUG - 2020-09-16 09:35:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:35:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:35:49 --> Model Class Initialized
INFO - 2020-09-16 09:35:49 --> Model Class Initialized
INFO - 2020-09-16 09:35:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 09:35:49 --> Final output sent to browser
DEBUG - 2020-09-16 09:35:49 --> Total execution time: 0.0256
ERROR - 2020-09-16 09:36:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:36:12 --> Config Class Initialized
INFO - 2020-09-16 09:36:12 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:36:12 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:36:12 --> Utf8 Class Initialized
INFO - 2020-09-16 09:36:12 --> URI Class Initialized
INFO - 2020-09-16 09:36:12 --> Router Class Initialized
INFO - 2020-09-16 09:36:12 --> Output Class Initialized
INFO - 2020-09-16 09:36:12 --> Security Class Initialized
DEBUG - 2020-09-16 09:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:36:12 --> Input Class Initialized
INFO - 2020-09-16 09:36:12 --> Language Class Initialized
INFO - 2020-09-16 09:36:12 --> Loader Class Initialized
INFO - 2020-09-16 09:36:12 --> Helper loaded: url_helper
INFO - 2020-09-16 09:36:12 --> Database Driver Class Initialized
INFO - 2020-09-16 09:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:36:12 --> Email Class Initialized
INFO - 2020-09-16 09:36:12 --> Controller Class Initialized
DEBUG - 2020-09-16 09:36:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:36:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:36:12 --> Model Class Initialized
INFO - 2020-09-16 09:36:12 --> Model Class Initialized
INFO - 2020-09-16 09:36:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_view.php
INFO - 2020-09-16 09:36:12 --> Final output sent to browser
DEBUG - 2020-09-16 09:36:12 --> Total execution time: 0.0586
ERROR - 2020-09-16 09:36:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:36:33 --> Config Class Initialized
INFO - 2020-09-16 09:36:33 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:36:33 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:36:33 --> Utf8 Class Initialized
INFO - 2020-09-16 09:36:33 --> URI Class Initialized
INFO - 2020-09-16 09:36:33 --> Router Class Initialized
INFO - 2020-09-16 09:36:33 --> Output Class Initialized
INFO - 2020-09-16 09:36:33 --> Security Class Initialized
DEBUG - 2020-09-16 09:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:36:33 --> Input Class Initialized
INFO - 2020-09-16 09:36:33 --> Language Class Initialized
INFO - 2020-09-16 09:36:33 --> Loader Class Initialized
INFO - 2020-09-16 09:36:33 --> Helper loaded: url_helper
INFO - 2020-09-16 09:36:33 --> Database Driver Class Initialized
INFO - 2020-09-16 09:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:36:33 --> Email Class Initialized
INFO - 2020-09-16 09:36:33 --> Controller Class Initialized
DEBUG - 2020-09-16 09:36:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:36:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:36:33 --> Model Class Initialized
INFO - 2020-09-16 09:36:33 --> Model Class Initialized
INFO - 2020-09-16 09:36:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-16 09:36:33 --> Final output sent to browser
DEBUG - 2020-09-16 09:36:33 --> Total execution time: 0.0398
ERROR - 2020-09-16 09:36:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:36:40 --> Config Class Initialized
INFO - 2020-09-16 09:36:40 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:36:40 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:36:40 --> Utf8 Class Initialized
INFO - 2020-09-16 09:36:40 --> URI Class Initialized
INFO - 2020-09-16 09:36:40 --> Router Class Initialized
INFO - 2020-09-16 09:36:40 --> Output Class Initialized
INFO - 2020-09-16 09:36:40 --> Security Class Initialized
DEBUG - 2020-09-16 09:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:36:40 --> Input Class Initialized
INFO - 2020-09-16 09:36:40 --> Language Class Initialized
INFO - 2020-09-16 09:36:40 --> Loader Class Initialized
INFO - 2020-09-16 09:36:40 --> Helper loaded: url_helper
INFO - 2020-09-16 09:36:40 --> Database Driver Class Initialized
INFO - 2020-09-16 09:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:36:40 --> Email Class Initialized
INFO - 2020-09-16 09:36:40 --> Controller Class Initialized
DEBUG - 2020-09-16 09:36:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:36:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:36:40 --> Model Class Initialized
INFO - 2020-09-16 09:36:40 --> Model Class Initialized
INFO - 2020-09-16 09:36:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-16 09:36:40 --> Final output sent to browser
DEBUG - 2020-09-16 09:36:40 --> Total execution time: 0.0247
ERROR - 2020-09-16 09:36:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:36:43 --> Config Class Initialized
INFO - 2020-09-16 09:36:43 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:36:43 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:36:43 --> Utf8 Class Initialized
INFO - 2020-09-16 09:36:43 --> URI Class Initialized
INFO - 2020-09-16 09:36:43 --> Router Class Initialized
INFO - 2020-09-16 09:36:43 --> Output Class Initialized
INFO - 2020-09-16 09:36:43 --> Security Class Initialized
DEBUG - 2020-09-16 09:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:36:43 --> Input Class Initialized
INFO - 2020-09-16 09:36:43 --> Language Class Initialized
INFO - 2020-09-16 09:36:43 --> Loader Class Initialized
INFO - 2020-09-16 09:36:43 --> Helper loaded: url_helper
INFO - 2020-09-16 09:36:43 --> Database Driver Class Initialized
INFO - 2020-09-16 09:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:36:43 --> Email Class Initialized
INFO - 2020-09-16 09:36:43 --> Controller Class Initialized
DEBUG - 2020-09-16 09:36:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:36:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:36:43 --> Model Class Initialized
INFO - 2020-09-16 09:36:43 --> Model Class Initialized
INFO - 2020-09-16 09:36:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 09:36:43 --> Final output sent to browser
DEBUG - 2020-09-16 09:36:43 --> Total execution time: 0.0237
ERROR - 2020-09-16 09:36:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:36:47 --> Config Class Initialized
INFO - 2020-09-16 09:36:47 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:36:47 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:36:47 --> Utf8 Class Initialized
INFO - 2020-09-16 09:36:47 --> URI Class Initialized
INFO - 2020-09-16 09:36:47 --> Router Class Initialized
INFO - 2020-09-16 09:36:47 --> Output Class Initialized
INFO - 2020-09-16 09:36:47 --> Security Class Initialized
DEBUG - 2020-09-16 09:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:36:47 --> Input Class Initialized
INFO - 2020-09-16 09:36:47 --> Language Class Initialized
INFO - 2020-09-16 09:36:47 --> Loader Class Initialized
INFO - 2020-09-16 09:36:47 --> Helper loaded: url_helper
INFO - 2020-09-16 09:36:47 --> Database Driver Class Initialized
INFO - 2020-09-16 09:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:36:47 --> Email Class Initialized
INFO - 2020-09-16 09:36:47 --> Controller Class Initialized
DEBUG - 2020-09-16 09:36:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:36:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:36:47 --> Model Class Initialized
INFO - 2020-09-16 09:36:47 --> Model Class Initialized
INFO - 2020-09-16 09:36:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_view.php
INFO - 2020-09-16 09:36:47 --> Final output sent to browser
DEBUG - 2020-09-16 09:36:47 --> Total execution time: 0.0230
ERROR - 2020-09-16 09:36:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:36:53 --> Config Class Initialized
INFO - 2020-09-16 09:36:53 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:36:53 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:36:53 --> Utf8 Class Initialized
INFO - 2020-09-16 09:36:53 --> URI Class Initialized
INFO - 2020-09-16 09:36:53 --> Router Class Initialized
INFO - 2020-09-16 09:36:53 --> Output Class Initialized
INFO - 2020-09-16 09:36:53 --> Security Class Initialized
DEBUG - 2020-09-16 09:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:36:53 --> Input Class Initialized
INFO - 2020-09-16 09:36:53 --> Language Class Initialized
INFO - 2020-09-16 09:36:53 --> Loader Class Initialized
INFO - 2020-09-16 09:36:53 --> Helper loaded: url_helper
INFO - 2020-09-16 09:36:53 --> Database Driver Class Initialized
INFO - 2020-09-16 09:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:36:53 --> Email Class Initialized
INFO - 2020-09-16 09:36:53 --> Controller Class Initialized
DEBUG - 2020-09-16 09:36:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:36:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:36:53 --> Model Class Initialized
INFO - 2020-09-16 09:36:53 --> Model Class Initialized
INFO - 2020-09-16 09:36:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-16 09:36:53 --> Final output sent to browser
DEBUG - 2020-09-16 09:36:53 --> Total execution time: 0.0222
ERROR - 2020-09-16 09:37:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:37:00 --> Config Class Initialized
INFO - 2020-09-16 09:37:00 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:37:00 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:37:00 --> Utf8 Class Initialized
INFO - 2020-09-16 09:37:00 --> URI Class Initialized
INFO - 2020-09-16 09:37:00 --> Router Class Initialized
INFO - 2020-09-16 09:37:00 --> Output Class Initialized
INFO - 2020-09-16 09:37:00 --> Security Class Initialized
DEBUG - 2020-09-16 09:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:37:00 --> Input Class Initialized
INFO - 2020-09-16 09:37:00 --> Language Class Initialized
INFO - 2020-09-16 09:37:00 --> Loader Class Initialized
INFO - 2020-09-16 09:37:00 --> Helper loaded: url_helper
INFO - 2020-09-16 09:37:00 --> Database Driver Class Initialized
INFO - 2020-09-16 09:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:37:00 --> Email Class Initialized
INFO - 2020-09-16 09:37:00 --> Controller Class Initialized
DEBUG - 2020-09-16 09:37:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:37:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:37:00 --> Model Class Initialized
INFO - 2020-09-16 09:37:00 --> Model Class Initialized
INFO - 2020-09-16 09:37:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_view.php
INFO - 2020-09-16 09:37:00 --> Final output sent to browser
DEBUG - 2020-09-16 09:37:00 --> Total execution time: 0.0219
ERROR - 2020-09-16 09:37:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:37:02 --> Config Class Initialized
INFO - 2020-09-16 09:37:02 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:37:02 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:37:02 --> Utf8 Class Initialized
INFO - 2020-09-16 09:37:02 --> URI Class Initialized
INFO - 2020-09-16 09:37:02 --> Router Class Initialized
INFO - 2020-09-16 09:37:02 --> Output Class Initialized
INFO - 2020-09-16 09:37:02 --> Security Class Initialized
DEBUG - 2020-09-16 09:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:37:02 --> Input Class Initialized
INFO - 2020-09-16 09:37:02 --> Language Class Initialized
INFO - 2020-09-16 09:37:02 --> Loader Class Initialized
INFO - 2020-09-16 09:37:02 --> Helper loaded: url_helper
INFO - 2020-09-16 09:37:02 --> Database Driver Class Initialized
INFO - 2020-09-16 09:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:37:02 --> Email Class Initialized
INFO - 2020-09-16 09:37:02 --> Controller Class Initialized
DEBUG - 2020-09-16 09:37:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:37:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:37:02 --> Model Class Initialized
INFO - 2020-09-16 09:37:02 --> Model Class Initialized
INFO - 2020-09-16 09:37:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-16 09:37:02 --> Final output sent to browser
DEBUG - 2020-09-16 09:37:02 --> Total execution time: 0.0250
ERROR - 2020-09-16 09:37:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:37:10 --> Config Class Initialized
INFO - 2020-09-16 09:37:10 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:37:10 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:37:10 --> Utf8 Class Initialized
INFO - 2020-09-16 09:37:10 --> URI Class Initialized
INFO - 2020-09-16 09:37:10 --> Router Class Initialized
INFO - 2020-09-16 09:37:10 --> Output Class Initialized
INFO - 2020-09-16 09:37:10 --> Security Class Initialized
DEBUG - 2020-09-16 09:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:37:10 --> Input Class Initialized
INFO - 2020-09-16 09:37:10 --> Language Class Initialized
INFO - 2020-09-16 09:37:10 --> Loader Class Initialized
INFO - 2020-09-16 09:37:10 --> Helper loaded: url_helper
INFO - 2020-09-16 09:37:10 --> Database Driver Class Initialized
INFO - 2020-09-16 09:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:37:10 --> Email Class Initialized
INFO - 2020-09-16 09:37:10 --> Controller Class Initialized
DEBUG - 2020-09-16 09:37:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:37:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:37:10 --> Model Class Initialized
INFO - 2020-09-16 09:37:10 --> Model Class Initialized
INFO - 2020-09-16 09:37:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-16 09:37:10 --> Final output sent to browser
DEBUG - 2020-09-16 09:37:10 --> Total execution time: 0.0231
ERROR - 2020-09-16 09:37:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:37:59 --> Config Class Initialized
INFO - 2020-09-16 09:37:59 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:37:59 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:37:59 --> Utf8 Class Initialized
INFO - 2020-09-16 09:37:59 --> URI Class Initialized
INFO - 2020-09-16 09:37:59 --> Router Class Initialized
INFO - 2020-09-16 09:37:59 --> Output Class Initialized
INFO - 2020-09-16 09:37:59 --> Security Class Initialized
DEBUG - 2020-09-16 09:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:37:59 --> Input Class Initialized
INFO - 2020-09-16 09:37:59 --> Language Class Initialized
INFO - 2020-09-16 09:37:59 --> Loader Class Initialized
INFO - 2020-09-16 09:37:59 --> Helper loaded: url_helper
INFO - 2020-09-16 09:37:59 --> Database Driver Class Initialized
INFO - 2020-09-16 09:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:37:59 --> Email Class Initialized
INFO - 2020-09-16 09:37:59 --> Controller Class Initialized
DEBUG - 2020-09-16 09:37:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:37:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:37:59 --> Model Class Initialized
INFO - 2020-09-16 09:37:59 --> Model Class Initialized
INFO - 2020-09-16 09:37:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 09:37:59 --> Final output sent to browser
DEBUG - 2020-09-16 09:37:59 --> Total execution time: 0.0265
ERROR - 2020-09-16 09:39:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:39:21 --> Config Class Initialized
INFO - 2020-09-16 09:39:21 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:39:21 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:39:21 --> Utf8 Class Initialized
INFO - 2020-09-16 09:39:21 --> URI Class Initialized
INFO - 2020-09-16 09:39:21 --> Router Class Initialized
INFO - 2020-09-16 09:39:21 --> Output Class Initialized
INFO - 2020-09-16 09:39:21 --> Security Class Initialized
DEBUG - 2020-09-16 09:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:39:21 --> Input Class Initialized
INFO - 2020-09-16 09:39:21 --> Language Class Initialized
INFO - 2020-09-16 09:39:21 --> Loader Class Initialized
INFO - 2020-09-16 09:39:21 --> Helper loaded: url_helper
INFO - 2020-09-16 09:39:21 --> Database Driver Class Initialized
INFO - 2020-09-16 09:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:39:21 --> Email Class Initialized
INFO - 2020-09-16 09:39:21 --> Controller Class Initialized
DEBUG - 2020-09-16 09:39:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:39:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:39:21 --> Model Class Initialized
INFO - 2020-09-16 09:39:21 --> Model Class Initialized
INFO - 2020-09-16 09:39:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-16 09:39:21 --> Final output sent to browser
DEBUG - 2020-09-16 09:39:21 --> Total execution time: 0.0232
ERROR - 2020-09-16 09:39:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:39:25 --> Config Class Initialized
INFO - 2020-09-16 09:39:25 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:39:25 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:39:25 --> Utf8 Class Initialized
INFO - 2020-09-16 09:39:25 --> URI Class Initialized
INFO - 2020-09-16 09:39:25 --> Router Class Initialized
INFO - 2020-09-16 09:39:25 --> Output Class Initialized
INFO - 2020-09-16 09:39:25 --> Security Class Initialized
DEBUG - 2020-09-16 09:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:39:25 --> Input Class Initialized
INFO - 2020-09-16 09:39:25 --> Language Class Initialized
INFO - 2020-09-16 09:39:25 --> Loader Class Initialized
INFO - 2020-09-16 09:39:25 --> Helper loaded: url_helper
INFO - 2020-09-16 09:39:25 --> Database Driver Class Initialized
INFO - 2020-09-16 09:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:39:25 --> Email Class Initialized
INFO - 2020-09-16 09:39:25 --> Controller Class Initialized
DEBUG - 2020-09-16 09:39:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:39:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:39:25 --> Model Class Initialized
INFO - 2020-09-16 09:39:25 --> Model Class Initialized
INFO - 2020-09-16 09:39:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 09:39:25 --> Final output sent to browser
DEBUG - 2020-09-16 09:39:25 --> Total execution time: 0.0222
ERROR - 2020-09-16 09:42:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:42:07 --> Config Class Initialized
INFO - 2020-09-16 09:42:07 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:42:07 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:42:07 --> Utf8 Class Initialized
INFO - 2020-09-16 09:42:07 --> URI Class Initialized
INFO - 2020-09-16 09:42:07 --> Router Class Initialized
INFO - 2020-09-16 09:42:07 --> Output Class Initialized
INFO - 2020-09-16 09:42:07 --> Security Class Initialized
DEBUG - 2020-09-16 09:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:42:07 --> Input Class Initialized
INFO - 2020-09-16 09:42:07 --> Language Class Initialized
INFO - 2020-09-16 09:42:07 --> Loader Class Initialized
INFO - 2020-09-16 09:42:07 --> Helper loaded: url_helper
INFO - 2020-09-16 09:42:07 --> Database Driver Class Initialized
INFO - 2020-09-16 09:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:42:07 --> Email Class Initialized
INFO - 2020-09-16 09:42:07 --> Controller Class Initialized
DEBUG - 2020-09-16 09:42:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:42:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:42:07 --> Model Class Initialized
INFO - 2020-09-16 09:42:07 --> Model Class Initialized
INFO - 2020-09-16 09:42:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 09:42:07 --> Final output sent to browser
DEBUG - 2020-09-16 09:42:07 --> Total execution time: 0.0243
ERROR - 2020-09-16 09:42:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:42:09 --> Config Class Initialized
INFO - 2020-09-16 09:42:09 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:42:09 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:42:09 --> Utf8 Class Initialized
INFO - 2020-09-16 09:42:09 --> URI Class Initialized
INFO - 2020-09-16 09:42:09 --> Router Class Initialized
INFO - 2020-09-16 09:42:09 --> Output Class Initialized
INFO - 2020-09-16 09:42:09 --> Security Class Initialized
DEBUG - 2020-09-16 09:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:42:09 --> Input Class Initialized
INFO - 2020-09-16 09:42:09 --> Language Class Initialized
INFO - 2020-09-16 09:42:09 --> Loader Class Initialized
INFO - 2020-09-16 09:42:09 --> Helper loaded: url_helper
INFO - 2020-09-16 09:42:09 --> Database Driver Class Initialized
INFO - 2020-09-16 09:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:42:09 --> Email Class Initialized
INFO - 2020-09-16 09:42:09 --> Controller Class Initialized
DEBUG - 2020-09-16 09:42:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:42:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:42:09 --> Model Class Initialized
INFO - 2020-09-16 09:42:09 --> Model Class Initialized
INFO - 2020-09-16 09:42:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 09:42:09 --> Final output sent to browser
DEBUG - 2020-09-16 09:42:09 --> Total execution time: 0.0243
ERROR - 2020-09-16 09:42:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:42:17 --> Config Class Initialized
INFO - 2020-09-16 09:42:17 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:42:17 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:42:17 --> Utf8 Class Initialized
INFO - 2020-09-16 09:42:17 --> URI Class Initialized
INFO - 2020-09-16 09:42:17 --> Router Class Initialized
INFO - 2020-09-16 09:42:17 --> Output Class Initialized
INFO - 2020-09-16 09:42:17 --> Security Class Initialized
DEBUG - 2020-09-16 09:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:42:17 --> Input Class Initialized
INFO - 2020-09-16 09:42:17 --> Language Class Initialized
INFO - 2020-09-16 09:42:17 --> Loader Class Initialized
INFO - 2020-09-16 09:42:17 --> Helper loaded: url_helper
INFO - 2020-09-16 09:42:17 --> Database Driver Class Initialized
INFO - 2020-09-16 09:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:42:17 --> Email Class Initialized
INFO - 2020-09-16 09:42:17 --> Controller Class Initialized
DEBUG - 2020-09-16 09:42:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:42:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:42:17 --> Model Class Initialized
INFO - 2020-09-16 09:42:17 --> Model Class Initialized
INFO - 2020-09-16 09:42:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-16 09:42:17 --> Final output sent to browser
DEBUG - 2020-09-16 09:42:17 --> Total execution time: 0.0250
ERROR - 2020-09-16 09:45:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:45:24 --> Config Class Initialized
INFO - 2020-09-16 09:45:24 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:45:24 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:45:24 --> Utf8 Class Initialized
INFO - 2020-09-16 09:45:24 --> URI Class Initialized
INFO - 2020-09-16 09:45:24 --> Router Class Initialized
INFO - 2020-09-16 09:45:24 --> Output Class Initialized
INFO - 2020-09-16 09:45:24 --> Security Class Initialized
DEBUG - 2020-09-16 09:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:45:24 --> Input Class Initialized
INFO - 2020-09-16 09:45:24 --> Language Class Initialized
INFO - 2020-09-16 09:45:24 --> Loader Class Initialized
INFO - 2020-09-16 09:45:24 --> Helper loaded: url_helper
INFO - 2020-09-16 09:45:24 --> Database Driver Class Initialized
INFO - 2020-09-16 09:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:45:24 --> Email Class Initialized
INFO - 2020-09-16 09:45:24 --> Controller Class Initialized
DEBUG - 2020-09-16 09:45:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:45:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:45:24 --> Model Class Initialized
INFO - 2020-09-16 09:45:24 --> Model Class Initialized
INFO - 2020-09-16 09:45:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 09:45:24 --> Final output sent to browser
DEBUG - 2020-09-16 09:45:24 --> Total execution time: 0.0282
ERROR - 2020-09-16 09:45:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:45:28 --> Config Class Initialized
INFO - 2020-09-16 09:45:28 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:45:28 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:45:28 --> Utf8 Class Initialized
INFO - 2020-09-16 09:45:28 --> URI Class Initialized
INFO - 2020-09-16 09:45:28 --> Router Class Initialized
INFO - 2020-09-16 09:45:28 --> Output Class Initialized
INFO - 2020-09-16 09:45:28 --> Security Class Initialized
DEBUG - 2020-09-16 09:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:45:28 --> Input Class Initialized
INFO - 2020-09-16 09:45:28 --> Language Class Initialized
INFO - 2020-09-16 09:45:28 --> Loader Class Initialized
INFO - 2020-09-16 09:45:28 --> Helper loaded: url_helper
INFO - 2020-09-16 09:45:28 --> Database Driver Class Initialized
INFO - 2020-09-16 09:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:45:28 --> Email Class Initialized
INFO - 2020-09-16 09:45:28 --> Controller Class Initialized
DEBUG - 2020-09-16 09:45:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:45:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:45:28 --> Model Class Initialized
INFO - 2020-09-16 09:45:28 --> Model Class Initialized
INFO - 2020-09-16 09:45:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 09:45:28 --> Final output sent to browser
DEBUG - 2020-09-16 09:45:28 --> Total execution time: 0.0256
ERROR - 2020-09-16 09:45:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:45:32 --> Config Class Initialized
INFO - 2020-09-16 09:45:32 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:45:32 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:45:32 --> Utf8 Class Initialized
INFO - 2020-09-16 09:45:32 --> URI Class Initialized
INFO - 2020-09-16 09:45:32 --> Router Class Initialized
INFO - 2020-09-16 09:45:32 --> Output Class Initialized
INFO - 2020-09-16 09:45:32 --> Security Class Initialized
DEBUG - 2020-09-16 09:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:45:32 --> Input Class Initialized
INFO - 2020-09-16 09:45:32 --> Language Class Initialized
INFO - 2020-09-16 09:45:32 --> Loader Class Initialized
INFO - 2020-09-16 09:45:32 --> Helper loaded: url_helper
INFO - 2020-09-16 09:45:32 --> Database Driver Class Initialized
INFO - 2020-09-16 09:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:45:32 --> Email Class Initialized
INFO - 2020-09-16 09:45:32 --> Controller Class Initialized
DEBUG - 2020-09-16 09:45:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:45:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:45:32 --> Model Class Initialized
INFO - 2020-09-16 09:45:32 --> Model Class Initialized
INFO - 2020-09-16 09:45:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 09:45:32 --> Final output sent to browser
DEBUG - 2020-09-16 09:45:32 --> Total execution time: 0.0232
ERROR - 2020-09-16 09:45:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:45:49 --> Config Class Initialized
INFO - 2020-09-16 09:45:49 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:45:49 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:45:49 --> Utf8 Class Initialized
INFO - 2020-09-16 09:45:49 --> URI Class Initialized
INFO - 2020-09-16 09:45:49 --> Router Class Initialized
INFO - 2020-09-16 09:45:49 --> Output Class Initialized
INFO - 2020-09-16 09:45:49 --> Security Class Initialized
DEBUG - 2020-09-16 09:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:45:49 --> Input Class Initialized
INFO - 2020-09-16 09:45:49 --> Language Class Initialized
INFO - 2020-09-16 09:45:49 --> Loader Class Initialized
INFO - 2020-09-16 09:45:49 --> Helper loaded: url_helper
INFO - 2020-09-16 09:45:49 --> Database Driver Class Initialized
INFO - 2020-09-16 09:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:45:49 --> Email Class Initialized
INFO - 2020-09-16 09:45:49 --> Controller Class Initialized
DEBUG - 2020-09-16 09:45:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:45:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:45:49 --> Model Class Initialized
INFO - 2020-09-16 09:45:49 --> Model Class Initialized
INFO - 2020-09-16 09:45:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-16 09:45:49 --> Final output sent to browser
DEBUG - 2020-09-16 09:45:49 --> Total execution time: 0.0226
ERROR - 2020-09-16 09:46:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:46:46 --> Config Class Initialized
INFO - 2020-09-16 09:46:46 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:46:46 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:46:46 --> Utf8 Class Initialized
INFO - 2020-09-16 09:46:46 --> URI Class Initialized
INFO - 2020-09-16 09:46:46 --> Router Class Initialized
INFO - 2020-09-16 09:46:46 --> Output Class Initialized
INFO - 2020-09-16 09:46:46 --> Security Class Initialized
DEBUG - 2020-09-16 09:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:46:46 --> Input Class Initialized
INFO - 2020-09-16 09:46:46 --> Language Class Initialized
INFO - 2020-09-16 09:46:46 --> Loader Class Initialized
INFO - 2020-09-16 09:46:46 --> Helper loaded: url_helper
INFO - 2020-09-16 09:46:46 --> Database Driver Class Initialized
INFO - 2020-09-16 09:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:46:46 --> Email Class Initialized
INFO - 2020-09-16 09:46:46 --> Controller Class Initialized
DEBUG - 2020-09-16 09:46:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:46:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:46:46 --> Model Class Initialized
INFO - 2020-09-16 09:46:46 --> Model Class Initialized
INFO - 2020-09-16 09:46:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-16 09:46:46 --> Final output sent to browser
DEBUG - 2020-09-16 09:46:46 --> Total execution time: 0.0222
ERROR - 2020-09-16 09:46:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:46:54 --> Config Class Initialized
INFO - 2020-09-16 09:46:54 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:46:54 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:46:54 --> Utf8 Class Initialized
INFO - 2020-09-16 09:46:54 --> URI Class Initialized
INFO - 2020-09-16 09:46:54 --> Router Class Initialized
INFO - 2020-09-16 09:46:54 --> Output Class Initialized
INFO - 2020-09-16 09:46:54 --> Security Class Initialized
DEBUG - 2020-09-16 09:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:46:54 --> Input Class Initialized
INFO - 2020-09-16 09:46:54 --> Language Class Initialized
INFO - 2020-09-16 09:46:54 --> Loader Class Initialized
INFO - 2020-09-16 09:46:54 --> Helper loaded: url_helper
INFO - 2020-09-16 09:46:54 --> Database Driver Class Initialized
INFO - 2020-09-16 09:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:46:54 --> Email Class Initialized
INFO - 2020-09-16 09:46:54 --> Controller Class Initialized
DEBUG - 2020-09-16 09:46:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:46:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:46:54 --> Model Class Initialized
INFO - 2020-09-16 09:46:54 --> Model Class Initialized
INFO - 2020-09-16 09:46:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-16 09:46:55 --> Final output sent to browser
DEBUG - 2020-09-16 09:46:55 --> Total execution time: 0.2966
ERROR - 2020-09-16 09:46:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:46:59 --> Config Class Initialized
INFO - 2020-09-16 09:46:59 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:46:59 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:46:59 --> Utf8 Class Initialized
INFO - 2020-09-16 09:46:59 --> URI Class Initialized
INFO - 2020-09-16 09:46:59 --> Router Class Initialized
INFO - 2020-09-16 09:46:59 --> Output Class Initialized
INFO - 2020-09-16 09:46:59 --> Security Class Initialized
DEBUG - 2020-09-16 09:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:46:59 --> Input Class Initialized
INFO - 2020-09-16 09:46:59 --> Language Class Initialized
INFO - 2020-09-16 09:46:59 --> Loader Class Initialized
INFO - 2020-09-16 09:46:59 --> Helper loaded: url_helper
INFO - 2020-09-16 09:46:59 --> Database Driver Class Initialized
INFO - 2020-09-16 09:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:46:59 --> Email Class Initialized
INFO - 2020-09-16 09:46:59 --> Controller Class Initialized
DEBUG - 2020-09-16 09:46:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:46:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:46:59 --> Model Class Initialized
INFO - 2020-09-16 09:46:59 --> Model Class Initialized
INFO - 2020-09-16 09:46:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 09:46:59 --> Final output sent to browser
DEBUG - 2020-09-16 09:46:59 --> Total execution time: 0.0250
ERROR - 2020-09-16 09:47:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:47:03 --> Config Class Initialized
INFO - 2020-09-16 09:47:03 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:47:03 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:47:03 --> Utf8 Class Initialized
INFO - 2020-09-16 09:47:03 --> URI Class Initialized
INFO - 2020-09-16 09:47:03 --> Router Class Initialized
INFO - 2020-09-16 09:47:03 --> Output Class Initialized
INFO - 2020-09-16 09:47:03 --> Security Class Initialized
DEBUG - 2020-09-16 09:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:47:03 --> Input Class Initialized
INFO - 2020-09-16 09:47:03 --> Language Class Initialized
INFO - 2020-09-16 09:47:03 --> Loader Class Initialized
INFO - 2020-09-16 09:47:03 --> Helper loaded: url_helper
INFO - 2020-09-16 09:47:03 --> Database Driver Class Initialized
INFO - 2020-09-16 09:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:47:03 --> Email Class Initialized
INFO - 2020-09-16 09:47:03 --> Controller Class Initialized
DEBUG - 2020-09-16 09:47:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:47:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:47:03 --> Model Class Initialized
INFO - 2020-09-16 09:47:03 --> Model Class Initialized
INFO - 2020-09-16 09:47:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-16 09:47:03 --> Final output sent to browser
DEBUG - 2020-09-16 09:47:03 --> Total execution time: 0.0220
ERROR - 2020-09-16 09:47:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:47:24 --> Config Class Initialized
INFO - 2020-09-16 09:47:24 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:47:24 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:47:24 --> Utf8 Class Initialized
INFO - 2020-09-16 09:47:24 --> URI Class Initialized
INFO - 2020-09-16 09:47:24 --> Router Class Initialized
INFO - 2020-09-16 09:47:24 --> Output Class Initialized
INFO - 2020-09-16 09:47:24 --> Security Class Initialized
DEBUG - 2020-09-16 09:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:47:24 --> Input Class Initialized
INFO - 2020-09-16 09:47:24 --> Language Class Initialized
INFO - 2020-09-16 09:47:24 --> Loader Class Initialized
INFO - 2020-09-16 09:47:24 --> Helper loaded: url_helper
INFO - 2020-09-16 09:47:24 --> Database Driver Class Initialized
INFO - 2020-09-16 09:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:47:24 --> Email Class Initialized
INFO - 2020-09-16 09:47:24 --> Controller Class Initialized
DEBUG - 2020-09-16 09:47:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:47:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:47:24 --> Model Class Initialized
INFO - 2020-09-16 09:47:24 --> Model Class Initialized
INFO - 2020-09-16 09:47:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-16 09:47:24 --> Final output sent to browser
DEBUG - 2020-09-16 09:47:24 --> Total execution time: 0.0233
ERROR - 2020-09-16 09:47:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:47:28 --> Config Class Initialized
INFO - 2020-09-16 09:47:28 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:47:28 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:47:28 --> Utf8 Class Initialized
INFO - 2020-09-16 09:47:28 --> URI Class Initialized
INFO - 2020-09-16 09:47:28 --> Router Class Initialized
INFO - 2020-09-16 09:47:28 --> Output Class Initialized
INFO - 2020-09-16 09:47:28 --> Security Class Initialized
DEBUG - 2020-09-16 09:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:47:28 --> Input Class Initialized
INFO - 2020-09-16 09:47:28 --> Language Class Initialized
INFO - 2020-09-16 09:47:28 --> Loader Class Initialized
INFO - 2020-09-16 09:47:28 --> Helper loaded: url_helper
INFO - 2020-09-16 09:47:28 --> Database Driver Class Initialized
INFO - 2020-09-16 09:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:47:28 --> Email Class Initialized
INFO - 2020-09-16 09:47:28 --> Controller Class Initialized
DEBUG - 2020-09-16 09:47:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:47:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:47:28 --> Model Class Initialized
INFO - 2020-09-16 09:47:28 --> Model Class Initialized
INFO - 2020-09-16 09:47:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 09:47:28 --> Final output sent to browser
DEBUG - 2020-09-16 09:47:28 --> Total execution time: 0.0196
ERROR - 2020-09-16 09:48:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:48:11 --> Config Class Initialized
INFO - 2020-09-16 09:48:11 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:48:11 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:48:11 --> Utf8 Class Initialized
INFO - 2020-09-16 09:48:11 --> URI Class Initialized
INFO - 2020-09-16 09:48:11 --> Router Class Initialized
INFO - 2020-09-16 09:48:11 --> Output Class Initialized
INFO - 2020-09-16 09:48:11 --> Security Class Initialized
DEBUG - 2020-09-16 09:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:48:11 --> Input Class Initialized
INFO - 2020-09-16 09:48:11 --> Language Class Initialized
INFO - 2020-09-16 09:48:11 --> Loader Class Initialized
INFO - 2020-09-16 09:48:11 --> Helper loaded: url_helper
INFO - 2020-09-16 09:48:11 --> Database Driver Class Initialized
INFO - 2020-09-16 09:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:48:11 --> Email Class Initialized
INFO - 2020-09-16 09:48:11 --> Controller Class Initialized
DEBUG - 2020-09-16 09:48:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:48:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:48:11 --> Model Class Initialized
INFO - 2020-09-16 09:48:11 --> Model Class Initialized
INFO - 2020-09-16 09:48:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_view.php
INFO - 2020-09-16 09:48:11 --> Final output sent to browser
DEBUG - 2020-09-16 09:48:11 --> Total execution time: 0.0205
ERROR - 2020-09-16 09:48:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:48:35 --> Config Class Initialized
INFO - 2020-09-16 09:48:35 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:48:35 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:48:35 --> Utf8 Class Initialized
INFO - 2020-09-16 09:48:35 --> URI Class Initialized
INFO - 2020-09-16 09:48:35 --> Router Class Initialized
INFO - 2020-09-16 09:48:35 --> Output Class Initialized
INFO - 2020-09-16 09:48:35 --> Security Class Initialized
DEBUG - 2020-09-16 09:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:48:35 --> Input Class Initialized
INFO - 2020-09-16 09:48:35 --> Language Class Initialized
INFO - 2020-09-16 09:48:35 --> Loader Class Initialized
INFO - 2020-09-16 09:48:35 --> Helper loaded: url_helper
INFO - 2020-09-16 09:48:35 --> Database Driver Class Initialized
INFO - 2020-09-16 09:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:48:35 --> Email Class Initialized
INFO - 2020-09-16 09:48:35 --> Controller Class Initialized
DEBUG - 2020-09-16 09:48:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:48:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:48:35 --> Model Class Initialized
INFO - 2020-09-16 09:48:35 --> Model Class Initialized
INFO - 2020-09-16 09:48:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-16 09:48:35 --> Final output sent to browser
DEBUG - 2020-09-16 09:48:35 --> Total execution time: 0.0240
ERROR - 2020-09-16 09:48:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:48:44 --> Config Class Initialized
INFO - 2020-09-16 09:48:44 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:48:44 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:48:44 --> Utf8 Class Initialized
INFO - 2020-09-16 09:48:44 --> URI Class Initialized
INFO - 2020-09-16 09:48:44 --> Router Class Initialized
INFO - 2020-09-16 09:48:44 --> Output Class Initialized
INFO - 2020-09-16 09:48:44 --> Security Class Initialized
DEBUG - 2020-09-16 09:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:48:44 --> Input Class Initialized
INFO - 2020-09-16 09:48:44 --> Language Class Initialized
INFO - 2020-09-16 09:48:44 --> Loader Class Initialized
INFO - 2020-09-16 09:48:44 --> Helper loaded: url_helper
INFO - 2020-09-16 09:48:44 --> Database Driver Class Initialized
INFO - 2020-09-16 09:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:48:44 --> Email Class Initialized
INFO - 2020-09-16 09:48:44 --> Controller Class Initialized
DEBUG - 2020-09-16 09:48:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:48:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:48:44 --> Model Class Initialized
INFO - 2020-09-16 09:48:44 --> Model Class Initialized
INFO - 2020-09-16 09:48:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-16 09:48:44 --> Final output sent to browser
DEBUG - 2020-09-16 09:48:44 --> Total execution time: 0.0252
ERROR - 2020-09-16 09:48:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:48:47 --> Config Class Initialized
INFO - 2020-09-16 09:48:47 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:48:47 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:48:47 --> Utf8 Class Initialized
INFO - 2020-09-16 09:48:47 --> URI Class Initialized
INFO - 2020-09-16 09:48:47 --> Router Class Initialized
INFO - 2020-09-16 09:48:47 --> Output Class Initialized
INFO - 2020-09-16 09:48:47 --> Security Class Initialized
DEBUG - 2020-09-16 09:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:48:47 --> Input Class Initialized
INFO - 2020-09-16 09:48:47 --> Language Class Initialized
INFO - 2020-09-16 09:48:47 --> Loader Class Initialized
INFO - 2020-09-16 09:48:47 --> Helper loaded: url_helper
INFO - 2020-09-16 09:48:47 --> Database Driver Class Initialized
INFO - 2020-09-16 09:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:48:47 --> Email Class Initialized
INFO - 2020-09-16 09:48:47 --> Controller Class Initialized
DEBUG - 2020-09-16 09:48:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:48:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:48:47 --> Model Class Initialized
INFO - 2020-09-16 09:48:47 --> Model Class Initialized
INFO - 2020-09-16 09:48:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 09:48:47 --> Final output sent to browser
DEBUG - 2020-09-16 09:48:47 --> Total execution time: 0.0249
ERROR - 2020-09-16 09:55:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:55:36 --> Config Class Initialized
INFO - 2020-09-16 09:55:36 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:55:36 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:55:36 --> Utf8 Class Initialized
INFO - 2020-09-16 09:55:36 --> URI Class Initialized
INFO - 2020-09-16 09:55:36 --> Router Class Initialized
INFO - 2020-09-16 09:55:36 --> Output Class Initialized
INFO - 2020-09-16 09:55:36 --> Security Class Initialized
DEBUG - 2020-09-16 09:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:55:36 --> Input Class Initialized
INFO - 2020-09-16 09:55:36 --> Language Class Initialized
INFO - 2020-09-16 09:55:36 --> Loader Class Initialized
INFO - 2020-09-16 09:55:36 --> Helper loaded: url_helper
INFO - 2020-09-16 09:55:36 --> Database Driver Class Initialized
INFO - 2020-09-16 09:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:55:36 --> Email Class Initialized
INFO - 2020-09-16 09:55:36 --> Controller Class Initialized
DEBUG - 2020-09-16 09:55:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:55:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:55:36 --> Model Class Initialized
INFO - 2020-09-16 09:55:36 --> Model Class Initialized
INFO - 2020-09-16 09:55:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 09:55:36 --> Final output sent to browser
DEBUG - 2020-09-16 09:55:36 --> Total execution time: 0.0249
ERROR - 2020-09-16 09:55:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:55:52 --> Config Class Initialized
INFO - 2020-09-16 09:55:52 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:55:52 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:55:52 --> Utf8 Class Initialized
INFO - 2020-09-16 09:55:52 --> URI Class Initialized
INFO - 2020-09-16 09:55:52 --> Router Class Initialized
INFO - 2020-09-16 09:55:52 --> Output Class Initialized
INFO - 2020-09-16 09:55:52 --> Security Class Initialized
DEBUG - 2020-09-16 09:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:55:52 --> Input Class Initialized
INFO - 2020-09-16 09:55:52 --> Language Class Initialized
INFO - 2020-09-16 09:55:52 --> Loader Class Initialized
INFO - 2020-09-16 09:55:52 --> Helper loaded: url_helper
INFO - 2020-09-16 09:55:52 --> Database Driver Class Initialized
INFO - 2020-09-16 09:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:55:52 --> Email Class Initialized
INFO - 2020-09-16 09:55:52 --> Controller Class Initialized
DEBUG - 2020-09-16 09:55:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:55:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:55:52 --> Model Class Initialized
INFO - 2020-09-16 09:55:52 --> Model Class Initialized
ERROR - 2020-09-16 09:55:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Sale_rep.php:335) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-09-16 09:55:52 --> Severity: Error --> Call to undefined method Sale_model::sale_rep_assign_view_for_client() /home/purpu1ex/public_html/carsm/application/controllers/Sale_rep.php 335
ERROR - 2020-09-16 09:55:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 09:55:56 --> Config Class Initialized
INFO - 2020-09-16 09:55:56 --> Hooks Class Initialized
DEBUG - 2020-09-16 09:55:56 --> UTF-8 Support Enabled
INFO - 2020-09-16 09:55:56 --> Utf8 Class Initialized
INFO - 2020-09-16 09:55:56 --> URI Class Initialized
INFO - 2020-09-16 09:55:56 --> Router Class Initialized
INFO - 2020-09-16 09:55:56 --> Output Class Initialized
INFO - 2020-09-16 09:55:56 --> Security Class Initialized
DEBUG - 2020-09-16 09:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 09:55:56 --> Input Class Initialized
INFO - 2020-09-16 09:55:56 --> Language Class Initialized
INFO - 2020-09-16 09:55:56 --> Loader Class Initialized
INFO - 2020-09-16 09:55:56 --> Helper loaded: url_helper
INFO - 2020-09-16 09:55:56 --> Database Driver Class Initialized
INFO - 2020-09-16 09:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 09:55:56 --> Email Class Initialized
INFO - 2020-09-16 09:55:56 --> Controller Class Initialized
DEBUG - 2020-09-16 09:55:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 09:55:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 09:55:56 --> Model Class Initialized
INFO - 2020-09-16 09:55:56 --> Model Class Initialized
INFO - 2020-09-16 09:55:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 09:55:56 --> Final output sent to browser
DEBUG - 2020-09-16 09:55:56 --> Total execution time: 0.0216
ERROR - 2020-09-16 10:05:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:05:15 --> Config Class Initialized
INFO - 2020-09-16 10:05:15 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:05:15 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:05:15 --> Utf8 Class Initialized
INFO - 2020-09-16 10:05:15 --> URI Class Initialized
INFO - 2020-09-16 10:05:15 --> Router Class Initialized
INFO - 2020-09-16 10:05:15 --> Output Class Initialized
INFO - 2020-09-16 10:05:15 --> Security Class Initialized
DEBUG - 2020-09-16 10:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:05:15 --> Input Class Initialized
INFO - 2020-09-16 10:05:15 --> Language Class Initialized
INFO - 2020-09-16 10:05:15 --> Loader Class Initialized
INFO - 2020-09-16 10:05:15 --> Helper loaded: url_helper
INFO - 2020-09-16 10:05:15 --> Database Driver Class Initialized
INFO - 2020-09-16 10:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:05:15 --> Email Class Initialized
INFO - 2020-09-16 10:05:15 --> Controller Class Initialized
DEBUG - 2020-09-16 10:05:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:05:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:05:15 --> Model Class Initialized
INFO - 2020-09-16 10:05:15 --> Model Class Initialized
INFO - 2020-09-16 10:05:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 10:05:15 --> Final output sent to browser
DEBUG - 2020-09-16 10:05:15 --> Total execution time: 0.0202
ERROR - 2020-09-16 10:05:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:05:18 --> Config Class Initialized
INFO - 2020-09-16 10:05:18 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:05:18 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:05:18 --> Utf8 Class Initialized
INFO - 2020-09-16 10:05:18 --> URI Class Initialized
INFO - 2020-09-16 10:05:18 --> Router Class Initialized
INFO - 2020-09-16 10:05:18 --> Output Class Initialized
INFO - 2020-09-16 10:05:18 --> Security Class Initialized
DEBUG - 2020-09-16 10:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:05:18 --> Input Class Initialized
INFO - 2020-09-16 10:05:18 --> Language Class Initialized
INFO - 2020-09-16 10:05:18 --> Loader Class Initialized
INFO - 2020-09-16 10:05:18 --> Helper loaded: url_helper
INFO - 2020-09-16 10:05:18 --> Database Driver Class Initialized
INFO - 2020-09-16 10:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:05:18 --> Email Class Initialized
INFO - 2020-09-16 10:05:18 --> Controller Class Initialized
DEBUG - 2020-09-16 10:05:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:05:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:05:18 --> Model Class Initialized
INFO - 2020-09-16 10:05:18 --> Model Class Initialized
INFO - 2020-09-16 10:05:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_view_for_client.php
INFO - 2020-09-16 10:05:18 --> Final output sent to browser
DEBUG - 2020-09-16 10:05:18 --> Total execution time: 0.0256
ERROR - 2020-09-16 10:09:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:09:01 --> Config Class Initialized
INFO - 2020-09-16 10:09:01 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:09:01 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:09:01 --> Utf8 Class Initialized
INFO - 2020-09-16 10:09:01 --> URI Class Initialized
INFO - 2020-09-16 10:09:01 --> Router Class Initialized
INFO - 2020-09-16 10:09:01 --> Output Class Initialized
INFO - 2020-09-16 10:09:01 --> Security Class Initialized
DEBUG - 2020-09-16 10:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:09:01 --> Input Class Initialized
INFO - 2020-09-16 10:09:01 --> Language Class Initialized
INFO - 2020-09-16 10:09:01 --> Loader Class Initialized
INFO - 2020-09-16 10:09:01 --> Helper loaded: url_helper
INFO - 2020-09-16 10:09:01 --> Database Driver Class Initialized
INFO - 2020-09-16 10:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:09:01 --> Email Class Initialized
INFO - 2020-09-16 10:09:01 --> Controller Class Initialized
DEBUG - 2020-09-16 10:09:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:09:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:09:01 --> Model Class Initialized
INFO - 2020-09-16 10:09:01 --> Model Class Initialized
INFO - 2020-09-16 10:09:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_view_for_client.php
INFO - 2020-09-16 10:09:01 --> Final output sent to browser
DEBUG - 2020-09-16 10:09:01 --> Total execution time: 0.2377
ERROR - 2020-09-16 10:09:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:09:12 --> Config Class Initialized
INFO - 2020-09-16 10:09:12 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:09:12 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:09:12 --> Utf8 Class Initialized
INFO - 2020-09-16 10:09:12 --> URI Class Initialized
INFO - 2020-09-16 10:09:12 --> Router Class Initialized
INFO - 2020-09-16 10:09:12 --> Output Class Initialized
INFO - 2020-09-16 10:09:12 --> Security Class Initialized
DEBUG - 2020-09-16 10:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:09:12 --> Input Class Initialized
INFO - 2020-09-16 10:09:12 --> Language Class Initialized
INFO - 2020-09-16 10:09:12 --> Loader Class Initialized
INFO - 2020-09-16 10:09:12 --> Helper loaded: url_helper
INFO - 2020-09-16 10:09:12 --> Database Driver Class Initialized
INFO - 2020-09-16 10:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:09:12 --> Email Class Initialized
INFO - 2020-09-16 10:09:12 --> Controller Class Initialized
DEBUG - 2020-09-16 10:09:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:09:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:09:12 --> Model Class Initialized
INFO - 2020-09-16 10:09:12 --> Model Class Initialized
INFO - 2020-09-16 10:09:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 10:09:12 --> Final output sent to browser
DEBUG - 2020-09-16 10:09:12 --> Total execution time: 0.0280
ERROR - 2020-09-16 10:09:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:09:17 --> Config Class Initialized
INFO - 2020-09-16 10:09:17 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:09:17 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:09:17 --> Utf8 Class Initialized
INFO - 2020-09-16 10:09:17 --> URI Class Initialized
INFO - 2020-09-16 10:09:17 --> Router Class Initialized
INFO - 2020-09-16 10:09:17 --> Output Class Initialized
INFO - 2020-09-16 10:09:17 --> Security Class Initialized
DEBUG - 2020-09-16 10:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:09:17 --> Input Class Initialized
INFO - 2020-09-16 10:09:17 --> Language Class Initialized
INFO - 2020-09-16 10:09:17 --> Loader Class Initialized
INFO - 2020-09-16 10:09:17 --> Helper loaded: url_helper
INFO - 2020-09-16 10:09:17 --> Database Driver Class Initialized
INFO - 2020-09-16 10:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:09:17 --> Email Class Initialized
INFO - 2020-09-16 10:09:17 --> Controller Class Initialized
DEBUG - 2020-09-16 10:09:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:09:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:09:17 --> Model Class Initialized
INFO - 2020-09-16 10:09:17 --> Model Class Initialized
INFO - 2020-09-16 10:09:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 10:09:17 --> Final output sent to browser
DEBUG - 2020-09-16 10:09:17 --> Total execution time: 0.0331
ERROR - 2020-09-16 10:09:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:09:24 --> Config Class Initialized
INFO - 2020-09-16 10:09:24 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:09:24 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:09:24 --> Utf8 Class Initialized
INFO - 2020-09-16 10:09:24 --> URI Class Initialized
INFO - 2020-09-16 10:09:24 --> Router Class Initialized
INFO - 2020-09-16 10:09:24 --> Output Class Initialized
INFO - 2020-09-16 10:09:24 --> Security Class Initialized
DEBUG - 2020-09-16 10:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:09:24 --> Input Class Initialized
INFO - 2020-09-16 10:09:24 --> Language Class Initialized
INFO - 2020-09-16 10:09:24 --> Loader Class Initialized
INFO - 2020-09-16 10:09:24 --> Helper loaded: url_helper
INFO - 2020-09-16 10:09:24 --> Database Driver Class Initialized
INFO - 2020-09-16 10:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:09:24 --> Email Class Initialized
INFO - 2020-09-16 10:09:24 --> Controller Class Initialized
DEBUG - 2020-09-16 10:09:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:09:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:09:24 --> Model Class Initialized
INFO - 2020-09-16 10:09:24 --> Model Class Initialized
INFO - 2020-09-16 10:09:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_view_for_client.php
INFO - 2020-09-16 10:09:24 --> Final output sent to browser
DEBUG - 2020-09-16 10:09:24 --> Total execution time: 0.0231
ERROR - 2020-09-16 10:09:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:09:25 --> Config Class Initialized
INFO - 2020-09-16 10:09:25 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:09:25 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:09:25 --> Utf8 Class Initialized
INFO - 2020-09-16 10:09:25 --> URI Class Initialized
INFO - 2020-09-16 10:09:25 --> Router Class Initialized
INFO - 2020-09-16 10:09:25 --> Output Class Initialized
INFO - 2020-09-16 10:09:25 --> Security Class Initialized
DEBUG - 2020-09-16 10:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:09:25 --> Input Class Initialized
INFO - 2020-09-16 10:09:25 --> Language Class Initialized
INFO - 2020-09-16 10:09:25 --> Loader Class Initialized
INFO - 2020-09-16 10:09:25 --> Helper loaded: url_helper
INFO - 2020-09-16 10:09:25 --> Database Driver Class Initialized
INFO - 2020-09-16 10:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:09:25 --> Email Class Initialized
INFO - 2020-09-16 10:09:25 --> Controller Class Initialized
DEBUG - 2020-09-16 10:09:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:09:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:09:25 --> Model Class Initialized
INFO - 2020-09-16 10:09:25 --> Model Class Initialized
INFO - 2020-09-16 10:09:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 10:09:25 --> Final output sent to browser
DEBUG - 2020-09-16 10:09:25 --> Total execution time: 0.0293
ERROR - 2020-09-16 10:09:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:09:49 --> Config Class Initialized
INFO - 2020-09-16 10:09:49 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:09:49 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:09:49 --> Utf8 Class Initialized
INFO - 2020-09-16 10:09:49 --> URI Class Initialized
INFO - 2020-09-16 10:09:49 --> Router Class Initialized
INFO - 2020-09-16 10:09:49 --> Output Class Initialized
INFO - 2020-09-16 10:09:49 --> Security Class Initialized
DEBUG - 2020-09-16 10:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:09:49 --> Input Class Initialized
INFO - 2020-09-16 10:09:49 --> Language Class Initialized
INFO - 2020-09-16 10:09:49 --> Loader Class Initialized
INFO - 2020-09-16 10:09:49 --> Helper loaded: url_helper
INFO - 2020-09-16 10:09:49 --> Database Driver Class Initialized
INFO - 2020-09-16 10:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:09:49 --> Email Class Initialized
INFO - 2020-09-16 10:09:49 --> Controller Class Initialized
DEBUG - 2020-09-16 10:09:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:09:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:09:49 --> Model Class Initialized
INFO - 2020-09-16 10:09:49 --> Model Class Initialized
INFO - 2020-09-16 10:09:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_view_for_client.php
INFO - 2020-09-16 10:09:49 --> Final output sent to browser
DEBUG - 2020-09-16 10:09:49 --> Total execution time: 0.0218
ERROR - 2020-09-16 10:10:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:10:32 --> Config Class Initialized
INFO - 2020-09-16 10:10:32 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:10:32 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:10:32 --> Utf8 Class Initialized
INFO - 2020-09-16 10:10:32 --> URI Class Initialized
INFO - 2020-09-16 10:10:32 --> Router Class Initialized
INFO - 2020-09-16 10:10:32 --> Output Class Initialized
INFO - 2020-09-16 10:10:32 --> Security Class Initialized
DEBUG - 2020-09-16 10:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:10:32 --> Input Class Initialized
INFO - 2020-09-16 10:10:32 --> Language Class Initialized
INFO - 2020-09-16 10:10:32 --> Loader Class Initialized
INFO - 2020-09-16 10:10:32 --> Helper loaded: url_helper
INFO - 2020-09-16 10:10:32 --> Database Driver Class Initialized
INFO - 2020-09-16 10:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:10:32 --> Email Class Initialized
INFO - 2020-09-16 10:10:32 --> Controller Class Initialized
DEBUG - 2020-09-16 10:10:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:10:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:10:32 --> Model Class Initialized
INFO - 2020-09-16 10:10:32 --> Model Class Initialized
INFO - 2020-09-16 10:10:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_view_for_client.php
INFO - 2020-09-16 10:10:32 --> Final output sent to browser
DEBUG - 2020-09-16 10:10:32 --> Total execution time: 0.0237
ERROR - 2020-09-16 10:10:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:10:34 --> Config Class Initialized
INFO - 2020-09-16 10:10:34 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:10:34 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:10:34 --> Utf8 Class Initialized
INFO - 2020-09-16 10:10:34 --> URI Class Initialized
INFO - 2020-09-16 10:10:34 --> Router Class Initialized
INFO - 2020-09-16 10:10:34 --> Output Class Initialized
INFO - 2020-09-16 10:10:34 --> Security Class Initialized
DEBUG - 2020-09-16 10:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:10:34 --> Input Class Initialized
INFO - 2020-09-16 10:10:34 --> Language Class Initialized
INFO - 2020-09-16 10:10:34 --> Loader Class Initialized
INFO - 2020-09-16 10:10:34 --> Helper loaded: url_helper
INFO - 2020-09-16 10:10:34 --> Database Driver Class Initialized
INFO - 2020-09-16 10:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:10:34 --> Email Class Initialized
INFO - 2020-09-16 10:10:34 --> Controller Class Initialized
DEBUG - 2020-09-16 10:10:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:10:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:10:34 --> Model Class Initialized
INFO - 2020-09-16 10:10:34 --> Model Class Initialized
INFO - 2020-09-16 10:10:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 10:10:34 --> Final output sent to browser
DEBUG - 2020-09-16 10:10:34 --> Total execution time: 0.0232
ERROR - 2020-09-16 10:13:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:13:55 --> Config Class Initialized
INFO - 2020-09-16 10:13:55 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:13:55 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:13:55 --> Utf8 Class Initialized
INFO - 2020-09-16 10:13:55 --> URI Class Initialized
INFO - 2020-09-16 10:13:55 --> Router Class Initialized
INFO - 2020-09-16 10:13:55 --> Output Class Initialized
INFO - 2020-09-16 10:13:55 --> Security Class Initialized
DEBUG - 2020-09-16 10:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:13:55 --> Input Class Initialized
INFO - 2020-09-16 10:13:55 --> Language Class Initialized
INFO - 2020-09-16 10:13:55 --> Loader Class Initialized
INFO - 2020-09-16 10:13:55 --> Helper loaded: url_helper
INFO - 2020-09-16 10:13:55 --> Database Driver Class Initialized
INFO - 2020-09-16 10:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:13:55 --> Email Class Initialized
INFO - 2020-09-16 10:13:55 --> Controller Class Initialized
DEBUG - 2020-09-16 10:13:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:13:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:13:55 --> Model Class Initialized
INFO - 2020-09-16 10:13:55 --> Model Class Initialized
INFO - 2020-09-16 10:13:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-16 10:13:55 --> Final output sent to browser
DEBUG - 2020-09-16 10:13:55 --> Total execution time: 0.0247
ERROR - 2020-09-16 10:22:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:22:04 --> Config Class Initialized
INFO - 2020-09-16 10:22:04 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:22:04 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:22:04 --> Utf8 Class Initialized
INFO - 2020-09-16 10:22:04 --> URI Class Initialized
INFO - 2020-09-16 10:22:04 --> Router Class Initialized
INFO - 2020-09-16 10:22:04 --> Output Class Initialized
INFO - 2020-09-16 10:22:04 --> Security Class Initialized
DEBUG - 2020-09-16 10:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:22:04 --> Input Class Initialized
INFO - 2020-09-16 10:22:04 --> Language Class Initialized
INFO - 2020-09-16 10:22:04 --> Loader Class Initialized
INFO - 2020-09-16 10:22:04 --> Helper loaded: url_helper
INFO - 2020-09-16 10:22:04 --> Database Driver Class Initialized
INFO - 2020-09-16 10:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:22:04 --> Email Class Initialized
INFO - 2020-09-16 10:22:04 --> Controller Class Initialized
DEBUG - 2020-09-16 10:22:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:22:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:22:04 --> Model Class Initialized
INFO - 2020-09-16 10:22:04 --> Model Class Initialized
INFO - 2020-09-16 10:22:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-16 10:22:04 --> Final output sent to browser
DEBUG - 2020-09-16 10:22:04 --> Total execution time: 0.0249
ERROR - 2020-09-16 10:22:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:22:09 --> Config Class Initialized
INFO - 2020-09-16 10:22:09 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:22:09 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:22:09 --> Utf8 Class Initialized
INFO - 2020-09-16 10:22:09 --> URI Class Initialized
INFO - 2020-09-16 10:22:09 --> Router Class Initialized
INFO - 2020-09-16 10:22:09 --> Output Class Initialized
INFO - 2020-09-16 10:22:09 --> Security Class Initialized
DEBUG - 2020-09-16 10:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:22:09 --> Input Class Initialized
INFO - 2020-09-16 10:22:09 --> Language Class Initialized
INFO - 2020-09-16 10:22:09 --> Loader Class Initialized
INFO - 2020-09-16 10:22:09 --> Helper loaded: url_helper
INFO - 2020-09-16 10:22:09 --> Database Driver Class Initialized
INFO - 2020-09-16 10:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:22:09 --> Email Class Initialized
INFO - 2020-09-16 10:22:09 --> Controller Class Initialized
DEBUG - 2020-09-16 10:22:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:22:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:22:09 --> Model Class Initialized
INFO - 2020-09-16 10:22:09 --> Model Class Initialized
INFO - 2020-09-16 10:22:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 10:22:09 --> Final output sent to browser
DEBUG - 2020-09-16 10:22:09 --> Total execution time: 0.0298
ERROR - 2020-09-16 10:22:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:22:12 --> Config Class Initialized
INFO - 2020-09-16 10:22:12 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:22:12 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:22:12 --> Utf8 Class Initialized
INFO - 2020-09-16 10:22:12 --> URI Class Initialized
INFO - 2020-09-16 10:22:12 --> Router Class Initialized
INFO - 2020-09-16 10:22:12 --> Output Class Initialized
INFO - 2020-09-16 10:22:12 --> Security Class Initialized
DEBUG - 2020-09-16 10:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:22:12 --> Input Class Initialized
INFO - 2020-09-16 10:22:12 --> Language Class Initialized
INFO - 2020-09-16 10:22:12 --> Loader Class Initialized
INFO - 2020-09-16 10:22:12 --> Helper loaded: url_helper
INFO - 2020-09-16 10:22:12 --> Database Driver Class Initialized
INFO - 2020-09-16 10:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:22:12 --> Email Class Initialized
INFO - 2020-09-16 10:22:12 --> Controller Class Initialized
DEBUG - 2020-09-16 10:22:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:22:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:22:12 --> Model Class Initialized
INFO - 2020-09-16 10:22:12 --> Model Class Initialized
INFO - 2020-09-16 10:22:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_edit.php
INFO - 2020-09-16 10:22:12 --> Final output sent to browser
DEBUG - 2020-09-16 10:22:12 --> Total execution time: 0.0268
ERROR - 2020-09-16 10:22:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:22:22 --> Config Class Initialized
INFO - 2020-09-16 10:22:22 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:22:22 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:22:22 --> Utf8 Class Initialized
INFO - 2020-09-16 10:22:22 --> URI Class Initialized
INFO - 2020-09-16 10:22:22 --> Router Class Initialized
INFO - 2020-09-16 10:22:22 --> Output Class Initialized
INFO - 2020-09-16 10:22:22 --> Security Class Initialized
DEBUG - 2020-09-16 10:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:22:22 --> Input Class Initialized
INFO - 2020-09-16 10:22:22 --> Language Class Initialized
INFO - 2020-09-16 10:22:22 --> Loader Class Initialized
INFO - 2020-09-16 10:22:22 --> Helper loaded: url_helper
INFO - 2020-09-16 10:22:22 --> Database Driver Class Initialized
INFO - 2020-09-16 10:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:22:22 --> Email Class Initialized
INFO - 2020-09-16 10:22:22 --> Controller Class Initialized
DEBUG - 2020-09-16 10:22:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:22:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:22:22 --> Model Class Initialized
INFO - 2020-09-16 10:22:22 --> Model Class Initialized
INFO - 2020-09-16 10:22:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 10:22:22 --> Final output sent to browser
DEBUG - 2020-09-16 10:22:22 --> Total execution time: 0.0233
ERROR - 2020-09-16 10:22:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:22:46 --> Config Class Initialized
INFO - 2020-09-16 10:22:46 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:22:46 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:22:46 --> Utf8 Class Initialized
INFO - 2020-09-16 10:22:46 --> URI Class Initialized
INFO - 2020-09-16 10:22:46 --> Router Class Initialized
INFO - 2020-09-16 10:22:46 --> Output Class Initialized
INFO - 2020-09-16 10:22:46 --> Security Class Initialized
DEBUG - 2020-09-16 10:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:22:46 --> Input Class Initialized
INFO - 2020-09-16 10:22:46 --> Language Class Initialized
INFO - 2020-09-16 10:22:46 --> Loader Class Initialized
INFO - 2020-09-16 10:22:46 --> Helper loaded: url_helper
INFO - 2020-09-16 10:22:46 --> Database Driver Class Initialized
INFO - 2020-09-16 10:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:22:46 --> Email Class Initialized
INFO - 2020-09-16 10:22:46 --> Controller Class Initialized
DEBUG - 2020-09-16 10:22:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:22:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:22:46 --> Model Class Initialized
INFO - 2020-09-16 10:22:46 --> Model Class Initialized
INFO - 2020-09-16 10:22:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_edit.php
INFO - 2020-09-16 10:22:46 --> Final output sent to browser
DEBUG - 2020-09-16 10:22:46 --> Total execution time: 0.0258
ERROR - 2020-09-16 10:30:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:30:41 --> Config Class Initialized
INFO - 2020-09-16 10:30:41 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:30:41 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:30:41 --> Utf8 Class Initialized
INFO - 2020-09-16 10:30:41 --> URI Class Initialized
INFO - 2020-09-16 10:30:41 --> Router Class Initialized
INFO - 2020-09-16 10:30:41 --> Output Class Initialized
INFO - 2020-09-16 10:30:41 --> Security Class Initialized
DEBUG - 2020-09-16 10:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:30:41 --> Input Class Initialized
INFO - 2020-09-16 10:30:41 --> Language Class Initialized
INFO - 2020-09-16 10:30:41 --> Loader Class Initialized
INFO - 2020-09-16 10:30:41 --> Helper loaded: url_helper
INFO - 2020-09-16 10:30:41 --> Database Driver Class Initialized
INFO - 2020-09-16 10:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:30:41 --> Email Class Initialized
INFO - 2020-09-16 10:30:41 --> Controller Class Initialized
DEBUG - 2020-09-16 10:30:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:30:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:30:41 --> Model Class Initialized
INFO - 2020-09-16 10:30:41 --> Model Class Initialized
INFO - 2020-09-16 10:30:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_edit.php
INFO - 2020-09-16 10:30:41 --> Final output sent to browser
DEBUG - 2020-09-16 10:30:41 --> Total execution time: 0.0254
ERROR - 2020-09-16 10:31:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:31:42 --> Config Class Initialized
INFO - 2020-09-16 10:31:42 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:31:42 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:31:42 --> Utf8 Class Initialized
INFO - 2020-09-16 10:31:42 --> URI Class Initialized
INFO - 2020-09-16 10:31:42 --> Router Class Initialized
INFO - 2020-09-16 10:31:42 --> Output Class Initialized
INFO - 2020-09-16 10:31:42 --> Security Class Initialized
DEBUG - 2020-09-16 10:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:31:42 --> Input Class Initialized
INFO - 2020-09-16 10:31:42 --> Language Class Initialized
INFO - 2020-09-16 10:31:42 --> Loader Class Initialized
INFO - 2020-09-16 10:31:42 --> Helper loaded: url_helper
INFO - 2020-09-16 10:31:42 --> Database Driver Class Initialized
INFO - 2020-09-16 10:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:31:42 --> Email Class Initialized
INFO - 2020-09-16 10:31:42 --> Controller Class Initialized
DEBUG - 2020-09-16 10:31:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:31:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:31:42 --> Model Class Initialized
INFO - 2020-09-16 10:31:42 --> Model Class Initialized
INFO - 2020-09-16 10:31:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_edit.php
INFO - 2020-09-16 10:31:42 --> Final output sent to browser
DEBUG - 2020-09-16 10:31:42 --> Total execution time: 0.1426
ERROR - 2020-09-16 10:36:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:36:19 --> Config Class Initialized
INFO - 2020-09-16 10:36:19 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:36:19 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:36:19 --> Utf8 Class Initialized
INFO - 2020-09-16 10:36:19 --> URI Class Initialized
INFO - 2020-09-16 10:36:19 --> Router Class Initialized
INFO - 2020-09-16 10:36:19 --> Output Class Initialized
INFO - 2020-09-16 10:36:19 --> Security Class Initialized
DEBUG - 2020-09-16 10:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:36:19 --> Input Class Initialized
INFO - 2020-09-16 10:36:19 --> Language Class Initialized
INFO - 2020-09-16 10:36:19 --> Loader Class Initialized
INFO - 2020-09-16 10:36:19 --> Helper loaded: url_helper
INFO - 2020-09-16 10:36:19 --> Database Driver Class Initialized
INFO - 2020-09-16 10:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:36:19 --> Email Class Initialized
INFO - 2020-09-16 10:36:19 --> Controller Class Initialized
DEBUG - 2020-09-16 10:36:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:36:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:36:19 --> Model Class Initialized
INFO - 2020-09-16 10:36:19 --> Model Class Initialized
INFO - 2020-09-16 10:36:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_edit.php
INFO - 2020-09-16 10:36:19 --> Final output sent to browser
DEBUG - 2020-09-16 10:36:19 --> Total execution time: 0.0234
ERROR - 2020-09-16 10:36:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:36:23 --> Config Class Initialized
INFO - 2020-09-16 10:36:23 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:36:23 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:36:23 --> Utf8 Class Initialized
INFO - 2020-09-16 10:36:23 --> URI Class Initialized
INFO - 2020-09-16 10:36:23 --> Router Class Initialized
INFO - 2020-09-16 10:36:23 --> Output Class Initialized
INFO - 2020-09-16 10:36:23 --> Security Class Initialized
DEBUG - 2020-09-16 10:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:36:23 --> Input Class Initialized
INFO - 2020-09-16 10:36:23 --> Language Class Initialized
INFO - 2020-09-16 10:36:23 --> Loader Class Initialized
INFO - 2020-09-16 10:36:23 --> Helper loaded: url_helper
INFO - 2020-09-16 10:36:23 --> Database Driver Class Initialized
INFO - 2020-09-16 10:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:36:23 --> Email Class Initialized
INFO - 2020-09-16 10:36:23 --> Controller Class Initialized
DEBUG - 2020-09-16 10:36:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:36:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:36:23 --> Model Class Initialized
INFO - 2020-09-16 10:36:23 --> Model Class Initialized
INFO - 2020-09-16 10:36:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 10:36:23 --> Final output sent to browser
DEBUG - 2020-09-16 10:36:23 --> Total execution time: 0.0271
ERROR - 2020-09-16 10:39:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:39:33 --> Config Class Initialized
INFO - 2020-09-16 10:39:33 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:39:33 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:39:33 --> Utf8 Class Initialized
INFO - 2020-09-16 10:39:33 --> URI Class Initialized
INFO - 2020-09-16 10:39:33 --> Router Class Initialized
INFO - 2020-09-16 10:39:33 --> Output Class Initialized
INFO - 2020-09-16 10:39:33 --> Security Class Initialized
DEBUG - 2020-09-16 10:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:39:33 --> Input Class Initialized
INFO - 2020-09-16 10:39:33 --> Language Class Initialized
INFO - 2020-09-16 10:39:33 --> Loader Class Initialized
INFO - 2020-09-16 10:39:33 --> Helper loaded: url_helper
INFO - 2020-09-16 10:39:33 --> Database Driver Class Initialized
INFO - 2020-09-16 10:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:39:33 --> Email Class Initialized
INFO - 2020-09-16 10:39:33 --> Controller Class Initialized
DEBUG - 2020-09-16 10:39:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:39:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:39:33 --> Model Class Initialized
INFO - 2020-09-16 10:39:33 --> Model Class Initialized
INFO - 2020-09-16 10:39:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 10:39:33 --> Final output sent to browser
DEBUG - 2020-09-16 10:39:33 --> Total execution time: 0.0268
ERROR - 2020-09-16 10:39:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:39:37 --> Config Class Initialized
INFO - 2020-09-16 10:39:37 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:39:37 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:39:37 --> Utf8 Class Initialized
INFO - 2020-09-16 10:39:37 --> URI Class Initialized
INFO - 2020-09-16 10:39:37 --> Router Class Initialized
INFO - 2020-09-16 10:39:37 --> Output Class Initialized
INFO - 2020-09-16 10:39:37 --> Security Class Initialized
DEBUG - 2020-09-16 10:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:39:37 --> Input Class Initialized
INFO - 2020-09-16 10:39:37 --> Language Class Initialized
INFO - 2020-09-16 10:39:37 --> Loader Class Initialized
INFO - 2020-09-16 10:39:37 --> Helper loaded: url_helper
INFO - 2020-09-16 10:39:37 --> Database Driver Class Initialized
INFO - 2020-09-16 10:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:39:37 --> Email Class Initialized
INFO - 2020-09-16 10:39:37 --> Controller Class Initialized
DEBUG - 2020-09-16 10:39:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:39:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:39:37 --> Model Class Initialized
INFO - 2020-09-16 10:39:37 --> Model Class Initialized
INFO - 2020-09-16 10:39:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 10:39:37 --> Final output sent to browser
DEBUG - 2020-09-16 10:39:37 --> Total execution time: 0.0191
ERROR - 2020-09-16 10:39:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:39:42 --> Config Class Initialized
INFO - 2020-09-16 10:39:42 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:39:42 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:39:42 --> Utf8 Class Initialized
INFO - 2020-09-16 10:39:42 --> URI Class Initialized
INFO - 2020-09-16 10:39:42 --> Router Class Initialized
INFO - 2020-09-16 10:39:42 --> Output Class Initialized
INFO - 2020-09-16 10:39:42 --> Security Class Initialized
DEBUG - 2020-09-16 10:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:39:42 --> Input Class Initialized
INFO - 2020-09-16 10:39:42 --> Language Class Initialized
INFO - 2020-09-16 10:39:42 --> Loader Class Initialized
INFO - 2020-09-16 10:39:42 --> Helper loaded: url_helper
INFO - 2020-09-16 10:39:42 --> Database Driver Class Initialized
INFO - 2020-09-16 10:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:39:42 --> Email Class Initialized
INFO - 2020-09-16 10:39:42 --> Controller Class Initialized
DEBUG - 2020-09-16 10:39:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:39:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:39:42 --> Model Class Initialized
INFO - 2020-09-16 10:39:42 --> Model Class Initialized
INFO - 2020-09-16 10:39:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 10:39:42 --> Final output sent to browser
DEBUG - 2020-09-16 10:39:42 --> Total execution time: 0.0223
ERROR - 2020-09-16 10:39:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:39:55 --> Config Class Initialized
INFO - 2020-09-16 10:39:55 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:39:55 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:39:55 --> Utf8 Class Initialized
INFO - 2020-09-16 10:39:55 --> URI Class Initialized
INFO - 2020-09-16 10:39:55 --> Router Class Initialized
INFO - 2020-09-16 10:39:55 --> Output Class Initialized
INFO - 2020-09-16 10:39:55 --> Security Class Initialized
DEBUG - 2020-09-16 10:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:39:55 --> Input Class Initialized
INFO - 2020-09-16 10:39:55 --> Language Class Initialized
INFO - 2020-09-16 10:39:55 --> Loader Class Initialized
INFO - 2020-09-16 10:39:55 --> Helper loaded: url_helper
INFO - 2020-09-16 10:39:55 --> Database Driver Class Initialized
INFO - 2020-09-16 10:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:39:55 --> Email Class Initialized
INFO - 2020-09-16 10:39:55 --> Controller Class Initialized
DEBUG - 2020-09-16 10:39:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:39:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:39:55 --> Model Class Initialized
INFO - 2020-09-16 10:39:55 --> Model Class Initialized
INFO - 2020-09-16 10:39:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_edit.php
INFO - 2020-09-16 10:39:55 --> Final output sent to browser
DEBUG - 2020-09-16 10:39:55 --> Total execution time: 0.0290
ERROR - 2020-09-16 10:39:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:39:59 --> Config Class Initialized
INFO - 2020-09-16 10:39:59 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:39:59 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:39:59 --> Utf8 Class Initialized
INFO - 2020-09-16 10:39:59 --> URI Class Initialized
INFO - 2020-09-16 10:39:59 --> Router Class Initialized
INFO - 2020-09-16 10:39:59 --> Output Class Initialized
INFO - 2020-09-16 10:39:59 --> Security Class Initialized
DEBUG - 2020-09-16 10:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:39:59 --> Input Class Initialized
INFO - 2020-09-16 10:39:59 --> Language Class Initialized
INFO - 2020-09-16 10:39:59 --> Loader Class Initialized
INFO - 2020-09-16 10:39:59 --> Helper loaded: url_helper
INFO - 2020-09-16 10:40:00 --> Database Driver Class Initialized
INFO - 2020-09-16 10:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:40:00 --> Email Class Initialized
INFO - 2020-09-16 10:40:00 --> Controller Class Initialized
DEBUG - 2020-09-16 10:40:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:40:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:40:00 --> Model Class Initialized
INFO - 2020-09-16 10:40:00 --> Model Class Initialized
INFO - 2020-09-16 10:40:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 10:40:00 --> Final output sent to browser
DEBUG - 2020-09-16 10:40:00 --> Total execution time: 0.0231
ERROR - 2020-09-16 10:40:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:40:04 --> Config Class Initialized
INFO - 2020-09-16 10:40:04 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:40:04 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:40:04 --> Utf8 Class Initialized
INFO - 2020-09-16 10:40:04 --> URI Class Initialized
INFO - 2020-09-16 10:40:04 --> Router Class Initialized
INFO - 2020-09-16 10:40:04 --> Output Class Initialized
INFO - 2020-09-16 10:40:04 --> Security Class Initialized
DEBUG - 2020-09-16 10:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:40:04 --> Input Class Initialized
INFO - 2020-09-16 10:40:04 --> Language Class Initialized
INFO - 2020-09-16 10:40:04 --> Loader Class Initialized
INFO - 2020-09-16 10:40:04 --> Helper loaded: url_helper
INFO - 2020-09-16 10:40:04 --> Database Driver Class Initialized
INFO - 2020-09-16 10:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:40:04 --> Email Class Initialized
INFO - 2020-09-16 10:40:04 --> Controller Class Initialized
DEBUG - 2020-09-16 10:40:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:40:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:40:04 --> Model Class Initialized
INFO - 2020-09-16 10:40:04 --> Model Class Initialized
INFO - 2020-09-16 10:40:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 10:40:04 --> Final output sent to browser
DEBUG - 2020-09-16 10:40:04 --> Total execution time: 0.0227
ERROR - 2020-09-16 10:40:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:40:10 --> Config Class Initialized
INFO - 2020-09-16 10:40:10 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:40:10 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:40:10 --> Utf8 Class Initialized
INFO - 2020-09-16 10:40:10 --> URI Class Initialized
INFO - 2020-09-16 10:40:10 --> Router Class Initialized
INFO - 2020-09-16 10:40:10 --> Output Class Initialized
INFO - 2020-09-16 10:40:10 --> Security Class Initialized
DEBUG - 2020-09-16 10:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:40:10 --> Input Class Initialized
INFO - 2020-09-16 10:40:10 --> Language Class Initialized
INFO - 2020-09-16 10:40:10 --> Loader Class Initialized
INFO - 2020-09-16 10:40:10 --> Helper loaded: url_helper
INFO - 2020-09-16 10:40:10 --> Database Driver Class Initialized
INFO - 2020-09-16 10:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:40:10 --> Email Class Initialized
INFO - 2020-09-16 10:40:10 --> Controller Class Initialized
DEBUG - 2020-09-16 10:40:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:40:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:40:10 --> Model Class Initialized
INFO - 2020-09-16 10:40:10 --> Model Class Initialized
INFO - 2020-09-16 10:40:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 10:40:10 --> Final output sent to browser
DEBUG - 2020-09-16 10:40:10 --> Total execution time: 0.0191
ERROR - 2020-09-16 10:42:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:42:45 --> Config Class Initialized
INFO - 2020-09-16 10:42:45 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:42:45 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:42:45 --> Utf8 Class Initialized
INFO - 2020-09-16 10:42:45 --> URI Class Initialized
INFO - 2020-09-16 10:42:45 --> Router Class Initialized
INFO - 2020-09-16 10:42:45 --> Output Class Initialized
INFO - 2020-09-16 10:42:45 --> Security Class Initialized
DEBUG - 2020-09-16 10:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:42:45 --> Input Class Initialized
INFO - 2020-09-16 10:42:45 --> Language Class Initialized
INFO - 2020-09-16 10:42:45 --> Loader Class Initialized
INFO - 2020-09-16 10:42:45 --> Helper loaded: url_helper
INFO - 2020-09-16 10:42:45 --> Database Driver Class Initialized
INFO - 2020-09-16 10:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:42:45 --> Email Class Initialized
INFO - 2020-09-16 10:42:45 --> Controller Class Initialized
DEBUG - 2020-09-16 10:42:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:42:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:42:45 --> Model Class Initialized
INFO - 2020-09-16 10:42:45 --> Model Class Initialized
INFO - 2020-09-16 10:42:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 10:42:45 --> Final output sent to browser
DEBUG - 2020-09-16 10:42:45 --> Total execution time: 0.0238
ERROR - 2020-09-16 10:43:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:43:18 --> Config Class Initialized
INFO - 2020-09-16 10:43:18 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:43:18 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:43:18 --> Utf8 Class Initialized
INFO - 2020-09-16 10:43:18 --> URI Class Initialized
INFO - 2020-09-16 10:43:18 --> Router Class Initialized
INFO - 2020-09-16 10:43:18 --> Output Class Initialized
INFO - 2020-09-16 10:43:18 --> Security Class Initialized
DEBUG - 2020-09-16 10:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:43:18 --> Input Class Initialized
INFO - 2020-09-16 10:43:18 --> Language Class Initialized
INFO - 2020-09-16 10:43:18 --> Loader Class Initialized
INFO - 2020-09-16 10:43:18 --> Helper loaded: url_helper
INFO - 2020-09-16 10:43:19 --> Database Driver Class Initialized
INFO - 2020-09-16 10:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:43:19 --> Email Class Initialized
INFO - 2020-09-16 10:43:19 --> Controller Class Initialized
DEBUG - 2020-09-16 10:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:43:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:43:19 --> Model Class Initialized
INFO - 2020-09-16 10:43:19 --> Model Class Initialized
INFO - 2020-09-16 10:43:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 10:43:19 --> Final output sent to browser
DEBUG - 2020-09-16 10:43:19 --> Total execution time: 0.0222
ERROR - 2020-09-16 10:43:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:43:33 --> Config Class Initialized
INFO - 2020-09-16 10:43:33 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:43:33 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:43:33 --> Utf8 Class Initialized
INFO - 2020-09-16 10:43:33 --> URI Class Initialized
INFO - 2020-09-16 10:43:33 --> Router Class Initialized
INFO - 2020-09-16 10:43:33 --> Output Class Initialized
INFO - 2020-09-16 10:43:33 --> Security Class Initialized
DEBUG - 2020-09-16 10:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:43:33 --> Input Class Initialized
INFO - 2020-09-16 10:43:33 --> Language Class Initialized
INFO - 2020-09-16 10:43:33 --> Loader Class Initialized
INFO - 2020-09-16 10:43:33 --> Helper loaded: url_helper
INFO - 2020-09-16 10:43:33 --> Database Driver Class Initialized
INFO - 2020-09-16 10:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:43:33 --> Email Class Initialized
INFO - 2020-09-16 10:43:33 --> Controller Class Initialized
DEBUG - 2020-09-16 10:43:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:43:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:43:33 --> Model Class Initialized
INFO - 2020-09-16 10:43:33 --> Model Class Initialized
INFO - 2020-09-16 10:43:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-16 10:43:33 --> Final output sent to browser
DEBUG - 2020-09-16 10:43:33 --> Total execution time: 0.0245
ERROR - 2020-09-16 10:43:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:43:37 --> Config Class Initialized
INFO - 2020-09-16 10:43:37 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:43:37 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:43:37 --> Utf8 Class Initialized
INFO - 2020-09-16 10:43:37 --> URI Class Initialized
INFO - 2020-09-16 10:43:37 --> Router Class Initialized
INFO - 2020-09-16 10:43:37 --> Output Class Initialized
INFO - 2020-09-16 10:43:37 --> Security Class Initialized
DEBUG - 2020-09-16 10:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:43:37 --> Input Class Initialized
INFO - 2020-09-16 10:43:37 --> Language Class Initialized
INFO - 2020-09-16 10:43:37 --> Loader Class Initialized
INFO - 2020-09-16 10:43:37 --> Helper loaded: url_helper
INFO - 2020-09-16 10:43:37 --> Database Driver Class Initialized
INFO - 2020-09-16 10:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:43:37 --> Email Class Initialized
INFO - 2020-09-16 10:43:37 --> Controller Class Initialized
DEBUG - 2020-09-16 10:43:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:43:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:43:37 --> Model Class Initialized
INFO - 2020-09-16 10:43:37 --> Model Class Initialized
INFO - 2020-09-16 10:43:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-16 10:43:37 --> Final output sent to browser
DEBUG - 2020-09-16 10:43:37 --> Total execution time: 0.0348
ERROR - 2020-09-16 10:43:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:43:56 --> Config Class Initialized
INFO - 2020-09-16 10:43:56 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:43:56 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:43:56 --> Utf8 Class Initialized
INFO - 2020-09-16 10:43:56 --> URI Class Initialized
INFO - 2020-09-16 10:43:56 --> Router Class Initialized
INFO - 2020-09-16 10:43:56 --> Output Class Initialized
INFO - 2020-09-16 10:43:56 --> Security Class Initialized
DEBUG - 2020-09-16 10:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:43:56 --> Input Class Initialized
INFO - 2020-09-16 10:43:56 --> Language Class Initialized
INFO - 2020-09-16 10:43:56 --> Loader Class Initialized
INFO - 2020-09-16 10:43:56 --> Helper loaded: url_helper
INFO - 2020-09-16 10:43:56 --> Database Driver Class Initialized
INFO - 2020-09-16 10:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:43:56 --> Email Class Initialized
INFO - 2020-09-16 10:43:56 --> Controller Class Initialized
DEBUG - 2020-09-16 10:43:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:43:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:43:56 --> Model Class Initialized
INFO - 2020-09-16 10:43:56 --> Model Class Initialized
INFO - 2020-09-16 10:43:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-16 10:43:56 --> Final output sent to browser
DEBUG - 2020-09-16 10:43:56 --> Total execution time: 0.0234
ERROR - 2020-09-16 10:44:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:44:00 --> Config Class Initialized
INFO - 2020-09-16 10:44:00 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:44:00 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:44:00 --> Utf8 Class Initialized
INFO - 2020-09-16 10:44:00 --> URI Class Initialized
INFO - 2020-09-16 10:44:00 --> Router Class Initialized
INFO - 2020-09-16 10:44:00 --> Output Class Initialized
INFO - 2020-09-16 10:44:00 --> Security Class Initialized
DEBUG - 2020-09-16 10:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:44:00 --> Input Class Initialized
INFO - 2020-09-16 10:44:00 --> Language Class Initialized
INFO - 2020-09-16 10:44:00 --> Loader Class Initialized
INFO - 2020-09-16 10:44:00 --> Helper loaded: url_helper
INFO - 2020-09-16 10:44:00 --> Database Driver Class Initialized
INFO - 2020-09-16 10:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:44:00 --> Email Class Initialized
INFO - 2020-09-16 10:44:00 --> Controller Class Initialized
DEBUG - 2020-09-16 10:44:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:44:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:44:00 --> Model Class Initialized
INFO - 2020-09-16 10:44:00 --> Model Class Initialized
INFO - 2020-09-16 10:44:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 10:44:00 --> Final output sent to browser
DEBUG - 2020-09-16 10:44:00 --> Total execution time: 0.0233
ERROR - 2020-09-16 10:44:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:44:03 --> Config Class Initialized
INFO - 2020-09-16 10:44:03 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:44:03 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:44:03 --> Utf8 Class Initialized
INFO - 2020-09-16 10:44:03 --> URI Class Initialized
INFO - 2020-09-16 10:44:03 --> Router Class Initialized
INFO - 2020-09-16 10:44:03 --> Output Class Initialized
INFO - 2020-09-16 10:44:03 --> Security Class Initialized
DEBUG - 2020-09-16 10:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:44:03 --> Input Class Initialized
INFO - 2020-09-16 10:44:03 --> Language Class Initialized
INFO - 2020-09-16 10:44:03 --> Loader Class Initialized
INFO - 2020-09-16 10:44:03 --> Helper loaded: url_helper
INFO - 2020-09-16 10:44:03 --> Database Driver Class Initialized
INFO - 2020-09-16 10:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:44:03 --> Email Class Initialized
INFO - 2020-09-16 10:44:03 --> Controller Class Initialized
DEBUG - 2020-09-16 10:44:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:44:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:44:03 --> Model Class Initialized
INFO - 2020-09-16 10:44:03 --> Model Class Initialized
INFO - 2020-09-16 10:44:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 10:44:03 --> Final output sent to browser
DEBUG - 2020-09-16 10:44:03 --> Total execution time: 0.0240
ERROR - 2020-09-16 10:44:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:44:06 --> Config Class Initialized
INFO - 2020-09-16 10:44:06 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:44:06 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:44:06 --> Utf8 Class Initialized
INFO - 2020-09-16 10:44:06 --> URI Class Initialized
INFO - 2020-09-16 10:44:06 --> Router Class Initialized
INFO - 2020-09-16 10:44:06 --> Output Class Initialized
INFO - 2020-09-16 10:44:06 --> Security Class Initialized
DEBUG - 2020-09-16 10:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:44:06 --> Input Class Initialized
INFO - 2020-09-16 10:44:06 --> Language Class Initialized
INFO - 2020-09-16 10:44:06 --> Loader Class Initialized
INFO - 2020-09-16 10:44:06 --> Helper loaded: url_helper
INFO - 2020-09-16 10:44:06 --> Database Driver Class Initialized
INFO - 2020-09-16 10:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:44:06 --> Email Class Initialized
INFO - 2020-09-16 10:44:06 --> Controller Class Initialized
DEBUG - 2020-09-16 10:44:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:44:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:44:06 --> Model Class Initialized
INFO - 2020-09-16 10:44:06 --> Model Class Initialized
INFO - 2020-09-16 10:44:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-16 10:44:06 --> Final output sent to browser
DEBUG - 2020-09-16 10:44:06 --> Total execution time: 0.0256
ERROR - 2020-09-16 10:44:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:44:09 --> Config Class Initialized
INFO - 2020-09-16 10:44:09 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:44:09 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:44:09 --> Utf8 Class Initialized
INFO - 2020-09-16 10:44:09 --> URI Class Initialized
INFO - 2020-09-16 10:44:09 --> Router Class Initialized
INFO - 2020-09-16 10:44:09 --> Output Class Initialized
INFO - 2020-09-16 10:44:09 --> Security Class Initialized
DEBUG - 2020-09-16 10:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:44:09 --> Input Class Initialized
INFO - 2020-09-16 10:44:09 --> Language Class Initialized
INFO - 2020-09-16 10:44:09 --> Loader Class Initialized
INFO - 2020-09-16 10:44:09 --> Helper loaded: url_helper
INFO - 2020-09-16 10:44:09 --> Database Driver Class Initialized
INFO - 2020-09-16 10:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:44:09 --> Email Class Initialized
INFO - 2020-09-16 10:44:09 --> Controller Class Initialized
DEBUG - 2020-09-16 10:44:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:44:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:44:09 --> Model Class Initialized
INFO - 2020-09-16 10:44:09 --> Model Class Initialized
INFO - 2020-09-16 10:44:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 10:44:09 --> Final output sent to browser
DEBUG - 2020-09-16 10:44:09 --> Total execution time: 0.0282
ERROR - 2020-09-16 10:44:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:44:11 --> Config Class Initialized
INFO - 2020-09-16 10:44:11 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:44:11 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:44:11 --> Utf8 Class Initialized
INFO - 2020-09-16 10:44:11 --> URI Class Initialized
INFO - 2020-09-16 10:44:11 --> Router Class Initialized
INFO - 2020-09-16 10:44:11 --> Output Class Initialized
INFO - 2020-09-16 10:44:11 --> Security Class Initialized
DEBUG - 2020-09-16 10:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:44:11 --> Input Class Initialized
INFO - 2020-09-16 10:44:11 --> Language Class Initialized
INFO - 2020-09-16 10:44:11 --> Loader Class Initialized
INFO - 2020-09-16 10:44:11 --> Helper loaded: url_helper
INFO - 2020-09-16 10:44:11 --> Database Driver Class Initialized
INFO - 2020-09-16 10:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:44:11 --> Email Class Initialized
INFO - 2020-09-16 10:44:11 --> Controller Class Initialized
DEBUG - 2020-09-16 10:44:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:44:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:44:11 --> Model Class Initialized
INFO - 2020-09-16 10:44:11 --> Model Class Initialized
INFO - 2020-09-16 10:44:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_view_for_client.php
INFO - 2020-09-16 10:44:11 --> Final output sent to browser
DEBUG - 2020-09-16 10:44:11 --> Total execution time: 0.0254
ERROR - 2020-09-16 10:44:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:44:13 --> Config Class Initialized
INFO - 2020-09-16 10:44:13 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:44:13 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:44:13 --> Utf8 Class Initialized
INFO - 2020-09-16 10:44:13 --> URI Class Initialized
INFO - 2020-09-16 10:44:13 --> Router Class Initialized
INFO - 2020-09-16 10:44:13 --> Output Class Initialized
INFO - 2020-09-16 10:44:13 --> Security Class Initialized
DEBUG - 2020-09-16 10:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:44:13 --> Input Class Initialized
INFO - 2020-09-16 10:44:13 --> Language Class Initialized
INFO - 2020-09-16 10:44:13 --> Loader Class Initialized
INFO - 2020-09-16 10:44:13 --> Helper loaded: url_helper
INFO - 2020-09-16 10:44:13 --> Database Driver Class Initialized
INFO - 2020-09-16 10:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:44:13 --> Email Class Initialized
INFO - 2020-09-16 10:44:13 --> Controller Class Initialized
DEBUG - 2020-09-16 10:44:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:44:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:44:13 --> Model Class Initialized
INFO - 2020-09-16 10:44:13 --> Model Class Initialized
INFO - 2020-09-16 10:44:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 10:44:13 --> Final output sent to browser
DEBUG - 2020-09-16 10:44:13 --> Total execution time: 0.0290
ERROR - 2020-09-16 10:44:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:44:15 --> Config Class Initialized
INFO - 2020-09-16 10:44:15 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:44:15 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:44:15 --> Utf8 Class Initialized
INFO - 2020-09-16 10:44:15 --> URI Class Initialized
INFO - 2020-09-16 10:44:15 --> Router Class Initialized
INFO - 2020-09-16 10:44:15 --> Output Class Initialized
INFO - 2020-09-16 10:44:15 --> Security Class Initialized
DEBUG - 2020-09-16 10:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:44:15 --> Input Class Initialized
INFO - 2020-09-16 10:44:15 --> Language Class Initialized
INFO - 2020-09-16 10:44:15 --> Loader Class Initialized
INFO - 2020-09-16 10:44:15 --> Helper loaded: url_helper
INFO - 2020-09-16 10:44:15 --> Database Driver Class Initialized
INFO - 2020-09-16 10:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:44:15 --> Email Class Initialized
INFO - 2020-09-16 10:44:15 --> Controller Class Initialized
DEBUG - 2020-09-16 10:44:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:44:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:44:15 --> Model Class Initialized
INFO - 2020-09-16 10:44:15 --> Model Class Initialized
INFO - 2020-09-16 10:44:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_edit.php
INFO - 2020-09-16 10:44:15 --> Final output sent to browser
DEBUG - 2020-09-16 10:44:15 --> Total execution time: 0.0229
ERROR - 2020-09-16 10:44:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:44:18 --> Config Class Initialized
INFO - 2020-09-16 10:44:18 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:44:18 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:44:18 --> Utf8 Class Initialized
INFO - 2020-09-16 10:44:18 --> URI Class Initialized
INFO - 2020-09-16 10:44:18 --> Router Class Initialized
INFO - 2020-09-16 10:44:18 --> Output Class Initialized
INFO - 2020-09-16 10:44:18 --> Security Class Initialized
DEBUG - 2020-09-16 10:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:44:18 --> Input Class Initialized
INFO - 2020-09-16 10:44:18 --> Language Class Initialized
INFO - 2020-09-16 10:44:18 --> Loader Class Initialized
INFO - 2020-09-16 10:44:18 --> Helper loaded: url_helper
INFO - 2020-09-16 10:44:18 --> Database Driver Class Initialized
INFO - 2020-09-16 10:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:44:18 --> Email Class Initialized
INFO - 2020-09-16 10:44:18 --> Controller Class Initialized
DEBUG - 2020-09-16 10:44:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:44:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:44:18 --> Model Class Initialized
INFO - 2020-09-16 10:44:18 --> Model Class Initialized
INFO - 2020-09-16 10:44:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 10:44:18 --> Final output sent to browser
DEBUG - 2020-09-16 10:44:18 --> Total execution time: 0.0393
ERROR - 2020-09-16 10:44:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:44:22 --> Config Class Initialized
INFO - 2020-09-16 10:44:22 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:44:22 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:44:22 --> Utf8 Class Initialized
INFO - 2020-09-16 10:44:22 --> URI Class Initialized
INFO - 2020-09-16 10:44:22 --> Router Class Initialized
INFO - 2020-09-16 10:44:22 --> Output Class Initialized
INFO - 2020-09-16 10:44:22 --> Security Class Initialized
DEBUG - 2020-09-16 10:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:44:22 --> Input Class Initialized
INFO - 2020-09-16 10:44:22 --> Language Class Initialized
INFO - 2020-09-16 10:44:22 --> Loader Class Initialized
INFO - 2020-09-16 10:44:22 --> Helper loaded: url_helper
INFO - 2020-09-16 10:44:22 --> Database Driver Class Initialized
INFO - 2020-09-16 10:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:44:22 --> Email Class Initialized
INFO - 2020-09-16 10:44:22 --> Controller Class Initialized
DEBUG - 2020-09-16 10:44:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:44:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:44:22 --> Model Class Initialized
INFO - 2020-09-16 10:44:22 --> Model Class Initialized
INFO - 2020-09-16 10:44:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-16 10:44:22 --> Final output sent to browser
DEBUG - 2020-09-16 10:44:22 --> Total execution time: 0.1339
ERROR - 2020-09-16 10:46:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:46:20 --> Config Class Initialized
INFO - 2020-09-16 10:46:20 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:46:20 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:46:20 --> Utf8 Class Initialized
INFO - 2020-09-16 10:46:20 --> URI Class Initialized
INFO - 2020-09-16 10:46:20 --> Router Class Initialized
INFO - 2020-09-16 10:46:20 --> Output Class Initialized
INFO - 2020-09-16 10:46:20 --> Security Class Initialized
DEBUG - 2020-09-16 10:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:46:20 --> Input Class Initialized
INFO - 2020-09-16 10:46:20 --> Language Class Initialized
INFO - 2020-09-16 10:46:20 --> Loader Class Initialized
INFO - 2020-09-16 10:46:20 --> Helper loaded: url_helper
INFO - 2020-09-16 10:46:20 --> Database Driver Class Initialized
INFO - 2020-09-16 10:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:46:20 --> Email Class Initialized
INFO - 2020-09-16 10:46:20 --> Controller Class Initialized
DEBUG - 2020-09-16 10:46:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:46:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:46:20 --> Model Class Initialized
INFO - 2020-09-16 10:46:20 --> Model Class Initialized
INFO - 2020-09-16 10:46:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-16 10:46:20 --> Final output sent to browser
DEBUG - 2020-09-16 10:46:20 --> Total execution time: 0.0205
ERROR - 2020-09-16 10:46:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:46:23 --> Config Class Initialized
INFO - 2020-09-16 10:46:23 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:46:23 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:46:23 --> Utf8 Class Initialized
INFO - 2020-09-16 10:46:23 --> URI Class Initialized
INFO - 2020-09-16 10:46:23 --> Router Class Initialized
INFO - 2020-09-16 10:46:23 --> Output Class Initialized
INFO - 2020-09-16 10:46:23 --> Security Class Initialized
DEBUG - 2020-09-16 10:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:46:23 --> Input Class Initialized
INFO - 2020-09-16 10:46:23 --> Language Class Initialized
INFO - 2020-09-16 10:46:23 --> Loader Class Initialized
INFO - 2020-09-16 10:46:23 --> Helper loaded: url_helper
INFO - 2020-09-16 10:46:23 --> Database Driver Class Initialized
INFO - 2020-09-16 10:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:46:23 --> Email Class Initialized
INFO - 2020-09-16 10:46:23 --> Controller Class Initialized
DEBUG - 2020-09-16 10:46:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:46:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:46:23 --> Model Class Initialized
INFO - 2020-09-16 10:46:23 --> Model Class Initialized
INFO - 2020-09-16 10:46:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-09-16 10:46:23 --> Final output sent to browser
DEBUG - 2020-09-16 10:46:23 --> Total execution time: 0.0180
ERROR - 2020-09-16 10:46:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:46:25 --> Config Class Initialized
INFO - 2020-09-16 10:46:25 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:46:25 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:46:25 --> Utf8 Class Initialized
INFO - 2020-09-16 10:46:25 --> URI Class Initialized
INFO - 2020-09-16 10:46:25 --> Router Class Initialized
INFO - 2020-09-16 10:46:25 --> Output Class Initialized
INFO - 2020-09-16 10:46:25 --> Security Class Initialized
DEBUG - 2020-09-16 10:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:46:25 --> Input Class Initialized
INFO - 2020-09-16 10:46:25 --> Language Class Initialized
INFO - 2020-09-16 10:46:25 --> Loader Class Initialized
INFO - 2020-09-16 10:46:25 --> Helper loaded: url_helper
INFO - 2020-09-16 10:46:25 --> Database Driver Class Initialized
INFO - 2020-09-16 10:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:46:25 --> Email Class Initialized
INFO - 2020-09-16 10:46:25 --> Controller Class Initialized
DEBUG - 2020-09-16 10:46:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:46:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:46:25 --> Model Class Initialized
INFO - 2020-09-16 10:46:25 --> Model Class Initialized
INFO - 2020-09-16 10:46:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-16 10:46:25 --> Final output sent to browser
DEBUG - 2020-09-16 10:46:25 --> Total execution time: 0.0224
ERROR - 2020-09-16 10:46:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:46:27 --> Config Class Initialized
INFO - 2020-09-16 10:46:27 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:46:27 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:46:27 --> Utf8 Class Initialized
INFO - 2020-09-16 10:46:27 --> URI Class Initialized
INFO - 2020-09-16 10:46:27 --> Router Class Initialized
INFO - 2020-09-16 10:46:27 --> Output Class Initialized
INFO - 2020-09-16 10:46:27 --> Security Class Initialized
DEBUG - 2020-09-16 10:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:46:27 --> Input Class Initialized
INFO - 2020-09-16 10:46:27 --> Language Class Initialized
INFO - 2020-09-16 10:46:27 --> Loader Class Initialized
INFO - 2020-09-16 10:46:27 --> Helper loaded: url_helper
INFO - 2020-09-16 10:46:27 --> Database Driver Class Initialized
INFO - 2020-09-16 10:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:46:27 --> Email Class Initialized
INFO - 2020-09-16 10:46:27 --> Controller Class Initialized
DEBUG - 2020-09-16 10:46:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:46:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:46:27 --> Model Class Initialized
INFO - 2020-09-16 10:46:27 --> Model Class Initialized
INFO - 2020-09-16 10:46:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_view.php
INFO - 2020-09-16 10:46:27 --> Final output sent to browser
DEBUG - 2020-09-16 10:46:27 --> Total execution time: 0.0205
ERROR - 2020-09-16 10:46:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:46:30 --> Config Class Initialized
INFO - 2020-09-16 10:46:30 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:46:30 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:46:30 --> Utf8 Class Initialized
INFO - 2020-09-16 10:46:30 --> URI Class Initialized
INFO - 2020-09-16 10:46:30 --> Router Class Initialized
INFO - 2020-09-16 10:46:30 --> Output Class Initialized
INFO - 2020-09-16 10:46:30 --> Security Class Initialized
DEBUG - 2020-09-16 10:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:46:30 --> Input Class Initialized
INFO - 2020-09-16 10:46:30 --> Language Class Initialized
INFO - 2020-09-16 10:46:30 --> Loader Class Initialized
INFO - 2020-09-16 10:46:30 --> Helper loaded: url_helper
INFO - 2020-09-16 10:46:30 --> Database Driver Class Initialized
INFO - 2020-09-16 10:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:46:30 --> Email Class Initialized
INFO - 2020-09-16 10:46:30 --> Controller Class Initialized
DEBUG - 2020-09-16 10:46:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:46:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:46:30 --> Model Class Initialized
INFO - 2020-09-16 10:46:30 --> Model Class Initialized
INFO - 2020-09-16 10:46:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-16 10:46:30 --> Final output sent to browser
DEBUG - 2020-09-16 10:46:30 --> Total execution time: 0.0222
ERROR - 2020-09-16 10:46:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:46:31 --> Config Class Initialized
INFO - 2020-09-16 10:46:31 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:46:31 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:46:31 --> Utf8 Class Initialized
INFO - 2020-09-16 10:46:31 --> URI Class Initialized
INFO - 2020-09-16 10:46:31 --> Router Class Initialized
INFO - 2020-09-16 10:46:31 --> Output Class Initialized
INFO - 2020-09-16 10:46:31 --> Security Class Initialized
DEBUG - 2020-09-16 10:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:46:31 --> Input Class Initialized
INFO - 2020-09-16 10:46:31 --> Language Class Initialized
INFO - 2020-09-16 10:46:31 --> Loader Class Initialized
INFO - 2020-09-16 10:46:31 --> Helper loaded: url_helper
INFO - 2020-09-16 10:46:31 --> Database Driver Class Initialized
INFO - 2020-09-16 10:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:46:31 --> Email Class Initialized
INFO - 2020-09-16 10:46:31 --> Controller Class Initialized
DEBUG - 2020-09-16 10:46:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:46:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:46:31 --> Model Class Initialized
INFO - 2020-09-16 10:46:31 --> Model Class Initialized
INFO - 2020-09-16 10:46:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-09-16 10:46:31 --> Final output sent to browser
DEBUG - 2020-09-16 10:46:31 --> Total execution time: 0.0210
ERROR - 2020-09-16 10:46:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:46:47 --> Config Class Initialized
INFO - 2020-09-16 10:46:47 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:46:47 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:46:47 --> Utf8 Class Initialized
INFO - 2020-09-16 10:46:47 --> URI Class Initialized
INFO - 2020-09-16 10:46:47 --> Router Class Initialized
INFO - 2020-09-16 10:46:47 --> Output Class Initialized
INFO - 2020-09-16 10:46:47 --> Security Class Initialized
DEBUG - 2020-09-16 10:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:46:47 --> Input Class Initialized
INFO - 2020-09-16 10:46:47 --> Language Class Initialized
INFO - 2020-09-16 10:46:47 --> Loader Class Initialized
INFO - 2020-09-16 10:46:47 --> Helper loaded: url_helper
INFO - 2020-09-16 10:46:47 --> Database Driver Class Initialized
INFO - 2020-09-16 10:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:46:47 --> Email Class Initialized
INFO - 2020-09-16 10:46:47 --> Controller Class Initialized
DEBUG - 2020-09-16 10:46:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:46:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:46:47 --> Model Class Initialized
INFO - 2020-09-16 10:46:47 --> Model Class Initialized
INFO - 2020-09-16 10:46:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-16 10:46:47 --> Final output sent to browser
DEBUG - 2020-09-16 10:46:47 --> Total execution time: 0.0312
ERROR - 2020-09-16 10:46:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:46:49 --> Config Class Initialized
INFO - 2020-09-16 10:46:49 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:46:49 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:46:49 --> Utf8 Class Initialized
INFO - 2020-09-16 10:46:49 --> URI Class Initialized
INFO - 2020-09-16 10:46:49 --> Router Class Initialized
INFO - 2020-09-16 10:46:49 --> Output Class Initialized
INFO - 2020-09-16 10:46:49 --> Security Class Initialized
DEBUG - 2020-09-16 10:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:46:49 --> Input Class Initialized
INFO - 2020-09-16 10:46:49 --> Language Class Initialized
INFO - 2020-09-16 10:46:49 --> Loader Class Initialized
INFO - 2020-09-16 10:46:49 --> Helper loaded: url_helper
INFO - 2020-09-16 10:46:49 --> Database Driver Class Initialized
INFO - 2020-09-16 10:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:46:49 --> Email Class Initialized
INFO - 2020-09-16 10:46:49 --> Controller Class Initialized
DEBUG - 2020-09-16 10:46:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:46:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:46:49 --> Model Class Initialized
INFO - 2020-09-16 10:46:49 --> Model Class Initialized
INFO - 2020-09-16 10:46:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-16 10:46:49 --> Final output sent to browser
DEBUG - 2020-09-16 10:46:49 --> Total execution time: 0.0267
ERROR - 2020-09-16 10:46:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:46:54 --> Config Class Initialized
INFO - 2020-09-16 10:46:54 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:46:54 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:46:54 --> Utf8 Class Initialized
INFO - 2020-09-16 10:46:54 --> URI Class Initialized
INFO - 2020-09-16 10:46:54 --> Router Class Initialized
INFO - 2020-09-16 10:46:54 --> Output Class Initialized
INFO - 2020-09-16 10:46:54 --> Security Class Initialized
DEBUG - 2020-09-16 10:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:46:54 --> Input Class Initialized
INFO - 2020-09-16 10:46:54 --> Language Class Initialized
INFO - 2020-09-16 10:46:54 --> Loader Class Initialized
INFO - 2020-09-16 10:46:54 --> Helper loaded: url_helper
INFO - 2020-09-16 10:46:54 --> Database Driver Class Initialized
INFO - 2020-09-16 10:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:46:54 --> Email Class Initialized
INFO - 2020-09-16 10:46:54 --> Controller Class Initialized
DEBUG - 2020-09-16 10:46:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:46:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:46:54 --> Model Class Initialized
INFO - 2020-09-16 10:46:54 --> Model Class Initialized
INFO - 2020-09-16 10:46:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-16 10:46:54 --> Final output sent to browser
DEBUG - 2020-09-16 10:46:54 --> Total execution time: 0.0230
ERROR - 2020-09-16 10:48:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:48:13 --> Config Class Initialized
INFO - 2020-09-16 10:48:13 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:48:13 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:48:13 --> Utf8 Class Initialized
INFO - 2020-09-16 10:48:13 --> URI Class Initialized
INFO - 2020-09-16 10:48:13 --> Router Class Initialized
INFO - 2020-09-16 10:48:13 --> Output Class Initialized
INFO - 2020-09-16 10:48:13 --> Security Class Initialized
DEBUG - 2020-09-16 10:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:48:13 --> Input Class Initialized
INFO - 2020-09-16 10:48:13 --> Language Class Initialized
INFO - 2020-09-16 10:48:13 --> Loader Class Initialized
INFO - 2020-09-16 10:48:13 --> Helper loaded: url_helper
INFO - 2020-09-16 10:48:13 --> Database Driver Class Initialized
INFO - 2020-09-16 10:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:48:13 --> Email Class Initialized
INFO - 2020-09-16 10:48:13 --> Controller Class Initialized
DEBUG - 2020-09-16 10:48:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:48:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:48:13 --> Model Class Initialized
INFO - 2020-09-16 10:48:13 --> Model Class Initialized
INFO - 2020-09-16 10:48:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-16 10:48:13 --> Final output sent to browser
DEBUG - 2020-09-16 10:48:13 --> Total execution time: 0.0430
ERROR - 2020-09-16 10:48:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:48:16 --> Config Class Initialized
INFO - 2020-09-16 10:48:16 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:48:16 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:48:16 --> Utf8 Class Initialized
INFO - 2020-09-16 10:48:16 --> URI Class Initialized
INFO - 2020-09-16 10:48:16 --> Router Class Initialized
INFO - 2020-09-16 10:48:16 --> Output Class Initialized
INFO - 2020-09-16 10:48:16 --> Security Class Initialized
DEBUG - 2020-09-16 10:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:48:16 --> Input Class Initialized
INFO - 2020-09-16 10:48:16 --> Language Class Initialized
INFO - 2020-09-16 10:48:16 --> Loader Class Initialized
INFO - 2020-09-16 10:48:16 --> Helper loaded: url_helper
INFO - 2020-09-16 10:48:16 --> Database Driver Class Initialized
INFO - 2020-09-16 10:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:48:16 --> Email Class Initialized
INFO - 2020-09-16 10:48:16 --> Controller Class Initialized
DEBUG - 2020-09-16 10:48:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:48:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:48:16 --> Model Class Initialized
INFO - 2020-09-16 10:48:16 --> Model Class Initialized
INFO - 2020-09-16 10:48:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-16 10:48:16 --> Final output sent to browser
DEBUG - 2020-09-16 10:48:16 --> Total execution time: 0.0270
ERROR - 2020-09-16 10:48:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:48:23 --> Config Class Initialized
INFO - 2020-09-16 10:48:23 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:48:23 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:48:23 --> Utf8 Class Initialized
INFO - 2020-09-16 10:48:23 --> URI Class Initialized
INFO - 2020-09-16 10:48:23 --> Router Class Initialized
INFO - 2020-09-16 10:48:23 --> Output Class Initialized
INFO - 2020-09-16 10:48:23 --> Security Class Initialized
DEBUG - 2020-09-16 10:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:48:23 --> Input Class Initialized
INFO - 2020-09-16 10:48:23 --> Language Class Initialized
INFO - 2020-09-16 10:48:23 --> Loader Class Initialized
INFO - 2020-09-16 10:48:23 --> Helper loaded: url_helper
INFO - 2020-09-16 10:48:23 --> Database Driver Class Initialized
INFO - 2020-09-16 10:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:48:23 --> Email Class Initialized
INFO - 2020-09-16 10:48:23 --> Controller Class Initialized
DEBUG - 2020-09-16 10:48:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:48:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:48:23 --> Model Class Initialized
INFO - 2020-09-16 10:48:23 --> Model Class Initialized
INFO - 2020-09-16 10:48:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-09-16 10:48:23 --> Final output sent to browser
DEBUG - 2020-09-16 10:48:23 --> Total execution time: 0.0253
ERROR - 2020-09-16 10:48:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:48:30 --> Config Class Initialized
INFO - 2020-09-16 10:48:30 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:48:30 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:48:30 --> Utf8 Class Initialized
INFO - 2020-09-16 10:48:30 --> URI Class Initialized
INFO - 2020-09-16 10:48:30 --> Router Class Initialized
INFO - 2020-09-16 10:48:30 --> Output Class Initialized
INFO - 2020-09-16 10:48:30 --> Security Class Initialized
DEBUG - 2020-09-16 10:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:48:30 --> Input Class Initialized
INFO - 2020-09-16 10:48:30 --> Language Class Initialized
INFO - 2020-09-16 10:48:30 --> Loader Class Initialized
INFO - 2020-09-16 10:48:30 --> Helper loaded: url_helper
INFO - 2020-09-16 10:48:30 --> Database Driver Class Initialized
INFO - 2020-09-16 10:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:48:30 --> Email Class Initialized
INFO - 2020-09-16 10:48:30 --> Controller Class Initialized
DEBUG - 2020-09-16 10:48:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:48:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:48:30 --> Model Class Initialized
INFO - 2020-09-16 10:48:30 --> Model Class Initialized
INFO - 2020-09-16 10:48:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-16 10:48:30 --> Final output sent to browser
DEBUG - 2020-09-16 10:48:30 --> Total execution time: 0.0236
ERROR - 2020-09-16 10:48:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:48:32 --> Config Class Initialized
INFO - 2020-09-16 10:48:32 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:48:32 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:48:32 --> Utf8 Class Initialized
INFO - 2020-09-16 10:48:32 --> URI Class Initialized
INFO - 2020-09-16 10:48:32 --> Router Class Initialized
INFO - 2020-09-16 10:48:32 --> Output Class Initialized
INFO - 2020-09-16 10:48:32 --> Security Class Initialized
DEBUG - 2020-09-16 10:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:48:32 --> Input Class Initialized
INFO - 2020-09-16 10:48:32 --> Language Class Initialized
INFO - 2020-09-16 10:48:32 --> Loader Class Initialized
INFO - 2020-09-16 10:48:32 --> Helper loaded: url_helper
INFO - 2020-09-16 10:48:32 --> Database Driver Class Initialized
INFO - 2020-09-16 10:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:48:32 --> Email Class Initialized
INFO - 2020-09-16 10:48:32 --> Controller Class Initialized
DEBUG - 2020-09-16 10:48:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:48:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:48:32 --> Model Class Initialized
INFO - 2020-09-16 10:48:32 --> Model Class Initialized
INFO - 2020-09-16 10:48:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-09-16 10:48:32 --> Final output sent to browser
DEBUG - 2020-09-16 10:48:32 --> Total execution time: 0.0250
ERROR - 2020-09-16 10:48:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:48:37 --> Config Class Initialized
INFO - 2020-09-16 10:48:37 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:48:37 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:48:37 --> Utf8 Class Initialized
INFO - 2020-09-16 10:48:37 --> URI Class Initialized
INFO - 2020-09-16 10:48:37 --> Router Class Initialized
INFO - 2020-09-16 10:48:37 --> Output Class Initialized
INFO - 2020-09-16 10:48:37 --> Security Class Initialized
DEBUG - 2020-09-16 10:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:48:37 --> Input Class Initialized
INFO - 2020-09-16 10:48:37 --> Language Class Initialized
INFO - 2020-09-16 10:48:37 --> Loader Class Initialized
INFO - 2020-09-16 10:48:37 --> Helper loaded: url_helper
INFO - 2020-09-16 10:48:37 --> Database Driver Class Initialized
INFO - 2020-09-16 10:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:48:37 --> Email Class Initialized
INFO - 2020-09-16 10:48:37 --> Controller Class Initialized
DEBUG - 2020-09-16 10:48:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:48:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:48:37 --> Model Class Initialized
INFO - 2020-09-16 10:48:37 --> Model Class Initialized
INFO - 2020-09-16 10:48:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-16 10:48:37 --> Final output sent to browser
DEBUG - 2020-09-16 10:48:37 --> Total execution time: 0.0254
ERROR - 2020-09-16 10:48:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:48:40 --> Config Class Initialized
INFO - 2020-09-16 10:48:40 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:48:40 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:48:40 --> Utf8 Class Initialized
INFO - 2020-09-16 10:48:40 --> URI Class Initialized
INFO - 2020-09-16 10:48:40 --> Router Class Initialized
INFO - 2020-09-16 10:48:40 --> Output Class Initialized
INFO - 2020-09-16 10:48:40 --> Security Class Initialized
DEBUG - 2020-09-16 10:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:48:40 --> Input Class Initialized
INFO - 2020-09-16 10:48:40 --> Language Class Initialized
INFO - 2020-09-16 10:48:40 --> Loader Class Initialized
INFO - 2020-09-16 10:48:40 --> Helper loaded: url_helper
INFO - 2020-09-16 10:48:40 --> Database Driver Class Initialized
INFO - 2020-09-16 10:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:48:40 --> Email Class Initialized
INFO - 2020-09-16 10:48:40 --> Controller Class Initialized
DEBUG - 2020-09-16 10:48:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:48:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:48:40 --> Model Class Initialized
INFO - 2020-09-16 10:48:40 --> Model Class Initialized
INFO - 2020-09-16 10:48:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 10:48:40 --> Final output sent to browser
DEBUG - 2020-09-16 10:48:40 --> Total execution time: 0.0242
ERROR - 2020-09-16 10:48:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:48:49 --> Config Class Initialized
INFO - 2020-09-16 10:48:49 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:48:49 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:48:49 --> Utf8 Class Initialized
INFO - 2020-09-16 10:48:49 --> URI Class Initialized
DEBUG - 2020-09-16 10:48:49 --> No URI present. Default controller set.
INFO - 2020-09-16 10:48:49 --> Router Class Initialized
INFO - 2020-09-16 10:48:49 --> Output Class Initialized
INFO - 2020-09-16 10:48:49 --> Security Class Initialized
DEBUG - 2020-09-16 10:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:48:49 --> Input Class Initialized
INFO - 2020-09-16 10:48:49 --> Language Class Initialized
INFO - 2020-09-16 10:48:49 --> Loader Class Initialized
INFO - 2020-09-16 10:48:49 --> Helper loaded: url_helper
INFO - 2020-09-16 10:48:49 --> Database Driver Class Initialized
INFO - 2020-09-16 10:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:48:49 --> Email Class Initialized
INFO - 2020-09-16 10:48:49 --> Controller Class Initialized
INFO - 2020-09-16 10:48:49 --> Model Class Initialized
INFO - 2020-09-16 10:48:49 --> Model Class Initialized
DEBUG - 2020-09-16 10:48:49 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:48:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-16 10:48:49 --> Final output sent to browser
DEBUG - 2020-09-16 10:48:49 --> Total execution time: 0.0199
ERROR - 2020-09-16 10:49:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:49:08 --> Config Class Initialized
INFO - 2020-09-16 10:49:08 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:49:08 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:49:08 --> Utf8 Class Initialized
INFO - 2020-09-16 10:49:08 --> URI Class Initialized
INFO - 2020-09-16 10:49:08 --> Router Class Initialized
INFO - 2020-09-16 10:49:08 --> Output Class Initialized
INFO - 2020-09-16 10:49:08 --> Security Class Initialized
DEBUG - 2020-09-16 10:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:49:08 --> Input Class Initialized
INFO - 2020-09-16 10:49:08 --> Language Class Initialized
INFO - 2020-09-16 10:49:08 --> Loader Class Initialized
INFO - 2020-09-16 10:49:08 --> Helper loaded: url_helper
INFO - 2020-09-16 10:49:08 --> Database Driver Class Initialized
INFO - 2020-09-16 10:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:49:08 --> Email Class Initialized
INFO - 2020-09-16 10:49:08 --> Controller Class Initialized
INFO - 2020-09-16 10:49:08 --> Model Class Initialized
INFO - 2020-09-16 10:49:08 --> Model Class Initialized
DEBUG - 2020-09-16 10:49:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:49:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:49:08 --> Model Class Initialized
INFO - 2020-09-16 10:49:08 --> Final output sent to browser
DEBUG - 2020-09-16 10:49:08 --> Total execution time: 0.0235
ERROR - 2020-09-16 10:49:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:49:08 --> Config Class Initialized
INFO - 2020-09-16 10:49:08 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:49:08 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:49:08 --> Utf8 Class Initialized
INFO - 2020-09-16 10:49:08 --> URI Class Initialized
INFO - 2020-09-16 10:49:08 --> Router Class Initialized
INFO - 2020-09-16 10:49:08 --> Output Class Initialized
INFO - 2020-09-16 10:49:08 --> Security Class Initialized
DEBUG - 2020-09-16 10:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:49:08 --> Input Class Initialized
INFO - 2020-09-16 10:49:08 --> Language Class Initialized
INFO - 2020-09-16 10:49:08 --> Loader Class Initialized
INFO - 2020-09-16 10:49:08 --> Helper loaded: url_helper
INFO - 2020-09-16 10:49:08 --> Database Driver Class Initialized
INFO - 2020-09-16 10:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:49:08 --> Email Class Initialized
INFO - 2020-09-16 10:49:08 --> Controller Class Initialized
INFO - 2020-09-16 10:49:08 --> Model Class Initialized
INFO - 2020-09-16 10:49:08 --> Model Class Initialized
DEBUG - 2020-09-16 10:49:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:49:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:49:09 --> Config Class Initialized
INFO - 2020-09-16 10:49:09 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:49:09 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:49:09 --> Utf8 Class Initialized
INFO - 2020-09-16 10:49:09 --> URI Class Initialized
DEBUG - 2020-09-16 10:49:09 --> No URI present. Default controller set.
INFO - 2020-09-16 10:49:09 --> Router Class Initialized
INFO - 2020-09-16 10:49:09 --> Output Class Initialized
INFO - 2020-09-16 10:49:09 --> Security Class Initialized
DEBUG - 2020-09-16 10:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:49:09 --> Input Class Initialized
INFO - 2020-09-16 10:49:09 --> Language Class Initialized
INFO - 2020-09-16 10:49:09 --> Loader Class Initialized
INFO - 2020-09-16 10:49:09 --> Helper loaded: url_helper
INFO - 2020-09-16 10:49:09 --> Database Driver Class Initialized
INFO - 2020-09-16 10:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:49:09 --> Email Class Initialized
INFO - 2020-09-16 10:49:09 --> Controller Class Initialized
INFO - 2020-09-16 10:49:09 --> Model Class Initialized
INFO - 2020-09-16 10:49:09 --> Model Class Initialized
DEBUG - 2020-09-16 10:49:09 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:49:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-16 10:49:09 --> Final output sent to browser
DEBUG - 2020-09-16 10:49:09 --> Total execution time: 0.0215
ERROR - 2020-09-16 10:49:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:49:28 --> Config Class Initialized
INFO - 2020-09-16 10:49:28 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:49:28 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:49:28 --> Utf8 Class Initialized
INFO - 2020-09-16 10:49:28 --> URI Class Initialized
INFO - 2020-09-16 10:49:28 --> Router Class Initialized
INFO - 2020-09-16 10:49:28 --> Output Class Initialized
INFO - 2020-09-16 10:49:28 --> Security Class Initialized
DEBUG - 2020-09-16 10:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:49:28 --> Input Class Initialized
INFO - 2020-09-16 10:49:28 --> Language Class Initialized
INFO - 2020-09-16 10:49:28 --> Loader Class Initialized
INFO - 2020-09-16 10:49:28 --> Helper loaded: url_helper
INFO - 2020-09-16 10:49:28 --> Database Driver Class Initialized
INFO - 2020-09-16 10:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:49:28 --> Email Class Initialized
INFO - 2020-09-16 10:49:28 --> Controller Class Initialized
INFO - 2020-09-16 10:49:28 --> Model Class Initialized
INFO - 2020-09-16 10:49:28 --> Model Class Initialized
DEBUG - 2020-09-16 10:49:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:49:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:49:28 --> Config Class Initialized
INFO - 2020-09-16 10:49:28 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:49:28 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:49:28 --> Utf8 Class Initialized
INFO - 2020-09-16 10:49:28 --> URI Class Initialized
INFO - 2020-09-16 10:49:28 --> Router Class Initialized
INFO - 2020-09-16 10:49:28 --> Output Class Initialized
INFO - 2020-09-16 10:49:28 --> Security Class Initialized
DEBUG - 2020-09-16 10:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:49:28 --> Input Class Initialized
INFO - 2020-09-16 10:49:28 --> Language Class Initialized
INFO - 2020-09-16 10:49:28 --> Loader Class Initialized
INFO - 2020-09-16 10:49:28 --> Helper loaded: url_helper
INFO - 2020-09-16 10:49:28 --> Database Driver Class Initialized
INFO - 2020-09-16 10:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:49:28 --> Email Class Initialized
INFO - 2020-09-16 10:49:28 --> Controller Class Initialized
INFO - 2020-09-16 10:49:28 --> Model Class Initialized
INFO - 2020-09-16 10:49:28 --> Model Class Initialized
DEBUG - 2020-09-16 10:49:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:49:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:49:28 --> Model Class Initialized
INFO - 2020-09-16 10:49:28 --> Final output sent to browser
DEBUG - 2020-09-16 10:49:28 --> Total execution time: 0.0240
ERROR - 2020-09-16 10:49:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:49:29 --> Config Class Initialized
INFO - 2020-09-16 10:49:29 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:49:29 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:49:29 --> Utf8 Class Initialized
INFO - 2020-09-16 10:49:29 --> URI Class Initialized
INFO - 2020-09-16 10:49:29 --> Router Class Initialized
INFO - 2020-09-16 10:49:29 --> Output Class Initialized
INFO - 2020-09-16 10:49:29 --> Security Class Initialized
DEBUG - 2020-09-16 10:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:49:29 --> Input Class Initialized
INFO - 2020-09-16 10:49:29 --> Language Class Initialized
INFO - 2020-09-16 10:49:29 --> Loader Class Initialized
INFO - 2020-09-16 10:49:29 --> Helper loaded: url_helper
INFO - 2020-09-16 10:49:29 --> Database Driver Class Initialized
INFO - 2020-09-16 10:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:49:29 --> Email Class Initialized
INFO - 2020-09-16 10:49:29 --> Controller Class Initialized
DEBUG - 2020-09-16 10:49:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:49:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:49:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-16 10:49:29 --> Final output sent to browser
DEBUG - 2020-09-16 10:49:29 --> Total execution time: 0.0397
ERROR - 2020-09-16 10:49:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:49:37 --> Config Class Initialized
INFO - 2020-09-16 10:49:37 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:49:37 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:49:37 --> Utf8 Class Initialized
INFO - 2020-09-16 10:49:37 --> URI Class Initialized
INFO - 2020-09-16 10:49:37 --> Router Class Initialized
INFO - 2020-09-16 10:49:37 --> Output Class Initialized
INFO - 2020-09-16 10:49:37 --> Security Class Initialized
DEBUG - 2020-09-16 10:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:49:37 --> Input Class Initialized
INFO - 2020-09-16 10:49:37 --> Language Class Initialized
INFO - 2020-09-16 10:49:37 --> Loader Class Initialized
INFO - 2020-09-16 10:49:37 --> Helper loaded: url_helper
INFO - 2020-09-16 10:49:37 --> Database Driver Class Initialized
INFO - 2020-09-16 10:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:49:37 --> Email Class Initialized
INFO - 2020-09-16 10:49:37 --> Controller Class Initialized
DEBUG - 2020-09-16 10:49:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:49:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:49:37 --> Model Class Initialized
INFO - 2020-09-16 10:49:37 --> Model Class Initialized
INFO - 2020-09-16 10:49:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-16 10:49:37 --> Final output sent to browser
DEBUG - 2020-09-16 10:49:37 --> Total execution time: 0.0589
ERROR - 2020-09-16 10:49:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:49:40 --> Config Class Initialized
INFO - 2020-09-16 10:49:40 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:49:40 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:49:40 --> Utf8 Class Initialized
INFO - 2020-09-16 10:49:40 --> URI Class Initialized
INFO - 2020-09-16 10:49:40 --> Router Class Initialized
INFO - 2020-09-16 10:49:40 --> Output Class Initialized
INFO - 2020-09-16 10:49:40 --> Security Class Initialized
DEBUG - 2020-09-16 10:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:49:40 --> Input Class Initialized
INFO - 2020-09-16 10:49:40 --> Language Class Initialized
INFO - 2020-09-16 10:49:40 --> Loader Class Initialized
INFO - 2020-09-16 10:49:40 --> Helper loaded: url_helper
INFO - 2020-09-16 10:49:40 --> Database Driver Class Initialized
INFO - 2020-09-16 10:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:49:40 --> Email Class Initialized
INFO - 2020-09-16 10:49:40 --> Controller Class Initialized
DEBUG - 2020-09-16 10:49:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:49:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:49:40 --> Model Class Initialized
INFO - 2020-09-16 10:49:40 --> Model Class Initialized
INFO - 2020-09-16 10:49:40 --> Model Class Initialized
INFO - 2020-09-16 10:49:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-09-16 10:49:40 --> Final output sent to browser
DEBUG - 2020-09-16 10:49:40 --> Total execution time: 0.0366
ERROR - 2020-09-16 10:54:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:54:25 --> Config Class Initialized
INFO - 2020-09-16 10:54:25 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:54:25 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:54:25 --> Utf8 Class Initialized
INFO - 2020-09-16 10:54:25 --> URI Class Initialized
INFO - 2020-09-16 10:54:25 --> Router Class Initialized
INFO - 2020-09-16 10:54:25 --> Output Class Initialized
INFO - 2020-09-16 10:54:25 --> Security Class Initialized
DEBUG - 2020-09-16 10:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:54:25 --> Input Class Initialized
INFO - 2020-09-16 10:54:25 --> Language Class Initialized
INFO - 2020-09-16 10:54:25 --> Loader Class Initialized
INFO - 2020-09-16 10:54:25 --> Helper loaded: url_helper
INFO - 2020-09-16 10:54:25 --> Database Driver Class Initialized
INFO - 2020-09-16 10:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:54:25 --> Email Class Initialized
INFO - 2020-09-16 10:54:25 --> Controller Class Initialized
DEBUG - 2020-09-16 10:54:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:54:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:54:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-16 10:54:25 --> Final output sent to browser
DEBUG - 2020-09-16 10:54:25 --> Total execution time: 0.0162
ERROR - 2020-09-16 10:54:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:54:26 --> Config Class Initialized
INFO - 2020-09-16 10:54:26 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:54:26 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:54:26 --> Utf8 Class Initialized
INFO - 2020-09-16 10:54:26 --> URI Class Initialized
DEBUG - 2020-09-16 10:54:26 --> No URI present. Default controller set.
INFO - 2020-09-16 10:54:26 --> Router Class Initialized
INFO - 2020-09-16 10:54:26 --> Output Class Initialized
INFO - 2020-09-16 10:54:26 --> Security Class Initialized
DEBUG - 2020-09-16 10:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:54:26 --> Input Class Initialized
INFO - 2020-09-16 10:54:26 --> Language Class Initialized
INFO - 2020-09-16 10:54:26 --> Loader Class Initialized
INFO - 2020-09-16 10:54:26 --> Helper loaded: url_helper
INFO - 2020-09-16 10:54:26 --> Database Driver Class Initialized
INFO - 2020-09-16 10:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:54:26 --> Email Class Initialized
INFO - 2020-09-16 10:54:26 --> Controller Class Initialized
INFO - 2020-09-16 10:54:26 --> Model Class Initialized
INFO - 2020-09-16 10:54:26 --> Model Class Initialized
DEBUG - 2020-09-16 10:54:26 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:54:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-16 10:54:26 --> Final output sent to browser
DEBUG - 2020-09-16 10:54:26 --> Total execution time: 0.0188
ERROR - 2020-09-16 10:54:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:54:29 --> Config Class Initialized
INFO - 2020-09-16 10:54:29 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:54:29 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:54:29 --> Utf8 Class Initialized
INFO - 2020-09-16 10:54:29 --> URI Class Initialized
INFO - 2020-09-16 10:54:29 --> Router Class Initialized
INFO - 2020-09-16 10:54:29 --> Output Class Initialized
INFO - 2020-09-16 10:54:29 --> Security Class Initialized
DEBUG - 2020-09-16 10:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:54:29 --> Input Class Initialized
INFO - 2020-09-16 10:54:29 --> Language Class Initialized
INFO - 2020-09-16 10:54:29 --> Loader Class Initialized
INFO - 2020-09-16 10:54:29 --> Helper loaded: url_helper
INFO - 2020-09-16 10:54:29 --> Database Driver Class Initialized
INFO - 2020-09-16 10:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:54:29 --> Email Class Initialized
INFO - 2020-09-16 10:54:29 --> Controller Class Initialized
INFO - 2020-09-16 10:54:29 --> Model Class Initialized
INFO - 2020-09-16 10:54:29 --> Model Class Initialized
DEBUG - 2020-09-16 10:54:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:54:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:54:29 --> Model Class Initialized
INFO - 2020-09-16 10:54:29 --> Final output sent to browser
DEBUG - 2020-09-16 10:54:29 --> Total execution time: 0.0249
ERROR - 2020-09-16 10:54:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:54:29 --> Config Class Initialized
INFO - 2020-09-16 10:54:29 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:54:29 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:54:29 --> Utf8 Class Initialized
INFO - 2020-09-16 10:54:29 --> URI Class Initialized
INFO - 2020-09-16 10:54:29 --> Router Class Initialized
INFO - 2020-09-16 10:54:29 --> Output Class Initialized
INFO - 2020-09-16 10:54:29 --> Security Class Initialized
DEBUG - 2020-09-16 10:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:54:29 --> Input Class Initialized
INFO - 2020-09-16 10:54:29 --> Language Class Initialized
INFO - 2020-09-16 10:54:29 --> Loader Class Initialized
INFO - 2020-09-16 10:54:29 --> Helper loaded: url_helper
INFO - 2020-09-16 10:54:29 --> Database Driver Class Initialized
INFO - 2020-09-16 10:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:54:29 --> Email Class Initialized
INFO - 2020-09-16 10:54:29 --> Controller Class Initialized
INFO - 2020-09-16 10:54:29 --> Model Class Initialized
INFO - 2020-09-16 10:54:29 --> Model Class Initialized
DEBUG - 2020-09-16 10:54:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-16 10:54:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:54:29 --> Config Class Initialized
INFO - 2020-09-16 10:54:29 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:54:29 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:54:29 --> Utf8 Class Initialized
INFO - 2020-09-16 10:54:29 --> URI Class Initialized
INFO - 2020-09-16 10:54:29 --> Router Class Initialized
INFO - 2020-09-16 10:54:29 --> Output Class Initialized
INFO - 2020-09-16 10:54:29 --> Security Class Initialized
DEBUG - 2020-09-16 10:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:54:29 --> Input Class Initialized
INFO - 2020-09-16 10:54:29 --> Language Class Initialized
INFO - 2020-09-16 10:54:29 --> Loader Class Initialized
INFO - 2020-09-16 10:54:29 --> Helper loaded: url_helper
INFO - 2020-09-16 10:54:29 --> Database Driver Class Initialized
INFO - 2020-09-16 10:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:54:29 --> Email Class Initialized
INFO - 2020-09-16 10:54:29 --> Controller Class Initialized
DEBUG - 2020-09-16 10:54:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:54:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:54:29 --> Model Class Initialized
INFO - 2020-09-16 10:54:29 --> Model Class Initialized
INFO - 2020-09-16 10:54:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-16 10:54:29 --> Final output sent to browser
DEBUG - 2020-09-16 10:54:29 --> Total execution time: 0.0259
ERROR - 2020-09-16 10:54:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:54:32 --> Config Class Initialized
INFO - 2020-09-16 10:54:32 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:54:32 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:54:32 --> Utf8 Class Initialized
INFO - 2020-09-16 10:54:32 --> URI Class Initialized
INFO - 2020-09-16 10:54:32 --> Router Class Initialized
INFO - 2020-09-16 10:54:32 --> Output Class Initialized
INFO - 2020-09-16 10:54:32 --> Security Class Initialized
DEBUG - 2020-09-16 10:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:54:32 --> Input Class Initialized
INFO - 2020-09-16 10:54:32 --> Language Class Initialized
INFO - 2020-09-16 10:54:32 --> Loader Class Initialized
INFO - 2020-09-16 10:54:32 --> Helper loaded: url_helper
INFO - 2020-09-16 10:54:32 --> Database Driver Class Initialized
INFO - 2020-09-16 10:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:54:32 --> Email Class Initialized
INFO - 2020-09-16 10:54:32 --> Controller Class Initialized
DEBUG - 2020-09-16 10:54:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:54:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:54:32 --> Model Class Initialized
INFO - 2020-09-16 10:54:32 --> Model Class Initialized
INFO - 2020-09-16 10:54:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 10:54:32 --> Final output sent to browser
DEBUG - 2020-09-16 10:54:32 --> Total execution time: 0.0214
ERROR - 2020-09-16 10:54:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:54:35 --> Config Class Initialized
INFO - 2020-09-16 10:54:35 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:54:35 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:54:35 --> Utf8 Class Initialized
INFO - 2020-09-16 10:54:35 --> URI Class Initialized
INFO - 2020-09-16 10:54:35 --> Router Class Initialized
INFO - 2020-09-16 10:54:35 --> Output Class Initialized
INFO - 2020-09-16 10:54:35 --> Security Class Initialized
DEBUG - 2020-09-16 10:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:54:35 --> Input Class Initialized
INFO - 2020-09-16 10:54:35 --> Language Class Initialized
INFO - 2020-09-16 10:54:35 --> Loader Class Initialized
INFO - 2020-09-16 10:54:35 --> Helper loaded: url_helper
INFO - 2020-09-16 10:54:35 --> Database Driver Class Initialized
INFO - 2020-09-16 10:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:54:35 --> Email Class Initialized
INFO - 2020-09-16 10:54:35 --> Controller Class Initialized
DEBUG - 2020-09-16 10:54:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:54:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:54:35 --> Model Class Initialized
INFO - 2020-09-16 10:54:35 --> Model Class Initialized
INFO - 2020-09-16 10:54:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_edit.php
INFO - 2020-09-16 10:54:35 --> Final output sent to browser
DEBUG - 2020-09-16 10:54:35 --> Total execution time: 0.0263
ERROR - 2020-09-16 10:55:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:55:41 --> Config Class Initialized
INFO - 2020-09-16 10:55:41 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:55:41 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:55:41 --> Utf8 Class Initialized
INFO - 2020-09-16 10:55:41 --> URI Class Initialized
INFO - 2020-09-16 10:55:41 --> Router Class Initialized
INFO - 2020-09-16 10:55:41 --> Output Class Initialized
INFO - 2020-09-16 10:55:41 --> Security Class Initialized
DEBUG - 2020-09-16 10:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:55:41 --> Input Class Initialized
INFO - 2020-09-16 10:55:41 --> Language Class Initialized
INFO - 2020-09-16 10:55:41 --> Loader Class Initialized
INFO - 2020-09-16 10:55:41 --> Helper loaded: url_helper
INFO - 2020-09-16 10:55:41 --> Database Driver Class Initialized
INFO - 2020-09-16 10:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:55:41 --> Email Class Initialized
INFO - 2020-09-16 10:55:41 --> Controller Class Initialized
DEBUG - 2020-09-16 10:55:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:55:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:55:41 --> Model Class Initialized
INFO - 2020-09-16 10:55:41 --> Model Class Initialized
INFO - 2020-09-16 10:55:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_edit.php
INFO - 2020-09-16 10:55:41 --> Final output sent to browser
DEBUG - 2020-09-16 10:55:41 --> Total execution time: 0.0276
ERROR - 2020-09-16 10:55:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:55:52 --> Config Class Initialized
INFO - 2020-09-16 10:55:52 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:55:52 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:55:52 --> Utf8 Class Initialized
INFO - 2020-09-16 10:55:52 --> URI Class Initialized
INFO - 2020-09-16 10:55:52 --> Router Class Initialized
INFO - 2020-09-16 10:55:52 --> Output Class Initialized
INFO - 2020-09-16 10:55:52 --> Security Class Initialized
DEBUG - 2020-09-16 10:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:55:52 --> Input Class Initialized
INFO - 2020-09-16 10:55:52 --> Language Class Initialized
INFO - 2020-09-16 10:55:52 --> Loader Class Initialized
INFO - 2020-09-16 10:55:52 --> Helper loaded: url_helper
INFO - 2020-09-16 10:55:52 --> Database Driver Class Initialized
INFO - 2020-09-16 10:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:55:52 --> Email Class Initialized
INFO - 2020-09-16 10:55:52 --> Controller Class Initialized
DEBUG - 2020-09-16 10:55:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:55:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:55:52 --> Model Class Initialized
INFO - 2020-09-16 10:55:52 --> Model Class Initialized
INFO - 2020-09-16 10:55:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 10:55:52 --> Final output sent to browser
DEBUG - 2020-09-16 10:55:52 --> Total execution time: 0.0226
ERROR - 2020-09-16 10:55:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:55:54 --> Config Class Initialized
INFO - 2020-09-16 10:55:54 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:55:54 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:55:54 --> Utf8 Class Initialized
INFO - 2020-09-16 10:55:54 --> URI Class Initialized
INFO - 2020-09-16 10:55:54 --> Router Class Initialized
INFO - 2020-09-16 10:55:54 --> Output Class Initialized
INFO - 2020-09-16 10:55:54 --> Security Class Initialized
DEBUG - 2020-09-16 10:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:55:54 --> Input Class Initialized
INFO - 2020-09-16 10:55:54 --> Language Class Initialized
INFO - 2020-09-16 10:55:54 --> Loader Class Initialized
INFO - 2020-09-16 10:55:54 --> Helper loaded: url_helper
INFO - 2020-09-16 10:55:54 --> Database Driver Class Initialized
INFO - 2020-09-16 10:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:55:54 --> Email Class Initialized
INFO - 2020-09-16 10:55:54 --> Controller Class Initialized
DEBUG - 2020-09-16 10:55:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:55:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:55:54 --> Model Class Initialized
INFO - 2020-09-16 10:55:54 --> Model Class Initialized
INFO - 2020-09-16 10:55:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_edit.php
INFO - 2020-09-16 10:55:54 --> Final output sent to browser
DEBUG - 2020-09-16 10:55:54 --> Total execution time: 0.0192
ERROR - 2020-09-16 10:56:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:56:19 --> Config Class Initialized
INFO - 2020-09-16 10:56:19 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:56:19 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:56:19 --> Utf8 Class Initialized
INFO - 2020-09-16 10:56:19 --> URI Class Initialized
INFO - 2020-09-16 10:56:19 --> Router Class Initialized
INFO - 2020-09-16 10:56:19 --> Output Class Initialized
INFO - 2020-09-16 10:56:19 --> Security Class Initialized
DEBUG - 2020-09-16 10:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:56:19 --> Input Class Initialized
INFO - 2020-09-16 10:56:19 --> Language Class Initialized
INFO - 2020-09-16 10:56:19 --> Loader Class Initialized
INFO - 2020-09-16 10:56:19 --> Helper loaded: url_helper
INFO - 2020-09-16 10:56:19 --> Database Driver Class Initialized
INFO - 2020-09-16 10:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:56:19 --> Email Class Initialized
INFO - 2020-09-16 10:56:19 --> Controller Class Initialized
DEBUG - 2020-09-16 10:56:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:56:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:56:19 --> Model Class Initialized
INFO - 2020-09-16 10:56:19 --> Model Class Initialized
INFO - 2020-09-16 10:56:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-16 10:56:19 --> Final output sent to browser
DEBUG - 2020-09-16 10:56:19 --> Total execution time: 0.0229
ERROR - 2020-09-16 10:56:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:56:21 --> Config Class Initialized
INFO - 2020-09-16 10:56:21 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:56:21 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:56:21 --> Utf8 Class Initialized
INFO - 2020-09-16 10:56:21 --> URI Class Initialized
INFO - 2020-09-16 10:56:21 --> Router Class Initialized
INFO - 2020-09-16 10:56:21 --> Output Class Initialized
INFO - 2020-09-16 10:56:21 --> Security Class Initialized
DEBUG - 2020-09-16 10:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:56:21 --> Input Class Initialized
INFO - 2020-09-16 10:56:21 --> Language Class Initialized
INFO - 2020-09-16 10:56:21 --> Loader Class Initialized
INFO - 2020-09-16 10:56:21 --> Helper loaded: url_helper
INFO - 2020-09-16 10:56:21 --> Database Driver Class Initialized
INFO - 2020-09-16 10:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:56:21 --> Email Class Initialized
INFO - 2020-09-16 10:56:21 --> Controller Class Initialized
DEBUG - 2020-09-16 10:56:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:56:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:56:21 --> Model Class Initialized
INFO - 2020-09-16 10:56:21 --> Model Class Initialized
INFO - 2020-09-16 10:56:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-09-16 10:56:21 --> Final output sent to browser
DEBUG - 2020-09-16 10:56:21 --> Total execution time: 0.0204
ERROR - 2020-09-16 10:56:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:56:36 --> Config Class Initialized
INFO - 2020-09-16 10:56:36 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:56:36 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:56:36 --> Utf8 Class Initialized
INFO - 2020-09-16 10:56:36 --> URI Class Initialized
INFO - 2020-09-16 10:56:36 --> Router Class Initialized
INFO - 2020-09-16 10:56:36 --> Output Class Initialized
INFO - 2020-09-16 10:56:36 --> Security Class Initialized
DEBUG - 2020-09-16 10:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:56:36 --> Input Class Initialized
INFO - 2020-09-16 10:56:36 --> Language Class Initialized
INFO - 2020-09-16 10:56:36 --> Loader Class Initialized
INFO - 2020-09-16 10:56:36 --> Helper loaded: url_helper
INFO - 2020-09-16 10:56:36 --> Database Driver Class Initialized
INFO - 2020-09-16 10:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:56:36 --> Email Class Initialized
INFO - 2020-09-16 10:56:36 --> Controller Class Initialized
DEBUG - 2020-09-16 10:56:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:56:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:56:36 --> Model Class Initialized
INFO - 2020-09-16 10:56:36 --> Model Class Initialized
INFO - 2020-09-16 10:56:36 --> Model Class Initialized
INFO - 2020-09-16 10:56:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-16 10:56:36 --> Final output sent to browser
DEBUG - 2020-09-16 10:56:36 --> Total execution time: 0.0896
ERROR - 2020-09-16 10:56:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:56:39 --> Config Class Initialized
INFO - 2020-09-16 10:56:39 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:56:39 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:56:39 --> Utf8 Class Initialized
INFO - 2020-09-16 10:56:39 --> URI Class Initialized
INFO - 2020-09-16 10:56:39 --> Router Class Initialized
INFO - 2020-09-16 10:56:39 --> Output Class Initialized
INFO - 2020-09-16 10:56:39 --> Security Class Initialized
DEBUG - 2020-09-16 10:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:56:39 --> Input Class Initialized
INFO - 2020-09-16 10:56:39 --> Language Class Initialized
INFO - 2020-09-16 10:56:39 --> Loader Class Initialized
INFO - 2020-09-16 10:56:39 --> Helper loaded: url_helper
INFO - 2020-09-16 10:56:39 --> Database Driver Class Initialized
INFO - 2020-09-16 10:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:56:39 --> Email Class Initialized
INFO - 2020-09-16 10:56:39 --> Controller Class Initialized
DEBUG - 2020-09-16 10:56:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:56:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:56:39 --> Model Class Initialized
INFO - 2020-09-16 10:56:39 --> Model Class Initialized
INFO - 2020-09-16 10:56:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 10:56:39 --> Final output sent to browser
DEBUG - 2020-09-16 10:56:39 --> Total execution time: 0.0226
ERROR - 2020-09-16 10:56:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:56:42 --> Config Class Initialized
INFO - 2020-09-16 10:56:42 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:56:42 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:56:42 --> Utf8 Class Initialized
INFO - 2020-09-16 10:56:42 --> URI Class Initialized
INFO - 2020-09-16 10:56:42 --> Router Class Initialized
INFO - 2020-09-16 10:56:42 --> Output Class Initialized
INFO - 2020-09-16 10:56:42 --> Security Class Initialized
DEBUG - 2020-09-16 10:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:56:42 --> Input Class Initialized
INFO - 2020-09-16 10:56:42 --> Language Class Initialized
INFO - 2020-09-16 10:56:42 --> Loader Class Initialized
INFO - 2020-09-16 10:56:42 --> Helper loaded: url_helper
INFO - 2020-09-16 10:56:42 --> Database Driver Class Initialized
INFO - 2020-09-16 10:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:56:42 --> Email Class Initialized
INFO - 2020-09-16 10:56:42 --> Controller Class Initialized
DEBUG - 2020-09-16 10:56:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:56:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:56:42 --> Model Class Initialized
INFO - 2020-09-16 10:56:42 --> Model Class Initialized
INFO - 2020-09-16 10:56:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_edit.php
INFO - 2020-09-16 10:56:42 --> Final output sent to browser
DEBUG - 2020-09-16 10:56:42 --> Total execution time: 0.0229
ERROR - 2020-09-16 10:56:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-16 10:56:49 --> Config Class Initialized
INFO - 2020-09-16 10:56:49 --> Hooks Class Initialized
DEBUG - 2020-09-16 10:56:49 --> UTF-8 Support Enabled
INFO - 2020-09-16 10:56:49 --> Utf8 Class Initialized
INFO - 2020-09-16 10:56:49 --> URI Class Initialized
INFO - 2020-09-16 10:56:49 --> Router Class Initialized
INFO - 2020-09-16 10:56:49 --> Output Class Initialized
INFO - 2020-09-16 10:56:49 --> Security Class Initialized
DEBUG - 2020-09-16 10:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-16 10:56:49 --> Input Class Initialized
INFO - 2020-09-16 10:56:49 --> Language Class Initialized
INFO - 2020-09-16 10:56:49 --> Loader Class Initialized
INFO - 2020-09-16 10:56:49 --> Helper loaded: url_helper
INFO - 2020-09-16 10:56:49 --> Database Driver Class Initialized
INFO - 2020-09-16 10:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-16 10:56:49 --> Email Class Initialized
INFO - 2020-09-16 10:56:49 --> Controller Class Initialized
DEBUG - 2020-09-16 10:56:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-16 10:56:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-16 10:56:49 --> Model Class Initialized
INFO - 2020-09-16 10:56:49 --> Model Class Initialized
INFO - 2020-09-16 10:56:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-16 10:56:49 --> Final output sent to browser
DEBUG - 2020-09-16 10:56:49 --> Total execution time: 0.0275
