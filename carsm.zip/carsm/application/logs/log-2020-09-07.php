<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-07 05:16:00 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-07 05:28:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 05:28:31 --> Config Class Initialized
INFO - 2020-09-07 05:28:31 --> Hooks Class Initialized
DEBUG - 2020-09-07 05:28:31 --> UTF-8 Support Enabled
INFO - 2020-09-07 05:28:31 --> Utf8 Class Initialized
INFO - 2020-09-07 05:28:31 --> URI Class Initialized
DEBUG - 2020-09-07 05:28:31 --> No URI present. Default controller set.
INFO - 2020-09-07 05:28:31 --> Router Class Initialized
INFO - 2020-09-07 05:28:31 --> Output Class Initialized
INFO - 2020-09-07 05:28:31 --> Security Class Initialized
DEBUG - 2020-09-07 05:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 05:28:31 --> Input Class Initialized
INFO - 2020-09-07 05:28:31 --> Language Class Initialized
INFO - 2020-09-07 05:28:31 --> Loader Class Initialized
INFO - 2020-09-07 05:28:31 --> Helper loaded: url_helper
INFO - 2020-09-07 05:28:31 --> Database Driver Class Initialized
INFO - 2020-09-07 05:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 05:28:31 --> Email Class Initialized
INFO - 2020-09-07 05:28:31 --> Controller Class Initialized
INFO - 2020-09-07 05:28:31 --> Model Class Initialized
INFO - 2020-09-07 05:28:31 --> Model Class Initialized
DEBUG - 2020-09-07 05:28:31 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-07 05:28:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-07 05:28:31 --> Final output sent to browser
DEBUG - 2020-09-07 05:28:31 --> Total execution time: 0.1498
ERROR - 2020-09-07 05:31:05 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-07 09:07:46 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-07 09:19:40 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-07 09:20:01 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-07 09:20:06 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-07 09:20:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 09:20:17 --> Config Class Initialized
INFO - 2020-09-07 09:20:17 --> Hooks Class Initialized
DEBUG - 2020-09-07 09:20:17 --> UTF-8 Support Enabled
INFO - 2020-09-07 09:20:17 --> Utf8 Class Initialized
INFO - 2020-09-07 09:20:17 --> URI Class Initialized
DEBUG - 2020-09-07 09:20:17 --> No URI present. Default controller set.
INFO - 2020-09-07 09:20:17 --> Router Class Initialized
INFO - 2020-09-07 09:20:17 --> Output Class Initialized
INFO - 2020-09-07 09:20:17 --> Security Class Initialized
DEBUG - 2020-09-07 09:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 09:20:17 --> Input Class Initialized
INFO - 2020-09-07 09:20:17 --> Language Class Initialized
INFO - 2020-09-07 09:20:17 --> Loader Class Initialized
INFO - 2020-09-07 09:20:17 --> Helper loaded: url_helper
INFO - 2020-09-07 09:20:17 --> Database Driver Class Initialized
INFO - 2020-09-07 09:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 09:20:17 --> Email Class Initialized
INFO - 2020-09-07 09:20:17 --> Controller Class Initialized
INFO - 2020-09-07 09:20:17 --> Model Class Initialized
INFO - 2020-09-07 09:20:17 --> Model Class Initialized
DEBUG - 2020-09-07 09:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-07 09:20:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-07 09:20:17 --> Final output sent to browser
DEBUG - 2020-09-07 09:20:17 --> Total execution time: 0.1283
ERROR - 2020-09-07 09:20:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 09:20:28 --> Config Class Initialized
INFO - 2020-09-07 09:20:28 --> Hooks Class Initialized
DEBUG - 2020-09-07 09:20:28 --> UTF-8 Support Enabled
INFO - 2020-09-07 09:20:28 --> Utf8 Class Initialized
INFO - 2020-09-07 09:20:28 --> URI Class Initialized
INFO - 2020-09-07 09:20:28 --> Router Class Initialized
INFO - 2020-09-07 09:20:28 --> Output Class Initialized
INFO - 2020-09-07 09:20:28 --> Security Class Initialized
DEBUG - 2020-09-07 09:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 09:20:28 --> Input Class Initialized
INFO - 2020-09-07 09:20:28 --> Language Class Initialized
INFO - 2020-09-07 09:20:28 --> Loader Class Initialized
INFO - 2020-09-07 09:20:28 --> Helper loaded: url_helper
ERROR - 2020-09-07 09:20:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 09:20:28 --> Config Class Initialized
INFO - 2020-09-07 09:20:28 --> Hooks Class Initialized
INFO - 2020-09-07 09:20:28 --> Database Driver Class Initialized
DEBUG - 2020-09-07 09:20:28 --> UTF-8 Support Enabled
INFO - 2020-09-07 09:20:28 --> Utf8 Class Initialized
INFO - 2020-09-07 09:20:28 --> URI Class Initialized
INFO - 2020-09-07 09:20:28 --> Router Class Initialized
INFO - 2020-09-07 09:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 09:20:28 --> Output Class Initialized
INFO - 2020-09-07 09:20:28 --> Security Class Initialized
DEBUG - 2020-09-07 09:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 09:20:28 --> Email Class Initialized
INFO - 2020-09-07 09:20:28 --> Input Class Initialized
INFO - 2020-09-07 09:20:28 --> Controller Class Initialized
INFO - 2020-09-07 09:20:28 --> Model Class Initialized
INFO - 2020-09-07 09:20:28 --> Language Class Initialized
INFO - 2020-09-07 09:20:28 --> Model Class Initialized
DEBUG - 2020-09-07 09:20:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 09:20:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-07 09:20:28 --> Loader Class Initialized
INFO - 2020-09-07 09:20:28 --> Helper loaded: url_helper
INFO - 2020-09-07 09:20:28 --> Database Driver Class Initialized
INFO - 2020-09-07 09:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 09:20:28 --> Email Class Initialized
INFO - 2020-09-07 09:20:28 --> Controller Class Initialized
INFO - 2020-09-07 09:20:28 --> Model Class Initialized
INFO - 2020-09-07 09:20:28 --> Model Class Initialized
DEBUG - 2020-09-07 09:20:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-07 09:20:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 09:20:29 --> Config Class Initialized
INFO - 2020-09-07 09:20:29 --> Hooks Class Initialized
DEBUG - 2020-09-07 09:20:29 --> UTF-8 Support Enabled
INFO - 2020-09-07 09:20:29 --> Utf8 Class Initialized
INFO - 2020-09-07 09:20:29 --> URI Class Initialized
DEBUG - 2020-09-07 09:20:29 --> No URI present. Default controller set.
INFO - 2020-09-07 09:20:29 --> Router Class Initialized
INFO - 2020-09-07 09:20:29 --> Output Class Initialized
INFO - 2020-09-07 09:20:29 --> Security Class Initialized
DEBUG - 2020-09-07 09:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 09:20:29 --> Input Class Initialized
INFO - 2020-09-07 09:20:29 --> Language Class Initialized
INFO - 2020-09-07 09:20:29 --> Loader Class Initialized
INFO - 2020-09-07 09:20:29 --> Helper loaded: url_helper
INFO - 2020-09-07 09:20:29 --> Database Driver Class Initialized
ERROR - 2020-09-07 09:20:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 09:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 09:20:29 --> Config Class Initialized
INFO - 2020-09-07 09:20:29 --> Hooks Class Initialized
DEBUG - 2020-09-07 09:20:29 --> UTF-8 Support Enabled
INFO - 2020-09-07 09:20:29 --> Utf8 Class Initialized
INFO - 2020-09-07 09:20:29 --> URI Class Initialized
INFO - 2020-09-07 09:20:29 --> Email Class Initialized
INFO - 2020-09-07 09:20:29 --> Controller Class Initialized
INFO - 2020-09-07 09:20:29 --> Model Class Initialized
INFO - 2020-09-07 09:20:29 --> Router Class Initialized
INFO - 2020-09-07 09:20:29 --> Model Class Initialized
DEBUG - 2020-09-07 09:20:29 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-07 09:20:29 --> Output Class Initialized
INFO - 2020-09-07 09:20:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-07 09:20:29 --> Final output sent to browser
DEBUG - 2020-09-07 09:20:29 --> Total execution time: 0.0244
INFO - 2020-09-07 09:20:29 --> Security Class Initialized
DEBUG - 2020-09-07 09:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 09:20:29 --> Input Class Initialized
INFO - 2020-09-07 09:20:29 --> Language Class Initialized
INFO - 2020-09-07 09:20:29 --> Loader Class Initialized
INFO - 2020-09-07 09:20:29 --> Helper loaded: url_helper
INFO - 2020-09-07 09:20:29 --> Database Driver Class Initialized
INFO - 2020-09-07 09:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 09:20:29 --> Email Class Initialized
INFO - 2020-09-07 09:20:29 --> Controller Class Initialized
DEBUG - 2020-09-07 09:20:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 09:20:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-07 09:20:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-07 09:20:29 --> Final output sent to browser
DEBUG - 2020-09-07 09:20:29 --> Total execution time: 0.0436
ERROR - 2020-09-07 09:20:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 09:20:32 --> Config Class Initialized
INFO - 2020-09-07 09:20:32 --> Hooks Class Initialized
DEBUG - 2020-09-07 09:20:32 --> UTF-8 Support Enabled
INFO - 2020-09-07 09:20:32 --> Utf8 Class Initialized
INFO - 2020-09-07 09:20:32 --> URI Class Initialized
DEBUG - 2020-09-07 09:20:32 --> No URI present. Default controller set.
INFO - 2020-09-07 09:20:32 --> Router Class Initialized
INFO - 2020-09-07 09:20:32 --> Output Class Initialized
INFO - 2020-09-07 09:20:32 --> Security Class Initialized
DEBUG - 2020-09-07 09:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 09:20:32 --> Input Class Initialized
INFO - 2020-09-07 09:20:32 --> Language Class Initialized
INFO - 2020-09-07 09:20:32 --> Loader Class Initialized
INFO - 2020-09-07 09:20:32 --> Helper loaded: url_helper
INFO - 2020-09-07 09:20:32 --> Database Driver Class Initialized
INFO - 2020-09-07 09:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 09:20:32 --> Email Class Initialized
INFO - 2020-09-07 09:20:32 --> Controller Class Initialized
INFO - 2020-09-07 09:20:32 --> Model Class Initialized
INFO - 2020-09-07 09:20:32 --> Model Class Initialized
DEBUG - 2020-09-07 09:20:32 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-07 09:20:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-07 09:20:32 --> Final output sent to browser
DEBUG - 2020-09-07 09:20:32 --> Total execution time: 0.0309
ERROR - 2020-09-07 09:22:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 09:22:02 --> Config Class Initialized
INFO - 2020-09-07 09:22:02 --> Hooks Class Initialized
DEBUG - 2020-09-07 09:22:02 --> UTF-8 Support Enabled
INFO - 2020-09-07 09:22:02 --> Utf8 Class Initialized
INFO - 2020-09-07 09:22:02 --> URI Class Initialized
INFO - 2020-09-07 09:22:02 --> Router Class Initialized
INFO - 2020-09-07 09:22:02 --> Output Class Initialized
INFO - 2020-09-07 09:22:02 --> Security Class Initialized
DEBUG - 2020-09-07 09:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 09:22:02 --> Input Class Initialized
INFO - 2020-09-07 09:22:02 --> Language Class Initialized
ERROR - 2020-09-07 09:22:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 09:22:02 --> Loader Class Initialized
INFO - 2020-09-07 09:22:02 --> Config Class Initialized
INFO - 2020-09-07 09:22:02 --> Hooks Class Initialized
INFO - 2020-09-07 09:22:02 --> Helper loaded: url_helper
DEBUG - 2020-09-07 09:22:02 --> UTF-8 Support Enabled
INFO - 2020-09-07 09:22:02 --> Utf8 Class Initialized
INFO - 2020-09-07 09:22:02 --> URI Class Initialized
INFO - 2020-09-07 09:22:02 --> Router Class Initialized
INFO - 2020-09-07 09:22:02 --> Database Driver Class Initialized
INFO - 2020-09-07 09:22:02 --> Output Class Initialized
INFO - 2020-09-07 09:22:02 --> Security Class Initialized
DEBUG - 2020-09-07 09:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 09:22:02 --> Input Class Initialized
INFO - 2020-09-07 09:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 09:22:02 --> Language Class Initialized
INFO - 2020-09-07 09:22:02 --> Loader Class Initialized
INFO - 2020-09-07 09:22:02 --> Helper loaded: url_helper
INFO - 2020-09-07 09:22:02 --> Email Class Initialized
INFO - 2020-09-07 09:22:02 --> Controller Class Initialized
INFO - 2020-09-07 09:22:02 --> Model Class Initialized
INFO - 2020-09-07 09:22:02 --> Model Class Initialized
DEBUG - 2020-09-07 09:22:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 09:22:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-07 09:22:02 --> Model Class Initialized
INFO - 2020-09-07 09:22:02 --> Database Driver Class Initialized
INFO - 2020-09-07 09:22:02 --> Final output sent to browser
DEBUG - 2020-09-07 09:22:02 --> Total execution time: 0.0278
INFO - 2020-09-07 09:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 09:22:02 --> Email Class Initialized
INFO - 2020-09-07 09:22:02 --> Controller Class Initialized
INFO - 2020-09-07 09:22:02 --> Model Class Initialized
INFO - 2020-09-07 09:22:02 --> Model Class Initialized
DEBUG - 2020-09-07 09:22:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-07 09:22:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 09:22:02 --> Config Class Initialized
INFO - 2020-09-07 09:22:02 --> Hooks Class Initialized
DEBUG - 2020-09-07 09:22:02 --> UTF-8 Support Enabled
INFO - 2020-09-07 09:22:02 --> Utf8 Class Initialized
INFO - 2020-09-07 09:22:02 --> URI Class Initialized
INFO - 2020-09-07 09:22:02 --> Router Class Initialized
INFO - 2020-09-07 09:22:02 --> Output Class Initialized
INFO - 2020-09-07 09:22:02 --> Security Class Initialized
DEBUG - 2020-09-07 09:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 09:22:02 --> Input Class Initialized
INFO - 2020-09-07 09:22:02 --> Language Class Initialized
INFO - 2020-09-07 09:22:02 --> Loader Class Initialized
INFO - 2020-09-07 09:22:02 --> Helper loaded: url_helper
INFO - 2020-09-07 09:22:02 --> Database Driver Class Initialized
INFO - 2020-09-07 09:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 09:22:02 --> Email Class Initialized
INFO - 2020-09-07 09:22:02 --> Controller Class Initialized
DEBUG - 2020-09-07 09:22:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 09:22:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-07 09:22:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-07 09:22:02 --> Final output sent to browser
DEBUG - 2020-09-07 09:22:02 --> Total execution time: 0.0191
ERROR - 2020-09-07 09:22:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 09:22:09 --> Config Class Initialized
INFO - 2020-09-07 09:22:09 --> Hooks Class Initialized
DEBUG - 2020-09-07 09:22:09 --> UTF-8 Support Enabled
INFO - 2020-09-07 09:22:09 --> Utf8 Class Initialized
INFO - 2020-09-07 09:22:09 --> URI Class Initialized
DEBUG - 2020-09-07 09:22:09 --> No URI present. Default controller set.
INFO - 2020-09-07 09:22:09 --> Router Class Initialized
INFO - 2020-09-07 09:22:09 --> Output Class Initialized
INFO - 2020-09-07 09:22:09 --> Security Class Initialized
DEBUG - 2020-09-07 09:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 09:22:09 --> Input Class Initialized
INFO - 2020-09-07 09:22:09 --> Language Class Initialized
INFO - 2020-09-07 09:22:09 --> Loader Class Initialized
INFO - 2020-09-07 09:22:09 --> Helper loaded: url_helper
INFO - 2020-09-07 09:22:09 --> Database Driver Class Initialized
INFO - 2020-09-07 09:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 09:22:09 --> Email Class Initialized
INFO - 2020-09-07 09:22:09 --> Controller Class Initialized
INFO - 2020-09-07 09:22:09 --> Model Class Initialized
INFO - 2020-09-07 09:22:09 --> Model Class Initialized
DEBUG - 2020-09-07 09:22:09 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-07 09:22:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-07 09:22:09 --> Final output sent to browser
DEBUG - 2020-09-07 09:22:09 --> Total execution time: 0.0264
ERROR - 2020-09-07 09:23:51 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-07 09:33:26 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-07 09:37:45 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/subtract.php 18
ERROR - 2020-09-07 09:38:45 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/subtract.php 18
ERROR - 2020-09-07 09:38:48 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/subtract.php 18
ERROR - 2020-09-07 09:38:51 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/subtract.php 18
ERROR - 2020-09-07 09:39:27 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/multiply.php 18
ERROR - 2020-09-07 09:43:31 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/divideby.php 18
ERROR - 2020-09-07 09:43:42 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/divideby.php 18
ERROR - 2020-09-07 09:48:19 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/divideby.php 18
ERROR - 2020-09-07 09:48:30 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/divideby.php 18
ERROR - 2020-09-07 09:48:59 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/matrix/classes/src/operations/add.php 22
ERROR - 2020-09-07 09:50:10 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-07 11:24:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 11:24:42 --> Config Class Initialized
INFO - 2020-09-07 11:24:42 --> Hooks Class Initialized
DEBUG - 2020-09-07 11:24:42 --> UTF-8 Support Enabled
INFO - 2020-09-07 11:24:42 --> Utf8 Class Initialized
INFO - 2020-09-07 11:24:42 --> URI Class Initialized
DEBUG - 2020-09-07 11:24:42 --> No URI present. Default controller set.
INFO - 2020-09-07 11:24:42 --> Router Class Initialized
INFO - 2020-09-07 11:24:42 --> Output Class Initialized
INFO - 2020-09-07 11:24:42 --> Security Class Initialized
DEBUG - 2020-09-07 11:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 11:24:42 --> Input Class Initialized
INFO - 2020-09-07 11:24:42 --> Language Class Initialized
INFO - 2020-09-07 11:24:42 --> Loader Class Initialized
INFO - 2020-09-07 11:24:42 --> Helper loaded: url_helper
INFO - 2020-09-07 11:24:42 --> Database Driver Class Initialized
INFO - 2020-09-07 11:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 11:24:42 --> Email Class Initialized
INFO - 2020-09-07 11:24:42 --> Controller Class Initialized
INFO - 2020-09-07 11:24:42 --> Model Class Initialized
INFO - 2020-09-07 11:24:42 --> Model Class Initialized
DEBUG - 2020-09-07 11:24:42 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-07 11:24:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-07 11:24:42 --> Final output sent to browser
DEBUG - 2020-09-07 11:24:42 --> Total execution time: 0.0210
ERROR - 2020-09-07 11:24:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 11:24:44 --> Config Class Initialized
INFO - 2020-09-07 11:24:44 --> Hooks Class Initialized
DEBUG - 2020-09-07 11:24:44 --> UTF-8 Support Enabled
INFO - 2020-09-07 11:24:44 --> Utf8 Class Initialized
INFO - 2020-09-07 11:24:44 --> URI Class Initialized
INFO - 2020-09-07 11:24:44 --> Router Class Initialized
INFO - 2020-09-07 11:24:44 --> Output Class Initialized
INFO - 2020-09-07 11:24:44 --> Security Class Initialized
DEBUG - 2020-09-07 11:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 11:24:44 --> Input Class Initialized
INFO - 2020-09-07 11:24:44 --> Language Class Initialized
INFO - 2020-09-07 11:24:44 --> Loader Class Initialized
INFO - 2020-09-07 11:24:44 --> Helper loaded: url_helper
INFO - 2020-09-07 11:24:44 --> Database Driver Class Initialized
INFO - 2020-09-07 11:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 11:24:44 --> Email Class Initialized
INFO - 2020-09-07 11:24:44 --> Controller Class Initialized
INFO - 2020-09-07 11:24:44 --> Model Class Initialized
INFO - 2020-09-07 11:24:44 --> Model Class Initialized
DEBUG - 2020-09-07 11:24:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 11:24:44 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-07 11:24:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 11:24:44 --> Config Class Initialized
INFO - 2020-09-07 11:24:44 --> Hooks Class Initialized
DEBUG - 2020-09-07 11:24:44 --> UTF-8 Support Enabled
INFO - 2020-09-07 11:24:44 --> Utf8 Class Initialized
INFO - 2020-09-07 11:24:44 --> URI Class Initialized
INFO - 2020-09-07 11:24:44 --> Router Class Initialized
INFO - 2020-09-07 11:24:44 --> Output Class Initialized
INFO - 2020-09-07 11:24:44 --> Security Class Initialized
DEBUG - 2020-09-07 11:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 11:24:44 --> Input Class Initialized
INFO - 2020-09-07 11:24:44 --> Language Class Initialized
INFO - 2020-09-07 11:24:44 --> Loader Class Initialized
INFO - 2020-09-07 11:24:44 --> Helper loaded: url_helper
INFO - 2020-09-07 11:24:44 --> Database Driver Class Initialized
INFO - 2020-09-07 11:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 11:24:44 --> Email Class Initialized
INFO - 2020-09-07 11:24:44 --> Controller Class Initialized
INFO - 2020-09-07 11:24:44 --> Model Class Initialized
INFO - 2020-09-07 11:24:44 --> Model Class Initialized
DEBUG - 2020-09-07 11:24:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-07 11:24:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 11:24:44 --> Config Class Initialized
INFO - 2020-09-07 11:24:44 --> Hooks Class Initialized
DEBUG - 2020-09-07 11:24:44 --> UTF-8 Support Enabled
INFO - 2020-09-07 11:24:44 --> Utf8 Class Initialized
INFO - 2020-09-07 11:24:44 --> URI Class Initialized
DEBUG - 2020-09-07 11:24:44 --> No URI present. Default controller set.
INFO - 2020-09-07 11:24:44 --> Router Class Initialized
INFO - 2020-09-07 11:24:44 --> Output Class Initialized
INFO - 2020-09-07 11:24:44 --> Security Class Initialized
DEBUG - 2020-09-07 11:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 11:24:44 --> Input Class Initialized
INFO - 2020-09-07 11:24:44 --> Language Class Initialized
INFO - 2020-09-07 11:24:44 --> Loader Class Initialized
INFO - 2020-09-07 11:24:44 --> Helper loaded: url_helper
INFO - 2020-09-07 11:24:44 --> Database Driver Class Initialized
INFO - 2020-09-07 11:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 11:24:44 --> Email Class Initialized
INFO - 2020-09-07 11:24:44 --> Controller Class Initialized
INFO - 2020-09-07 11:24:44 --> Model Class Initialized
INFO - 2020-09-07 11:24:44 --> Model Class Initialized
DEBUG - 2020-09-07 11:24:44 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-07 11:24:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-07 11:24:44 --> Final output sent to browser
DEBUG - 2020-09-07 11:24:44 --> Total execution time: 0.0224
ERROR - 2020-09-07 11:24:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 11:24:44 --> Config Class Initialized
INFO - 2020-09-07 11:24:44 --> Hooks Class Initialized
DEBUG - 2020-09-07 11:24:44 --> UTF-8 Support Enabled
INFO - 2020-09-07 11:24:44 --> Utf8 Class Initialized
INFO - 2020-09-07 11:24:44 --> URI Class Initialized
INFO - 2020-09-07 11:24:44 --> Router Class Initialized
INFO - 2020-09-07 11:24:44 --> Output Class Initialized
INFO - 2020-09-07 11:24:44 --> Security Class Initialized
DEBUG - 2020-09-07 11:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 11:24:44 --> Input Class Initialized
INFO - 2020-09-07 11:24:44 --> Language Class Initialized
INFO - 2020-09-07 11:24:44 --> Loader Class Initialized
INFO - 2020-09-07 11:24:44 --> Helper loaded: url_helper
INFO - 2020-09-07 11:24:44 --> Database Driver Class Initialized
INFO - 2020-09-07 11:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 11:24:44 --> Email Class Initialized
INFO - 2020-09-07 11:24:44 --> Controller Class Initialized
DEBUG - 2020-09-07 11:24:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 11:24:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-07 11:24:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-07 11:24:44 --> Final output sent to browser
DEBUG - 2020-09-07 11:24:44 --> Total execution time: 0.0214
ERROR - 2020-09-07 11:25:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 11:25:01 --> Config Class Initialized
INFO - 2020-09-07 11:25:01 --> Hooks Class Initialized
DEBUG - 2020-09-07 11:25:01 --> UTF-8 Support Enabled
INFO - 2020-09-07 11:25:01 --> Utf8 Class Initialized
INFO - 2020-09-07 11:25:01 --> URI Class Initialized
INFO - 2020-09-07 11:25:01 --> Router Class Initialized
INFO - 2020-09-07 11:25:01 --> Output Class Initialized
INFO - 2020-09-07 11:25:01 --> Security Class Initialized
DEBUG - 2020-09-07 11:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 11:25:01 --> Input Class Initialized
INFO - 2020-09-07 11:25:01 --> Language Class Initialized
INFO - 2020-09-07 11:25:01 --> Loader Class Initialized
INFO - 2020-09-07 11:25:01 --> Helper loaded: url_helper
INFO - 2020-09-07 11:25:01 --> Database Driver Class Initialized
INFO - 2020-09-07 11:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 11:25:01 --> Email Class Initialized
INFO - 2020-09-07 11:25:01 --> Controller Class Initialized
INFO - 2020-09-07 11:25:01 --> Model Class Initialized
INFO - 2020-09-07 11:25:01 --> Model Class Initialized
INFO - 2020-09-07 11:25:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_import.php
INFO - 2020-09-07 11:25:01 --> Final output sent to browser
DEBUG - 2020-09-07 11:25:01 --> Total execution time: 0.0449
ERROR - 2020-09-07 11:25:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 11:25:12 --> Config Class Initialized
INFO - 2020-09-07 11:25:12 --> Hooks Class Initialized
DEBUG - 2020-09-07 11:25:12 --> UTF-8 Support Enabled
INFO - 2020-09-07 11:25:12 --> Utf8 Class Initialized
INFO - 2020-09-07 11:25:12 --> URI Class Initialized
INFO - 2020-09-07 11:25:12 --> Router Class Initialized
INFO - 2020-09-07 11:25:12 --> Output Class Initialized
INFO - 2020-09-07 11:25:12 --> Security Class Initialized
DEBUG - 2020-09-07 11:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 11:25:12 --> Input Class Initialized
INFO - 2020-09-07 11:25:12 --> Language Class Initialized
INFO - 2020-09-07 11:25:12 --> Loader Class Initialized
INFO - 2020-09-07 11:25:12 --> Helper loaded: url_helper
INFO - 2020-09-07 11:25:12 --> Database Driver Class Initialized
INFO - 2020-09-07 11:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 11:25:12 --> Email Class Initialized
INFO - 2020-09-07 11:25:12 --> Controller Class Initialized
INFO - 2020-09-07 11:25:12 --> Model Class Initialized
INFO - 2020-09-07 11:25:12 --> Model Class Initialized
INFO - 2020-09-07 11:25:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_import.php
INFO - 2020-09-07 11:25:12 --> Final output sent to browser
DEBUG - 2020-09-07 11:25:12 --> Total execution time: 0.0387
ERROR - 2020-09-07 11:28:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 11:28:14 --> Config Class Initialized
INFO - 2020-09-07 11:28:14 --> Hooks Class Initialized
DEBUG - 2020-09-07 11:28:14 --> UTF-8 Support Enabled
INFO - 2020-09-07 11:28:14 --> Utf8 Class Initialized
INFO - 2020-09-07 11:28:14 --> URI Class Initialized
INFO - 2020-09-07 11:28:14 --> Router Class Initialized
INFO - 2020-09-07 11:28:14 --> Output Class Initialized
INFO - 2020-09-07 11:28:14 --> Security Class Initialized
DEBUG - 2020-09-07 11:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 11:28:14 --> Input Class Initialized
INFO - 2020-09-07 11:28:14 --> Language Class Initialized
INFO - 2020-09-07 11:28:14 --> Loader Class Initialized
INFO - 2020-09-07 11:28:14 --> Helper loaded: url_helper
INFO - 2020-09-07 11:28:14 --> Database Driver Class Initialized
INFO - 2020-09-07 11:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 11:28:14 --> Email Class Initialized
INFO - 2020-09-07 11:28:14 --> Controller Class Initialized
INFO - 2020-09-07 11:28:14 --> Model Class Initialized
INFO - 2020-09-07 11:28:14 --> Model Class Initialized
INFO - 2020-09-07 11:28:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_import.php
INFO - 2020-09-07 11:28:14 --> Final output sent to browser
DEBUG - 2020-09-07 11:28:14 --> Total execution time: 0.0699
ERROR - 2020-09-07 11:29:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 11:29:31 --> Config Class Initialized
INFO - 2020-09-07 11:29:31 --> Hooks Class Initialized
DEBUG - 2020-09-07 11:29:31 --> UTF-8 Support Enabled
INFO - 2020-09-07 11:29:31 --> Utf8 Class Initialized
INFO - 2020-09-07 11:29:31 --> URI Class Initialized
INFO - 2020-09-07 11:29:31 --> Router Class Initialized
INFO - 2020-09-07 11:29:31 --> Output Class Initialized
INFO - 2020-09-07 11:29:31 --> Security Class Initialized
DEBUG - 2020-09-07 11:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 11:29:31 --> Input Class Initialized
INFO - 2020-09-07 11:29:31 --> Language Class Initialized
INFO - 2020-09-07 11:29:31 --> Loader Class Initialized
INFO - 2020-09-07 11:29:31 --> Helper loaded: url_helper
INFO - 2020-09-07 11:29:31 --> Database Driver Class Initialized
INFO - 2020-09-07 11:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 11:29:31 --> Email Class Initialized
INFO - 2020-09-07 11:29:31 --> Controller Class Initialized
INFO - 2020-09-07 11:29:31 --> Model Class Initialized
INFO - 2020-09-07 11:29:31 --> Model Class Initialized
INFO - 2020-09-07 11:29:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_import.php
INFO - 2020-09-07 11:29:31 --> Final output sent to browser
DEBUG - 2020-09-07 11:29:31 --> Total execution time: 0.0447
ERROR - 2020-09-07 11:32:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 11:32:01 --> Config Class Initialized
INFO - 2020-09-07 11:32:01 --> Hooks Class Initialized
DEBUG - 2020-09-07 11:32:01 --> UTF-8 Support Enabled
INFO - 2020-09-07 11:32:01 --> Utf8 Class Initialized
INFO - 2020-09-07 11:32:01 --> URI Class Initialized
INFO - 2020-09-07 11:32:01 --> Router Class Initialized
INFO - 2020-09-07 11:32:01 --> Output Class Initialized
INFO - 2020-09-07 11:32:01 --> Security Class Initialized
DEBUG - 2020-09-07 11:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 11:32:01 --> Input Class Initialized
INFO - 2020-09-07 11:32:01 --> Language Class Initialized
INFO - 2020-09-07 11:32:01 --> Loader Class Initialized
INFO - 2020-09-07 11:32:01 --> Helper loaded: url_helper
INFO - 2020-09-07 11:32:01 --> Database Driver Class Initialized
INFO - 2020-09-07 11:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 11:32:01 --> Email Class Initialized
INFO - 2020-09-07 11:32:01 --> Controller Class Initialized
INFO - 2020-09-07 11:32:01 --> Model Class Initialized
INFO - 2020-09-07 11:32:01 --> Model Class Initialized
INFO - 2020-09-07 11:32:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_import.php
INFO - 2020-09-07 11:32:01 --> Final output sent to browser
DEBUG - 2020-09-07 11:32:01 --> Total execution time: 0.0435
ERROR - 2020-09-07 11:33:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 11:33:09 --> Config Class Initialized
INFO - 2020-09-07 11:33:09 --> Hooks Class Initialized
DEBUG - 2020-09-07 11:33:09 --> UTF-8 Support Enabled
INFO - 2020-09-07 11:33:09 --> Utf8 Class Initialized
INFO - 2020-09-07 11:33:09 --> URI Class Initialized
INFO - 2020-09-07 11:33:09 --> Router Class Initialized
INFO - 2020-09-07 11:33:09 --> Output Class Initialized
INFO - 2020-09-07 11:33:09 --> Security Class Initialized
DEBUG - 2020-09-07 11:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 11:33:09 --> Input Class Initialized
INFO - 2020-09-07 11:33:09 --> Language Class Initialized
INFO - 2020-09-07 11:33:09 --> Loader Class Initialized
INFO - 2020-09-07 11:33:09 --> Helper loaded: url_helper
INFO - 2020-09-07 11:33:09 --> Database Driver Class Initialized
INFO - 2020-09-07 11:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 11:33:09 --> Email Class Initialized
INFO - 2020-09-07 11:33:09 --> Controller Class Initialized
INFO - 2020-09-07 11:33:09 --> Model Class Initialized
INFO - 2020-09-07 11:33:09 --> Model Class Initialized
INFO - 2020-09-07 11:33:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_import.php
INFO - 2020-09-07 11:33:09 --> Final output sent to browser
DEBUG - 2020-09-07 11:33:09 --> Total execution time: 0.0390
ERROR - 2020-09-07 11:33:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 11:33:18 --> Config Class Initialized
INFO - 2020-09-07 11:33:18 --> Hooks Class Initialized
DEBUG - 2020-09-07 11:33:18 --> UTF-8 Support Enabled
INFO - 2020-09-07 11:33:18 --> Utf8 Class Initialized
INFO - 2020-09-07 11:33:18 --> URI Class Initialized
INFO - 2020-09-07 11:33:18 --> Router Class Initialized
INFO - 2020-09-07 11:33:18 --> Output Class Initialized
INFO - 2020-09-07 11:33:18 --> Security Class Initialized
DEBUG - 2020-09-07 11:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 11:33:18 --> Input Class Initialized
INFO - 2020-09-07 11:33:18 --> Language Class Initialized
INFO - 2020-09-07 11:33:18 --> Loader Class Initialized
INFO - 2020-09-07 11:33:18 --> Helper loaded: url_helper
INFO - 2020-09-07 11:33:18 --> Database Driver Class Initialized
INFO - 2020-09-07 11:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 11:33:18 --> Email Class Initialized
INFO - 2020-09-07 11:33:18 --> Controller Class Initialized
INFO - 2020-09-07 11:33:18 --> Model Class Initialized
INFO - 2020-09-07 11:33:18 --> Model Class Initialized
INFO - 2020-09-07 11:33:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_import.php
INFO - 2020-09-07 11:33:18 --> Final output sent to browser
DEBUG - 2020-09-07 11:33:18 --> Total execution time: 0.0438
ERROR - 2020-09-07 11:38:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 11:38:14 --> Config Class Initialized
INFO - 2020-09-07 11:38:14 --> Hooks Class Initialized
DEBUG - 2020-09-07 11:38:14 --> UTF-8 Support Enabled
INFO - 2020-09-07 11:38:14 --> Utf8 Class Initialized
INFO - 2020-09-07 11:38:14 --> URI Class Initialized
INFO - 2020-09-07 11:38:14 --> Router Class Initialized
INFO - 2020-09-07 11:38:14 --> Output Class Initialized
INFO - 2020-09-07 11:38:14 --> Security Class Initialized
DEBUG - 2020-09-07 11:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 11:38:14 --> Input Class Initialized
INFO - 2020-09-07 11:38:14 --> Language Class Initialized
INFO - 2020-09-07 11:38:14 --> Loader Class Initialized
INFO - 2020-09-07 11:38:14 --> Helper loaded: url_helper
INFO - 2020-09-07 11:38:14 --> Database Driver Class Initialized
INFO - 2020-09-07 11:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 11:38:14 --> Email Class Initialized
INFO - 2020-09-07 11:38:14 --> Controller Class Initialized
INFO - 2020-09-07 11:38:14 --> Model Class Initialized
INFO - 2020-09-07 11:38:14 --> Model Class Initialized
INFO - 2020-09-07 11:38:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_import.php
INFO - 2020-09-07 11:38:14 --> Final output sent to browser
DEBUG - 2020-09-07 11:38:14 --> Total execution time: 0.0408
ERROR - 2020-09-07 11:38:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 11:38:52 --> Config Class Initialized
INFO - 2020-09-07 11:38:52 --> Hooks Class Initialized
DEBUG - 2020-09-07 11:38:52 --> UTF-8 Support Enabled
INFO - 2020-09-07 11:38:52 --> Utf8 Class Initialized
INFO - 2020-09-07 11:38:52 --> URI Class Initialized
INFO - 2020-09-07 11:38:52 --> Router Class Initialized
INFO - 2020-09-07 11:38:52 --> Output Class Initialized
INFO - 2020-09-07 11:38:52 --> Security Class Initialized
DEBUG - 2020-09-07 11:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 11:38:52 --> Input Class Initialized
INFO - 2020-09-07 11:38:52 --> Language Class Initialized
INFO - 2020-09-07 11:38:52 --> Loader Class Initialized
INFO - 2020-09-07 11:38:52 --> Helper loaded: url_helper
INFO - 2020-09-07 11:38:52 --> Database Driver Class Initialized
INFO - 2020-09-07 11:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 11:38:52 --> Email Class Initialized
INFO - 2020-09-07 11:38:52 --> Controller Class Initialized
INFO - 2020-09-07 11:38:52 --> Model Class Initialized
INFO - 2020-09-07 11:38:52 --> Model Class Initialized
INFO - 2020-09-07 11:38:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_import.php
INFO - 2020-09-07 11:38:52 --> Final output sent to browser
DEBUG - 2020-09-07 11:38:52 --> Total execution time: 0.0347
ERROR - 2020-09-07 11:39:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 11:39:50 --> Config Class Initialized
INFO - 2020-09-07 11:39:50 --> Hooks Class Initialized
DEBUG - 2020-09-07 11:39:50 --> UTF-8 Support Enabled
INFO - 2020-09-07 11:39:50 --> Utf8 Class Initialized
INFO - 2020-09-07 11:39:50 --> URI Class Initialized
INFO - 2020-09-07 11:39:50 --> Router Class Initialized
INFO - 2020-09-07 11:39:50 --> Output Class Initialized
INFO - 2020-09-07 11:39:50 --> Security Class Initialized
DEBUG - 2020-09-07 11:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 11:39:50 --> Input Class Initialized
INFO - 2020-09-07 11:39:50 --> Language Class Initialized
INFO - 2020-09-07 11:39:50 --> Loader Class Initialized
INFO - 2020-09-07 11:39:50 --> Helper loaded: url_helper
INFO - 2020-09-07 11:39:50 --> Database Driver Class Initialized
INFO - 2020-09-07 11:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 11:39:50 --> Email Class Initialized
INFO - 2020-09-07 11:39:50 --> Controller Class Initialized
INFO - 2020-09-07 11:39:50 --> Model Class Initialized
INFO - 2020-09-07 11:39:50 --> Model Class Initialized
INFO - 2020-09-07 11:39:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_import.php
INFO - 2020-09-07 11:39:50 --> Final output sent to browser
DEBUG - 2020-09-07 11:39:50 --> Total execution time: 0.0456
ERROR - 2020-09-07 11:41:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 11:41:12 --> Config Class Initialized
INFO - 2020-09-07 11:41:12 --> Hooks Class Initialized
DEBUG - 2020-09-07 11:41:12 --> UTF-8 Support Enabled
INFO - 2020-09-07 11:41:12 --> Utf8 Class Initialized
INFO - 2020-09-07 11:41:12 --> URI Class Initialized
INFO - 2020-09-07 11:41:12 --> Router Class Initialized
INFO - 2020-09-07 11:41:12 --> Output Class Initialized
INFO - 2020-09-07 11:41:12 --> Security Class Initialized
DEBUG - 2020-09-07 11:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 11:41:12 --> Input Class Initialized
INFO - 2020-09-07 11:41:12 --> Language Class Initialized
INFO - 2020-09-07 11:41:12 --> Loader Class Initialized
INFO - 2020-09-07 11:41:12 --> Helper loaded: url_helper
INFO - 2020-09-07 11:41:12 --> Database Driver Class Initialized
INFO - 2020-09-07 11:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 11:41:12 --> Email Class Initialized
INFO - 2020-09-07 11:41:12 --> Controller Class Initialized
INFO - 2020-09-07 11:41:12 --> Model Class Initialized
INFO - 2020-09-07 11:41:12 --> Model Class Initialized
INFO - 2020-09-07 11:41:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_import.php
INFO - 2020-09-07 11:41:12 --> Final output sent to browser
DEBUG - 2020-09-07 11:41:12 --> Total execution time: 0.0421
ERROR - 2020-09-07 11:42:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 11:42:32 --> Config Class Initialized
INFO - 2020-09-07 11:42:32 --> Hooks Class Initialized
DEBUG - 2020-09-07 11:42:32 --> UTF-8 Support Enabled
INFO - 2020-09-07 11:42:32 --> Utf8 Class Initialized
INFO - 2020-09-07 11:42:32 --> URI Class Initialized
INFO - 2020-09-07 11:42:32 --> Router Class Initialized
INFO - 2020-09-07 11:42:32 --> Output Class Initialized
INFO - 2020-09-07 11:42:32 --> Security Class Initialized
DEBUG - 2020-09-07 11:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 11:42:32 --> Input Class Initialized
INFO - 2020-09-07 11:42:32 --> Language Class Initialized
INFO - 2020-09-07 11:42:32 --> Loader Class Initialized
INFO - 2020-09-07 11:42:32 --> Helper loaded: url_helper
INFO - 2020-09-07 11:42:32 --> Database Driver Class Initialized
INFO - 2020-09-07 11:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 11:42:32 --> Email Class Initialized
INFO - 2020-09-07 11:42:32 --> Controller Class Initialized
INFO - 2020-09-07 11:42:32 --> Model Class Initialized
INFO - 2020-09-07 11:42:32 --> Model Class Initialized
INFO - 2020-09-07 11:42:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_import.php
INFO - 2020-09-07 11:42:32 --> Final output sent to browser
DEBUG - 2020-09-07 11:42:32 --> Total execution time: 0.0393
ERROR - 2020-09-07 11:46:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 11:46:45 --> Config Class Initialized
INFO - 2020-09-07 11:46:45 --> Hooks Class Initialized
DEBUG - 2020-09-07 11:46:45 --> UTF-8 Support Enabled
INFO - 2020-09-07 11:46:45 --> Utf8 Class Initialized
INFO - 2020-09-07 11:46:45 --> URI Class Initialized
INFO - 2020-09-07 11:46:45 --> Router Class Initialized
INFO - 2020-09-07 11:46:45 --> Output Class Initialized
INFO - 2020-09-07 11:46:45 --> Security Class Initialized
DEBUG - 2020-09-07 11:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 11:46:45 --> Input Class Initialized
INFO - 2020-09-07 11:46:45 --> Language Class Initialized
INFO - 2020-09-07 11:46:45 --> Loader Class Initialized
INFO - 2020-09-07 11:46:45 --> Helper loaded: url_helper
INFO - 2020-09-07 11:46:45 --> Database Driver Class Initialized
INFO - 2020-09-07 11:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 11:46:45 --> Email Class Initialized
INFO - 2020-09-07 11:46:45 --> Controller Class Initialized
INFO - 2020-09-07 11:46:46 --> Model Class Initialized
INFO - 2020-09-07 11:46:46 --> Model Class Initialized
INFO - 2020-09-07 11:46:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_import.php
INFO - 2020-09-07 11:46:46 --> Final output sent to browser
DEBUG - 2020-09-07 11:46:46 --> Total execution time: 0.0451
ERROR - 2020-09-07 11:49:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 11:49:15 --> Config Class Initialized
INFO - 2020-09-07 11:49:15 --> Hooks Class Initialized
DEBUG - 2020-09-07 11:49:15 --> UTF-8 Support Enabled
INFO - 2020-09-07 11:49:15 --> Utf8 Class Initialized
INFO - 2020-09-07 11:49:15 --> URI Class Initialized
INFO - 2020-09-07 11:49:15 --> Router Class Initialized
INFO - 2020-09-07 11:49:15 --> Output Class Initialized
INFO - 2020-09-07 11:49:15 --> Security Class Initialized
DEBUG - 2020-09-07 11:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 11:49:15 --> Input Class Initialized
INFO - 2020-09-07 11:49:15 --> Language Class Initialized
ERROR - 2020-09-07 11:49:15 --> 404 Page Not Found: Excel_import/index
ERROR - 2020-09-07 11:49:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 11:49:23 --> Config Class Initialized
INFO - 2020-09-07 11:49:23 --> Hooks Class Initialized
DEBUG - 2020-09-07 11:49:23 --> UTF-8 Support Enabled
INFO - 2020-09-07 11:49:23 --> Utf8 Class Initialized
INFO - 2020-09-07 11:49:23 --> URI Class Initialized
INFO - 2020-09-07 11:49:23 --> Router Class Initialized
INFO - 2020-09-07 11:49:23 --> Output Class Initialized
INFO - 2020-09-07 11:49:23 --> Security Class Initialized
DEBUG - 2020-09-07 11:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 11:49:23 --> Input Class Initialized
INFO - 2020-09-07 11:49:23 --> Language Class Initialized
INFO - 2020-09-07 11:49:23 --> Loader Class Initialized
INFO - 2020-09-07 11:49:23 --> Helper loaded: url_helper
INFO - 2020-09-07 11:49:23 --> Database Driver Class Initialized
INFO - 2020-09-07 11:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 11:49:23 --> Email Class Initialized
INFO - 2020-09-07 11:49:23 --> Controller Class Initialized
INFO - 2020-09-07 11:49:23 --> Model Class Initialized
INFO - 2020-09-07 11:49:23 --> Model Class Initialized
INFO - 2020-09-07 11:49:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_import.php
INFO - 2020-09-07 11:49:23 --> Final output sent to browser
DEBUG - 2020-09-07 11:49:23 --> Total execution time: 0.0438
ERROR - 2020-09-07 11:56:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 11:56:21 --> Config Class Initialized
INFO - 2020-09-07 11:56:21 --> Hooks Class Initialized
DEBUG - 2020-09-07 11:56:21 --> UTF-8 Support Enabled
INFO - 2020-09-07 11:56:21 --> Utf8 Class Initialized
INFO - 2020-09-07 11:56:21 --> URI Class Initialized
INFO - 2020-09-07 11:56:21 --> Router Class Initialized
INFO - 2020-09-07 11:56:21 --> Output Class Initialized
INFO - 2020-09-07 11:56:21 --> Security Class Initialized
DEBUG - 2020-09-07 11:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 11:56:21 --> Input Class Initialized
INFO - 2020-09-07 11:56:21 --> Language Class Initialized
INFO - 2020-09-07 11:56:21 --> Loader Class Initialized
INFO - 2020-09-07 11:56:21 --> Helper loaded: url_helper
INFO - 2020-09-07 11:56:21 --> Database Driver Class Initialized
INFO - 2020-09-07 11:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 11:56:21 --> Email Class Initialized
INFO - 2020-09-07 11:56:21 --> Controller Class Initialized
INFO - 2020-09-07 11:56:21 --> Model Class Initialized
INFO - 2020-09-07 11:56:21 --> Model Class Initialized
INFO - 2020-09-07 11:56:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_import.php
INFO - 2020-09-07 11:56:21 --> Final output sent to browser
DEBUG - 2020-09-07 11:56:21 --> Total execution time: 0.0405
ERROR - 2020-09-07 11:58:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 11:58:28 --> Config Class Initialized
INFO - 2020-09-07 11:58:28 --> Hooks Class Initialized
DEBUG - 2020-09-07 11:58:28 --> UTF-8 Support Enabled
INFO - 2020-09-07 11:58:28 --> Utf8 Class Initialized
INFO - 2020-09-07 11:58:28 --> URI Class Initialized
INFO - 2020-09-07 11:58:28 --> Router Class Initialized
INFO - 2020-09-07 11:58:28 --> Output Class Initialized
INFO - 2020-09-07 11:58:28 --> Security Class Initialized
DEBUG - 2020-09-07 11:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 11:58:28 --> Input Class Initialized
INFO - 2020-09-07 11:58:28 --> Language Class Initialized
INFO - 2020-09-07 11:58:28 --> Loader Class Initialized
INFO - 2020-09-07 11:58:28 --> Helper loaded: url_helper
INFO - 2020-09-07 11:58:28 --> Database Driver Class Initialized
INFO - 2020-09-07 11:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 11:58:28 --> Email Class Initialized
INFO - 2020-09-07 11:58:28 --> Controller Class Initialized
INFO - 2020-09-07 11:58:28 --> Model Class Initialized
INFO - 2020-09-07 11:58:28 --> Model Class Initialized
INFO - 2020-09-07 11:58:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_import.php
INFO - 2020-09-07 11:58:28 --> Final output sent to browser
DEBUG - 2020-09-07 11:58:28 --> Total execution time: 0.0432
ERROR - 2020-09-07 11:59:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 11:59:54 --> Config Class Initialized
INFO - 2020-09-07 11:59:54 --> Hooks Class Initialized
DEBUG - 2020-09-07 11:59:54 --> UTF-8 Support Enabled
INFO - 2020-09-07 11:59:54 --> Utf8 Class Initialized
INFO - 2020-09-07 11:59:54 --> URI Class Initialized
INFO - 2020-09-07 11:59:54 --> Router Class Initialized
INFO - 2020-09-07 11:59:54 --> Output Class Initialized
INFO - 2020-09-07 11:59:54 --> Security Class Initialized
DEBUG - 2020-09-07 11:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 11:59:54 --> Input Class Initialized
INFO - 2020-09-07 11:59:54 --> Language Class Initialized
INFO - 2020-09-07 11:59:54 --> Loader Class Initialized
INFO - 2020-09-07 11:59:54 --> Helper loaded: url_helper
INFO - 2020-09-07 11:59:54 --> Database Driver Class Initialized
INFO - 2020-09-07 11:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 11:59:54 --> Email Class Initialized
INFO - 2020-09-07 11:59:54 --> Controller Class Initialized
INFO - 2020-09-07 11:59:54 --> Model Class Initialized
INFO - 2020-09-07 11:59:54 --> Model Class Initialized
INFO - 2020-09-07 11:59:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_import.php
INFO - 2020-09-07 11:59:54 --> Final output sent to browser
DEBUG - 2020-09-07 11:59:54 --> Total execution time: 0.0441
ERROR - 2020-09-07 12:00:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 12:00:45 --> Config Class Initialized
INFO - 2020-09-07 12:00:45 --> Hooks Class Initialized
DEBUG - 2020-09-07 12:00:45 --> UTF-8 Support Enabled
INFO - 2020-09-07 12:00:45 --> Utf8 Class Initialized
INFO - 2020-09-07 12:00:45 --> URI Class Initialized
INFO - 2020-09-07 12:00:45 --> Router Class Initialized
INFO - 2020-09-07 12:00:45 --> Output Class Initialized
INFO - 2020-09-07 12:00:45 --> Security Class Initialized
DEBUG - 2020-09-07 12:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 12:00:45 --> Input Class Initialized
INFO - 2020-09-07 12:00:45 --> Language Class Initialized
INFO - 2020-09-07 12:00:45 --> Loader Class Initialized
INFO - 2020-09-07 12:00:45 --> Helper loaded: url_helper
INFO - 2020-09-07 12:00:45 --> Database Driver Class Initialized
INFO - 2020-09-07 12:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 12:00:45 --> Email Class Initialized
INFO - 2020-09-07 12:00:45 --> Controller Class Initialized
INFO - 2020-09-07 12:00:45 --> Model Class Initialized
INFO - 2020-09-07 12:00:45 --> Model Class Initialized
INFO - 2020-09-07 12:00:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_import.php
INFO - 2020-09-07 12:00:45 --> Final output sent to browser
DEBUG - 2020-09-07 12:00:45 --> Total execution time: 0.0491
ERROR - 2020-09-07 12:01:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 12:01:34 --> Config Class Initialized
INFO - 2020-09-07 12:01:34 --> Hooks Class Initialized
DEBUG - 2020-09-07 12:01:34 --> UTF-8 Support Enabled
INFO - 2020-09-07 12:01:34 --> Utf8 Class Initialized
INFO - 2020-09-07 12:01:34 --> URI Class Initialized
INFO - 2020-09-07 12:01:34 --> Router Class Initialized
INFO - 2020-09-07 12:01:34 --> Output Class Initialized
INFO - 2020-09-07 12:01:34 --> Security Class Initialized
DEBUG - 2020-09-07 12:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 12:01:34 --> Input Class Initialized
INFO - 2020-09-07 12:01:34 --> Language Class Initialized
INFO - 2020-09-07 12:01:34 --> Loader Class Initialized
INFO - 2020-09-07 12:01:34 --> Helper loaded: url_helper
INFO - 2020-09-07 12:01:34 --> Database Driver Class Initialized
INFO - 2020-09-07 12:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 12:01:34 --> Email Class Initialized
INFO - 2020-09-07 12:01:34 --> Controller Class Initialized
INFO - 2020-09-07 12:01:34 --> Model Class Initialized
INFO - 2020-09-07 12:01:34 --> Model Class Initialized
INFO - 2020-09-07 12:01:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_import.php
INFO - 2020-09-07 12:01:34 --> Final output sent to browser
DEBUG - 2020-09-07 12:01:34 --> Total execution time: 0.0444
ERROR - 2020-09-07 12:03:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 12:03:09 --> Config Class Initialized
INFO - 2020-09-07 12:03:09 --> Hooks Class Initialized
DEBUG - 2020-09-07 12:03:09 --> UTF-8 Support Enabled
INFO - 2020-09-07 12:03:09 --> Utf8 Class Initialized
INFO - 2020-09-07 12:03:09 --> URI Class Initialized
INFO - 2020-09-07 12:03:09 --> Router Class Initialized
INFO - 2020-09-07 12:03:09 --> Output Class Initialized
INFO - 2020-09-07 12:03:09 --> Security Class Initialized
DEBUG - 2020-09-07 12:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 12:03:09 --> Input Class Initialized
INFO - 2020-09-07 12:03:09 --> Language Class Initialized
INFO - 2020-09-07 12:03:09 --> Loader Class Initialized
INFO - 2020-09-07 12:03:09 --> Helper loaded: url_helper
INFO - 2020-09-07 12:03:09 --> Database Driver Class Initialized
INFO - 2020-09-07 12:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 12:03:09 --> Email Class Initialized
INFO - 2020-09-07 12:03:09 --> Controller Class Initialized
INFO - 2020-09-07 12:03:09 --> Model Class Initialized
INFO - 2020-09-07 12:03:09 --> Model Class Initialized
INFO - 2020-09-07 12:03:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_import.php
INFO - 2020-09-07 12:03:09 --> Final output sent to browser
DEBUG - 2020-09-07 12:03:09 --> Total execution time: 0.0430
ERROR - 2020-09-07 12:03:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 12:03:48 --> Config Class Initialized
INFO - 2020-09-07 12:03:48 --> Hooks Class Initialized
DEBUG - 2020-09-07 12:03:48 --> UTF-8 Support Enabled
INFO - 2020-09-07 12:03:48 --> Utf8 Class Initialized
INFO - 2020-09-07 12:03:48 --> URI Class Initialized
INFO - 2020-09-07 12:03:48 --> Router Class Initialized
INFO - 2020-09-07 12:03:48 --> Output Class Initialized
INFO - 2020-09-07 12:03:48 --> Security Class Initialized
DEBUG - 2020-09-07 12:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 12:03:48 --> Input Class Initialized
INFO - 2020-09-07 12:03:48 --> Language Class Initialized
INFO - 2020-09-07 12:03:48 --> Loader Class Initialized
INFO - 2020-09-07 12:03:48 --> Helper loaded: url_helper
INFO - 2020-09-07 12:03:48 --> Database Driver Class Initialized
INFO - 2020-09-07 12:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 12:03:48 --> Email Class Initialized
INFO - 2020-09-07 12:03:48 --> Controller Class Initialized
INFO - 2020-09-07 12:03:48 --> Model Class Initialized
INFO - 2020-09-07 12:03:48 --> Model Class Initialized
INFO - 2020-09-07 12:03:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_import.php
INFO - 2020-09-07 12:03:48 --> Final output sent to browser
DEBUG - 2020-09-07 12:03:48 --> Total execution time: 0.0436
ERROR - 2020-09-07 12:05:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 12:05:30 --> Config Class Initialized
INFO - 2020-09-07 12:05:30 --> Hooks Class Initialized
DEBUG - 2020-09-07 12:05:30 --> UTF-8 Support Enabled
INFO - 2020-09-07 12:05:30 --> Utf8 Class Initialized
INFO - 2020-09-07 12:05:30 --> URI Class Initialized
INFO - 2020-09-07 12:05:30 --> Router Class Initialized
INFO - 2020-09-07 12:05:30 --> Output Class Initialized
INFO - 2020-09-07 12:05:30 --> Security Class Initialized
DEBUG - 2020-09-07 12:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 12:05:30 --> Input Class Initialized
INFO - 2020-09-07 12:05:30 --> Language Class Initialized
INFO - 2020-09-07 12:05:30 --> Loader Class Initialized
INFO - 2020-09-07 12:05:30 --> Helper loaded: url_helper
INFO - 2020-09-07 12:05:30 --> Database Driver Class Initialized
INFO - 2020-09-07 12:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 12:05:30 --> Email Class Initialized
INFO - 2020-09-07 12:05:30 --> Controller Class Initialized
INFO - 2020-09-07 12:05:30 --> Model Class Initialized
INFO - 2020-09-07 12:05:30 --> Model Class Initialized
INFO - 2020-09-07 12:05:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_import.php
INFO - 2020-09-07 12:05:30 --> Final output sent to browser
DEBUG - 2020-09-07 12:05:30 --> Total execution time: 0.0428
ERROR - 2020-09-07 12:05:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 12:05:38 --> Config Class Initialized
INFO - 2020-09-07 12:05:38 --> Hooks Class Initialized
DEBUG - 2020-09-07 12:05:38 --> UTF-8 Support Enabled
INFO - 2020-09-07 12:05:38 --> Utf8 Class Initialized
INFO - 2020-09-07 12:05:38 --> URI Class Initialized
INFO - 2020-09-07 12:05:38 --> Router Class Initialized
INFO - 2020-09-07 12:05:38 --> Output Class Initialized
INFO - 2020-09-07 12:05:38 --> Security Class Initialized
DEBUG - 2020-09-07 12:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 12:05:38 --> Input Class Initialized
INFO - 2020-09-07 12:05:38 --> Language Class Initialized
INFO - 2020-09-07 12:05:38 --> Loader Class Initialized
INFO - 2020-09-07 12:05:38 --> Helper loaded: url_helper
INFO - 2020-09-07 12:05:38 --> Database Driver Class Initialized
INFO - 2020-09-07 12:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 12:05:38 --> Email Class Initialized
INFO - 2020-09-07 12:05:38 --> Controller Class Initialized
INFO - 2020-09-07 12:05:38 --> Model Class Initialized
INFO - 2020-09-07 12:05:38 --> Model Class Initialized
INFO - 2020-09-07 12:05:39 --> Final output sent to browser
DEBUG - 2020-09-07 12:05:39 --> Total execution time: 0.0614
ERROR - 2020-09-07 12:05:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 12:05:39 --> Config Class Initialized
INFO - 2020-09-07 12:05:39 --> Hooks Class Initialized
DEBUG - 2020-09-07 12:05:39 --> UTF-8 Support Enabled
INFO - 2020-09-07 12:05:39 --> Utf8 Class Initialized
INFO - 2020-09-07 12:05:39 --> URI Class Initialized
INFO - 2020-09-07 12:05:39 --> Router Class Initialized
INFO - 2020-09-07 12:05:39 --> Output Class Initialized
INFO - 2020-09-07 12:05:39 --> Security Class Initialized
DEBUG - 2020-09-07 12:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 12:05:39 --> Input Class Initialized
INFO - 2020-09-07 12:05:39 --> Language Class Initialized
INFO - 2020-09-07 12:05:39 --> Loader Class Initialized
INFO - 2020-09-07 12:05:39 --> Helper loaded: url_helper
INFO - 2020-09-07 12:05:39 --> Database Driver Class Initialized
INFO - 2020-09-07 12:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 12:05:39 --> Email Class Initialized
INFO - 2020-09-07 12:05:39 --> Controller Class Initialized
INFO - 2020-09-07 12:05:39 --> Model Class Initialized
INFO - 2020-09-07 12:05:39 --> Model Class Initialized
INFO - 2020-09-07 12:05:39 --> Final output sent to browser
DEBUG - 2020-09-07 12:05:39 --> Total execution time: 0.0562
ERROR - 2020-09-07 12:05:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 12:05:39 --> Config Class Initialized
INFO - 2020-09-07 12:05:39 --> Hooks Class Initialized
DEBUG - 2020-09-07 12:05:39 --> UTF-8 Support Enabled
INFO - 2020-09-07 12:05:39 --> Utf8 Class Initialized
INFO - 2020-09-07 12:05:39 --> URI Class Initialized
INFO - 2020-09-07 12:05:39 --> Router Class Initialized
INFO - 2020-09-07 12:05:39 --> Output Class Initialized
INFO - 2020-09-07 12:05:39 --> Security Class Initialized
DEBUG - 2020-09-07 12:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 12:05:39 --> Input Class Initialized
INFO - 2020-09-07 12:05:39 --> Language Class Initialized
INFO - 2020-09-07 12:05:39 --> Loader Class Initialized
INFO - 2020-09-07 12:05:39 --> Helper loaded: url_helper
INFO - 2020-09-07 12:05:39 --> Database Driver Class Initialized
INFO - 2020-09-07 12:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 12:05:39 --> Email Class Initialized
INFO - 2020-09-07 12:05:39 --> Controller Class Initialized
INFO - 2020-09-07 12:05:39 --> Model Class Initialized
INFO - 2020-09-07 12:05:39 --> Model Class Initialized
INFO - 2020-09-07 12:05:39 --> Final output sent to browser
DEBUG - 2020-09-07 12:05:39 --> Total execution time: 0.0837
ERROR - 2020-09-07 12:05:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 12:05:40 --> Config Class Initialized
INFO - 2020-09-07 12:05:40 --> Hooks Class Initialized
DEBUG - 2020-09-07 12:05:40 --> UTF-8 Support Enabled
INFO - 2020-09-07 12:05:40 --> Utf8 Class Initialized
INFO - 2020-09-07 12:05:40 --> URI Class Initialized
INFO - 2020-09-07 12:05:40 --> Router Class Initialized
INFO - 2020-09-07 12:05:40 --> Output Class Initialized
INFO - 2020-09-07 12:05:40 --> Security Class Initialized
DEBUG - 2020-09-07 12:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 12:05:40 --> Input Class Initialized
INFO - 2020-09-07 12:05:40 --> Language Class Initialized
INFO - 2020-09-07 12:05:40 --> Loader Class Initialized
INFO - 2020-09-07 12:05:40 --> Helper loaded: url_helper
INFO - 2020-09-07 12:05:40 --> Database Driver Class Initialized
INFO - 2020-09-07 12:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 12:05:40 --> Email Class Initialized
INFO - 2020-09-07 12:05:40 --> Controller Class Initialized
INFO - 2020-09-07 12:05:40 --> Model Class Initialized
INFO - 2020-09-07 12:05:40 --> Model Class Initialized
INFO - 2020-09-07 12:05:40 --> Final output sent to browser
DEBUG - 2020-09-07 12:05:40 --> Total execution time: 0.0609
ERROR - 2020-09-07 12:05:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 12:05:40 --> Config Class Initialized
INFO - 2020-09-07 12:05:40 --> Hooks Class Initialized
DEBUG - 2020-09-07 12:05:40 --> UTF-8 Support Enabled
INFO - 2020-09-07 12:05:40 --> Utf8 Class Initialized
INFO - 2020-09-07 12:05:40 --> URI Class Initialized
INFO - 2020-09-07 12:05:40 --> Router Class Initialized
INFO - 2020-09-07 12:05:40 --> Output Class Initialized
INFO - 2020-09-07 12:05:40 --> Security Class Initialized
DEBUG - 2020-09-07 12:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 12:05:40 --> Input Class Initialized
INFO - 2020-09-07 12:05:40 --> Language Class Initialized
INFO - 2020-09-07 12:05:40 --> Loader Class Initialized
INFO - 2020-09-07 12:05:40 --> Helper loaded: url_helper
INFO - 2020-09-07 12:05:40 --> Database Driver Class Initialized
INFO - 2020-09-07 12:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 12:05:40 --> Email Class Initialized
INFO - 2020-09-07 12:05:40 --> Controller Class Initialized
INFO - 2020-09-07 12:05:40 --> Model Class Initialized
INFO - 2020-09-07 12:05:40 --> Model Class Initialized
INFO - 2020-09-07 12:05:40 --> Final output sent to browser
DEBUG - 2020-09-07 12:05:40 --> Total execution time: 0.0572
ERROR - 2020-09-07 12:05:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 12:05:40 --> Config Class Initialized
INFO - 2020-09-07 12:05:40 --> Hooks Class Initialized
DEBUG - 2020-09-07 12:05:40 --> UTF-8 Support Enabled
INFO - 2020-09-07 12:05:40 --> Utf8 Class Initialized
INFO - 2020-09-07 12:05:40 --> URI Class Initialized
INFO - 2020-09-07 12:05:40 --> Router Class Initialized
INFO - 2020-09-07 12:05:40 --> Output Class Initialized
INFO - 2020-09-07 12:05:40 --> Security Class Initialized
DEBUG - 2020-09-07 12:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 12:05:40 --> Input Class Initialized
INFO - 2020-09-07 12:05:40 --> Language Class Initialized
INFO - 2020-09-07 12:05:40 --> Loader Class Initialized
INFO - 2020-09-07 12:05:40 --> Helper loaded: url_helper
INFO - 2020-09-07 12:05:40 --> Database Driver Class Initialized
INFO - 2020-09-07 12:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 12:05:40 --> Email Class Initialized
INFO - 2020-09-07 12:05:40 --> Controller Class Initialized
INFO - 2020-09-07 12:05:40 --> Model Class Initialized
INFO - 2020-09-07 12:05:40 --> Model Class Initialized
INFO - 2020-09-07 12:05:40 --> Final output sent to browser
DEBUG - 2020-09-07 12:05:40 --> Total execution time: 0.0625
ERROR - 2020-09-07 12:08:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 12:08:01 --> Config Class Initialized
INFO - 2020-09-07 12:08:01 --> Hooks Class Initialized
DEBUG - 2020-09-07 12:08:01 --> UTF-8 Support Enabled
INFO - 2020-09-07 12:08:01 --> Utf8 Class Initialized
INFO - 2020-09-07 12:08:01 --> URI Class Initialized
INFO - 2020-09-07 12:08:01 --> Router Class Initialized
INFO - 2020-09-07 12:08:01 --> Output Class Initialized
INFO - 2020-09-07 12:08:01 --> Security Class Initialized
DEBUG - 2020-09-07 12:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 12:08:01 --> Input Class Initialized
INFO - 2020-09-07 12:08:01 --> Language Class Initialized
INFO - 2020-09-07 12:08:01 --> Loader Class Initialized
INFO - 2020-09-07 12:08:01 --> Helper loaded: url_helper
INFO - 2020-09-07 12:08:01 --> Database Driver Class Initialized
INFO - 2020-09-07 12:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 12:08:01 --> Email Class Initialized
INFO - 2020-09-07 12:08:01 --> Controller Class Initialized
INFO - 2020-09-07 12:08:01 --> Model Class Initialized
INFO - 2020-09-07 12:08:01 --> Model Class Initialized
INFO - 2020-09-07 12:08:01 --> Final output sent to browser
DEBUG - 2020-09-07 12:08:01 --> Total execution time: 0.0737
ERROR - 2020-09-07 12:08:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 12:08:03 --> Config Class Initialized
INFO - 2020-09-07 12:08:03 --> Hooks Class Initialized
DEBUG - 2020-09-07 12:08:03 --> UTF-8 Support Enabled
INFO - 2020-09-07 12:08:03 --> Utf8 Class Initialized
INFO - 2020-09-07 12:08:03 --> URI Class Initialized
INFO - 2020-09-07 12:08:03 --> Router Class Initialized
INFO - 2020-09-07 12:08:03 --> Output Class Initialized
INFO - 2020-09-07 12:08:03 --> Security Class Initialized
DEBUG - 2020-09-07 12:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 12:08:03 --> Input Class Initialized
INFO - 2020-09-07 12:08:03 --> Language Class Initialized
INFO - 2020-09-07 12:08:03 --> Loader Class Initialized
INFO - 2020-09-07 12:08:03 --> Helper loaded: url_helper
INFO - 2020-09-07 12:08:03 --> Database Driver Class Initialized
INFO - 2020-09-07 12:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 12:08:03 --> Email Class Initialized
INFO - 2020-09-07 12:08:03 --> Controller Class Initialized
INFO - 2020-09-07 12:08:03 --> Model Class Initialized
INFO - 2020-09-07 12:08:03 --> Model Class Initialized
INFO - 2020-09-07 12:08:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_import.php
INFO - 2020-09-07 12:08:03 --> Final output sent to browser
DEBUG - 2020-09-07 12:08:03 --> Total execution time: 0.0469
ERROR - 2020-09-07 12:08:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 12:08:05 --> Config Class Initialized
INFO - 2020-09-07 12:08:05 --> Hooks Class Initialized
DEBUG - 2020-09-07 12:08:05 --> UTF-8 Support Enabled
INFO - 2020-09-07 12:08:05 --> Utf8 Class Initialized
INFO - 2020-09-07 12:08:05 --> URI Class Initialized
INFO - 2020-09-07 12:08:05 --> Router Class Initialized
INFO - 2020-09-07 12:08:05 --> Output Class Initialized
INFO - 2020-09-07 12:08:05 --> Security Class Initialized
DEBUG - 2020-09-07 12:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 12:08:05 --> Input Class Initialized
INFO - 2020-09-07 12:08:05 --> Language Class Initialized
INFO - 2020-09-07 12:08:05 --> Loader Class Initialized
INFO - 2020-09-07 12:08:05 --> Helper loaded: url_helper
INFO - 2020-09-07 12:08:05 --> Database Driver Class Initialized
INFO - 2020-09-07 12:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 12:08:05 --> Email Class Initialized
INFO - 2020-09-07 12:08:05 --> Controller Class Initialized
INFO - 2020-09-07 12:08:05 --> Model Class Initialized
INFO - 2020-09-07 12:08:05 --> Model Class Initialized
INFO - 2020-09-07 12:08:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_import.php
INFO - 2020-09-07 12:08:05 --> Final output sent to browser
DEBUG - 2020-09-07 12:08:05 --> Total execution time: 0.0436
ERROR - 2020-09-07 12:08:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 12:08:14 --> Config Class Initialized
INFO - 2020-09-07 12:08:14 --> Hooks Class Initialized
DEBUG - 2020-09-07 12:08:14 --> UTF-8 Support Enabled
INFO - 2020-09-07 12:08:14 --> Utf8 Class Initialized
INFO - 2020-09-07 12:08:14 --> URI Class Initialized
INFO - 2020-09-07 12:08:14 --> Router Class Initialized
INFO - 2020-09-07 12:08:14 --> Output Class Initialized
INFO - 2020-09-07 12:08:14 --> Security Class Initialized
DEBUG - 2020-09-07 12:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 12:08:14 --> Input Class Initialized
INFO - 2020-09-07 12:08:14 --> Language Class Initialized
INFO - 2020-09-07 12:08:14 --> Loader Class Initialized
INFO - 2020-09-07 12:08:14 --> Helper loaded: url_helper
INFO - 2020-09-07 12:08:14 --> Database Driver Class Initialized
INFO - 2020-09-07 12:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 12:08:14 --> Email Class Initialized
INFO - 2020-09-07 12:08:14 --> Controller Class Initialized
INFO - 2020-09-07 12:08:14 --> Model Class Initialized
INFO - 2020-09-07 12:08:14 --> Model Class Initialized
INFO - 2020-09-07 12:08:14 --> Final output sent to browser
DEBUG - 2020-09-07 12:08:14 --> Total execution time: 0.0703
ERROR - 2020-09-07 12:08:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 12:08:57 --> Config Class Initialized
INFO - 2020-09-07 12:08:57 --> Hooks Class Initialized
DEBUG - 2020-09-07 12:08:57 --> UTF-8 Support Enabled
INFO - 2020-09-07 12:08:57 --> Utf8 Class Initialized
INFO - 2020-09-07 12:08:57 --> URI Class Initialized
INFO - 2020-09-07 12:08:57 --> Router Class Initialized
INFO - 2020-09-07 12:08:57 --> Output Class Initialized
INFO - 2020-09-07 12:08:57 --> Security Class Initialized
DEBUG - 2020-09-07 12:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 12:08:57 --> Input Class Initialized
INFO - 2020-09-07 12:08:57 --> Language Class Initialized
INFO - 2020-09-07 12:08:57 --> Loader Class Initialized
INFO - 2020-09-07 12:08:57 --> Helper loaded: url_helper
INFO - 2020-09-07 12:08:57 --> Database Driver Class Initialized
INFO - 2020-09-07 12:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 12:08:57 --> Email Class Initialized
INFO - 2020-09-07 12:08:57 --> Controller Class Initialized
INFO - 2020-09-07 12:08:57 --> Model Class Initialized
INFO - 2020-09-07 12:08:57 --> Model Class Initialized
INFO - 2020-09-07 12:08:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_import.php
INFO - 2020-09-07 12:08:57 --> Final output sent to browser
DEBUG - 2020-09-07 12:08:57 --> Total execution time: 0.0391
ERROR - 2020-09-07 12:09:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 12:09:05 --> Config Class Initialized
INFO - 2020-09-07 12:09:05 --> Hooks Class Initialized
DEBUG - 2020-09-07 12:09:05 --> UTF-8 Support Enabled
INFO - 2020-09-07 12:09:05 --> Utf8 Class Initialized
INFO - 2020-09-07 12:09:05 --> URI Class Initialized
INFO - 2020-09-07 12:09:05 --> Router Class Initialized
INFO - 2020-09-07 12:09:05 --> Output Class Initialized
INFO - 2020-09-07 12:09:05 --> Security Class Initialized
DEBUG - 2020-09-07 12:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 12:09:05 --> Input Class Initialized
INFO - 2020-09-07 12:09:05 --> Language Class Initialized
INFO - 2020-09-07 12:09:05 --> Loader Class Initialized
INFO - 2020-09-07 12:09:05 --> Helper loaded: url_helper
INFO - 2020-09-07 12:09:05 --> Database Driver Class Initialized
INFO - 2020-09-07 12:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 12:09:05 --> Email Class Initialized
INFO - 2020-09-07 12:09:05 --> Controller Class Initialized
INFO - 2020-09-07 12:09:05 --> Model Class Initialized
INFO - 2020-09-07 12:09:05 --> Model Class Initialized
INFO - 2020-09-07 12:09:05 --> Final output sent to browser
DEBUG - 2020-09-07 12:09:05 --> Total execution time: 0.0499
ERROR - 2020-09-07 12:19:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 12:19:53 --> Config Class Initialized
INFO - 2020-09-07 12:19:53 --> Hooks Class Initialized
DEBUG - 2020-09-07 12:19:53 --> UTF-8 Support Enabled
INFO - 2020-09-07 12:19:53 --> Utf8 Class Initialized
INFO - 2020-09-07 12:19:53 --> URI Class Initialized
INFO - 2020-09-07 12:19:53 --> Router Class Initialized
INFO - 2020-09-07 12:19:53 --> Output Class Initialized
INFO - 2020-09-07 12:19:53 --> Security Class Initialized
DEBUG - 2020-09-07 12:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 12:19:53 --> Input Class Initialized
INFO - 2020-09-07 12:19:53 --> Language Class Initialized
INFO - 2020-09-07 12:19:53 --> Loader Class Initialized
INFO - 2020-09-07 12:19:53 --> Helper loaded: url_helper
INFO - 2020-09-07 12:19:53 --> Database Driver Class Initialized
INFO - 2020-09-07 12:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 12:19:53 --> Email Class Initialized
INFO - 2020-09-07 12:19:53 --> Controller Class Initialized
INFO - 2020-09-07 12:19:53 --> Model Class Initialized
INFO - 2020-09-07 12:19:53 --> Model Class Initialized
INFO - 2020-09-07 12:19:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-07 12:19:53 --> Final output sent to browser
DEBUG - 2020-09-07 12:19:53 --> Total execution time: 0.0382
ERROR - 2020-09-07 12:20:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 12:20:10 --> Config Class Initialized
INFO - 2020-09-07 12:20:10 --> Hooks Class Initialized
DEBUG - 2020-09-07 12:20:10 --> UTF-8 Support Enabled
INFO - 2020-09-07 12:20:10 --> Utf8 Class Initialized
INFO - 2020-09-07 12:20:10 --> URI Class Initialized
INFO - 2020-09-07 12:20:10 --> Router Class Initialized
INFO - 2020-09-07 12:20:10 --> Output Class Initialized
INFO - 2020-09-07 12:20:10 --> Security Class Initialized
DEBUG - 2020-09-07 12:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 12:20:10 --> Input Class Initialized
INFO - 2020-09-07 12:20:10 --> Language Class Initialized
INFO - 2020-09-07 12:20:10 --> Loader Class Initialized
INFO - 2020-09-07 12:20:10 --> Helper loaded: url_helper
INFO - 2020-09-07 12:20:10 --> Database Driver Class Initialized
INFO - 2020-09-07 12:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 12:20:10 --> Email Class Initialized
INFO - 2020-09-07 12:20:10 --> Controller Class Initialized
INFO - 2020-09-07 12:20:10 --> Model Class Initialized
INFO - 2020-09-07 12:20:10 --> Model Class Initialized
INFO - 2020-09-07 12:20:10 --> Final output sent to browser
DEBUG - 2020-09-07 12:20:10 --> Total execution time: 0.0583
ERROR - 2020-09-07 14:15:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 14:15:02 --> Config Class Initialized
INFO - 2020-09-07 14:15:02 --> Hooks Class Initialized
DEBUG - 2020-09-07 14:15:02 --> UTF-8 Support Enabled
INFO - 2020-09-07 14:15:02 --> Utf8 Class Initialized
INFO - 2020-09-07 14:15:02 --> URI Class Initialized
INFO - 2020-09-07 14:15:02 --> Router Class Initialized
INFO - 2020-09-07 14:15:02 --> Output Class Initialized
INFO - 2020-09-07 14:15:02 --> Security Class Initialized
DEBUG - 2020-09-07 14:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 14:15:02 --> Input Class Initialized
INFO - 2020-09-07 14:15:02 --> Language Class Initialized
INFO - 2020-09-07 14:15:02 --> Loader Class Initialized
INFO - 2020-09-07 14:15:02 --> Helper loaded: url_helper
INFO - 2020-09-07 14:15:02 --> Database Driver Class Initialized
INFO - 2020-09-07 14:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 14:15:02 --> Email Class Initialized
INFO - 2020-09-07 14:15:02 --> Controller Class Initialized
INFO - 2020-09-07 14:15:02 --> Model Class Initialized
INFO - 2020-09-07 14:15:02 --> Model Class Initialized
INFO - 2020-09-07 14:15:02 --> Final output sent to browser
DEBUG - 2020-09-07 14:15:02 --> Total execution time: 0.0619
ERROR - 2020-09-07 15:05:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:05:07 --> Config Class Initialized
INFO - 2020-09-07 15:05:07 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:05:07 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:05:07 --> Utf8 Class Initialized
INFO - 2020-09-07 15:05:07 --> URI Class Initialized
INFO - 2020-09-07 15:05:07 --> Router Class Initialized
INFO - 2020-09-07 15:05:07 --> Output Class Initialized
INFO - 2020-09-07 15:05:07 --> Security Class Initialized
DEBUG - 2020-09-07 15:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:05:07 --> Input Class Initialized
INFO - 2020-09-07 15:05:07 --> Language Class Initialized
INFO - 2020-09-07 15:05:07 --> Loader Class Initialized
INFO - 2020-09-07 15:05:07 --> Helper loaded: url_helper
INFO - 2020-09-07 15:05:07 --> Database Driver Class Initialized
INFO - 2020-09-07 15:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:05:07 --> Email Class Initialized
INFO - 2020-09-07 15:05:07 --> Controller Class Initialized
INFO - 2020-09-07 15:05:07 --> Model Class Initialized
INFO - 2020-09-07 15:05:07 --> Model Class Initialized
INFO - 2020-09-07 15:05:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-07 15:05:07 --> Final output sent to browser
DEBUG - 2020-09-07 15:05:07 --> Total execution time: 0.0420
ERROR - 2020-09-07 15:05:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:05:08 --> Config Class Initialized
INFO - 2020-09-07 15:05:08 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:05:08 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:05:08 --> Utf8 Class Initialized
INFO - 2020-09-07 15:05:08 --> URI Class Initialized
INFO - 2020-09-07 15:05:08 --> Router Class Initialized
INFO - 2020-09-07 15:05:08 --> Output Class Initialized
INFO - 2020-09-07 15:05:08 --> Security Class Initialized
DEBUG - 2020-09-07 15:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:05:08 --> Input Class Initialized
INFO - 2020-09-07 15:05:08 --> Language Class Initialized
INFO - 2020-09-07 15:05:08 --> Loader Class Initialized
INFO - 2020-09-07 15:05:08 --> Helper loaded: url_helper
INFO - 2020-09-07 15:05:08 --> Database Driver Class Initialized
INFO - 2020-09-07 15:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:05:08 --> Email Class Initialized
INFO - 2020-09-07 15:05:08 --> Controller Class Initialized
INFO - 2020-09-07 15:05:08 --> Model Class Initialized
INFO - 2020-09-07 15:05:08 --> Model Class Initialized
ERROR - 2020-09-07 15:05:08 --> Query error: Unknown column 'CustomerID' in 'order clause' - Invalid query: SELECT *
FROM `tbl_customer`
ORDER BY `CustomerID` DESC
INFO - 2020-09-07 15:05:08 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-07 15:05:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:05:16 --> Config Class Initialized
INFO - 2020-09-07 15:05:16 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:05:16 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:05:16 --> Utf8 Class Initialized
INFO - 2020-09-07 15:05:16 --> URI Class Initialized
INFO - 2020-09-07 15:05:16 --> Router Class Initialized
INFO - 2020-09-07 15:05:16 --> Output Class Initialized
INFO - 2020-09-07 15:05:16 --> Security Class Initialized
DEBUG - 2020-09-07 15:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:05:16 --> Input Class Initialized
INFO - 2020-09-07 15:05:16 --> Language Class Initialized
INFO - 2020-09-07 15:05:16 --> Loader Class Initialized
INFO - 2020-09-07 15:05:16 --> Helper loaded: url_helper
INFO - 2020-09-07 15:05:16 --> Database Driver Class Initialized
INFO - 2020-09-07 15:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:05:16 --> Email Class Initialized
INFO - 2020-09-07 15:05:16 --> Controller Class Initialized
INFO - 2020-09-07 15:05:16 --> Model Class Initialized
INFO - 2020-09-07 15:05:16 --> Model Class Initialized
INFO - 2020-09-07 15:05:16 --> Final output sent to browser
DEBUG - 2020-09-07 15:05:16 --> Total execution time: 0.1548
ERROR - 2020-09-07 15:05:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:05:16 --> Config Class Initialized
INFO - 2020-09-07 15:05:16 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:05:16 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:05:16 --> Utf8 Class Initialized
INFO - 2020-09-07 15:05:16 --> URI Class Initialized
INFO - 2020-09-07 15:05:16 --> Router Class Initialized
INFO - 2020-09-07 15:05:16 --> Output Class Initialized
INFO - 2020-09-07 15:05:16 --> Security Class Initialized
DEBUG - 2020-09-07 15:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:05:16 --> Input Class Initialized
INFO - 2020-09-07 15:05:16 --> Language Class Initialized
INFO - 2020-09-07 15:05:16 --> Loader Class Initialized
INFO - 2020-09-07 15:05:16 --> Helper loaded: url_helper
INFO - 2020-09-07 15:05:16 --> Database Driver Class Initialized
INFO - 2020-09-07 15:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:05:17 --> Email Class Initialized
INFO - 2020-09-07 15:05:17 --> Controller Class Initialized
INFO - 2020-09-07 15:05:17 --> Model Class Initialized
INFO - 2020-09-07 15:05:17 --> Model Class Initialized
ERROR - 2020-09-07 15:05:17 --> Query error: Unknown column 'CustomerID' in 'order clause' - Invalid query: SELECT *
FROM `tbl_customer`
ORDER BY `CustomerID` DESC
INFO - 2020-09-07 15:05:17 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-07 15:06:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:06:08 --> Config Class Initialized
INFO - 2020-09-07 15:06:08 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:06:08 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:06:08 --> Utf8 Class Initialized
INFO - 2020-09-07 15:06:08 --> URI Class Initialized
INFO - 2020-09-07 15:06:08 --> Router Class Initialized
INFO - 2020-09-07 15:06:08 --> Output Class Initialized
INFO - 2020-09-07 15:06:08 --> Security Class Initialized
DEBUG - 2020-09-07 15:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:06:08 --> Input Class Initialized
INFO - 2020-09-07 15:06:08 --> Language Class Initialized
INFO - 2020-09-07 15:06:08 --> Loader Class Initialized
INFO - 2020-09-07 15:06:08 --> Helper loaded: url_helper
INFO - 2020-09-07 15:06:08 --> Database Driver Class Initialized
INFO - 2020-09-07 15:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:06:08 --> Email Class Initialized
INFO - 2020-09-07 15:06:08 --> Controller Class Initialized
INFO - 2020-09-07 15:06:08 --> Model Class Initialized
INFO - 2020-09-07 15:06:08 --> Model Class Initialized
INFO - 2020-09-07 15:06:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-07 15:06:08 --> Final output sent to browser
DEBUG - 2020-09-07 15:06:08 --> Total execution time: 0.0517
ERROR - 2020-09-07 15:06:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:06:09 --> Config Class Initialized
INFO - 2020-09-07 15:06:09 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:06:09 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:06:09 --> Utf8 Class Initialized
INFO - 2020-09-07 15:06:09 --> URI Class Initialized
INFO - 2020-09-07 15:06:09 --> Router Class Initialized
INFO - 2020-09-07 15:06:09 --> Output Class Initialized
INFO - 2020-09-07 15:06:09 --> Security Class Initialized
DEBUG - 2020-09-07 15:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:06:09 --> Input Class Initialized
INFO - 2020-09-07 15:06:09 --> Language Class Initialized
INFO - 2020-09-07 15:06:09 --> Loader Class Initialized
INFO - 2020-09-07 15:06:09 --> Helper loaded: url_helper
INFO - 2020-09-07 15:06:09 --> Database Driver Class Initialized
INFO - 2020-09-07 15:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:06:09 --> Email Class Initialized
INFO - 2020-09-07 15:06:09 --> Controller Class Initialized
INFO - 2020-09-07 15:06:09 --> Model Class Initialized
INFO - 2020-09-07 15:06:09 --> Model Class Initialized
ERROR - 2020-09-07 15:06:09 --> Query error: Unknown column 'CustomerID' in 'order clause' - Invalid query: SELECT *
FROM `tbl_customer`
ORDER BY `CustomerID` DESC
INFO - 2020-09-07 15:06:09 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-07 15:07:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:07:54 --> Config Class Initialized
INFO - 2020-09-07 15:07:54 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:07:54 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:07:54 --> Utf8 Class Initialized
INFO - 2020-09-07 15:07:54 --> URI Class Initialized
INFO - 2020-09-07 15:07:54 --> Router Class Initialized
INFO - 2020-09-07 15:07:54 --> Output Class Initialized
INFO - 2020-09-07 15:07:54 --> Security Class Initialized
DEBUG - 2020-09-07 15:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:07:54 --> Input Class Initialized
INFO - 2020-09-07 15:07:54 --> Language Class Initialized
ERROR - 2020-09-07 15:07:54 --> 404 Page Not Found: Excel_import/excel_impt
ERROR - 2020-09-07 15:08:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:08:03 --> Config Class Initialized
INFO - 2020-09-07 15:08:03 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:08:03 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:08:03 --> Utf8 Class Initialized
INFO - 2020-09-07 15:08:03 --> URI Class Initialized
INFO - 2020-09-07 15:08:03 --> Router Class Initialized
INFO - 2020-09-07 15:08:03 --> Output Class Initialized
INFO - 2020-09-07 15:08:03 --> Security Class Initialized
DEBUG - 2020-09-07 15:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:08:03 --> Input Class Initialized
INFO - 2020-09-07 15:08:03 --> Language Class Initialized
INFO - 2020-09-07 15:08:03 --> Loader Class Initialized
INFO - 2020-09-07 15:08:03 --> Helper loaded: url_helper
INFO - 2020-09-07 15:08:03 --> Database Driver Class Initialized
INFO - 2020-09-07 15:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:08:03 --> Email Class Initialized
INFO - 2020-09-07 15:08:03 --> Controller Class Initialized
INFO - 2020-09-07 15:08:03 --> Model Class Initialized
INFO - 2020-09-07 15:08:03 --> Model Class Initialized
INFO - 2020-09-07 15:08:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-07 15:08:03 --> Final output sent to browser
DEBUG - 2020-09-07 15:08:03 --> Total execution time: 0.0418
ERROR - 2020-09-07 15:08:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:08:04 --> Config Class Initialized
INFO - 2020-09-07 15:08:04 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:08:04 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:08:04 --> Utf8 Class Initialized
INFO - 2020-09-07 15:08:04 --> URI Class Initialized
INFO - 2020-09-07 15:08:04 --> Router Class Initialized
INFO - 2020-09-07 15:08:04 --> Output Class Initialized
INFO - 2020-09-07 15:08:04 --> Security Class Initialized
DEBUG - 2020-09-07 15:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:08:04 --> Input Class Initialized
INFO - 2020-09-07 15:08:04 --> Language Class Initialized
INFO - 2020-09-07 15:08:04 --> Loader Class Initialized
INFO - 2020-09-07 15:08:04 --> Helper loaded: url_helper
INFO - 2020-09-07 15:08:04 --> Database Driver Class Initialized
INFO - 2020-09-07 15:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:08:04 --> Email Class Initialized
INFO - 2020-09-07 15:08:04 --> Controller Class Initialized
INFO - 2020-09-07 15:08:04 --> Model Class Initialized
INFO - 2020-09-07 15:08:04 --> Model Class Initialized
ERROR - 2020-09-07 15:08:04 --> Query error: Unknown column 'CustomerID' in 'order clause' - Invalid query: SELECT *
FROM `tbl_customer`
ORDER BY `CustomerID` DESC
INFO - 2020-09-07 15:08:04 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-07 15:08:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:08:16 --> Config Class Initialized
INFO - 2020-09-07 15:08:16 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:08:16 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:08:16 --> Utf8 Class Initialized
INFO - 2020-09-07 15:08:16 --> URI Class Initialized
INFO - 2020-09-07 15:08:16 --> Router Class Initialized
INFO - 2020-09-07 15:08:16 --> Output Class Initialized
INFO - 2020-09-07 15:08:16 --> Security Class Initialized
DEBUG - 2020-09-07 15:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:08:16 --> Input Class Initialized
INFO - 2020-09-07 15:08:16 --> Language Class Initialized
INFO - 2020-09-07 15:08:16 --> Loader Class Initialized
INFO - 2020-09-07 15:08:16 --> Helper loaded: url_helper
INFO - 2020-09-07 15:08:16 --> Database Driver Class Initialized
INFO - 2020-09-07 15:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:08:16 --> Email Class Initialized
INFO - 2020-09-07 15:08:16 --> Controller Class Initialized
INFO - 2020-09-07 15:08:16 --> Model Class Initialized
INFO - 2020-09-07 15:08:16 --> Model Class Initialized
INFO - 2020-09-07 15:08:16 --> Final output sent to browser
DEBUG - 2020-09-07 15:08:16 --> Total execution time: 0.2398
ERROR - 2020-09-07 15:08:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:08:16 --> Config Class Initialized
INFO - 2020-09-07 15:08:16 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:08:16 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:08:16 --> Utf8 Class Initialized
INFO - 2020-09-07 15:08:16 --> URI Class Initialized
INFO - 2020-09-07 15:08:16 --> Router Class Initialized
INFO - 2020-09-07 15:08:16 --> Output Class Initialized
INFO - 2020-09-07 15:08:16 --> Security Class Initialized
DEBUG - 2020-09-07 15:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:08:16 --> Input Class Initialized
INFO - 2020-09-07 15:08:16 --> Language Class Initialized
INFO - 2020-09-07 15:08:16 --> Loader Class Initialized
INFO - 2020-09-07 15:08:16 --> Helper loaded: url_helper
INFO - 2020-09-07 15:08:16 --> Database Driver Class Initialized
INFO - 2020-09-07 15:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:08:16 --> Email Class Initialized
INFO - 2020-09-07 15:08:16 --> Controller Class Initialized
INFO - 2020-09-07 15:08:16 --> Model Class Initialized
INFO - 2020-09-07 15:08:16 --> Model Class Initialized
ERROR - 2020-09-07 15:08:16 --> Query error: Unknown column 'CustomerID' in 'order clause' - Invalid query: SELECT *
FROM `tbl_customer`
ORDER BY `CustomerID` DESC
INFO - 2020-09-07 15:08:16 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-07 15:11:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:11:06 --> Config Class Initialized
INFO - 2020-09-07 15:11:06 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:11:06 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:11:06 --> Utf8 Class Initialized
INFO - 2020-09-07 15:11:06 --> URI Class Initialized
INFO - 2020-09-07 15:11:06 --> Router Class Initialized
INFO - 2020-09-07 15:11:06 --> Output Class Initialized
INFO - 2020-09-07 15:11:06 --> Security Class Initialized
DEBUG - 2020-09-07 15:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:11:06 --> Input Class Initialized
INFO - 2020-09-07 15:11:06 --> Language Class Initialized
INFO - 2020-09-07 15:11:06 --> Loader Class Initialized
INFO - 2020-09-07 15:11:06 --> Helper loaded: url_helper
INFO - 2020-09-07 15:11:06 --> Database Driver Class Initialized
INFO - 2020-09-07 15:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:11:06 --> Email Class Initialized
INFO - 2020-09-07 15:11:06 --> Controller Class Initialized
INFO - 2020-09-07 15:11:06 --> Model Class Initialized
INFO - 2020-09-07 15:11:06 --> Model Class Initialized
INFO - 2020-09-07 15:11:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-07 15:11:06 --> Final output sent to browser
DEBUG - 2020-09-07 15:11:06 --> Total execution time: 0.2279
ERROR - 2020-09-07 15:11:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:11:08 --> Config Class Initialized
INFO - 2020-09-07 15:11:08 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:11:08 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:11:08 --> Utf8 Class Initialized
INFO - 2020-09-07 15:11:08 --> URI Class Initialized
INFO - 2020-09-07 15:11:08 --> Router Class Initialized
INFO - 2020-09-07 15:11:08 --> Output Class Initialized
INFO - 2020-09-07 15:11:08 --> Security Class Initialized
DEBUG - 2020-09-07 15:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:11:08 --> Input Class Initialized
INFO - 2020-09-07 15:11:08 --> Language Class Initialized
INFO - 2020-09-07 15:11:08 --> Loader Class Initialized
INFO - 2020-09-07 15:11:08 --> Helper loaded: url_helper
INFO - 2020-09-07 15:11:08 --> Database Driver Class Initialized
INFO - 2020-09-07 15:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:11:08 --> Email Class Initialized
INFO - 2020-09-07 15:11:08 --> Controller Class Initialized
INFO - 2020-09-07 15:11:08 --> Model Class Initialized
INFO - 2020-09-07 15:11:08 --> Model Class Initialized
ERROR - 2020-09-07 15:11:08 --> Query error: Unknown column 'CustomerID' in 'order clause' - Invalid query: SELECT *
FROM `tbl_customer`
ORDER BY `CustomerID` DESC
INFO - 2020-09-07 15:11:08 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-07 15:11:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:11:10 --> Config Class Initialized
INFO - 2020-09-07 15:11:10 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:11:10 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:11:10 --> Utf8 Class Initialized
INFO - 2020-09-07 15:11:10 --> URI Class Initialized
INFO - 2020-09-07 15:11:10 --> Router Class Initialized
INFO - 2020-09-07 15:11:10 --> Output Class Initialized
INFO - 2020-09-07 15:11:10 --> Security Class Initialized
DEBUG - 2020-09-07 15:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:11:10 --> Input Class Initialized
INFO - 2020-09-07 15:11:10 --> Language Class Initialized
INFO - 2020-09-07 15:11:10 --> Loader Class Initialized
INFO - 2020-09-07 15:11:10 --> Helper loaded: url_helper
INFO - 2020-09-07 15:11:10 --> Database Driver Class Initialized
INFO - 2020-09-07 15:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:11:10 --> Email Class Initialized
INFO - 2020-09-07 15:11:10 --> Controller Class Initialized
INFO - 2020-09-07 15:11:10 --> Model Class Initialized
INFO - 2020-09-07 15:11:10 --> Model Class Initialized
INFO - 2020-09-07 15:11:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-07 15:11:10 --> Final output sent to browser
DEBUG - 2020-09-07 15:11:10 --> Total execution time: 0.0426
ERROR - 2020-09-07 15:11:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:11:11 --> Config Class Initialized
INFO - 2020-09-07 15:11:11 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:11:11 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:11:11 --> Utf8 Class Initialized
INFO - 2020-09-07 15:11:11 --> URI Class Initialized
INFO - 2020-09-07 15:11:11 --> Router Class Initialized
INFO - 2020-09-07 15:11:11 --> Output Class Initialized
INFO - 2020-09-07 15:11:11 --> Security Class Initialized
DEBUG - 2020-09-07 15:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:11:11 --> Input Class Initialized
INFO - 2020-09-07 15:11:11 --> Language Class Initialized
INFO - 2020-09-07 15:11:11 --> Loader Class Initialized
INFO - 2020-09-07 15:11:11 --> Helper loaded: url_helper
INFO - 2020-09-07 15:11:11 --> Database Driver Class Initialized
INFO - 2020-09-07 15:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:11:11 --> Email Class Initialized
INFO - 2020-09-07 15:11:11 --> Controller Class Initialized
INFO - 2020-09-07 15:11:11 --> Model Class Initialized
INFO - 2020-09-07 15:11:11 --> Model Class Initialized
ERROR - 2020-09-07 15:11:11 --> Query error: Unknown column 'CustomerID' in 'order clause' - Invalid query: SELECT *
FROM `tbl_customer`
ORDER BY `CustomerID` DESC
INFO - 2020-09-07 15:11:11 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-07 15:11:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:11:47 --> Config Class Initialized
INFO - 2020-09-07 15:11:47 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:11:47 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:11:47 --> Utf8 Class Initialized
INFO - 2020-09-07 15:11:47 --> URI Class Initialized
INFO - 2020-09-07 15:11:47 --> Router Class Initialized
INFO - 2020-09-07 15:11:47 --> Output Class Initialized
INFO - 2020-09-07 15:11:47 --> Security Class Initialized
DEBUG - 2020-09-07 15:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:11:47 --> Input Class Initialized
INFO - 2020-09-07 15:11:47 --> Language Class Initialized
INFO - 2020-09-07 15:11:47 --> Loader Class Initialized
INFO - 2020-09-07 15:11:47 --> Helper loaded: url_helper
INFO - 2020-09-07 15:11:47 --> Database Driver Class Initialized
INFO - 2020-09-07 15:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:11:47 --> Email Class Initialized
INFO - 2020-09-07 15:11:47 --> Controller Class Initialized
INFO - 2020-09-07 15:11:47 --> Model Class Initialized
INFO - 2020-09-07 15:11:47 --> Model Class Initialized
ERROR - 2020-09-07 15:11:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:11:48 --> Config Class Initialized
INFO - 2020-09-07 15:11:48 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:11:48 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:11:48 --> Utf8 Class Initialized
INFO - 2020-09-07 15:11:48 --> URI Class Initialized
DEBUG - 2020-09-07 15:11:48 --> No URI present. Default controller set.
INFO - 2020-09-07 15:11:48 --> Router Class Initialized
INFO - 2020-09-07 15:11:48 --> Output Class Initialized
INFO - 2020-09-07 15:11:48 --> Security Class Initialized
DEBUG - 2020-09-07 15:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:11:48 --> Input Class Initialized
INFO - 2020-09-07 15:11:48 --> Language Class Initialized
INFO - 2020-09-07 15:11:48 --> Loader Class Initialized
INFO - 2020-09-07 15:11:48 --> Helper loaded: url_helper
INFO - 2020-09-07 15:11:48 --> Database Driver Class Initialized
INFO - 2020-09-07 15:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:11:48 --> Email Class Initialized
INFO - 2020-09-07 15:11:48 --> Controller Class Initialized
INFO - 2020-09-07 15:11:48 --> Model Class Initialized
INFO - 2020-09-07 15:11:48 --> Model Class Initialized
DEBUG - 2020-09-07 15:11:48 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-07 15:11:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-07 15:11:48 --> Final output sent to browser
DEBUG - 2020-09-07 15:11:48 --> Total execution time: 0.0402
ERROR - 2020-09-07 15:11:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:11:52 --> Config Class Initialized
INFO - 2020-09-07 15:11:52 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:11:52 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:11:52 --> Utf8 Class Initialized
INFO - 2020-09-07 15:11:52 --> URI Class Initialized
INFO - 2020-09-07 15:11:52 --> Router Class Initialized
INFO - 2020-09-07 15:11:52 --> Output Class Initialized
INFO - 2020-09-07 15:11:52 --> Security Class Initialized
DEBUG - 2020-09-07 15:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:11:52 --> Input Class Initialized
INFO - 2020-09-07 15:11:52 --> Language Class Initialized
INFO - 2020-09-07 15:11:52 --> Loader Class Initialized
INFO - 2020-09-07 15:11:52 --> Helper loaded: url_helper
INFO - 2020-09-07 15:11:52 --> Database Driver Class Initialized
INFO - 2020-09-07 15:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:11:52 --> Email Class Initialized
INFO - 2020-09-07 15:11:52 --> Controller Class Initialized
INFO - 2020-09-07 15:11:52 --> Model Class Initialized
INFO - 2020-09-07 15:11:52 --> Model Class Initialized
DEBUG - 2020-09-07 15:11:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 15:11:52 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-07 15:11:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:11:52 --> Config Class Initialized
INFO - 2020-09-07 15:11:52 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:11:52 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:11:52 --> Utf8 Class Initialized
INFO - 2020-09-07 15:11:52 --> URI Class Initialized
INFO - 2020-09-07 15:11:52 --> Router Class Initialized
INFO - 2020-09-07 15:11:52 --> Output Class Initialized
INFO - 2020-09-07 15:11:52 --> Security Class Initialized
DEBUG - 2020-09-07 15:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:11:52 --> Input Class Initialized
INFO - 2020-09-07 15:11:52 --> Language Class Initialized
INFO - 2020-09-07 15:11:52 --> Loader Class Initialized
INFO - 2020-09-07 15:11:52 --> Helper loaded: url_helper
INFO - 2020-09-07 15:11:52 --> Database Driver Class Initialized
INFO - 2020-09-07 15:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:11:52 --> Email Class Initialized
INFO - 2020-09-07 15:11:52 --> Controller Class Initialized
INFO - 2020-09-07 15:11:52 --> Model Class Initialized
INFO - 2020-09-07 15:11:52 --> Model Class Initialized
DEBUG - 2020-09-07 15:11:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-07 15:11:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:11:52 --> Config Class Initialized
INFO - 2020-09-07 15:11:52 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:11:52 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:11:52 --> Utf8 Class Initialized
INFO - 2020-09-07 15:11:52 --> URI Class Initialized
DEBUG - 2020-09-07 15:11:52 --> No URI present. Default controller set.
INFO - 2020-09-07 15:11:52 --> Router Class Initialized
INFO - 2020-09-07 15:11:52 --> Output Class Initialized
INFO - 2020-09-07 15:11:52 --> Security Class Initialized
DEBUG - 2020-09-07 15:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:11:52 --> Input Class Initialized
INFO - 2020-09-07 15:11:52 --> Language Class Initialized
INFO - 2020-09-07 15:11:52 --> Loader Class Initialized
INFO - 2020-09-07 15:11:52 --> Helper loaded: url_helper
INFO - 2020-09-07 15:11:52 --> Database Driver Class Initialized
INFO - 2020-09-07 15:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:11:52 --> Email Class Initialized
INFO - 2020-09-07 15:11:52 --> Controller Class Initialized
INFO - 2020-09-07 15:11:52 --> Model Class Initialized
INFO - 2020-09-07 15:11:52 --> Model Class Initialized
DEBUG - 2020-09-07 15:11:52 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-07 15:11:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-07 15:11:52 --> Final output sent to browser
DEBUG - 2020-09-07 15:11:52 --> Total execution time: 0.0197
ERROR - 2020-09-07 15:11:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:11:53 --> Config Class Initialized
INFO - 2020-09-07 15:11:53 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:11:53 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:11:53 --> Utf8 Class Initialized
INFO - 2020-09-07 15:11:53 --> URI Class Initialized
INFO - 2020-09-07 15:11:53 --> Router Class Initialized
INFO - 2020-09-07 15:11:53 --> Output Class Initialized
INFO - 2020-09-07 15:11:53 --> Security Class Initialized
DEBUG - 2020-09-07 15:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:11:53 --> Input Class Initialized
INFO - 2020-09-07 15:11:53 --> Language Class Initialized
INFO - 2020-09-07 15:11:53 --> Loader Class Initialized
INFO - 2020-09-07 15:11:53 --> Helper loaded: url_helper
INFO - 2020-09-07 15:11:53 --> Database Driver Class Initialized
INFO - 2020-09-07 15:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:11:53 --> Email Class Initialized
INFO - 2020-09-07 15:11:53 --> Controller Class Initialized
DEBUG - 2020-09-07 15:11:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 15:11:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-07 15:11:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-07 15:11:53 --> Final output sent to browser
DEBUG - 2020-09-07 15:11:53 --> Total execution time: 0.0323
ERROR - 2020-09-07 15:12:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:12:26 --> Config Class Initialized
INFO - 2020-09-07 15:12:26 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:12:26 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:12:26 --> Utf8 Class Initialized
INFO - 2020-09-07 15:12:26 --> URI Class Initialized
INFO - 2020-09-07 15:12:26 --> Router Class Initialized
INFO - 2020-09-07 15:12:26 --> Output Class Initialized
INFO - 2020-09-07 15:12:26 --> Security Class Initialized
DEBUG - 2020-09-07 15:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:12:26 --> Input Class Initialized
INFO - 2020-09-07 15:12:26 --> Language Class Initialized
INFO - 2020-09-07 15:12:26 --> Loader Class Initialized
INFO - 2020-09-07 15:12:26 --> Helper loaded: url_helper
INFO - 2020-09-07 15:12:26 --> Database Driver Class Initialized
INFO - 2020-09-07 15:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:12:26 --> Email Class Initialized
INFO - 2020-09-07 15:12:26 --> Controller Class Initialized
INFO - 2020-09-07 15:12:26 --> Model Class Initialized
INFO - 2020-09-07 15:12:26 --> Model Class Initialized
INFO - 2020-09-07 15:12:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-07 15:12:26 --> Final output sent to browser
DEBUG - 2020-09-07 15:12:26 --> Total execution time: 0.0435
ERROR - 2020-09-07 15:12:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:12:26 --> Config Class Initialized
INFO - 2020-09-07 15:12:26 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:12:26 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:12:26 --> Utf8 Class Initialized
INFO - 2020-09-07 15:12:26 --> URI Class Initialized
INFO - 2020-09-07 15:12:26 --> Router Class Initialized
INFO - 2020-09-07 15:12:26 --> Output Class Initialized
INFO - 2020-09-07 15:12:26 --> Security Class Initialized
DEBUG - 2020-09-07 15:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:12:26 --> Input Class Initialized
INFO - 2020-09-07 15:12:26 --> Language Class Initialized
INFO - 2020-09-07 15:12:26 --> Loader Class Initialized
INFO - 2020-09-07 15:12:26 --> Helper loaded: url_helper
INFO - 2020-09-07 15:12:26 --> Database Driver Class Initialized
INFO - 2020-09-07 15:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:12:27 --> Email Class Initialized
INFO - 2020-09-07 15:12:27 --> Controller Class Initialized
INFO - 2020-09-07 15:12:27 --> Model Class Initialized
INFO - 2020-09-07 15:12:27 --> Model Class Initialized
ERROR - 2020-09-07 15:12:27 --> Query error: Unknown column 'CustomerID' in 'order clause' - Invalid query: SELECT *
FROM `tbl_customer`
ORDER BY `CustomerID` DESC
INFO - 2020-09-07 15:12:27 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-07 15:12:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:12:32 --> Config Class Initialized
INFO - 2020-09-07 15:12:32 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:12:32 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:12:32 --> Utf8 Class Initialized
INFO - 2020-09-07 15:12:32 --> URI Class Initialized
INFO - 2020-09-07 15:12:32 --> Router Class Initialized
INFO - 2020-09-07 15:12:32 --> Output Class Initialized
INFO - 2020-09-07 15:12:32 --> Security Class Initialized
DEBUG - 2020-09-07 15:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:12:32 --> Input Class Initialized
INFO - 2020-09-07 15:12:32 --> Language Class Initialized
INFO - 2020-09-07 15:12:32 --> Loader Class Initialized
INFO - 2020-09-07 15:12:32 --> Helper loaded: url_helper
INFO - 2020-09-07 15:12:32 --> Database Driver Class Initialized
INFO - 2020-09-07 15:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:12:32 --> Email Class Initialized
INFO - 2020-09-07 15:12:32 --> Controller Class Initialized
INFO - 2020-09-07 15:12:32 --> Model Class Initialized
INFO - 2020-09-07 15:12:32 --> Model Class Initialized
INFO - 2020-09-07 15:12:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-07 15:12:32 --> Final output sent to browser
DEBUG - 2020-09-07 15:12:32 --> Total execution time: 0.0397
ERROR - 2020-09-07 15:12:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:12:33 --> Config Class Initialized
INFO - 2020-09-07 15:12:33 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:12:33 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:12:33 --> Utf8 Class Initialized
INFO - 2020-09-07 15:12:33 --> URI Class Initialized
INFO - 2020-09-07 15:12:33 --> Router Class Initialized
INFO - 2020-09-07 15:12:33 --> Output Class Initialized
INFO - 2020-09-07 15:12:33 --> Security Class Initialized
DEBUG - 2020-09-07 15:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:12:33 --> Input Class Initialized
INFO - 2020-09-07 15:12:33 --> Language Class Initialized
INFO - 2020-09-07 15:12:33 --> Loader Class Initialized
INFO - 2020-09-07 15:12:33 --> Helper loaded: url_helper
INFO - 2020-09-07 15:12:33 --> Database Driver Class Initialized
INFO - 2020-09-07 15:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:12:33 --> Email Class Initialized
INFO - 2020-09-07 15:12:33 --> Controller Class Initialized
INFO - 2020-09-07 15:12:33 --> Model Class Initialized
INFO - 2020-09-07 15:12:33 --> Model Class Initialized
ERROR - 2020-09-07 15:12:33 --> Query error: Unknown column 'CustomerID' in 'order clause' - Invalid query: SELECT *
FROM `tbl_customer`
ORDER BY `CustomerID` DESC
INFO - 2020-09-07 15:12:33 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-07 15:12:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:12:54 --> Config Class Initialized
INFO - 2020-09-07 15:12:54 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:12:54 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:12:54 --> Utf8 Class Initialized
INFO - 2020-09-07 15:12:54 --> URI Class Initialized
INFO - 2020-09-07 15:12:54 --> Router Class Initialized
INFO - 2020-09-07 15:12:54 --> Output Class Initialized
INFO - 2020-09-07 15:12:54 --> Security Class Initialized
DEBUG - 2020-09-07 15:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:12:54 --> Input Class Initialized
INFO - 2020-09-07 15:12:54 --> Language Class Initialized
INFO - 2020-09-07 15:12:54 --> Loader Class Initialized
INFO - 2020-09-07 15:12:54 --> Helper loaded: url_helper
INFO - 2020-09-07 15:12:54 --> Database Driver Class Initialized
INFO - 2020-09-07 15:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:12:54 --> Email Class Initialized
INFO - 2020-09-07 15:12:54 --> Controller Class Initialized
DEBUG - 2020-09-07 15:12:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 15:12:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-07 15:12:54 --> Model Class Initialized
INFO - 2020-09-07 15:12:54 --> Model Class Initialized
INFO - 2020-09-07 15:12:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-09-07 15:12:54 --> Final output sent to browser
DEBUG - 2020-09-07 15:12:54 --> Total execution time: 0.0311
ERROR - 2020-09-07 15:13:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:13:00 --> Config Class Initialized
INFO - 2020-09-07 15:13:00 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:13:00 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:13:00 --> Utf8 Class Initialized
INFO - 2020-09-07 15:13:00 --> URI Class Initialized
INFO - 2020-09-07 15:13:00 --> Router Class Initialized
INFO - 2020-09-07 15:13:00 --> Output Class Initialized
INFO - 2020-09-07 15:13:00 --> Security Class Initialized
DEBUG - 2020-09-07 15:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:13:00 --> Input Class Initialized
INFO - 2020-09-07 15:13:00 --> Language Class Initialized
INFO - 2020-09-07 15:13:00 --> Loader Class Initialized
INFO - 2020-09-07 15:13:00 --> Helper loaded: url_helper
INFO - 2020-09-07 15:13:00 --> Database Driver Class Initialized
INFO - 2020-09-07 15:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:13:00 --> Email Class Initialized
INFO - 2020-09-07 15:13:00 --> Controller Class Initialized
INFO - 2020-09-07 15:13:00 --> Model Class Initialized
INFO - 2020-09-07 15:13:00 --> Model Class Initialized
INFO - 2020-09-07 15:13:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-07 15:13:00 --> Final output sent to browser
DEBUG - 2020-09-07 15:13:00 --> Total execution time: 0.0388
ERROR - 2020-09-07 15:13:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:13:01 --> Config Class Initialized
INFO - 2020-09-07 15:13:01 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:13:01 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:13:01 --> Utf8 Class Initialized
INFO - 2020-09-07 15:13:01 --> URI Class Initialized
INFO - 2020-09-07 15:13:01 --> Router Class Initialized
INFO - 2020-09-07 15:13:01 --> Output Class Initialized
INFO - 2020-09-07 15:13:01 --> Security Class Initialized
DEBUG - 2020-09-07 15:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:13:01 --> Input Class Initialized
INFO - 2020-09-07 15:13:01 --> Language Class Initialized
INFO - 2020-09-07 15:13:01 --> Loader Class Initialized
INFO - 2020-09-07 15:13:01 --> Helper loaded: url_helper
INFO - 2020-09-07 15:13:01 --> Database Driver Class Initialized
INFO - 2020-09-07 15:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:13:01 --> Email Class Initialized
INFO - 2020-09-07 15:13:01 --> Controller Class Initialized
INFO - 2020-09-07 15:13:01 --> Model Class Initialized
INFO - 2020-09-07 15:13:01 --> Model Class Initialized
ERROR - 2020-09-07 15:13:01 --> Query error: Unknown column 'CustomerID' in 'order clause' - Invalid query: SELECT *
FROM `tbl_customer`
ORDER BY `CustomerID` DESC
INFO - 2020-09-07 15:13:01 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-07 15:15:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:15:24 --> Config Class Initialized
INFO - 2020-09-07 15:15:24 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:15:24 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:15:24 --> Utf8 Class Initialized
INFO - 2020-09-07 15:15:24 --> URI Class Initialized
INFO - 2020-09-07 15:15:24 --> Router Class Initialized
INFO - 2020-09-07 15:15:24 --> Output Class Initialized
INFO - 2020-09-07 15:15:24 --> Security Class Initialized
DEBUG - 2020-09-07 15:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:15:24 --> Input Class Initialized
INFO - 2020-09-07 15:15:24 --> Language Class Initialized
INFO - 2020-09-07 15:15:24 --> Loader Class Initialized
INFO - 2020-09-07 15:15:24 --> Helper loaded: url_helper
INFO - 2020-09-07 15:15:24 --> Database Driver Class Initialized
INFO - 2020-09-07 15:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:15:24 --> Email Class Initialized
INFO - 2020-09-07 15:15:24 --> Controller Class Initialized
INFO - 2020-09-07 15:15:24 --> Model Class Initialized
INFO - 2020-09-07 15:15:24 --> Model Class Initialized
INFO - 2020-09-07 15:15:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-07 15:15:24 --> Final output sent to browser
DEBUG - 2020-09-07 15:15:24 --> Total execution time: 0.0690
ERROR - 2020-09-07 15:15:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:15:25 --> Config Class Initialized
INFO - 2020-09-07 15:15:25 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:15:25 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:15:25 --> Utf8 Class Initialized
INFO - 2020-09-07 15:15:25 --> URI Class Initialized
INFO - 2020-09-07 15:15:25 --> Router Class Initialized
INFO - 2020-09-07 15:15:25 --> Output Class Initialized
INFO - 2020-09-07 15:15:25 --> Security Class Initialized
DEBUG - 2020-09-07 15:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:15:25 --> Input Class Initialized
INFO - 2020-09-07 15:15:25 --> Language Class Initialized
INFO - 2020-09-07 15:15:25 --> Loader Class Initialized
INFO - 2020-09-07 15:15:25 --> Helper loaded: url_helper
INFO - 2020-09-07 15:15:25 --> Database Driver Class Initialized
INFO - 2020-09-07 15:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:15:25 --> Email Class Initialized
INFO - 2020-09-07 15:15:25 --> Controller Class Initialized
INFO - 2020-09-07 15:15:25 --> Model Class Initialized
INFO - 2020-09-07 15:15:25 --> Model Class Initialized
ERROR - 2020-09-07 15:15:25 --> Query error: Unknown column 'CustomerID' in 'order clause' - Invalid query: SELECT *
FROM `tbl_customer`
ORDER BY `CustomerID` DESC
INFO - 2020-09-07 15:15:25 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-07 15:15:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:15:40 --> Config Class Initialized
INFO - 2020-09-07 15:15:40 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:15:40 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:15:40 --> Utf8 Class Initialized
INFO - 2020-09-07 15:15:40 --> URI Class Initialized
INFO - 2020-09-07 15:15:40 --> Router Class Initialized
INFO - 2020-09-07 15:15:40 --> Output Class Initialized
INFO - 2020-09-07 15:15:40 --> Security Class Initialized
DEBUG - 2020-09-07 15:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:15:40 --> Input Class Initialized
INFO - 2020-09-07 15:15:40 --> Language Class Initialized
INFO - 2020-09-07 15:15:40 --> Loader Class Initialized
INFO - 2020-09-07 15:15:40 --> Helper loaded: url_helper
INFO - 2020-09-07 15:15:40 --> Database Driver Class Initialized
INFO - 2020-09-07 15:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:15:40 --> Email Class Initialized
INFO - 2020-09-07 15:15:40 --> Controller Class Initialized
DEBUG - 2020-09-07 15:15:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 15:15:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-07 15:15:40 --> Model Class Initialized
INFO - 2020-09-07 15:15:40 --> Model Class Initialized
INFO - 2020-09-07 15:15:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-07 15:15:40 --> Final output sent to browser
DEBUG - 2020-09-07 15:15:40 --> Total execution time: 0.0448
ERROR - 2020-09-07 15:18:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:18:24 --> Config Class Initialized
INFO - 2020-09-07 15:18:24 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:18:24 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:18:24 --> Utf8 Class Initialized
INFO - 2020-09-07 15:18:24 --> URI Class Initialized
INFO - 2020-09-07 15:18:24 --> Router Class Initialized
INFO - 2020-09-07 15:18:24 --> Output Class Initialized
INFO - 2020-09-07 15:18:24 --> Security Class Initialized
DEBUG - 2020-09-07 15:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:18:24 --> Input Class Initialized
INFO - 2020-09-07 15:18:24 --> Language Class Initialized
INFO - 2020-09-07 15:18:24 --> Loader Class Initialized
INFO - 2020-09-07 15:18:24 --> Helper loaded: url_helper
INFO - 2020-09-07 15:18:24 --> Database Driver Class Initialized
INFO - 2020-09-07 15:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:18:24 --> Email Class Initialized
INFO - 2020-09-07 15:18:24 --> Controller Class Initialized
INFO - 2020-09-07 15:18:24 --> Model Class Initialized
INFO - 2020-09-07 15:18:24 --> Model Class Initialized
INFO - 2020-09-07 15:18:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-07 15:18:24 --> Final output sent to browser
DEBUG - 2020-09-07 15:18:24 --> Total execution time: 0.4162
ERROR - 2020-09-07 15:18:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:18:26 --> Config Class Initialized
INFO - 2020-09-07 15:18:26 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:18:26 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:18:26 --> Utf8 Class Initialized
INFO - 2020-09-07 15:18:26 --> URI Class Initialized
INFO - 2020-09-07 15:18:26 --> Router Class Initialized
INFO - 2020-09-07 15:18:26 --> Output Class Initialized
INFO - 2020-09-07 15:18:26 --> Security Class Initialized
DEBUG - 2020-09-07 15:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:18:26 --> Input Class Initialized
INFO - 2020-09-07 15:18:26 --> Language Class Initialized
INFO - 2020-09-07 15:18:26 --> Loader Class Initialized
INFO - 2020-09-07 15:18:26 --> Helper loaded: url_helper
INFO - 2020-09-07 15:18:26 --> Database Driver Class Initialized
INFO - 2020-09-07 15:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:18:26 --> Email Class Initialized
INFO - 2020-09-07 15:18:26 --> Controller Class Initialized
INFO - 2020-09-07 15:18:26 --> Model Class Initialized
INFO - 2020-09-07 15:18:26 --> Model Class Initialized
ERROR - 2020-09-07 15:18:26 --> Query error: Unknown column 'CustomerID' in 'order clause' - Invalid query: SELECT *
FROM `tbl_customer`
ORDER BY `CustomerID` DESC
INFO - 2020-09-07 15:18:26 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-07 15:18:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:18:27 --> Config Class Initialized
INFO - 2020-09-07 15:18:27 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:18:27 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:18:27 --> Utf8 Class Initialized
INFO - 2020-09-07 15:18:27 --> URI Class Initialized
INFO - 2020-09-07 15:18:27 --> Router Class Initialized
INFO - 2020-09-07 15:18:27 --> Output Class Initialized
INFO - 2020-09-07 15:18:27 --> Security Class Initialized
DEBUG - 2020-09-07 15:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:18:27 --> Input Class Initialized
INFO - 2020-09-07 15:18:27 --> Language Class Initialized
INFO - 2020-09-07 15:18:27 --> Loader Class Initialized
INFO - 2020-09-07 15:18:27 --> Helper loaded: url_helper
INFO - 2020-09-07 15:18:27 --> Database Driver Class Initialized
INFO - 2020-09-07 15:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:18:27 --> Email Class Initialized
INFO - 2020-09-07 15:18:27 --> Controller Class Initialized
INFO - 2020-09-07 15:18:27 --> Model Class Initialized
INFO - 2020-09-07 15:18:27 --> Model Class Initialized
INFO - 2020-09-07 15:18:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-07 15:18:27 --> Final output sent to browser
DEBUG - 2020-09-07 15:18:27 --> Total execution time: 0.0447
ERROR - 2020-09-07 15:18:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:18:28 --> Config Class Initialized
INFO - 2020-09-07 15:18:28 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:18:28 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:18:28 --> Utf8 Class Initialized
INFO - 2020-09-07 15:18:28 --> URI Class Initialized
INFO - 2020-09-07 15:18:28 --> Router Class Initialized
INFO - 2020-09-07 15:18:28 --> Output Class Initialized
INFO - 2020-09-07 15:18:28 --> Security Class Initialized
DEBUG - 2020-09-07 15:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:18:28 --> Input Class Initialized
INFO - 2020-09-07 15:18:28 --> Language Class Initialized
INFO - 2020-09-07 15:18:28 --> Loader Class Initialized
INFO - 2020-09-07 15:18:28 --> Helper loaded: url_helper
INFO - 2020-09-07 15:18:28 --> Database Driver Class Initialized
INFO - 2020-09-07 15:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:18:28 --> Email Class Initialized
INFO - 2020-09-07 15:18:28 --> Controller Class Initialized
INFO - 2020-09-07 15:18:28 --> Model Class Initialized
INFO - 2020-09-07 15:18:28 --> Model Class Initialized
ERROR - 2020-09-07 15:18:28 --> Query error: Unknown column 'CustomerID' in 'order clause' - Invalid query: SELECT *
FROM `tbl_customer`
ORDER BY `CustomerID` DESC
INFO - 2020-09-07 15:18:28 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-07 15:18:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:18:38 --> Config Class Initialized
INFO - 2020-09-07 15:18:38 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:18:38 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:18:38 --> Utf8 Class Initialized
INFO - 2020-09-07 15:18:38 --> URI Class Initialized
INFO - 2020-09-07 15:18:38 --> Router Class Initialized
INFO - 2020-09-07 15:18:38 --> Output Class Initialized
INFO - 2020-09-07 15:18:38 --> Security Class Initialized
DEBUG - 2020-09-07 15:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:18:38 --> Input Class Initialized
INFO - 2020-09-07 15:18:38 --> Language Class Initialized
INFO - 2020-09-07 15:18:38 --> Loader Class Initialized
INFO - 2020-09-07 15:18:38 --> Helper loaded: url_helper
INFO - 2020-09-07 15:18:38 --> Database Driver Class Initialized
INFO - 2020-09-07 15:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:18:38 --> Email Class Initialized
INFO - 2020-09-07 15:18:38 --> Controller Class Initialized
INFO - 2020-09-07 15:18:38 --> Model Class Initialized
INFO - 2020-09-07 15:18:38 --> Model Class Initialized
INFO - 2020-09-07 15:18:38 --> Final output sent to browser
DEBUG - 2020-09-07 15:18:38 --> Total execution time: 0.0833
ERROR - 2020-09-07 15:18:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:18:39 --> Config Class Initialized
INFO - 2020-09-07 15:18:39 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:18:39 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:18:39 --> Utf8 Class Initialized
INFO - 2020-09-07 15:18:39 --> URI Class Initialized
INFO - 2020-09-07 15:18:39 --> Router Class Initialized
INFO - 2020-09-07 15:18:39 --> Output Class Initialized
INFO - 2020-09-07 15:18:39 --> Security Class Initialized
DEBUG - 2020-09-07 15:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:18:39 --> Input Class Initialized
INFO - 2020-09-07 15:18:39 --> Language Class Initialized
INFO - 2020-09-07 15:18:39 --> Loader Class Initialized
INFO - 2020-09-07 15:18:39 --> Helper loaded: url_helper
INFO - 2020-09-07 15:18:39 --> Database Driver Class Initialized
INFO - 2020-09-07 15:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:18:39 --> Email Class Initialized
INFO - 2020-09-07 15:18:39 --> Controller Class Initialized
INFO - 2020-09-07 15:18:39 --> Model Class Initialized
INFO - 2020-09-07 15:18:39 --> Model Class Initialized
ERROR - 2020-09-07 15:18:39 --> Query error: Unknown column 'CustomerID' in 'order clause' - Invalid query: SELECT *
FROM `tbl_customer`
ORDER BY `CustomerID` DESC
INFO - 2020-09-07 15:18:39 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-07 15:28:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:28:19 --> Config Class Initialized
INFO - 2020-09-07 15:28:19 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:28:19 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:28:19 --> Utf8 Class Initialized
INFO - 2020-09-07 15:28:19 --> URI Class Initialized
INFO - 2020-09-07 15:28:19 --> Router Class Initialized
INFO - 2020-09-07 15:28:19 --> Output Class Initialized
INFO - 2020-09-07 15:28:19 --> Security Class Initialized
DEBUG - 2020-09-07 15:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:28:19 --> Input Class Initialized
INFO - 2020-09-07 15:28:19 --> Language Class Initialized
INFO - 2020-09-07 15:28:19 --> Loader Class Initialized
INFO - 2020-09-07 15:28:19 --> Helper loaded: url_helper
INFO - 2020-09-07 15:28:19 --> Database Driver Class Initialized
INFO - 2020-09-07 15:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:28:20 --> Email Class Initialized
INFO - 2020-09-07 15:28:20 --> Controller Class Initialized
INFO - 2020-09-07 15:28:20 --> Model Class Initialized
INFO - 2020-09-07 15:28:20 --> Model Class Initialized
INFO - 2020-09-07 15:28:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-07 15:28:20 --> Final output sent to browser
DEBUG - 2020-09-07 15:28:20 --> Total execution time: 0.0418
ERROR - 2020-09-07 15:28:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:28:21 --> Config Class Initialized
INFO - 2020-09-07 15:28:21 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:28:21 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:28:21 --> Utf8 Class Initialized
INFO - 2020-09-07 15:28:21 --> URI Class Initialized
INFO - 2020-09-07 15:28:21 --> Router Class Initialized
INFO - 2020-09-07 15:28:21 --> Output Class Initialized
INFO - 2020-09-07 15:28:21 --> Security Class Initialized
DEBUG - 2020-09-07 15:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:28:21 --> Input Class Initialized
INFO - 2020-09-07 15:28:21 --> Language Class Initialized
INFO - 2020-09-07 15:28:21 --> Loader Class Initialized
INFO - 2020-09-07 15:28:21 --> Helper loaded: url_helper
INFO - 2020-09-07 15:28:21 --> Database Driver Class Initialized
INFO - 2020-09-07 15:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:28:21 --> Email Class Initialized
INFO - 2020-09-07 15:28:21 --> Controller Class Initialized
INFO - 2020-09-07 15:28:21 --> Model Class Initialized
INFO - 2020-09-07 15:28:21 --> Model Class Initialized
ERROR - 2020-09-07 15:28:21 --> Query error: Unknown column 'CustomerID' in 'order clause' - Invalid query: SELECT *
FROM `tbl_customer`
ORDER BY `CustomerID` DESC
INFO - 2020-09-07 15:28:21 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-07 15:29:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:29:26 --> Config Class Initialized
INFO - 2020-09-07 15:29:26 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:29:26 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:29:26 --> Utf8 Class Initialized
INFO - 2020-09-07 15:29:26 --> URI Class Initialized
INFO - 2020-09-07 15:29:26 --> Router Class Initialized
INFO - 2020-09-07 15:29:26 --> Output Class Initialized
INFO - 2020-09-07 15:29:26 --> Security Class Initialized
DEBUG - 2020-09-07 15:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:29:26 --> Input Class Initialized
INFO - 2020-09-07 15:29:26 --> Language Class Initialized
INFO - 2020-09-07 15:29:26 --> Loader Class Initialized
INFO - 2020-09-07 15:29:26 --> Helper loaded: url_helper
INFO - 2020-09-07 15:29:26 --> Database Driver Class Initialized
INFO - 2020-09-07 15:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:29:26 --> Email Class Initialized
INFO - 2020-09-07 15:29:26 --> Controller Class Initialized
DEBUG - 2020-09-07 15:29:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-07 15:29:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-07 15:29:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-07 15:29:26 --> Final output sent to browser
DEBUG - 2020-09-07 15:29:26 --> Total execution time: 0.0202
ERROR - 2020-09-07 15:36:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:36:01 --> Config Class Initialized
INFO - 2020-09-07 15:36:01 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:36:01 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:36:01 --> Utf8 Class Initialized
INFO - 2020-09-07 15:36:01 --> URI Class Initialized
INFO - 2020-09-07 15:36:01 --> Router Class Initialized
INFO - 2020-09-07 15:36:01 --> Output Class Initialized
INFO - 2020-09-07 15:36:01 --> Security Class Initialized
DEBUG - 2020-09-07 15:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:36:01 --> Input Class Initialized
INFO - 2020-09-07 15:36:01 --> Language Class Initialized
INFO - 2020-09-07 15:36:01 --> Loader Class Initialized
INFO - 2020-09-07 15:36:01 --> Helper loaded: url_helper
INFO - 2020-09-07 15:36:01 --> Database Driver Class Initialized
INFO - 2020-09-07 15:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:36:01 --> Email Class Initialized
INFO - 2020-09-07 15:36:01 --> Controller Class Initialized
INFO - 2020-09-07 15:36:01 --> Model Class Initialized
INFO - 2020-09-07 15:36:01 --> Model Class Initialized
INFO - 2020-09-07 15:36:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-07 15:36:01 --> Final output sent to browser
DEBUG - 2020-09-07 15:36:01 --> Total execution time: 0.0519
ERROR - 2020-09-07 15:36:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:36:03 --> Config Class Initialized
INFO - 2020-09-07 15:36:03 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:36:03 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:36:03 --> Utf8 Class Initialized
INFO - 2020-09-07 15:36:03 --> URI Class Initialized
INFO - 2020-09-07 15:36:03 --> Router Class Initialized
INFO - 2020-09-07 15:36:03 --> Output Class Initialized
INFO - 2020-09-07 15:36:03 --> Security Class Initialized
DEBUG - 2020-09-07 15:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:36:03 --> Input Class Initialized
INFO - 2020-09-07 15:36:03 --> Language Class Initialized
INFO - 2020-09-07 15:36:03 --> Loader Class Initialized
INFO - 2020-09-07 15:36:03 --> Helper loaded: url_helper
INFO - 2020-09-07 15:36:03 --> Database Driver Class Initialized
INFO - 2020-09-07 15:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:36:03 --> Email Class Initialized
INFO - 2020-09-07 15:36:03 --> Controller Class Initialized
INFO - 2020-09-07 15:36:03 --> Model Class Initialized
INFO - 2020-09-07 15:36:03 --> Model Class Initialized
ERROR - 2020-09-07 15:36:03 --> Query error: Unknown column 'CustomerID' in 'order clause' - Invalid query: SELECT *
FROM `tbl_customer`
ORDER BY `CustomerID` DESC
INFO - 2020-09-07 15:36:03 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-07 15:36:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:36:10 --> Config Class Initialized
INFO - 2020-09-07 15:36:10 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:36:10 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:36:10 --> Utf8 Class Initialized
INFO - 2020-09-07 15:36:10 --> URI Class Initialized
INFO - 2020-09-07 15:36:10 --> Router Class Initialized
INFO - 2020-09-07 15:36:10 --> Output Class Initialized
INFO - 2020-09-07 15:36:10 --> Security Class Initialized
DEBUG - 2020-09-07 15:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:36:10 --> Input Class Initialized
INFO - 2020-09-07 15:36:10 --> Language Class Initialized
INFO - 2020-09-07 15:36:10 --> Loader Class Initialized
INFO - 2020-09-07 15:36:10 --> Helper loaded: url_helper
INFO - 2020-09-07 15:36:10 --> Database Driver Class Initialized
INFO - 2020-09-07 15:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:36:10 --> Email Class Initialized
INFO - 2020-09-07 15:36:10 --> Controller Class Initialized
INFO - 2020-09-07 15:36:10 --> Model Class Initialized
INFO - 2020-09-07 15:36:10 --> Model Class Initialized
INFO - 2020-09-07 15:36:10 --> Final output sent to browser
DEBUG - 2020-09-07 15:36:10 --> Total execution time: 0.0826
ERROR - 2020-09-07 15:36:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:36:10 --> Config Class Initialized
INFO - 2020-09-07 15:36:10 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:36:10 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:36:10 --> Utf8 Class Initialized
INFO - 2020-09-07 15:36:10 --> URI Class Initialized
INFO - 2020-09-07 15:36:10 --> Router Class Initialized
INFO - 2020-09-07 15:36:10 --> Output Class Initialized
INFO - 2020-09-07 15:36:10 --> Security Class Initialized
DEBUG - 2020-09-07 15:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:36:10 --> Input Class Initialized
INFO - 2020-09-07 15:36:10 --> Language Class Initialized
INFO - 2020-09-07 15:36:10 --> Loader Class Initialized
INFO - 2020-09-07 15:36:10 --> Helper loaded: url_helper
INFO - 2020-09-07 15:36:10 --> Database Driver Class Initialized
INFO - 2020-09-07 15:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:36:10 --> Email Class Initialized
INFO - 2020-09-07 15:36:10 --> Controller Class Initialized
INFO - 2020-09-07 15:36:10 --> Model Class Initialized
INFO - 2020-09-07 15:36:10 --> Model Class Initialized
ERROR - 2020-09-07 15:36:10 --> Query error: Unknown column 'CustomerID' in 'order clause' - Invalid query: SELECT *
FROM `tbl_customer`
ORDER BY `CustomerID` DESC
INFO - 2020-09-07 15:36:10 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-07 15:39:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:39:16 --> Config Class Initialized
INFO - 2020-09-07 15:39:16 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:39:16 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:39:16 --> Utf8 Class Initialized
INFO - 2020-09-07 15:39:16 --> URI Class Initialized
INFO - 2020-09-07 15:39:16 --> Router Class Initialized
INFO - 2020-09-07 15:39:16 --> Output Class Initialized
INFO - 2020-09-07 15:39:16 --> Security Class Initialized
DEBUG - 2020-09-07 15:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:39:16 --> Input Class Initialized
INFO - 2020-09-07 15:39:16 --> Language Class Initialized
INFO - 2020-09-07 15:39:16 --> Loader Class Initialized
INFO - 2020-09-07 15:39:16 --> Helper loaded: url_helper
INFO - 2020-09-07 15:39:16 --> Database Driver Class Initialized
INFO - 2020-09-07 15:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:39:16 --> Email Class Initialized
INFO - 2020-09-07 15:39:16 --> Controller Class Initialized
INFO - 2020-09-07 15:39:16 --> Model Class Initialized
INFO - 2020-09-07 15:39:16 --> Model Class Initialized
INFO - 2020-09-07 15:39:16 --> Final output sent to browser
DEBUG - 2020-09-07 15:39:16 --> Total execution time: 0.0905
ERROR - 2020-09-07 15:39:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:39:17 --> Config Class Initialized
INFO - 2020-09-07 15:39:17 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:39:17 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:39:17 --> Utf8 Class Initialized
INFO - 2020-09-07 15:39:17 --> URI Class Initialized
INFO - 2020-09-07 15:39:17 --> Router Class Initialized
INFO - 2020-09-07 15:39:17 --> Output Class Initialized
INFO - 2020-09-07 15:39:17 --> Security Class Initialized
DEBUG - 2020-09-07 15:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:39:17 --> Input Class Initialized
INFO - 2020-09-07 15:39:17 --> Language Class Initialized
INFO - 2020-09-07 15:39:17 --> Loader Class Initialized
INFO - 2020-09-07 15:39:17 --> Helper loaded: url_helper
INFO - 2020-09-07 15:39:17 --> Database Driver Class Initialized
INFO - 2020-09-07 15:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:39:17 --> Email Class Initialized
INFO - 2020-09-07 15:39:17 --> Controller Class Initialized
INFO - 2020-09-07 15:39:17 --> Model Class Initialized
INFO - 2020-09-07 15:39:17 --> Model Class Initialized
ERROR - 2020-09-07 15:39:17 --> Query error: Unknown column 'CustomerID' in 'order clause' - Invalid query: SELECT *
FROM `tbl_customer`
ORDER BY `CustomerID` DESC
INFO - 2020-09-07 15:39:17 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-07 15:44:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:44:32 --> Config Class Initialized
INFO - 2020-09-07 15:44:32 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:44:32 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:44:32 --> Utf8 Class Initialized
INFO - 2020-09-07 15:44:32 --> URI Class Initialized
INFO - 2020-09-07 15:44:32 --> Router Class Initialized
INFO - 2020-09-07 15:44:32 --> Output Class Initialized
INFO - 2020-09-07 15:44:32 --> Security Class Initialized
DEBUG - 2020-09-07 15:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:44:32 --> Input Class Initialized
INFO - 2020-09-07 15:44:32 --> Language Class Initialized
INFO - 2020-09-07 15:44:32 --> Loader Class Initialized
INFO - 2020-09-07 15:44:32 --> Helper loaded: url_helper
INFO - 2020-09-07 15:44:32 --> Database Driver Class Initialized
INFO - 2020-09-07 15:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:44:32 --> Email Class Initialized
INFO - 2020-09-07 15:44:32 --> Controller Class Initialized
INFO - 2020-09-07 15:44:32 --> Model Class Initialized
INFO - 2020-09-07 15:44:32 --> Model Class Initialized
INFO - 2020-09-07 15:44:32 --> Final output sent to browser
DEBUG - 2020-09-07 15:44:32 --> Total execution time: 0.0766
ERROR - 2020-09-07 15:44:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:44:32 --> Config Class Initialized
INFO - 2020-09-07 15:44:32 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:44:32 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:44:32 --> Utf8 Class Initialized
INFO - 2020-09-07 15:44:32 --> URI Class Initialized
INFO - 2020-09-07 15:44:32 --> Router Class Initialized
INFO - 2020-09-07 15:44:32 --> Output Class Initialized
INFO - 2020-09-07 15:44:32 --> Security Class Initialized
DEBUG - 2020-09-07 15:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:44:32 --> Input Class Initialized
INFO - 2020-09-07 15:44:32 --> Language Class Initialized
INFO - 2020-09-07 15:44:32 --> Loader Class Initialized
INFO - 2020-09-07 15:44:32 --> Helper loaded: url_helper
INFO - 2020-09-07 15:44:32 --> Database Driver Class Initialized
INFO - 2020-09-07 15:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:44:32 --> Email Class Initialized
INFO - 2020-09-07 15:44:32 --> Controller Class Initialized
INFO - 2020-09-07 15:44:32 --> Model Class Initialized
INFO - 2020-09-07 15:44:32 --> Model Class Initialized
INFO - 2020-09-07 15:44:32 --> Final output sent to browser
DEBUG - 2020-09-07 15:44:32 --> Total execution time: 0.0713
ERROR - 2020-09-07 15:44:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-07 15:44:32 --> Config Class Initialized
INFO - 2020-09-07 15:44:32 --> Hooks Class Initialized
DEBUG - 2020-09-07 15:44:32 --> UTF-8 Support Enabled
INFO - 2020-09-07 15:44:32 --> Utf8 Class Initialized
INFO - 2020-09-07 15:44:32 --> URI Class Initialized
INFO - 2020-09-07 15:44:32 --> Router Class Initialized
INFO - 2020-09-07 15:44:32 --> Output Class Initialized
INFO - 2020-09-07 15:44:32 --> Security Class Initialized
DEBUG - 2020-09-07 15:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-07 15:44:32 --> Input Class Initialized
INFO - 2020-09-07 15:44:32 --> Language Class Initialized
INFO - 2020-09-07 15:44:32 --> Loader Class Initialized
INFO - 2020-09-07 15:44:32 --> Helper loaded: url_helper
INFO - 2020-09-07 15:44:32 --> Database Driver Class Initialized
INFO - 2020-09-07 15:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-07 15:44:32 --> Email Class Initialized
INFO - 2020-09-07 15:44:32 --> Controller Class Initialized
INFO - 2020-09-07 15:44:32 --> Model Class Initialized
INFO - 2020-09-07 15:44:32 --> Model Class Initialized
ERROR - 2020-09-07 15:44:32 --> Query error: Unknown column 'CustomerID' in 'order clause' - Invalid query: SELECT *
FROM `import`
ORDER BY `CustomerID` DESC
INFO - 2020-09-07 15:44:32 --> Language file loaded: language/english/db_lang.php
