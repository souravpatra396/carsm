<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-08 14:12:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 14:12:55 --> Config Class Initialized
INFO - 2020-11-08 14:12:55 --> Hooks Class Initialized
DEBUG - 2020-11-08 14:12:55 --> UTF-8 Support Enabled
INFO - 2020-11-08 14:12:55 --> Utf8 Class Initialized
INFO - 2020-11-08 14:12:55 --> URI Class Initialized
DEBUG - 2020-11-08 14:12:55 --> No URI present. Default controller set.
INFO - 2020-11-08 14:12:55 --> Router Class Initialized
INFO - 2020-11-08 14:12:55 --> Output Class Initialized
INFO - 2020-11-08 14:12:55 --> Security Class Initialized
DEBUG - 2020-11-08 14:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 14:12:55 --> Input Class Initialized
INFO - 2020-11-08 14:12:55 --> Language Class Initialized
INFO - 2020-11-08 14:12:55 --> Loader Class Initialized
INFO - 2020-11-08 14:12:55 --> Helper loaded: url_helper
INFO - 2020-11-08 14:12:55 --> Database Driver Class Initialized
INFO - 2020-11-08 14:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 14:12:55 --> Email Class Initialized
INFO - 2020-11-08 14:12:55 --> Controller Class Initialized
INFO - 2020-11-08 14:12:55 --> Model Class Initialized
INFO - 2020-11-08 14:12:55 --> Model Class Initialized
DEBUG - 2020-11-08 14:12:55 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-08 14:12:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-08 14:12:55 --> Final output sent to browser
DEBUG - 2020-11-08 14:12:55 --> Total execution time: 0.1238
ERROR - 2020-11-08 14:25:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 14:25:46 --> Config Class Initialized
INFO - 2020-11-08 14:25:46 --> Hooks Class Initialized
DEBUG - 2020-11-08 14:25:46 --> UTF-8 Support Enabled
INFO - 2020-11-08 14:25:46 --> Utf8 Class Initialized
INFO - 2020-11-08 14:25:46 --> URI Class Initialized
DEBUG - 2020-11-08 14:25:46 --> No URI present. Default controller set.
INFO - 2020-11-08 14:25:46 --> Router Class Initialized
INFO - 2020-11-08 14:25:46 --> Output Class Initialized
INFO - 2020-11-08 14:25:46 --> Security Class Initialized
DEBUG - 2020-11-08 14:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 14:25:46 --> Input Class Initialized
INFO - 2020-11-08 14:25:46 --> Language Class Initialized
INFO - 2020-11-08 14:25:46 --> Loader Class Initialized
INFO - 2020-11-08 14:25:46 --> Helper loaded: url_helper
INFO - 2020-11-08 14:25:46 --> Database Driver Class Initialized
INFO - 2020-11-08 14:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 14:25:46 --> Email Class Initialized
INFO - 2020-11-08 14:25:46 --> Controller Class Initialized
INFO - 2020-11-08 14:25:46 --> Model Class Initialized
INFO - 2020-11-08 14:25:46 --> Model Class Initialized
DEBUG - 2020-11-08 14:25:46 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-08 14:25:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-08 14:25:46 --> Final output sent to browser
DEBUG - 2020-11-08 14:25:46 --> Total execution time: 0.0585
ERROR - 2020-11-08 14:26:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 14:26:04 --> Config Class Initialized
INFO - 2020-11-08 14:26:04 --> Hooks Class Initialized
DEBUG - 2020-11-08 14:26:04 --> UTF-8 Support Enabled
INFO - 2020-11-08 14:26:04 --> Utf8 Class Initialized
INFO - 2020-11-08 14:26:04 --> URI Class Initialized
INFO - 2020-11-08 14:26:04 --> Router Class Initialized
INFO - 2020-11-08 14:26:04 --> Output Class Initialized
INFO - 2020-11-08 14:26:04 --> Security Class Initialized
DEBUG - 2020-11-08 14:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 14:26:04 --> Input Class Initialized
INFO - 2020-11-08 14:26:04 --> Language Class Initialized
INFO - 2020-11-08 14:26:04 --> Loader Class Initialized
INFO - 2020-11-08 14:26:04 --> Helper loaded: url_helper
INFO - 2020-11-08 14:26:04 --> Database Driver Class Initialized
INFO - 2020-11-08 14:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 14:26:04 --> Email Class Initialized
INFO - 2020-11-08 14:26:04 --> Controller Class Initialized
INFO - 2020-11-08 14:26:04 --> Model Class Initialized
INFO - 2020-11-08 14:26:04 --> Model Class Initialized
DEBUG - 2020-11-08 14:26:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 14:26:04 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-08 14:26:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 14:26:04 --> Config Class Initialized
INFO - 2020-11-08 14:26:04 --> Hooks Class Initialized
DEBUG - 2020-11-08 14:26:04 --> UTF-8 Support Enabled
INFO - 2020-11-08 14:26:04 --> Utf8 Class Initialized
INFO - 2020-11-08 14:26:04 --> URI Class Initialized
INFO - 2020-11-08 14:26:04 --> Router Class Initialized
INFO - 2020-11-08 14:26:04 --> Output Class Initialized
INFO - 2020-11-08 14:26:04 --> Security Class Initialized
DEBUG - 2020-11-08 14:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 14:26:04 --> Input Class Initialized
INFO - 2020-11-08 14:26:04 --> Language Class Initialized
INFO - 2020-11-08 14:26:04 --> Loader Class Initialized
INFO - 2020-11-08 14:26:04 --> Helper loaded: url_helper
INFO - 2020-11-08 14:26:04 --> Database Driver Class Initialized
INFO - 2020-11-08 14:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 14:26:04 --> Email Class Initialized
INFO - 2020-11-08 14:26:04 --> Controller Class Initialized
INFO - 2020-11-08 14:26:04 --> Model Class Initialized
INFO - 2020-11-08 14:26:04 --> Model Class Initialized
DEBUG - 2020-11-08 14:26:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-11-08 14:26:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 14:26:05 --> Config Class Initialized
INFO - 2020-11-08 14:26:05 --> Hooks Class Initialized
DEBUG - 2020-11-08 14:26:05 --> UTF-8 Support Enabled
INFO - 2020-11-08 14:26:05 --> Utf8 Class Initialized
INFO - 2020-11-08 14:26:05 --> URI Class Initialized
DEBUG - 2020-11-08 14:26:05 --> No URI present. Default controller set.
INFO - 2020-11-08 14:26:05 --> Router Class Initialized
INFO - 2020-11-08 14:26:05 --> Output Class Initialized
INFO - 2020-11-08 14:26:05 --> Security Class Initialized
DEBUG - 2020-11-08 14:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 14:26:05 --> Input Class Initialized
INFO - 2020-11-08 14:26:05 --> Language Class Initialized
INFO - 2020-11-08 14:26:05 --> Loader Class Initialized
INFO - 2020-11-08 14:26:05 --> Helper loaded: url_helper
INFO - 2020-11-08 14:26:05 --> Database Driver Class Initialized
INFO - 2020-11-08 14:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 14:26:05 --> Email Class Initialized
INFO - 2020-11-08 14:26:05 --> Controller Class Initialized
INFO - 2020-11-08 14:26:05 --> Model Class Initialized
INFO - 2020-11-08 14:26:05 --> Model Class Initialized
DEBUG - 2020-11-08 14:26:05 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-08 14:26:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-08 14:26:05 --> Final output sent to browser
DEBUG - 2020-11-08 14:26:05 --> Total execution time: 0.0208
ERROR - 2020-11-08 14:26:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 14:26:05 --> Config Class Initialized
INFO - 2020-11-08 14:26:05 --> Hooks Class Initialized
DEBUG - 2020-11-08 14:26:05 --> UTF-8 Support Enabled
INFO - 2020-11-08 14:26:05 --> Utf8 Class Initialized
INFO - 2020-11-08 14:26:05 --> URI Class Initialized
INFO - 2020-11-08 14:26:05 --> Router Class Initialized
INFO - 2020-11-08 14:26:05 --> Output Class Initialized
INFO - 2020-11-08 14:26:05 --> Security Class Initialized
DEBUG - 2020-11-08 14:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 14:26:05 --> Input Class Initialized
INFO - 2020-11-08 14:26:05 --> Language Class Initialized
INFO - 2020-11-08 14:26:05 --> Loader Class Initialized
INFO - 2020-11-08 14:26:05 --> Helper loaded: url_helper
INFO - 2020-11-08 14:26:05 --> Database Driver Class Initialized
INFO - 2020-11-08 14:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 14:26:05 --> Email Class Initialized
INFO - 2020-11-08 14:26:05 --> Controller Class Initialized
DEBUG - 2020-11-08 14:26:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 14:26:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 14:26:05 --> Model Class Initialized
INFO - 2020-11-08 14:26:05 --> Model Class Initialized
INFO - 2020-11-08 14:26:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-08 14:26:05 --> Final output sent to browser
DEBUG - 2020-11-08 14:26:05 --> Total execution time: 0.0916
ERROR - 2020-11-08 14:26:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 14:26:12 --> Config Class Initialized
INFO - 2020-11-08 14:26:12 --> Hooks Class Initialized
DEBUG - 2020-11-08 14:26:12 --> UTF-8 Support Enabled
INFO - 2020-11-08 14:26:12 --> Utf8 Class Initialized
INFO - 2020-11-08 14:26:12 --> URI Class Initialized
INFO - 2020-11-08 14:26:12 --> Router Class Initialized
INFO - 2020-11-08 14:26:12 --> Output Class Initialized
INFO - 2020-11-08 14:26:12 --> Security Class Initialized
DEBUG - 2020-11-08 14:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 14:26:12 --> Input Class Initialized
INFO - 2020-11-08 14:26:12 --> Language Class Initialized
INFO - 2020-11-08 14:26:12 --> Loader Class Initialized
INFO - 2020-11-08 14:26:12 --> Helper loaded: url_helper
INFO - 2020-11-08 14:26:12 --> Database Driver Class Initialized
INFO - 2020-11-08 14:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 14:26:12 --> Email Class Initialized
INFO - 2020-11-08 14:26:12 --> Controller Class Initialized
DEBUG - 2020-11-08 14:26:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 14:26:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 14:26:12 --> Model Class Initialized
INFO - 2020-11-08 14:26:12 --> Model Class Initialized
INFO - 2020-11-08 14:26:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-11-08 14:26:12 --> Final output sent to browser
DEBUG - 2020-11-08 14:26:12 --> Total execution time: 0.2615
ERROR - 2020-11-08 14:26:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 14:26:18 --> Config Class Initialized
INFO - 2020-11-08 14:26:18 --> Hooks Class Initialized
DEBUG - 2020-11-08 14:26:18 --> UTF-8 Support Enabled
INFO - 2020-11-08 14:26:18 --> Utf8 Class Initialized
INFO - 2020-11-08 14:26:18 --> URI Class Initialized
INFO - 2020-11-08 14:26:18 --> Router Class Initialized
INFO - 2020-11-08 14:26:18 --> Output Class Initialized
INFO - 2020-11-08 14:26:18 --> Security Class Initialized
DEBUG - 2020-11-08 14:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 14:26:18 --> Input Class Initialized
INFO - 2020-11-08 14:26:18 --> Language Class Initialized
INFO - 2020-11-08 14:26:18 --> Loader Class Initialized
INFO - 2020-11-08 14:26:18 --> Helper loaded: url_helper
INFO - 2020-11-08 14:26:18 --> Database Driver Class Initialized
INFO - 2020-11-08 14:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 14:26:18 --> Email Class Initialized
INFO - 2020-11-08 14:26:18 --> Controller Class Initialized
DEBUG - 2020-11-08 14:26:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 14:26:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 14:26:18 --> Model Class Initialized
INFO - 2020-11-08 14:26:18 --> Model Class Initialized
ERROR - 2020-11-08 14:26:18 --> Severity: Runtime Notice --> Non-static method Purlem::get_contact() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-08 14:26:18 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 17
INFO - 2020-11-08 14:26:20 --> Final output sent to browser
DEBUG - 2020-11-08 14:26:20 --> Total execution time: 1.5212
ERROR - 2020-11-08 14:34:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 14:34:32 --> Config Class Initialized
INFO - 2020-11-08 14:34:32 --> Hooks Class Initialized
DEBUG - 2020-11-08 14:34:32 --> UTF-8 Support Enabled
INFO - 2020-11-08 14:34:32 --> Utf8 Class Initialized
INFO - 2020-11-08 14:34:32 --> URI Class Initialized
INFO - 2020-11-08 14:34:32 --> Router Class Initialized
INFO - 2020-11-08 14:34:32 --> Output Class Initialized
INFO - 2020-11-08 14:34:32 --> Security Class Initialized
DEBUG - 2020-11-08 14:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 14:34:32 --> Input Class Initialized
INFO - 2020-11-08 14:34:32 --> Language Class Initialized
INFO - 2020-11-08 14:34:32 --> Loader Class Initialized
INFO - 2020-11-08 14:34:32 --> Helper loaded: url_helper
INFO - 2020-11-08 14:34:32 --> Database Driver Class Initialized
INFO - 2020-11-08 14:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 14:34:32 --> Email Class Initialized
INFO - 2020-11-08 14:34:32 --> Controller Class Initialized
DEBUG - 2020-11-08 14:34:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 14:34:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 14:34:32 --> Model Class Initialized
INFO - 2020-11-08 14:34:32 --> Model Class Initialized
ERROR - 2020-11-08 14:34:32 --> Severity: Runtime Notice --> Non-static method Purlem::get_campaign() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-08 14:34:32 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 51
INFO - 2020-11-08 14:34:34 --> Final output sent to browser
DEBUG - 2020-11-08 14:34:34 --> Total execution time: 1.8553
ERROR - 2020-11-08 14:42:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 14:42:08 --> Config Class Initialized
INFO - 2020-11-08 14:42:08 --> Hooks Class Initialized
DEBUG - 2020-11-08 14:42:08 --> UTF-8 Support Enabled
INFO - 2020-11-08 14:42:08 --> Utf8 Class Initialized
INFO - 2020-11-08 14:42:08 --> URI Class Initialized
INFO - 2020-11-08 14:42:08 --> Router Class Initialized
INFO - 2020-11-08 14:42:08 --> Output Class Initialized
INFO - 2020-11-08 14:42:08 --> Security Class Initialized
DEBUG - 2020-11-08 14:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 14:42:08 --> Input Class Initialized
INFO - 2020-11-08 14:42:08 --> Language Class Initialized
INFO - 2020-11-08 14:42:08 --> Loader Class Initialized
INFO - 2020-11-08 14:42:08 --> Helper loaded: url_helper
INFO - 2020-11-08 14:42:08 --> Database Driver Class Initialized
INFO - 2020-11-08 14:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 14:42:08 --> Email Class Initialized
INFO - 2020-11-08 14:42:08 --> Controller Class Initialized
DEBUG - 2020-11-08 14:42:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 14:42:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 14:42:08 --> Model Class Initialized
INFO - 2020-11-08 14:42:08 --> Model Class Initialized
ERROR - 2020-11-08 14:42:08 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-08 14:42:08 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
INFO - 2020-11-08 14:42:09 --> Final output sent to browser
DEBUG - 2020-11-08 14:42:09 --> Total execution time: 0.9939
ERROR - 2020-11-08 14:47:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 14:47:47 --> Config Class Initialized
INFO - 2020-11-08 14:47:47 --> Hooks Class Initialized
DEBUG - 2020-11-08 14:47:47 --> UTF-8 Support Enabled
INFO - 2020-11-08 14:47:47 --> Utf8 Class Initialized
INFO - 2020-11-08 14:47:47 --> URI Class Initialized
INFO - 2020-11-08 14:47:47 --> Router Class Initialized
INFO - 2020-11-08 14:47:47 --> Output Class Initialized
INFO - 2020-11-08 14:47:47 --> Security Class Initialized
DEBUG - 2020-11-08 14:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 14:47:47 --> Input Class Initialized
INFO - 2020-11-08 14:47:47 --> Language Class Initialized
INFO - 2020-11-08 14:47:47 --> Loader Class Initialized
INFO - 2020-11-08 14:47:47 --> Helper loaded: url_helper
INFO - 2020-11-08 14:47:47 --> Database Driver Class Initialized
INFO - 2020-11-08 14:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 14:47:47 --> Email Class Initialized
INFO - 2020-11-08 14:47:47 --> Controller Class Initialized
DEBUG - 2020-11-08 14:47:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 14:47:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 14:47:47 --> Model Class Initialized
INFO - 2020-11-08 14:47:47 --> Model Class Initialized
ERROR - 2020-11-08 14:47:47 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaign_contacts() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 14:47:47 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 59
INFO - 2020-11-08 14:47:48 --> Final output sent to browser
DEBUG - 2020-11-08 14:47:48 --> Total execution time: 1.6428
ERROR - 2020-11-08 14:50:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 14:50:53 --> Config Class Initialized
INFO - 2020-11-08 14:50:53 --> Hooks Class Initialized
DEBUG - 2020-11-08 14:50:53 --> UTF-8 Support Enabled
INFO - 2020-11-08 14:50:53 --> Utf8 Class Initialized
INFO - 2020-11-08 14:50:53 --> URI Class Initialized
INFO - 2020-11-08 14:50:53 --> Router Class Initialized
INFO - 2020-11-08 14:50:53 --> Output Class Initialized
INFO - 2020-11-08 14:50:53 --> Security Class Initialized
DEBUG - 2020-11-08 14:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 14:50:53 --> Input Class Initialized
INFO - 2020-11-08 14:50:53 --> Language Class Initialized
INFO - 2020-11-08 14:50:53 --> Loader Class Initialized
INFO - 2020-11-08 14:50:53 --> Helper loaded: url_helper
INFO - 2020-11-08 14:50:53 --> Database Driver Class Initialized
INFO - 2020-11-08 14:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 14:50:53 --> Email Class Initialized
INFO - 2020-11-08 14:50:53 --> Controller Class Initialized
DEBUG - 2020-11-08 14:50:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 14:50:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 14:50:53 --> Model Class Initialized
INFO - 2020-11-08 14:50:53 --> Model Class Initialized
ERROR - 2020-11-08 14:50:53 --> Severity: Runtime Notice --> Non-static method Purlem::get_campaign_fields() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 14:50:53 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 55
INFO - 2020-11-08 14:50:54 --> Final output sent to browser
DEBUG - 2020-11-08 14:50:54 --> Total execution time: 1.0270
ERROR - 2020-11-08 14:53:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 14:53:07 --> Config Class Initialized
INFO - 2020-11-08 14:53:07 --> Hooks Class Initialized
DEBUG - 2020-11-08 14:53:07 --> UTF-8 Support Enabled
INFO - 2020-11-08 14:53:07 --> Utf8 Class Initialized
INFO - 2020-11-08 14:53:07 --> URI Class Initialized
INFO - 2020-11-08 14:53:07 --> Router Class Initialized
INFO - 2020-11-08 14:53:07 --> Output Class Initialized
INFO - 2020-11-08 14:53:07 --> Security Class Initialized
DEBUG - 2020-11-08 14:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 14:53:07 --> Input Class Initialized
INFO - 2020-11-08 14:53:07 --> Language Class Initialized
INFO - 2020-11-08 14:53:07 --> Loader Class Initialized
INFO - 2020-11-08 14:53:07 --> Helper loaded: url_helper
INFO - 2020-11-08 14:53:07 --> Database Driver Class Initialized
INFO - 2020-11-08 14:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 14:53:07 --> Email Class Initialized
INFO - 2020-11-08 14:53:07 --> Controller Class Initialized
DEBUG - 2020-11-08 14:53:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 14:53:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 14:53:07 --> Model Class Initialized
INFO - 2020-11-08 14:53:07 --> Model Class Initialized
ERROR - 2020-11-08 14:53:07 --> Severity: Runtime Notice --> Non-static method Purlem::get_campaign_fields() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 14:53:07 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 55
INFO - 2020-11-08 14:53:08 --> Final output sent to browser
DEBUG - 2020-11-08 14:53:08 --> Total execution time: 0.9734
ERROR - 2020-11-08 14:56:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 14:56:59 --> Config Class Initialized
INFO - 2020-11-08 14:56:59 --> Hooks Class Initialized
DEBUG - 2020-11-08 14:56:59 --> UTF-8 Support Enabled
INFO - 2020-11-08 14:56:59 --> Utf8 Class Initialized
INFO - 2020-11-08 14:56:59 --> URI Class Initialized
INFO - 2020-11-08 14:56:59 --> Router Class Initialized
INFO - 2020-11-08 14:56:59 --> Output Class Initialized
INFO - 2020-11-08 14:56:59 --> Security Class Initialized
DEBUG - 2020-11-08 14:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 14:56:59 --> Input Class Initialized
INFO - 2020-11-08 14:56:59 --> Language Class Initialized
INFO - 2020-11-08 14:56:59 --> Loader Class Initialized
INFO - 2020-11-08 14:56:59 --> Helper loaded: url_helper
INFO - 2020-11-08 14:56:59 --> Database Driver Class Initialized
INFO - 2020-11-08 14:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 14:56:59 --> Email Class Initialized
INFO - 2020-11-08 14:56:59 --> Controller Class Initialized
DEBUG - 2020-11-08 14:56:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 14:56:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 14:56:59 --> Model Class Initialized
INFO - 2020-11-08 14:56:59 --> Model Class Initialized
ERROR - 2020-11-08 14:56:59 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 405
ERROR - 2020-11-08 14:56:59 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-11-08 14:57:01 --> Final output sent to browser
DEBUG - 2020-11-08 14:57:01 --> Total execution time: 1.9417
ERROR - 2020-11-08 14:59:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 14:59:28 --> Config Class Initialized
INFO - 2020-11-08 14:59:28 --> Hooks Class Initialized
DEBUG - 2020-11-08 14:59:28 --> UTF-8 Support Enabled
INFO - 2020-11-08 14:59:28 --> Utf8 Class Initialized
INFO - 2020-11-08 14:59:28 --> URI Class Initialized
INFO - 2020-11-08 14:59:28 --> Router Class Initialized
INFO - 2020-11-08 14:59:28 --> Output Class Initialized
INFO - 2020-11-08 14:59:28 --> Security Class Initialized
DEBUG - 2020-11-08 14:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 14:59:28 --> Input Class Initialized
INFO - 2020-11-08 14:59:28 --> Language Class Initialized
INFO - 2020-11-08 14:59:28 --> Loader Class Initialized
INFO - 2020-11-08 14:59:28 --> Helper loaded: url_helper
INFO - 2020-11-08 14:59:28 --> Database Driver Class Initialized
INFO - 2020-11-08 14:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 14:59:28 --> Email Class Initialized
INFO - 2020-11-08 14:59:28 --> Controller Class Initialized
DEBUG - 2020-11-08 14:59:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 14:59:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 14:59:28 --> Model Class Initialized
INFO - 2020-11-08 14:59:28 --> Model Class Initialized
ERROR - 2020-11-08 14:59:28 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 405
ERROR - 2020-11-08 14:59:28 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-11-08 14:59:30 --> Final output sent to browser
DEBUG - 2020-11-08 14:59:30 --> Total execution time: 1.3318
ERROR - 2020-11-08 15:02:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 15:02:50 --> Config Class Initialized
INFO - 2020-11-08 15:02:50 --> Hooks Class Initialized
DEBUG - 2020-11-08 15:02:50 --> UTF-8 Support Enabled
INFO - 2020-11-08 15:02:50 --> Utf8 Class Initialized
INFO - 2020-11-08 15:02:50 --> URI Class Initialized
INFO - 2020-11-08 15:02:50 --> Router Class Initialized
INFO - 2020-11-08 15:02:50 --> Output Class Initialized
INFO - 2020-11-08 15:02:50 --> Security Class Initialized
DEBUG - 2020-11-08 15:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 15:02:50 --> Input Class Initialized
INFO - 2020-11-08 15:02:50 --> Language Class Initialized
INFO - 2020-11-08 15:02:50 --> Loader Class Initialized
INFO - 2020-11-08 15:02:50 --> Helper loaded: url_helper
INFO - 2020-11-08 15:02:50 --> Database Driver Class Initialized
INFO - 2020-11-08 15:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 15:02:50 --> Email Class Initialized
INFO - 2020-11-08 15:02:50 --> Controller Class Initialized
DEBUG - 2020-11-08 15:02:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 15:02:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 15:02:50 --> Model Class Initialized
INFO - 2020-11-08 15:02:50 --> Model Class Initialized
ERROR - 2020-11-08 15:02:50 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 405
ERROR - 2020-11-08 15:02:50 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-11-08 15:02:51 --> Final output sent to browser
DEBUG - 2020-11-08 15:02:51 --> Total execution time: 1.2027
ERROR - 2020-11-08 15:06:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 15:06:36 --> Config Class Initialized
INFO - 2020-11-08 15:06:36 --> Hooks Class Initialized
DEBUG - 2020-11-08 15:06:36 --> UTF-8 Support Enabled
INFO - 2020-11-08 15:06:36 --> Utf8 Class Initialized
INFO - 2020-11-08 15:06:36 --> URI Class Initialized
INFO - 2020-11-08 15:06:36 --> Router Class Initialized
INFO - 2020-11-08 15:06:36 --> Output Class Initialized
INFO - 2020-11-08 15:06:36 --> Security Class Initialized
DEBUG - 2020-11-08 15:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 15:06:36 --> Input Class Initialized
INFO - 2020-11-08 15:06:36 --> Language Class Initialized
INFO - 2020-11-08 15:06:36 --> Loader Class Initialized
INFO - 2020-11-08 15:06:36 --> Helper loaded: url_helper
INFO - 2020-11-08 15:06:36 --> Database Driver Class Initialized
INFO - 2020-11-08 15:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 15:06:36 --> Email Class Initialized
INFO - 2020-11-08 15:06:36 --> Controller Class Initialized
DEBUG - 2020-11-08 15:06:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 15:06:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 15:06:36 --> Model Class Initialized
INFO - 2020-11-08 15:06:36 --> Model Class Initialized
ERROR - 2020-11-08 15:06:36 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 405
ERROR - 2020-11-08 15:06:36 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-11-08 15:06:37 --> Final output sent to browser
DEBUG - 2020-11-08 15:06:37 --> Total execution time: 1.2084
ERROR - 2020-11-08 15:34:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 15:34:23 --> Config Class Initialized
INFO - 2020-11-08 15:34:23 --> Hooks Class Initialized
DEBUG - 2020-11-08 15:34:23 --> UTF-8 Support Enabled
INFO - 2020-11-08 15:34:23 --> Utf8 Class Initialized
INFO - 2020-11-08 15:34:23 --> URI Class Initialized
INFO - 2020-11-08 15:34:23 --> Router Class Initialized
INFO - 2020-11-08 15:34:23 --> Output Class Initialized
INFO - 2020-11-08 15:34:23 --> Security Class Initialized
DEBUG - 2020-11-08 15:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 15:34:23 --> Input Class Initialized
INFO - 2020-11-08 15:34:23 --> Language Class Initialized
INFO - 2020-11-08 15:34:23 --> Loader Class Initialized
INFO - 2020-11-08 15:34:23 --> Helper loaded: url_helper
INFO - 2020-11-08 15:34:23 --> Database Driver Class Initialized
INFO - 2020-11-08 15:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 15:34:23 --> Email Class Initialized
INFO - 2020-11-08 15:34:23 --> Controller Class Initialized
DEBUG - 2020-11-08 15:34:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 15:34:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 15:34:23 --> Model Class Initialized
INFO - 2020-11-08 15:34:23 --> Model Class Initialized
ERROR - 2020-11-08 15:34:23 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 405
ERROR - 2020-11-08 15:34:23 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-11-08 15:34:24 --> Final output sent to browser
DEBUG - 2020-11-08 15:34:24 --> Total execution time: 1.2784
ERROR - 2020-11-08 15:42:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 15:42:19 --> Config Class Initialized
INFO - 2020-11-08 15:42:19 --> Hooks Class Initialized
DEBUG - 2020-11-08 15:42:19 --> UTF-8 Support Enabled
INFO - 2020-11-08 15:42:19 --> Utf8 Class Initialized
INFO - 2020-11-08 15:42:19 --> URI Class Initialized
INFO - 2020-11-08 15:42:19 --> Router Class Initialized
INFO - 2020-11-08 15:42:19 --> Output Class Initialized
INFO - 2020-11-08 15:42:19 --> Security Class Initialized
DEBUG - 2020-11-08 15:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 15:42:19 --> Input Class Initialized
INFO - 2020-11-08 15:42:19 --> Language Class Initialized
INFO - 2020-11-08 15:42:19 --> Loader Class Initialized
INFO - 2020-11-08 15:42:19 --> Helper loaded: url_helper
INFO - 2020-11-08 15:42:19 --> Database Driver Class Initialized
INFO - 2020-11-08 15:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 15:42:19 --> Email Class Initialized
INFO - 2020-11-08 15:42:19 --> Controller Class Initialized
DEBUG - 2020-11-08 15:42:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 15:42:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 15:42:19 --> Model Class Initialized
INFO - 2020-11-08 15:42:19 --> Model Class Initialized
ERROR - 2020-11-08 15:42:19 --> Severity: Runtime Notice --> Non-static method Purlem::get_campaign_fields() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 405
ERROR - 2020-11-08 15:42:19 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 55
INFO - 2020-11-08 15:42:20 --> Final output sent to browser
DEBUG - 2020-11-08 15:42:20 --> Total execution time: 0.9493
ERROR - 2020-11-08 15:43:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 15:43:02 --> Config Class Initialized
INFO - 2020-11-08 15:43:02 --> Hooks Class Initialized
DEBUG - 2020-11-08 15:43:02 --> UTF-8 Support Enabled
INFO - 2020-11-08 15:43:02 --> Utf8 Class Initialized
INFO - 2020-11-08 15:43:02 --> URI Class Initialized
INFO - 2020-11-08 15:43:02 --> Router Class Initialized
INFO - 2020-11-08 15:43:02 --> Output Class Initialized
INFO - 2020-11-08 15:43:02 --> Security Class Initialized
DEBUG - 2020-11-08 15:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 15:43:02 --> Input Class Initialized
INFO - 2020-11-08 15:43:02 --> Language Class Initialized
INFO - 2020-11-08 15:43:02 --> Loader Class Initialized
INFO - 2020-11-08 15:43:02 --> Helper loaded: url_helper
INFO - 2020-11-08 15:43:02 --> Database Driver Class Initialized
INFO - 2020-11-08 15:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 15:43:02 --> Email Class Initialized
INFO - 2020-11-08 15:43:02 --> Controller Class Initialized
DEBUG - 2020-11-08 15:43:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 15:43:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 15:43:02 --> Model Class Initialized
INFO - 2020-11-08 15:43:02 --> Model Class Initialized
ERROR - 2020-11-08 15:43:02 --> Severity: Runtime Notice --> Non-static method Purlem::get_campaign_fields() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 405
ERROR - 2020-11-08 15:43:02 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 55
INFO - 2020-11-08 15:43:03 --> Final output sent to browser
DEBUG - 2020-11-08 15:43:03 --> Total execution time: 1.0557
ERROR - 2020-11-08 15:43:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 15:43:08 --> Config Class Initialized
INFO - 2020-11-08 15:43:08 --> Hooks Class Initialized
DEBUG - 2020-11-08 15:43:08 --> UTF-8 Support Enabled
INFO - 2020-11-08 15:43:08 --> Utf8 Class Initialized
INFO - 2020-11-08 15:43:08 --> URI Class Initialized
INFO - 2020-11-08 15:43:08 --> Router Class Initialized
INFO - 2020-11-08 15:43:08 --> Output Class Initialized
INFO - 2020-11-08 15:43:08 --> Security Class Initialized
DEBUG - 2020-11-08 15:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 15:43:08 --> Input Class Initialized
INFO - 2020-11-08 15:43:08 --> Language Class Initialized
INFO - 2020-11-08 15:43:08 --> Loader Class Initialized
INFO - 2020-11-08 15:43:08 --> Helper loaded: url_helper
INFO - 2020-11-08 15:43:08 --> Database Driver Class Initialized
INFO - 2020-11-08 15:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 15:43:08 --> Email Class Initialized
INFO - 2020-11-08 15:43:08 --> Controller Class Initialized
DEBUG - 2020-11-08 15:43:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 15:43:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 15:43:08 --> Model Class Initialized
INFO - 2020-11-08 15:43:08 --> Model Class Initialized
ERROR - 2020-11-08 15:43:08 --> Severity: Runtime Notice --> Non-static method Purlem::get_campaign_fields() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 405
ERROR - 2020-11-08 15:43:08 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 55
INFO - 2020-11-08 15:43:09 --> Final output sent to browser
DEBUG - 2020-11-08 15:43:09 --> Total execution time: 0.9539
ERROR - 2020-11-08 15:46:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 15:46:15 --> Config Class Initialized
INFO - 2020-11-08 15:46:15 --> Hooks Class Initialized
DEBUG - 2020-11-08 15:46:15 --> UTF-8 Support Enabled
INFO - 2020-11-08 15:46:15 --> Utf8 Class Initialized
INFO - 2020-11-08 15:46:15 --> URI Class Initialized
INFO - 2020-11-08 15:46:15 --> Router Class Initialized
INFO - 2020-11-08 15:46:15 --> Output Class Initialized
INFO - 2020-11-08 15:46:15 --> Security Class Initialized
DEBUG - 2020-11-08 15:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 15:46:15 --> Input Class Initialized
INFO - 2020-11-08 15:46:15 --> Language Class Initialized
INFO - 2020-11-08 15:46:15 --> Loader Class Initialized
INFO - 2020-11-08 15:46:15 --> Helper loaded: url_helper
INFO - 2020-11-08 15:46:15 --> Database Driver Class Initialized
INFO - 2020-11-08 15:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 15:46:15 --> Email Class Initialized
INFO - 2020-11-08 15:46:15 --> Controller Class Initialized
DEBUG - 2020-11-08 15:46:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 15:46:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 15:46:15 --> Model Class Initialized
INFO - 2020-11-08 15:46:15 --> Model Class Initialized
ERROR - 2020-11-08 15:46:15 --> Severity: Runtime Notice --> Non-static method Purlem::get_campaign_fields() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 405
ERROR - 2020-11-08 15:46:15 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 55
INFO - 2020-11-08 15:46:16 --> Final output sent to browser
DEBUG - 2020-11-08 15:46:16 --> Total execution time: 1.0504
ERROR - 2020-11-08 15:46:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 15:46:19 --> Config Class Initialized
INFO - 2020-11-08 15:46:19 --> Hooks Class Initialized
DEBUG - 2020-11-08 15:46:19 --> UTF-8 Support Enabled
INFO - 2020-11-08 15:46:19 --> Utf8 Class Initialized
INFO - 2020-11-08 15:46:19 --> URI Class Initialized
INFO - 2020-11-08 15:46:19 --> Router Class Initialized
INFO - 2020-11-08 15:46:19 --> Output Class Initialized
INFO - 2020-11-08 15:46:19 --> Security Class Initialized
DEBUG - 2020-11-08 15:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 15:46:19 --> Input Class Initialized
INFO - 2020-11-08 15:46:19 --> Language Class Initialized
INFO - 2020-11-08 15:46:19 --> Loader Class Initialized
INFO - 2020-11-08 15:46:19 --> Helper loaded: url_helper
INFO - 2020-11-08 15:46:19 --> Database Driver Class Initialized
INFO - 2020-11-08 15:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 15:46:19 --> Email Class Initialized
INFO - 2020-11-08 15:46:19 --> Controller Class Initialized
DEBUG - 2020-11-08 15:46:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 15:46:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 15:46:19 --> Model Class Initialized
INFO - 2020-11-08 15:46:19 --> Model Class Initialized
ERROR - 2020-11-08 15:46:19 --> Severity: Runtime Notice --> Non-static method Purlem::get_campaign_fields() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 405
ERROR - 2020-11-08 15:46:19 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 55
INFO - 2020-11-08 15:46:20 --> Final output sent to browser
DEBUG - 2020-11-08 15:46:20 --> Total execution time: 0.9705
ERROR - 2020-11-08 15:49:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 15:49:41 --> Config Class Initialized
INFO - 2020-11-08 15:49:41 --> Hooks Class Initialized
DEBUG - 2020-11-08 15:49:41 --> UTF-8 Support Enabled
INFO - 2020-11-08 15:49:41 --> Utf8 Class Initialized
INFO - 2020-11-08 15:49:41 --> URI Class Initialized
INFO - 2020-11-08 15:49:41 --> Router Class Initialized
INFO - 2020-11-08 15:49:41 --> Output Class Initialized
INFO - 2020-11-08 15:49:41 --> Security Class Initialized
DEBUG - 2020-11-08 15:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 15:49:41 --> Input Class Initialized
INFO - 2020-11-08 15:49:41 --> Language Class Initialized
INFO - 2020-11-08 15:49:41 --> Loader Class Initialized
INFO - 2020-11-08 15:49:41 --> Helper loaded: url_helper
INFO - 2020-11-08 15:49:41 --> Database Driver Class Initialized
INFO - 2020-11-08 15:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 15:49:41 --> Email Class Initialized
INFO - 2020-11-08 15:49:41 --> Controller Class Initialized
DEBUG - 2020-11-08 15:49:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 15:49:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 15:49:41 --> Model Class Initialized
INFO - 2020-11-08 15:49:41 --> Model Class Initialized
ERROR - 2020-11-08 15:49:41 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_by() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 15:49:41 --> Severity: Warning --> Missing argument 2 for Purlem::get_many_by(), called in /home/purpu1ex/public_html/carsm/application/controllers/Campain.php on line 404 and defined /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 30
ERROR - 2020-11-08 15:49:41 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 31
INFO - 2020-11-08 15:49:42 --> Final output sent to browser
DEBUG - 2020-11-08 15:49:42 --> Total execution time: 1.0466
ERROR - 2020-11-08 15:50:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 15:50:09 --> Config Class Initialized
INFO - 2020-11-08 15:50:09 --> Hooks Class Initialized
DEBUG - 2020-11-08 15:50:09 --> UTF-8 Support Enabled
INFO - 2020-11-08 15:50:09 --> Utf8 Class Initialized
INFO - 2020-11-08 15:50:09 --> URI Class Initialized
INFO - 2020-11-08 15:50:09 --> Router Class Initialized
INFO - 2020-11-08 15:50:09 --> Output Class Initialized
INFO - 2020-11-08 15:50:09 --> Security Class Initialized
DEBUG - 2020-11-08 15:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 15:50:09 --> Input Class Initialized
INFO - 2020-11-08 15:50:09 --> Language Class Initialized
INFO - 2020-11-08 15:50:09 --> Loader Class Initialized
INFO - 2020-11-08 15:50:09 --> Helper loaded: url_helper
INFO - 2020-11-08 15:50:09 --> Database Driver Class Initialized
INFO - 2020-11-08 15:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 15:50:09 --> Email Class Initialized
INFO - 2020-11-08 15:50:09 --> Controller Class Initialized
DEBUG - 2020-11-08 15:50:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 15:50:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 15:50:09 --> Model Class Initialized
INFO - 2020-11-08 15:50:09 --> Model Class Initialized
ERROR - 2020-11-08 15:50:09 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_by() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 15:50:09 --> Severity: Warning --> Missing argument 2 for Purlem::get_many_by(), called in /home/purpu1ex/public_html/carsm/application/controllers/Campain.php on line 404 and defined /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 30
ERROR - 2020-11-08 15:50:09 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 31
INFO - 2020-11-08 15:50:10 --> Final output sent to browser
DEBUG - 2020-11-08 15:50:10 --> Total execution time: 1.0455
ERROR - 2020-11-08 15:50:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 15:50:55 --> Config Class Initialized
INFO - 2020-11-08 15:50:55 --> Hooks Class Initialized
DEBUG - 2020-11-08 15:50:55 --> UTF-8 Support Enabled
INFO - 2020-11-08 15:50:55 --> Utf8 Class Initialized
INFO - 2020-11-08 15:50:55 --> URI Class Initialized
INFO - 2020-11-08 15:50:55 --> Router Class Initialized
INFO - 2020-11-08 15:50:55 --> Output Class Initialized
INFO - 2020-11-08 15:50:55 --> Security Class Initialized
DEBUG - 2020-11-08 15:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 15:50:55 --> Input Class Initialized
INFO - 2020-11-08 15:50:55 --> Language Class Initialized
INFO - 2020-11-08 15:50:55 --> Loader Class Initialized
INFO - 2020-11-08 15:50:55 --> Helper loaded: url_helper
INFO - 2020-11-08 15:50:55 --> Database Driver Class Initialized
INFO - 2020-11-08 15:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 15:50:55 --> Email Class Initialized
INFO - 2020-11-08 15:50:55 --> Controller Class Initialized
DEBUG - 2020-11-08 15:50:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 15:50:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 15:50:55 --> Model Class Initialized
INFO - 2020-11-08 15:50:55 --> Model Class Initialized
ERROR - 2020-11-08 15:50:55 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_by() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 15:50:55 --> Severity: Warning --> Missing argument 2 for Purlem::get_many_by(), called in /home/purpu1ex/public_html/carsm/application/controllers/Campain.php on line 404 and defined /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 30
ERROR - 2020-11-08 15:50:55 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 31
INFO - 2020-11-08 15:50:56 --> Final output sent to browser
DEBUG - 2020-11-08 15:50:56 --> Total execution time: 1.0299
ERROR - 2020-11-08 15:50:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 15:50:58 --> Config Class Initialized
INFO - 2020-11-08 15:50:58 --> Hooks Class Initialized
DEBUG - 2020-11-08 15:50:58 --> UTF-8 Support Enabled
INFO - 2020-11-08 15:50:58 --> Utf8 Class Initialized
INFO - 2020-11-08 15:50:58 --> URI Class Initialized
INFO - 2020-11-08 15:50:58 --> Router Class Initialized
INFO - 2020-11-08 15:50:58 --> Output Class Initialized
INFO - 2020-11-08 15:50:58 --> Security Class Initialized
DEBUG - 2020-11-08 15:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 15:50:58 --> Input Class Initialized
INFO - 2020-11-08 15:50:58 --> Language Class Initialized
INFO - 2020-11-08 15:50:58 --> Loader Class Initialized
INFO - 2020-11-08 15:50:58 --> Helper loaded: url_helper
INFO - 2020-11-08 15:50:58 --> Database Driver Class Initialized
INFO - 2020-11-08 15:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 15:50:58 --> Email Class Initialized
INFO - 2020-11-08 15:50:58 --> Controller Class Initialized
DEBUG - 2020-11-08 15:50:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 15:50:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 15:50:58 --> Model Class Initialized
INFO - 2020-11-08 15:50:58 --> Model Class Initialized
ERROR - 2020-11-08 15:50:58 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_by() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 15:50:58 --> Severity: Warning --> Missing argument 2 for Purlem::get_many_by(), called in /home/purpu1ex/public_html/carsm/application/controllers/Campain.php on line 404 and defined /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 30
ERROR - 2020-11-08 15:50:58 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 31
INFO - 2020-11-08 15:50:59 --> Final output sent to browser
DEBUG - 2020-11-08 15:50:59 --> Total execution time: 0.9832
ERROR - 2020-11-08 15:52:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 15:52:30 --> Config Class Initialized
INFO - 2020-11-08 15:52:30 --> Hooks Class Initialized
DEBUG - 2020-11-08 15:52:30 --> UTF-8 Support Enabled
INFO - 2020-11-08 15:52:30 --> Utf8 Class Initialized
INFO - 2020-11-08 15:52:30 --> URI Class Initialized
INFO - 2020-11-08 15:52:30 --> Router Class Initialized
INFO - 2020-11-08 15:52:30 --> Output Class Initialized
INFO - 2020-11-08 15:52:30 --> Security Class Initialized
DEBUG - 2020-11-08 15:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 15:52:30 --> Input Class Initialized
INFO - 2020-11-08 15:52:30 --> Language Class Initialized
INFO - 2020-11-08 15:52:30 --> Loader Class Initialized
INFO - 2020-11-08 15:52:30 --> Helper loaded: url_helper
INFO - 2020-11-08 15:52:30 --> Database Driver Class Initialized
INFO - 2020-11-08 15:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 15:52:30 --> Email Class Initialized
INFO - 2020-11-08 15:52:30 --> Controller Class Initialized
DEBUG - 2020-11-08 15:52:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 15:52:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 15:52:30 --> Model Class Initialized
INFO - 2020-11-08 15:52:30 --> Model Class Initialized
ERROR - 2020-11-08 15:52:30 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_by() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 15:52:30 --> Severity: Warning --> Missing argument 2 for Purlem::get_many_by(), called in /home/purpu1ex/public_html/carsm/application/controllers/Campain.php on line 404 and defined /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 30
ERROR - 2020-11-08 15:52:30 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 31
INFO - 2020-11-08 15:52:31 --> Final output sent to browser
DEBUG - 2020-11-08 15:52:31 --> Total execution time: 0.9604
ERROR - 2020-11-08 15:52:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 15:52:47 --> Config Class Initialized
INFO - 2020-11-08 15:52:47 --> Hooks Class Initialized
DEBUG - 2020-11-08 15:52:47 --> UTF-8 Support Enabled
INFO - 2020-11-08 15:52:47 --> Utf8 Class Initialized
INFO - 2020-11-08 15:52:47 --> URI Class Initialized
INFO - 2020-11-08 15:52:47 --> Router Class Initialized
INFO - 2020-11-08 15:52:47 --> Output Class Initialized
INFO - 2020-11-08 15:52:47 --> Security Class Initialized
DEBUG - 2020-11-08 15:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 15:52:47 --> Input Class Initialized
INFO - 2020-11-08 15:52:47 --> Language Class Initialized
INFO - 2020-11-08 15:52:47 --> Loader Class Initialized
INFO - 2020-11-08 15:52:47 --> Helper loaded: url_helper
INFO - 2020-11-08 15:52:47 --> Database Driver Class Initialized
INFO - 2020-11-08 15:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 15:52:47 --> Email Class Initialized
INFO - 2020-11-08 15:52:47 --> Controller Class Initialized
DEBUG - 2020-11-08 15:52:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 15:52:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 15:52:47 --> Model Class Initialized
INFO - 2020-11-08 15:52:47 --> Model Class Initialized
ERROR - 2020-11-08 15:52:47 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_by() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 15:52:47 --> Severity: Warning --> Missing argument 2 for Purlem::get_many_by(), called in /home/purpu1ex/public_html/carsm/application/controllers/Campain.php on line 404 and defined /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 30
ERROR - 2020-11-08 15:52:47 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 31
INFO - 2020-11-08 15:52:48 --> Final output sent to browser
DEBUG - 2020-11-08 15:52:48 --> Total execution time: 1.0001
ERROR - 2020-11-08 15:52:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 15:52:49 --> Config Class Initialized
INFO - 2020-11-08 15:52:49 --> Hooks Class Initialized
DEBUG - 2020-11-08 15:52:49 --> UTF-8 Support Enabled
INFO - 2020-11-08 15:52:49 --> Utf8 Class Initialized
INFO - 2020-11-08 15:52:49 --> URI Class Initialized
INFO - 2020-11-08 15:52:49 --> Router Class Initialized
INFO - 2020-11-08 15:52:49 --> Output Class Initialized
INFO - 2020-11-08 15:52:49 --> Security Class Initialized
DEBUG - 2020-11-08 15:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 15:52:49 --> Input Class Initialized
INFO - 2020-11-08 15:52:49 --> Language Class Initialized
INFO - 2020-11-08 15:52:49 --> Loader Class Initialized
INFO - 2020-11-08 15:52:49 --> Helper loaded: url_helper
INFO - 2020-11-08 15:52:49 --> Database Driver Class Initialized
INFO - 2020-11-08 15:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 15:52:49 --> Email Class Initialized
INFO - 2020-11-08 15:52:49 --> Controller Class Initialized
DEBUG - 2020-11-08 15:52:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 15:52:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 15:52:49 --> Model Class Initialized
INFO - 2020-11-08 15:52:49 --> Model Class Initialized
ERROR - 2020-11-08 15:52:49 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_by() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 15:52:49 --> Severity: Warning --> Missing argument 2 for Purlem::get_many_by(), called in /home/purpu1ex/public_html/carsm/application/controllers/Campain.php on line 404 and defined /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 30
ERROR - 2020-11-08 15:52:49 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 31
INFO - 2020-11-08 15:52:50 --> Final output sent to browser
DEBUG - 2020-11-08 15:52:50 --> Total execution time: 0.9266
ERROR - 2020-11-08 15:52:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 15:52:52 --> Config Class Initialized
INFO - 2020-11-08 15:52:52 --> Hooks Class Initialized
DEBUG - 2020-11-08 15:52:52 --> UTF-8 Support Enabled
INFO - 2020-11-08 15:52:52 --> Utf8 Class Initialized
INFO - 2020-11-08 15:52:52 --> URI Class Initialized
INFO - 2020-11-08 15:52:52 --> Router Class Initialized
INFO - 2020-11-08 15:52:52 --> Output Class Initialized
INFO - 2020-11-08 15:52:52 --> Security Class Initialized
DEBUG - 2020-11-08 15:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 15:52:52 --> Input Class Initialized
INFO - 2020-11-08 15:52:52 --> Language Class Initialized
INFO - 2020-11-08 15:52:52 --> Loader Class Initialized
INFO - 2020-11-08 15:52:52 --> Helper loaded: url_helper
INFO - 2020-11-08 15:52:52 --> Database Driver Class Initialized
INFO - 2020-11-08 15:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 15:52:52 --> Email Class Initialized
INFO - 2020-11-08 15:52:52 --> Controller Class Initialized
DEBUG - 2020-11-08 15:52:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 15:52:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 15:52:52 --> Model Class Initialized
INFO - 2020-11-08 15:52:52 --> Model Class Initialized
ERROR - 2020-11-08 15:52:52 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_by() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 15:52:52 --> Severity: Warning --> Missing argument 2 for Purlem::get_many_by(), called in /home/purpu1ex/public_html/carsm/application/controllers/Campain.php on line 404 and defined /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 30
ERROR - 2020-11-08 15:52:52 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 31
INFO - 2020-11-08 15:52:53 --> Final output sent to browser
DEBUG - 2020-11-08 15:52:53 --> Total execution time: 1.0125
ERROR - 2020-11-08 15:53:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 15:53:21 --> Config Class Initialized
INFO - 2020-11-08 15:53:21 --> Hooks Class Initialized
DEBUG - 2020-11-08 15:53:21 --> UTF-8 Support Enabled
INFO - 2020-11-08 15:53:21 --> Utf8 Class Initialized
INFO - 2020-11-08 15:53:21 --> URI Class Initialized
INFO - 2020-11-08 15:53:21 --> Router Class Initialized
INFO - 2020-11-08 15:53:21 --> Output Class Initialized
INFO - 2020-11-08 15:53:21 --> Security Class Initialized
DEBUG - 2020-11-08 15:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 15:53:21 --> Input Class Initialized
INFO - 2020-11-08 15:53:21 --> Language Class Initialized
INFO - 2020-11-08 15:53:21 --> Loader Class Initialized
INFO - 2020-11-08 15:53:21 --> Helper loaded: url_helper
INFO - 2020-11-08 15:53:21 --> Database Driver Class Initialized
INFO - 2020-11-08 15:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 15:53:21 --> Email Class Initialized
INFO - 2020-11-08 15:53:21 --> Controller Class Initialized
DEBUG - 2020-11-08 15:53:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 15:53:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 15:53:21 --> Model Class Initialized
INFO - 2020-11-08 15:53:21 --> Model Class Initialized
ERROR - 2020-11-08 15:53:21 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_by() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 15:53:21 --> Severity: Warning --> Missing argument 2 for Purlem::get_many_by(), called in /home/purpu1ex/public_html/carsm/application/controllers/Campain.php on line 404 and defined /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 30
ERROR - 2020-11-08 15:53:21 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 31
INFO - 2020-11-08 15:53:22 --> Final output sent to browser
DEBUG - 2020-11-08 15:53:22 --> Total execution time: 1.0181
ERROR - 2020-11-08 15:53:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 15:53:24 --> Config Class Initialized
INFO - 2020-11-08 15:53:24 --> Hooks Class Initialized
DEBUG - 2020-11-08 15:53:24 --> UTF-8 Support Enabled
INFO - 2020-11-08 15:53:24 --> Utf8 Class Initialized
INFO - 2020-11-08 15:53:24 --> URI Class Initialized
INFO - 2020-11-08 15:53:24 --> Router Class Initialized
INFO - 2020-11-08 15:53:24 --> Output Class Initialized
INFO - 2020-11-08 15:53:24 --> Security Class Initialized
DEBUG - 2020-11-08 15:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 15:53:24 --> Input Class Initialized
INFO - 2020-11-08 15:53:24 --> Language Class Initialized
INFO - 2020-11-08 15:53:24 --> Loader Class Initialized
INFO - 2020-11-08 15:53:24 --> Helper loaded: url_helper
INFO - 2020-11-08 15:53:24 --> Database Driver Class Initialized
INFO - 2020-11-08 15:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 15:53:24 --> Email Class Initialized
INFO - 2020-11-08 15:53:24 --> Controller Class Initialized
DEBUG - 2020-11-08 15:53:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 15:53:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 15:53:24 --> Model Class Initialized
INFO - 2020-11-08 15:53:24 --> Model Class Initialized
ERROR - 2020-11-08 15:53:24 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_by() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 15:53:24 --> Severity: Warning --> Missing argument 2 for Purlem::get_many_by(), called in /home/purpu1ex/public_html/carsm/application/controllers/Campain.php on line 404 and defined /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 30
ERROR - 2020-11-08 15:53:24 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 31
INFO - 2020-11-08 15:53:25 --> Final output sent to browser
DEBUG - 2020-11-08 15:53:25 --> Total execution time: 0.9530
ERROR - 2020-11-08 15:53:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 15:53:35 --> Config Class Initialized
INFO - 2020-11-08 15:53:35 --> Hooks Class Initialized
DEBUG - 2020-11-08 15:53:35 --> UTF-8 Support Enabled
INFO - 2020-11-08 15:53:35 --> Utf8 Class Initialized
INFO - 2020-11-08 15:53:35 --> URI Class Initialized
INFO - 2020-11-08 15:53:35 --> Router Class Initialized
INFO - 2020-11-08 15:53:35 --> Output Class Initialized
INFO - 2020-11-08 15:53:35 --> Security Class Initialized
DEBUG - 2020-11-08 15:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 15:53:35 --> Input Class Initialized
INFO - 2020-11-08 15:53:35 --> Language Class Initialized
INFO - 2020-11-08 15:53:35 --> Loader Class Initialized
INFO - 2020-11-08 15:53:35 --> Helper loaded: url_helper
INFO - 2020-11-08 15:53:35 --> Database Driver Class Initialized
INFO - 2020-11-08 15:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 15:53:35 --> Email Class Initialized
INFO - 2020-11-08 15:53:35 --> Controller Class Initialized
DEBUG - 2020-11-08 15:53:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 15:53:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 15:53:35 --> Model Class Initialized
INFO - 2020-11-08 15:53:35 --> Model Class Initialized
ERROR - 2020-11-08 15:53:35 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_by() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 15:53:35 --> Severity: Warning --> Missing argument 2 for Purlem::get_many_by(), called in /home/purpu1ex/public_html/carsm/application/controllers/Campain.php on line 404 and defined /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 30
ERROR - 2020-11-08 15:53:35 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 31
INFO - 2020-11-08 15:53:36 --> Final output sent to browser
DEBUG - 2020-11-08 15:53:36 --> Total execution time: 0.9531
ERROR - 2020-11-08 15:54:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 15:54:01 --> Config Class Initialized
INFO - 2020-11-08 15:54:01 --> Hooks Class Initialized
DEBUG - 2020-11-08 15:54:01 --> UTF-8 Support Enabled
INFO - 2020-11-08 15:54:01 --> Utf8 Class Initialized
INFO - 2020-11-08 15:54:01 --> URI Class Initialized
INFO - 2020-11-08 15:54:01 --> Router Class Initialized
INFO - 2020-11-08 15:54:01 --> Output Class Initialized
INFO - 2020-11-08 15:54:01 --> Security Class Initialized
DEBUG - 2020-11-08 15:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 15:54:01 --> Input Class Initialized
INFO - 2020-11-08 15:54:01 --> Language Class Initialized
INFO - 2020-11-08 15:54:01 --> Loader Class Initialized
INFO - 2020-11-08 15:54:01 --> Helper loaded: url_helper
INFO - 2020-11-08 15:54:01 --> Database Driver Class Initialized
INFO - 2020-11-08 15:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 15:54:01 --> Email Class Initialized
INFO - 2020-11-08 15:54:01 --> Controller Class Initialized
DEBUG - 2020-11-08 15:54:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 15:54:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 15:54:01 --> Model Class Initialized
INFO - 2020-11-08 15:54:01 --> Model Class Initialized
ERROR - 2020-11-08 15:54:01 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_by() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 15:54:01 --> Severity: Warning --> Missing argument 2 for Purlem::get_many_by(), called in /home/purpu1ex/public_html/carsm/application/controllers/Campain.php on line 404 and defined /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 30
ERROR - 2020-11-08 15:54:01 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 31
INFO - 2020-11-08 15:54:02 --> Final output sent to browser
DEBUG - 2020-11-08 15:54:02 --> Total execution time: 0.9681
ERROR - 2020-11-08 15:54:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 15:54:34 --> Config Class Initialized
INFO - 2020-11-08 15:54:34 --> Hooks Class Initialized
DEBUG - 2020-11-08 15:54:34 --> UTF-8 Support Enabled
INFO - 2020-11-08 15:54:34 --> Utf8 Class Initialized
INFO - 2020-11-08 15:54:34 --> URI Class Initialized
INFO - 2020-11-08 15:54:34 --> Router Class Initialized
INFO - 2020-11-08 15:54:34 --> Output Class Initialized
INFO - 2020-11-08 15:54:34 --> Security Class Initialized
DEBUG - 2020-11-08 15:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 15:54:34 --> Input Class Initialized
INFO - 2020-11-08 15:54:34 --> Language Class Initialized
INFO - 2020-11-08 15:54:34 --> Loader Class Initialized
INFO - 2020-11-08 15:54:34 --> Helper loaded: url_helper
INFO - 2020-11-08 15:54:34 --> Database Driver Class Initialized
INFO - 2020-11-08 15:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 15:54:34 --> Email Class Initialized
INFO - 2020-11-08 15:54:34 --> Controller Class Initialized
DEBUG - 2020-11-08 15:54:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 15:54:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 15:54:34 --> Model Class Initialized
INFO - 2020-11-08 15:54:34 --> Model Class Initialized
ERROR - 2020-11-08 15:54:34 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_by() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 15:54:34 --> Severity: Warning --> Missing argument 2 for Purlem::get_many_by(), called in /home/purpu1ex/public_html/carsm/application/controllers/Campain.php on line 404 and defined /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 30
ERROR - 2020-11-08 15:54:34 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 31
INFO - 2020-11-08 15:54:35 --> Final output sent to browser
DEBUG - 2020-11-08 15:54:35 --> Total execution time: 1.0686
ERROR - 2020-11-08 15:54:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 15:54:37 --> Config Class Initialized
INFO - 2020-11-08 15:54:37 --> Hooks Class Initialized
DEBUG - 2020-11-08 15:54:37 --> UTF-8 Support Enabled
INFO - 2020-11-08 15:54:37 --> Utf8 Class Initialized
INFO - 2020-11-08 15:54:37 --> URI Class Initialized
INFO - 2020-11-08 15:54:37 --> Router Class Initialized
INFO - 2020-11-08 15:54:37 --> Output Class Initialized
INFO - 2020-11-08 15:54:37 --> Security Class Initialized
DEBUG - 2020-11-08 15:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 15:54:37 --> Input Class Initialized
INFO - 2020-11-08 15:54:37 --> Language Class Initialized
INFO - 2020-11-08 15:54:37 --> Loader Class Initialized
INFO - 2020-11-08 15:54:37 --> Helper loaded: url_helper
INFO - 2020-11-08 15:54:37 --> Database Driver Class Initialized
INFO - 2020-11-08 15:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 15:54:37 --> Email Class Initialized
INFO - 2020-11-08 15:54:37 --> Controller Class Initialized
DEBUG - 2020-11-08 15:54:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 15:54:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 15:54:37 --> Model Class Initialized
INFO - 2020-11-08 15:54:37 --> Model Class Initialized
ERROR - 2020-11-08 15:54:37 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_by() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 15:54:37 --> Severity: Warning --> Missing argument 2 for Purlem::get_many_by(), called in /home/purpu1ex/public_html/carsm/application/controllers/Campain.php on line 404 and defined /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 30
ERROR - 2020-11-08 15:54:37 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 31
INFO - 2020-11-08 15:54:38 --> Final output sent to browser
DEBUG - 2020-11-08 15:54:38 --> Total execution time: 0.9354
ERROR - 2020-11-08 15:55:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 15:55:51 --> Config Class Initialized
INFO - 2020-11-08 15:55:51 --> Hooks Class Initialized
DEBUG - 2020-11-08 15:55:51 --> UTF-8 Support Enabled
INFO - 2020-11-08 15:55:51 --> Utf8 Class Initialized
INFO - 2020-11-08 15:55:51 --> URI Class Initialized
INFO - 2020-11-08 15:55:51 --> Router Class Initialized
INFO - 2020-11-08 15:55:51 --> Output Class Initialized
INFO - 2020-11-08 15:55:51 --> Security Class Initialized
DEBUG - 2020-11-08 15:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 15:55:51 --> Input Class Initialized
INFO - 2020-11-08 15:55:51 --> Language Class Initialized
INFO - 2020-11-08 15:55:51 --> Loader Class Initialized
INFO - 2020-11-08 15:55:51 --> Helper loaded: url_helper
INFO - 2020-11-08 15:55:51 --> Database Driver Class Initialized
INFO - 2020-11-08 15:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 15:55:51 --> Email Class Initialized
INFO - 2020-11-08 15:55:51 --> Controller Class Initialized
DEBUG - 2020-11-08 15:55:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 15:55:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 15:55:51 --> Model Class Initialized
INFO - 2020-11-08 15:55:51 --> Model Class Initialized
ERROR - 2020-11-08 15:55:51 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_by() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 15:55:51 --> Severity: Warning --> Missing argument 2 for Purlem::get_many_by(), called in /home/purpu1ex/public_html/carsm/application/controllers/Campain.php on line 404 and defined /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 30
ERROR - 2020-11-08 15:55:51 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 31
INFO - 2020-11-08 15:55:52 --> Final output sent to browser
DEBUG - 2020-11-08 15:55:52 --> Total execution time: 0.9957
ERROR - 2020-11-08 15:55:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 15:55:54 --> Config Class Initialized
INFO - 2020-11-08 15:55:54 --> Hooks Class Initialized
DEBUG - 2020-11-08 15:55:54 --> UTF-8 Support Enabled
INFO - 2020-11-08 15:55:54 --> Utf8 Class Initialized
INFO - 2020-11-08 15:55:54 --> URI Class Initialized
INFO - 2020-11-08 15:55:54 --> Router Class Initialized
INFO - 2020-11-08 15:55:54 --> Output Class Initialized
INFO - 2020-11-08 15:55:54 --> Security Class Initialized
DEBUG - 2020-11-08 15:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 15:55:54 --> Input Class Initialized
INFO - 2020-11-08 15:55:54 --> Language Class Initialized
INFO - 2020-11-08 15:55:54 --> Loader Class Initialized
INFO - 2020-11-08 15:55:54 --> Helper loaded: url_helper
INFO - 2020-11-08 15:55:54 --> Database Driver Class Initialized
INFO - 2020-11-08 15:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 15:55:54 --> Email Class Initialized
INFO - 2020-11-08 15:55:54 --> Controller Class Initialized
DEBUG - 2020-11-08 15:55:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 15:55:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 15:55:54 --> Model Class Initialized
INFO - 2020-11-08 15:55:54 --> Model Class Initialized
ERROR - 2020-11-08 15:55:54 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_by() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 15:55:54 --> Severity: Warning --> Missing argument 2 for Purlem::get_many_by(), called in /home/purpu1ex/public_html/carsm/application/controllers/Campain.php on line 404 and defined /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 30
ERROR - 2020-11-08 15:55:54 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 31
INFO - 2020-11-08 15:55:55 --> Final output sent to browser
DEBUG - 2020-11-08 15:55:55 --> Total execution time: 1.0034
ERROR - 2020-11-08 15:56:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 15:56:34 --> Config Class Initialized
INFO - 2020-11-08 15:56:34 --> Hooks Class Initialized
DEBUG - 2020-11-08 15:56:34 --> UTF-8 Support Enabled
INFO - 2020-11-08 15:56:34 --> Utf8 Class Initialized
INFO - 2020-11-08 15:56:34 --> URI Class Initialized
INFO - 2020-11-08 15:56:34 --> Router Class Initialized
INFO - 2020-11-08 15:56:34 --> Output Class Initialized
INFO - 2020-11-08 15:56:34 --> Security Class Initialized
DEBUG - 2020-11-08 15:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 15:56:34 --> Input Class Initialized
INFO - 2020-11-08 15:56:34 --> Language Class Initialized
INFO - 2020-11-08 15:56:34 --> Loader Class Initialized
INFO - 2020-11-08 15:56:34 --> Helper loaded: url_helper
INFO - 2020-11-08 15:56:34 --> Database Driver Class Initialized
INFO - 2020-11-08 15:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 15:56:34 --> Email Class Initialized
INFO - 2020-11-08 15:56:34 --> Controller Class Initialized
DEBUG - 2020-11-08 15:56:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 15:56:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 15:56:34 --> Model Class Initialized
INFO - 2020-11-08 15:56:34 --> Model Class Initialized
ERROR - 2020-11-08 15:56:34 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_by() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 15:56:34 --> Severity: Warning --> Missing argument 2 for Purlem::get_many_by(), called in /home/purpu1ex/public_html/carsm/application/controllers/Campain.php on line 404 and defined /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 30
ERROR - 2020-11-08 15:56:34 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 31
INFO - 2020-11-08 15:56:35 --> Final output sent to browser
DEBUG - 2020-11-08 15:56:35 --> Total execution time: 0.9135
ERROR - 2020-11-08 15:57:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 15:57:13 --> Config Class Initialized
INFO - 2020-11-08 15:57:13 --> Hooks Class Initialized
DEBUG - 2020-11-08 15:57:13 --> UTF-8 Support Enabled
INFO - 2020-11-08 15:57:13 --> Utf8 Class Initialized
INFO - 2020-11-08 15:57:13 --> URI Class Initialized
INFO - 2020-11-08 15:57:13 --> Router Class Initialized
INFO - 2020-11-08 15:57:13 --> Output Class Initialized
INFO - 2020-11-08 15:57:13 --> Security Class Initialized
DEBUG - 2020-11-08 15:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 15:57:13 --> Input Class Initialized
INFO - 2020-11-08 15:57:13 --> Language Class Initialized
INFO - 2020-11-08 15:57:13 --> Loader Class Initialized
INFO - 2020-11-08 15:57:13 --> Helper loaded: url_helper
INFO - 2020-11-08 15:57:13 --> Database Driver Class Initialized
INFO - 2020-11-08 15:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 15:57:13 --> Email Class Initialized
INFO - 2020-11-08 15:57:13 --> Controller Class Initialized
DEBUG - 2020-11-08 15:57:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 15:57:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 15:57:13 --> Model Class Initialized
INFO - 2020-11-08 15:57:13 --> Model Class Initialized
ERROR - 2020-11-08 15:57:13 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_by() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 15:57:13 --> Severity: Warning --> Missing argument 2 for Purlem::get_many_by(), called in /home/purpu1ex/public_html/carsm/application/controllers/Campain.php on line 404 and defined /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 30
ERROR - 2020-11-08 15:57:13 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 31
INFO - 2020-11-08 15:57:14 --> Final output sent to browser
DEBUG - 2020-11-08 15:57:14 --> Total execution time: 1.0160
ERROR - 2020-11-08 15:58:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 15:58:00 --> Config Class Initialized
INFO - 2020-11-08 15:58:00 --> Hooks Class Initialized
DEBUG - 2020-11-08 15:58:00 --> UTF-8 Support Enabled
INFO - 2020-11-08 15:58:00 --> Utf8 Class Initialized
INFO - 2020-11-08 15:58:00 --> URI Class Initialized
INFO - 2020-11-08 15:58:00 --> Router Class Initialized
INFO - 2020-11-08 15:58:00 --> Output Class Initialized
INFO - 2020-11-08 15:58:00 --> Security Class Initialized
DEBUG - 2020-11-08 15:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 15:58:00 --> Input Class Initialized
INFO - 2020-11-08 15:58:00 --> Language Class Initialized
INFO - 2020-11-08 15:58:00 --> Loader Class Initialized
INFO - 2020-11-08 15:58:00 --> Helper loaded: url_helper
INFO - 2020-11-08 15:58:00 --> Database Driver Class Initialized
INFO - 2020-11-08 15:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 15:58:00 --> Email Class Initialized
INFO - 2020-11-08 15:58:00 --> Controller Class Initialized
DEBUG - 2020-11-08 15:58:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 15:58:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 15:58:00 --> Model Class Initialized
INFO - 2020-11-08 15:58:00 --> Model Class Initialized
ERROR - 2020-11-08 15:58:00 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_by() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 15:58:00 --> Severity: Warning --> Missing argument 2 for Purlem::get_many_by(), called in /home/purpu1ex/public_html/carsm/application/controllers/Campain.php on line 404 and defined /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 30
ERROR - 2020-11-08 15:58:00 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 31
INFO - 2020-11-08 15:58:01 --> Final output sent to browser
DEBUG - 2020-11-08 15:58:01 --> Total execution time: 1.0638
ERROR - 2020-11-08 15:58:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 15:58:38 --> Config Class Initialized
INFO - 2020-11-08 15:58:38 --> Hooks Class Initialized
DEBUG - 2020-11-08 15:58:38 --> UTF-8 Support Enabled
INFO - 2020-11-08 15:58:38 --> Utf8 Class Initialized
INFO - 2020-11-08 15:58:38 --> URI Class Initialized
INFO - 2020-11-08 15:58:38 --> Router Class Initialized
INFO - 2020-11-08 15:58:38 --> Output Class Initialized
INFO - 2020-11-08 15:58:38 --> Security Class Initialized
DEBUG - 2020-11-08 15:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 15:58:38 --> Input Class Initialized
INFO - 2020-11-08 15:58:38 --> Language Class Initialized
INFO - 2020-11-08 15:58:38 --> Loader Class Initialized
INFO - 2020-11-08 15:58:38 --> Helper loaded: url_helper
INFO - 2020-11-08 15:58:38 --> Database Driver Class Initialized
INFO - 2020-11-08 15:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 15:58:38 --> Email Class Initialized
INFO - 2020-11-08 15:58:38 --> Controller Class Initialized
DEBUG - 2020-11-08 15:58:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 15:58:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 15:58:38 --> Model Class Initialized
INFO - 2020-11-08 15:58:38 --> Model Class Initialized
ERROR - 2020-11-08 15:58:38 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_by() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 15:58:38 --> Severity: Warning --> Missing argument 2 for Purlem::get_many_by(), called in /home/purpu1ex/public_html/carsm/application/controllers/Campain.php on line 404 and defined /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 30
ERROR - 2020-11-08 15:58:38 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 31
INFO - 2020-11-08 15:58:39 --> Final output sent to browser
DEBUG - 2020-11-08 15:58:39 --> Total execution time: 1.0346
ERROR - 2020-11-08 15:58:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 15:58:41 --> Config Class Initialized
INFO - 2020-11-08 15:58:41 --> Hooks Class Initialized
DEBUG - 2020-11-08 15:58:41 --> UTF-8 Support Enabled
INFO - 2020-11-08 15:58:41 --> Utf8 Class Initialized
INFO - 2020-11-08 15:58:41 --> URI Class Initialized
INFO - 2020-11-08 15:58:41 --> Router Class Initialized
INFO - 2020-11-08 15:58:41 --> Output Class Initialized
INFO - 2020-11-08 15:58:41 --> Security Class Initialized
DEBUG - 2020-11-08 15:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 15:58:41 --> Input Class Initialized
INFO - 2020-11-08 15:58:41 --> Language Class Initialized
INFO - 2020-11-08 15:58:41 --> Loader Class Initialized
INFO - 2020-11-08 15:58:41 --> Helper loaded: url_helper
INFO - 2020-11-08 15:58:41 --> Database Driver Class Initialized
INFO - 2020-11-08 15:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 15:58:41 --> Email Class Initialized
INFO - 2020-11-08 15:58:41 --> Controller Class Initialized
DEBUG - 2020-11-08 15:58:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 15:58:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 15:58:41 --> Model Class Initialized
INFO - 2020-11-08 15:58:41 --> Model Class Initialized
ERROR - 2020-11-08 15:58:41 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_by() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 15:58:41 --> Severity: Warning --> Missing argument 2 for Purlem::get_many_by(), called in /home/purpu1ex/public_html/carsm/application/controllers/Campain.php on line 404 and defined /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 30
ERROR - 2020-11-08 15:58:41 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 31
INFO - 2020-11-08 15:58:42 --> Final output sent to browser
DEBUG - 2020-11-08 15:58:42 --> Total execution time: 0.9400
ERROR - 2020-11-08 15:59:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 15:59:34 --> Config Class Initialized
INFO - 2020-11-08 15:59:34 --> Hooks Class Initialized
DEBUG - 2020-11-08 15:59:34 --> UTF-8 Support Enabled
INFO - 2020-11-08 15:59:34 --> Utf8 Class Initialized
INFO - 2020-11-08 15:59:34 --> URI Class Initialized
INFO - 2020-11-08 15:59:34 --> Router Class Initialized
INFO - 2020-11-08 15:59:34 --> Output Class Initialized
INFO - 2020-11-08 15:59:34 --> Security Class Initialized
DEBUG - 2020-11-08 15:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 15:59:34 --> Input Class Initialized
INFO - 2020-11-08 15:59:34 --> Language Class Initialized
INFO - 2020-11-08 15:59:34 --> Loader Class Initialized
INFO - 2020-11-08 15:59:34 --> Helper loaded: url_helper
INFO - 2020-11-08 15:59:34 --> Database Driver Class Initialized
INFO - 2020-11-08 15:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 15:59:34 --> Email Class Initialized
INFO - 2020-11-08 15:59:34 --> Controller Class Initialized
DEBUG - 2020-11-08 15:59:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 15:59:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 15:59:34 --> Model Class Initialized
INFO - 2020-11-08 15:59:34 --> Model Class Initialized
ERROR - 2020-11-08 15:59:34 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_by() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 15:59:34 --> Severity: Warning --> Missing argument 2 for Purlem::get_many_by(), called in /home/purpu1ex/public_html/carsm/application/controllers/Campain.php on line 404 and defined /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 30
ERROR - 2020-11-08 15:59:34 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 31
INFO - 2020-11-08 15:59:35 --> Final output sent to browser
DEBUG - 2020-11-08 15:59:35 --> Total execution time: 0.9571
ERROR - 2020-11-08 15:59:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 15:59:37 --> Config Class Initialized
INFO - 2020-11-08 15:59:37 --> Hooks Class Initialized
DEBUG - 2020-11-08 15:59:37 --> UTF-8 Support Enabled
INFO - 2020-11-08 15:59:37 --> Utf8 Class Initialized
INFO - 2020-11-08 15:59:37 --> URI Class Initialized
INFO - 2020-11-08 15:59:37 --> Router Class Initialized
INFO - 2020-11-08 15:59:37 --> Output Class Initialized
INFO - 2020-11-08 15:59:37 --> Security Class Initialized
DEBUG - 2020-11-08 15:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 15:59:37 --> Input Class Initialized
INFO - 2020-11-08 15:59:37 --> Language Class Initialized
INFO - 2020-11-08 15:59:37 --> Loader Class Initialized
INFO - 2020-11-08 15:59:37 --> Helper loaded: url_helper
INFO - 2020-11-08 15:59:37 --> Database Driver Class Initialized
INFO - 2020-11-08 15:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 15:59:37 --> Email Class Initialized
INFO - 2020-11-08 15:59:37 --> Controller Class Initialized
DEBUG - 2020-11-08 15:59:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 15:59:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 15:59:37 --> Model Class Initialized
INFO - 2020-11-08 15:59:37 --> Model Class Initialized
ERROR - 2020-11-08 15:59:37 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_by() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 15:59:37 --> Severity: Warning --> Missing argument 2 for Purlem::get_many_by(), called in /home/purpu1ex/public_html/carsm/application/controllers/Campain.php on line 404 and defined /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 30
ERROR - 2020-11-08 15:59:37 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 31
INFO - 2020-11-08 15:59:38 --> Final output sent to browser
DEBUG - 2020-11-08 15:59:38 --> Total execution time: 1.0433
ERROR - 2020-11-08 16:40:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 16:40:54 --> Config Class Initialized
INFO - 2020-11-08 16:40:54 --> Hooks Class Initialized
DEBUG - 2020-11-08 16:40:54 --> UTF-8 Support Enabled
INFO - 2020-11-08 16:40:54 --> Utf8 Class Initialized
INFO - 2020-11-08 16:40:54 --> URI Class Initialized
INFO - 2020-11-08 16:40:54 --> Router Class Initialized
INFO - 2020-11-08 16:40:54 --> Output Class Initialized
INFO - 2020-11-08 16:40:54 --> Security Class Initialized
DEBUG - 2020-11-08 16:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 16:40:54 --> Input Class Initialized
INFO - 2020-11-08 16:40:54 --> Language Class Initialized
INFO - 2020-11-08 16:40:54 --> Loader Class Initialized
INFO - 2020-11-08 16:40:54 --> Helper loaded: url_helper
INFO - 2020-11-08 16:40:54 --> Database Driver Class Initialized
INFO - 2020-11-08 16:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 16:40:54 --> Email Class Initialized
INFO - 2020-11-08 16:40:54 --> Controller Class Initialized
DEBUG - 2020-11-08 16:40:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 16:40:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 16:40:54 --> Model Class Initialized
INFO - 2020-11-08 16:40:54 --> Model Class Initialized
ERROR - 2020-11-08 16:40:54 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_by() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 16:40:54 --> Severity: Warning --> Missing argument 2 for Purlem::get_many_by(), called in /home/purpu1ex/public_html/carsm/application/controllers/Campain.php on line 404 and defined /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 30
ERROR - 2020-11-08 16:40:54 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 31
INFO - 2020-11-08 16:40:55 --> Final output sent to browser
DEBUG - 2020-11-08 16:40:55 --> Total execution time: 1.2847
ERROR - 2020-11-08 16:40:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 16:40:57 --> Config Class Initialized
INFO - 2020-11-08 16:40:57 --> Hooks Class Initialized
DEBUG - 2020-11-08 16:40:57 --> UTF-8 Support Enabled
INFO - 2020-11-08 16:40:57 --> Utf8 Class Initialized
INFO - 2020-11-08 16:40:57 --> URI Class Initialized
INFO - 2020-11-08 16:40:57 --> Router Class Initialized
INFO - 2020-11-08 16:40:57 --> Output Class Initialized
INFO - 2020-11-08 16:40:57 --> Security Class Initialized
DEBUG - 2020-11-08 16:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 16:40:57 --> Input Class Initialized
INFO - 2020-11-08 16:40:57 --> Language Class Initialized
INFO - 2020-11-08 16:40:58 --> Loader Class Initialized
INFO - 2020-11-08 16:40:58 --> Helper loaded: url_helper
INFO - 2020-11-08 16:40:58 --> Database Driver Class Initialized
INFO - 2020-11-08 16:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 16:40:58 --> Email Class Initialized
INFO - 2020-11-08 16:40:58 --> Controller Class Initialized
DEBUG - 2020-11-08 16:40:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 16:40:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 16:40:58 --> Model Class Initialized
INFO - 2020-11-08 16:40:58 --> Model Class Initialized
ERROR - 2020-11-08 16:40:58 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_by() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 16:40:58 --> Severity: Warning --> Missing argument 2 for Purlem::get_many_by(), called in /home/purpu1ex/public_html/carsm/application/controllers/Campain.php on line 404 and defined /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 30
ERROR - 2020-11-08 16:40:58 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 31
INFO - 2020-11-08 16:40:58 --> Final output sent to browser
DEBUG - 2020-11-08 16:40:58 --> Total execution time: 0.9316
ERROR - 2020-11-08 16:43:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 16:43:31 --> Config Class Initialized
INFO - 2020-11-08 16:43:31 --> Hooks Class Initialized
DEBUG - 2020-11-08 16:43:31 --> UTF-8 Support Enabled
INFO - 2020-11-08 16:43:31 --> Utf8 Class Initialized
INFO - 2020-11-08 16:43:31 --> URI Class Initialized
INFO - 2020-11-08 16:43:31 --> Router Class Initialized
INFO - 2020-11-08 16:43:31 --> Output Class Initialized
INFO - 2020-11-08 16:43:31 --> Security Class Initialized
DEBUG - 2020-11-08 16:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 16:43:31 --> Input Class Initialized
INFO - 2020-11-08 16:43:31 --> Language Class Initialized
INFO - 2020-11-08 16:43:31 --> Loader Class Initialized
INFO - 2020-11-08 16:43:31 --> Helper loaded: url_helper
INFO - 2020-11-08 16:43:31 --> Database Driver Class Initialized
INFO - 2020-11-08 16:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 16:43:31 --> Email Class Initialized
INFO - 2020-11-08 16:43:31 --> Controller Class Initialized
DEBUG - 2020-11-08 16:43:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 16:43:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 16:43:31 --> Model Class Initialized
INFO - 2020-11-08 16:43:31 --> Model Class Initialized
ERROR - 2020-11-08 16:43:31 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_where_exists() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 16:43:31 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 27
INFO - 2020-11-08 16:43:32 --> Final output sent to browser
DEBUG - 2020-11-08 16:43:32 --> Total execution time: 1.0131
ERROR - 2020-11-08 16:43:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 16:43:53 --> Config Class Initialized
INFO - 2020-11-08 16:43:53 --> Hooks Class Initialized
DEBUG - 2020-11-08 16:43:53 --> UTF-8 Support Enabled
INFO - 2020-11-08 16:43:53 --> Utf8 Class Initialized
INFO - 2020-11-08 16:43:53 --> URI Class Initialized
INFO - 2020-11-08 16:43:53 --> Router Class Initialized
INFO - 2020-11-08 16:43:53 --> Output Class Initialized
INFO - 2020-11-08 16:43:53 --> Security Class Initialized
DEBUG - 2020-11-08 16:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 16:43:53 --> Input Class Initialized
INFO - 2020-11-08 16:43:53 --> Language Class Initialized
INFO - 2020-11-08 16:43:53 --> Loader Class Initialized
INFO - 2020-11-08 16:43:53 --> Helper loaded: url_helper
INFO - 2020-11-08 16:43:53 --> Database Driver Class Initialized
INFO - 2020-11-08 16:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 16:43:53 --> Email Class Initialized
INFO - 2020-11-08 16:43:53 --> Controller Class Initialized
DEBUG - 2020-11-08 16:43:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 16:43:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 16:43:53 --> Model Class Initialized
INFO - 2020-11-08 16:43:53 --> Model Class Initialized
ERROR - 2020-11-08 16:43:53 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_where_exists() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 16:43:53 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 27
INFO - 2020-11-08 16:43:54 --> Final output sent to browser
DEBUG - 2020-11-08 16:43:54 --> Total execution time: 0.9700
ERROR - 2020-11-08 16:43:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 16:43:57 --> Config Class Initialized
INFO - 2020-11-08 16:43:57 --> Hooks Class Initialized
DEBUG - 2020-11-08 16:43:57 --> UTF-8 Support Enabled
INFO - 2020-11-08 16:43:57 --> Utf8 Class Initialized
INFO - 2020-11-08 16:43:57 --> URI Class Initialized
INFO - 2020-11-08 16:43:57 --> Router Class Initialized
INFO - 2020-11-08 16:43:57 --> Output Class Initialized
INFO - 2020-11-08 16:43:57 --> Security Class Initialized
DEBUG - 2020-11-08 16:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 16:43:57 --> Input Class Initialized
INFO - 2020-11-08 16:43:57 --> Language Class Initialized
INFO - 2020-11-08 16:43:57 --> Loader Class Initialized
INFO - 2020-11-08 16:43:57 --> Helper loaded: url_helper
INFO - 2020-11-08 16:43:57 --> Database Driver Class Initialized
INFO - 2020-11-08 16:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 16:43:57 --> Email Class Initialized
INFO - 2020-11-08 16:43:57 --> Controller Class Initialized
DEBUG - 2020-11-08 16:43:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 16:43:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 16:43:57 --> Model Class Initialized
INFO - 2020-11-08 16:43:57 --> Model Class Initialized
ERROR - 2020-11-08 16:43:57 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_where_exists() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 16:43:57 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 27
INFO - 2020-11-08 16:43:58 --> Final output sent to browser
DEBUG - 2020-11-08 16:43:58 --> Total execution time: 0.9528
ERROR - 2020-11-08 16:45:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 16:45:23 --> Config Class Initialized
INFO - 2020-11-08 16:45:23 --> Hooks Class Initialized
DEBUG - 2020-11-08 16:45:23 --> UTF-8 Support Enabled
INFO - 2020-11-08 16:45:23 --> Utf8 Class Initialized
INFO - 2020-11-08 16:45:23 --> URI Class Initialized
INFO - 2020-11-08 16:45:23 --> Router Class Initialized
INFO - 2020-11-08 16:45:23 --> Output Class Initialized
INFO - 2020-11-08 16:45:23 --> Security Class Initialized
DEBUG - 2020-11-08 16:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 16:45:23 --> Input Class Initialized
INFO - 2020-11-08 16:45:23 --> Language Class Initialized
INFO - 2020-11-08 16:45:23 --> Loader Class Initialized
INFO - 2020-11-08 16:45:23 --> Helper loaded: url_helper
INFO - 2020-11-08 16:45:23 --> Database Driver Class Initialized
INFO - 2020-11-08 16:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 16:45:23 --> Email Class Initialized
INFO - 2020-11-08 16:45:23 --> Controller Class Initialized
DEBUG - 2020-11-08 16:45:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 16:45:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 16:45:23 --> Model Class Initialized
INFO - 2020-11-08 16:45:23 --> Model Class Initialized
ERROR - 2020-11-08 16:45:23 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_where_exists() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 16:45:23 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 27
INFO - 2020-11-08 16:45:24 --> Final output sent to browser
DEBUG - 2020-11-08 16:45:24 --> Total execution time: 0.9066
ERROR - 2020-11-08 16:46:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 16:46:33 --> Config Class Initialized
INFO - 2020-11-08 16:46:33 --> Hooks Class Initialized
DEBUG - 2020-11-08 16:46:33 --> UTF-8 Support Enabled
INFO - 2020-11-08 16:46:33 --> Utf8 Class Initialized
INFO - 2020-11-08 16:46:33 --> URI Class Initialized
INFO - 2020-11-08 16:46:33 --> Router Class Initialized
INFO - 2020-11-08 16:46:33 --> Output Class Initialized
INFO - 2020-11-08 16:46:33 --> Security Class Initialized
DEBUG - 2020-11-08 16:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 16:46:33 --> Input Class Initialized
INFO - 2020-11-08 16:46:33 --> Language Class Initialized
INFO - 2020-11-08 16:46:33 --> Loader Class Initialized
INFO - 2020-11-08 16:46:33 --> Helper loaded: url_helper
INFO - 2020-11-08 16:46:33 --> Database Driver Class Initialized
INFO - 2020-11-08 16:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 16:46:33 --> Email Class Initialized
INFO - 2020-11-08 16:46:33 --> Controller Class Initialized
DEBUG - 2020-11-08 16:46:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 16:46:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 16:46:33 --> Model Class Initialized
INFO - 2020-11-08 16:46:33 --> Model Class Initialized
ERROR - 2020-11-08 16:46:33 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_where_exists() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 16:46:33 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 27
INFO - 2020-11-08 16:46:34 --> Final output sent to browser
DEBUG - 2020-11-08 16:46:34 --> Total execution time: 1.0047
ERROR - 2020-11-08 16:46:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 16:46:38 --> Config Class Initialized
INFO - 2020-11-08 16:46:38 --> Hooks Class Initialized
DEBUG - 2020-11-08 16:46:38 --> UTF-8 Support Enabled
INFO - 2020-11-08 16:46:38 --> Utf8 Class Initialized
INFO - 2020-11-08 16:46:38 --> URI Class Initialized
INFO - 2020-11-08 16:46:38 --> Router Class Initialized
INFO - 2020-11-08 16:46:38 --> Output Class Initialized
INFO - 2020-11-08 16:46:38 --> Security Class Initialized
DEBUG - 2020-11-08 16:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 16:46:38 --> Input Class Initialized
INFO - 2020-11-08 16:46:38 --> Language Class Initialized
INFO - 2020-11-08 16:46:38 --> Loader Class Initialized
INFO - 2020-11-08 16:46:38 --> Helper loaded: url_helper
INFO - 2020-11-08 16:46:38 --> Database Driver Class Initialized
INFO - 2020-11-08 16:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 16:46:38 --> Email Class Initialized
INFO - 2020-11-08 16:46:38 --> Controller Class Initialized
DEBUG - 2020-11-08 16:46:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 16:46:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 16:46:38 --> Model Class Initialized
INFO - 2020-11-08 16:46:38 --> Model Class Initialized
ERROR - 2020-11-08 16:46:38 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_where_exists() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 16:46:38 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 27
INFO - 2020-11-08 16:46:39 --> Final output sent to browser
DEBUG - 2020-11-08 16:46:39 --> Total execution time: 0.9404
ERROR - 2020-11-08 16:47:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 16:47:16 --> Config Class Initialized
INFO - 2020-11-08 16:47:16 --> Hooks Class Initialized
DEBUG - 2020-11-08 16:47:16 --> UTF-8 Support Enabled
INFO - 2020-11-08 16:47:16 --> Utf8 Class Initialized
INFO - 2020-11-08 16:47:16 --> URI Class Initialized
INFO - 2020-11-08 16:47:16 --> Router Class Initialized
INFO - 2020-11-08 16:47:16 --> Output Class Initialized
INFO - 2020-11-08 16:47:16 --> Security Class Initialized
DEBUG - 2020-11-08 16:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 16:47:16 --> Input Class Initialized
INFO - 2020-11-08 16:47:16 --> Language Class Initialized
INFO - 2020-11-08 16:47:16 --> Loader Class Initialized
INFO - 2020-11-08 16:47:16 --> Helper loaded: url_helper
INFO - 2020-11-08 16:47:16 --> Database Driver Class Initialized
INFO - 2020-11-08 16:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 16:47:16 --> Email Class Initialized
INFO - 2020-11-08 16:47:16 --> Controller Class Initialized
DEBUG - 2020-11-08 16:47:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 16:47:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 16:47:16 --> Model Class Initialized
INFO - 2020-11-08 16:47:16 --> Model Class Initialized
ERROR - 2020-11-08 16:47:16 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_where_exists() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 16:47:16 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 27
INFO - 2020-11-08 16:47:17 --> Final output sent to browser
DEBUG - 2020-11-08 16:47:17 --> Total execution time: 1.4881
ERROR - 2020-11-08 16:49:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 16:49:54 --> Config Class Initialized
INFO - 2020-11-08 16:49:54 --> Hooks Class Initialized
DEBUG - 2020-11-08 16:49:54 --> UTF-8 Support Enabled
INFO - 2020-11-08 16:49:54 --> Utf8 Class Initialized
INFO - 2020-11-08 16:49:54 --> URI Class Initialized
INFO - 2020-11-08 16:49:54 --> Router Class Initialized
INFO - 2020-11-08 16:49:54 --> Output Class Initialized
INFO - 2020-11-08 16:49:54 --> Security Class Initialized
DEBUG - 2020-11-08 16:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 16:49:54 --> Input Class Initialized
INFO - 2020-11-08 16:49:54 --> Language Class Initialized
INFO - 2020-11-08 16:49:54 --> Loader Class Initialized
INFO - 2020-11-08 16:49:54 --> Helper loaded: url_helper
INFO - 2020-11-08 16:49:54 --> Database Driver Class Initialized
INFO - 2020-11-08 16:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 16:49:54 --> Email Class Initialized
INFO - 2020-11-08 16:49:54 --> Controller Class Initialized
DEBUG - 2020-11-08 16:49:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 16:49:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 16:49:54 --> Model Class Initialized
INFO - 2020-11-08 16:49:54 --> Model Class Initialized
ERROR - 2020-11-08 16:49:54 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_where_exists() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 16:49:54 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 27
INFO - 2020-11-08 16:49:55 --> Final output sent to browser
DEBUG - 2020-11-08 16:49:55 --> Total execution time: 1.4166
ERROR - 2020-11-08 16:49:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 16:49:59 --> Config Class Initialized
INFO - 2020-11-08 16:49:59 --> Hooks Class Initialized
DEBUG - 2020-11-08 16:49:59 --> UTF-8 Support Enabled
INFO - 2020-11-08 16:49:59 --> Utf8 Class Initialized
INFO - 2020-11-08 16:49:59 --> URI Class Initialized
INFO - 2020-11-08 16:49:59 --> Router Class Initialized
INFO - 2020-11-08 16:49:59 --> Output Class Initialized
INFO - 2020-11-08 16:49:59 --> Security Class Initialized
DEBUG - 2020-11-08 16:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 16:49:59 --> Input Class Initialized
INFO - 2020-11-08 16:49:59 --> Language Class Initialized
INFO - 2020-11-08 16:49:59 --> Loader Class Initialized
INFO - 2020-11-08 16:49:59 --> Helper loaded: url_helper
INFO - 2020-11-08 16:49:59 --> Database Driver Class Initialized
INFO - 2020-11-08 16:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 16:49:59 --> Email Class Initialized
INFO - 2020-11-08 16:49:59 --> Controller Class Initialized
DEBUG - 2020-11-08 16:49:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 16:49:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 16:49:59 --> Model Class Initialized
INFO - 2020-11-08 16:49:59 --> Model Class Initialized
ERROR - 2020-11-08 16:49:59 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_where_exists() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 16:49:59 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 27
INFO - 2020-11-08 16:50:00 --> Final output sent to browser
DEBUG - 2020-11-08 16:50:00 --> Total execution time: 0.9838
ERROR - 2020-11-08 16:50:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 16:50:26 --> Config Class Initialized
INFO - 2020-11-08 16:50:26 --> Hooks Class Initialized
DEBUG - 2020-11-08 16:50:26 --> UTF-8 Support Enabled
INFO - 2020-11-08 16:50:26 --> Utf8 Class Initialized
INFO - 2020-11-08 16:50:26 --> URI Class Initialized
INFO - 2020-11-08 16:50:26 --> Router Class Initialized
INFO - 2020-11-08 16:50:26 --> Output Class Initialized
INFO - 2020-11-08 16:50:26 --> Security Class Initialized
DEBUG - 2020-11-08 16:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 16:50:26 --> Input Class Initialized
INFO - 2020-11-08 16:50:26 --> Language Class Initialized
INFO - 2020-11-08 16:50:26 --> Loader Class Initialized
INFO - 2020-11-08 16:50:26 --> Helper loaded: url_helper
INFO - 2020-11-08 16:50:26 --> Database Driver Class Initialized
INFO - 2020-11-08 16:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 16:50:26 --> Email Class Initialized
INFO - 2020-11-08 16:50:26 --> Controller Class Initialized
DEBUG - 2020-11-08 16:50:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 16:50:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 16:50:26 --> Model Class Initialized
INFO - 2020-11-08 16:50:26 --> Model Class Initialized
ERROR - 2020-11-08 16:50:26 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_where_exists() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 16:50:26 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 27
INFO - 2020-11-08 16:50:31 --> Final output sent to browser
DEBUG - 2020-11-08 16:50:31 --> Total execution time: 4.3805
ERROR - 2020-11-08 16:51:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 16:51:38 --> Config Class Initialized
INFO - 2020-11-08 16:51:38 --> Hooks Class Initialized
DEBUG - 2020-11-08 16:51:38 --> UTF-8 Support Enabled
INFO - 2020-11-08 16:51:38 --> Utf8 Class Initialized
INFO - 2020-11-08 16:51:38 --> URI Class Initialized
INFO - 2020-11-08 16:51:38 --> Router Class Initialized
INFO - 2020-11-08 16:51:38 --> Output Class Initialized
INFO - 2020-11-08 16:51:38 --> Security Class Initialized
DEBUG - 2020-11-08 16:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 16:51:38 --> Input Class Initialized
INFO - 2020-11-08 16:51:38 --> Language Class Initialized
INFO - 2020-11-08 16:51:38 --> Loader Class Initialized
INFO - 2020-11-08 16:51:38 --> Helper loaded: url_helper
INFO - 2020-11-08 16:51:38 --> Database Driver Class Initialized
INFO - 2020-11-08 16:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 16:51:38 --> Email Class Initialized
INFO - 2020-11-08 16:51:38 --> Controller Class Initialized
DEBUG - 2020-11-08 16:51:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 16:51:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 16:51:38 --> Model Class Initialized
INFO - 2020-11-08 16:51:38 --> Model Class Initialized
ERROR - 2020-11-08 16:51:38 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_where_exists() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 16:51:38 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 27
INFO - 2020-11-08 16:51:40 --> Final output sent to browser
DEBUG - 2020-11-08 16:51:40 --> Total execution time: 1.0540
ERROR - 2020-11-08 16:52:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 16:52:05 --> Config Class Initialized
INFO - 2020-11-08 16:52:05 --> Hooks Class Initialized
DEBUG - 2020-11-08 16:52:05 --> UTF-8 Support Enabled
INFO - 2020-11-08 16:52:05 --> Utf8 Class Initialized
INFO - 2020-11-08 16:52:05 --> URI Class Initialized
INFO - 2020-11-08 16:52:05 --> Router Class Initialized
INFO - 2020-11-08 16:52:05 --> Output Class Initialized
INFO - 2020-11-08 16:52:05 --> Security Class Initialized
DEBUG - 2020-11-08 16:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 16:52:05 --> Input Class Initialized
INFO - 2020-11-08 16:52:05 --> Language Class Initialized
INFO - 2020-11-08 16:52:05 --> Loader Class Initialized
INFO - 2020-11-08 16:52:05 --> Helper loaded: url_helper
INFO - 2020-11-08 16:52:05 --> Database Driver Class Initialized
INFO - 2020-11-08 16:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 16:52:05 --> Email Class Initialized
INFO - 2020-11-08 16:52:05 --> Controller Class Initialized
DEBUG - 2020-11-08 16:52:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 16:52:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 16:52:05 --> Model Class Initialized
INFO - 2020-11-08 16:52:05 --> Model Class Initialized
ERROR - 2020-11-08 16:52:05 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_where_exists() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 16:52:05 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 27
INFO - 2020-11-08 16:52:06 --> Final output sent to browser
DEBUG - 2020-11-08 16:52:06 --> Total execution time: 0.9635
ERROR - 2020-11-08 16:52:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 16:52:52 --> Config Class Initialized
INFO - 2020-11-08 16:52:52 --> Hooks Class Initialized
DEBUG - 2020-11-08 16:52:52 --> UTF-8 Support Enabled
INFO - 2020-11-08 16:52:52 --> Utf8 Class Initialized
INFO - 2020-11-08 16:52:52 --> URI Class Initialized
INFO - 2020-11-08 16:52:52 --> Router Class Initialized
INFO - 2020-11-08 16:52:52 --> Output Class Initialized
INFO - 2020-11-08 16:52:52 --> Security Class Initialized
DEBUG - 2020-11-08 16:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 16:52:52 --> Input Class Initialized
INFO - 2020-11-08 16:52:52 --> Language Class Initialized
INFO - 2020-11-08 16:52:52 --> Loader Class Initialized
INFO - 2020-11-08 16:52:52 --> Helper loaded: url_helper
INFO - 2020-11-08 16:52:52 --> Database Driver Class Initialized
INFO - 2020-11-08 16:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 16:52:52 --> Email Class Initialized
INFO - 2020-11-08 16:52:52 --> Controller Class Initialized
DEBUG - 2020-11-08 16:52:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 16:52:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 16:52:52 --> Model Class Initialized
INFO - 2020-11-08 16:52:52 --> Model Class Initialized
ERROR - 2020-11-08 16:52:52 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_where_exists() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 16:52:52 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 27
INFO - 2020-11-08 16:52:56 --> Final output sent to browser
DEBUG - 2020-11-08 16:52:56 --> Total execution time: 4.0823
ERROR - 2020-11-08 16:53:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 16:53:11 --> Config Class Initialized
INFO - 2020-11-08 16:53:11 --> Hooks Class Initialized
DEBUG - 2020-11-08 16:53:11 --> UTF-8 Support Enabled
INFO - 2020-11-08 16:53:11 --> Utf8 Class Initialized
INFO - 2020-11-08 16:53:11 --> URI Class Initialized
INFO - 2020-11-08 16:53:11 --> Router Class Initialized
INFO - 2020-11-08 16:53:11 --> Output Class Initialized
INFO - 2020-11-08 16:53:11 --> Security Class Initialized
DEBUG - 2020-11-08 16:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 16:53:11 --> Input Class Initialized
INFO - 2020-11-08 16:53:11 --> Language Class Initialized
INFO - 2020-11-08 16:53:11 --> Loader Class Initialized
INFO - 2020-11-08 16:53:11 --> Helper loaded: url_helper
INFO - 2020-11-08 16:53:11 --> Database Driver Class Initialized
INFO - 2020-11-08 16:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 16:53:11 --> Email Class Initialized
INFO - 2020-11-08 16:53:11 --> Controller Class Initialized
DEBUG - 2020-11-08 16:53:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 16:53:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 16:53:11 --> Model Class Initialized
INFO - 2020-11-08 16:53:11 --> Model Class Initialized
ERROR - 2020-11-08 16:53:11 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_where_exists() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 16:53:11 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 27
INFO - 2020-11-08 16:53:12 --> Final output sent to browser
DEBUG - 2020-11-08 16:53:12 --> Total execution time: 1.0166
ERROR - 2020-11-08 16:56:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-08 16:56:53 --> Config Class Initialized
INFO - 2020-11-08 16:56:53 --> Hooks Class Initialized
DEBUG - 2020-11-08 16:56:53 --> UTF-8 Support Enabled
INFO - 2020-11-08 16:56:53 --> Utf8 Class Initialized
INFO - 2020-11-08 16:56:53 --> URI Class Initialized
INFO - 2020-11-08 16:56:53 --> Router Class Initialized
INFO - 2020-11-08 16:56:53 --> Output Class Initialized
INFO - 2020-11-08 16:56:53 --> Security Class Initialized
DEBUG - 2020-11-08 16:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 16:56:53 --> Input Class Initialized
INFO - 2020-11-08 16:56:53 --> Language Class Initialized
INFO - 2020-11-08 16:56:53 --> Loader Class Initialized
INFO - 2020-11-08 16:56:53 --> Helper loaded: url_helper
INFO - 2020-11-08 16:56:53 --> Database Driver Class Initialized
INFO - 2020-11-08 16:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 16:56:53 --> Email Class Initialized
INFO - 2020-11-08 16:56:53 --> Controller Class Initialized
DEBUG - 2020-11-08 16:56:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-08 16:56:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-08 16:56:53 --> Model Class Initialized
INFO - 2020-11-08 16:56:53 --> Model Class Initialized
ERROR - 2020-11-08 16:56:53 --> Severity: Runtime Notice --> Non-static method Purlem::get_campaign() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-08 16:56:53 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 51
INFO - 2020-11-08 16:56:54 --> Final output sent to browser
DEBUG - 2020-11-08 16:56:54 --> Total execution time: 1.0332
