<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-29 19:26:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-29 19:26:10 --> Config Class Initialized
INFO - 2020-09-29 19:26:10 --> Hooks Class Initialized
DEBUG - 2020-09-29 19:26:10 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:26:10 --> Utf8 Class Initialized
INFO - 2020-09-29 19:26:10 --> URI Class Initialized
DEBUG - 2020-09-29 19:26:10 --> No URI present. Default controller set.
INFO - 2020-09-29 19:26:10 --> Router Class Initialized
INFO - 2020-09-29 19:26:10 --> Output Class Initialized
INFO - 2020-09-29 19:26:10 --> Security Class Initialized
DEBUG - 2020-09-29 19:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:26:10 --> Input Class Initialized
INFO - 2020-09-29 19:26:10 --> Language Class Initialized
INFO - 2020-09-29 19:26:10 --> Loader Class Initialized
INFO - 2020-09-29 19:26:10 --> Helper loaded: url_helper
INFO - 2020-09-29 19:26:10 --> Database Driver Class Initialized
INFO - 2020-09-29 19:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:26:10 --> Email Class Initialized
INFO - 2020-09-29 19:26:10 --> Controller Class Initialized
INFO - 2020-09-29 19:26:10 --> Model Class Initialized
INFO - 2020-09-29 19:26:10 --> Model Class Initialized
DEBUG - 2020-09-29 19:26:10 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-29 19:26:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-29 19:26:10 --> Final output sent to browser
DEBUG - 2020-09-29 19:26:10 --> Total execution time: 0.1404
ERROR - 2020-09-29 19:26:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-29 19:26:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-29 19:26:12 --> Config Class Initialized
INFO - 2020-09-29 19:26:12 --> Hooks Class Initialized
INFO - 2020-09-29 19:26:12 --> Config Class Initialized
INFO - 2020-09-29 19:26:12 --> Hooks Class Initialized
DEBUG - 2020-09-29 19:26:12 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:26:12 --> Utf8 Class Initialized
DEBUG - 2020-09-29 19:26:12 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:26:12 --> Utf8 Class Initialized
INFO - 2020-09-29 19:26:12 --> URI Class Initialized
INFO - 2020-09-29 19:26:12 --> URI Class Initialized
DEBUG - 2020-09-29 19:26:12 --> No URI present. Default controller set.
INFO - 2020-09-29 19:26:12 --> Router Class Initialized
DEBUG - 2020-09-29 19:26:12 --> No URI present. Default controller set.
INFO - 2020-09-29 19:26:12 --> Router Class Initialized
INFO - 2020-09-29 19:26:12 --> Output Class Initialized
INFO - 2020-09-29 19:26:12 --> Output Class Initialized
INFO - 2020-09-29 19:26:12 --> Security Class Initialized
INFO - 2020-09-29 19:26:12 --> Security Class Initialized
DEBUG - 2020-09-29 19:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:26:12 --> Input Class Initialized
DEBUG - 2020-09-29 19:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:26:12 --> Input Class Initialized
INFO - 2020-09-29 19:26:12 --> Language Class Initialized
INFO - 2020-09-29 19:26:12 --> Language Class Initialized
INFO - 2020-09-29 19:26:12 --> Loader Class Initialized
INFO - 2020-09-29 19:26:12 --> Loader Class Initialized
INFO - 2020-09-29 19:26:12 --> Helper loaded: url_helper
INFO - 2020-09-29 19:26:12 --> Helper loaded: url_helper
INFO - 2020-09-29 19:26:12 --> Database Driver Class Initialized
INFO - 2020-09-29 19:26:12 --> Database Driver Class Initialized
INFO - 2020-09-29 19:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:26:12 --> Email Class Initialized
INFO - 2020-09-29 19:26:12 --> Email Class Initialized
INFO - 2020-09-29 19:26:12 --> Controller Class Initialized
INFO - 2020-09-29 19:26:12 --> Controller Class Initialized
INFO - 2020-09-29 19:26:12 --> Model Class Initialized
INFO - 2020-09-29 19:26:12 --> Model Class Initialized
INFO - 2020-09-29 19:26:12 --> Model Class Initialized
DEBUG - 2020-09-29 19:26:12 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-29 19:26:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-29 19:26:12 --> Model Class Initialized
INFO - 2020-09-29 19:26:12 --> Final output sent to browser
DEBUG - 2020-09-29 19:26:12 --> Total execution time: 0.0240
DEBUG - 2020-09-29 19:26:12 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-29 19:26:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-29 19:26:12 --> Final output sent to browser
DEBUG - 2020-09-29 19:26:12 --> Total execution time: 0.0244
ERROR - 2020-09-29 19:26:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-29 19:26:41 --> Config Class Initialized
INFO - 2020-09-29 19:26:41 --> Hooks Class Initialized
DEBUG - 2020-09-29 19:26:41 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:26:41 --> Utf8 Class Initialized
INFO - 2020-09-29 19:26:41 --> URI Class Initialized
INFO - 2020-09-29 19:26:41 --> Router Class Initialized
INFO - 2020-09-29 19:26:41 --> Output Class Initialized
INFO - 2020-09-29 19:26:41 --> Security Class Initialized
DEBUG - 2020-09-29 19:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:26:41 --> Input Class Initialized
INFO - 2020-09-29 19:26:41 --> Language Class Initialized
INFO - 2020-09-29 19:26:41 --> Loader Class Initialized
INFO - 2020-09-29 19:26:41 --> Helper loaded: url_helper
INFO - 2020-09-29 19:26:41 --> Database Driver Class Initialized
INFO - 2020-09-29 19:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:26:41 --> Email Class Initialized
INFO - 2020-09-29 19:26:41 --> Controller Class Initialized
INFO - 2020-09-29 19:26:41 --> Model Class Initialized
INFO - 2020-09-29 19:26:41 --> Model Class Initialized
DEBUG - 2020-09-29 19:26:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-29 19:26:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-29 19:26:41 --> Config Class Initialized
INFO - 2020-09-29 19:26:41 --> Hooks Class Initialized
DEBUG - 2020-09-29 19:26:41 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:26:41 --> Utf8 Class Initialized
INFO - 2020-09-29 19:26:41 --> URI Class Initialized
INFO - 2020-09-29 19:26:41 --> Router Class Initialized
INFO - 2020-09-29 19:26:41 --> Output Class Initialized
INFO - 2020-09-29 19:26:41 --> Security Class Initialized
DEBUG - 2020-09-29 19:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:26:41 --> Input Class Initialized
INFO - 2020-09-29 19:26:41 --> Language Class Initialized
INFO - 2020-09-29 19:26:41 --> Loader Class Initialized
INFO - 2020-09-29 19:26:41 --> Helper loaded: url_helper
INFO - 2020-09-29 19:26:41 --> Database Driver Class Initialized
INFO - 2020-09-29 19:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:26:41 --> Email Class Initialized
INFO - 2020-09-29 19:26:41 --> Controller Class Initialized
DEBUG - 2020-09-29 19:26:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-29 19:26:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-29 19:26:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-29 19:26:41 --> Final output sent to browser
DEBUG - 2020-09-29 19:26:41 --> Total execution time: 0.0480
ERROR - 2020-09-29 19:26:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-29 19:26:43 --> Config Class Initialized
INFO - 2020-09-29 19:26:43 --> Hooks Class Initialized
DEBUG - 2020-09-29 19:26:43 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:26:43 --> Utf8 Class Initialized
INFO - 2020-09-29 19:26:43 --> URI Class Initialized
INFO - 2020-09-29 19:26:43 --> Router Class Initialized
INFO - 2020-09-29 19:26:43 --> Output Class Initialized
INFO - 2020-09-29 19:26:43 --> Security Class Initialized
DEBUG - 2020-09-29 19:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:26:43 --> Input Class Initialized
INFO - 2020-09-29 19:26:43 --> Language Class Initialized
INFO - 2020-09-29 19:26:43 --> Loader Class Initialized
INFO - 2020-09-29 19:26:43 --> Helper loaded: url_helper
INFO - 2020-09-29 19:26:43 --> Database Driver Class Initialized
INFO - 2020-09-29 19:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:26:43 --> Email Class Initialized
INFO - 2020-09-29 19:26:43 --> Controller Class Initialized
DEBUG - 2020-09-29 19:26:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-29 19:26:43 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-29 19:26:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-29 19:26:43 --> Config Class Initialized
INFO - 2020-09-29 19:26:43 --> Hooks Class Initialized
DEBUG - 2020-09-29 19:26:43 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:26:43 --> Utf8 Class Initialized
INFO - 2020-09-29 19:26:43 --> URI Class Initialized
INFO - 2020-09-29 19:26:43 --> Router Class Initialized
INFO - 2020-09-29 19:26:43 --> Output Class Initialized
INFO - 2020-09-29 19:26:43 --> Security Class Initialized
DEBUG - 2020-09-29 19:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:26:43 --> Input Class Initialized
INFO - 2020-09-29 19:26:43 --> Language Class Initialized
INFO - 2020-09-29 19:26:43 --> Loader Class Initialized
INFO - 2020-09-29 19:26:43 --> Helper loaded: url_helper
INFO - 2020-09-29 19:26:43 --> Database Driver Class Initialized
INFO - 2020-09-29 19:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:26:43 --> Email Class Initialized
INFO - 2020-09-29 19:26:43 --> Controller Class Initialized
INFO - 2020-09-29 19:26:43 --> Model Class Initialized
INFO - 2020-09-29 19:26:43 --> Model Class Initialized
DEBUG - 2020-09-29 19:26:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-29 19:26:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-29 19:26:43 --> Config Class Initialized
INFO - 2020-09-29 19:26:43 --> Hooks Class Initialized
DEBUG - 2020-09-29 19:26:43 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:26:43 --> Utf8 Class Initialized
INFO - 2020-09-29 19:26:43 --> URI Class Initialized
DEBUG - 2020-09-29 19:26:43 --> No URI present. Default controller set.
INFO - 2020-09-29 19:26:43 --> Router Class Initialized
INFO - 2020-09-29 19:26:43 --> Output Class Initialized
INFO - 2020-09-29 19:26:43 --> Security Class Initialized
DEBUG - 2020-09-29 19:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:26:43 --> Input Class Initialized
INFO - 2020-09-29 19:26:43 --> Language Class Initialized
INFO - 2020-09-29 19:26:43 --> Loader Class Initialized
INFO - 2020-09-29 19:26:43 --> Helper loaded: url_helper
INFO - 2020-09-29 19:26:43 --> Database Driver Class Initialized
INFO - 2020-09-29 19:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:26:43 --> Email Class Initialized
INFO - 2020-09-29 19:26:43 --> Controller Class Initialized
INFO - 2020-09-29 19:26:43 --> Model Class Initialized
INFO - 2020-09-29 19:26:43 --> Model Class Initialized
DEBUG - 2020-09-29 19:26:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-29 19:26:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-29 19:26:43 --> Final output sent to browser
DEBUG - 2020-09-29 19:26:43 --> Total execution time: 0.0225
ERROR - 2020-09-29 19:26:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-29 19:26:51 --> Config Class Initialized
INFO - 2020-09-29 19:26:51 --> Hooks Class Initialized
DEBUG - 2020-09-29 19:26:51 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:26:51 --> Utf8 Class Initialized
INFO - 2020-09-29 19:26:51 --> URI Class Initialized
INFO - 2020-09-29 19:26:51 --> Router Class Initialized
INFO - 2020-09-29 19:26:51 --> Output Class Initialized
INFO - 2020-09-29 19:26:51 --> Security Class Initialized
DEBUG - 2020-09-29 19:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:26:51 --> Input Class Initialized
INFO - 2020-09-29 19:26:51 --> Language Class Initialized
INFO - 2020-09-29 19:26:51 --> Loader Class Initialized
INFO - 2020-09-29 19:26:51 --> Helper loaded: url_helper
INFO - 2020-09-29 19:26:51 --> Database Driver Class Initialized
INFO - 2020-09-29 19:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:26:51 --> Email Class Initialized
INFO - 2020-09-29 19:26:51 --> Controller Class Initialized
DEBUG - 2020-09-29 19:26:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-29 19:26:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-29 19:26:51 --> Model Class Initialized
INFO - 2020-09-29 19:26:51 --> Model Class Initialized
INFO - 2020-09-29 19:26:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-29 19:26:51 --> Final output sent to browser
DEBUG - 2020-09-29 19:26:51 --> Total execution time: 0.0586
ERROR - 2020-09-29 19:26:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-29 19:26:52 --> Config Class Initialized
INFO - 2020-09-29 19:26:52 --> Hooks Class Initialized
DEBUG - 2020-09-29 19:26:52 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:26:52 --> Utf8 Class Initialized
INFO - 2020-09-29 19:26:52 --> URI Class Initialized
INFO - 2020-09-29 19:26:52 --> Router Class Initialized
INFO - 2020-09-29 19:26:52 --> Output Class Initialized
INFO - 2020-09-29 19:26:52 --> Security Class Initialized
DEBUG - 2020-09-29 19:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:26:52 --> Input Class Initialized
INFO - 2020-09-29 19:26:52 --> Language Class Initialized
INFO - 2020-09-29 19:26:52 --> Loader Class Initialized
INFO - 2020-09-29 19:26:52 --> Helper loaded: url_helper
INFO - 2020-09-29 19:26:52 --> Database Driver Class Initialized
INFO - 2020-09-29 19:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:26:52 --> Email Class Initialized
INFO - 2020-09-29 19:26:52 --> Controller Class Initialized
DEBUG - 2020-09-29 19:26:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-29 19:26:52 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-29 19:26:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-29 19:26:53 --> Config Class Initialized
INFO - 2020-09-29 19:26:53 --> Hooks Class Initialized
DEBUG - 2020-09-29 19:26:53 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:26:53 --> Utf8 Class Initialized
INFO - 2020-09-29 19:26:53 --> URI Class Initialized
DEBUG - 2020-09-29 19:26:53 --> No URI present. Default controller set.
INFO - 2020-09-29 19:26:53 --> Router Class Initialized
INFO - 2020-09-29 19:26:53 --> Output Class Initialized
INFO - 2020-09-29 19:26:53 --> Security Class Initialized
DEBUG - 2020-09-29 19:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:26:53 --> Input Class Initialized
INFO - 2020-09-29 19:26:53 --> Language Class Initialized
INFO - 2020-09-29 19:26:53 --> Loader Class Initialized
INFO - 2020-09-29 19:26:53 --> Helper loaded: url_helper
INFO - 2020-09-29 19:26:53 --> Database Driver Class Initialized
INFO - 2020-09-29 19:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:26:53 --> Email Class Initialized
INFO - 2020-09-29 19:26:53 --> Controller Class Initialized
INFO - 2020-09-29 19:26:53 --> Model Class Initialized
INFO - 2020-09-29 19:26:53 --> Model Class Initialized
DEBUG - 2020-09-29 19:26:53 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-29 19:26:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-29 19:26:53 --> Final output sent to browser
DEBUG - 2020-09-29 19:26:53 --> Total execution time: 0.0192
ERROR - 2020-09-29 19:27:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-29 19:27:03 --> Config Class Initialized
INFO - 2020-09-29 19:27:03 --> Hooks Class Initialized
DEBUG - 2020-09-29 19:27:03 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:27:03 --> Utf8 Class Initialized
INFO - 2020-09-29 19:27:03 --> URI Class Initialized
INFO - 2020-09-29 19:27:03 --> Router Class Initialized
INFO - 2020-09-29 19:27:03 --> Output Class Initialized
INFO - 2020-09-29 19:27:03 --> Security Class Initialized
DEBUG - 2020-09-29 19:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:27:03 --> Input Class Initialized
INFO - 2020-09-29 19:27:03 --> Language Class Initialized
INFO - 2020-09-29 19:27:03 --> Loader Class Initialized
INFO - 2020-09-29 19:27:03 --> Helper loaded: url_helper
INFO - 2020-09-29 19:27:03 --> Database Driver Class Initialized
INFO - 2020-09-29 19:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:27:03 --> Email Class Initialized
INFO - 2020-09-29 19:27:03 --> Controller Class Initialized
DEBUG - 2020-09-29 19:27:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-29 19:27:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-29 19:27:03 --> Model Class Initialized
INFO - 2020-09-29 19:27:03 --> Model Class Initialized
INFO - 2020-09-29 19:27:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_view.php
INFO - 2020-09-29 19:27:03 --> Final output sent to browser
DEBUG - 2020-09-29 19:27:03 --> Total execution time: 0.0376
ERROR - 2020-09-29 19:27:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-29 19:27:04 --> Config Class Initialized
INFO - 2020-09-29 19:27:04 --> Hooks Class Initialized
DEBUG - 2020-09-29 19:27:04 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:27:04 --> Utf8 Class Initialized
INFO - 2020-09-29 19:27:04 --> URI Class Initialized
INFO - 2020-09-29 19:27:04 --> Router Class Initialized
INFO - 2020-09-29 19:27:04 --> Output Class Initialized
INFO - 2020-09-29 19:27:04 --> Security Class Initialized
DEBUG - 2020-09-29 19:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:27:04 --> Input Class Initialized
INFO - 2020-09-29 19:27:04 --> Language Class Initialized
INFO - 2020-09-29 19:27:04 --> Loader Class Initialized
INFO - 2020-09-29 19:27:04 --> Helper loaded: url_helper
INFO - 2020-09-29 19:27:04 --> Database Driver Class Initialized
INFO - 2020-09-29 19:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:27:04 --> Email Class Initialized
INFO - 2020-09-29 19:27:04 --> Controller Class Initialized
DEBUG - 2020-09-29 19:27:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-29 19:27:04 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-29 19:27:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-29 19:27:05 --> Config Class Initialized
INFO - 2020-09-29 19:27:05 --> Hooks Class Initialized
DEBUG - 2020-09-29 19:27:05 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:27:05 --> Utf8 Class Initialized
INFO - 2020-09-29 19:27:05 --> URI Class Initialized
DEBUG - 2020-09-29 19:27:05 --> No URI present. Default controller set.
INFO - 2020-09-29 19:27:05 --> Router Class Initialized
INFO - 2020-09-29 19:27:05 --> Output Class Initialized
INFO - 2020-09-29 19:27:05 --> Security Class Initialized
DEBUG - 2020-09-29 19:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:27:05 --> Input Class Initialized
INFO - 2020-09-29 19:27:05 --> Language Class Initialized
INFO - 2020-09-29 19:27:05 --> Loader Class Initialized
INFO - 2020-09-29 19:27:05 --> Helper loaded: url_helper
INFO - 2020-09-29 19:27:05 --> Database Driver Class Initialized
INFO - 2020-09-29 19:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:27:05 --> Email Class Initialized
INFO - 2020-09-29 19:27:05 --> Controller Class Initialized
INFO - 2020-09-29 19:27:05 --> Model Class Initialized
INFO - 2020-09-29 19:27:05 --> Model Class Initialized
DEBUG - 2020-09-29 19:27:05 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-29 19:27:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-29 19:27:05 --> Final output sent to browser
DEBUG - 2020-09-29 19:27:05 --> Total execution time: 0.0217
ERROR - 2020-09-29 19:27:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-29 19:27:07 --> Config Class Initialized
INFO - 2020-09-29 19:27:07 --> Hooks Class Initialized
DEBUG - 2020-09-29 19:27:07 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:27:07 --> Utf8 Class Initialized
INFO - 2020-09-29 19:27:07 --> URI Class Initialized
INFO - 2020-09-29 19:27:07 --> Router Class Initialized
INFO - 2020-09-29 19:27:07 --> Output Class Initialized
INFO - 2020-09-29 19:27:07 --> Security Class Initialized
DEBUG - 2020-09-29 19:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:27:07 --> Input Class Initialized
INFO - 2020-09-29 19:27:07 --> Language Class Initialized
INFO - 2020-09-29 19:27:07 --> Loader Class Initialized
INFO - 2020-09-29 19:27:07 --> Helper loaded: url_helper
INFO - 2020-09-29 19:27:07 --> Database Driver Class Initialized
INFO - 2020-09-29 19:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:27:07 --> Email Class Initialized
INFO - 2020-09-29 19:27:07 --> Controller Class Initialized
DEBUG - 2020-09-29 19:27:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-29 19:27:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-29 19:27:07 --> Model Class Initialized
INFO - 2020-09-29 19:27:07 --> Model Class Initialized
INFO - 2020-09-29 19:27:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-29 19:27:08 --> Final output sent to browser
DEBUG - 2020-09-29 19:27:08 --> Total execution time: 0.0508
ERROR - 2020-09-29 19:27:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-29 19:27:09 --> Config Class Initialized
INFO - 2020-09-29 19:27:09 --> Hooks Class Initialized
DEBUG - 2020-09-29 19:27:09 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:27:09 --> Utf8 Class Initialized
INFO - 2020-09-29 19:27:09 --> URI Class Initialized
INFO - 2020-09-29 19:27:09 --> Router Class Initialized
INFO - 2020-09-29 19:27:09 --> Output Class Initialized
INFO - 2020-09-29 19:27:09 --> Security Class Initialized
DEBUG - 2020-09-29 19:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:27:09 --> Input Class Initialized
INFO - 2020-09-29 19:27:09 --> Language Class Initialized
INFO - 2020-09-29 19:27:09 --> Loader Class Initialized
INFO - 2020-09-29 19:27:09 --> Helper loaded: url_helper
INFO - 2020-09-29 19:27:09 --> Database Driver Class Initialized
INFO - 2020-09-29 19:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:27:09 --> Email Class Initialized
INFO - 2020-09-29 19:27:09 --> Controller Class Initialized
DEBUG - 2020-09-29 19:27:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-29 19:27:09 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-29 19:27:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-29 19:27:10 --> Config Class Initialized
INFO - 2020-09-29 19:27:10 --> Hooks Class Initialized
DEBUG - 2020-09-29 19:27:10 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:27:10 --> Utf8 Class Initialized
INFO - 2020-09-29 19:27:10 --> URI Class Initialized
DEBUG - 2020-09-29 19:27:10 --> No URI present. Default controller set.
INFO - 2020-09-29 19:27:10 --> Router Class Initialized
INFO - 2020-09-29 19:27:10 --> Output Class Initialized
INFO - 2020-09-29 19:27:10 --> Security Class Initialized
DEBUG - 2020-09-29 19:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:27:10 --> Input Class Initialized
INFO - 2020-09-29 19:27:10 --> Language Class Initialized
INFO - 2020-09-29 19:27:10 --> Loader Class Initialized
INFO - 2020-09-29 19:27:10 --> Helper loaded: url_helper
INFO - 2020-09-29 19:27:10 --> Database Driver Class Initialized
INFO - 2020-09-29 19:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:27:10 --> Email Class Initialized
INFO - 2020-09-29 19:27:10 --> Controller Class Initialized
INFO - 2020-09-29 19:27:10 --> Model Class Initialized
INFO - 2020-09-29 19:27:10 --> Model Class Initialized
DEBUG - 2020-09-29 19:27:10 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-29 19:27:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-29 19:27:10 --> Final output sent to browser
DEBUG - 2020-09-29 19:27:10 --> Total execution time: 0.0220
ERROR - 2020-09-29 19:27:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-29 19:27:14 --> Config Class Initialized
INFO - 2020-09-29 19:27:14 --> Hooks Class Initialized
DEBUG - 2020-09-29 19:27:14 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:27:14 --> Utf8 Class Initialized
INFO - 2020-09-29 19:27:14 --> URI Class Initialized
INFO - 2020-09-29 19:27:14 --> Router Class Initialized
INFO - 2020-09-29 19:27:14 --> Output Class Initialized
INFO - 2020-09-29 19:27:14 --> Security Class Initialized
DEBUG - 2020-09-29 19:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:27:14 --> Input Class Initialized
INFO - 2020-09-29 19:27:14 --> Language Class Initialized
INFO - 2020-09-29 19:27:14 --> Loader Class Initialized
INFO - 2020-09-29 19:27:14 --> Helper loaded: url_helper
INFO - 2020-09-29 19:27:14 --> Database Driver Class Initialized
INFO - 2020-09-29 19:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:27:14 --> Email Class Initialized
INFO - 2020-09-29 19:27:14 --> Controller Class Initialized
DEBUG - 2020-09-29 19:27:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-29 19:27:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-29 19:27:14 --> Model Class Initialized
INFO - 2020-09-29 19:27:14 --> Model Class Initialized
INFO - 2020-09-29 19:27:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-09-29 19:27:14 --> Final output sent to browser
DEBUG - 2020-09-29 19:27:14 --> Total execution time: 0.0379
ERROR - 2020-09-29 19:27:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-29 19:27:15 --> Config Class Initialized
INFO - 2020-09-29 19:27:15 --> Hooks Class Initialized
DEBUG - 2020-09-29 19:27:15 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:27:15 --> Utf8 Class Initialized
INFO - 2020-09-29 19:27:15 --> URI Class Initialized
INFO - 2020-09-29 19:27:15 --> Router Class Initialized
INFO - 2020-09-29 19:27:15 --> Output Class Initialized
INFO - 2020-09-29 19:27:15 --> Security Class Initialized
DEBUG - 2020-09-29 19:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:27:15 --> Input Class Initialized
INFO - 2020-09-29 19:27:15 --> Language Class Initialized
INFO - 2020-09-29 19:27:15 --> Loader Class Initialized
INFO - 2020-09-29 19:27:15 --> Helper loaded: url_helper
INFO - 2020-09-29 19:27:15 --> Database Driver Class Initialized
INFO - 2020-09-29 19:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:27:15 --> Email Class Initialized
INFO - 2020-09-29 19:27:15 --> Controller Class Initialized
DEBUG - 2020-09-29 19:27:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-29 19:27:15 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-29 19:27:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-29 19:27:16 --> Config Class Initialized
INFO - 2020-09-29 19:27:16 --> Hooks Class Initialized
DEBUG - 2020-09-29 19:27:16 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:27:16 --> Utf8 Class Initialized
INFO - 2020-09-29 19:27:16 --> URI Class Initialized
DEBUG - 2020-09-29 19:27:16 --> No URI present. Default controller set.
INFO - 2020-09-29 19:27:16 --> Router Class Initialized
INFO - 2020-09-29 19:27:16 --> Output Class Initialized
INFO - 2020-09-29 19:27:16 --> Security Class Initialized
DEBUG - 2020-09-29 19:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:27:16 --> Input Class Initialized
INFO - 2020-09-29 19:27:16 --> Language Class Initialized
INFO - 2020-09-29 19:27:16 --> Loader Class Initialized
INFO - 2020-09-29 19:27:16 --> Helper loaded: url_helper
INFO - 2020-09-29 19:27:16 --> Database Driver Class Initialized
INFO - 2020-09-29 19:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:27:16 --> Email Class Initialized
INFO - 2020-09-29 19:27:16 --> Controller Class Initialized
INFO - 2020-09-29 19:27:16 --> Model Class Initialized
INFO - 2020-09-29 19:27:16 --> Model Class Initialized
DEBUG - 2020-09-29 19:27:16 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-29 19:27:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-29 19:27:16 --> Final output sent to browser
DEBUG - 2020-09-29 19:27:16 --> Total execution time: 0.0201
ERROR - 2020-09-29 19:27:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-29 19:27:17 --> Config Class Initialized
INFO - 2020-09-29 19:27:17 --> Hooks Class Initialized
DEBUG - 2020-09-29 19:27:17 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:27:17 --> Utf8 Class Initialized
INFO - 2020-09-29 19:27:17 --> URI Class Initialized
INFO - 2020-09-29 19:27:17 --> Router Class Initialized
INFO - 2020-09-29 19:27:17 --> Output Class Initialized
INFO - 2020-09-29 19:27:17 --> Security Class Initialized
DEBUG - 2020-09-29 19:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:27:17 --> Input Class Initialized
INFO - 2020-09-29 19:27:17 --> Language Class Initialized
INFO - 2020-09-29 19:27:17 --> Loader Class Initialized
INFO - 2020-09-29 19:27:17 --> Helper loaded: url_helper
INFO - 2020-09-29 19:27:17 --> Database Driver Class Initialized
INFO - 2020-09-29 19:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:27:17 --> Email Class Initialized
INFO - 2020-09-29 19:27:17 --> Controller Class Initialized
DEBUG - 2020-09-29 19:27:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-29 19:27:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-29 19:27:17 --> Model Class Initialized
INFO - 2020-09-29 19:27:17 --> Model Class Initialized
INFO - 2020-09-29 19:27:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-29 19:27:17 --> Final output sent to browser
DEBUG - 2020-09-29 19:27:17 --> Total execution time: 0.0222
ERROR - 2020-09-29 19:27:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-29 19:27:18 --> Config Class Initialized
INFO - 2020-09-29 19:27:18 --> Hooks Class Initialized
DEBUG - 2020-09-29 19:27:18 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:27:18 --> Utf8 Class Initialized
INFO - 2020-09-29 19:27:18 --> URI Class Initialized
INFO - 2020-09-29 19:27:18 --> Router Class Initialized
INFO - 2020-09-29 19:27:18 --> Output Class Initialized
INFO - 2020-09-29 19:27:18 --> Security Class Initialized
DEBUG - 2020-09-29 19:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:27:18 --> Input Class Initialized
INFO - 2020-09-29 19:27:18 --> Language Class Initialized
INFO - 2020-09-29 19:27:18 --> Loader Class Initialized
INFO - 2020-09-29 19:27:18 --> Helper loaded: url_helper
INFO - 2020-09-29 19:27:18 --> Database Driver Class Initialized
INFO - 2020-09-29 19:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:27:18 --> Email Class Initialized
INFO - 2020-09-29 19:27:18 --> Controller Class Initialized
DEBUG - 2020-09-29 19:27:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-29 19:27:18 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-29 19:27:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-29 19:27:19 --> Config Class Initialized
INFO - 2020-09-29 19:27:19 --> Hooks Class Initialized
DEBUG - 2020-09-29 19:27:19 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:27:19 --> Utf8 Class Initialized
INFO - 2020-09-29 19:27:19 --> URI Class Initialized
DEBUG - 2020-09-29 19:27:19 --> No URI present. Default controller set.
INFO - 2020-09-29 19:27:19 --> Router Class Initialized
INFO - 2020-09-29 19:27:19 --> Output Class Initialized
INFO - 2020-09-29 19:27:19 --> Security Class Initialized
DEBUG - 2020-09-29 19:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:27:19 --> Input Class Initialized
INFO - 2020-09-29 19:27:19 --> Language Class Initialized
INFO - 2020-09-29 19:27:19 --> Loader Class Initialized
INFO - 2020-09-29 19:27:19 --> Helper loaded: url_helper
INFO - 2020-09-29 19:27:19 --> Database Driver Class Initialized
INFO - 2020-09-29 19:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:27:19 --> Email Class Initialized
INFO - 2020-09-29 19:27:19 --> Controller Class Initialized
INFO - 2020-09-29 19:27:19 --> Model Class Initialized
INFO - 2020-09-29 19:27:19 --> Model Class Initialized
DEBUG - 2020-09-29 19:27:19 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-29 19:27:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-29 19:27:19 --> Final output sent to browser
DEBUG - 2020-09-29 19:27:19 --> Total execution time: 0.0204
ERROR - 2020-09-29 19:27:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-29 19:27:19 --> Config Class Initialized
INFO - 2020-09-29 19:27:19 --> Hooks Class Initialized
DEBUG - 2020-09-29 19:27:19 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:27:19 --> Utf8 Class Initialized
INFO - 2020-09-29 19:27:19 --> URI Class Initialized
INFO - 2020-09-29 19:27:19 --> Router Class Initialized
INFO - 2020-09-29 19:27:19 --> Output Class Initialized
INFO - 2020-09-29 19:27:19 --> Security Class Initialized
DEBUG - 2020-09-29 19:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:27:19 --> Input Class Initialized
INFO - 2020-09-29 19:27:19 --> Language Class Initialized
INFO - 2020-09-29 19:27:19 --> Loader Class Initialized
INFO - 2020-09-29 19:27:19 --> Helper loaded: url_helper
INFO - 2020-09-29 19:27:19 --> Database Driver Class Initialized
INFO - 2020-09-29 19:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:27:19 --> Email Class Initialized
INFO - 2020-09-29 19:27:19 --> Controller Class Initialized
DEBUG - 2020-09-29 19:27:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-29 19:27:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-29 19:27:19 --> Model Class Initialized
INFO - 2020-09-29 19:27:19 --> Model Class Initialized
INFO - 2020-09-29 19:27:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-09-29 19:27:19 --> Final output sent to browser
DEBUG - 2020-09-29 19:27:19 --> Total execution time: 0.0355
ERROR - 2020-09-29 19:27:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-29 19:27:21 --> Config Class Initialized
INFO - 2020-09-29 19:27:21 --> Hooks Class Initialized
DEBUG - 2020-09-29 19:27:21 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:27:21 --> Utf8 Class Initialized
INFO - 2020-09-29 19:27:21 --> URI Class Initialized
INFO - 2020-09-29 19:27:21 --> Router Class Initialized
INFO - 2020-09-29 19:27:21 --> Output Class Initialized
INFO - 2020-09-29 19:27:21 --> Security Class Initialized
DEBUG - 2020-09-29 19:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:27:21 --> Input Class Initialized
INFO - 2020-09-29 19:27:21 --> Language Class Initialized
INFO - 2020-09-29 19:27:21 --> Loader Class Initialized
INFO - 2020-09-29 19:27:21 --> Helper loaded: url_helper
INFO - 2020-09-29 19:27:21 --> Database Driver Class Initialized
INFO - 2020-09-29 19:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:27:21 --> Email Class Initialized
INFO - 2020-09-29 19:27:21 --> Controller Class Initialized
DEBUG - 2020-09-29 19:27:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-29 19:27:21 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-29 19:27:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-29 19:27:22 --> Config Class Initialized
INFO - 2020-09-29 19:27:22 --> Hooks Class Initialized
DEBUG - 2020-09-29 19:27:22 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:27:22 --> Utf8 Class Initialized
INFO - 2020-09-29 19:27:22 --> URI Class Initialized
DEBUG - 2020-09-29 19:27:22 --> No URI present. Default controller set.
INFO - 2020-09-29 19:27:22 --> Router Class Initialized
INFO - 2020-09-29 19:27:22 --> Output Class Initialized
INFO - 2020-09-29 19:27:22 --> Security Class Initialized
DEBUG - 2020-09-29 19:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:27:22 --> Input Class Initialized
INFO - 2020-09-29 19:27:22 --> Language Class Initialized
INFO - 2020-09-29 19:27:22 --> Loader Class Initialized
INFO - 2020-09-29 19:27:22 --> Helper loaded: url_helper
INFO - 2020-09-29 19:27:22 --> Database Driver Class Initialized
INFO - 2020-09-29 19:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:27:22 --> Email Class Initialized
INFO - 2020-09-29 19:27:22 --> Controller Class Initialized
INFO - 2020-09-29 19:27:22 --> Model Class Initialized
INFO - 2020-09-29 19:27:22 --> Model Class Initialized
DEBUG - 2020-09-29 19:27:22 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-29 19:27:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-29 19:27:22 --> Final output sent to browser
DEBUG - 2020-09-29 19:27:22 --> Total execution time: 0.0220
ERROR - 2020-09-29 19:27:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-29 19:27:38 --> Config Class Initialized
INFO - 2020-09-29 19:27:38 --> Hooks Class Initialized
DEBUG - 2020-09-29 19:27:38 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:27:38 --> Utf8 Class Initialized
INFO - 2020-09-29 19:27:38 --> URI Class Initialized
INFO - 2020-09-29 19:27:38 --> Router Class Initialized
INFO - 2020-09-29 19:27:38 --> Output Class Initialized
INFO - 2020-09-29 19:27:38 --> Security Class Initialized
DEBUG - 2020-09-29 19:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:27:38 --> Input Class Initialized
INFO - 2020-09-29 19:27:38 --> Language Class Initialized
INFO - 2020-09-29 19:27:38 --> Loader Class Initialized
INFO - 2020-09-29 19:27:38 --> Helper loaded: url_helper
INFO - 2020-09-29 19:27:38 --> Database Driver Class Initialized
INFO - 2020-09-29 19:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:27:38 --> Email Class Initialized
INFO - 2020-09-29 19:27:38 --> Controller Class Initialized
DEBUG - 2020-09-29 19:27:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-29 19:27:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-29 19:27:38 --> Model Class Initialized
INFO - 2020-09-29 19:27:38 --> Model Class Initialized
INFO - 2020-09-29 19:27:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-29 19:27:38 --> Final output sent to browser
DEBUG - 2020-09-29 19:27:38 --> Total execution time: 0.0471
ERROR - 2020-09-29 19:27:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-29 19:27:39 --> Config Class Initialized
INFO - 2020-09-29 19:27:39 --> Hooks Class Initialized
DEBUG - 2020-09-29 19:27:39 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:27:39 --> Utf8 Class Initialized
INFO - 2020-09-29 19:27:39 --> URI Class Initialized
INFO - 2020-09-29 19:27:39 --> Router Class Initialized
INFO - 2020-09-29 19:27:39 --> Output Class Initialized
INFO - 2020-09-29 19:27:39 --> Security Class Initialized
DEBUG - 2020-09-29 19:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:27:39 --> Input Class Initialized
INFO - 2020-09-29 19:27:39 --> Language Class Initialized
INFO - 2020-09-29 19:27:39 --> Loader Class Initialized
INFO - 2020-09-29 19:27:39 --> Helper loaded: url_helper
INFO - 2020-09-29 19:27:39 --> Database Driver Class Initialized
INFO - 2020-09-29 19:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:27:39 --> Email Class Initialized
INFO - 2020-09-29 19:27:39 --> Controller Class Initialized
DEBUG - 2020-09-29 19:27:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-29 19:27:39 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-29 19:27:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-29 19:27:40 --> Config Class Initialized
INFO - 2020-09-29 19:27:40 --> Hooks Class Initialized
DEBUG - 2020-09-29 19:27:40 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:27:40 --> Utf8 Class Initialized
INFO - 2020-09-29 19:27:40 --> URI Class Initialized
DEBUG - 2020-09-29 19:27:40 --> No URI present. Default controller set.
INFO - 2020-09-29 19:27:40 --> Router Class Initialized
INFO - 2020-09-29 19:27:40 --> Output Class Initialized
INFO - 2020-09-29 19:27:40 --> Security Class Initialized
DEBUG - 2020-09-29 19:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:27:40 --> Input Class Initialized
INFO - 2020-09-29 19:27:40 --> Language Class Initialized
INFO - 2020-09-29 19:27:40 --> Loader Class Initialized
INFO - 2020-09-29 19:27:40 --> Helper loaded: url_helper
INFO - 2020-09-29 19:27:40 --> Database Driver Class Initialized
INFO - 2020-09-29 19:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:27:40 --> Email Class Initialized
INFO - 2020-09-29 19:27:40 --> Controller Class Initialized
INFO - 2020-09-29 19:27:40 --> Model Class Initialized
INFO - 2020-09-29 19:27:40 --> Model Class Initialized
DEBUG - 2020-09-29 19:27:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-29 19:27:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-29 19:27:40 --> Final output sent to browser
DEBUG - 2020-09-29 19:27:40 --> Total execution time: 0.0215
ERROR - 2020-09-29 19:28:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-29 19:28:00 --> Config Class Initialized
INFO - 2020-09-29 19:28:00 --> Hooks Class Initialized
DEBUG - 2020-09-29 19:28:00 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:28:00 --> Utf8 Class Initialized
INFO - 2020-09-29 19:28:00 --> URI Class Initialized
INFO - 2020-09-29 19:28:00 --> Router Class Initialized
INFO - 2020-09-29 19:28:00 --> Output Class Initialized
INFO - 2020-09-29 19:28:00 --> Security Class Initialized
DEBUG - 2020-09-29 19:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:28:00 --> Input Class Initialized
INFO - 2020-09-29 19:28:00 --> Language Class Initialized
INFO - 2020-09-29 19:28:00 --> Loader Class Initialized
INFO - 2020-09-29 19:28:00 --> Helper loaded: url_helper
INFO - 2020-09-29 19:28:00 --> Database Driver Class Initialized
INFO - 2020-09-29 19:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:28:00 --> Email Class Initialized
INFO - 2020-09-29 19:28:00 --> Controller Class Initialized
INFO - 2020-09-29 19:28:00 --> Model Class Initialized
INFO - 2020-09-29 19:28:00 --> Model Class Initialized
INFO - 2020-09-29 19:28:01 --> Model Class Initialized
INFO - 2020-09-29 19:28:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-29 19:28:01 --> Final output sent to browser
DEBUG - 2020-09-29 19:28:01 --> Total execution time: 0.2152
ERROR - 2020-09-29 19:28:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-29 19:28:01 --> Config Class Initialized
INFO - 2020-09-29 19:28:01 --> Hooks Class Initialized
DEBUG - 2020-09-29 19:28:01 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:28:01 --> Utf8 Class Initialized
INFO - 2020-09-29 19:28:01 --> URI Class Initialized
INFO - 2020-09-29 19:28:01 --> Router Class Initialized
INFO - 2020-09-29 19:28:01 --> Output Class Initialized
INFO - 2020-09-29 19:28:01 --> Security Class Initialized
DEBUG - 2020-09-29 19:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:28:01 --> Input Class Initialized
INFO - 2020-09-29 19:28:01 --> Language Class Initialized
INFO - 2020-09-29 19:28:01 --> Loader Class Initialized
INFO - 2020-09-29 19:28:01 --> Helper loaded: url_helper
INFO - 2020-09-29 19:28:01 --> Database Driver Class Initialized
INFO - 2020-09-29 19:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:28:01 --> Email Class Initialized
INFO - 2020-09-29 19:28:01 --> Controller Class Initialized
INFO - 2020-09-29 19:28:01 --> Model Class Initialized
INFO - 2020-09-29 19:28:01 --> Model Class Initialized
INFO - 2020-09-29 19:28:01 --> Final output sent to browser
DEBUG - 2020-09-29 19:28:01 --> Total execution time: 0.0507
ERROR - 2020-09-29 19:28:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-29 19:28:02 --> Config Class Initialized
INFO - 2020-09-29 19:28:02 --> Hooks Class Initialized
DEBUG - 2020-09-29 19:28:02 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:28:02 --> Utf8 Class Initialized
INFO - 2020-09-29 19:28:02 --> URI Class Initialized
INFO - 2020-09-29 19:28:02 --> Router Class Initialized
INFO - 2020-09-29 19:28:02 --> Output Class Initialized
INFO - 2020-09-29 19:28:02 --> Security Class Initialized
DEBUG - 2020-09-29 19:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:28:02 --> Input Class Initialized
INFO - 2020-09-29 19:28:02 --> Language Class Initialized
INFO - 2020-09-29 19:28:02 --> Loader Class Initialized
INFO - 2020-09-29 19:28:02 --> Helper loaded: url_helper
INFO - 2020-09-29 19:28:02 --> Database Driver Class Initialized
INFO - 2020-09-29 19:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:28:02 --> Email Class Initialized
INFO - 2020-09-29 19:28:02 --> Controller Class Initialized
INFO - 2020-09-29 19:28:02 --> Model Class Initialized
INFO - 2020-09-29 19:28:02 --> Model Class Initialized
ERROR - 2020-09-29 19:28:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-29 19:28:02 --> Config Class Initialized
INFO - 2020-09-29 19:28:02 --> Hooks Class Initialized
DEBUG - 2020-09-29 19:28:02 --> UTF-8 Support Enabled
INFO - 2020-09-29 19:28:02 --> Utf8 Class Initialized
INFO - 2020-09-29 19:28:02 --> URI Class Initialized
DEBUG - 2020-09-29 19:28:02 --> No URI present. Default controller set.
INFO - 2020-09-29 19:28:02 --> Router Class Initialized
INFO - 2020-09-29 19:28:02 --> Output Class Initialized
INFO - 2020-09-29 19:28:02 --> Security Class Initialized
DEBUG - 2020-09-29 19:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-29 19:28:02 --> Input Class Initialized
INFO - 2020-09-29 19:28:02 --> Language Class Initialized
INFO - 2020-09-29 19:28:02 --> Loader Class Initialized
INFO - 2020-09-29 19:28:02 --> Helper loaded: url_helper
INFO - 2020-09-29 19:28:02 --> Database Driver Class Initialized
INFO - 2020-09-29 19:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-29 19:28:02 --> Email Class Initialized
INFO - 2020-09-29 19:28:02 --> Controller Class Initialized
INFO - 2020-09-29 19:28:02 --> Model Class Initialized
INFO - 2020-09-29 19:28:02 --> Model Class Initialized
DEBUG - 2020-09-29 19:28:02 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-29 19:28:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-29 19:28:02 --> Final output sent to browser
DEBUG - 2020-09-29 19:28:02 --> Total execution time: 0.0218
