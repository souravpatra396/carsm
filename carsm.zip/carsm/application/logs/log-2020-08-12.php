<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-08-12 03:06:12 --> Config Class Initialized
INFO - 2020-08-12 03:06:12 --> Hooks Class Initialized
DEBUG - 2020-08-12 03:06:12 --> UTF-8 Support Enabled
INFO - 2020-08-12 03:06:12 --> Utf8 Class Initialized
INFO - 2020-08-12 03:06:12 --> URI Class Initialized
DEBUG - 2020-08-12 03:06:12 --> No URI present. Default controller set.
INFO - 2020-08-12 03:06:12 --> Router Class Initialized
INFO - 2020-08-12 03:06:12 --> Output Class Initialized
INFO - 2020-08-12 03:06:12 --> Security Class Initialized
DEBUG - 2020-08-12 03:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 03:06:12 --> Input Class Initialized
INFO - 2020-08-12 03:06:12 --> Language Class Initialized
INFO - 2020-08-12 03:06:12 --> Loader Class Initialized
INFO - 2020-08-12 03:06:12 --> Helper loaded: url_helper
INFO - 2020-08-12 03:06:12 --> Database Driver Class Initialized
INFO - 2020-08-12 03:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 03:06:12 --> Email Class Initialized
INFO - 2020-08-12 03:06:12 --> Controller Class Initialized
INFO - 2020-08-12 03:06:12 --> Model Class Initialized
INFO - 2020-08-12 03:06:12 --> Model Class Initialized
DEBUG - 2020-08-12 03:06:12 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-12 03:06:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-12 03:06:12 --> Final output sent to browser
DEBUG - 2020-08-12 03:06:12 --> Total execution time: 0.1930
INFO - 2020-08-12 03:06:16 --> Config Class Initialized
INFO - 2020-08-12 03:06:16 --> Hooks Class Initialized
DEBUG - 2020-08-12 03:06:16 --> UTF-8 Support Enabled
INFO - 2020-08-12 03:06:16 --> Utf8 Class Initialized
INFO - 2020-08-12 03:06:16 --> URI Class Initialized
INFO - 2020-08-12 03:06:16 --> Router Class Initialized
INFO - 2020-08-12 03:06:16 --> Output Class Initialized
INFO - 2020-08-12 03:06:16 --> Security Class Initialized
DEBUG - 2020-08-12 03:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 03:06:16 --> Input Class Initialized
INFO - 2020-08-12 03:06:16 --> Language Class Initialized
INFO - 2020-08-12 03:06:16 --> Loader Class Initialized
INFO - 2020-08-12 03:06:16 --> Helper loaded: url_helper
INFO - 2020-08-12 03:06:16 --> Database Driver Class Initialized
INFO - 2020-08-12 03:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 03:06:16 --> Email Class Initialized
INFO - 2020-08-12 03:06:16 --> Controller Class Initialized
INFO - 2020-08-12 03:06:16 --> Model Class Initialized
INFO - 2020-08-12 03:06:16 --> Model Class Initialized
DEBUG - 2020-08-12 03:06:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 03:06:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 03:06:16 --> Config Class Initialized
INFO - 2020-08-12 03:06:16 --> Hooks Class Initialized
DEBUG - 2020-08-12 03:06:16 --> UTF-8 Support Enabled
INFO - 2020-08-12 03:06:16 --> Utf8 Class Initialized
INFO - 2020-08-12 03:06:16 --> URI Class Initialized
INFO - 2020-08-12 03:06:16 --> Router Class Initialized
INFO - 2020-08-12 03:06:16 --> Output Class Initialized
INFO - 2020-08-12 03:06:16 --> Security Class Initialized
DEBUG - 2020-08-12 03:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 03:06:16 --> Input Class Initialized
INFO - 2020-08-12 03:06:16 --> Language Class Initialized
INFO - 2020-08-12 03:06:16 --> Loader Class Initialized
INFO - 2020-08-12 03:06:16 --> Helper loaded: url_helper
INFO - 2020-08-12 03:06:16 --> Database Driver Class Initialized
INFO - 2020-08-12 03:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 03:06:16 --> Email Class Initialized
INFO - 2020-08-12 03:06:16 --> Controller Class Initialized
INFO - 2020-08-12 03:06:16 --> Model Class Initialized
INFO - 2020-08-12 03:06:16 --> Model Class Initialized
DEBUG - 2020-08-12 03:06:16 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-12 03:06:17 --> Config Class Initialized
INFO - 2020-08-12 03:06:17 --> Hooks Class Initialized
DEBUG - 2020-08-12 03:06:17 --> UTF-8 Support Enabled
INFO - 2020-08-12 03:06:17 --> Utf8 Class Initialized
INFO - 2020-08-12 03:06:17 --> URI Class Initialized
DEBUG - 2020-08-12 03:06:17 --> No URI present. Default controller set.
INFO - 2020-08-12 03:06:17 --> Router Class Initialized
INFO - 2020-08-12 03:06:17 --> Output Class Initialized
INFO - 2020-08-12 03:06:17 --> Security Class Initialized
DEBUG - 2020-08-12 03:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 03:06:17 --> Input Class Initialized
INFO - 2020-08-12 03:06:17 --> Language Class Initialized
INFO - 2020-08-12 03:06:17 --> Loader Class Initialized
INFO - 2020-08-12 03:06:17 --> Helper loaded: url_helper
INFO - 2020-08-12 03:06:17 --> Database Driver Class Initialized
INFO - 2020-08-12 03:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 03:06:17 --> Email Class Initialized
INFO - 2020-08-12 03:06:17 --> Controller Class Initialized
INFO - 2020-08-12 03:06:17 --> Model Class Initialized
INFO - 2020-08-12 03:06:17 --> Model Class Initialized
DEBUG - 2020-08-12 03:06:17 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-12 03:06:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-12 03:06:17 --> Final output sent to browser
DEBUG - 2020-08-12 03:06:17 --> Total execution time: 0.0217
INFO - 2020-08-12 03:06:17 --> Config Class Initialized
INFO - 2020-08-12 03:06:17 --> Hooks Class Initialized
DEBUG - 2020-08-12 03:06:17 --> UTF-8 Support Enabled
INFO - 2020-08-12 03:06:17 --> Utf8 Class Initialized
INFO - 2020-08-12 03:06:17 --> URI Class Initialized
DEBUG - 2020-08-12 03:06:17 --> No URI present. Default controller set.
INFO - 2020-08-12 03:06:17 --> Router Class Initialized
INFO - 2020-08-12 03:06:17 --> Output Class Initialized
INFO - 2020-08-12 03:06:17 --> Security Class Initialized
DEBUG - 2020-08-12 03:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 03:06:17 --> Input Class Initialized
INFO - 2020-08-12 03:06:17 --> Language Class Initialized
INFO - 2020-08-12 03:06:17 --> Loader Class Initialized
INFO - 2020-08-12 03:06:17 --> Helper loaded: url_helper
INFO - 2020-08-12 03:06:17 --> Database Driver Class Initialized
INFO - 2020-08-12 03:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 03:06:17 --> Email Class Initialized
INFO - 2020-08-12 03:06:17 --> Controller Class Initialized
INFO - 2020-08-12 03:06:17 --> Model Class Initialized
INFO - 2020-08-12 03:06:17 --> Model Class Initialized
DEBUG - 2020-08-12 03:06:17 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-12 03:06:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-12 03:06:17 --> Final output sent to browser
DEBUG - 2020-08-12 03:06:17 --> Total execution time: 0.0196
INFO - 2020-08-12 03:08:43 --> Config Class Initialized
INFO - 2020-08-12 03:08:43 --> Config Class Initialized
INFO - 2020-08-12 03:08:43 --> Hooks Class Initialized
INFO - 2020-08-12 03:08:43 --> Hooks Class Initialized
DEBUG - 2020-08-12 03:08:43 --> UTF-8 Support Enabled
INFO - 2020-08-12 03:08:43 --> Utf8 Class Initialized
DEBUG - 2020-08-12 03:08:43 --> UTF-8 Support Enabled
INFO - 2020-08-12 03:08:43 --> Utf8 Class Initialized
INFO - 2020-08-12 03:08:43 --> URI Class Initialized
INFO - 2020-08-12 03:08:43 --> URI Class Initialized
INFO - 2020-08-12 03:08:43 --> Router Class Initialized
INFO - 2020-08-12 03:08:43 --> Router Class Initialized
INFO - 2020-08-12 03:08:43 --> Output Class Initialized
INFO - 2020-08-12 03:08:43 --> Security Class Initialized
INFO - 2020-08-12 03:08:43 --> Output Class Initialized
DEBUG - 2020-08-12 03:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 03:08:43 --> Input Class Initialized
INFO - 2020-08-12 03:08:43 --> Language Class Initialized
INFO - 2020-08-12 03:08:43 --> Security Class Initialized
DEBUG - 2020-08-12 03:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 03:08:43 --> Loader Class Initialized
INFO - 2020-08-12 03:08:43 --> Input Class Initialized
INFO - 2020-08-12 03:08:43 --> Language Class Initialized
INFO - 2020-08-12 03:08:43 --> Helper loaded: url_helper
INFO - 2020-08-12 03:08:43 --> Loader Class Initialized
INFO - 2020-08-12 03:08:43 --> Helper loaded: url_helper
INFO - 2020-08-12 03:08:43 --> Database Driver Class Initialized
INFO - 2020-08-12 03:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 03:08:43 --> Database Driver Class Initialized
INFO - 2020-08-12 03:08:43 --> Email Class Initialized
INFO - 2020-08-12 03:08:43 --> Controller Class Initialized
INFO - 2020-08-12 03:08:43 --> Model Class Initialized
INFO - 2020-08-12 03:08:43 --> Model Class Initialized
DEBUG - 2020-08-12 03:08:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-12 03:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 03:08:43 --> Email Class Initialized
INFO - 2020-08-12 03:08:43 --> Controller Class Initialized
INFO - 2020-08-12 03:08:43 --> Model Class Initialized
INFO - 2020-08-12 03:08:43 --> Model Class Initialized
DEBUG - 2020-08-12 03:08:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 03:08:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 03:08:43 --> Model Class Initialized
INFO - 2020-08-12 03:08:43 --> Final output sent to browser
DEBUG - 2020-08-12 03:08:43 --> Total execution time: 0.0347
INFO - 2020-08-12 03:08:43 --> Config Class Initialized
INFO - 2020-08-12 03:08:43 --> Hooks Class Initialized
DEBUG - 2020-08-12 03:08:43 --> UTF-8 Support Enabled
INFO - 2020-08-12 03:08:43 --> Utf8 Class Initialized
INFO - 2020-08-12 03:08:43 --> URI Class Initialized
INFO - 2020-08-12 03:08:43 --> Router Class Initialized
INFO - 2020-08-12 03:08:43 --> Output Class Initialized
INFO - 2020-08-12 03:08:43 --> Security Class Initialized
DEBUG - 2020-08-12 03:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 03:08:43 --> Input Class Initialized
INFO - 2020-08-12 03:08:43 --> Language Class Initialized
INFO - 2020-08-12 03:08:43 --> Loader Class Initialized
INFO - 2020-08-12 03:08:43 --> Helper loaded: url_helper
INFO - 2020-08-12 03:08:43 --> Database Driver Class Initialized
INFO - 2020-08-12 03:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 03:08:43 --> Email Class Initialized
INFO - 2020-08-12 03:08:43 --> Controller Class Initialized
DEBUG - 2020-08-12 03:08:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 03:08:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 03:08:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-12 03:08:43 --> Final output sent to browser
DEBUG - 2020-08-12 03:08:43 --> Total execution time: 0.0487
INFO - 2020-08-12 14:57:56 --> Config Class Initialized
INFO - 2020-08-12 14:57:56 --> Hooks Class Initialized
DEBUG - 2020-08-12 14:57:56 --> UTF-8 Support Enabled
INFO - 2020-08-12 14:57:56 --> Utf8 Class Initialized
INFO - 2020-08-12 14:57:56 --> URI Class Initialized
DEBUG - 2020-08-12 14:57:56 --> No URI present. Default controller set.
INFO - 2020-08-12 14:57:56 --> Router Class Initialized
INFO - 2020-08-12 14:57:56 --> Output Class Initialized
INFO - 2020-08-12 14:57:56 --> Security Class Initialized
DEBUG - 2020-08-12 14:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 14:57:56 --> Input Class Initialized
INFO - 2020-08-12 14:57:56 --> Language Class Initialized
INFO - 2020-08-12 14:57:56 --> Loader Class Initialized
INFO - 2020-08-12 14:57:56 --> Helper loaded: url_helper
INFO - 2020-08-12 14:57:56 --> Database Driver Class Initialized
INFO - 2020-08-12 14:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 14:57:56 --> Email Class Initialized
INFO - 2020-08-12 14:57:56 --> Controller Class Initialized
INFO - 2020-08-12 14:57:56 --> Model Class Initialized
INFO - 2020-08-12 14:57:56 --> Model Class Initialized
DEBUG - 2020-08-12 14:57:56 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-12 14:57:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-12 14:57:56 --> Final output sent to browser
DEBUG - 2020-08-12 14:57:56 --> Total execution time: 0.1690
INFO - 2020-08-12 17:00:00 --> Config Class Initialized
INFO - 2020-08-12 17:00:00 --> Hooks Class Initialized
INFO - 2020-08-12 17:00:00 --> Config Class Initialized
INFO - 2020-08-12 17:00:00 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:00:00 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:00:00 --> Utf8 Class Initialized
DEBUG - 2020-08-12 17:00:00 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:00:00 --> Utf8 Class Initialized
INFO - 2020-08-12 17:00:00 --> URI Class Initialized
INFO - 2020-08-12 17:00:00 --> URI Class Initialized
INFO - 2020-08-12 17:00:00 --> Router Class Initialized
INFO - 2020-08-12 17:00:00 --> Router Class Initialized
INFO - 2020-08-12 17:00:00 --> Output Class Initialized
INFO - 2020-08-12 17:00:00 --> Output Class Initialized
INFO - 2020-08-12 17:00:00 --> Security Class Initialized
INFO - 2020-08-12 17:00:00 --> Security Class Initialized
DEBUG - 2020-08-12 17:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:00:00 --> Input Class Initialized
INFO - 2020-08-12 17:00:00 --> Language Class Initialized
DEBUG - 2020-08-12 17:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:00:00 --> Input Class Initialized
INFO - 2020-08-12 17:00:00 --> Language Class Initialized
INFO - 2020-08-12 17:00:00 --> Loader Class Initialized
INFO - 2020-08-12 17:00:00 --> Helper loaded: url_helper
INFO - 2020-08-12 17:00:00 --> Loader Class Initialized
INFO - 2020-08-12 17:00:00 --> Database Driver Class Initialized
INFO - 2020-08-12 17:00:00 --> Helper loaded: url_helper
INFO - 2020-08-12 17:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:00:00 --> Database Driver Class Initialized
INFO - 2020-08-12 17:00:00 --> Email Class Initialized
INFO - 2020-08-12 17:00:00 --> Controller Class Initialized
INFO - 2020-08-12 17:00:00 --> Model Class Initialized
INFO - 2020-08-12 17:00:00 --> Model Class Initialized
DEBUG - 2020-08-12 17:00:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:00:00 --> Email Class Initialized
INFO - 2020-08-12 17:00:00 --> Controller Class Initialized
INFO - 2020-08-12 17:00:00 --> Model Class Initialized
INFO - 2020-08-12 17:00:00 --> Model Class Initialized
DEBUG - 2020-08-12 17:00:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:00:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:00:00 --> Config Class Initialized
INFO - 2020-08-12 17:00:00 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:00:00 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:00:00 --> Utf8 Class Initialized
INFO - 2020-08-12 17:00:00 --> URI Class Initialized
DEBUG - 2020-08-12 17:00:00 --> No URI present. Default controller set.
INFO - 2020-08-12 17:00:00 --> Router Class Initialized
INFO - 2020-08-12 17:00:00 --> Output Class Initialized
INFO - 2020-08-12 17:00:00 --> Security Class Initialized
DEBUG - 2020-08-12 17:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:00:00 --> Input Class Initialized
INFO - 2020-08-12 17:00:00 --> Language Class Initialized
INFO - 2020-08-12 17:00:00 --> Loader Class Initialized
INFO - 2020-08-12 17:00:00 --> Helper loaded: url_helper
INFO - 2020-08-12 17:00:00 --> Database Driver Class Initialized
INFO - 2020-08-12 17:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:00:00 --> Email Class Initialized
INFO - 2020-08-12 17:00:00 --> Controller Class Initialized
INFO - 2020-08-12 17:00:00 --> Model Class Initialized
INFO - 2020-08-12 17:00:00 --> Model Class Initialized
DEBUG - 2020-08-12 17:00:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:00:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-12 17:00:00 --> Final output sent to browser
DEBUG - 2020-08-12 17:00:00 --> Total execution time: 0.0231
INFO - 2020-08-12 17:00:01 --> Config Class Initialized
INFO - 2020-08-12 17:00:01 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:00:01 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:00:01 --> Utf8 Class Initialized
INFO - 2020-08-12 17:00:01 --> URI Class Initialized
DEBUG - 2020-08-12 17:00:01 --> No URI present. Default controller set.
INFO - 2020-08-12 17:00:01 --> Router Class Initialized
INFO - 2020-08-12 17:00:01 --> Output Class Initialized
INFO - 2020-08-12 17:00:01 --> Security Class Initialized
DEBUG - 2020-08-12 17:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:00:01 --> Input Class Initialized
INFO - 2020-08-12 17:00:01 --> Language Class Initialized
INFO - 2020-08-12 17:00:01 --> Loader Class Initialized
INFO - 2020-08-12 17:00:01 --> Helper loaded: url_helper
INFO - 2020-08-12 17:00:01 --> Database Driver Class Initialized
INFO - 2020-08-12 17:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:00:01 --> Email Class Initialized
INFO - 2020-08-12 17:00:01 --> Controller Class Initialized
INFO - 2020-08-12 17:00:01 --> Model Class Initialized
INFO - 2020-08-12 17:00:01 --> Model Class Initialized
DEBUG - 2020-08-12 17:00:01 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:00:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-12 17:00:01 --> Final output sent to browser
DEBUG - 2020-08-12 17:00:01 --> Total execution time: 0.0222
INFO - 2020-08-12 17:00:15 --> Config Class Initialized
INFO - 2020-08-12 17:00:15 --> Config Class Initialized
INFO - 2020-08-12 17:00:15 --> Hooks Class Initialized
INFO - 2020-08-12 17:00:15 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:00:15 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:00:15 --> Utf8 Class Initialized
DEBUG - 2020-08-12 17:00:15 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:00:15 --> Utf8 Class Initialized
INFO - 2020-08-12 17:00:15 --> URI Class Initialized
INFO - 2020-08-12 17:00:15 --> URI Class Initialized
INFO - 2020-08-12 17:00:15 --> Router Class Initialized
INFO - 2020-08-12 17:00:15 --> Router Class Initialized
INFO - 2020-08-12 17:00:15 --> Output Class Initialized
INFO - 2020-08-12 17:00:15 --> Output Class Initialized
INFO - 2020-08-12 17:00:15 --> Security Class Initialized
INFO - 2020-08-12 17:00:15 --> Security Class Initialized
DEBUG - 2020-08-12 17:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:00:15 --> Input Class Initialized
DEBUG - 2020-08-12 17:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:00:15 --> Input Class Initialized
INFO - 2020-08-12 17:00:15 --> Language Class Initialized
INFO - 2020-08-12 17:00:15 --> Language Class Initialized
INFO - 2020-08-12 17:00:15 --> Loader Class Initialized
INFO - 2020-08-12 17:00:15 --> Loader Class Initialized
INFO - 2020-08-12 17:00:15 --> Helper loaded: url_helper
INFO - 2020-08-12 17:00:15 --> Helper loaded: url_helper
INFO - 2020-08-12 17:00:15 --> Database Driver Class Initialized
INFO - 2020-08-12 17:00:15 --> Database Driver Class Initialized
INFO - 2020-08-12 17:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:00:15 --> Email Class Initialized
INFO - 2020-08-12 17:00:15 --> Controller Class Initialized
INFO - 2020-08-12 17:00:15 --> Model Class Initialized
INFO - 2020-08-12 17:00:15 --> Model Class Initialized
DEBUG - 2020-08-12 17:00:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:00:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:00:15 --> Email Class Initialized
INFO - 2020-08-12 17:00:15 --> Controller Class Initialized
INFO - 2020-08-12 17:00:15 --> Model Class Initialized
INFO - 2020-08-12 17:00:15 --> Model Class Initialized
DEBUG - 2020-08-12 17:00:15 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:00:16 --> Config Class Initialized
INFO - 2020-08-12 17:00:16 --> Hooks Class Initialized
INFO - 2020-08-12 17:00:16 --> Config Class Initialized
INFO - 2020-08-12 17:00:16 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:00:16 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:00:16 --> Utf8 Class Initialized
DEBUG - 2020-08-12 17:00:16 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:00:16 --> Utf8 Class Initialized
INFO - 2020-08-12 17:00:16 --> URI Class Initialized
INFO - 2020-08-12 17:00:16 --> URI Class Initialized
INFO - 2020-08-12 17:00:16 --> Router Class Initialized
DEBUG - 2020-08-12 17:00:16 --> No URI present. Default controller set.
INFO - 2020-08-12 17:00:16 --> Router Class Initialized
INFO - 2020-08-12 17:00:16 --> Output Class Initialized
INFO - 2020-08-12 17:00:16 --> Output Class Initialized
INFO - 2020-08-12 17:00:16 --> Security Class Initialized
INFO - 2020-08-12 17:00:16 --> Security Class Initialized
DEBUG - 2020-08-12 17:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:00:16 --> Input Class Initialized
INFO - 2020-08-12 17:00:16 --> Language Class Initialized
DEBUG - 2020-08-12 17:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:00:16 --> Input Class Initialized
INFO - 2020-08-12 17:00:16 --> Language Class Initialized
INFO - 2020-08-12 17:00:16 --> Loader Class Initialized
INFO - 2020-08-12 17:00:16 --> Loader Class Initialized
INFO - 2020-08-12 17:00:16 --> Helper loaded: url_helper
INFO - 2020-08-12 17:00:16 --> Helper loaded: url_helper
INFO - 2020-08-12 17:00:16 --> Database Driver Class Initialized
INFO - 2020-08-12 17:00:16 --> Database Driver Class Initialized
INFO - 2020-08-12 17:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:00:16 --> Email Class Initialized
INFO - 2020-08-12 17:00:16 --> Controller Class Initialized
DEBUG - 2020-08-12 17:00:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:00:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:00:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-12 17:00:16 --> Final output sent to browser
DEBUG - 2020-08-12 17:00:16 --> Total execution time: 0.0279
INFO - 2020-08-12 17:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:00:16 --> Email Class Initialized
INFO - 2020-08-12 17:00:16 --> Controller Class Initialized
INFO - 2020-08-12 17:00:16 --> Model Class Initialized
INFO - 2020-08-12 17:00:16 --> Model Class Initialized
DEBUG - 2020-08-12 17:00:16 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:00:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-12 17:00:16 --> Final output sent to browser
DEBUG - 2020-08-12 17:00:16 --> Total execution time: 0.0324
INFO - 2020-08-12 17:06:08 --> Config Class Initialized
INFO - 2020-08-12 17:06:08 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:06:08 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:06:08 --> Utf8 Class Initialized
INFO - 2020-08-12 17:06:08 --> URI Class Initialized
DEBUG - 2020-08-12 17:06:08 --> No URI present. Default controller set.
INFO - 2020-08-12 17:06:08 --> Router Class Initialized
INFO - 2020-08-12 17:06:08 --> Output Class Initialized
INFO - 2020-08-12 17:06:08 --> Security Class Initialized
DEBUG - 2020-08-12 17:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:06:08 --> Input Class Initialized
INFO - 2020-08-12 17:06:08 --> Language Class Initialized
INFO - 2020-08-12 17:06:08 --> Loader Class Initialized
INFO - 2020-08-12 17:06:08 --> Helper loaded: url_helper
INFO - 2020-08-12 17:06:08 --> Database Driver Class Initialized
INFO - 2020-08-12 17:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:06:08 --> Email Class Initialized
INFO - 2020-08-12 17:06:08 --> Controller Class Initialized
INFO - 2020-08-12 17:06:08 --> Model Class Initialized
INFO - 2020-08-12 17:06:08 --> Model Class Initialized
DEBUG - 2020-08-12 17:06:08 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:06:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-12 17:06:08 --> Final output sent to browser
DEBUG - 2020-08-12 17:06:08 --> Total execution time: 0.0227
INFO - 2020-08-12 17:06:21 --> Config Class Initialized
INFO - 2020-08-12 17:06:21 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:06:21 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:06:21 --> Utf8 Class Initialized
INFO - 2020-08-12 17:06:21 --> URI Class Initialized
INFO - 2020-08-12 17:06:21 --> Router Class Initialized
INFO - 2020-08-12 17:06:21 --> Output Class Initialized
INFO - 2020-08-12 17:06:21 --> Security Class Initialized
DEBUG - 2020-08-12 17:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:06:21 --> Input Class Initialized
INFO - 2020-08-12 17:06:21 --> Language Class Initialized
INFO - 2020-08-12 17:06:21 --> Loader Class Initialized
INFO - 2020-08-12 17:06:21 --> Helper loaded: url_helper
INFO - 2020-08-12 17:06:21 --> Database Driver Class Initialized
INFO - 2020-08-12 17:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:06:21 --> Email Class Initialized
INFO - 2020-08-12 17:06:21 --> Controller Class Initialized
INFO - 2020-08-12 17:06:21 --> Model Class Initialized
INFO - 2020-08-12 17:06:21 --> Model Class Initialized
DEBUG - 2020-08-12 17:06:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:06:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:06:21 --> Model Class Initialized
INFO - 2020-08-12 17:06:21 --> Final output sent to browser
DEBUG - 2020-08-12 17:06:21 --> Total execution time: 0.0268
INFO - 2020-08-12 17:06:21 --> Config Class Initialized
INFO - 2020-08-12 17:06:21 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:06:21 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:06:21 --> Utf8 Class Initialized
INFO - 2020-08-12 17:06:21 --> URI Class Initialized
INFO - 2020-08-12 17:06:21 --> Router Class Initialized
INFO - 2020-08-12 17:06:21 --> Output Class Initialized
INFO - 2020-08-12 17:06:21 --> Security Class Initialized
DEBUG - 2020-08-12 17:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:06:21 --> Input Class Initialized
INFO - 2020-08-12 17:06:21 --> Language Class Initialized
INFO - 2020-08-12 17:06:21 --> Loader Class Initialized
INFO - 2020-08-12 17:06:21 --> Helper loaded: url_helper
INFO - 2020-08-12 17:06:21 --> Database Driver Class Initialized
INFO - 2020-08-12 17:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:06:21 --> Email Class Initialized
INFO - 2020-08-12 17:06:21 --> Controller Class Initialized
INFO - 2020-08-12 17:06:21 --> Model Class Initialized
INFO - 2020-08-12 17:06:21 --> Model Class Initialized
DEBUG - 2020-08-12 17:06:21 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:06:22 --> Config Class Initialized
INFO - 2020-08-12 17:06:22 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:06:22 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:06:22 --> Utf8 Class Initialized
INFO - 2020-08-12 17:06:22 --> URI Class Initialized
INFO - 2020-08-12 17:06:22 --> Router Class Initialized
INFO - 2020-08-12 17:06:22 --> Output Class Initialized
INFO - 2020-08-12 17:06:22 --> Security Class Initialized
DEBUG - 2020-08-12 17:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:06:22 --> Input Class Initialized
INFO - 2020-08-12 17:06:22 --> Language Class Initialized
INFO - 2020-08-12 17:06:22 --> Loader Class Initialized
INFO - 2020-08-12 17:06:22 --> Helper loaded: url_helper
INFO - 2020-08-12 17:06:22 --> Database Driver Class Initialized
INFO - 2020-08-12 17:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:06:22 --> Email Class Initialized
INFO - 2020-08-12 17:06:22 --> Controller Class Initialized
DEBUG - 2020-08-12 17:06:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:06:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:06:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-12 17:06:22 --> Final output sent to browser
DEBUG - 2020-08-12 17:06:22 --> Total execution time: 0.0226
INFO - 2020-08-12 17:06:33 --> Config Class Initialized
INFO - 2020-08-12 17:06:33 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:06:33 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:06:33 --> Utf8 Class Initialized
INFO - 2020-08-12 17:06:33 --> URI Class Initialized
DEBUG - 2020-08-12 17:06:33 --> No URI present. Default controller set.
INFO - 2020-08-12 17:06:33 --> Router Class Initialized
INFO - 2020-08-12 17:06:33 --> Output Class Initialized
INFO - 2020-08-12 17:06:33 --> Security Class Initialized
DEBUG - 2020-08-12 17:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:06:33 --> Input Class Initialized
INFO - 2020-08-12 17:06:33 --> Language Class Initialized
INFO - 2020-08-12 17:06:33 --> Loader Class Initialized
INFO - 2020-08-12 17:06:33 --> Helper loaded: url_helper
INFO - 2020-08-12 17:06:33 --> Database Driver Class Initialized
INFO - 2020-08-12 17:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:06:33 --> Email Class Initialized
INFO - 2020-08-12 17:06:33 --> Controller Class Initialized
INFO - 2020-08-12 17:06:33 --> Model Class Initialized
INFO - 2020-08-12 17:06:33 --> Model Class Initialized
DEBUG - 2020-08-12 17:06:33 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:06:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-12 17:06:33 --> Final output sent to browser
DEBUG - 2020-08-12 17:06:33 --> Total execution time: 0.0265
INFO - 2020-08-12 17:06:36 --> Config Class Initialized
INFO - 2020-08-12 17:06:36 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:06:36 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:06:36 --> Utf8 Class Initialized
INFO - 2020-08-12 17:06:36 --> URI Class Initialized
DEBUG - 2020-08-12 17:06:36 --> No URI present. Default controller set.
INFO - 2020-08-12 17:06:36 --> Router Class Initialized
INFO - 2020-08-12 17:06:36 --> Output Class Initialized
INFO - 2020-08-12 17:06:36 --> Security Class Initialized
DEBUG - 2020-08-12 17:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:06:36 --> Input Class Initialized
INFO - 2020-08-12 17:06:36 --> Language Class Initialized
INFO - 2020-08-12 17:06:36 --> Loader Class Initialized
INFO - 2020-08-12 17:06:36 --> Helper loaded: url_helper
INFO - 2020-08-12 17:06:36 --> Database Driver Class Initialized
INFO - 2020-08-12 17:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:06:36 --> Email Class Initialized
INFO - 2020-08-12 17:06:36 --> Controller Class Initialized
INFO - 2020-08-12 17:06:36 --> Model Class Initialized
INFO - 2020-08-12 17:06:36 --> Model Class Initialized
DEBUG - 2020-08-12 17:06:36 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:06:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-12 17:06:36 --> Final output sent to browser
DEBUG - 2020-08-12 17:06:36 --> Total execution time: 0.0247
INFO - 2020-08-12 17:07:36 --> Config Class Initialized
INFO - 2020-08-12 17:07:36 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:07:36 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:07:36 --> Utf8 Class Initialized
INFO - 2020-08-12 17:07:36 --> URI Class Initialized
INFO - 2020-08-12 17:07:36 --> Router Class Initialized
INFO - 2020-08-12 17:07:36 --> Output Class Initialized
INFO - 2020-08-12 17:07:36 --> Security Class Initialized
DEBUG - 2020-08-12 17:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:07:36 --> Input Class Initialized
INFO - 2020-08-12 17:07:36 --> Language Class Initialized
INFO - 2020-08-12 17:07:36 --> Loader Class Initialized
INFO - 2020-08-12 17:07:36 --> Helper loaded: url_helper
INFO - 2020-08-12 17:07:36 --> Database Driver Class Initialized
INFO - 2020-08-12 17:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:07:36 --> Email Class Initialized
INFO - 2020-08-12 17:07:36 --> Controller Class Initialized
INFO - 2020-08-12 17:07:36 --> Model Class Initialized
INFO - 2020-08-12 17:07:36 --> Model Class Initialized
DEBUG - 2020-08-12 17:07:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:07:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:07:36 --> Model Class Initialized
INFO - 2020-08-12 17:07:36 --> Final output sent to browser
DEBUG - 2020-08-12 17:07:36 --> Total execution time: 0.0271
INFO - 2020-08-12 17:07:36 --> Config Class Initialized
INFO - 2020-08-12 17:07:36 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:07:36 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:07:36 --> Utf8 Class Initialized
INFO - 2020-08-12 17:07:36 --> URI Class Initialized
INFO - 2020-08-12 17:07:36 --> Router Class Initialized
INFO - 2020-08-12 17:07:36 --> Output Class Initialized
INFO - 2020-08-12 17:07:36 --> Security Class Initialized
DEBUG - 2020-08-12 17:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:07:36 --> Input Class Initialized
INFO - 2020-08-12 17:07:36 --> Language Class Initialized
INFO - 2020-08-12 17:07:36 --> Loader Class Initialized
INFO - 2020-08-12 17:07:36 --> Helper loaded: url_helper
INFO - 2020-08-12 17:07:36 --> Database Driver Class Initialized
INFO - 2020-08-12 17:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:07:36 --> Email Class Initialized
INFO - 2020-08-12 17:07:36 --> Controller Class Initialized
INFO - 2020-08-12 17:07:36 --> Model Class Initialized
INFO - 2020-08-12 17:07:36 --> Model Class Initialized
DEBUG - 2020-08-12 17:07:36 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:07:36 --> Config Class Initialized
INFO - 2020-08-12 17:07:36 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:07:36 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:07:36 --> Utf8 Class Initialized
INFO - 2020-08-12 17:07:36 --> URI Class Initialized
DEBUG - 2020-08-12 17:07:36 --> No URI present. Default controller set.
INFO - 2020-08-12 17:07:36 --> Router Class Initialized
INFO - 2020-08-12 17:07:36 --> Output Class Initialized
INFO - 2020-08-12 17:07:36 --> Security Class Initialized
DEBUG - 2020-08-12 17:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:07:36 --> Input Class Initialized
INFO - 2020-08-12 17:07:36 --> Language Class Initialized
INFO - 2020-08-12 17:07:36 --> Loader Class Initialized
INFO - 2020-08-12 17:07:36 --> Helper loaded: url_helper
INFO - 2020-08-12 17:07:36 --> Database Driver Class Initialized
INFO - 2020-08-12 17:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:07:36 --> Email Class Initialized
INFO - 2020-08-12 17:07:36 --> Controller Class Initialized
INFO - 2020-08-12 17:07:36 --> Model Class Initialized
INFO - 2020-08-12 17:07:36 --> Model Class Initialized
DEBUG - 2020-08-12 17:07:36 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:07:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-12 17:07:36 --> Final output sent to browser
DEBUG - 2020-08-12 17:07:36 --> Total execution time: 0.0191
INFO - 2020-08-12 17:07:48 --> Config Class Initialized
INFO - 2020-08-12 17:07:48 --> Hooks Class Initialized
INFO - 2020-08-12 17:07:48 --> Config Class Initialized
INFO - 2020-08-12 17:07:48 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:07:48 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:07:48 --> Utf8 Class Initialized
DEBUG - 2020-08-12 17:07:48 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:07:48 --> Utf8 Class Initialized
INFO - 2020-08-12 17:07:48 --> URI Class Initialized
INFO - 2020-08-12 17:07:48 --> URI Class Initialized
INFO - 2020-08-12 17:07:48 --> Router Class Initialized
INFO - 2020-08-12 17:07:48 --> Router Class Initialized
INFO - 2020-08-12 17:07:48 --> Output Class Initialized
INFO - 2020-08-12 17:07:48 --> Output Class Initialized
INFO - 2020-08-12 17:07:48 --> Security Class Initialized
INFO - 2020-08-12 17:07:48 --> Security Class Initialized
DEBUG - 2020-08-12 17:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:07:48 --> Input Class Initialized
DEBUG - 2020-08-12 17:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:07:48 --> Input Class Initialized
INFO - 2020-08-12 17:07:48 --> Language Class Initialized
INFO - 2020-08-12 17:07:48 --> Language Class Initialized
INFO - 2020-08-12 17:07:48 --> Loader Class Initialized
INFO - 2020-08-12 17:07:48 --> Loader Class Initialized
INFO - 2020-08-12 17:07:48 --> Helper loaded: url_helper
INFO - 2020-08-12 17:07:48 --> Helper loaded: url_helper
INFO - 2020-08-12 17:07:48 --> Database Driver Class Initialized
INFO - 2020-08-12 17:07:48 --> Database Driver Class Initialized
INFO - 2020-08-12 17:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:07:48 --> Email Class Initialized
INFO - 2020-08-12 17:07:48 --> Controller Class Initialized
INFO - 2020-08-12 17:07:48 --> Model Class Initialized
INFO - 2020-08-12 17:07:48 --> Model Class Initialized
DEBUG - 2020-08-12 17:07:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:07:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:07:48 --> Model Class Initialized
INFO - 2020-08-12 17:07:48 --> Final output sent to browser
DEBUG - 2020-08-12 17:07:48 --> Total execution time: 0.3073
INFO - 2020-08-12 17:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:07:48 --> Email Class Initialized
INFO - 2020-08-12 17:07:48 --> Controller Class Initialized
INFO - 2020-08-12 17:07:48 --> Model Class Initialized
INFO - 2020-08-12 17:07:48 --> Model Class Initialized
DEBUG - 2020-08-12 17:07:48 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:07:48 --> Config Class Initialized
INFO - 2020-08-12 17:07:48 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:07:48 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:07:48 --> Utf8 Class Initialized
INFO - 2020-08-12 17:07:48 --> URI Class Initialized
INFO - 2020-08-12 17:07:48 --> Router Class Initialized
INFO - 2020-08-12 17:07:48 --> Output Class Initialized
INFO - 2020-08-12 17:07:48 --> Security Class Initialized
DEBUG - 2020-08-12 17:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:07:48 --> Input Class Initialized
INFO - 2020-08-12 17:07:48 --> Language Class Initialized
INFO - 2020-08-12 17:07:48 --> Loader Class Initialized
INFO - 2020-08-12 17:07:48 --> Helper loaded: url_helper
INFO - 2020-08-12 17:07:48 --> Database Driver Class Initialized
INFO - 2020-08-12 17:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:07:48 --> Email Class Initialized
INFO - 2020-08-12 17:07:48 --> Controller Class Initialized
DEBUG - 2020-08-12 17:07:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:07:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:07:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-12 17:07:48 --> Final output sent to browser
DEBUG - 2020-08-12 17:07:48 --> Total execution time: 0.0238
INFO - 2020-08-12 17:08:05 --> Config Class Initialized
INFO - 2020-08-12 17:08:05 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:08:05 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:08:05 --> Utf8 Class Initialized
INFO - 2020-08-12 17:08:05 --> URI Class Initialized
INFO - 2020-08-12 17:08:05 --> Router Class Initialized
INFO - 2020-08-12 17:08:05 --> Output Class Initialized
INFO - 2020-08-12 17:08:05 --> Security Class Initialized
DEBUG - 2020-08-12 17:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:08:05 --> Input Class Initialized
INFO - 2020-08-12 17:08:05 --> Language Class Initialized
INFO - 2020-08-12 17:08:05 --> Loader Class Initialized
INFO - 2020-08-12 17:08:05 --> Helper loaded: url_helper
INFO - 2020-08-12 17:08:05 --> Database Driver Class Initialized
INFO - 2020-08-12 17:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:08:05 --> Email Class Initialized
INFO - 2020-08-12 17:08:05 --> Controller Class Initialized
DEBUG - 2020-08-12 17:08:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:08:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:08:05 --> Model Class Initialized
INFO - 2020-08-12 17:08:05 --> Model Class Initialized
INFO - 2020-08-12 17:08:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-12 17:08:05 --> Final output sent to browser
DEBUG - 2020-08-12 17:08:05 --> Total execution time: 0.0400
INFO - 2020-08-12 17:08:16 --> Config Class Initialized
INFO - 2020-08-12 17:08:16 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:08:16 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:08:16 --> Utf8 Class Initialized
INFO - 2020-08-12 17:08:16 --> URI Class Initialized
DEBUG - 2020-08-12 17:08:16 --> No URI present. Default controller set.
INFO - 2020-08-12 17:08:16 --> Router Class Initialized
INFO - 2020-08-12 17:08:16 --> Output Class Initialized
INFO - 2020-08-12 17:08:16 --> Security Class Initialized
DEBUG - 2020-08-12 17:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:08:16 --> Input Class Initialized
INFO - 2020-08-12 17:08:16 --> Language Class Initialized
INFO - 2020-08-12 17:08:16 --> Loader Class Initialized
INFO - 2020-08-12 17:08:16 --> Helper loaded: url_helper
INFO - 2020-08-12 17:08:16 --> Database Driver Class Initialized
INFO - 2020-08-12 17:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:08:16 --> Email Class Initialized
INFO - 2020-08-12 17:08:16 --> Controller Class Initialized
INFO - 2020-08-12 17:08:16 --> Model Class Initialized
INFO - 2020-08-12 17:08:16 --> Model Class Initialized
DEBUG - 2020-08-12 17:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:08:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-12 17:08:16 --> Final output sent to browser
DEBUG - 2020-08-12 17:08:16 --> Total execution time: 0.0325
INFO - 2020-08-12 17:09:12 --> Config Class Initialized
INFO - 2020-08-12 17:09:12 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:09:12 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:09:12 --> Utf8 Class Initialized
INFO - 2020-08-12 17:09:12 --> URI Class Initialized
INFO - 2020-08-12 17:09:12 --> Router Class Initialized
INFO - 2020-08-12 17:09:12 --> Output Class Initialized
INFO - 2020-08-12 17:09:12 --> Security Class Initialized
DEBUG - 2020-08-12 17:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:09:12 --> Input Class Initialized
INFO - 2020-08-12 17:09:12 --> Language Class Initialized
INFO - 2020-08-12 17:09:12 --> Loader Class Initialized
INFO - 2020-08-12 17:09:12 --> Helper loaded: url_helper
INFO - 2020-08-12 17:09:12 --> Database Driver Class Initialized
INFO - 2020-08-12 17:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:09:12 --> Email Class Initialized
INFO - 2020-08-12 17:09:12 --> Controller Class Initialized
INFO - 2020-08-12 17:09:12 --> Model Class Initialized
INFO - 2020-08-12 17:09:12 --> Model Class Initialized
DEBUG - 2020-08-12 17:09:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:09:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:09:12 --> Model Class Initialized
INFO - 2020-08-12 17:09:12 --> Final output sent to browser
DEBUG - 2020-08-12 17:09:12 --> Total execution time: 0.0222
INFO - 2020-08-12 17:09:12 --> Config Class Initialized
INFO - 2020-08-12 17:09:12 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:09:12 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:09:12 --> Utf8 Class Initialized
INFO - 2020-08-12 17:09:12 --> URI Class Initialized
INFO - 2020-08-12 17:09:12 --> Router Class Initialized
INFO - 2020-08-12 17:09:12 --> Output Class Initialized
INFO - 2020-08-12 17:09:12 --> Security Class Initialized
DEBUG - 2020-08-12 17:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:09:12 --> Input Class Initialized
INFO - 2020-08-12 17:09:12 --> Language Class Initialized
INFO - 2020-08-12 17:09:12 --> Loader Class Initialized
INFO - 2020-08-12 17:09:12 --> Helper loaded: url_helper
INFO - 2020-08-12 17:09:12 --> Database Driver Class Initialized
INFO - 2020-08-12 17:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:09:12 --> Email Class Initialized
INFO - 2020-08-12 17:09:12 --> Controller Class Initialized
INFO - 2020-08-12 17:09:12 --> Model Class Initialized
INFO - 2020-08-12 17:09:12 --> Model Class Initialized
DEBUG - 2020-08-12 17:09:12 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:09:13 --> Config Class Initialized
INFO - 2020-08-12 17:09:13 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:09:13 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:09:13 --> Utf8 Class Initialized
INFO - 2020-08-12 17:09:13 --> URI Class Initialized
INFO - 2020-08-12 17:09:13 --> Router Class Initialized
INFO - 2020-08-12 17:09:13 --> Output Class Initialized
INFO - 2020-08-12 17:09:13 --> Security Class Initialized
DEBUG - 2020-08-12 17:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:09:13 --> Input Class Initialized
INFO - 2020-08-12 17:09:13 --> Language Class Initialized
INFO - 2020-08-12 17:09:13 --> Loader Class Initialized
INFO - 2020-08-12 17:09:13 --> Helper loaded: url_helper
INFO - 2020-08-12 17:09:13 --> Database Driver Class Initialized
INFO - 2020-08-12 17:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:09:13 --> Email Class Initialized
INFO - 2020-08-12 17:09:13 --> Controller Class Initialized
DEBUG - 2020-08-12 17:09:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:09:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:09:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-12 17:09:13 --> Final output sent to browser
DEBUG - 2020-08-12 17:09:13 --> Total execution time: 0.0215
INFO - 2020-08-12 17:10:50 --> Config Class Initialized
INFO - 2020-08-12 17:10:50 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:10:50 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:10:50 --> Utf8 Class Initialized
INFO - 2020-08-12 17:10:50 --> URI Class Initialized
INFO - 2020-08-12 17:10:50 --> Router Class Initialized
INFO - 2020-08-12 17:10:50 --> Output Class Initialized
INFO - 2020-08-12 17:10:50 --> Security Class Initialized
DEBUG - 2020-08-12 17:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:10:50 --> Input Class Initialized
INFO - 2020-08-12 17:10:50 --> Language Class Initialized
INFO - 2020-08-12 17:10:50 --> Loader Class Initialized
INFO - 2020-08-12 17:10:50 --> Helper loaded: url_helper
INFO - 2020-08-12 17:10:50 --> Database Driver Class Initialized
INFO - 2020-08-12 17:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:10:50 --> Email Class Initialized
INFO - 2020-08-12 17:10:50 --> Controller Class Initialized
DEBUG - 2020-08-12 17:10:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:10:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:10:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-12 17:10:50 --> Final output sent to browser
DEBUG - 2020-08-12 17:10:50 --> Total execution time: 0.0248
INFO - 2020-08-12 17:18:15 --> Config Class Initialized
INFO - 2020-08-12 17:18:15 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:18:15 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:18:15 --> Utf8 Class Initialized
INFO - 2020-08-12 17:18:15 --> URI Class Initialized
INFO - 2020-08-12 17:18:15 --> Router Class Initialized
INFO - 2020-08-12 17:18:15 --> Output Class Initialized
INFO - 2020-08-12 17:18:15 --> Security Class Initialized
DEBUG - 2020-08-12 17:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:18:15 --> Input Class Initialized
INFO - 2020-08-12 17:18:15 --> Language Class Initialized
INFO - 2020-08-12 17:18:15 --> Loader Class Initialized
INFO - 2020-08-12 17:18:15 --> Helper loaded: url_helper
INFO - 2020-08-12 17:18:15 --> Database Driver Class Initialized
INFO - 2020-08-12 17:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:18:15 --> Email Class Initialized
INFO - 2020-08-12 17:18:15 --> Controller Class Initialized
DEBUG - 2020-08-12 17:18:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:18:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:18:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-12 17:18:15 --> Final output sent to browser
DEBUG - 2020-08-12 17:18:15 --> Total execution time: 0.0231
INFO - 2020-08-12 17:18:18 --> Config Class Initialized
INFO - 2020-08-12 17:18:18 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:18:18 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:18:18 --> Utf8 Class Initialized
INFO - 2020-08-12 17:18:18 --> URI Class Initialized
INFO - 2020-08-12 17:18:18 --> Router Class Initialized
INFO - 2020-08-12 17:18:18 --> Output Class Initialized
INFO - 2020-08-12 17:18:18 --> Security Class Initialized
DEBUG - 2020-08-12 17:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:18:18 --> Input Class Initialized
INFO - 2020-08-12 17:18:18 --> Language Class Initialized
INFO - 2020-08-12 17:18:18 --> Loader Class Initialized
INFO - 2020-08-12 17:18:18 --> Helper loaded: url_helper
INFO - 2020-08-12 17:18:18 --> Database Driver Class Initialized
INFO - 2020-08-12 17:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:18:18 --> Email Class Initialized
INFO - 2020-08-12 17:18:18 --> Controller Class Initialized
DEBUG - 2020-08-12 17:18:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:18:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:18:18 --> Model Class Initialized
INFO - 2020-08-12 17:18:18 --> Model Class Initialized
INFO - 2020-08-12 17:18:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-12 17:18:18 --> Final output sent to browser
DEBUG - 2020-08-12 17:18:18 --> Total execution time: 0.0717
INFO - 2020-08-12 17:19:19 --> Config Class Initialized
INFO - 2020-08-12 17:19:19 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:19:19 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:19:19 --> Utf8 Class Initialized
INFO - 2020-08-12 17:19:19 --> URI Class Initialized
INFO - 2020-08-12 17:19:19 --> Router Class Initialized
INFO - 2020-08-12 17:19:19 --> Output Class Initialized
INFO - 2020-08-12 17:19:19 --> Security Class Initialized
DEBUG - 2020-08-12 17:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:19:19 --> Input Class Initialized
INFO - 2020-08-12 17:19:19 --> Language Class Initialized
INFO - 2020-08-12 17:19:19 --> Loader Class Initialized
INFO - 2020-08-12 17:19:19 --> Helper loaded: url_helper
INFO - 2020-08-12 17:19:19 --> Database Driver Class Initialized
INFO - 2020-08-12 17:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:19:19 --> Email Class Initialized
INFO - 2020-08-12 17:19:19 --> Controller Class Initialized
DEBUG - 2020-08-12 17:19:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:19:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:19:19 --> Model Class Initialized
INFO - 2020-08-12 17:19:19 --> Model Class Initialized
INFO - 2020-08-12 17:19:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-12 17:19:19 --> Final output sent to browser
DEBUG - 2020-08-12 17:19:19 --> Total execution time: 0.0259
INFO - 2020-08-12 17:19:31 --> Config Class Initialized
INFO - 2020-08-12 17:19:31 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:19:31 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:19:31 --> Utf8 Class Initialized
INFO - 2020-08-12 17:19:31 --> URI Class Initialized
INFO - 2020-08-12 17:19:31 --> Router Class Initialized
INFO - 2020-08-12 17:19:31 --> Output Class Initialized
INFO - 2020-08-12 17:19:31 --> Security Class Initialized
DEBUG - 2020-08-12 17:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:19:31 --> Input Class Initialized
INFO - 2020-08-12 17:19:31 --> Language Class Initialized
INFO - 2020-08-12 17:19:31 --> Loader Class Initialized
INFO - 2020-08-12 17:19:31 --> Helper loaded: url_helper
INFO - 2020-08-12 17:19:31 --> Database Driver Class Initialized
INFO - 2020-08-12 17:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:19:31 --> Email Class Initialized
INFO - 2020-08-12 17:19:31 --> Controller Class Initialized
DEBUG - 2020-08-12 17:19:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:19:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:19:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-12 17:19:31 --> Final output sent to browser
DEBUG - 2020-08-12 17:19:31 --> Total execution time: 0.0225
INFO - 2020-08-12 17:19:36 --> Config Class Initialized
INFO - 2020-08-12 17:19:36 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:19:36 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:19:36 --> Utf8 Class Initialized
INFO - 2020-08-12 17:19:36 --> URI Class Initialized
INFO - 2020-08-12 17:19:36 --> Router Class Initialized
INFO - 2020-08-12 17:19:36 --> Output Class Initialized
INFO - 2020-08-12 17:19:36 --> Security Class Initialized
DEBUG - 2020-08-12 17:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:19:36 --> Input Class Initialized
INFO - 2020-08-12 17:19:36 --> Language Class Initialized
INFO - 2020-08-12 17:19:36 --> Loader Class Initialized
INFO - 2020-08-12 17:19:36 --> Helper loaded: url_helper
INFO - 2020-08-12 17:19:36 --> Database Driver Class Initialized
INFO - 2020-08-12 17:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:19:36 --> Email Class Initialized
INFO - 2020-08-12 17:19:36 --> Controller Class Initialized
DEBUG - 2020-08-12 17:19:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:19:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:19:36 --> Model Class Initialized
INFO - 2020-08-12 17:19:36 --> Model Class Initialized
INFO - 2020-08-12 17:19:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-12 17:19:36 --> Final output sent to browser
DEBUG - 2020-08-12 17:19:36 --> Total execution time: 0.0221
INFO - 2020-08-12 17:25:13 --> Config Class Initialized
INFO - 2020-08-12 17:25:13 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:25:13 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:25:13 --> Utf8 Class Initialized
INFO - 2020-08-12 17:25:13 --> URI Class Initialized
INFO - 2020-08-12 17:25:13 --> Router Class Initialized
INFO - 2020-08-12 17:25:13 --> Output Class Initialized
INFO - 2020-08-12 17:25:13 --> Security Class Initialized
DEBUG - 2020-08-12 17:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:25:13 --> Input Class Initialized
INFO - 2020-08-12 17:25:13 --> Language Class Initialized
INFO - 2020-08-12 17:25:13 --> Loader Class Initialized
INFO - 2020-08-12 17:25:13 --> Helper loaded: url_helper
INFO - 2020-08-12 17:25:13 --> Database Driver Class Initialized
INFO - 2020-08-12 17:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:25:13 --> Config Class Initialized
INFO - 2020-08-12 17:25:13 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:25:13 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:25:13 --> Utf8 Class Initialized
INFO - 2020-08-12 17:25:13 --> Email Class Initialized
INFO - 2020-08-12 17:25:13 --> Controller Class Initialized
DEBUG - 2020-08-12 17:25:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:25:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:25:13 --> Model Class Initialized
INFO - 2020-08-12 17:25:13 --> Model Class Initialized
INFO - 2020-08-12 17:25:13 --> URI Class Initialized
INFO - 2020-08-12 17:25:13 --> Router Class Initialized
INFO - 2020-08-12 17:25:13 --> Output Class Initialized
INFO - 2020-08-12 17:25:13 --> Security Class Initialized
DEBUG - 2020-08-12 17:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:25:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-12 17:25:13 --> Input Class Initialized
INFO - 2020-08-12 17:25:13 --> Final output sent to browser
DEBUG - 2020-08-12 17:25:13 --> Total execution time: 0.0367
INFO - 2020-08-12 17:25:13 --> Language Class Initialized
INFO - 2020-08-12 17:25:13 --> Loader Class Initialized
INFO - 2020-08-12 17:25:13 --> Helper loaded: url_helper
INFO - 2020-08-12 17:25:13 --> Database Driver Class Initialized
INFO - 2020-08-12 17:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:25:13 --> Email Class Initialized
INFO - 2020-08-12 17:25:13 --> Controller Class Initialized
DEBUG - 2020-08-12 17:25:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:25:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:25:13 --> Model Class Initialized
INFO - 2020-08-12 17:25:13 --> Config Class Initialized
INFO - 2020-08-12 17:25:13 --> Hooks Class Initialized
INFO - 2020-08-12 17:25:13 --> Model Class Initialized
DEBUG - 2020-08-12 17:25:13 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:25:13 --> Utf8 Class Initialized
INFO - 2020-08-12 17:25:13 --> URI Class Initialized
INFO - 2020-08-12 17:25:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-12 17:25:13 --> Final output sent to browser
DEBUG - 2020-08-12 17:25:13 --> Total execution time: 0.0277
INFO - 2020-08-12 17:25:13 --> Router Class Initialized
INFO - 2020-08-12 17:25:13 --> Output Class Initialized
INFO - 2020-08-12 17:25:13 --> Security Class Initialized
DEBUG - 2020-08-12 17:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:25:13 --> Input Class Initialized
INFO - 2020-08-12 17:25:13 --> Language Class Initialized
INFO - 2020-08-12 17:25:13 --> Loader Class Initialized
INFO - 2020-08-12 17:25:13 --> Helper loaded: url_helper
INFO - 2020-08-12 17:25:13 --> Database Driver Class Initialized
INFO - 2020-08-12 17:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:25:13 --> Email Class Initialized
INFO - 2020-08-12 17:25:13 --> Controller Class Initialized
DEBUG - 2020-08-12 17:25:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:25:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:25:13 --> Model Class Initialized
INFO - 2020-08-12 17:25:13 --> Model Class Initialized
INFO - 2020-08-12 17:25:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-12 17:25:13 --> Final output sent to browser
DEBUG - 2020-08-12 17:25:13 --> Total execution time: 0.0298
INFO - 2020-08-12 17:25:17 --> Config Class Initialized
INFO - 2020-08-12 17:25:17 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:25:17 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:25:17 --> Utf8 Class Initialized
INFO - 2020-08-12 17:25:17 --> URI Class Initialized
INFO - 2020-08-12 17:25:17 --> Router Class Initialized
INFO - 2020-08-12 17:25:17 --> Output Class Initialized
INFO - 2020-08-12 17:25:17 --> Security Class Initialized
DEBUG - 2020-08-12 17:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:25:17 --> Input Class Initialized
INFO - 2020-08-12 17:25:17 --> Language Class Initialized
INFO - 2020-08-12 17:25:17 --> Loader Class Initialized
INFO - 2020-08-12 17:25:17 --> Helper loaded: url_helper
INFO - 2020-08-12 17:25:17 --> Database Driver Class Initialized
INFO - 2020-08-12 17:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:25:17 --> Email Class Initialized
INFO - 2020-08-12 17:25:17 --> Controller Class Initialized
DEBUG - 2020-08-12 17:25:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:25:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:25:17 --> Model Class Initialized
INFO - 2020-08-12 17:25:17 --> Model Class Initialized
INFO - 2020-08-12 17:25:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-12 17:25:17 --> Final output sent to browser
DEBUG - 2020-08-12 17:25:17 --> Total execution time: 0.0217
INFO - 2020-08-12 17:25:23 --> Config Class Initialized
INFO - 2020-08-12 17:25:23 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:25:23 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:25:23 --> Utf8 Class Initialized
INFO - 2020-08-12 17:25:23 --> URI Class Initialized
DEBUG - 2020-08-12 17:25:23 --> No URI present. Default controller set.
INFO - 2020-08-12 17:25:23 --> Router Class Initialized
INFO - 2020-08-12 17:25:23 --> Output Class Initialized
INFO - 2020-08-12 17:25:23 --> Security Class Initialized
DEBUG - 2020-08-12 17:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:25:23 --> Input Class Initialized
INFO - 2020-08-12 17:25:23 --> Language Class Initialized
INFO - 2020-08-12 17:25:23 --> Loader Class Initialized
INFO - 2020-08-12 17:25:23 --> Helper loaded: url_helper
INFO - 2020-08-12 17:25:23 --> Database Driver Class Initialized
INFO - 2020-08-12 17:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:25:23 --> Email Class Initialized
INFO - 2020-08-12 17:25:23 --> Controller Class Initialized
INFO - 2020-08-12 17:25:23 --> Model Class Initialized
INFO - 2020-08-12 17:25:23 --> Model Class Initialized
DEBUG - 2020-08-12 17:25:23 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:25:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-12 17:25:23 --> Final output sent to browser
DEBUG - 2020-08-12 17:25:23 --> Total execution time: 0.0258
INFO - 2020-08-12 17:25:33 --> Config Class Initialized
INFO - 2020-08-12 17:25:33 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:25:33 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:25:33 --> Utf8 Class Initialized
INFO - 2020-08-12 17:25:33 --> URI Class Initialized
INFO - 2020-08-12 17:25:33 --> Router Class Initialized
INFO - 2020-08-12 17:25:33 --> Output Class Initialized
INFO - 2020-08-12 17:25:33 --> Security Class Initialized
DEBUG - 2020-08-12 17:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:25:33 --> Input Class Initialized
INFO - 2020-08-12 17:25:33 --> Language Class Initialized
INFO - 2020-08-12 17:25:33 --> Loader Class Initialized
INFO - 2020-08-12 17:25:33 --> Helper loaded: url_helper
INFO - 2020-08-12 17:25:33 --> Database Driver Class Initialized
INFO - 2020-08-12 17:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:25:33 --> Email Class Initialized
INFO - 2020-08-12 17:25:33 --> Controller Class Initialized
INFO - 2020-08-12 17:25:33 --> Model Class Initialized
INFO - 2020-08-12 17:25:33 --> Model Class Initialized
DEBUG - 2020-08-12 17:25:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:25:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:25:33 --> Model Class Initialized
INFO - 2020-08-12 17:25:33 --> Final output sent to browser
DEBUG - 2020-08-12 17:25:33 --> Total execution time: 0.0275
INFO - 2020-08-12 17:25:33 --> Config Class Initialized
INFO - 2020-08-12 17:25:33 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:25:33 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:25:33 --> Utf8 Class Initialized
INFO - 2020-08-12 17:25:33 --> URI Class Initialized
INFO - 2020-08-12 17:25:33 --> Router Class Initialized
INFO - 2020-08-12 17:25:33 --> Output Class Initialized
INFO - 2020-08-12 17:25:33 --> Security Class Initialized
DEBUG - 2020-08-12 17:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:25:33 --> Input Class Initialized
INFO - 2020-08-12 17:25:33 --> Language Class Initialized
INFO - 2020-08-12 17:25:33 --> Loader Class Initialized
INFO - 2020-08-12 17:25:33 --> Helper loaded: url_helper
INFO - 2020-08-12 17:25:33 --> Database Driver Class Initialized
INFO - 2020-08-12 17:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:25:33 --> Email Class Initialized
INFO - 2020-08-12 17:25:33 --> Controller Class Initialized
INFO - 2020-08-12 17:25:33 --> Model Class Initialized
INFO - 2020-08-12 17:25:33 --> Model Class Initialized
DEBUG - 2020-08-12 17:25:33 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:25:33 --> Config Class Initialized
INFO - 2020-08-12 17:25:33 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:25:33 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:25:33 --> Utf8 Class Initialized
INFO - 2020-08-12 17:25:33 --> URI Class Initialized
INFO - 2020-08-12 17:25:33 --> Router Class Initialized
INFO - 2020-08-12 17:25:33 --> Output Class Initialized
INFO - 2020-08-12 17:25:33 --> Security Class Initialized
DEBUG - 2020-08-12 17:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:25:33 --> Input Class Initialized
INFO - 2020-08-12 17:25:33 --> Language Class Initialized
INFO - 2020-08-12 17:25:33 --> Loader Class Initialized
INFO - 2020-08-12 17:25:33 --> Helper loaded: url_helper
INFO - 2020-08-12 17:25:33 --> Database Driver Class Initialized
INFO - 2020-08-12 17:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:25:33 --> Email Class Initialized
INFO - 2020-08-12 17:25:33 --> Controller Class Initialized
DEBUG - 2020-08-12 17:25:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:25:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:25:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-12 17:25:33 --> Final output sent to browser
DEBUG - 2020-08-12 17:25:33 --> Total execution time: 0.0227
INFO - 2020-08-12 17:25:45 --> Config Class Initialized
INFO - 2020-08-12 17:25:45 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:25:45 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:25:45 --> Utf8 Class Initialized
INFO - 2020-08-12 17:25:45 --> URI Class Initialized
INFO - 2020-08-12 17:25:45 --> Router Class Initialized
INFO - 2020-08-12 17:25:45 --> Output Class Initialized
INFO - 2020-08-12 17:25:45 --> Security Class Initialized
DEBUG - 2020-08-12 17:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:25:45 --> Input Class Initialized
INFO - 2020-08-12 17:25:45 --> Language Class Initialized
INFO - 2020-08-12 17:25:45 --> Loader Class Initialized
INFO - 2020-08-12 17:25:45 --> Helper loaded: url_helper
INFO - 2020-08-12 17:25:45 --> Database Driver Class Initialized
INFO - 2020-08-12 17:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:25:45 --> Email Class Initialized
INFO - 2020-08-12 17:25:45 --> Controller Class Initialized
DEBUG - 2020-08-12 17:25:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:25:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:25:45 --> Model Class Initialized
INFO - 2020-08-12 17:25:45 --> Model Class Initialized
INFO - 2020-08-12 17:25:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-12 17:25:45 --> Final output sent to browser
DEBUG - 2020-08-12 17:25:45 --> Total execution time: 0.0259
INFO - 2020-08-12 17:25:48 --> Config Class Initialized
INFO - 2020-08-12 17:25:48 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:25:48 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:25:48 --> Utf8 Class Initialized
INFO - 2020-08-12 17:25:48 --> URI Class Initialized
INFO - 2020-08-12 17:25:48 --> Router Class Initialized
INFO - 2020-08-12 17:25:48 --> Output Class Initialized
INFO - 2020-08-12 17:25:48 --> Security Class Initialized
DEBUG - 2020-08-12 17:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:25:48 --> Input Class Initialized
INFO - 2020-08-12 17:25:48 --> Language Class Initialized
ERROR - 2020-08-12 17:25:48 --> 404 Page Not Found: Dealer/client_module
INFO - 2020-08-12 17:26:05 --> Config Class Initialized
INFO - 2020-08-12 17:26:05 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:26:05 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:26:05 --> Utf8 Class Initialized
INFO - 2020-08-12 17:26:05 --> URI Class Initialized
INFO - 2020-08-12 17:26:05 --> Router Class Initialized
INFO - 2020-08-12 17:26:05 --> Output Class Initialized
INFO - 2020-08-12 17:26:05 --> Security Class Initialized
DEBUG - 2020-08-12 17:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:26:05 --> Input Class Initialized
INFO - 2020-08-12 17:26:05 --> Language Class Initialized
INFO - 2020-08-12 17:26:05 --> Loader Class Initialized
INFO - 2020-08-12 17:26:05 --> Helper loaded: url_helper
INFO - 2020-08-12 17:26:05 --> Database Driver Class Initialized
INFO - 2020-08-12 17:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:26:05 --> Email Class Initialized
INFO - 2020-08-12 17:26:05 --> Controller Class Initialized
DEBUG - 2020-08-12 17:26:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:26:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:26:05 --> Model Class Initialized
INFO - 2020-08-12 17:26:05 --> Model Class Initialized
INFO - 2020-08-12 17:26:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-12 17:26:05 --> Final output sent to browser
DEBUG - 2020-08-12 17:26:05 --> Total execution time: 0.0219
INFO - 2020-08-12 17:26:10 --> Config Class Initialized
INFO - 2020-08-12 17:26:10 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:26:10 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:26:10 --> Utf8 Class Initialized
INFO - 2020-08-12 17:26:10 --> URI Class Initialized
INFO - 2020-08-12 17:26:10 --> Router Class Initialized
INFO - 2020-08-12 17:26:10 --> Output Class Initialized
INFO - 2020-08-12 17:26:10 --> Security Class Initialized
DEBUG - 2020-08-12 17:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:26:10 --> Input Class Initialized
INFO - 2020-08-12 17:26:10 --> Language Class Initialized
ERROR - 2020-08-12 17:26:10 --> 404 Page Not Found: Dealer/client_module
INFO - 2020-08-12 17:26:14 --> Config Class Initialized
INFO - 2020-08-12 17:26:14 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:26:14 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:26:14 --> Utf8 Class Initialized
INFO - 2020-08-12 17:26:14 --> URI Class Initialized
INFO - 2020-08-12 17:26:14 --> Router Class Initialized
INFO - 2020-08-12 17:26:14 --> Output Class Initialized
INFO - 2020-08-12 17:26:14 --> Security Class Initialized
DEBUG - 2020-08-12 17:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:26:14 --> Input Class Initialized
INFO - 2020-08-12 17:26:14 --> Language Class Initialized
INFO - 2020-08-12 17:26:14 --> Loader Class Initialized
INFO - 2020-08-12 17:26:14 --> Helper loaded: url_helper
INFO - 2020-08-12 17:26:14 --> Database Driver Class Initialized
INFO - 2020-08-12 17:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:26:14 --> Email Class Initialized
INFO - 2020-08-12 17:26:14 --> Controller Class Initialized
DEBUG - 2020-08-12 17:26:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:26:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:26:14 --> Model Class Initialized
INFO - 2020-08-12 17:26:14 --> Model Class Initialized
INFO - 2020-08-12 17:26:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-12 17:26:14 --> Final output sent to browser
DEBUG - 2020-08-12 17:26:14 --> Total execution time: 0.0251
INFO - 2020-08-12 17:26:35 --> Config Class Initialized
INFO - 2020-08-12 17:26:35 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:26:35 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:26:35 --> Utf8 Class Initialized
INFO - 2020-08-12 17:26:35 --> URI Class Initialized
INFO - 2020-08-12 17:26:35 --> Router Class Initialized
INFO - 2020-08-12 17:26:35 --> Output Class Initialized
INFO - 2020-08-12 17:26:35 --> Security Class Initialized
DEBUG - 2020-08-12 17:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:26:35 --> Input Class Initialized
INFO - 2020-08-12 17:26:35 --> Language Class Initialized
INFO - 2020-08-12 17:26:35 --> Loader Class Initialized
INFO - 2020-08-12 17:26:35 --> Helper loaded: url_helper
INFO - 2020-08-12 17:26:35 --> Database Driver Class Initialized
INFO - 2020-08-12 17:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:26:35 --> Email Class Initialized
INFO - 2020-08-12 17:26:35 --> Controller Class Initialized
DEBUG - 2020-08-12 17:26:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:26:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:26:35 --> Model Class Initialized
INFO - 2020-08-12 17:26:35 --> Model Class Initialized
INFO - 2020-08-12 17:26:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-12 17:26:35 --> Final output sent to browser
DEBUG - 2020-08-12 17:26:35 --> Total execution time: 0.1490
INFO - 2020-08-12 17:26:37 --> Config Class Initialized
INFO - 2020-08-12 17:26:37 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:26:37 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:26:37 --> Utf8 Class Initialized
INFO - 2020-08-12 17:26:37 --> URI Class Initialized
INFO - 2020-08-12 17:26:37 --> Router Class Initialized
INFO - 2020-08-12 17:26:37 --> Output Class Initialized
INFO - 2020-08-12 17:26:37 --> Security Class Initialized
DEBUG - 2020-08-12 17:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:26:37 --> Input Class Initialized
INFO - 2020-08-12 17:26:37 --> Language Class Initialized
INFO - 2020-08-12 17:26:37 --> Loader Class Initialized
INFO - 2020-08-12 17:26:37 --> Helper loaded: url_helper
INFO - 2020-08-12 17:26:37 --> Database Driver Class Initialized
INFO - 2020-08-12 17:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:26:37 --> Email Class Initialized
INFO - 2020-08-12 17:26:37 --> Controller Class Initialized
DEBUG - 2020-08-12 17:26:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:26:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:26:37 --> Model Class Initialized
INFO - 2020-08-12 17:26:37 --> Model Class Initialized
INFO - 2020-08-12 17:26:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-12 17:26:37 --> Final output sent to browser
DEBUG - 2020-08-12 17:26:37 --> Total execution time: 0.0244
INFO - 2020-08-12 17:26:40 --> Config Class Initialized
INFO - 2020-08-12 17:26:40 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:26:40 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:26:40 --> Utf8 Class Initialized
INFO - 2020-08-12 17:26:40 --> URI Class Initialized
INFO - 2020-08-12 17:26:40 --> Router Class Initialized
INFO - 2020-08-12 17:26:40 --> Output Class Initialized
INFO - 2020-08-12 17:26:40 --> Security Class Initialized
DEBUG - 2020-08-12 17:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:26:40 --> Input Class Initialized
INFO - 2020-08-12 17:26:40 --> Language Class Initialized
INFO - 2020-08-12 17:26:40 --> Loader Class Initialized
INFO - 2020-08-12 17:26:40 --> Helper loaded: url_helper
INFO - 2020-08-12 17:26:40 --> Database Driver Class Initialized
INFO - 2020-08-12 17:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:26:40 --> Email Class Initialized
INFO - 2020-08-12 17:26:40 --> Controller Class Initialized
DEBUG - 2020-08-12 17:26:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:26:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:26:40 --> Model Class Initialized
INFO - 2020-08-12 17:26:40 --> Model Class Initialized
INFO - 2020-08-12 17:26:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-12 17:26:40 --> Final output sent to browser
DEBUG - 2020-08-12 17:26:40 --> Total execution time: 0.1539
INFO - 2020-08-12 17:26:42 --> Config Class Initialized
INFO - 2020-08-12 17:26:42 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:26:42 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:26:42 --> Utf8 Class Initialized
INFO - 2020-08-12 17:26:42 --> URI Class Initialized
INFO - 2020-08-12 17:26:42 --> Router Class Initialized
INFO - 2020-08-12 17:26:42 --> Output Class Initialized
INFO - 2020-08-12 17:26:42 --> Security Class Initialized
DEBUG - 2020-08-12 17:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:26:42 --> Input Class Initialized
INFO - 2020-08-12 17:26:42 --> Language Class Initialized
INFO - 2020-08-12 17:26:42 --> Loader Class Initialized
INFO - 2020-08-12 17:26:42 --> Helper loaded: url_helper
INFO - 2020-08-12 17:26:42 --> Database Driver Class Initialized
INFO - 2020-08-12 17:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:26:42 --> Email Class Initialized
INFO - 2020-08-12 17:26:42 --> Controller Class Initialized
DEBUG - 2020-08-12 17:26:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:26:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:26:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-12 17:26:42 --> Final output sent to browser
DEBUG - 2020-08-12 17:26:42 --> Total execution time: 0.0196
INFO - 2020-08-12 17:26:45 --> Config Class Initialized
INFO - 2020-08-12 17:26:45 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:26:45 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:26:45 --> Utf8 Class Initialized
INFO - 2020-08-12 17:26:45 --> URI Class Initialized
INFO - 2020-08-12 17:26:45 --> Router Class Initialized
INFO - 2020-08-12 17:26:45 --> Output Class Initialized
INFO - 2020-08-12 17:26:45 --> Security Class Initialized
DEBUG - 2020-08-12 17:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:26:45 --> Input Class Initialized
INFO - 2020-08-12 17:26:45 --> Language Class Initialized
INFO - 2020-08-12 17:26:45 --> Loader Class Initialized
INFO - 2020-08-12 17:26:45 --> Helper loaded: url_helper
INFO - 2020-08-12 17:26:45 --> Database Driver Class Initialized
INFO - 2020-08-12 17:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:26:45 --> Email Class Initialized
INFO - 2020-08-12 17:26:45 --> Controller Class Initialized
DEBUG - 2020-08-12 17:26:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:26:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:26:45 --> Model Class Initialized
INFO - 2020-08-12 17:26:45 --> Model Class Initialized
INFO - 2020-08-12 17:26:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-12 17:26:45 --> Final output sent to browser
DEBUG - 2020-08-12 17:26:45 --> Total execution time: 0.0244
INFO - 2020-08-12 17:28:11 --> Config Class Initialized
INFO - 2020-08-12 17:28:11 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:28:11 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:28:11 --> Utf8 Class Initialized
INFO - 2020-08-12 17:28:11 --> URI Class Initialized
INFO - 2020-08-12 17:28:11 --> Router Class Initialized
INFO - 2020-08-12 17:28:11 --> Output Class Initialized
INFO - 2020-08-12 17:28:11 --> Security Class Initialized
DEBUG - 2020-08-12 17:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:28:11 --> Input Class Initialized
INFO - 2020-08-12 17:28:11 --> Language Class Initialized
INFO - 2020-08-12 17:28:11 --> Loader Class Initialized
INFO - 2020-08-12 17:28:11 --> Helper loaded: url_helper
INFO - 2020-08-12 17:28:11 --> Database Driver Class Initialized
INFO - 2020-08-12 17:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:28:11 --> Email Class Initialized
INFO - 2020-08-12 17:28:11 --> Controller Class Initialized
DEBUG - 2020-08-12 17:28:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:28:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:28:11 --> Model Class Initialized
INFO - 2020-08-12 17:28:11 --> Model Class Initialized
INFO - 2020-08-12 17:28:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-12 17:28:11 --> Final output sent to browser
DEBUG - 2020-08-12 17:28:11 --> Total execution time: 0.0256
INFO - 2020-08-12 17:28:14 --> Config Class Initialized
INFO - 2020-08-12 17:28:14 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:28:14 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:28:14 --> Utf8 Class Initialized
INFO - 2020-08-12 17:28:14 --> URI Class Initialized
INFO - 2020-08-12 17:28:14 --> Router Class Initialized
INFO - 2020-08-12 17:28:14 --> Output Class Initialized
INFO - 2020-08-12 17:28:14 --> Security Class Initialized
DEBUG - 2020-08-12 17:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:28:14 --> Input Class Initialized
INFO - 2020-08-12 17:28:14 --> Language Class Initialized
INFO - 2020-08-12 17:28:14 --> Loader Class Initialized
INFO - 2020-08-12 17:28:14 --> Helper loaded: url_helper
INFO - 2020-08-12 17:28:14 --> Database Driver Class Initialized
INFO - 2020-08-12 17:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:28:14 --> Email Class Initialized
INFO - 2020-08-12 17:28:14 --> Controller Class Initialized
DEBUG - 2020-08-12 17:28:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:28:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:28:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-08-12 17:28:14 --> Final output sent to browser
DEBUG - 2020-08-12 17:28:14 --> Total execution time: 0.0231
INFO - 2020-08-12 17:28:49 --> Config Class Initialized
INFO - 2020-08-12 17:28:49 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:28:49 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:28:49 --> Utf8 Class Initialized
INFO - 2020-08-12 17:28:49 --> URI Class Initialized
INFO - 2020-08-12 17:28:49 --> Router Class Initialized
INFO - 2020-08-12 17:28:49 --> Output Class Initialized
INFO - 2020-08-12 17:28:49 --> Security Class Initialized
DEBUG - 2020-08-12 17:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:28:49 --> Input Class Initialized
INFO - 2020-08-12 17:28:49 --> Language Class Initialized
INFO - 2020-08-12 17:28:49 --> Loader Class Initialized
INFO - 2020-08-12 17:28:49 --> Helper loaded: url_helper
INFO - 2020-08-12 17:28:49 --> Database Driver Class Initialized
INFO - 2020-08-12 17:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:28:49 --> Email Class Initialized
INFO - 2020-08-12 17:28:49 --> Controller Class Initialized
DEBUG - 2020-08-12 17:28:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:28:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:28:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-08-12 17:28:49 --> Final output sent to browser
DEBUG - 2020-08-12 17:28:49 --> Total execution time: 0.0239
INFO - 2020-08-12 17:28:59 --> Config Class Initialized
INFO - 2020-08-12 17:28:59 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:28:59 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:28:59 --> Utf8 Class Initialized
INFO - 2020-08-12 17:28:59 --> URI Class Initialized
INFO - 2020-08-12 17:28:59 --> Router Class Initialized
INFO - 2020-08-12 17:28:59 --> Output Class Initialized
INFO - 2020-08-12 17:28:59 --> Security Class Initialized
DEBUG - 2020-08-12 17:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:28:59 --> Input Class Initialized
INFO - 2020-08-12 17:28:59 --> Language Class Initialized
INFO - 2020-08-12 17:28:59 --> Loader Class Initialized
INFO - 2020-08-12 17:28:59 --> Helper loaded: url_helper
INFO - 2020-08-12 17:28:59 --> Database Driver Class Initialized
INFO - 2020-08-12 17:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:28:59 --> Email Class Initialized
INFO - 2020-08-12 17:28:59 --> Controller Class Initialized
DEBUG - 2020-08-12 17:28:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:28:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:28:59 --> Model Class Initialized
INFO - 2020-08-12 17:28:59 --> Model Class Initialized
INFO - 2020-08-12 17:28:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-12 17:28:59 --> Final output sent to browser
DEBUG - 2020-08-12 17:28:59 --> Total execution time: 0.0257
INFO - 2020-08-12 17:29:08 --> Config Class Initialized
INFO - 2020-08-12 17:29:08 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:29:08 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:29:08 --> Utf8 Class Initialized
INFO - 2020-08-12 17:29:08 --> URI Class Initialized
INFO - 2020-08-12 17:29:08 --> Router Class Initialized
INFO - 2020-08-12 17:29:08 --> Output Class Initialized
INFO - 2020-08-12 17:29:08 --> Security Class Initialized
DEBUG - 2020-08-12 17:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:29:08 --> Input Class Initialized
INFO - 2020-08-12 17:29:08 --> Language Class Initialized
INFO - 2020-08-12 17:29:08 --> Loader Class Initialized
INFO - 2020-08-12 17:29:08 --> Helper loaded: url_helper
INFO - 2020-08-12 17:29:08 --> Database Driver Class Initialized
INFO - 2020-08-12 17:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:29:08 --> Email Class Initialized
INFO - 2020-08-12 17:29:08 --> Controller Class Initialized
DEBUG - 2020-08-12 17:29:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:29:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:29:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-08-12 17:29:08 --> Final output sent to browser
DEBUG - 2020-08-12 17:29:08 --> Total execution time: 0.0216
INFO - 2020-08-12 17:29:35 --> Config Class Initialized
INFO - 2020-08-12 17:29:35 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:29:35 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:29:35 --> Utf8 Class Initialized
INFO - 2020-08-12 17:29:35 --> URI Class Initialized
INFO - 2020-08-12 17:29:35 --> Router Class Initialized
INFO - 2020-08-12 17:29:35 --> Output Class Initialized
INFO - 2020-08-12 17:29:35 --> Security Class Initialized
DEBUG - 2020-08-12 17:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:29:35 --> Input Class Initialized
INFO - 2020-08-12 17:29:35 --> Language Class Initialized
INFO - 2020-08-12 17:29:35 --> Loader Class Initialized
INFO - 2020-08-12 17:29:35 --> Helper loaded: url_helper
INFO - 2020-08-12 17:29:35 --> Database Driver Class Initialized
INFO - 2020-08-12 17:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:29:35 --> Email Class Initialized
INFO - 2020-08-12 17:29:35 --> Controller Class Initialized
DEBUG - 2020-08-12 17:29:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:29:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:29:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-12 17:29:35 --> Final output sent to browser
DEBUG - 2020-08-12 17:29:35 --> Total execution time: 0.0202
INFO - 2020-08-12 17:30:03 --> Config Class Initialized
INFO - 2020-08-12 17:30:03 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:30:03 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:30:03 --> Utf8 Class Initialized
INFO - 2020-08-12 17:30:03 --> URI Class Initialized
INFO - 2020-08-12 17:30:03 --> Router Class Initialized
INFO - 2020-08-12 17:30:03 --> Output Class Initialized
INFO - 2020-08-12 17:30:03 --> Security Class Initialized
DEBUG - 2020-08-12 17:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:30:03 --> Input Class Initialized
INFO - 2020-08-12 17:30:03 --> Language Class Initialized
INFO - 2020-08-12 17:30:03 --> Loader Class Initialized
INFO - 2020-08-12 17:30:03 --> Helper loaded: url_helper
INFO - 2020-08-12 17:30:03 --> Database Driver Class Initialized
INFO - 2020-08-12 17:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:30:03 --> Email Class Initialized
INFO - 2020-08-12 17:30:03 --> Controller Class Initialized
DEBUG - 2020-08-12 17:30:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:30:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:30:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-12 17:30:03 --> Final output sent to browser
DEBUG - 2020-08-12 17:30:03 --> Total execution time: 0.0478
INFO - 2020-08-12 17:30:20 --> Config Class Initialized
INFO - 2020-08-12 17:30:20 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:30:20 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:30:20 --> Utf8 Class Initialized
INFO - 2020-08-12 17:30:20 --> URI Class Initialized
INFO - 2020-08-12 17:30:20 --> Router Class Initialized
INFO - 2020-08-12 17:30:20 --> Output Class Initialized
INFO - 2020-08-12 17:30:20 --> Security Class Initialized
DEBUG - 2020-08-12 17:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:30:20 --> Input Class Initialized
INFO - 2020-08-12 17:30:20 --> Language Class Initialized
INFO - 2020-08-12 17:30:20 --> Loader Class Initialized
INFO - 2020-08-12 17:30:20 --> Helper loaded: url_helper
INFO - 2020-08-12 17:30:20 --> Database Driver Class Initialized
INFO - 2020-08-12 17:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:30:20 --> Email Class Initialized
INFO - 2020-08-12 17:30:20 --> Controller Class Initialized
DEBUG - 2020-08-12 17:30:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:30:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:30:20 --> Model Class Initialized
INFO - 2020-08-12 17:30:20 --> Model Class Initialized
INFO - 2020-08-12 17:30:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-12 17:30:20 --> Final output sent to browser
DEBUG - 2020-08-12 17:30:20 --> Total execution time: 0.0248
INFO - 2020-08-12 17:32:53 --> Config Class Initialized
INFO - 2020-08-12 17:32:53 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:32:53 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:32:53 --> Utf8 Class Initialized
INFO - 2020-08-12 17:32:53 --> URI Class Initialized
INFO - 2020-08-12 17:32:53 --> Router Class Initialized
INFO - 2020-08-12 17:32:53 --> Output Class Initialized
INFO - 2020-08-12 17:32:53 --> Security Class Initialized
DEBUG - 2020-08-12 17:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:32:53 --> Input Class Initialized
INFO - 2020-08-12 17:32:53 --> Language Class Initialized
INFO - 2020-08-12 17:32:53 --> Loader Class Initialized
INFO - 2020-08-12 17:32:53 --> Helper loaded: url_helper
INFO - 2020-08-12 17:32:53 --> Database Driver Class Initialized
INFO - 2020-08-12 17:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:32:53 --> Email Class Initialized
INFO - 2020-08-12 17:32:53 --> Controller Class Initialized
DEBUG - 2020-08-12 17:32:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:32:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:32:53 --> Model Class Initialized
INFO - 2020-08-12 17:32:53 --> Model Class Initialized
INFO - 2020-08-12 17:32:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-12 17:32:53 --> Final output sent to browser
DEBUG - 2020-08-12 17:32:53 --> Total execution time: 0.0244
INFO - 2020-08-12 17:35:02 --> Config Class Initialized
INFO - 2020-08-12 17:35:02 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:35:02 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:35:02 --> Utf8 Class Initialized
INFO - 2020-08-12 17:35:02 --> URI Class Initialized
INFO - 2020-08-12 17:35:02 --> Router Class Initialized
INFO - 2020-08-12 17:35:02 --> Output Class Initialized
INFO - 2020-08-12 17:35:02 --> Security Class Initialized
DEBUG - 2020-08-12 17:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:35:02 --> Input Class Initialized
INFO - 2020-08-12 17:35:02 --> Language Class Initialized
INFO - 2020-08-12 17:35:02 --> Loader Class Initialized
INFO - 2020-08-12 17:35:02 --> Helper loaded: url_helper
INFO - 2020-08-12 17:35:02 --> Database Driver Class Initialized
INFO - 2020-08-12 17:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:35:02 --> Email Class Initialized
INFO - 2020-08-12 17:35:02 --> Controller Class Initialized
DEBUG - 2020-08-12 17:35:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:35:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:35:02 --> Model Class Initialized
INFO - 2020-08-12 17:35:02 --> Model Class Initialized
INFO - 2020-08-12 17:35:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-12 17:35:02 --> Final output sent to browser
DEBUG - 2020-08-12 17:35:02 --> Total execution time: 0.0278
INFO - 2020-08-12 17:35:05 --> Config Class Initialized
INFO - 2020-08-12 17:35:05 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:35:05 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:35:05 --> Utf8 Class Initialized
INFO - 2020-08-12 17:35:05 --> URI Class Initialized
INFO - 2020-08-12 17:35:05 --> Router Class Initialized
INFO - 2020-08-12 17:35:05 --> Output Class Initialized
INFO - 2020-08-12 17:35:05 --> Security Class Initialized
DEBUG - 2020-08-12 17:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:35:05 --> Input Class Initialized
INFO - 2020-08-12 17:35:05 --> Language Class Initialized
INFO - 2020-08-12 17:35:05 --> Loader Class Initialized
INFO - 2020-08-12 17:35:05 --> Helper loaded: url_helper
INFO - 2020-08-12 17:35:05 --> Database Driver Class Initialized
INFO - 2020-08-12 17:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:35:05 --> Email Class Initialized
INFO - 2020-08-12 17:35:05 --> Controller Class Initialized
DEBUG - 2020-08-12 17:35:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:35:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:35:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-12 17:35:05 --> Final output sent to browser
DEBUG - 2020-08-12 17:35:05 --> Total execution time: 0.0232
INFO - 2020-08-12 17:35:18 --> Config Class Initialized
INFO - 2020-08-12 17:35:18 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:35:18 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:35:18 --> Utf8 Class Initialized
INFO - 2020-08-12 17:35:18 --> URI Class Initialized
INFO - 2020-08-12 17:35:18 --> Router Class Initialized
INFO - 2020-08-12 17:35:18 --> Output Class Initialized
INFO - 2020-08-12 17:35:18 --> Security Class Initialized
DEBUG - 2020-08-12 17:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:35:18 --> Input Class Initialized
INFO - 2020-08-12 17:35:18 --> Language Class Initialized
INFO - 2020-08-12 17:35:18 --> Loader Class Initialized
INFO - 2020-08-12 17:35:18 --> Helper loaded: url_helper
INFO - 2020-08-12 17:35:18 --> Database Driver Class Initialized
INFO - 2020-08-12 17:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:35:18 --> Email Class Initialized
INFO - 2020-08-12 17:35:18 --> Controller Class Initialized
DEBUG - 2020-08-12 17:35:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:35:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:35:18 --> Model Class Initialized
INFO - 2020-08-12 17:35:18 --> Model Class Initialized
INFO - 2020-08-12 17:35:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-12 17:35:18 --> Final output sent to browser
DEBUG - 2020-08-12 17:35:18 --> Total execution time: 0.0265
INFO - 2020-08-12 17:35:23 --> Config Class Initialized
INFO - 2020-08-12 17:35:23 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:35:23 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:35:23 --> Utf8 Class Initialized
INFO - 2020-08-12 17:35:23 --> URI Class Initialized
INFO - 2020-08-12 17:35:23 --> Router Class Initialized
INFO - 2020-08-12 17:35:23 --> Output Class Initialized
INFO - 2020-08-12 17:35:23 --> Security Class Initialized
DEBUG - 2020-08-12 17:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:35:23 --> Input Class Initialized
INFO - 2020-08-12 17:35:23 --> Language Class Initialized
INFO - 2020-08-12 17:35:23 --> Loader Class Initialized
INFO - 2020-08-12 17:35:23 --> Helper loaded: url_helper
INFO - 2020-08-12 17:35:23 --> Database Driver Class Initialized
INFO - 2020-08-12 17:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:35:23 --> Email Class Initialized
INFO - 2020-08-12 17:35:23 --> Controller Class Initialized
DEBUG - 2020-08-12 17:35:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:35:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:35:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-12 17:35:23 --> Final output sent to browser
DEBUG - 2020-08-12 17:35:23 --> Total execution time: 0.0223
INFO - 2020-08-12 17:35:25 --> Config Class Initialized
INFO - 2020-08-12 17:35:25 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:35:25 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:35:25 --> Utf8 Class Initialized
INFO - 2020-08-12 17:35:25 --> URI Class Initialized
INFO - 2020-08-12 17:35:25 --> Router Class Initialized
INFO - 2020-08-12 17:35:25 --> Output Class Initialized
INFO - 2020-08-12 17:35:25 --> Security Class Initialized
DEBUG - 2020-08-12 17:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:35:25 --> Input Class Initialized
INFO - 2020-08-12 17:35:25 --> Language Class Initialized
INFO - 2020-08-12 17:35:25 --> Loader Class Initialized
INFO - 2020-08-12 17:35:25 --> Helper loaded: url_helper
INFO - 2020-08-12 17:35:25 --> Database Driver Class Initialized
INFO - 2020-08-12 17:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:35:25 --> Email Class Initialized
INFO - 2020-08-12 17:35:25 --> Controller Class Initialized
DEBUG - 2020-08-12 17:35:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:35:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:35:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-12 17:35:25 --> Final output sent to browser
DEBUG - 2020-08-12 17:35:25 --> Total execution time: 0.0230
INFO - 2020-08-12 17:35:32 --> Config Class Initialized
INFO - 2020-08-12 17:35:32 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:35:32 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:35:32 --> Utf8 Class Initialized
INFO - 2020-08-12 17:35:32 --> URI Class Initialized
INFO - 2020-08-12 17:35:32 --> Router Class Initialized
INFO - 2020-08-12 17:35:32 --> Output Class Initialized
INFO - 2020-08-12 17:35:32 --> Security Class Initialized
DEBUG - 2020-08-12 17:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:35:32 --> Input Class Initialized
INFO - 2020-08-12 17:35:32 --> Language Class Initialized
INFO - 2020-08-12 17:35:32 --> Loader Class Initialized
INFO - 2020-08-12 17:35:32 --> Helper loaded: url_helper
INFO - 2020-08-12 17:35:32 --> Database Driver Class Initialized
INFO - 2020-08-12 17:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:35:32 --> Email Class Initialized
INFO - 2020-08-12 17:35:32 --> Controller Class Initialized
DEBUG - 2020-08-12 17:35:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:35:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:35:32 --> Model Class Initialized
INFO - 2020-08-12 17:35:32 --> Model Class Initialized
INFO - 2020-08-12 17:35:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-12 17:35:32 --> Final output sent to browser
DEBUG - 2020-08-12 17:35:32 --> Total execution time: 0.0216
INFO - 2020-08-12 17:49:46 --> Config Class Initialized
INFO - 2020-08-12 17:49:46 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:49:46 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:49:46 --> Utf8 Class Initialized
INFO - 2020-08-12 17:49:46 --> URI Class Initialized
INFO - 2020-08-12 17:49:46 --> Router Class Initialized
INFO - 2020-08-12 17:49:46 --> Output Class Initialized
INFO - 2020-08-12 17:49:46 --> Security Class Initialized
DEBUG - 2020-08-12 17:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:49:46 --> Input Class Initialized
INFO - 2020-08-12 17:49:46 --> Language Class Initialized
INFO - 2020-08-12 17:49:46 --> Loader Class Initialized
INFO - 2020-08-12 17:49:46 --> Helper loaded: url_helper
INFO - 2020-08-12 17:49:46 --> Database Driver Class Initialized
INFO - 2020-08-12 17:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:49:46 --> Email Class Initialized
INFO - 2020-08-12 17:49:46 --> Controller Class Initialized
DEBUG - 2020-08-12 17:49:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:49:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:49:46 --> Model Class Initialized
INFO - 2020-08-12 17:49:46 --> Model Class Initialized
INFO - 2020-08-12 17:49:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-12 17:49:46 --> Final output sent to browser
DEBUG - 2020-08-12 17:49:46 --> Total execution time: 0.0249
INFO - 2020-08-12 17:51:08 --> Config Class Initialized
INFO - 2020-08-12 17:51:08 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:51:08 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:51:08 --> Utf8 Class Initialized
INFO - 2020-08-12 17:51:08 --> URI Class Initialized
INFO - 2020-08-12 17:51:08 --> Router Class Initialized
INFO - 2020-08-12 17:51:08 --> Output Class Initialized
INFO - 2020-08-12 17:51:08 --> Security Class Initialized
DEBUG - 2020-08-12 17:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:51:08 --> Input Class Initialized
INFO - 2020-08-12 17:51:08 --> Language Class Initialized
INFO - 2020-08-12 17:51:08 --> Loader Class Initialized
INFO - 2020-08-12 17:51:08 --> Helper loaded: url_helper
INFO - 2020-08-12 17:51:08 --> Database Driver Class Initialized
INFO - 2020-08-12 17:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:51:08 --> Email Class Initialized
INFO - 2020-08-12 17:51:08 --> Controller Class Initialized
DEBUG - 2020-08-12 17:51:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:51:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:51:08 --> Model Class Initialized
INFO - 2020-08-12 17:51:08 --> Model Class Initialized
INFO - 2020-08-12 17:51:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-12 17:51:08 --> Final output sent to browser
DEBUG - 2020-08-12 17:51:08 --> Total execution time: 0.0263
INFO - 2020-08-12 17:56:57 --> Config Class Initialized
INFO - 2020-08-12 17:56:57 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:56:57 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:56:57 --> Utf8 Class Initialized
INFO - 2020-08-12 17:56:57 --> URI Class Initialized
INFO - 2020-08-12 17:56:57 --> Router Class Initialized
INFO - 2020-08-12 17:56:57 --> Output Class Initialized
INFO - 2020-08-12 17:56:57 --> Security Class Initialized
DEBUG - 2020-08-12 17:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:56:57 --> Input Class Initialized
INFO - 2020-08-12 17:56:57 --> Language Class Initialized
INFO - 2020-08-12 17:56:57 --> Loader Class Initialized
INFO - 2020-08-12 17:56:57 --> Helper loaded: url_helper
INFO - 2020-08-12 17:56:57 --> Database Driver Class Initialized
INFO - 2020-08-12 17:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:56:57 --> Email Class Initialized
INFO - 2020-08-12 17:56:57 --> Controller Class Initialized
DEBUG - 2020-08-12 17:56:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:56:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:56:57 --> Model Class Initialized
INFO - 2020-08-12 17:56:57 --> Model Class Initialized
INFO - 2020-08-12 17:56:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-12 17:56:57 --> Final output sent to browser
DEBUG - 2020-08-12 17:56:57 --> Total execution time: 0.0262
INFO - 2020-08-12 17:56:59 --> Config Class Initialized
INFO - 2020-08-12 17:56:59 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:56:59 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:56:59 --> Utf8 Class Initialized
INFO - 2020-08-12 17:56:59 --> URI Class Initialized
INFO - 2020-08-12 17:56:59 --> Router Class Initialized
INFO - 2020-08-12 17:56:59 --> Output Class Initialized
INFO - 2020-08-12 17:56:59 --> Security Class Initialized
DEBUG - 2020-08-12 17:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:56:59 --> Input Class Initialized
INFO - 2020-08-12 17:56:59 --> Language Class Initialized
INFO - 2020-08-12 17:56:59 --> Loader Class Initialized
INFO - 2020-08-12 17:56:59 --> Helper loaded: url_helper
INFO - 2020-08-12 17:56:59 --> Database Driver Class Initialized
INFO - 2020-08-12 17:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:56:59 --> Email Class Initialized
INFO - 2020-08-12 17:56:59 --> Controller Class Initialized
DEBUG - 2020-08-12 17:56:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:56:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:56:59 --> Model Class Initialized
INFO - 2020-08-12 17:56:59 --> Model Class Initialized
INFO - 2020-08-12 17:56:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-12 17:56:59 --> Final output sent to browser
DEBUG - 2020-08-12 17:56:59 --> Total execution time: 0.0270
INFO - 2020-08-12 17:57:05 --> Config Class Initialized
INFO - 2020-08-12 17:57:05 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:57:05 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:57:05 --> Utf8 Class Initialized
INFO - 2020-08-12 17:57:05 --> URI Class Initialized
INFO - 2020-08-12 17:57:05 --> Router Class Initialized
INFO - 2020-08-12 17:57:05 --> Output Class Initialized
INFO - 2020-08-12 17:57:05 --> Security Class Initialized
DEBUG - 2020-08-12 17:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:57:05 --> Input Class Initialized
INFO - 2020-08-12 17:57:05 --> Language Class Initialized
INFO - 2020-08-12 17:57:05 --> Loader Class Initialized
INFO - 2020-08-12 17:57:05 --> Helper loaded: url_helper
INFO - 2020-08-12 17:57:05 --> Database Driver Class Initialized
INFO - 2020-08-12 17:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:57:05 --> Email Class Initialized
INFO - 2020-08-12 17:57:05 --> Controller Class Initialized
DEBUG - 2020-08-12 17:57:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:57:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:57:05 --> Model Class Initialized
INFO - 2020-08-12 17:57:05 --> Model Class Initialized
INFO - 2020-08-12 17:57:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-12 17:57:05 --> Final output sent to browser
DEBUG - 2020-08-12 17:57:05 --> Total execution time: 0.0266
INFO - 2020-08-12 17:58:10 --> Config Class Initialized
INFO - 2020-08-12 17:58:10 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:58:10 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:58:10 --> Utf8 Class Initialized
INFO - 2020-08-12 17:58:10 --> URI Class Initialized
INFO - 2020-08-12 17:58:10 --> Router Class Initialized
INFO - 2020-08-12 17:58:10 --> Output Class Initialized
INFO - 2020-08-12 17:58:10 --> Security Class Initialized
DEBUG - 2020-08-12 17:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:58:10 --> Input Class Initialized
INFO - 2020-08-12 17:58:10 --> Language Class Initialized
INFO - 2020-08-12 17:58:10 --> Loader Class Initialized
INFO - 2020-08-12 17:58:10 --> Helper loaded: url_helper
INFO - 2020-08-12 17:58:10 --> Database Driver Class Initialized
INFO - 2020-08-12 17:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:58:10 --> Email Class Initialized
INFO - 2020-08-12 17:58:10 --> Controller Class Initialized
DEBUG - 2020-08-12 17:58:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:58:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:58:10 --> Model Class Initialized
INFO - 2020-08-12 17:58:10 --> Model Class Initialized
INFO - 2020-08-12 17:58:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-12 17:58:10 --> Final output sent to browser
DEBUG - 2020-08-12 17:58:10 --> Total execution time: 0.0231
INFO - 2020-08-12 17:58:13 --> Config Class Initialized
INFO - 2020-08-12 17:58:13 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:58:13 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:58:13 --> Utf8 Class Initialized
INFO - 2020-08-12 17:58:13 --> URI Class Initialized
DEBUG - 2020-08-12 17:58:13 --> No URI present. Default controller set.
INFO - 2020-08-12 17:58:13 --> Router Class Initialized
INFO - 2020-08-12 17:58:13 --> Output Class Initialized
INFO - 2020-08-12 17:58:13 --> Security Class Initialized
DEBUG - 2020-08-12 17:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:58:13 --> Input Class Initialized
INFO - 2020-08-12 17:58:13 --> Language Class Initialized
INFO - 2020-08-12 17:58:13 --> Loader Class Initialized
INFO - 2020-08-12 17:58:13 --> Helper loaded: url_helper
INFO - 2020-08-12 17:58:13 --> Database Driver Class Initialized
INFO - 2020-08-12 17:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:58:13 --> Email Class Initialized
INFO - 2020-08-12 17:58:13 --> Controller Class Initialized
INFO - 2020-08-12 17:58:13 --> Model Class Initialized
INFO - 2020-08-12 17:58:13 --> Model Class Initialized
DEBUG - 2020-08-12 17:58:13 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:58:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-12 17:58:13 --> Final output sent to browser
DEBUG - 2020-08-12 17:58:13 --> Total execution time: 0.0196
INFO - 2020-08-12 17:58:16 --> Config Class Initialized
INFO - 2020-08-12 17:58:16 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:58:16 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:58:16 --> Utf8 Class Initialized
INFO - 2020-08-12 17:58:16 --> URI Class Initialized
INFO - 2020-08-12 17:58:16 --> Router Class Initialized
INFO - 2020-08-12 17:58:16 --> Output Class Initialized
INFO - 2020-08-12 17:58:16 --> Security Class Initialized
DEBUG - 2020-08-12 17:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:58:16 --> Input Class Initialized
INFO - 2020-08-12 17:58:16 --> Language Class Initialized
INFO - 2020-08-12 17:58:16 --> Loader Class Initialized
INFO - 2020-08-12 17:58:16 --> Helper loaded: url_helper
INFO - 2020-08-12 17:58:16 --> Database Driver Class Initialized
INFO - 2020-08-12 17:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:58:16 --> Email Class Initialized
INFO - 2020-08-12 17:58:16 --> Controller Class Initialized
INFO - 2020-08-12 17:58:16 --> Model Class Initialized
INFO - 2020-08-12 17:58:16 --> Model Class Initialized
DEBUG - 2020-08-12 17:58:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:58:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:58:16 --> Model Class Initialized
INFO - 2020-08-12 17:58:16 --> Final output sent to browser
DEBUG - 2020-08-12 17:58:16 --> Total execution time: 0.0269
INFO - 2020-08-12 17:58:16 --> Config Class Initialized
INFO - 2020-08-12 17:58:16 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:58:16 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:58:16 --> Utf8 Class Initialized
INFO - 2020-08-12 17:58:16 --> URI Class Initialized
INFO - 2020-08-12 17:58:16 --> Router Class Initialized
INFO - 2020-08-12 17:58:16 --> Output Class Initialized
INFO - 2020-08-12 17:58:16 --> Security Class Initialized
DEBUG - 2020-08-12 17:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:58:16 --> Input Class Initialized
INFO - 2020-08-12 17:58:16 --> Language Class Initialized
INFO - 2020-08-12 17:58:16 --> Loader Class Initialized
INFO - 2020-08-12 17:58:16 --> Helper loaded: url_helper
INFO - 2020-08-12 17:58:16 --> Database Driver Class Initialized
INFO - 2020-08-12 17:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:58:16 --> Email Class Initialized
INFO - 2020-08-12 17:58:16 --> Controller Class Initialized
INFO - 2020-08-12 17:58:16 --> Model Class Initialized
INFO - 2020-08-12 17:58:16 --> Model Class Initialized
DEBUG - 2020-08-12 17:58:16 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:58:16 --> Config Class Initialized
INFO - 2020-08-12 17:58:16 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:58:16 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:58:16 --> Utf8 Class Initialized
INFO - 2020-08-12 17:58:16 --> URI Class Initialized
INFO - 2020-08-12 17:58:16 --> Router Class Initialized
INFO - 2020-08-12 17:58:16 --> Output Class Initialized
INFO - 2020-08-12 17:58:16 --> Security Class Initialized
DEBUG - 2020-08-12 17:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:58:16 --> Input Class Initialized
INFO - 2020-08-12 17:58:16 --> Language Class Initialized
INFO - 2020-08-12 17:58:16 --> Loader Class Initialized
INFO - 2020-08-12 17:58:16 --> Helper loaded: url_helper
INFO - 2020-08-12 17:58:16 --> Database Driver Class Initialized
INFO - 2020-08-12 17:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:58:16 --> Email Class Initialized
INFO - 2020-08-12 17:58:16 --> Controller Class Initialized
DEBUG - 2020-08-12 17:58:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:58:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:58:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-12 17:58:16 --> Final output sent to browser
DEBUG - 2020-08-12 17:58:16 --> Total execution time: 0.0245
INFO - 2020-08-12 17:58:20 --> Config Class Initialized
INFO - 2020-08-12 17:58:20 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:58:20 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:58:20 --> Utf8 Class Initialized
INFO - 2020-08-12 17:58:20 --> URI Class Initialized
INFO - 2020-08-12 17:58:20 --> Router Class Initialized
INFO - 2020-08-12 17:58:20 --> Output Class Initialized
INFO - 2020-08-12 17:58:20 --> Security Class Initialized
DEBUG - 2020-08-12 17:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:58:20 --> Input Class Initialized
INFO - 2020-08-12 17:58:20 --> Language Class Initialized
INFO - 2020-08-12 17:58:20 --> Loader Class Initialized
INFO - 2020-08-12 17:58:20 --> Helper loaded: url_helper
INFO - 2020-08-12 17:58:20 --> Database Driver Class Initialized
INFO - 2020-08-12 17:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:58:20 --> Email Class Initialized
INFO - 2020-08-12 17:58:20 --> Controller Class Initialized
DEBUG - 2020-08-12 17:58:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:58:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:58:20 --> Model Class Initialized
INFO - 2020-08-12 17:58:20 --> Model Class Initialized
INFO - 2020-08-12 17:58:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-12 17:58:20 --> Final output sent to browser
DEBUG - 2020-08-12 17:58:20 --> Total execution time: 0.0255
INFO - 2020-08-12 17:58:24 --> Config Class Initialized
INFO - 2020-08-12 17:58:24 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:58:24 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:58:24 --> Utf8 Class Initialized
INFO - 2020-08-12 17:58:24 --> URI Class Initialized
INFO - 2020-08-12 17:58:24 --> Router Class Initialized
INFO - 2020-08-12 17:58:24 --> Output Class Initialized
INFO - 2020-08-12 17:58:24 --> Security Class Initialized
DEBUG - 2020-08-12 17:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:58:24 --> Input Class Initialized
INFO - 2020-08-12 17:58:24 --> Language Class Initialized
INFO - 2020-08-12 17:58:24 --> Loader Class Initialized
INFO - 2020-08-12 17:58:24 --> Helper loaded: url_helper
INFO - 2020-08-12 17:58:24 --> Database Driver Class Initialized
INFO - 2020-08-12 17:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:58:24 --> Email Class Initialized
INFO - 2020-08-12 17:58:24 --> Controller Class Initialized
DEBUG - 2020-08-12 17:58:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:58:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:58:24 --> Model Class Initialized
INFO - 2020-08-12 17:58:24 --> Model Class Initialized
INFO - 2020-08-12 17:58:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-12 17:58:24 --> Final output sent to browser
DEBUG - 2020-08-12 17:58:24 --> Total execution time: 0.0240
INFO - 2020-08-12 17:58:27 --> Config Class Initialized
INFO - 2020-08-12 17:58:27 --> Hooks Class Initialized
DEBUG - 2020-08-12 17:58:27 --> UTF-8 Support Enabled
INFO - 2020-08-12 17:58:27 --> Utf8 Class Initialized
INFO - 2020-08-12 17:58:27 --> URI Class Initialized
INFO - 2020-08-12 17:58:27 --> Router Class Initialized
INFO - 2020-08-12 17:58:27 --> Output Class Initialized
INFO - 2020-08-12 17:58:27 --> Security Class Initialized
DEBUG - 2020-08-12 17:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 17:58:27 --> Input Class Initialized
INFO - 2020-08-12 17:58:27 --> Language Class Initialized
INFO - 2020-08-12 17:58:27 --> Loader Class Initialized
INFO - 2020-08-12 17:58:27 --> Helper loaded: url_helper
INFO - 2020-08-12 17:58:27 --> Database Driver Class Initialized
INFO - 2020-08-12 17:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 17:58:27 --> Email Class Initialized
INFO - 2020-08-12 17:58:27 --> Controller Class Initialized
DEBUG - 2020-08-12 17:58:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 17:58:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 17:58:27 --> Model Class Initialized
INFO - 2020-08-12 17:58:27 --> Model Class Initialized
INFO - 2020-08-12 17:58:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-12 17:58:27 --> Final output sent to browser
DEBUG - 2020-08-12 17:58:27 --> Total execution time: 0.0261
INFO - 2020-08-12 18:05:04 --> Config Class Initialized
INFO - 2020-08-12 18:05:04 --> Hooks Class Initialized
DEBUG - 2020-08-12 18:05:04 --> UTF-8 Support Enabled
INFO - 2020-08-12 18:05:04 --> Utf8 Class Initialized
INFO - 2020-08-12 18:05:04 --> URI Class Initialized
INFO - 2020-08-12 18:05:04 --> Router Class Initialized
INFO - 2020-08-12 18:05:04 --> Output Class Initialized
INFO - 2020-08-12 18:05:04 --> Security Class Initialized
DEBUG - 2020-08-12 18:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 18:05:04 --> Input Class Initialized
INFO - 2020-08-12 18:05:04 --> Language Class Initialized
INFO - 2020-08-12 18:05:04 --> Loader Class Initialized
INFO - 2020-08-12 18:05:04 --> Helper loaded: url_helper
INFO - 2020-08-12 18:05:04 --> Database Driver Class Initialized
INFO - 2020-08-12 18:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 18:05:04 --> Email Class Initialized
INFO - 2020-08-12 18:05:04 --> Controller Class Initialized
DEBUG - 2020-08-12 18:05:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 18:05:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 18:05:04 --> Model Class Initialized
INFO - 2020-08-12 18:05:04 --> Model Class Initialized
INFO - 2020-08-12 18:05:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-12 18:05:04 --> Final output sent to browser
DEBUG - 2020-08-12 18:05:04 --> Total execution time: 0.0211
INFO - 2020-08-12 18:05:07 --> Config Class Initialized
INFO - 2020-08-12 18:05:07 --> Hooks Class Initialized
DEBUG - 2020-08-12 18:05:07 --> UTF-8 Support Enabled
INFO - 2020-08-12 18:05:07 --> Utf8 Class Initialized
INFO - 2020-08-12 18:05:07 --> URI Class Initialized
INFO - 2020-08-12 18:05:07 --> Router Class Initialized
INFO - 2020-08-12 18:05:07 --> Output Class Initialized
INFO - 2020-08-12 18:05:07 --> Security Class Initialized
DEBUG - 2020-08-12 18:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 18:05:07 --> Input Class Initialized
INFO - 2020-08-12 18:05:07 --> Language Class Initialized
INFO - 2020-08-12 18:05:07 --> Loader Class Initialized
INFO - 2020-08-12 18:05:07 --> Helper loaded: url_helper
INFO - 2020-08-12 18:05:07 --> Database Driver Class Initialized
INFO - 2020-08-12 18:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 18:05:07 --> Email Class Initialized
INFO - 2020-08-12 18:05:07 --> Controller Class Initialized
DEBUG - 2020-08-12 18:05:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 18:05:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 18:05:07 --> Model Class Initialized
INFO - 2020-08-12 18:05:07 --> Model Class Initialized
INFO - 2020-08-12 18:05:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-12 18:05:07 --> Final output sent to browser
DEBUG - 2020-08-12 18:05:07 --> Total execution time: 0.0252
INFO - 2020-08-12 18:05:17 --> Config Class Initialized
INFO - 2020-08-12 18:05:17 --> Hooks Class Initialized
DEBUG - 2020-08-12 18:05:17 --> UTF-8 Support Enabled
INFO - 2020-08-12 18:05:17 --> Utf8 Class Initialized
INFO - 2020-08-12 18:05:17 --> URI Class Initialized
INFO - 2020-08-12 18:05:17 --> Router Class Initialized
INFO - 2020-08-12 18:05:17 --> Output Class Initialized
INFO - 2020-08-12 18:05:17 --> Security Class Initialized
DEBUG - 2020-08-12 18:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 18:05:17 --> Input Class Initialized
INFO - 2020-08-12 18:05:17 --> Language Class Initialized
INFO - 2020-08-12 18:05:17 --> Loader Class Initialized
INFO - 2020-08-12 18:05:17 --> Helper loaded: url_helper
INFO - 2020-08-12 18:05:17 --> Database Driver Class Initialized
INFO - 2020-08-12 18:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 18:05:17 --> Email Class Initialized
INFO - 2020-08-12 18:05:17 --> Controller Class Initialized
DEBUG - 2020-08-12 18:05:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 18:05:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 18:05:17 --> Model Class Initialized
INFO - 2020-08-12 18:05:17 --> Model Class Initialized
INFO - 2020-08-12 18:05:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-12 18:05:18 --> Final output sent to browser
DEBUG - 2020-08-12 18:05:18 --> Total execution time: 0.0245
INFO - 2020-08-12 18:06:32 --> Config Class Initialized
INFO - 2020-08-12 18:06:32 --> Hooks Class Initialized
DEBUG - 2020-08-12 18:06:32 --> UTF-8 Support Enabled
INFO - 2020-08-12 18:06:32 --> Utf8 Class Initialized
INFO - 2020-08-12 18:06:32 --> URI Class Initialized
INFO - 2020-08-12 18:06:32 --> Router Class Initialized
INFO - 2020-08-12 18:06:32 --> Output Class Initialized
INFO - 2020-08-12 18:06:32 --> Security Class Initialized
DEBUG - 2020-08-12 18:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 18:06:32 --> Input Class Initialized
INFO - 2020-08-12 18:06:32 --> Language Class Initialized
INFO - 2020-08-12 18:06:32 --> Loader Class Initialized
INFO - 2020-08-12 18:06:32 --> Helper loaded: url_helper
INFO - 2020-08-12 18:06:32 --> Database Driver Class Initialized
INFO - 2020-08-12 18:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 18:06:32 --> Email Class Initialized
INFO - 2020-08-12 18:06:32 --> Controller Class Initialized
DEBUG - 2020-08-12 18:06:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 18:06:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 18:06:32 --> Model Class Initialized
INFO - 2020-08-12 18:06:32 --> Model Class Initialized
INFO - 2020-08-12 18:06:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-12 18:06:32 --> Final output sent to browser
DEBUG - 2020-08-12 18:06:32 --> Total execution time: 0.0277
INFO - 2020-08-12 18:06:41 --> Config Class Initialized
INFO - 2020-08-12 18:06:41 --> Hooks Class Initialized
DEBUG - 2020-08-12 18:06:41 --> UTF-8 Support Enabled
INFO - 2020-08-12 18:06:41 --> Utf8 Class Initialized
INFO - 2020-08-12 18:06:41 --> URI Class Initialized
INFO - 2020-08-12 18:06:41 --> Router Class Initialized
INFO - 2020-08-12 18:06:41 --> Output Class Initialized
INFO - 2020-08-12 18:06:41 --> Security Class Initialized
DEBUG - 2020-08-12 18:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 18:06:41 --> Input Class Initialized
INFO - 2020-08-12 18:06:41 --> Language Class Initialized
INFO - 2020-08-12 18:06:41 --> Loader Class Initialized
INFO - 2020-08-12 18:06:41 --> Helper loaded: url_helper
INFO - 2020-08-12 18:06:41 --> Database Driver Class Initialized
INFO - 2020-08-12 18:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 18:06:41 --> Email Class Initialized
INFO - 2020-08-12 18:06:41 --> Controller Class Initialized
DEBUG - 2020-08-12 18:06:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 18:06:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 18:06:41 --> Model Class Initialized
INFO - 2020-08-12 18:06:41 --> Model Class Initialized
INFO - 2020-08-12 18:06:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-12 18:06:41 --> Final output sent to browser
DEBUG - 2020-08-12 18:06:41 --> Total execution time: 0.0228
INFO - 2020-08-12 18:06:43 --> Config Class Initialized
INFO - 2020-08-12 18:06:43 --> Hooks Class Initialized
DEBUG - 2020-08-12 18:06:43 --> UTF-8 Support Enabled
INFO - 2020-08-12 18:06:43 --> Utf8 Class Initialized
INFO - 2020-08-12 18:06:43 --> URI Class Initialized
INFO - 2020-08-12 18:06:43 --> Router Class Initialized
INFO - 2020-08-12 18:06:43 --> Output Class Initialized
INFO - 2020-08-12 18:06:43 --> Security Class Initialized
DEBUG - 2020-08-12 18:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 18:06:43 --> Input Class Initialized
INFO - 2020-08-12 18:06:43 --> Language Class Initialized
INFO - 2020-08-12 18:06:43 --> Loader Class Initialized
INFO - 2020-08-12 18:06:43 --> Helper loaded: url_helper
INFO - 2020-08-12 18:06:43 --> Database Driver Class Initialized
INFO - 2020-08-12 18:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 18:06:43 --> Email Class Initialized
INFO - 2020-08-12 18:06:43 --> Controller Class Initialized
DEBUG - 2020-08-12 18:06:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 18:06:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 18:06:43 --> Model Class Initialized
INFO - 2020-08-12 18:06:43 --> Model Class Initialized
INFO - 2020-08-12 18:06:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-12 18:06:43 --> Final output sent to browser
DEBUG - 2020-08-12 18:06:43 --> Total execution time: 0.0238
INFO - 2020-08-12 18:06:47 --> Config Class Initialized
INFO - 2020-08-12 18:06:47 --> Hooks Class Initialized
DEBUG - 2020-08-12 18:06:47 --> UTF-8 Support Enabled
INFO - 2020-08-12 18:06:47 --> Utf8 Class Initialized
INFO - 2020-08-12 18:06:47 --> URI Class Initialized
INFO - 2020-08-12 18:06:47 --> Router Class Initialized
INFO - 2020-08-12 18:06:47 --> Output Class Initialized
INFO - 2020-08-12 18:06:47 --> Security Class Initialized
DEBUG - 2020-08-12 18:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 18:06:47 --> Input Class Initialized
INFO - 2020-08-12 18:06:47 --> Language Class Initialized
INFO - 2020-08-12 18:06:47 --> Loader Class Initialized
INFO - 2020-08-12 18:06:47 --> Helper loaded: url_helper
INFO - 2020-08-12 18:06:47 --> Database Driver Class Initialized
INFO - 2020-08-12 18:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 18:06:47 --> Email Class Initialized
INFO - 2020-08-12 18:06:47 --> Controller Class Initialized
DEBUG - 2020-08-12 18:06:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 18:06:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 18:06:47 --> Model Class Initialized
INFO - 2020-08-12 18:06:47 --> Model Class Initialized
INFO - 2020-08-12 18:06:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-12 18:06:47 --> Final output sent to browser
DEBUG - 2020-08-12 18:06:47 --> Total execution time: 0.0234
INFO - 2020-08-12 18:06:49 --> Config Class Initialized
INFO - 2020-08-12 18:06:49 --> Hooks Class Initialized
DEBUG - 2020-08-12 18:06:49 --> UTF-8 Support Enabled
INFO - 2020-08-12 18:06:49 --> Utf8 Class Initialized
INFO - 2020-08-12 18:06:49 --> URI Class Initialized
INFO - 2020-08-12 18:06:49 --> Router Class Initialized
INFO - 2020-08-12 18:06:49 --> Output Class Initialized
INFO - 2020-08-12 18:06:49 --> Security Class Initialized
DEBUG - 2020-08-12 18:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 18:06:49 --> Input Class Initialized
INFO - 2020-08-12 18:06:49 --> Language Class Initialized
INFO - 2020-08-12 18:06:49 --> Loader Class Initialized
INFO - 2020-08-12 18:06:49 --> Helper loaded: url_helper
INFO - 2020-08-12 18:06:49 --> Database Driver Class Initialized
INFO - 2020-08-12 18:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 18:06:49 --> Email Class Initialized
INFO - 2020-08-12 18:06:49 --> Controller Class Initialized
DEBUG - 2020-08-12 18:06:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 18:06:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 18:06:49 --> Model Class Initialized
INFO - 2020-08-12 18:06:49 --> Model Class Initialized
INFO - 2020-08-12 18:06:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-12 18:06:49 --> Final output sent to browser
DEBUG - 2020-08-12 18:06:49 --> Total execution time: 0.0267
INFO - 2020-08-12 18:06:59 --> Config Class Initialized
INFO - 2020-08-12 18:06:59 --> Hooks Class Initialized
DEBUG - 2020-08-12 18:06:59 --> UTF-8 Support Enabled
INFO - 2020-08-12 18:06:59 --> Utf8 Class Initialized
INFO - 2020-08-12 18:06:59 --> URI Class Initialized
INFO - 2020-08-12 18:06:59 --> Router Class Initialized
INFO - 2020-08-12 18:06:59 --> Output Class Initialized
INFO - 2020-08-12 18:06:59 --> Security Class Initialized
DEBUG - 2020-08-12 18:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-12 18:06:59 --> Input Class Initialized
INFO - 2020-08-12 18:06:59 --> Language Class Initialized
INFO - 2020-08-12 18:06:59 --> Loader Class Initialized
INFO - 2020-08-12 18:06:59 --> Helper loaded: url_helper
INFO - 2020-08-12 18:06:59 --> Database Driver Class Initialized
INFO - 2020-08-12 18:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-12 18:07:00 --> Email Class Initialized
INFO - 2020-08-12 18:07:00 --> Controller Class Initialized
DEBUG - 2020-08-12 18:07:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-12 18:07:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-12 18:07:00 --> Model Class Initialized
INFO - 2020-08-12 18:07:00 --> Model Class Initialized
INFO - 2020-08-12 18:07:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-12 18:07:00 --> Final output sent to browser
DEBUG - 2020-08-12 18:07:00 --> Total execution time: 0.2666
