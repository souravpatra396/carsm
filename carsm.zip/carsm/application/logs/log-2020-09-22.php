<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-22 03:24:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 03:24:36 --> Config Class Initialized
INFO - 2020-09-22 03:24:36 --> Hooks Class Initialized
DEBUG - 2020-09-22 03:24:36 --> UTF-8 Support Enabled
INFO - 2020-09-22 03:24:36 --> Utf8 Class Initialized
INFO - 2020-09-22 03:24:36 --> URI Class Initialized
DEBUG - 2020-09-22 03:24:36 --> No URI present. Default controller set.
INFO - 2020-09-22 03:24:36 --> Router Class Initialized
INFO - 2020-09-22 03:24:36 --> Output Class Initialized
INFO - 2020-09-22 03:24:36 --> Security Class Initialized
DEBUG - 2020-09-22 03:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 03:24:36 --> Input Class Initialized
INFO - 2020-09-22 03:24:36 --> Language Class Initialized
INFO - 2020-09-22 03:24:36 --> Loader Class Initialized
INFO - 2020-09-22 03:24:36 --> Helper loaded: url_helper
INFO - 2020-09-22 03:24:36 --> Database Driver Class Initialized
INFO - 2020-09-22 03:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 03:24:36 --> Email Class Initialized
INFO - 2020-09-22 03:24:36 --> Controller Class Initialized
INFO - 2020-09-22 03:24:36 --> Model Class Initialized
INFO - 2020-09-22 03:24:36 --> Model Class Initialized
DEBUG - 2020-09-22 03:24:36 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 03:24:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 03:24:36 --> Final output sent to browser
DEBUG - 2020-09-22 03:24:36 --> Total execution time: 0.0215
ERROR - 2020-09-22 03:30:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 03:30:15 --> Config Class Initialized
INFO - 2020-09-22 03:30:15 --> Hooks Class Initialized
ERROR - 2020-09-22 03:30:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 03:30:15 --> Config Class Initialized
INFO - 2020-09-22 03:30:15 --> Hooks Class Initialized
DEBUG - 2020-09-22 03:30:15 --> UTF-8 Support Enabled
INFO - 2020-09-22 03:30:15 --> Utf8 Class Initialized
INFO - 2020-09-22 03:30:15 --> URI Class Initialized
DEBUG - 2020-09-22 03:30:15 --> UTF-8 Support Enabled
INFO - 2020-09-22 03:30:15 --> Utf8 Class Initialized
INFO - 2020-09-22 03:30:15 --> Router Class Initialized
INFO - 2020-09-22 03:30:15 --> URI Class Initialized
INFO - 2020-09-22 03:30:15 --> Output Class Initialized
INFO - 2020-09-22 03:30:15 --> Router Class Initialized
INFO - 2020-09-22 03:30:15 --> Security Class Initialized
INFO - 2020-09-22 03:30:15 --> Output Class Initialized
DEBUG - 2020-09-22 03:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 03:30:15 --> Input Class Initialized
INFO - 2020-09-22 03:30:15 --> Security Class Initialized
INFO - 2020-09-22 03:30:15 --> Language Class Initialized
DEBUG - 2020-09-22 03:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 03:30:15 --> Input Class Initialized
INFO - 2020-09-22 03:30:15 --> Language Class Initialized
INFO - 2020-09-22 03:30:15 --> Loader Class Initialized
INFO - 2020-09-22 03:30:15 --> Helper loaded: url_helper
INFO - 2020-09-22 03:30:15 --> Loader Class Initialized
INFO - 2020-09-22 03:30:15 --> Helper loaded: url_helper
INFO - 2020-09-22 03:30:15 --> Database Driver Class Initialized
INFO - 2020-09-22 03:30:15 --> Database Driver Class Initialized
INFO - 2020-09-22 03:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 03:30:15 --> Email Class Initialized
INFO - 2020-09-22 03:30:15 --> Controller Class Initialized
INFO - 2020-09-22 03:30:15 --> Model Class Initialized
INFO - 2020-09-22 03:30:15 --> Model Class Initialized
DEBUG - 2020-09-22 03:30:15 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 03:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 03:30:15 --> Email Class Initialized
INFO - 2020-09-22 03:30:15 --> Controller Class Initialized
INFO - 2020-09-22 03:30:15 --> Model Class Initialized
INFO - 2020-09-22 03:30:15 --> Model Class Initialized
DEBUG - 2020-09-22 03:30:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 03:30:15 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-22 03:30:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 03:30:16 --> Config Class Initialized
INFO - 2020-09-22 03:30:16 --> Hooks Class Initialized
ERROR - 2020-09-22 03:30:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
DEBUG - 2020-09-22 03:30:16 --> UTF-8 Support Enabled
INFO - 2020-09-22 03:30:16 --> Utf8 Class Initialized
INFO - 2020-09-22 03:30:16 --> Config Class Initialized
INFO - 2020-09-22 03:30:16 --> Hooks Class Initialized
INFO - 2020-09-22 03:30:16 --> URI Class Initialized
DEBUG - 2020-09-22 03:30:16 --> No URI present. Default controller set.
INFO - 2020-09-22 03:30:16 --> Router Class Initialized
DEBUG - 2020-09-22 03:30:16 --> UTF-8 Support Enabled
INFO - 2020-09-22 03:30:16 --> Utf8 Class Initialized
INFO - 2020-09-22 03:30:16 --> Output Class Initialized
INFO - 2020-09-22 03:30:16 --> URI Class Initialized
INFO - 2020-09-22 03:30:16 --> Router Class Initialized
INFO - 2020-09-22 03:30:16 --> Security Class Initialized
DEBUG - 2020-09-22 03:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 03:30:16 --> Input Class Initialized
INFO - 2020-09-22 03:30:16 --> Output Class Initialized
INFO - 2020-09-22 03:30:16 --> Language Class Initialized
INFO - 2020-09-22 03:30:16 --> Security Class Initialized
DEBUG - 2020-09-22 03:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 03:30:16 --> Input Class Initialized
INFO - 2020-09-22 03:30:16 --> Loader Class Initialized
INFO - 2020-09-22 03:30:16 --> Language Class Initialized
INFO - 2020-09-22 03:30:16 --> Helper loaded: url_helper
INFO - 2020-09-22 03:30:16 --> Loader Class Initialized
INFO - 2020-09-22 03:30:16 --> Helper loaded: url_helper
INFO - 2020-09-22 03:30:16 --> Database Driver Class Initialized
INFO - 2020-09-22 03:30:16 --> Database Driver Class Initialized
INFO - 2020-09-22 03:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 03:30:16 --> Email Class Initialized
INFO - 2020-09-22 03:30:16 --> Controller Class Initialized
INFO - 2020-09-22 03:30:16 --> Model Class Initialized
INFO - 2020-09-22 03:30:16 --> Model Class Initialized
DEBUG - 2020-09-22 03:30:16 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 03:30:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 03:30:16 --> Final output sent to browser
DEBUG - 2020-09-22 03:30:16 --> Total execution time: 0.0200
INFO - 2020-09-22 03:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 03:30:16 --> Email Class Initialized
INFO - 2020-09-22 03:30:16 --> Controller Class Initialized
DEBUG - 2020-09-22 03:30:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 03:30:16 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-22 03:30:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 03:30:16 --> Config Class Initialized
INFO - 2020-09-22 03:30:16 --> Hooks Class Initialized
DEBUG - 2020-09-22 03:30:16 --> UTF-8 Support Enabled
INFO - 2020-09-22 03:30:16 --> Utf8 Class Initialized
INFO - 2020-09-22 03:30:16 --> URI Class Initialized
DEBUG - 2020-09-22 03:30:16 --> No URI present. Default controller set.
INFO - 2020-09-22 03:30:16 --> Router Class Initialized
INFO - 2020-09-22 03:30:16 --> Output Class Initialized
INFO - 2020-09-22 03:30:16 --> Security Class Initialized
DEBUG - 2020-09-22 03:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 03:30:16 --> Input Class Initialized
INFO - 2020-09-22 03:30:16 --> Language Class Initialized
INFO - 2020-09-22 03:30:16 --> Loader Class Initialized
INFO - 2020-09-22 03:30:16 --> Helper loaded: url_helper
INFO - 2020-09-22 03:30:16 --> Database Driver Class Initialized
INFO - 2020-09-22 03:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 03:30:16 --> Email Class Initialized
INFO - 2020-09-22 03:30:16 --> Controller Class Initialized
INFO - 2020-09-22 03:30:16 --> Model Class Initialized
INFO - 2020-09-22 03:30:16 --> Model Class Initialized
DEBUG - 2020-09-22 03:30:16 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 03:30:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 03:30:16 --> Final output sent to browser
DEBUG - 2020-09-22 03:30:16 --> Total execution time: 0.0191
ERROR - 2020-09-22 03:30:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 03:30:19 --> Config Class Initialized
INFO - 2020-09-22 03:30:19 --> Hooks Class Initialized
DEBUG - 2020-09-22 03:30:19 --> UTF-8 Support Enabled
INFO - 2020-09-22 03:30:19 --> Utf8 Class Initialized
INFO - 2020-09-22 03:30:19 --> URI Class Initialized
INFO - 2020-09-22 03:30:19 --> Router Class Initialized
INFO - 2020-09-22 03:30:19 --> Output Class Initialized
INFO - 2020-09-22 03:30:19 --> Security Class Initialized
DEBUG - 2020-09-22 03:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 03:30:19 --> Input Class Initialized
INFO - 2020-09-22 03:30:19 --> Language Class Initialized
INFO - 2020-09-22 03:30:19 --> Loader Class Initialized
INFO - 2020-09-22 03:30:19 --> Helper loaded: url_helper
INFO - 2020-09-22 03:30:19 --> Database Driver Class Initialized
INFO - 2020-09-22 03:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 03:30:19 --> Email Class Initialized
INFO - 2020-09-22 03:30:19 --> Controller Class Initialized
INFO - 2020-09-22 03:30:19 --> Model Class Initialized
INFO - 2020-09-22 03:30:19 --> Model Class Initialized
DEBUG - 2020-09-22 03:30:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 03:30:19 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-22 03:30:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 03:30:19 --> Config Class Initialized
INFO - 2020-09-22 03:30:19 --> Hooks Class Initialized
DEBUG - 2020-09-22 03:30:19 --> UTF-8 Support Enabled
INFO - 2020-09-22 03:30:19 --> Utf8 Class Initialized
INFO - 2020-09-22 03:30:19 --> URI Class Initialized
INFO - 2020-09-22 03:30:19 --> Router Class Initialized
INFO - 2020-09-22 03:30:19 --> Output Class Initialized
INFO - 2020-09-22 03:30:19 --> Security Class Initialized
DEBUG - 2020-09-22 03:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 03:30:19 --> Input Class Initialized
INFO - 2020-09-22 03:30:19 --> Language Class Initialized
INFO - 2020-09-22 03:30:19 --> Loader Class Initialized
INFO - 2020-09-22 03:30:19 --> Helper loaded: url_helper
INFO - 2020-09-22 03:30:19 --> Database Driver Class Initialized
INFO - 2020-09-22 03:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 03:30:19 --> Email Class Initialized
INFO - 2020-09-22 03:30:19 --> Controller Class Initialized
INFO - 2020-09-22 03:30:19 --> Model Class Initialized
INFO - 2020-09-22 03:30:19 --> Model Class Initialized
DEBUG - 2020-09-22 03:30:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-22 03:30:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 03:30:19 --> Config Class Initialized
INFO - 2020-09-22 03:30:19 --> Hooks Class Initialized
DEBUG - 2020-09-22 03:30:19 --> UTF-8 Support Enabled
INFO - 2020-09-22 03:30:19 --> Utf8 Class Initialized
INFO - 2020-09-22 03:30:19 --> URI Class Initialized
DEBUG - 2020-09-22 03:30:19 --> No URI present. Default controller set.
INFO - 2020-09-22 03:30:19 --> Router Class Initialized
INFO - 2020-09-22 03:30:19 --> Output Class Initialized
INFO - 2020-09-22 03:30:19 --> Security Class Initialized
DEBUG - 2020-09-22 03:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 03:30:19 --> Input Class Initialized
INFO - 2020-09-22 03:30:19 --> Language Class Initialized
INFO - 2020-09-22 03:30:19 --> Loader Class Initialized
INFO - 2020-09-22 03:30:19 --> Helper loaded: url_helper
INFO - 2020-09-22 03:30:19 --> Database Driver Class Initialized
INFO - 2020-09-22 03:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 03:30:19 --> Email Class Initialized
INFO - 2020-09-22 03:30:19 --> Controller Class Initialized
INFO - 2020-09-22 03:30:19 --> Model Class Initialized
INFO - 2020-09-22 03:30:19 --> Model Class Initialized
DEBUG - 2020-09-22 03:30:19 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 03:30:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 03:30:19 --> Final output sent to browser
DEBUG - 2020-09-22 03:30:19 --> Total execution time: 0.0215
ERROR - 2020-09-22 03:30:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 03:30:19 --> Config Class Initialized
INFO - 2020-09-22 03:30:19 --> Hooks Class Initialized
DEBUG - 2020-09-22 03:30:19 --> UTF-8 Support Enabled
INFO - 2020-09-22 03:30:19 --> Utf8 Class Initialized
INFO - 2020-09-22 03:30:19 --> URI Class Initialized
INFO - 2020-09-22 03:30:19 --> Router Class Initialized
INFO - 2020-09-22 03:30:19 --> Output Class Initialized
INFO - 2020-09-22 03:30:19 --> Security Class Initialized
DEBUG - 2020-09-22 03:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 03:30:19 --> Input Class Initialized
INFO - 2020-09-22 03:30:19 --> Language Class Initialized
INFO - 2020-09-22 03:30:19 --> Loader Class Initialized
INFO - 2020-09-22 03:30:19 --> Helper loaded: url_helper
INFO - 2020-09-22 03:30:19 --> Database Driver Class Initialized
INFO - 2020-09-22 03:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 03:30:19 --> Email Class Initialized
INFO - 2020-09-22 03:30:19 --> Controller Class Initialized
DEBUG - 2020-09-22 03:30:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 03:30:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 03:30:19 --> Model Class Initialized
INFO - 2020-09-22 03:30:19 --> Model Class Initialized
INFO - 2020-09-22 03:30:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-22 03:30:19 --> Final output sent to browser
DEBUG - 2020-09-22 03:30:19 --> Total execution time: 0.0367
ERROR - 2020-09-22 03:30:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 03:30:25 --> Config Class Initialized
INFO - 2020-09-22 03:30:25 --> Hooks Class Initialized
DEBUG - 2020-09-22 03:30:25 --> UTF-8 Support Enabled
INFO - 2020-09-22 03:30:25 --> Utf8 Class Initialized
INFO - 2020-09-22 03:30:25 --> URI Class Initialized
INFO - 2020-09-22 03:30:25 --> Router Class Initialized
INFO - 2020-09-22 03:30:25 --> Output Class Initialized
INFO - 2020-09-22 03:30:25 --> Security Class Initialized
DEBUG - 2020-09-22 03:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 03:30:25 --> Input Class Initialized
INFO - 2020-09-22 03:30:25 --> Language Class Initialized
INFO - 2020-09-22 03:30:25 --> Loader Class Initialized
INFO - 2020-09-22 03:30:25 --> Helper loaded: url_helper
INFO - 2020-09-22 03:30:25 --> Database Driver Class Initialized
INFO - 2020-09-22 03:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 03:30:25 --> Email Class Initialized
INFO - 2020-09-22 03:30:25 --> Controller Class Initialized
DEBUG - 2020-09-22 03:30:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 03:30:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 03:30:25 --> Model Class Initialized
INFO - 2020-09-22 03:30:25 --> Model Class Initialized
INFO - 2020-09-22 03:30:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 03:30:25 --> Final output sent to browser
DEBUG - 2020-09-22 03:30:25 --> Total execution time: 0.0254
ERROR - 2020-09-22 03:30:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 03:30:29 --> Config Class Initialized
INFO - 2020-09-22 03:30:29 --> Hooks Class Initialized
DEBUG - 2020-09-22 03:30:29 --> UTF-8 Support Enabled
INFO - 2020-09-22 03:30:29 --> Utf8 Class Initialized
INFO - 2020-09-22 03:30:29 --> URI Class Initialized
INFO - 2020-09-22 03:30:29 --> Router Class Initialized
INFO - 2020-09-22 03:30:29 --> Output Class Initialized
INFO - 2020-09-22 03:30:29 --> Security Class Initialized
DEBUG - 2020-09-22 03:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 03:30:29 --> Input Class Initialized
INFO - 2020-09-22 03:30:29 --> Language Class Initialized
INFO - 2020-09-22 03:30:29 --> Loader Class Initialized
INFO - 2020-09-22 03:30:29 --> Helper loaded: url_helper
INFO - 2020-09-22 03:30:29 --> Database Driver Class Initialized
INFO - 2020-09-22 03:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 03:30:29 --> Email Class Initialized
INFO - 2020-09-22 03:30:29 --> Controller Class Initialized
DEBUG - 2020-09-22 03:30:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 03:30:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 03:30:29 --> Model Class Initialized
INFO - 2020-09-22 03:30:29 --> Model Class Initialized
INFO - 2020-09-22 03:30:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 03:30:29 --> Final output sent to browser
DEBUG - 2020-09-22 03:30:29 --> Total execution time: 0.0265
ERROR - 2020-09-22 03:53:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 03:53:56 --> Config Class Initialized
INFO - 2020-09-22 03:53:56 --> Hooks Class Initialized
DEBUG - 2020-09-22 03:53:56 --> UTF-8 Support Enabled
INFO - 2020-09-22 03:53:56 --> Utf8 Class Initialized
INFO - 2020-09-22 03:53:56 --> URI Class Initialized
DEBUG - 2020-09-22 03:53:56 --> No URI present. Default controller set.
INFO - 2020-09-22 03:53:56 --> Router Class Initialized
INFO - 2020-09-22 03:53:56 --> Output Class Initialized
INFO - 2020-09-22 03:53:56 --> Security Class Initialized
DEBUG - 2020-09-22 03:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 03:53:56 --> Input Class Initialized
INFO - 2020-09-22 03:53:56 --> Language Class Initialized
INFO - 2020-09-22 03:53:56 --> Loader Class Initialized
INFO - 2020-09-22 03:53:56 --> Helper loaded: url_helper
INFO - 2020-09-22 03:53:56 --> Database Driver Class Initialized
INFO - 2020-09-22 03:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 03:53:56 --> Email Class Initialized
INFO - 2020-09-22 03:53:56 --> Controller Class Initialized
INFO - 2020-09-22 03:53:56 --> Model Class Initialized
INFO - 2020-09-22 03:53:56 --> Model Class Initialized
DEBUG - 2020-09-22 03:53:56 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 03:53:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 03:53:56 --> Final output sent to browser
DEBUG - 2020-09-22 03:53:56 --> Total execution time: 0.0229
ERROR - 2020-09-22 03:57:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 03:57:13 --> Config Class Initialized
INFO - 2020-09-22 03:57:13 --> Hooks Class Initialized
DEBUG - 2020-09-22 03:57:13 --> UTF-8 Support Enabled
INFO - 2020-09-22 03:57:13 --> Utf8 Class Initialized
INFO - 2020-09-22 03:57:13 --> URI Class Initialized
INFO - 2020-09-22 03:57:13 --> Router Class Initialized
INFO - 2020-09-22 03:57:13 --> Output Class Initialized
INFO - 2020-09-22 03:57:13 --> Security Class Initialized
DEBUG - 2020-09-22 03:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 03:57:13 --> Input Class Initialized
INFO - 2020-09-22 03:57:13 --> Language Class Initialized
INFO - 2020-09-22 03:57:13 --> Loader Class Initialized
INFO - 2020-09-22 03:57:13 --> Helper loaded: url_helper
INFO - 2020-09-22 03:57:13 --> Database Driver Class Initialized
INFO - 2020-09-22 03:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 03:57:13 --> Email Class Initialized
INFO - 2020-09-22 03:57:13 --> Controller Class Initialized
INFO - 2020-09-22 03:57:13 --> Model Class Initialized
INFO - 2020-09-22 03:57:13 --> Model Class Initialized
DEBUG - 2020-09-22 03:57:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-22 03:57:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 03:57:13 --> Config Class Initialized
INFO - 2020-09-22 03:57:13 --> Hooks Class Initialized
DEBUG - 2020-09-22 03:57:13 --> UTF-8 Support Enabled
INFO - 2020-09-22 03:57:13 --> Utf8 Class Initialized
INFO - 2020-09-22 03:57:13 --> URI Class Initialized
INFO - 2020-09-22 03:57:13 --> Router Class Initialized
INFO - 2020-09-22 03:57:13 --> Output Class Initialized
INFO - 2020-09-22 03:57:13 --> Security Class Initialized
DEBUG - 2020-09-22 03:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 03:57:13 --> Input Class Initialized
INFO - 2020-09-22 03:57:13 --> Language Class Initialized
INFO - 2020-09-22 03:57:13 --> Loader Class Initialized
INFO - 2020-09-22 03:57:13 --> Helper loaded: url_helper
INFO - 2020-09-22 03:57:13 --> Database Driver Class Initialized
INFO - 2020-09-22 03:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 03:57:13 --> Email Class Initialized
INFO - 2020-09-22 03:57:13 --> Controller Class Initialized
INFO - 2020-09-22 03:57:13 --> Model Class Initialized
INFO - 2020-09-22 03:57:13 --> Model Class Initialized
DEBUG - 2020-09-22 03:57:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 03:57:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 03:57:13 --> Model Class Initialized
INFO - 2020-09-22 03:57:13 --> Final output sent to browser
DEBUG - 2020-09-22 03:57:13 --> Total execution time: 0.0239
ERROR - 2020-09-22 03:57:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 03:57:13 --> Config Class Initialized
INFO - 2020-09-22 03:57:13 --> Hooks Class Initialized
DEBUG - 2020-09-22 03:57:13 --> UTF-8 Support Enabled
INFO - 2020-09-22 03:57:13 --> Utf8 Class Initialized
INFO - 2020-09-22 03:57:13 --> URI Class Initialized
INFO - 2020-09-22 03:57:13 --> Router Class Initialized
INFO - 2020-09-22 03:57:13 --> Output Class Initialized
INFO - 2020-09-22 03:57:13 --> Security Class Initialized
DEBUG - 2020-09-22 03:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 03:57:13 --> Input Class Initialized
INFO - 2020-09-22 03:57:13 --> Language Class Initialized
INFO - 2020-09-22 03:57:13 --> Loader Class Initialized
INFO - 2020-09-22 03:57:13 --> Helper loaded: url_helper
INFO - 2020-09-22 03:57:13 --> Database Driver Class Initialized
INFO - 2020-09-22 03:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 03:57:13 --> Email Class Initialized
INFO - 2020-09-22 03:57:13 --> Controller Class Initialized
DEBUG - 2020-09-22 03:57:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 03:57:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 03:57:13 --> Model Class Initialized
INFO - 2020-09-22 03:57:13 --> Model Class Initialized
INFO - 2020-09-22 03:57:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-22 03:57:13 --> Final output sent to browser
DEBUG - 2020-09-22 03:57:13 --> Total execution time: 0.0260
ERROR - 2020-09-22 03:57:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 03:57:18 --> Config Class Initialized
INFO - 2020-09-22 03:57:18 --> Hooks Class Initialized
DEBUG - 2020-09-22 03:57:18 --> UTF-8 Support Enabled
INFO - 2020-09-22 03:57:18 --> Utf8 Class Initialized
INFO - 2020-09-22 03:57:18 --> URI Class Initialized
INFO - 2020-09-22 03:57:18 --> Router Class Initialized
INFO - 2020-09-22 03:57:18 --> Output Class Initialized
INFO - 2020-09-22 03:57:18 --> Security Class Initialized
DEBUG - 2020-09-22 03:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 03:57:18 --> Input Class Initialized
INFO - 2020-09-22 03:57:18 --> Language Class Initialized
INFO - 2020-09-22 03:57:18 --> Loader Class Initialized
INFO - 2020-09-22 03:57:18 --> Helper loaded: url_helper
INFO - 2020-09-22 03:57:18 --> Database Driver Class Initialized
INFO - 2020-09-22 03:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 03:57:18 --> Email Class Initialized
INFO - 2020-09-22 03:57:18 --> Controller Class Initialized
DEBUG - 2020-09-22 03:57:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 03:57:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 03:57:18 --> Model Class Initialized
INFO - 2020-09-22 03:57:18 --> Model Class Initialized
INFO - 2020-09-22 03:57:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 03:57:18 --> Final output sent to browser
DEBUG - 2020-09-22 03:57:18 --> Total execution time: 0.0231
ERROR - 2020-09-22 03:57:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 03:57:21 --> Config Class Initialized
INFO - 2020-09-22 03:57:21 --> Hooks Class Initialized
DEBUG - 2020-09-22 03:57:21 --> UTF-8 Support Enabled
INFO - 2020-09-22 03:57:21 --> Utf8 Class Initialized
INFO - 2020-09-22 03:57:21 --> URI Class Initialized
INFO - 2020-09-22 03:57:21 --> Router Class Initialized
INFO - 2020-09-22 03:57:21 --> Output Class Initialized
INFO - 2020-09-22 03:57:21 --> Security Class Initialized
DEBUG - 2020-09-22 03:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 03:57:21 --> Input Class Initialized
INFO - 2020-09-22 03:57:21 --> Language Class Initialized
INFO - 2020-09-22 03:57:21 --> Loader Class Initialized
INFO - 2020-09-22 03:57:21 --> Helper loaded: url_helper
INFO - 2020-09-22 03:57:21 --> Database Driver Class Initialized
INFO - 2020-09-22 03:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 03:57:21 --> Email Class Initialized
INFO - 2020-09-22 03:57:21 --> Controller Class Initialized
DEBUG - 2020-09-22 03:57:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 03:57:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 03:57:21 --> Model Class Initialized
INFO - 2020-09-22 03:57:21 --> Model Class Initialized
INFO - 2020-09-22 03:57:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 03:57:21 --> Final output sent to browser
DEBUG - 2020-09-22 03:57:21 --> Total execution time: 0.1160
ERROR - 2020-09-22 05:13:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 05:13:51 --> Config Class Initialized
INFO - 2020-09-22 05:13:51 --> Hooks Class Initialized
DEBUG - 2020-09-22 05:13:51 --> UTF-8 Support Enabled
INFO - 2020-09-22 05:13:51 --> Utf8 Class Initialized
INFO - 2020-09-22 05:13:51 --> URI Class Initialized
DEBUG - 2020-09-22 05:13:51 --> No URI present. Default controller set.
INFO - 2020-09-22 05:13:51 --> Router Class Initialized
INFO - 2020-09-22 05:13:51 --> Output Class Initialized
INFO - 2020-09-22 05:13:51 --> Security Class Initialized
DEBUG - 2020-09-22 05:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 05:13:51 --> Input Class Initialized
INFO - 2020-09-22 05:13:51 --> Language Class Initialized
INFO - 2020-09-22 05:13:51 --> Loader Class Initialized
INFO - 2020-09-22 05:13:51 --> Helper loaded: url_helper
INFO - 2020-09-22 05:13:51 --> Database Driver Class Initialized
INFO - 2020-09-22 05:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 05:13:51 --> Email Class Initialized
INFO - 2020-09-22 05:13:51 --> Controller Class Initialized
INFO - 2020-09-22 05:13:51 --> Model Class Initialized
INFO - 2020-09-22 05:13:51 --> Model Class Initialized
DEBUG - 2020-09-22 05:13:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 05:13:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 05:13:51 --> Final output sent to browser
DEBUG - 2020-09-22 05:13:51 --> Total execution time: 0.0180
ERROR - 2020-09-22 05:17:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 05:17:26 --> Config Class Initialized
INFO - 2020-09-22 05:17:26 --> Hooks Class Initialized
DEBUG - 2020-09-22 05:17:26 --> UTF-8 Support Enabled
INFO - 2020-09-22 05:17:26 --> Utf8 Class Initialized
INFO - 2020-09-22 05:17:26 --> URI Class Initialized
DEBUG - 2020-09-22 05:17:26 --> No URI present. Default controller set.
INFO - 2020-09-22 05:17:26 --> Router Class Initialized
INFO - 2020-09-22 05:17:26 --> Output Class Initialized
INFO - 2020-09-22 05:17:26 --> Security Class Initialized
DEBUG - 2020-09-22 05:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 05:17:26 --> Input Class Initialized
INFO - 2020-09-22 05:17:26 --> Language Class Initialized
INFO - 2020-09-22 05:17:26 --> Loader Class Initialized
INFO - 2020-09-22 05:17:26 --> Helper loaded: url_helper
INFO - 2020-09-22 05:17:26 --> Database Driver Class Initialized
INFO - 2020-09-22 05:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 05:17:26 --> Email Class Initialized
INFO - 2020-09-22 05:17:26 --> Controller Class Initialized
INFO - 2020-09-22 05:17:26 --> Model Class Initialized
INFO - 2020-09-22 05:17:26 --> Model Class Initialized
DEBUG - 2020-09-22 05:17:26 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 05:17:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 05:17:26 --> Final output sent to browser
DEBUG - 2020-09-22 05:17:26 --> Total execution time: 0.0213
ERROR - 2020-09-22 05:21:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 05:21:57 --> Config Class Initialized
INFO - 2020-09-22 05:21:57 --> Hooks Class Initialized
DEBUG - 2020-09-22 05:21:57 --> UTF-8 Support Enabled
INFO - 2020-09-22 05:21:57 --> Utf8 Class Initialized
INFO - 2020-09-22 05:21:57 --> URI Class Initialized
INFO - 2020-09-22 05:21:57 --> Router Class Initialized
INFO - 2020-09-22 05:21:57 --> Output Class Initialized
INFO - 2020-09-22 05:21:57 --> Security Class Initialized
DEBUG - 2020-09-22 05:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 05:21:57 --> Input Class Initialized
INFO - 2020-09-22 05:21:57 --> Language Class Initialized
INFO - 2020-09-22 05:21:57 --> Loader Class Initialized
INFO - 2020-09-22 05:21:57 --> Helper loaded: url_helper
INFO - 2020-09-22 05:21:57 --> Database Driver Class Initialized
INFO - 2020-09-22 05:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 05:21:57 --> Email Class Initialized
INFO - 2020-09-22 05:21:57 --> Controller Class Initialized
INFO - 2020-09-22 05:21:57 --> Model Class Initialized
INFO - 2020-09-22 05:21:57 --> Model Class Initialized
DEBUG - 2020-09-22 05:21:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 05:21:57 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-22 05:21:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 05:21:57 --> Config Class Initialized
INFO - 2020-09-22 05:21:57 --> Hooks Class Initialized
DEBUG - 2020-09-22 05:21:57 --> UTF-8 Support Enabled
INFO - 2020-09-22 05:21:57 --> Utf8 Class Initialized
INFO - 2020-09-22 05:21:57 --> URI Class Initialized
INFO - 2020-09-22 05:21:57 --> Router Class Initialized
INFO - 2020-09-22 05:21:57 --> Output Class Initialized
INFO - 2020-09-22 05:21:57 --> Security Class Initialized
DEBUG - 2020-09-22 05:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 05:21:57 --> Input Class Initialized
INFO - 2020-09-22 05:21:57 --> Language Class Initialized
INFO - 2020-09-22 05:21:57 --> Loader Class Initialized
INFO - 2020-09-22 05:21:57 --> Helper loaded: url_helper
INFO - 2020-09-22 05:21:57 --> Database Driver Class Initialized
INFO - 2020-09-22 05:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 05:21:57 --> Email Class Initialized
INFO - 2020-09-22 05:21:57 --> Controller Class Initialized
INFO - 2020-09-22 05:21:57 --> Model Class Initialized
INFO - 2020-09-22 05:21:57 --> Model Class Initialized
DEBUG - 2020-09-22 05:21:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-22 05:21:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 05:21:57 --> Config Class Initialized
INFO - 2020-09-22 05:21:57 --> Hooks Class Initialized
DEBUG - 2020-09-22 05:21:57 --> UTF-8 Support Enabled
INFO - 2020-09-22 05:21:57 --> Utf8 Class Initialized
INFO - 2020-09-22 05:21:57 --> URI Class Initialized
DEBUG - 2020-09-22 05:21:57 --> No URI present. Default controller set.
INFO - 2020-09-22 05:21:57 --> Router Class Initialized
INFO - 2020-09-22 05:21:57 --> Output Class Initialized
INFO - 2020-09-22 05:21:57 --> Security Class Initialized
DEBUG - 2020-09-22 05:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 05:21:57 --> Input Class Initialized
INFO - 2020-09-22 05:21:57 --> Language Class Initialized
INFO - 2020-09-22 05:21:57 --> Loader Class Initialized
INFO - 2020-09-22 05:21:57 --> Helper loaded: url_helper
INFO - 2020-09-22 05:21:57 --> Database Driver Class Initialized
INFO - 2020-09-22 05:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 05:21:57 --> Email Class Initialized
INFO - 2020-09-22 05:21:57 --> Controller Class Initialized
INFO - 2020-09-22 05:21:57 --> Model Class Initialized
INFO - 2020-09-22 05:21:57 --> Model Class Initialized
DEBUG - 2020-09-22 05:21:57 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 05:21:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 05:21:57 --> Final output sent to browser
DEBUG - 2020-09-22 05:21:57 --> Total execution time: 0.0215
ERROR - 2020-09-22 05:21:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 05:21:57 --> Config Class Initialized
INFO - 2020-09-22 05:21:57 --> Hooks Class Initialized
DEBUG - 2020-09-22 05:21:57 --> UTF-8 Support Enabled
INFO - 2020-09-22 05:21:57 --> Utf8 Class Initialized
INFO - 2020-09-22 05:21:57 --> URI Class Initialized
INFO - 2020-09-22 05:21:57 --> Router Class Initialized
INFO - 2020-09-22 05:21:57 --> Output Class Initialized
INFO - 2020-09-22 05:21:57 --> Security Class Initialized
DEBUG - 2020-09-22 05:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 05:21:57 --> Input Class Initialized
INFO - 2020-09-22 05:21:57 --> Language Class Initialized
INFO - 2020-09-22 05:21:57 --> Loader Class Initialized
INFO - 2020-09-22 05:21:57 --> Helper loaded: url_helper
INFO - 2020-09-22 05:21:57 --> Database Driver Class Initialized
INFO - 2020-09-22 05:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 05:21:57 --> Email Class Initialized
INFO - 2020-09-22 05:21:57 --> Controller Class Initialized
DEBUG - 2020-09-22 05:21:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 05:21:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 05:21:57 --> Model Class Initialized
INFO - 2020-09-22 05:21:57 --> Model Class Initialized
INFO - 2020-09-22 05:21:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-22 05:21:57 --> Final output sent to browser
DEBUG - 2020-09-22 05:21:57 --> Total execution time: 0.0223
ERROR - 2020-09-22 05:22:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 05:22:03 --> Config Class Initialized
INFO - 2020-09-22 05:22:03 --> Hooks Class Initialized
DEBUG - 2020-09-22 05:22:03 --> UTF-8 Support Enabled
INFO - 2020-09-22 05:22:03 --> Utf8 Class Initialized
INFO - 2020-09-22 05:22:03 --> URI Class Initialized
INFO - 2020-09-22 05:22:03 --> Router Class Initialized
INFO - 2020-09-22 05:22:03 --> Output Class Initialized
INFO - 2020-09-22 05:22:03 --> Security Class Initialized
DEBUG - 2020-09-22 05:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 05:22:03 --> Input Class Initialized
INFO - 2020-09-22 05:22:03 --> Language Class Initialized
INFO - 2020-09-22 05:22:03 --> Loader Class Initialized
INFO - 2020-09-22 05:22:03 --> Helper loaded: url_helper
INFO - 2020-09-22 05:22:03 --> Database Driver Class Initialized
INFO - 2020-09-22 05:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 05:22:03 --> Email Class Initialized
INFO - 2020-09-22 05:22:03 --> Controller Class Initialized
DEBUG - 2020-09-22 05:22:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 05:22:03 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-22 05:22:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 05:22:03 --> Config Class Initialized
INFO - 2020-09-22 05:22:03 --> Hooks Class Initialized
DEBUG - 2020-09-22 05:22:03 --> UTF-8 Support Enabled
INFO - 2020-09-22 05:22:03 --> Utf8 Class Initialized
INFO - 2020-09-22 05:22:03 --> URI Class Initialized
DEBUG - 2020-09-22 05:22:03 --> No URI present. Default controller set.
INFO - 2020-09-22 05:22:03 --> Router Class Initialized
INFO - 2020-09-22 05:22:03 --> Output Class Initialized
INFO - 2020-09-22 05:22:03 --> Security Class Initialized
DEBUG - 2020-09-22 05:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 05:22:03 --> Input Class Initialized
INFO - 2020-09-22 05:22:03 --> Language Class Initialized
INFO - 2020-09-22 05:22:03 --> Loader Class Initialized
INFO - 2020-09-22 05:22:03 --> Helper loaded: url_helper
INFO - 2020-09-22 05:22:03 --> Database Driver Class Initialized
INFO - 2020-09-22 05:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 05:22:03 --> Email Class Initialized
INFO - 2020-09-22 05:22:03 --> Controller Class Initialized
INFO - 2020-09-22 05:22:03 --> Model Class Initialized
INFO - 2020-09-22 05:22:03 --> Model Class Initialized
DEBUG - 2020-09-22 05:22:03 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 05:22:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 05:22:03 --> Final output sent to browser
DEBUG - 2020-09-22 05:22:03 --> Total execution time: 0.0197
ERROR - 2020-09-22 05:22:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-22 05:22:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 05:22:07 --> Config Class Initialized
INFO - 2020-09-22 05:22:07 --> Hooks Class Initialized
INFO - 2020-09-22 05:22:07 --> Config Class Initialized
INFO - 2020-09-22 05:22:07 --> Hooks Class Initialized
DEBUG - 2020-09-22 05:22:07 --> UTF-8 Support Enabled
INFO - 2020-09-22 05:22:07 --> Utf8 Class Initialized
DEBUG - 2020-09-22 05:22:07 --> UTF-8 Support Enabled
INFO - 2020-09-22 05:22:07 --> Utf8 Class Initialized
INFO - 2020-09-22 05:22:07 --> URI Class Initialized
INFO - 2020-09-22 05:22:07 --> URI Class Initialized
INFO - 2020-09-22 05:22:07 --> Router Class Initialized
INFO - 2020-09-22 05:22:07 --> Router Class Initialized
INFO - 2020-09-22 05:22:07 --> Output Class Initialized
INFO - 2020-09-22 05:22:07 --> Output Class Initialized
INFO - 2020-09-22 05:22:07 --> Security Class Initialized
INFO - 2020-09-22 05:22:07 --> Security Class Initialized
DEBUG - 2020-09-22 05:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 05:22:07 --> Input Class Initialized
DEBUG - 2020-09-22 05:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 05:22:07 --> Input Class Initialized
INFO - 2020-09-22 05:22:07 --> Language Class Initialized
INFO - 2020-09-22 05:22:07 --> Language Class Initialized
INFO - 2020-09-22 05:22:07 --> Loader Class Initialized
INFO - 2020-09-22 05:22:07 --> Loader Class Initialized
INFO - 2020-09-22 05:22:07 --> Helper loaded: url_helper
INFO - 2020-09-22 05:22:07 --> Helper loaded: url_helper
INFO - 2020-09-22 05:22:07 --> Database Driver Class Initialized
INFO - 2020-09-22 05:22:07 --> Database Driver Class Initialized
INFO - 2020-09-22 05:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 05:22:07 --> Email Class Initialized
INFO - 2020-09-22 05:22:07 --> Controller Class Initialized
INFO - 2020-09-22 05:22:07 --> Model Class Initialized
INFO - 2020-09-22 05:22:07 --> Model Class Initialized
DEBUG - 2020-09-22 05:22:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 05:22:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 05:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 05:22:07 --> Email Class Initialized
INFO - 2020-09-22 05:22:07 --> Controller Class Initialized
INFO - 2020-09-22 05:22:07 --> Model Class Initialized
INFO - 2020-09-22 05:22:07 --> Model Class Initialized
DEBUG - 2020-09-22 05:22:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-22 05:22:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 05:22:07 --> Config Class Initialized
INFO - 2020-09-22 05:22:07 --> Hooks Class Initialized
DEBUG - 2020-09-22 05:22:07 --> UTF-8 Support Enabled
INFO - 2020-09-22 05:22:07 --> Utf8 Class Initialized
INFO - 2020-09-22 05:22:07 --> URI Class Initialized
DEBUG - 2020-09-22 05:22:07 --> No URI present. Default controller set.
INFO - 2020-09-22 05:22:07 --> Router Class Initialized
INFO - 2020-09-22 05:22:07 --> Output Class Initialized
INFO - 2020-09-22 05:22:07 --> Security Class Initialized
DEBUG - 2020-09-22 05:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 05:22:07 --> Input Class Initialized
INFO - 2020-09-22 05:22:07 --> Language Class Initialized
INFO - 2020-09-22 05:22:07 --> Loader Class Initialized
INFO - 2020-09-22 05:22:07 --> Helper loaded: url_helper
INFO - 2020-09-22 05:22:07 --> Database Driver Class Initialized
INFO - 2020-09-22 05:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 05:22:07 --> Email Class Initialized
INFO - 2020-09-22 05:22:07 --> Controller Class Initialized
INFO - 2020-09-22 05:22:07 --> Model Class Initialized
INFO - 2020-09-22 05:22:07 --> Model Class Initialized
DEBUG - 2020-09-22 05:22:07 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 05:22:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 05:22:07 --> Final output sent to browser
DEBUG - 2020-09-22 05:22:07 --> Total execution time: 0.0216
ERROR - 2020-09-22 05:22:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 05:22:07 --> Config Class Initialized
INFO - 2020-09-22 05:22:07 --> Hooks Class Initialized
DEBUG - 2020-09-22 05:22:07 --> UTF-8 Support Enabled
INFO - 2020-09-22 05:22:07 --> Utf8 Class Initialized
INFO - 2020-09-22 05:22:07 --> URI Class Initialized
INFO - 2020-09-22 05:22:07 --> Router Class Initialized
INFO - 2020-09-22 05:22:07 --> Output Class Initialized
INFO - 2020-09-22 05:22:07 --> Security Class Initialized
DEBUG - 2020-09-22 05:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 05:22:07 --> Input Class Initialized
INFO - 2020-09-22 05:22:07 --> Language Class Initialized
INFO - 2020-09-22 05:22:07 --> Loader Class Initialized
INFO - 2020-09-22 05:22:07 --> Helper loaded: url_helper
INFO - 2020-09-22 05:22:07 --> Database Driver Class Initialized
INFO - 2020-09-22 05:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 05:22:07 --> Email Class Initialized
INFO - 2020-09-22 05:22:07 --> Controller Class Initialized
DEBUG - 2020-09-22 05:22:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 05:22:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 05:22:07 --> Model Class Initialized
INFO - 2020-09-22 05:22:07 --> Model Class Initialized
INFO - 2020-09-22 05:22:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-22 05:22:07 --> Final output sent to browser
DEBUG - 2020-09-22 05:22:07 --> Total execution time: 0.0263
ERROR - 2020-09-22 05:22:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 05:22:11 --> Config Class Initialized
INFO - 2020-09-22 05:22:11 --> Hooks Class Initialized
DEBUG - 2020-09-22 05:22:11 --> UTF-8 Support Enabled
INFO - 2020-09-22 05:22:11 --> Utf8 Class Initialized
INFO - 2020-09-22 05:22:11 --> URI Class Initialized
INFO - 2020-09-22 05:22:11 --> Router Class Initialized
INFO - 2020-09-22 05:22:11 --> Output Class Initialized
INFO - 2020-09-22 05:22:11 --> Security Class Initialized
DEBUG - 2020-09-22 05:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 05:22:11 --> Input Class Initialized
INFO - 2020-09-22 05:22:11 --> Language Class Initialized
INFO - 2020-09-22 05:22:11 --> Loader Class Initialized
INFO - 2020-09-22 05:22:11 --> Helper loaded: url_helper
INFO - 2020-09-22 05:22:11 --> Database Driver Class Initialized
INFO - 2020-09-22 05:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 05:22:11 --> Email Class Initialized
INFO - 2020-09-22 05:22:11 --> Controller Class Initialized
DEBUG - 2020-09-22 05:22:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 05:22:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 05:22:11 --> Model Class Initialized
INFO - 2020-09-22 05:22:11 --> Model Class Initialized
INFO - 2020-09-22 05:22:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 05:22:11 --> Final output sent to browser
DEBUG - 2020-09-22 05:22:11 --> Total execution time: 0.0235
ERROR - 2020-09-22 05:22:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 05:22:14 --> Config Class Initialized
INFO - 2020-09-22 05:22:14 --> Hooks Class Initialized
DEBUG - 2020-09-22 05:22:14 --> UTF-8 Support Enabled
INFO - 2020-09-22 05:22:14 --> Utf8 Class Initialized
INFO - 2020-09-22 05:22:14 --> URI Class Initialized
INFO - 2020-09-22 05:22:14 --> Router Class Initialized
INFO - 2020-09-22 05:22:14 --> Output Class Initialized
INFO - 2020-09-22 05:22:14 --> Security Class Initialized
DEBUG - 2020-09-22 05:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 05:22:14 --> Input Class Initialized
INFO - 2020-09-22 05:22:14 --> Language Class Initialized
INFO - 2020-09-22 05:22:14 --> Loader Class Initialized
INFO - 2020-09-22 05:22:14 --> Helper loaded: url_helper
INFO - 2020-09-22 05:22:14 --> Database Driver Class Initialized
INFO - 2020-09-22 05:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 05:22:14 --> Email Class Initialized
INFO - 2020-09-22 05:22:14 --> Controller Class Initialized
DEBUG - 2020-09-22 05:22:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 05:22:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 05:22:14 --> Model Class Initialized
INFO - 2020-09-22 05:22:14 --> Model Class Initialized
INFO - 2020-09-22 05:22:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 05:22:14 --> Final output sent to browser
DEBUG - 2020-09-22 05:22:14 --> Total execution time: 0.0282
ERROR - 2020-09-22 05:22:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 05:22:14 --> Config Class Initialized
INFO - 2020-09-22 05:22:14 --> Hooks Class Initialized
DEBUG - 2020-09-22 05:22:14 --> UTF-8 Support Enabled
INFO - 2020-09-22 05:22:14 --> Utf8 Class Initialized
INFO - 2020-09-22 05:22:14 --> URI Class Initialized
INFO - 2020-09-22 05:22:14 --> Router Class Initialized
INFO - 2020-09-22 05:22:14 --> Output Class Initialized
INFO - 2020-09-22 05:22:14 --> Security Class Initialized
DEBUG - 2020-09-22 05:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 05:22:14 --> Input Class Initialized
INFO - 2020-09-22 05:22:14 --> Language Class Initialized
INFO - 2020-09-22 05:22:14 --> Loader Class Initialized
INFO - 2020-09-22 05:22:14 --> Helper loaded: url_helper
INFO - 2020-09-22 05:22:14 --> Database Driver Class Initialized
INFO - 2020-09-22 05:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 05:22:14 --> Email Class Initialized
INFO - 2020-09-22 05:22:14 --> Controller Class Initialized
DEBUG - 2020-09-22 05:22:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 05:22:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 05:22:14 --> Model Class Initialized
INFO - 2020-09-22 05:22:14 --> Model Class Initialized
INFO - 2020-09-22 05:22:14 --> Final output sent to browser
DEBUG - 2020-09-22 05:22:14 --> Total execution time: 0.0385
ERROR - 2020-09-22 06:01:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:01:50 --> Config Class Initialized
INFO - 2020-09-22 06:01:50 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:01:50 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:01:50 --> Utf8 Class Initialized
INFO - 2020-09-22 06:01:50 --> URI Class Initialized
DEBUG - 2020-09-22 06:01:50 --> No URI present. Default controller set.
INFO - 2020-09-22 06:01:50 --> Router Class Initialized
INFO - 2020-09-22 06:01:50 --> Output Class Initialized
INFO - 2020-09-22 06:01:50 --> Security Class Initialized
DEBUG - 2020-09-22 06:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:01:50 --> Input Class Initialized
INFO - 2020-09-22 06:01:50 --> Language Class Initialized
INFO - 2020-09-22 06:01:50 --> Loader Class Initialized
INFO - 2020-09-22 06:01:50 --> Helper loaded: url_helper
INFO - 2020-09-22 06:01:50 --> Database Driver Class Initialized
INFO - 2020-09-22 06:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:01:50 --> Email Class Initialized
INFO - 2020-09-22 06:01:50 --> Controller Class Initialized
INFO - 2020-09-22 06:01:50 --> Model Class Initialized
INFO - 2020-09-22 06:01:50 --> Model Class Initialized
DEBUG - 2020-09-22 06:01:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:01:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 06:01:50 --> Final output sent to browser
DEBUG - 2020-09-22 06:01:50 --> Total execution time: 0.0193
ERROR - 2020-09-22 06:12:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:12:15 --> Config Class Initialized
INFO - 2020-09-22 06:12:15 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:12:15 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:12:15 --> Utf8 Class Initialized
INFO - 2020-09-22 06:12:15 --> URI Class Initialized
INFO - 2020-09-22 06:12:15 --> Router Class Initialized
INFO - 2020-09-22 06:12:15 --> Output Class Initialized
INFO - 2020-09-22 06:12:15 --> Security Class Initialized
DEBUG - 2020-09-22 06:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:12:15 --> Input Class Initialized
INFO - 2020-09-22 06:12:15 --> Language Class Initialized
INFO - 2020-09-22 06:12:15 --> Loader Class Initialized
INFO - 2020-09-22 06:12:15 --> Helper loaded: url_helper
INFO - 2020-09-22 06:12:15 --> Database Driver Class Initialized
INFO - 2020-09-22 06:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:12:15 --> Email Class Initialized
INFO - 2020-09-22 06:12:15 --> Controller Class Initialized
INFO - 2020-09-22 06:12:15 --> Model Class Initialized
INFO - 2020-09-22 06:12:15 --> Model Class Initialized
DEBUG - 2020-09-22 06:12:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-22 06:12:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:12:15 --> Config Class Initialized
INFO - 2020-09-22 06:12:15 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:12:15 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:12:15 --> Utf8 Class Initialized
INFO - 2020-09-22 06:12:15 --> URI Class Initialized
INFO - 2020-09-22 06:12:15 --> Router Class Initialized
INFO - 2020-09-22 06:12:15 --> Output Class Initialized
INFO - 2020-09-22 06:12:15 --> Security Class Initialized
DEBUG - 2020-09-22 06:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:12:15 --> Input Class Initialized
INFO - 2020-09-22 06:12:15 --> Language Class Initialized
INFO - 2020-09-22 06:12:15 --> Loader Class Initialized
INFO - 2020-09-22 06:12:15 --> Helper loaded: url_helper
INFO - 2020-09-22 06:12:15 --> Database Driver Class Initialized
INFO - 2020-09-22 06:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:12:15 --> Email Class Initialized
INFO - 2020-09-22 06:12:15 --> Controller Class Initialized
INFO - 2020-09-22 06:12:15 --> Model Class Initialized
INFO - 2020-09-22 06:12:15 --> Model Class Initialized
DEBUG - 2020-09-22 06:12:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:12:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:12:15 --> Model Class Initialized
INFO - 2020-09-22 06:12:15 --> Final output sent to browser
DEBUG - 2020-09-22 06:12:15 --> Total execution time: 0.0207
ERROR - 2020-09-22 06:12:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:12:16 --> Config Class Initialized
INFO - 2020-09-22 06:12:16 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:12:16 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:12:16 --> Utf8 Class Initialized
INFO - 2020-09-22 06:12:16 --> URI Class Initialized
INFO - 2020-09-22 06:12:16 --> Router Class Initialized
INFO - 2020-09-22 06:12:16 --> Output Class Initialized
INFO - 2020-09-22 06:12:16 --> Security Class Initialized
DEBUG - 2020-09-22 06:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:12:16 --> Input Class Initialized
INFO - 2020-09-22 06:12:16 --> Language Class Initialized
INFO - 2020-09-22 06:12:16 --> Loader Class Initialized
INFO - 2020-09-22 06:12:16 --> Helper loaded: url_helper
INFO - 2020-09-22 06:12:16 --> Database Driver Class Initialized
INFO - 2020-09-22 06:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:12:16 --> Email Class Initialized
INFO - 2020-09-22 06:12:16 --> Controller Class Initialized
DEBUG - 2020-09-22 06:12:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:12:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:12:16 --> Model Class Initialized
INFO - 2020-09-22 06:12:16 --> Model Class Initialized
INFO - 2020-09-22 06:12:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-22 06:12:16 --> Final output sent to browser
DEBUG - 2020-09-22 06:12:16 --> Total execution time: 0.0272
ERROR - 2020-09-22 06:12:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:12:18 --> Config Class Initialized
INFO - 2020-09-22 06:12:18 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:12:18 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:12:18 --> Utf8 Class Initialized
INFO - 2020-09-22 06:12:18 --> URI Class Initialized
INFO - 2020-09-22 06:12:18 --> Router Class Initialized
INFO - 2020-09-22 06:12:18 --> Output Class Initialized
INFO - 2020-09-22 06:12:18 --> Security Class Initialized
DEBUG - 2020-09-22 06:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:12:18 --> Input Class Initialized
INFO - 2020-09-22 06:12:18 --> Language Class Initialized
INFO - 2020-09-22 06:12:18 --> Loader Class Initialized
INFO - 2020-09-22 06:12:18 --> Helper loaded: url_helper
INFO - 2020-09-22 06:12:18 --> Database Driver Class Initialized
INFO - 2020-09-22 06:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:12:18 --> Email Class Initialized
INFO - 2020-09-22 06:12:18 --> Controller Class Initialized
DEBUG - 2020-09-22 06:12:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:12:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:12:18 --> Model Class Initialized
INFO - 2020-09-22 06:12:18 --> Model Class Initialized
INFO - 2020-09-22 06:12:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 06:12:18 --> Final output sent to browser
DEBUG - 2020-09-22 06:12:18 --> Total execution time: 0.0268
ERROR - 2020-09-22 06:12:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:12:23 --> Config Class Initialized
INFO - 2020-09-22 06:12:23 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:12:23 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:12:23 --> Utf8 Class Initialized
INFO - 2020-09-22 06:12:23 --> URI Class Initialized
INFO - 2020-09-22 06:12:23 --> Router Class Initialized
INFO - 2020-09-22 06:12:23 --> Output Class Initialized
INFO - 2020-09-22 06:12:23 --> Security Class Initialized
DEBUG - 2020-09-22 06:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:12:23 --> Input Class Initialized
INFO - 2020-09-22 06:12:23 --> Language Class Initialized
INFO - 2020-09-22 06:12:23 --> Loader Class Initialized
INFO - 2020-09-22 06:12:23 --> Helper loaded: url_helper
INFO - 2020-09-22 06:12:23 --> Database Driver Class Initialized
INFO - 2020-09-22 06:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:12:23 --> Email Class Initialized
INFO - 2020-09-22 06:12:23 --> Controller Class Initialized
DEBUG - 2020-09-22 06:12:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:12:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:12:23 --> Model Class Initialized
INFO - 2020-09-22 06:12:23 --> Model Class Initialized
INFO - 2020-09-22 06:12:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 06:12:23 --> Final output sent to browser
DEBUG - 2020-09-22 06:12:23 --> Total execution time: 0.0357
ERROR - 2020-09-22 06:12:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:12:24 --> Config Class Initialized
INFO - 2020-09-22 06:12:24 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:12:24 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:12:24 --> Utf8 Class Initialized
INFO - 2020-09-22 06:12:24 --> URI Class Initialized
INFO - 2020-09-22 06:12:24 --> Router Class Initialized
INFO - 2020-09-22 06:12:24 --> Output Class Initialized
INFO - 2020-09-22 06:12:24 --> Security Class Initialized
DEBUG - 2020-09-22 06:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:12:24 --> Input Class Initialized
INFO - 2020-09-22 06:12:24 --> Language Class Initialized
INFO - 2020-09-22 06:12:24 --> Loader Class Initialized
INFO - 2020-09-22 06:12:24 --> Helper loaded: url_helper
INFO - 2020-09-22 06:12:24 --> Database Driver Class Initialized
INFO - 2020-09-22 06:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:12:24 --> Email Class Initialized
INFO - 2020-09-22 06:12:24 --> Controller Class Initialized
DEBUG - 2020-09-22 06:12:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:12:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:12:24 --> Model Class Initialized
INFO - 2020-09-22 06:12:24 --> Model Class Initialized
INFO - 2020-09-22 06:12:24 --> Final output sent to browser
DEBUG - 2020-09-22 06:12:24 --> Total execution time: 0.0286
ERROR - 2020-09-22 06:14:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:14:24 --> Config Class Initialized
INFO - 2020-09-22 06:14:24 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:14:24 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:14:24 --> Utf8 Class Initialized
INFO - 2020-09-22 06:14:24 --> URI Class Initialized
INFO - 2020-09-22 06:14:24 --> Router Class Initialized
INFO - 2020-09-22 06:14:24 --> Output Class Initialized
INFO - 2020-09-22 06:14:24 --> Security Class Initialized
DEBUG - 2020-09-22 06:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:14:24 --> Input Class Initialized
INFO - 2020-09-22 06:14:24 --> Language Class Initialized
INFO - 2020-09-22 06:14:24 --> Loader Class Initialized
INFO - 2020-09-22 06:14:24 --> Helper loaded: url_helper
INFO - 2020-09-22 06:14:24 --> Database Driver Class Initialized
INFO - 2020-09-22 06:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:14:24 --> Email Class Initialized
INFO - 2020-09-22 06:14:24 --> Controller Class Initialized
DEBUG - 2020-09-22 06:14:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:14:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:14:24 --> Model Class Initialized
INFO - 2020-09-22 06:14:24 --> Model Class Initialized
INFO - 2020-09-22 06:14:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 06:14:24 --> Final output sent to browser
DEBUG - 2020-09-22 06:14:24 --> Total execution time: 0.0404
ERROR - 2020-09-22 06:14:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:14:25 --> Config Class Initialized
INFO - 2020-09-22 06:14:25 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:14:25 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:14:25 --> Utf8 Class Initialized
INFO - 2020-09-22 06:14:25 --> URI Class Initialized
INFO - 2020-09-22 06:14:25 --> Router Class Initialized
INFO - 2020-09-22 06:14:25 --> Output Class Initialized
INFO - 2020-09-22 06:14:25 --> Security Class Initialized
DEBUG - 2020-09-22 06:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:14:25 --> Input Class Initialized
INFO - 2020-09-22 06:14:25 --> Language Class Initialized
INFO - 2020-09-22 06:14:25 --> Loader Class Initialized
INFO - 2020-09-22 06:14:25 --> Helper loaded: url_helper
INFO - 2020-09-22 06:14:25 --> Database Driver Class Initialized
INFO - 2020-09-22 06:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:14:25 --> Email Class Initialized
INFO - 2020-09-22 06:14:25 --> Controller Class Initialized
DEBUG - 2020-09-22 06:14:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:14:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:14:25 --> Model Class Initialized
INFO - 2020-09-22 06:14:25 --> Model Class Initialized
INFO - 2020-09-22 06:14:25 --> Final output sent to browser
DEBUG - 2020-09-22 06:14:25 --> Total execution time: 0.0260
ERROR - 2020-09-22 06:19:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:19:54 --> Config Class Initialized
INFO - 2020-09-22 06:19:54 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:19:54 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:19:54 --> Utf8 Class Initialized
INFO - 2020-09-22 06:19:54 --> URI Class Initialized
INFO - 2020-09-22 06:19:54 --> Router Class Initialized
INFO - 2020-09-22 06:19:54 --> Output Class Initialized
INFO - 2020-09-22 06:19:54 --> Security Class Initialized
DEBUG - 2020-09-22 06:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:19:54 --> Input Class Initialized
INFO - 2020-09-22 06:19:54 --> Language Class Initialized
INFO - 2020-09-22 06:19:54 --> Loader Class Initialized
INFO - 2020-09-22 06:19:54 --> Helper loaded: url_helper
INFO - 2020-09-22 06:19:54 --> Database Driver Class Initialized
INFO - 2020-09-22 06:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:19:54 --> Email Class Initialized
INFO - 2020-09-22 06:19:54 --> Controller Class Initialized
DEBUG - 2020-09-22 06:19:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:19:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:19:54 --> Model Class Initialized
INFO - 2020-09-22 06:19:54 --> Model Class Initialized
INFO - 2020-09-22 06:19:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 06:19:54 --> Final output sent to browser
DEBUG - 2020-09-22 06:19:54 --> Total execution time: 0.0266
ERROR - 2020-09-22 06:20:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:20:48 --> Config Class Initialized
INFO - 2020-09-22 06:20:48 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:20:48 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:20:48 --> Utf8 Class Initialized
INFO - 2020-09-22 06:20:48 --> URI Class Initialized
INFO - 2020-09-22 06:20:48 --> Router Class Initialized
INFO - 2020-09-22 06:20:48 --> Output Class Initialized
INFO - 2020-09-22 06:20:48 --> Security Class Initialized
DEBUG - 2020-09-22 06:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:20:48 --> Input Class Initialized
INFO - 2020-09-22 06:20:48 --> Language Class Initialized
INFO - 2020-09-22 06:20:48 --> Loader Class Initialized
INFO - 2020-09-22 06:20:48 --> Helper loaded: url_helper
INFO - 2020-09-22 06:20:48 --> Database Driver Class Initialized
INFO - 2020-09-22 06:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:20:48 --> Email Class Initialized
INFO - 2020-09-22 06:20:48 --> Controller Class Initialized
DEBUG - 2020-09-22 06:20:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:20:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:20:48 --> Model Class Initialized
INFO - 2020-09-22 06:20:48 --> Model Class Initialized
INFO - 2020-09-22 06:20:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 06:20:48 --> Final output sent to browser
DEBUG - 2020-09-22 06:20:48 --> Total execution time: 0.0285
ERROR - 2020-09-22 06:20:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:20:49 --> Config Class Initialized
INFO - 2020-09-22 06:20:49 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:20:49 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:20:49 --> Utf8 Class Initialized
INFO - 2020-09-22 06:20:49 --> URI Class Initialized
INFO - 2020-09-22 06:20:49 --> Router Class Initialized
INFO - 2020-09-22 06:20:49 --> Output Class Initialized
INFO - 2020-09-22 06:20:49 --> Security Class Initialized
DEBUG - 2020-09-22 06:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:20:49 --> Input Class Initialized
INFO - 2020-09-22 06:20:49 --> Language Class Initialized
INFO - 2020-09-22 06:20:49 --> Loader Class Initialized
INFO - 2020-09-22 06:20:49 --> Helper loaded: url_helper
INFO - 2020-09-22 06:20:49 --> Database Driver Class Initialized
INFO - 2020-09-22 06:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:20:49 --> Email Class Initialized
INFO - 2020-09-22 06:20:49 --> Controller Class Initialized
DEBUG - 2020-09-22 06:20:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:20:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:20:49 --> Model Class Initialized
INFO - 2020-09-22 06:20:49 --> Model Class Initialized
INFO - 2020-09-22 06:20:49 --> Final output sent to browser
DEBUG - 2020-09-22 06:20:49 --> Total execution time: 0.0240
ERROR - 2020-09-22 06:21:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:21:10 --> Config Class Initialized
INFO - 2020-09-22 06:21:10 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:21:10 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:21:10 --> Utf8 Class Initialized
INFO - 2020-09-22 06:21:10 --> URI Class Initialized
INFO - 2020-09-22 06:21:10 --> Router Class Initialized
INFO - 2020-09-22 06:21:10 --> Output Class Initialized
INFO - 2020-09-22 06:21:10 --> Security Class Initialized
DEBUG - 2020-09-22 06:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:21:10 --> Input Class Initialized
INFO - 2020-09-22 06:21:10 --> Language Class Initialized
INFO - 2020-09-22 06:21:10 --> Loader Class Initialized
INFO - 2020-09-22 06:21:10 --> Helper loaded: url_helper
INFO - 2020-09-22 06:21:10 --> Database Driver Class Initialized
INFO - 2020-09-22 06:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:21:10 --> Email Class Initialized
INFO - 2020-09-22 06:21:10 --> Controller Class Initialized
DEBUG - 2020-09-22 06:21:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:21:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:21:10 --> Model Class Initialized
INFO - 2020-09-22 06:21:10 --> Model Class Initialized
INFO - 2020-09-22 06:21:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 06:21:10 --> Final output sent to browser
DEBUG - 2020-09-22 06:21:10 --> Total execution time: 0.0271
ERROR - 2020-09-22 06:21:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:21:10 --> Config Class Initialized
INFO - 2020-09-22 06:21:10 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:21:10 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:21:10 --> Utf8 Class Initialized
INFO - 2020-09-22 06:21:10 --> URI Class Initialized
INFO - 2020-09-22 06:21:10 --> Router Class Initialized
INFO - 2020-09-22 06:21:10 --> Output Class Initialized
INFO - 2020-09-22 06:21:10 --> Security Class Initialized
DEBUG - 2020-09-22 06:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:21:10 --> Input Class Initialized
INFO - 2020-09-22 06:21:10 --> Language Class Initialized
INFO - 2020-09-22 06:21:10 --> Loader Class Initialized
INFO - 2020-09-22 06:21:10 --> Helper loaded: url_helper
INFO - 2020-09-22 06:21:10 --> Database Driver Class Initialized
INFO - 2020-09-22 06:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:21:10 --> Email Class Initialized
INFO - 2020-09-22 06:21:10 --> Controller Class Initialized
DEBUG - 2020-09-22 06:21:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:21:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:21:10 --> Model Class Initialized
INFO - 2020-09-22 06:21:10 --> Model Class Initialized
INFO - 2020-09-22 06:21:10 --> Final output sent to browser
DEBUG - 2020-09-22 06:21:10 --> Total execution time: 0.0277
ERROR - 2020-09-22 06:22:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:22:03 --> Config Class Initialized
INFO - 2020-09-22 06:22:03 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:22:03 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:22:03 --> Utf8 Class Initialized
INFO - 2020-09-22 06:22:03 --> URI Class Initialized
INFO - 2020-09-22 06:22:03 --> Router Class Initialized
INFO - 2020-09-22 06:22:03 --> Output Class Initialized
INFO - 2020-09-22 06:22:03 --> Security Class Initialized
DEBUG - 2020-09-22 06:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:22:03 --> Input Class Initialized
INFO - 2020-09-22 06:22:03 --> Language Class Initialized
INFO - 2020-09-22 06:22:03 --> Loader Class Initialized
INFO - 2020-09-22 06:22:03 --> Helper loaded: url_helper
INFO - 2020-09-22 06:22:03 --> Database Driver Class Initialized
INFO - 2020-09-22 06:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:22:03 --> Email Class Initialized
INFO - 2020-09-22 06:22:03 --> Controller Class Initialized
DEBUG - 2020-09-22 06:22:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:22:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:22:03 --> Model Class Initialized
INFO - 2020-09-22 06:22:03 --> Model Class Initialized
INFO - 2020-09-22 06:22:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 06:22:03 --> Final output sent to browser
DEBUG - 2020-09-22 06:22:03 --> Total execution time: 0.0284
ERROR - 2020-09-22 06:22:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:22:28 --> Config Class Initialized
INFO - 2020-09-22 06:22:28 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:22:28 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:22:28 --> Utf8 Class Initialized
INFO - 2020-09-22 06:22:28 --> URI Class Initialized
INFO - 2020-09-22 06:22:28 --> Router Class Initialized
INFO - 2020-09-22 06:22:28 --> Output Class Initialized
INFO - 2020-09-22 06:22:28 --> Security Class Initialized
DEBUG - 2020-09-22 06:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:22:28 --> Input Class Initialized
INFO - 2020-09-22 06:22:28 --> Language Class Initialized
INFO - 2020-09-22 06:22:28 --> Loader Class Initialized
INFO - 2020-09-22 06:22:28 --> Helper loaded: url_helper
INFO - 2020-09-22 06:22:28 --> Database Driver Class Initialized
INFO - 2020-09-22 06:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:22:28 --> Email Class Initialized
INFO - 2020-09-22 06:22:28 --> Controller Class Initialized
DEBUG - 2020-09-22 06:22:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:22:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:22:28 --> Model Class Initialized
INFO - 2020-09-22 06:22:28 --> Model Class Initialized
INFO - 2020-09-22 06:22:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_edit.php
INFO - 2020-09-22 06:22:28 --> Final output sent to browser
DEBUG - 2020-09-22 06:22:28 --> Total execution time: 0.0265
ERROR - 2020-09-22 06:23:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:23:01 --> Config Class Initialized
INFO - 2020-09-22 06:23:01 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:23:01 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:23:01 --> Utf8 Class Initialized
INFO - 2020-09-22 06:23:01 --> URI Class Initialized
INFO - 2020-09-22 06:23:01 --> Router Class Initialized
INFO - 2020-09-22 06:23:01 --> Output Class Initialized
INFO - 2020-09-22 06:23:01 --> Security Class Initialized
DEBUG - 2020-09-22 06:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:23:01 --> Input Class Initialized
INFO - 2020-09-22 06:23:01 --> Language Class Initialized
INFO - 2020-09-22 06:23:01 --> Loader Class Initialized
INFO - 2020-09-22 06:23:01 --> Helper loaded: url_helper
INFO - 2020-09-22 06:23:01 --> Database Driver Class Initialized
INFO - 2020-09-22 06:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:23:01 --> Email Class Initialized
INFO - 2020-09-22 06:23:01 --> Controller Class Initialized
DEBUG - 2020-09-22 06:23:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:23:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:23:01 --> Model Class Initialized
INFO - 2020-09-22 06:23:01 --> Model Class Initialized
INFO - 2020-09-22 06:23:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 06:23:01 --> Final output sent to browser
DEBUG - 2020-09-22 06:23:01 --> Total execution time: 0.0283
ERROR - 2020-09-22 06:23:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:23:03 --> Config Class Initialized
INFO - 2020-09-22 06:23:03 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:23:03 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:23:03 --> Utf8 Class Initialized
INFO - 2020-09-22 06:23:03 --> URI Class Initialized
INFO - 2020-09-22 06:23:03 --> Router Class Initialized
INFO - 2020-09-22 06:23:03 --> Output Class Initialized
INFO - 2020-09-22 06:23:03 --> Security Class Initialized
DEBUG - 2020-09-22 06:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:23:03 --> Input Class Initialized
INFO - 2020-09-22 06:23:03 --> Language Class Initialized
INFO - 2020-09-22 06:23:03 --> Loader Class Initialized
INFO - 2020-09-22 06:23:03 --> Helper loaded: url_helper
INFO - 2020-09-22 06:23:03 --> Database Driver Class Initialized
INFO - 2020-09-22 06:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:23:03 --> Email Class Initialized
INFO - 2020-09-22 06:23:03 --> Controller Class Initialized
DEBUG - 2020-09-22 06:23:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:23:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:23:03 --> Model Class Initialized
INFO - 2020-09-22 06:23:03 --> Model Class Initialized
INFO - 2020-09-22 06:23:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_view_for_client.php
INFO - 2020-09-22 06:23:03 --> Final output sent to browser
DEBUG - 2020-09-22 06:23:03 --> Total execution time: 0.0268
ERROR - 2020-09-22 06:23:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:23:06 --> Config Class Initialized
INFO - 2020-09-22 06:23:06 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:23:06 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:23:06 --> Utf8 Class Initialized
INFO - 2020-09-22 06:23:06 --> URI Class Initialized
INFO - 2020-09-22 06:23:06 --> Router Class Initialized
INFO - 2020-09-22 06:23:06 --> Output Class Initialized
INFO - 2020-09-22 06:23:06 --> Security Class Initialized
DEBUG - 2020-09-22 06:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:23:06 --> Input Class Initialized
INFO - 2020-09-22 06:23:06 --> Language Class Initialized
INFO - 2020-09-22 06:23:06 --> Loader Class Initialized
INFO - 2020-09-22 06:23:06 --> Helper loaded: url_helper
INFO - 2020-09-22 06:23:06 --> Database Driver Class Initialized
INFO - 2020-09-22 06:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:23:06 --> Email Class Initialized
INFO - 2020-09-22 06:23:06 --> Controller Class Initialized
DEBUG - 2020-09-22 06:23:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:23:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:23:06 --> Model Class Initialized
INFO - 2020-09-22 06:23:06 --> Model Class Initialized
INFO - 2020-09-22 06:23:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 06:23:06 --> Final output sent to browser
DEBUG - 2020-09-22 06:23:06 --> Total execution time: 0.0233
ERROR - 2020-09-22 06:23:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:23:42 --> Config Class Initialized
INFO - 2020-09-22 06:23:42 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:23:42 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:23:42 --> Utf8 Class Initialized
INFO - 2020-09-22 06:23:42 --> URI Class Initialized
INFO - 2020-09-22 06:23:42 --> Router Class Initialized
INFO - 2020-09-22 06:23:42 --> Output Class Initialized
INFO - 2020-09-22 06:23:42 --> Security Class Initialized
DEBUG - 2020-09-22 06:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:23:42 --> Input Class Initialized
INFO - 2020-09-22 06:23:42 --> Language Class Initialized
INFO - 2020-09-22 06:23:42 --> Loader Class Initialized
INFO - 2020-09-22 06:23:42 --> Helper loaded: url_helper
INFO - 2020-09-22 06:23:42 --> Database Driver Class Initialized
INFO - 2020-09-22 06:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:23:42 --> Email Class Initialized
INFO - 2020-09-22 06:23:42 --> Controller Class Initialized
DEBUG - 2020-09-22 06:23:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:23:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:23:42 --> Model Class Initialized
INFO - 2020-09-22 06:23:42 --> Model Class Initialized
INFO - 2020-09-22 06:23:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 06:23:42 --> Final output sent to browser
DEBUG - 2020-09-22 06:23:42 --> Total execution time: 0.0283
ERROR - 2020-09-22 06:23:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:23:42 --> Config Class Initialized
INFO - 2020-09-22 06:23:42 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:23:42 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:23:42 --> Utf8 Class Initialized
INFO - 2020-09-22 06:23:42 --> URI Class Initialized
INFO - 2020-09-22 06:23:42 --> Router Class Initialized
INFO - 2020-09-22 06:23:42 --> Output Class Initialized
INFO - 2020-09-22 06:23:42 --> Security Class Initialized
DEBUG - 2020-09-22 06:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:23:42 --> Input Class Initialized
INFO - 2020-09-22 06:23:42 --> Language Class Initialized
INFO - 2020-09-22 06:23:42 --> Loader Class Initialized
INFO - 2020-09-22 06:23:42 --> Helper loaded: url_helper
INFO - 2020-09-22 06:23:42 --> Database Driver Class Initialized
INFO - 2020-09-22 06:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:23:42 --> Email Class Initialized
INFO - 2020-09-22 06:23:42 --> Controller Class Initialized
DEBUG - 2020-09-22 06:23:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:23:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:23:42 --> Model Class Initialized
INFO - 2020-09-22 06:23:42 --> Model Class Initialized
INFO - 2020-09-22 06:23:42 --> Final output sent to browser
DEBUG - 2020-09-22 06:23:42 --> Total execution time: 0.0234
ERROR - 2020-09-22 06:24:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:24:16 --> Config Class Initialized
INFO - 2020-09-22 06:24:16 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:24:16 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:24:16 --> Utf8 Class Initialized
INFO - 2020-09-22 06:24:16 --> URI Class Initialized
INFO - 2020-09-22 06:24:16 --> Router Class Initialized
INFO - 2020-09-22 06:24:16 --> Output Class Initialized
INFO - 2020-09-22 06:24:16 --> Security Class Initialized
DEBUG - 2020-09-22 06:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:24:16 --> Input Class Initialized
INFO - 2020-09-22 06:24:16 --> Language Class Initialized
INFO - 2020-09-22 06:24:16 --> Loader Class Initialized
INFO - 2020-09-22 06:24:16 --> Helper loaded: url_helper
INFO - 2020-09-22 06:24:16 --> Database Driver Class Initialized
INFO - 2020-09-22 06:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:24:16 --> Email Class Initialized
INFO - 2020-09-22 06:24:16 --> Controller Class Initialized
DEBUG - 2020-09-22 06:24:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:24:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:24:16 --> Model Class Initialized
INFO - 2020-09-22 06:24:16 --> Model Class Initialized
INFO - 2020-09-22 06:24:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 06:24:16 --> Final output sent to browser
DEBUG - 2020-09-22 06:24:16 --> Total execution time: 0.0239
ERROR - 2020-09-22 06:26:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:26:44 --> Config Class Initialized
INFO - 2020-09-22 06:26:44 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:26:44 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:26:44 --> Utf8 Class Initialized
INFO - 2020-09-22 06:26:44 --> URI Class Initialized
INFO - 2020-09-22 06:26:44 --> Router Class Initialized
INFO - 2020-09-22 06:26:44 --> Output Class Initialized
INFO - 2020-09-22 06:26:44 --> Security Class Initialized
DEBUG - 2020-09-22 06:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:26:44 --> Input Class Initialized
INFO - 2020-09-22 06:26:44 --> Language Class Initialized
INFO - 2020-09-22 06:26:44 --> Loader Class Initialized
INFO - 2020-09-22 06:26:44 --> Helper loaded: url_helper
INFO - 2020-09-22 06:26:44 --> Database Driver Class Initialized
INFO - 2020-09-22 06:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:26:45 --> Email Class Initialized
INFO - 2020-09-22 06:26:45 --> Controller Class Initialized
DEBUG - 2020-09-22 06:26:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:26:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:26:45 --> Model Class Initialized
INFO - 2020-09-22 06:26:45 --> Model Class Initialized
INFO - 2020-09-22 06:26:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 06:26:45 --> Final output sent to browser
DEBUG - 2020-09-22 06:26:45 --> Total execution time: 0.0270
ERROR - 2020-09-22 06:26:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:26:45 --> Config Class Initialized
INFO - 2020-09-22 06:26:45 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:26:45 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:26:45 --> Utf8 Class Initialized
INFO - 2020-09-22 06:26:45 --> URI Class Initialized
INFO - 2020-09-22 06:26:45 --> Router Class Initialized
INFO - 2020-09-22 06:26:45 --> Output Class Initialized
INFO - 2020-09-22 06:26:45 --> Security Class Initialized
DEBUG - 2020-09-22 06:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:26:45 --> Input Class Initialized
INFO - 2020-09-22 06:26:45 --> Language Class Initialized
INFO - 2020-09-22 06:26:45 --> Loader Class Initialized
INFO - 2020-09-22 06:26:45 --> Helper loaded: url_helper
INFO - 2020-09-22 06:26:45 --> Database Driver Class Initialized
INFO - 2020-09-22 06:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:26:45 --> Email Class Initialized
INFO - 2020-09-22 06:26:45 --> Controller Class Initialized
DEBUG - 2020-09-22 06:26:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:26:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:26:45 --> Model Class Initialized
INFO - 2020-09-22 06:26:45 --> Model Class Initialized
INFO - 2020-09-22 06:26:45 --> Final output sent to browser
DEBUG - 2020-09-22 06:26:45 --> Total execution time: 0.0249
ERROR - 2020-09-22 06:26:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:26:54 --> Config Class Initialized
INFO - 2020-09-22 06:26:54 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:26:54 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:26:54 --> Utf8 Class Initialized
INFO - 2020-09-22 06:26:54 --> URI Class Initialized
INFO - 2020-09-22 06:26:54 --> Router Class Initialized
INFO - 2020-09-22 06:26:54 --> Output Class Initialized
INFO - 2020-09-22 06:26:54 --> Security Class Initialized
DEBUG - 2020-09-22 06:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:26:54 --> Input Class Initialized
INFO - 2020-09-22 06:26:54 --> Language Class Initialized
INFO - 2020-09-22 06:26:54 --> Loader Class Initialized
INFO - 2020-09-22 06:26:54 --> Helper loaded: url_helper
INFO - 2020-09-22 06:26:54 --> Database Driver Class Initialized
INFO - 2020-09-22 06:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:26:54 --> Email Class Initialized
INFO - 2020-09-22 06:26:54 --> Controller Class Initialized
DEBUG - 2020-09-22 06:26:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:26:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:26:54 --> Model Class Initialized
INFO - 2020-09-22 06:26:54 --> Model Class Initialized
INFO - 2020-09-22 06:26:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 06:26:54 --> Final output sent to browser
DEBUG - 2020-09-22 06:26:54 --> Total execution time: 0.0319
ERROR - 2020-09-22 06:27:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:27:53 --> Config Class Initialized
INFO - 2020-09-22 06:27:53 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:27:53 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:27:53 --> Utf8 Class Initialized
INFO - 2020-09-22 06:27:53 --> URI Class Initialized
INFO - 2020-09-22 06:27:53 --> Router Class Initialized
INFO - 2020-09-22 06:27:53 --> Output Class Initialized
INFO - 2020-09-22 06:27:53 --> Security Class Initialized
DEBUG - 2020-09-22 06:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:27:53 --> Input Class Initialized
INFO - 2020-09-22 06:27:53 --> Language Class Initialized
INFO - 2020-09-22 06:27:53 --> Loader Class Initialized
INFO - 2020-09-22 06:27:53 --> Helper loaded: url_helper
INFO - 2020-09-22 06:27:53 --> Database Driver Class Initialized
INFO - 2020-09-22 06:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:27:53 --> Email Class Initialized
INFO - 2020-09-22 06:27:53 --> Controller Class Initialized
DEBUG - 2020-09-22 06:27:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:27:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:27:53 --> Model Class Initialized
INFO - 2020-09-22 06:27:53 --> Model Class Initialized
INFO - 2020-09-22 06:27:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 06:27:53 --> Final output sent to browser
DEBUG - 2020-09-22 06:27:53 --> Total execution time: 0.0277
ERROR - 2020-09-22 06:27:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:27:54 --> Config Class Initialized
INFO - 2020-09-22 06:27:54 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:27:54 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:27:54 --> Utf8 Class Initialized
INFO - 2020-09-22 06:27:54 --> URI Class Initialized
INFO - 2020-09-22 06:27:54 --> Router Class Initialized
INFO - 2020-09-22 06:27:54 --> Output Class Initialized
INFO - 2020-09-22 06:27:54 --> Security Class Initialized
DEBUG - 2020-09-22 06:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:27:54 --> Input Class Initialized
INFO - 2020-09-22 06:27:54 --> Language Class Initialized
INFO - 2020-09-22 06:27:54 --> Loader Class Initialized
INFO - 2020-09-22 06:27:54 --> Helper loaded: url_helper
INFO - 2020-09-22 06:27:54 --> Database Driver Class Initialized
INFO - 2020-09-22 06:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:27:54 --> Email Class Initialized
INFO - 2020-09-22 06:27:54 --> Controller Class Initialized
DEBUG - 2020-09-22 06:27:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:27:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:27:54 --> Model Class Initialized
INFO - 2020-09-22 06:27:54 --> Model Class Initialized
INFO - 2020-09-22 06:27:54 --> Final output sent to browser
DEBUG - 2020-09-22 06:27:54 --> Total execution time: 0.0265
ERROR - 2020-09-22 06:30:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:30:37 --> Config Class Initialized
INFO - 2020-09-22 06:30:37 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:30:37 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:30:37 --> Utf8 Class Initialized
INFO - 2020-09-22 06:30:37 --> URI Class Initialized
INFO - 2020-09-22 06:30:37 --> Router Class Initialized
INFO - 2020-09-22 06:30:37 --> Output Class Initialized
INFO - 2020-09-22 06:30:37 --> Security Class Initialized
DEBUG - 2020-09-22 06:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:30:37 --> Input Class Initialized
INFO - 2020-09-22 06:30:37 --> Language Class Initialized
INFO - 2020-09-22 06:30:37 --> Loader Class Initialized
INFO - 2020-09-22 06:30:37 --> Helper loaded: url_helper
INFO - 2020-09-22 06:30:37 --> Database Driver Class Initialized
INFO - 2020-09-22 06:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:30:37 --> Email Class Initialized
INFO - 2020-09-22 06:30:37 --> Controller Class Initialized
DEBUG - 2020-09-22 06:30:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:30:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:30:37 --> Model Class Initialized
INFO - 2020-09-22 06:30:37 --> Model Class Initialized
INFO - 2020-09-22 06:30:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 06:30:37 --> Final output sent to browser
DEBUG - 2020-09-22 06:30:37 --> Total execution time: 0.0291
ERROR - 2020-09-22 06:30:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:30:38 --> Config Class Initialized
INFO - 2020-09-22 06:30:38 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:30:38 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:30:38 --> Utf8 Class Initialized
INFO - 2020-09-22 06:30:38 --> URI Class Initialized
INFO - 2020-09-22 06:30:38 --> Router Class Initialized
INFO - 2020-09-22 06:30:38 --> Output Class Initialized
INFO - 2020-09-22 06:30:38 --> Security Class Initialized
DEBUG - 2020-09-22 06:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:30:38 --> Input Class Initialized
INFO - 2020-09-22 06:30:38 --> Language Class Initialized
INFO - 2020-09-22 06:30:38 --> Loader Class Initialized
INFO - 2020-09-22 06:30:38 --> Helper loaded: url_helper
INFO - 2020-09-22 06:30:38 --> Database Driver Class Initialized
INFO - 2020-09-22 06:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:30:38 --> Email Class Initialized
INFO - 2020-09-22 06:30:38 --> Controller Class Initialized
DEBUG - 2020-09-22 06:30:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:30:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:30:38 --> Model Class Initialized
INFO - 2020-09-22 06:30:38 --> Model Class Initialized
INFO - 2020-09-22 06:30:38 --> Final output sent to browser
DEBUG - 2020-09-22 06:30:38 --> Total execution time: 0.0267
ERROR - 2020-09-22 06:30:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:30:51 --> Config Class Initialized
INFO - 2020-09-22 06:30:51 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:30:51 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:30:51 --> Utf8 Class Initialized
INFO - 2020-09-22 06:30:51 --> URI Class Initialized
INFO - 2020-09-22 06:30:51 --> Router Class Initialized
INFO - 2020-09-22 06:30:51 --> Output Class Initialized
INFO - 2020-09-22 06:30:51 --> Security Class Initialized
DEBUG - 2020-09-22 06:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:30:51 --> Input Class Initialized
INFO - 2020-09-22 06:30:51 --> Language Class Initialized
INFO - 2020-09-22 06:30:51 --> Loader Class Initialized
INFO - 2020-09-22 06:30:51 --> Helper loaded: url_helper
INFO - 2020-09-22 06:30:51 --> Database Driver Class Initialized
INFO - 2020-09-22 06:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:30:51 --> Email Class Initialized
INFO - 2020-09-22 06:30:51 --> Controller Class Initialized
DEBUG - 2020-09-22 06:30:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:30:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:30:51 --> Model Class Initialized
INFO - 2020-09-22 06:30:51 --> Model Class Initialized
INFO - 2020-09-22 06:30:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 06:30:51 --> Final output sent to browser
DEBUG - 2020-09-22 06:30:51 --> Total execution time: 0.0271
ERROR - 2020-09-22 06:30:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:30:52 --> Config Class Initialized
INFO - 2020-09-22 06:30:52 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:30:52 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:30:52 --> Utf8 Class Initialized
INFO - 2020-09-22 06:30:52 --> URI Class Initialized
INFO - 2020-09-22 06:30:52 --> Router Class Initialized
INFO - 2020-09-22 06:30:52 --> Output Class Initialized
INFO - 2020-09-22 06:30:52 --> Security Class Initialized
DEBUG - 2020-09-22 06:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:30:52 --> Input Class Initialized
INFO - 2020-09-22 06:30:52 --> Language Class Initialized
INFO - 2020-09-22 06:30:52 --> Loader Class Initialized
INFO - 2020-09-22 06:30:52 --> Helper loaded: url_helper
INFO - 2020-09-22 06:30:52 --> Database Driver Class Initialized
INFO - 2020-09-22 06:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:30:52 --> Email Class Initialized
INFO - 2020-09-22 06:30:52 --> Controller Class Initialized
DEBUG - 2020-09-22 06:30:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:30:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:30:52 --> Model Class Initialized
INFO - 2020-09-22 06:30:52 --> Model Class Initialized
INFO - 2020-09-22 06:30:52 --> Final output sent to browser
DEBUG - 2020-09-22 06:30:52 --> Total execution time: 0.0301
ERROR - 2020-09-22 06:34:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:34:10 --> Config Class Initialized
INFO - 2020-09-22 06:34:10 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:34:10 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:34:10 --> Utf8 Class Initialized
INFO - 2020-09-22 06:34:10 --> URI Class Initialized
INFO - 2020-09-22 06:34:10 --> Router Class Initialized
INFO - 2020-09-22 06:34:10 --> Output Class Initialized
INFO - 2020-09-22 06:34:10 --> Security Class Initialized
DEBUG - 2020-09-22 06:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:34:10 --> Input Class Initialized
INFO - 2020-09-22 06:34:10 --> Language Class Initialized
INFO - 2020-09-22 06:34:10 --> Loader Class Initialized
INFO - 2020-09-22 06:34:10 --> Helper loaded: url_helper
INFO - 2020-09-22 06:34:10 --> Database Driver Class Initialized
INFO - 2020-09-22 06:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:34:10 --> Email Class Initialized
INFO - 2020-09-22 06:34:10 --> Controller Class Initialized
DEBUG - 2020-09-22 06:34:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:34:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:34:10 --> Model Class Initialized
INFO - 2020-09-22 06:34:10 --> Model Class Initialized
INFO - 2020-09-22 06:34:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 06:34:10 --> Final output sent to browser
DEBUG - 2020-09-22 06:34:10 --> Total execution time: 0.0285
ERROR - 2020-09-22 06:34:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:34:12 --> Config Class Initialized
INFO - 2020-09-22 06:34:12 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:34:12 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:34:12 --> Utf8 Class Initialized
INFO - 2020-09-22 06:34:12 --> URI Class Initialized
INFO - 2020-09-22 06:34:12 --> Router Class Initialized
INFO - 2020-09-22 06:34:12 --> Output Class Initialized
INFO - 2020-09-22 06:34:12 --> Security Class Initialized
DEBUG - 2020-09-22 06:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:34:12 --> Input Class Initialized
INFO - 2020-09-22 06:34:12 --> Language Class Initialized
INFO - 2020-09-22 06:34:12 --> Loader Class Initialized
INFO - 2020-09-22 06:34:12 --> Helper loaded: url_helper
INFO - 2020-09-22 06:34:12 --> Database Driver Class Initialized
INFO - 2020-09-22 06:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:34:12 --> Email Class Initialized
INFO - 2020-09-22 06:34:12 --> Controller Class Initialized
DEBUG - 2020-09-22 06:34:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:34:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:34:12 --> Model Class Initialized
INFO - 2020-09-22 06:34:12 --> Model Class Initialized
INFO - 2020-09-22 06:34:12 --> Final output sent to browser
DEBUG - 2020-09-22 06:34:12 --> Total execution time: 0.0253
ERROR - 2020-09-22 06:35:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:35:36 --> Config Class Initialized
INFO - 2020-09-22 06:35:36 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:35:36 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:35:36 --> Utf8 Class Initialized
INFO - 2020-09-22 06:35:36 --> URI Class Initialized
INFO - 2020-09-22 06:35:36 --> Router Class Initialized
INFO - 2020-09-22 06:35:36 --> Output Class Initialized
INFO - 2020-09-22 06:35:36 --> Security Class Initialized
DEBUG - 2020-09-22 06:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:35:36 --> Input Class Initialized
INFO - 2020-09-22 06:35:36 --> Language Class Initialized
INFO - 2020-09-22 06:35:36 --> Loader Class Initialized
INFO - 2020-09-22 06:35:36 --> Helper loaded: url_helper
INFO - 2020-09-22 06:35:36 --> Database Driver Class Initialized
INFO - 2020-09-22 06:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:35:36 --> Email Class Initialized
INFO - 2020-09-22 06:35:36 --> Controller Class Initialized
DEBUG - 2020-09-22 06:35:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:35:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:35:36 --> Model Class Initialized
INFO - 2020-09-22 06:35:36 --> Model Class Initialized
INFO - 2020-09-22 06:35:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 06:35:36 --> Final output sent to browser
DEBUG - 2020-09-22 06:35:36 --> Total execution time: 0.0247
ERROR - 2020-09-22 06:35:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:35:37 --> Config Class Initialized
INFO - 2020-09-22 06:35:37 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:35:37 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:35:37 --> Utf8 Class Initialized
INFO - 2020-09-22 06:35:37 --> URI Class Initialized
INFO - 2020-09-22 06:35:37 --> Router Class Initialized
INFO - 2020-09-22 06:35:37 --> Output Class Initialized
INFO - 2020-09-22 06:35:37 --> Security Class Initialized
DEBUG - 2020-09-22 06:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:35:37 --> Input Class Initialized
INFO - 2020-09-22 06:35:37 --> Language Class Initialized
INFO - 2020-09-22 06:35:37 --> Loader Class Initialized
INFO - 2020-09-22 06:35:37 --> Helper loaded: url_helper
INFO - 2020-09-22 06:35:37 --> Database Driver Class Initialized
INFO - 2020-09-22 06:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:35:37 --> Email Class Initialized
INFO - 2020-09-22 06:35:37 --> Controller Class Initialized
DEBUG - 2020-09-22 06:35:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:35:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:35:37 --> Model Class Initialized
INFO - 2020-09-22 06:35:37 --> Model Class Initialized
INFO - 2020-09-22 06:35:37 --> Final output sent to browser
DEBUG - 2020-09-22 06:35:37 --> Total execution time: 0.0242
ERROR - 2020-09-22 06:37:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:37:19 --> Config Class Initialized
INFO - 2020-09-22 06:37:19 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:37:19 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:37:19 --> Utf8 Class Initialized
INFO - 2020-09-22 06:37:19 --> URI Class Initialized
INFO - 2020-09-22 06:37:19 --> Router Class Initialized
INFO - 2020-09-22 06:37:19 --> Output Class Initialized
INFO - 2020-09-22 06:37:19 --> Security Class Initialized
DEBUG - 2020-09-22 06:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:37:19 --> Input Class Initialized
INFO - 2020-09-22 06:37:19 --> Language Class Initialized
INFO - 2020-09-22 06:37:19 --> Loader Class Initialized
INFO - 2020-09-22 06:37:19 --> Helper loaded: url_helper
INFO - 2020-09-22 06:37:19 --> Database Driver Class Initialized
INFO - 2020-09-22 06:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:37:19 --> Email Class Initialized
INFO - 2020-09-22 06:37:19 --> Controller Class Initialized
DEBUG - 2020-09-22 06:37:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:37:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:37:19 --> Model Class Initialized
INFO - 2020-09-22 06:37:19 --> Model Class Initialized
INFO - 2020-09-22 06:37:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 06:37:19 --> Final output sent to browser
DEBUG - 2020-09-22 06:37:19 --> Total execution time: 0.0357
ERROR - 2020-09-22 06:37:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:37:20 --> Config Class Initialized
INFO - 2020-09-22 06:37:20 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:37:20 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:37:20 --> Utf8 Class Initialized
INFO - 2020-09-22 06:37:20 --> URI Class Initialized
INFO - 2020-09-22 06:37:20 --> Router Class Initialized
INFO - 2020-09-22 06:37:20 --> Output Class Initialized
INFO - 2020-09-22 06:37:20 --> Security Class Initialized
DEBUG - 2020-09-22 06:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:37:20 --> Input Class Initialized
INFO - 2020-09-22 06:37:20 --> Language Class Initialized
INFO - 2020-09-22 06:37:20 --> Loader Class Initialized
INFO - 2020-09-22 06:37:20 --> Helper loaded: url_helper
INFO - 2020-09-22 06:37:20 --> Database Driver Class Initialized
INFO - 2020-09-22 06:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:37:20 --> Email Class Initialized
INFO - 2020-09-22 06:37:20 --> Controller Class Initialized
DEBUG - 2020-09-22 06:37:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:37:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:37:20 --> Model Class Initialized
INFO - 2020-09-22 06:37:20 --> Model Class Initialized
INFO - 2020-09-22 06:37:20 --> Final output sent to browser
DEBUG - 2020-09-22 06:37:20 --> Total execution time: 0.0237
ERROR - 2020-09-22 06:38:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:38:16 --> Config Class Initialized
INFO - 2020-09-22 06:38:16 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:38:16 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:38:16 --> Utf8 Class Initialized
INFO - 2020-09-22 06:38:16 --> URI Class Initialized
INFO - 2020-09-22 06:38:16 --> Router Class Initialized
INFO - 2020-09-22 06:38:16 --> Output Class Initialized
INFO - 2020-09-22 06:38:16 --> Security Class Initialized
DEBUG - 2020-09-22 06:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:38:16 --> Input Class Initialized
INFO - 2020-09-22 06:38:16 --> Language Class Initialized
INFO - 2020-09-22 06:38:16 --> Loader Class Initialized
INFO - 2020-09-22 06:38:16 --> Helper loaded: url_helper
INFO - 2020-09-22 06:38:16 --> Database Driver Class Initialized
INFO - 2020-09-22 06:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:38:16 --> Email Class Initialized
INFO - 2020-09-22 06:38:16 --> Controller Class Initialized
DEBUG - 2020-09-22 06:38:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:38:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:38:16 --> Model Class Initialized
INFO - 2020-09-22 06:38:16 --> Model Class Initialized
INFO - 2020-09-22 06:38:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 06:38:16 --> Final output sent to browser
DEBUG - 2020-09-22 06:38:16 --> Total execution time: 0.0287
ERROR - 2020-09-22 06:38:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:38:17 --> Config Class Initialized
INFO - 2020-09-22 06:38:17 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:38:17 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:38:17 --> Utf8 Class Initialized
INFO - 2020-09-22 06:38:17 --> URI Class Initialized
INFO - 2020-09-22 06:38:17 --> Router Class Initialized
INFO - 2020-09-22 06:38:17 --> Output Class Initialized
INFO - 2020-09-22 06:38:17 --> Security Class Initialized
DEBUG - 2020-09-22 06:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:38:17 --> Input Class Initialized
INFO - 2020-09-22 06:38:17 --> Language Class Initialized
INFO - 2020-09-22 06:38:17 --> Loader Class Initialized
INFO - 2020-09-22 06:38:17 --> Helper loaded: url_helper
INFO - 2020-09-22 06:38:17 --> Database Driver Class Initialized
INFO - 2020-09-22 06:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:38:17 --> Email Class Initialized
INFO - 2020-09-22 06:38:17 --> Controller Class Initialized
DEBUG - 2020-09-22 06:38:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:38:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:38:17 --> Model Class Initialized
INFO - 2020-09-22 06:38:17 --> Model Class Initialized
INFO - 2020-09-22 06:38:17 --> Final output sent to browser
DEBUG - 2020-09-22 06:38:17 --> Total execution time: 0.0275
ERROR - 2020-09-22 06:41:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:41:28 --> Config Class Initialized
INFO - 2020-09-22 06:41:28 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:41:28 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:41:28 --> Utf8 Class Initialized
INFO - 2020-09-22 06:41:28 --> URI Class Initialized
INFO - 2020-09-22 06:41:28 --> Router Class Initialized
INFO - 2020-09-22 06:41:28 --> Output Class Initialized
INFO - 2020-09-22 06:41:28 --> Security Class Initialized
DEBUG - 2020-09-22 06:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:41:28 --> Input Class Initialized
INFO - 2020-09-22 06:41:28 --> Language Class Initialized
INFO - 2020-09-22 06:41:28 --> Loader Class Initialized
INFO - 2020-09-22 06:41:28 --> Helper loaded: url_helper
INFO - 2020-09-22 06:41:28 --> Database Driver Class Initialized
INFO - 2020-09-22 06:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:41:28 --> Email Class Initialized
INFO - 2020-09-22 06:41:28 --> Controller Class Initialized
DEBUG - 2020-09-22 06:41:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:41:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:41:28 --> Model Class Initialized
INFO - 2020-09-22 06:41:28 --> Model Class Initialized
INFO - 2020-09-22 06:41:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 06:41:28 --> Final output sent to browser
DEBUG - 2020-09-22 06:41:28 --> Total execution time: 0.0378
ERROR - 2020-09-22 06:41:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:41:32 --> Config Class Initialized
INFO - 2020-09-22 06:41:32 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:41:32 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:41:32 --> Utf8 Class Initialized
INFO - 2020-09-22 06:41:32 --> URI Class Initialized
INFO - 2020-09-22 06:41:32 --> Router Class Initialized
INFO - 2020-09-22 06:41:32 --> Output Class Initialized
INFO - 2020-09-22 06:41:32 --> Security Class Initialized
DEBUG - 2020-09-22 06:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:41:32 --> Input Class Initialized
INFO - 2020-09-22 06:41:32 --> Language Class Initialized
INFO - 2020-09-22 06:41:32 --> Loader Class Initialized
INFO - 2020-09-22 06:41:32 --> Helper loaded: url_helper
INFO - 2020-09-22 06:41:32 --> Database Driver Class Initialized
INFO - 2020-09-22 06:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:41:32 --> Email Class Initialized
INFO - 2020-09-22 06:41:32 --> Controller Class Initialized
DEBUG - 2020-09-22 06:41:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:41:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:41:32 --> Model Class Initialized
INFO - 2020-09-22 06:41:32 --> Model Class Initialized
INFO - 2020-09-22 06:41:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_edit.php
INFO - 2020-09-22 06:41:32 --> Final output sent to browser
DEBUG - 2020-09-22 06:41:32 --> Total execution time: 0.0268
ERROR - 2020-09-22 06:41:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:41:47 --> Config Class Initialized
INFO - 2020-09-22 06:41:47 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:41:47 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:41:47 --> Utf8 Class Initialized
INFO - 2020-09-22 06:41:47 --> URI Class Initialized
INFO - 2020-09-22 06:41:47 --> Router Class Initialized
INFO - 2020-09-22 06:41:47 --> Output Class Initialized
INFO - 2020-09-22 06:41:47 --> Security Class Initialized
DEBUG - 2020-09-22 06:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:41:47 --> Input Class Initialized
INFO - 2020-09-22 06:41:47 --> Language Class Initialized
INFO - 2020-09-22 06:41:47 --> Loader Class Initialized
INFO - 2020-09-22 06:41:47 --> Helper loaded: url_helper
INFO - 2020-09-22 06:41:47 --> Database Driver Class Initialized
INFO - 2020-09-22 06:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:41:47 --> Email Class Initialized
INFO - 2020-09-22 06:41:47 --> Controller Class Initialized
DEBUG - 2020-09-22 06:41:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:41:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:41:47 --> Model Class Initialized
INFO - 2020-09-22 06:41:47 --> Model Class Initialized
INFO - 2020-09-22 06:41:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 06:41:47 --> Final output sent to browser
DEBUG - 2020-09-22 06:41:47 --> Total execution time: 0.0263
ERROR - 2020-09-22 06:41:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:41:58 --> Config Class Initialized
INFO - 2020-09-22 06:41:58 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:41:58 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:41:58 --> Utf8 Class Initialized
INFO - 2020-09-22 06:41:58 --> URI Class Initialized
INFO - 2020-09-22 06:41:58 --> Router Class Initialized
INFO - 2020-09-22 06:41:58 --> Output Class Initialized
INFO - 2020-09-22 06:41:58 --> Security Class Initialized
DEBUG - 2020-09-22 06:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:41:58 --> Input Class Initialized
INFO - 2020-09-22 06:41:58 --> Language Class Initialized
INFO - 2020-09-22 06:41:58 --> Loader Class Initialized
INFO - 2020-09-22 06:41:58 --> Helper loaded: url_helper
INFO - 2020-09-22 06:41:58 --> Database Driver Class Initialized
INFO - 2020-09-22 06:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:41:58 --> Email Class Initialized
INFO - 2020-09-22 06:41:58 --> Controller Class Initialized
DEBUG - 2020-09-22 06:41:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:41:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:41:58 --> Model Class Initialized
INFO - 2020-09-22 06:41:58 --> Model Class Initialized
INFO - 2020-09-22 06:41:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_edit.php
INFO - 2020-09-22 06:41:58 --> Final output sent to browser
DEBUG - 2020-09-22 06:41:58 --> Total execution time: 0.0280
ERROR - 2020-09-22 06:42:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:42:02 --> Config Class Initialized
INFO - 2020-09-22 06:42:02 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:42:02 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:42:02 --> Utf8 Class Initialized
INFO - 2020-09-22 06:42:02 --> URI Class Initialized
INFO - 2020-09-22 06:42:02 --> Router Class Initialized
INFO - 2020-09-22 06:42:02 --> Output Class Initialized
INFO - 2020-09-22 06:42:02 --> Security Class Initialized
DEBUG - 2020-09-22 06:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:42:02 --> Input Class Initialized
INFO - 2020-09-22 06:42:02 --> Language Class Initialized
INFO - 2020-09-22 06:42:02 --> Loader Class Initialized
INFO - 2020-09-22 06:42:02 --> Helper loaded: url_helper
INFO - 2020-09-22 06:42:02 --> Database Driver Class Initialized
INFO - 2020-09-22 06:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:42:02 --> Email Class Initialized
INFO - 2020-09-22 06:42:02 --> Controller Class Initialized
DEBUG - 2020-09-22 06:42:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:42:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:42:02 --> Model Class Initialized
INFO - 2020-09-22 06:42:02 --> Model Class Initialized
INFO - 2020-09-22 06:42:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 06:42:02 --> Final output sent to browser
DEBUG - 2020-09-22 06:42:02 --> Total execution time: 0.0335
ERROR - 2020-09-22 06:42:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:42:48 --> Config Class Initialized
INFO - 2020-09-22 06:42:48 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:42:48 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:42:48 --> Utf8 Class Initialized
INFO - 2020-09-22 06:42:48 --> URI Class Initialized
INFO - 2020-09-22 06:42:48 --> Router Class Initialized
INFO - 2020-09-22 06:42:48 --> Output Class Initialized
INFO - 2020-09-22 06:42:48 --> Security Class Initialized
DEBUG - 2020-09-22 06:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:42:48 --> Input Class Initialized
INFO - 2020-09-22 06:42:48 --> Language Class Initialized
INFO - 2020-09-22 06:42:48 --> Loader Class Initialized
INFO - 2020-09-22 06:42:48 --> Helper loaded: url_helper
INFO - 2020-09-22 06:42:48 --> Database Driver Class Initialized
INFO - 2020-09-22 06:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:42:48 --> Email Class Initialized
INFO - 2020-09-22 06:42:48 --> Controller Class Initialized
DEBUG - 2020-09-22 06:42:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:42:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:42:48 --> Model Class Initialized
INFO - 2020-09-22 06:42:48 --> Model Class Initialized
INFO - 2020-09-22 06:42:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 06:42:48 --> Final output sent to browser
DEBUG - 2020-09-22 06:42:48 --> Total execution time: 0.0296
ERROR - 2020-09-22 06:42:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:42:49 --> Config Class Initialized
INFO - 2020-09-22 06:42:49 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:42:49 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:42:49 --> Utf8 Class Initialized
INFO - 2020-09-22 06:42:49 --> URI Class Initialized
INFO - 2020-09-22 06:42:49 --> Router Class Initialized
INFO - 2020-09-22 06:42:49 --> Output Class Initialized
INFO - 2020-09-22 06:42:49 --> Security Class Initialized
DEBUG - 2020-09-22 06:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:42:49 --> Input Class Initialized
INFO - 2020-09-22 06:42:49 --> Language Class Initialized
INFO - 2020-09-22 06:42:49 --> Loader Class Initialized
INFO - 2020-09-22 06:42:49 --> Helper loaded: url_helper
INFO - 2020-09-22 06:42:49 --> Database Driver Class Initialized
INFO - 2020-09-22 06:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:42:49 --> Email Class Initialized
INFO - 2020-09-22 06:42:49 --> Controller Class Initialized
DEBUG - 2020-09-22 06:42:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:42:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:42:49 --> Model Class Initialized
INFO - 2020-09-22 06:42:49 --> Model Class Initialized
INFO - 2020-09-22 06:42:49 --> Final output sent to browser
DEBUG - 2020-09-22 06:42:49 --> Total execution time: 0.0281
ERROR - 2020-09-22 06:45:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:45:13 --> Config Class Initialized
INFO - 2020-09-22 06:45:13 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:45:13 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:45:13 --> Utf8 Class Initialized
INFO - 2020-09-22 06:45:13 --> URI Class Initialized
INFO - 2020-09-22 06:45:13 --> Router Class Initialized
INFO - 2020-09-22 06:45:13 --> Output Class Initialized
INFO - 2020-09-22 06:45:13 --> Security Class Initialized
DEBUG - 2020-09-22 06:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:45:13 --> Input Class Initialized
INFO - 2020-09-22 06:45:13 --> Language Class Initialized
INFO - 2020-09-22 06:45:13 --> Loader Class Initialized
INFO - 2020-09-22 06:45:13 --> Helper loaded: url_helper
INFO - 2020-09-22 06:45:13 --> Database Driver Class Initialized
INFO - 2020-09-22 06:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:45:13 --> Email Class Initialized
INFO - 2020-09-22 06:45:13 --> Controller Class Initialized
DEBUG - 2020-09-22 06:45:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:45:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:45:13 --> Model Class Initialized
INFO - 2020-09-22 06:45:13 --> Model Class Initialized
INFO - 2020-09-22 06:45:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 06:45:13 --> Final output sent to browser
DEBUG - 2020-09-22 06:45:13 --> Total execution time: 0.0232
ERROR - 2020-09-22 06:45:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:45:15 --> Config Class Initialized
INFO - 2020-09-22 06:45:15 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:45:15 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:45:15 --> Utf8 Class Initialized
INFO - 2020-09-22 06:45:15 --> URI Class Initialized
INFO - 2020-09-22 06:45:15 --> Router Class Initialized
INFO - 2020-09-22 06:45:15 --> Output Class Initialized
INFO - 2020-09-22 06:45:15 --> Security Class Initialized
DEBUG - 2020-09-22 06:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:45:15 --> Input Class Initialized
INFO - 2020-09-22 06:45:15 --> Language Class Initialized
INFO - 2020-09-22 06:45:15 --> Loader Class Initialized
INFO - 2020-09-22 06:45:15 --> Helper loaded: url_helper
INFO - 2020-09-22 06:45:15 --> Database Driver Class Initialized
INFO - 2020-09-22 06:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:45:15 --> Email Class Initialized
INFO - 2020-09-22 06:45:15 --> Controller Class Initialized
DEBUG - 2020-09-22 06:45:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:45:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:45:15 --> Model Class Initialized
INFO - 2020-09-22 06:45:15 --> Model Class Initialized
INFO - 2020-09-22 06:45:15 --> Final output sent to browser
DEBUG - 2020-09-22 06:45:15 --> Total execution time: 0.0238
ERROR - 2020-09-22 06:45:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:45:57 --> Config Class Initialized
INFO - 2020-09-22 06:45:57 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:45:57 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:45:57 --> Utf8 Class Initialized
INFO - 2020-09-22 06:45:57 --> URI Class Initialized
INFO - 2020-09-22 06:45:57 --> Router Class Initialized
INFO - 2020-09-22 06:45:57 --> Output Class Initialized
INFO - 2020-09-22 06:45:57 --> Security Class Initialized
DEBUG - 2020-09-22 06:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:45:57 --> Input Class Initialized
INFO - 2020-09-22 06:45:57 --> Language Class Initialized
INFO - 2020-09-22 06:45:57 --> Loader Class Initialized
INFO - 2020-09-22 06:45:57 --> Helper loaded: url_helper
INFO - 2020-09-22 06:45:57 --> Database Driver Class Initialized
INFO - 2020-09-22 06:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:45:57 --> Email Class Initialized
INFO - 2020-09-22 06:45:57 --> Controller Class Initialized
DEBUG - 2020-09-22 06:45:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:45:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:45:57 --> Model Class Initialized
INFO - 2020-09-22 06:45:57 --> Model Class Initialized
INFO - 2020-09-22 06:45:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 06:45:57 --> Final output sent to browser
DEBUG - 2020-09-22 06:45:57 --> Total execution time: 0.0268
ERROR - 2020-09-22 06:45:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:45:58 --> Config Class Initialized
INFO - 2020-09-22 06:45:58 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:45:58 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:45:58 --> Utf8 Class Initialized
INFO - 2020-09-22 06:45:58 --> URI Class Initialized
INFO - 2020-09-22 06:45:58 --> Router Class Initialized
INFO - 2020-09-22 06:45:58 --> Output Class Initialized
INFO - 2020-09-22 06:45:58 --> Security Class Initialized
DEBUG - 2020-09-22 06:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:45:58 --> Input Class Initialized
INFO - 2020-09-22 06:45:58 --> Language Class Initialized
INFO - 2020-09-22 06:45:58 --> Loader Class Initialized
INFO - 2020-09-22 06:45:58 --> Helper loaded: url_helper
INFO - 2020-09-22 06:45:58 --> Database Driver Class Initialized
INFO - 2020-09-22 06:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:45:58 --> Email Class Initialized
INFO - 2020-09-22 06:45:58 --> Controller Class Initialized
DEBUG - 2020-09-22 06:45:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:45:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:45:58 --> Model Class Initialized
INFO - 2020-09-22 06:45:58 --> Model Class Initialized
INFO - 2020-09-22 06:45:58 --> Final output sent to browser
DEBUG - 2020-09-22 06:45:58 --> Total execution time: 0.0260
ERROR - 2020-09-22 06:48:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:48:08 --> Config Class Initialized
INFO - 2020-09-22 06:48:08 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:48:08 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:48:08 --> Utf8 Class Initialized
INFO - 2020-09-22 06:48:08 --> URI Class Initialized
INFO - 2020-09-22 06:48:08 --> Router Class Initialized
INFO - 2020-09-22 06:48:08 --> Output Class Initialized
INFO - 2020-09-22 06:48:08 --> Security Class Initialized
DEBUG - 2020-09-22 06:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:48:08 --> Input Class Initialized
INFO - 2020-09-22 06:48:08 --> Language Class Initialized
INFO - 2020-09-22 06:48:08 --> Loader Class Initialized
INFO - 2020-09-22 06:48:08 --> Helper loaded: url_helper
INFO - 2020-09-22 06:48:08 --> Database Driver Class Initialized
INFO - 2020-09-22 06:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:48:08 --> Email Class Initialized
INFO - 2020-09-22 06:48:08 --> Controller Class Initialized
DEBUG - 2020-09-22 06:48:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:48:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:48:08 --> Model Class Initialized
INFO - 2020-09-22 06:48:08 --> Model Class Initialized
INFO - 2020-09-22 06:48:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 06:48:08 --> Final output sent to browser
DEBUG - 2020-09-22 06:48:08 --> Total execution time: 0.3705
ERROR - 2020-09-22 06:48:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:48:09 --> Config Class Initialized
INFO - 2020-09-22 06:48:09 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:48:09 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:48:09 --> Utf8 Class Initialized
INFO - 2020-09-22 06:48:09 --> URI Class Initialized
INFO - 2020-09-22 06:48:09 --> Router Class Initialized
INFO - 2020-09-22 06:48:09 --> Output Class Initialized
INFO - 2020-09-22 06:48:09 --> Security Class Initialized
DEBUG - 2020-09-22 06:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:48:09 --> Input Class Initialized
INFO - 2020-09-22 06:48:09 --> Language Class Initialized
INFO - 2020-09-22 06:48:09 --> Loader Class Initialized
INFO - 2020-09-22 06:48:09 --> Helper loaded: url_helper
INFO - 2020-09-22 06:48:09 --> Database Driver Class Initialized
INFO - 2020-09-22 06:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:48:09 --> Email Class Initialized
INFO - 2020-09-22 06:48:09 --> Controller Class Initialized
DEBUG - 2020-09-22 06:48:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:48:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:48:09 --> Model Class Initialized
INFO - 2020-09-22 06:48:09 --> Model Class Initialized
INFO - 2020-09-22 06:48:09 --> Final output sent to browser
DEBUG - 2020-09-22 06:48:09 --> Total execution time: 0.1192
ERROR - 2020-09-22 06:49:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:49:04 --> Config Class Initialized
INFO - 2020-09-22 06:49:04 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:49:04 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:49:04 --> Utf8 Class Initialized
INFO - 2020-09-22 06:49:04 --> URI Class Initialized
INFO - 2020-09-22 06:49:04 --> Router Class Initialized
INFO - 2020-09-22 06:49:04 --> Output Class Initialized
INFO - 2020-09-22 06:49:04 --> Security Class Initialized
DEBUG - 2020-09-22 06:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:49:04 --> Input Class Initialized
INFO - 2020-09-22 06:49:04 --> Language Class Initialized
INFO - 2020-09-22 06:49:04 --> Loader Class Initialized
INFO - 2020-09-22 06:49:04 --> Helper loaded: url_helper
INFO - 2020-09-22 06:49:04 --> Database Driver Class Initialized
INFO - 2020-09-22 06:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:49:04 --> Email Class Initialized
INFO - 2020-09-22 06:49:04 --> Controller Class Initialized
DEBUG - 2020-09-22 06:49:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:49:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:49:04 --> Model Class Initialized
INFO - 2020-09-22 06:49:04 --> Model Class Initialized
INFO - 2020-09-22 06:49:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 06:49:04 --> Final output sent to browser
DEBUG - 2020-09-22 06:49:04 --> Total execution time: 0.0247
ERROR - 2020-09-22 06:49:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:49:10 --> Config Class Initialized
INFO - 2020-09-22 06:49:10 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:49:10 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:49:10 --> Utf8 Class Initialized
INFO - 2020-09-22 06:49:10 --> URI Class Initialized
INFO - 2020-09-22 06:49:10 --> Router Class Initialized
INFO - 2020-09-22 06:49:10 --> Output Class Initialized
INFO - 2020-09-22 06:49:10 --> Security Class Initialized
DEBUG - 2020-09-22 06:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:49:10 --> Input Class Initialized
INFO - 2020-09-22 06:49:10 --> Language Class Initialized
INFO - 2020-09-22 06:49:10 --> Loader Class Initialized
INFO - 2020-09-22 06:49:10 --> Helper loaded: url_helper
INFO - 2020-09-22 06:49:10 --> Database Driver Class Initialized
INFO - 2020-09-22 06:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:49:10 --> Email Class Initialized
INFO - 2020-09-22 06:49:10 --> Controller Class Initialized
DEBUG - 2020-09-22 06:49:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:49:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:49:10 --> Model Class Initialized
INFO - 2020-09-22 06:49:10 --> Model Class Initialized
INFO - 2020-09-22 06:49:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_edit.php
INFO - 2020-09-22 06:49:10 --> Final output sent to browser
DEBUG - 2020-09-22 06:49:10 --> Total execution time: 0.0246
ERROR - 2020-09-22 06:52:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:52:49 --> Config Class Initialized
INFO - 2020-09-22 06:52:49 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:52:49 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:52:49 --> Utf8 Class Initialized
INFO - 2020-09-22 06:52:49 --> URI Class Initialized
INFO - 2020-09-22 06:52:49 --> Router Class Initialized
INFO - 2020-09-22 06:52:49 --> Output Class Initialized
INFO - 2020-09-22 06:52:49 --> Security Class Initialized
DEBUG - 2020-09-22 06:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:52:49 --> Input Class Initialized
INFO - 2020-09-22 06:52:49 --> Language Class Initialized
INFO - 2020-09-22 06:52:49 --> Loader Class Initialized
INFO - 2020-09-22 06:52:49 --> Helper loaded: url_helper
INFO - 2020-09-22 06:52:49 --> Database Driver Class Initialized
INFO - 2020-09-22 06:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:52:49 --> Email Class Initialized
INFO - 2020-09-22 06:52:49 --> Controller Class Initialized
DEBUG - 2020-09-22 06:52:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:52:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:52:49 --> Model Class Initialized
INFO - 2020-09-22 06:52:49 --> Model Class Initialized
INFO - 2020-09-22 06:52:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 06:52:49 --> Final output sent to browser
DEBUG - 2020-09-22 06:52:49 --> Total execution time: 0.0262
ERROR - 2020-09-22 06:52:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:52:52 --> Config Class Initialized
INFO - 2020-09-22 06:52:52 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:52:52 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:52:52 --> Utf8 Class Initialized
INFO - 2020-09-22 06:52:52 --> URI Class Initialized
INFO - 2020-09-22 06:52:52 --> Router Class Initialized
INFO - 2020-09-22 06:52:52 --> Output Class Initialized
INFO - 2020-09-22 06:52:52 --> Security Class Initialized
DEBUG - 2020-09-22 06:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:52:52 --> Input Class Initialized
INFO - 2020-09-22 06:52:52 --> Language Class Initialized
INFO - 2020-09-22 06:52:52 --> Loader Class Initialized
INFO - 2020-09-22 06:52:52 --> Helper loaded: url_helper
INFO - 2020-09-22 06:52:52 --> Database Driver Class Initialized
INFO - 2020-09-22 06:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:52:52 --> Email Class Initialized
INFO - 2020-09-22 06:52:52 --> Controller Class Initialized
DEBUG - 2020-09-22 06:52:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:52:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:52:52 --> Model Class Initialized
INFO - 2020-09-22 06:52:52 --> Model Class Initialized
INFO - 2020-09-22 06:52:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_edit.php
INFO - 2020-09-22 06:52:52 --> Final output sent to browser
DEBUG - 2020-09-22 06:52:52 --> Total execution time: 0.0279
ERROR - 2020-09-22 06:53:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:53:23 --> Config Class Initialized
INFO - 2020-09-22 06:53:23 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:53:23 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:53:23 --> Utf8 Class Initialized
INFO - 2020-09-22 06:53:23 --> URI Class Initialized
INFO - 2020-09-22 06:53:23 --> Router Class Initialized
INFO - 2020-09-22 06:53:23 --> Output Class Initialized
INFO - 2020-09-22 06:53:23 --> Security Class Initialized
DEBUG - 2020-09-22 06:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:53:23 --> Input Class Initialized
INFO - 2020-09-22 06:53:23 --> Language Class Initialized
INFO - 2020-09-22 06:53:23 --> Loader Class Initialized
INFO - 2020-09-22 06:53:23 --> Helper loaded: url_helper
INFO - 2020-09-22 06:53:23 --> Database Driver Class Initialized
INFO - 2020-09-22 06:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:53:23 --> Email Class Initialized
INFO - 2020-09-22 06:53:23 --> Controller Class Initialized
DEBUG - 2020-09-22 06:53:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:53:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:53:23 --> Model Class Initialized
INFO - 2020-09-22 06:53:23 --> Model Class Initialized
INFO - 2020-09-22 06:53:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 06:53:23 --> Final output sent to browser
DEBUG - 2020-09-22 06:53:23 --> Total execution time: 0.0233
ERROR - 2020-09-22 06:53:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:53:26 --> Config Class Initialized
INFO - 2020-09-22 06:53:26 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:53:26 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:53:26 --> Utf8 Class Initialized
INFO - 2020-09-22 06:53:26 --> URI Class Initialized
INFO - 2020-09-22 06:53:26 --> Router Class Initialized
INFO - 2020-09-22 06:53:26 --> Output Class Initialized
INFO - 2020-09-22 06:53:26 --> Security Class Initialized
DEBUG - 2020-09-22 06:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:53:26 --> Input Class Initialized
INFO - 2020-09-22 06:53:26 --> Language Class Initialized
INFO - 2020-09-22 06:53:26 --> Loader Class Initialized
INFO - 2020-09-22 06:53:26 --> Helper loaded: url_helper
INFO - 2020-09-22 06:53:26 --> Database Driver Class Initialized
INFO - 2020-09-22 06:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:53:26 --> Email Class Initialized
INFO - 2020-09-22 06:53:26 --> Controller Class Initialized
DEBUG - 2020-09-22 06:53:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:53:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:53:26 --> Model Class Initialized
INFO - 2020-09-22 06:53:26 --> Model Class Initialized
INFO - 2020-09-22 06:53:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_edit.php
INFO - 2020-09-22 06:53:26 --> Final output sent to browser
DEBUG - 2020-09-22 06:53:26 --> Total execution time: 0.0262
ERROR - 2020-09-22 06:53:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:53:29 --> Config Class Initialized
INFO - 2020-09-22 06:53:29 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:53:29 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:53:29 --> Utf8 Class Initialized
INFO - 2020-09-22 06:53:29 --> URI Class Initialized
INFO - 2020-09-22 06:53:29 --> Router Class Initialized
INFO - 2020-09-22 06:53:29 --> Output Class Initialized
INFO - 2020-09-22 06:53:29 --> Security Class Initialized
DEBUG - 2020-09-22 06:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:53:29 --> Input Class Initialized
INFO - 2020-09-22 06:53:29 --> Language Class Initialized
INFO - 2020-09-22 06:53:29 --> Loader Class Initialized
INFO - 2020-09-22 06:53:29 --> Helper loaded: url_helper
INFO - 2020-09-22 06:53:29 --> Database Driver Class Initialized
INFO - 2020-09-22 06:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:53:29 --> Email Class Initialized
INFO - 2020-09-22 06:53:29 --> Controller Class Initialized
DEBUG - 2020-09-22 06:53:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:53:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:53:29 --> Model Class Initialized
INFO - 2020-09-22 06:53:29 --> Model Class Initialized
INFO - 2020-09-22 06:53:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 06:53:29 --> Final output sent to browser
DEBUG - 2020-09-22 06:53:29 --> Total execution time: 0.0241
ERROR - 2020-09-22 06:58:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:58:02 --> Config Class Initialized
INFO - 2020-09-22 06:58:02 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:58:02 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:58:02 --> Utf8 Class Initialized
INFO - 2020-09-22 06:58:02 --> URI Class Initialized
INFO - 2020-09-22 06:58:02 --> Router Class Initialized
INFO - 2020-09-22 06:58:02 --> Output Class Initialized
INFO - 2020-09-22 06:58:02 --> Security Class Initialized
DEBUG - 2020-09-22 06:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:58:02 --> Input Class Initialized
INFO - 2020-09-22 06:58:02 --> Language Class Initialized
INFO - 2020-09-22 06:58:02 --> Loader Class Initialized
INFO - 2020-09-22 06:58:02 --> Helper loaded: url_helper
INFO - 2020-09-22 06:58:02 --> Database Driver Class Initialized
INFO - 2020-09-22 06:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:58:02 --> Email Class Initialized
INFO - 2020-09-22 06:58:02 --> Controller Class Initialized
DEBUG - 2020-09-22 06:58:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:58:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:58:02 --> Model Class Initialized
INFO - 2020-09-22 06:58:02 --> Model Class Initialized
INFO - 2020-09-22 06:58:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 06:58:02 --> Final output sent to browser
DEBUG - 2020-09-22 06:58:02 --> Total execution time: 0.0262
ERROR - 2020-09-22 06:58:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:58:46 --> Config Class Initialized
INFO - 2020-09-22 06:58:46 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:58:46 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:58:46 --> Utf8 Class Initialized
INFO - 2020-09-22 06:58:46 --> URI Class Initialized
INFO - 2020-09-22 06:58:46 --> Router Class Initialized
INFO - 2020-09-22 06:58:46 --> Output Class Initialized
INFO - 2020-09-22 06:58:46 --> Security Class Initialized
DEBUG - 2020-09-22 06:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:58:46 --> Input Class Initialized
INFO - 2020-09-22 06:58:46 --> Language Class Initialized
INFO - 2020-09-22 06:58:46 --> Loader Class Initialized
INFO - 2020-09-22 06:58:46 --> Helper loaded: url_helper
INFO - 2020-09-22 06:58:46 --> Database Driver Class Initialized
INFO - 2020-09-22 06:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:58:46 --> Email Class Initialized
INFO - 2020-09-22 06:58:46 --> Controller Class Initialized
DEBUG - 2020-09-22 06:58:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:58:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:58:46 --> Model Class Initialized
INFO - 2020-09-22 06:58:46 --> Model Class Initialized
INFO - 2020-09-22 06:58:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 06:58:46 --> Final output sent to browser
DEBUG - 2020-09-22 06:58:46 --> Total execution time: 0.0234
ERROR - 2020-09-22 06:58:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:58:51 --> Config Class Initialized
INFO - 2020-09-22 06:58:51 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:58:51 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:58:51 --> Utf8 Class Initialized
INFO - 2020-09-22 06:58:51 --> URI Class Initialized
INFO - 2020-09-22 06:58:51 --> Router Class Initialized
INFO - 2020-09-22 06:58:51 --> Output Class Initialized
INFO - 2020-09-22 06:58:51 --> Security Class Initialized
DEBUG - 2020-09-22 06:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:58:51 --> Input Class Initialized
INFO - 2020-09-22 06:58:51 --> Language Class Initialized
INFO - 2020-09-22 06:58:51 --> Loader Class Initialized
INFO - 2020-09-22 06:58:51 --> Helper loaded: url_helper
INFO - 2020-09-22 06:58:51 --> Database Driver Class Initialized
INFO - 2020-09-22 06:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:58:51 --> Email Class Initialized
INFO - 2020-09-22 06:58:51 --> Controller Class Initialized
DEBUG - 2020-09-22 06:58:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:58:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:58:51 --> Model Class Initialized
INFO - 2020-09-22 06:58:51 --> Model Class Initialized
INFO - 2020-09-22 06:58:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 06:58:51 --> Final output sent to browser
DEBUG - 2020-09-22 06:58:51 --> Total execution time: 0.0369
ERROR - 2020-09-22 06:58:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:58:56 --> Config Class Initialized
INFO - 2020-09-22 06:58:56 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:58:56 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:58:56 --> Utf8 Class Initialized
INFO - 2020-09-22 06:58:56 --> URI Class Initialized
INFO - 2020-09-22 06:58:56 --> Router Class Initialized
INFO - 2020-09-22 06:58:56 --> Output Class Initialized
INFO - 2020-09-22 06:58:56 --> Security Class Initialized
DEBUG - 2020-09-22 06:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:58:56 --> Input Class Initialized
INFO - 2020-09-22 06:58:56 --> Language Class Initialized
INFO - 2020-09-22 06:58:56 --> Loader Class Initialized
INFO - 2020-09-22 06:58:56 --> Helper loaded: url_helper
INFO - 2020-09-22 06:58:56 --> Database Driver Class Initialized
INFO - 2020-09-22 06:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:58:56 --> Email Class Initialized
INFO - 2020-09-22 06:58:56 --> Controller Class Initialized
DEBUG - 2020-09-22 06:58:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:58:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:58:56 --> Model Class Initialized
INFO - 2020-09-22 06:58:56 --> Model Class Initialized
INFO - 2020-09-22 06:58:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-22 06:58:56 --> Final output sent to browser
DEBUG - 2020-09-22 06:58:56 --> Total execution time: 0.0249
ERROR - 2020-09-22 06:58:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:58:58 --> Config Class Initialized
INFO - 2020-09-22 06:58:58 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:58:58 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:58:58 --> Utf8 Class Initialized
INFO - 2020-09-22 06:58:58 --> URI Class Initialized
INFO - 2020-09-22 06:58:58 --> Router Class Initialized
INFO - 2020-09-22 06:58:58 --> Output Class Initialized
INFO - 2020-09-22 06:58:58 --> Security Class Initialized
DEBUG - 2020-09-22 06:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:58:58 --> Input Class Initialized
INFO - 2020-09-22 06:58:58 --> Language Class Initialized
INFO - 2020-09-22 06:58:58 --> Loader Class Initialized
INFO - 2020-09-22 06:58:58 --> Helper loaded: url_helper
INFO - 2020-09-22 06:58:58 --> Database Driver Class Initialized
INFO - 2020-09-22 06:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:58:58 --> Email Class Initialized
INFO - 2020-09-22 06:58:58 --> Controller Class Initialized
DEBUG - 2020-09-22 06:58:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:58:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:58:58 --> Model Class Initialized
INFO - 2020-09-22 06:58:58 --> Model Class Initialized
INFO - 2020-09-22 06:58:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 06:58:58 --> Final output sent to browser
DEBUG - 2020-09-22 06:58:58 --> Total execution time: 0.0236
ERROR - 2020-09-22 06:59:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:59:00 --> Config Class Initialized
INFO - 2020-09-22 06:59:00 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:59:00 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:59:00 --> Utf8 Class Initialized
INFO - 2020-09-22 06:59:00 --> URI Class Initialized
INFO - 2020-09-22 06:59:00 --> Router Class Initialized
INFO - 2020-09-22 06:59:00 --> Output Class Initialized
INFO - 2020-09-22 06:59:00 --> Security Class Initialized
DEBUG - 2020-09-22 06:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:59:00 --> Input Class Initialized
INFO - 2020-09-22 06:59:00 --> Language Class Initialized
INFO - 2020-09-22 06:59:00 --> Loader Class Initialized
INFO - 2020-09-22 06:59:00 --> Helper loaded: url_helper
INFO - 2020-09-22 06:59:00 --> Database Driver Class Initialized
INFO - 2020-09-22 06:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:59:00 --> Email Class Initialized
INFO - 2020-09-22 06:59:00 --> Controller Class Initialized
DEBUG - 2020-09-22 06:59:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:59:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:59:00 --> Model Class Initialized
INFO - 2020-09-22 06:59:00 --> Model Class Initialized
INFO - 2020-09-22 06:59:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 06:59:00 --> Final output sent to browser
DEBUG - 2020-09-22 06:59:00 --> Total execution time: 0.0282
ERROR - 2020-09-22 06:59:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:59:01 --> Config Class Initialized
INFO - 2020-09-22 06:59:01 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:59:01 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:59:01 --> Utf8 Class Initialized
INFO - 2020-09-22 06:59:01 --> URI Class Initialized
INFO - 2020-09-22 06:59:01 --> Router Class Initialized
INFO - 2020-09-22 06:59:01 --> Output Class Initialized
INFO - 2020-09-22 06:59:01 --> Security Class Initialized
DEBUG - 2020-09-22 06:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:59:01 --> Input Class Initialized
INFO - 2020-09-22 06:59:01 --> Language Class Initialized
INFO - 2020-09-22 06:59:01 --> Loader Class Initialized
INFO - 2020-09-22 06:59:01 --> Helper loaded: url_helper
INFO - 2020-09-22 06:59:01 --> Database Driver Class Initialized
INFO - 2020-09-22 06:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:59:01 --> Email Class Initialized
INFO - 2020-09-22 06:59:01 --> Controller Class Initialized
DEBUG - 2020-09-22 06:59:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:59:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:59:01 --> Model Class Initialized
INFO - 2020-09-22 06:59:01 --> Model Class Initialized
INFO - 2020-09-22 06:59:01 --> Final output sent to browser
DEBUG - 2020-09-22 06:59:01 --> Total execution time: 0.0282
ERROR - 2020-09-22 06:59:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:59:49 --> Config Class Initialized
INFO - 2020-09-22 06:59:49 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:59:49 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:59:49 --> Utf8 Class Initialized
INFO - 2020-09-22 06:59:49 --> URI Class Initialized
INFO - 2020-09-22 06:59:49 --> Router Class Initialized
INFO - 2020-09-22 06:59:49 --> Output Class Initialized
INFO - 2020-09-22 06:59:49 --> Security Class Initialized
DEBUG - 2020-09-22 06:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:59:49 --> Input Class Initialized
INFO - 2020-09-22 06:59:49 --> Language Class Initialized
INFO - 2020-09-22 06:59:49 --> Loader Class Initialized
INFO - 2020-09-22 06:59:49 --> Helper loaded: url_helper
INFO - 2020-09-22 06:59:49 --> Database Driver Class Initialized
INFO - 2020-09-22 06:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:59:49 --> Email Class Initialized
INFO - 2020-09-22 06:59:49 --> Controller Class Initialized
DEBUG - 2020-09-22 06:59:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:59:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:59:49 --> Model Class Initialized
INFO - 2020-09-22 06:59:49 --> Model Class Initialized
INFO - 2020-09-22 06:59:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 06:59:49 --> Final output sent to browser
DEBUG - 2020-09-22 06:59:49 --> Total execution time: 0.0258
ERROR - 2020-09-22 06:59:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 06:59:51 --> Config Class Initialized
INFO - 2020-09-22 06:59:51 --> Hooks Class Initialized
DEBUG - 2020-09-22 06:59:51 --> UTF-8 Support Enabled
INFO - 2020-09-22 06:59:51 --> Utf8 Class Initialized
INFO - 2020-09-22 06:59:51 --> URI Class Initialized
INFO - 2020-09-22 06:59:51 --> Router Class Initialized
INFO - 2020-09-22 06:59:51 --> Output Class Initialized
INFO - 2020-09-22 06:59:51 --> Security Class Initialized
DEBUG - 2020-09-22 06:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 06:59:51 --> Input Class Initialized
INFO - 2020-09-22 06:59:51 --> Language Class Initialized
INFO - 2020-09-22 06:59:51 --> Loader Class Initialized
INFO - 2020-09-22 06:59:51 --> Helper loaded: url_helper
INFO - 2020-09-22 06:59:51 --> Database Driver Class Initialized
INFO - 2020-09-22 06:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 06:59:51 --> Email Class Initialized
INFO - 2020-09-22 06:59:51 --> Controller Class Initialized
DEBUG - 2020-09-22 06:59:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 06:59:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 06:59:51 --> Model Class Initialized
INFO - 2020-09-22 06:59:51 --> Model Class Initialized
INFO - 2020-09-22 06:59:51 --> Final output sent to browser
DEBUG - 2020-09-22 06:59:51 --> Total execution time: 0.0241
ERROR - 2020-09-22 07:01:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:01:00 --> Config Class Initialized
INFO - 2020-09-22 07:01:00 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:01:00 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:01:00 --> Utf8 Class Initialized
INFO - 2020-09-22 07:01:00 --> URI Class Initialized
INFO - 2020-09-22 07:01:00 --> Router Class Initialized
INFO - 2020-09-22 07:01:00 --> Output Class Initialized
INFO - 2020-09-22 07:01:00 --> Security Class Initialized
DEBUG - 2020-09-22 07:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:01:00 --> Input Class Initialized
INFO - 2020-09-22 07:01:00 --> Language Class Initialized
INFO - 2020-09-22 07:01:00 --> Loader Class Initialized
INFO - 2020-09-22 07:01:00 --> Helper loaded: url_helper
INFO - 2020-09-22 07:01:00 --> Database Driver Class Initialized
INFO - 2020-09-22 07:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:01:00 --> Email Class Initialized
INFO - 2020-09-22 07:01:00 --> Controller Class Initialized
DEBUG - 2020-09-22 07:01:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:01:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:01:00 --> Model Class Initialized
INFO - 2020-09-22 07:01:00 --> Model Class Initialized
INFO - 2020-09-22 07:01:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-22 07:01:00 --> Final output sent to browser
DEBUG - 2020-09-22 07:01:00 --> Total execution time: 0.0235
ERROR - 2020-09-22 07:01:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:01:04 --> Config Class Initialized
INFO - 2020-09-22 07:01:04 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:01:04 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:01:04 --> Utf8 Class Initialized
INFO - 2020-09-22 07:01:04 --> URI Class Initialized
INFO - 2020-09-22 07:01:04 --> Router Class Initialized
INFO - 2020-09-22 07:01:04 --> Output Class Initialized
INFO - 2020-09-22 07:01:04 --> Security Class Initialized
DEBUG - 2020-09-22 07:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:01:04 --> Input Class Initialized
INFO - 2020-09-22 07:01:04 --> Language Class Initialized
INFO - 2020-09-22 07:01:04 --> Loader Class Initialized
INFO - 2020-09-22 07:01:04 --> Helper loaded: url_helper
INFO - 2020-09-22 07:01:04 --> Database Driver Class Initialized
INFO - 2020-09-22 07:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:01:04 --> Email Class Initialized
INFO - 2020-09-22 07:01:04 --> Controller Class Initialized
DEBUG - 2020-09-22 07:01:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:01:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:01:04 --> Model Class Initialized
INFO - 2020-09-22 07:01:04 --> Model Class Initialized
INFO - 2020-09-22 07:01:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 07:01:04 --> Final output sent to browser
DEBUG - 2020-09-22 07:01:04 --> Total execution time: 0.0371
ERROR - 2020-09-22 07:01:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:01:06 --> Config Class Initialized
INFO - 2020-09-22 07:01:06 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:01:06 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:01:06 --> Utf8 Class Initialized
INFO - 2020-09-22 07:01:06 --> URI Class Initialized
INFO - 2020-09-22 07:01:06 --> Router Class Initialized
INFO - 2020-09-22 07:01:06 --> Output Class Initialized
INFO - 2020-09-22 07:01:06 --> Security Class Initialized
DEBUG - 2020-09-22 07:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:01:06 --> Input Class Initialized
INFO - 2020-09-22 07:01:06 --> Language Class Initialized
INFO - 2020-09-22 07:01:06 --> Loader Class Initialized
INFO - 2020-09-22 07:01:06 --> Helper loaded: url_helper
INFO - 2020-09-22 07:01:06 --> Database Driver Class Initialized
INFO - 2020-09-22 07:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:01:06 --> Email Class Initialized
INFO - 2020-09-22 07:01:06 --> Controller Class Initialized
DEBUG - 2020-09-22 07:01:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:01:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:01:06 --> Model Class Initialized
INFO - 2020-09-22 07:01:06 --> Model Class Initialized
INFO - 2020-09-22 07:01:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-22 07:01:06 --> Final output sent to browser
DEBUG - 2020-09-22 07:01:06 --> Total execution time: 0.0263
ERROR - 2020-09-22 07:01:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:01:10 --> Config Class Initialized
INFO - 2020-09-22 07:01:10 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:01:10 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:01:10 --> Utf8 Class Initialized
INFO - 2020-09-22 07:01:10 --> URI Class Initialized
INFO - 2020-09-22 07:01:10 --> Router Class Initialized
INFO - 2020-09-22 07:01:10 --> Output Class Initialized
INFO - 2020-09-22 07:01:10 --> Security Class Initialized
DEBUG - 2020-09-22 07:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:01:10 --> Input Class Initialized
INFO - 2020-09-22 07:01:10 --> Language Class Initialized
INFO - 2020-09-22 07:01:10 --> Loader Class Initialized
INFO - 2020-09-22 07:01:10 --> Helper loaded: url_helper
INFO - 2020-09-22 07:01:10 --> Database Driver Class Initialized
INFO - 2020-09-22 07:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:01:10 --> Email Class Initialized
INFO - 2020-09-22 07:01:10 --> Controller Class Initialized
DEBUG - 2020-09-22 07:01:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:01:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:01:10 --> Model Class Initialized
INFO - 2020-09-22 07:01:10 --> Model Class Initialized
INFO - 2020-09-22 07:01:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-09-22 07:01:10 --> Final output sent to browser
DEBUG - 2020-09-22 07:01:10 --> Total execution time: 0.0237
ERROR - 2020-09-22 07:01:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:01:14 --> Config Class Initialized
INFO - 2020-09-22 07:01:14 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:01:14 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:01:14 --> Utf8 Class Initialized
INFO - 2020-09-22 07:01:14 --> URI Class Initialized
INFO - 2020-09-22 07:01:14 --> Router Class Initialized
INFO - 2020-09-22 07:01:14 --> Output Class Initialized
INFO - 2020-09-22 07:01:14 --> Security Class Initialized
DEBUG - 2020-09-22 07:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:01:14 --> Input Class Initialized
INFO - 2020-09-22 07:01:14 --> Language Class Initialized
INFO - 2020-09-22 07:01:14 --> Loader Class Initialized
INFO - 2020-09-22 07:01:14 --> Helper loaded: url_helper
INFO - 2020-09-22 07:01:14 --> Database Driver Class Initialized
INFO - 2020-09-22 07:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:01:14 --> Email Class Initialized
INFO - 2020-09-22 07:01:14 --> Controller Class Initialized
DEBUG - 2020-09-22 07:01:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:01:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:01:14 --> Model Class Initialized
INFO - 2020-09-22 07:01:14 --> Model Class Initialized
INFO - 2020-09-22 07:01:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-22 07:01:14 --> Final output sent to browser
DEBUG - 2020-09-22 07:01:14 --> Total execution time: 0.0277
ERROR - 2020-09-22 07:01:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:01:16 --> Config Class Initialized
INFO - 2020-09-22 07:01:16 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:01:16 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:01:16 --> Utf8 Class Initialized
INFO - 2020-09-22 07:01:16 --> URI Class Initialized
INFO - 2020-09-22 07:01:16 --> Router Class Initialized
INFO - 2020-09-22 07:01:16 --> Output Class Initialized
INFO - 2020-09-22 07:01:16 --> Security Class Initialized
DEBUG - 2020-09-22 07:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:01:16 --> Input Class Initialized
INFO - 2020-09-22 07:01:16 --> Language Class Initialized
INFO - 2020-09-22 07:01:16 --> Loader Class Initialized
INFO - 2020-09-22 07:01:16 --> Helper loaded: url_helper
INFO - 2020-09-22 07:01:16 --> Database Driver Class Initialized
INFO - 2020-09-22 07:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:01:16 --> Email Class Initialized
INFO - 2020-09-22 07:01:16 --> Controller Class Initialized
DEBUG - 2020-09-22 07:01:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:01:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:01:16 --> Model Class Initialized
INFO - 2020-09-22 07:01:16 --> Model Class Initialized
INFO - 2020-09-22 07:01:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_view.php
INFO - 2020-09-22 07:01:16 --> Final output sent to browser
DEBUG - 2020-09-22 07:01:16 --> Total execution time: 0.0308
ERROR - 2020-09-22 07:01:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:01:19 --> Config Class Initialized
INFO - 2020-09-22 07:01:19 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:01:19 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:01:19 --> Utf8 Class Initialized
INFO - 2020-09-22 07:01:19 --> URI Class Initialized
INFO - 2020-09-22 07:01:19 --> Router Class Initialized
INFO - 2020-09-22 07:01:19 --> Output Class Initialized
INFO - 2020-09-22 07:01:19 --> Security Class Initialized
DEBUG - 2020-09-22 07:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:01:19 --> Input Class Initialized
INFO - 2020-09-22 07:01:19 --> Language Class Initialized
INFO - 2020-09-22 07:01:19 --> Loader Class Initialized
INFO - 2020-09-22 07:01:19 --> Helper loaded: url_helper
INFO - 2020-09-22 07:01:19 --> Database Driver Class Initialized
INFO - 2020-09-22 07:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:01:19 --> Email Class Initialized
INFO - 2020-09-22 07:01:19 --> Controller Class Initialized
DEBUG - 2020-09-22 07:01:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:01:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:01:19 --> Model Class Initialized
INFO - 2020-09-22 07:01:19 --> Model Class Initialized
INFO - 2020-09-22 07:01:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-22 07:01:19 --> Final output sent to browser
DEBUG - 2020-09-22 07:01:19 --> Total execution time: 0.0269
ERROR - 2020-09-22 07:01:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:01:20 --> Config Class Initialized
INFO - 2020-09-22 07:01:20 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:01:20 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:01:20 --> Utf8 Class Initialized
INFO - 2020-09-22 07:01:20 --> URI Class Initialized
INFO - 2020-09-22 07:01:20 --> Router Class Initialized
INFO - 2020-09-22 07:01:20 --> Output Class Initialized
INFO - 2020-09-22 07:01:20 --> Security Class Initialized
DEBUG - 2020-09-22 07:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:01:20 --> Input Class Initialized
INFO - 2020-09-22 07:01:20 --> Language Class Initialized
INFO - 2020-09-22 07:01:20 --> Loader Class Initialized
INFO - 2020-09-22 07:01:20 --> Helper loaded: url_helper
INFO - 2020-09-22 07:01:20 --> Database Driver Class Initialized
INFO - 2020-09-22 07:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:01:20 --> Email Class Initialized
INFO - 2020-09-22 07:01:20 --> Controller Class Initialized
DEBUG - 2020-09-22 07:01:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:01:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:01:20 --> Model Class Initialized
INFO - 2020-09-22 07:01:20 --> Model Class Initialized
INFO - 2020-09-22 07:01:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-09-22 07:01:20 --> Final output sent to browser
DEBUG - 2020-09-22 07:01:20 --> Total execution time: 0.0266
ERROR - 2020-09-22 07:01:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:01:23 --> Config Class Initialized
INFO - 2020-09-22 07:01:23 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:01:23 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:01:23 --> Utf8 Class Initialized
INFO - 2020-09-22 07:01:23 --> URI Class Initialized
INFO - 2020-09-22 07:01:23 --> Router Class Initialized
INFO - 2020-09-22 07:01:23 --> Output Class Initialized
INFO - 2020-09-22 07:01:23 --> Security Class Initialized
DEBUG - 2020-09-22 07:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:01:23 --> Input Class Initialized
INFO - 2020-09-22 07:01:23 --> Language Class Initialized
INFO - 2020-09-22 07:01:23 --> Loader Class Initialized
INFO - 2020-09-22 07:01:23 --> Helper loaded: url_helper
INFO - 2020-09-22 07:01:23 --> Database Driver Class Initialized
INFO - 2020-09-22 07:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:01:23 --> Email Class Initialized
INFO - 2020-09-22 07:01:23 --> Controller Class Initialized
DEBUG - 2020-09-22 07:01:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:01:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:01:23 --> Model Class Initialized
INFO - 2020-09-22 07:01:23 --> Model Class Initialized
INFO - 2020-09-22 07:01:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-22 07:01:23 --> Final output sent to browser
DEBUG - 2020-09-22 07:01:23 --> Total execution time: 0.0239
ERROR - 2020-09-22 07:01:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:01:25 --> Config Class Initialized
INFO - 2020-09-22 07:01:25 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:01:25 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:01:25 --> Utf8 Class Initialized
INFO - 2020-09-22 07:01:25 --> URI Class Initialized
INFO - 2020-09-22 07:01:25 --> Router Class Initialized
INFO - 2020-09-22 07:01:25 --> Output Class Initialized
INFO - 2020-09-22 07:01:25 --> Security Class Initialized
DEBUG - 2020-09-22 07:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:01:25 --> Input Class Initialized
INFO - 2020-09-22 07:01:25 --> Language Class Initialized
INFO - 2020-09-22 07:01:25 --> Loader Class Initialized
INFO - 2020-09-22 07:01:25 --> Helper loaded: url_helper
INFO - 2020-09-22 07:01:25 --> Database Driver Class Initialized
INFO - 2020-09-22 07:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:01:25 --> Email Class Initialized
INFO - 2020-09-22 07:01:25 --> Controller Class Initialized
DEBUG - 2020-09-22 07:01:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:01:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:01:25 --> Model Class Initialized
INFO - 2020-09-22 07:01:25 --> Model Class Initialized
INFO - 2020-09-22 07:01:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 07:01:25 --> Final output sent to browser
DEBUG - 2020-09-22 07:01:25 --> Total execution time: 0.0248
ERROR - 2020-09-22 07:07:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:07:03 --> Config Class Initialized
INFO - 2020-09-22 07:07:03 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:07:03 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:07:03 --> Utf8 Class Initialized
INFO - 2020-09-22 07:07:03 --> URI Class Initialized
INFO - 2020-09-22 07:07:03 --> Router Class Initialized
INFO - 2020-09-22 07:07:03 --> Output Class Initialized
INFO - 2020-09-22 07:07:03 --> Security Class Initialized
DEBUG - 2020-09-22 07:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:07:03 --> Input Class Initialized
INFO - 2020-09-22 07:07:03 --> Language Class Initialized
INFO - 2020-09-22 07:07:03 --> Loader Class Initialized
INFO - 2020-09-22 07:07:03 --> Helper loaded: url_helper
INFO - 2020-09-22 07:07:03 --> Database Driver Class Initialized
INFO - 2020-09-22 07:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:07:03 --> Email Class Initialized
INFO - 2020-09-22 07:07:03 --> Controller Class Initialized
DEBUG - 2020-09-22 07:07:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:07:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:07:03 --> Model Class Initialized
INFO - 2020-09-22 07:07:03 --> Model Class Initialized
INFO - 2020-09-22 07:07:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 07:07:03 --> Final output sent to browser
DEBUG - 2020-09-22 07:07:03 --> Total execution time: 0.0266
ERROR - 2020-09-22 07:08:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:08:14 --> Config Class Initialized
INFO - 2020-09-22 07:08:14 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:08:14 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:08:14 --> Utf8 Class Initialized
INFO - 2020-09-22 07:08:14 --> URI Class Initialized
INFO - 2020-09-22 07:08:14 --> Router Class Initialized
INFO - 2020-09-22 07:08:14 --> Output Class Initialized
INFO - 2020-09-22 07:08:14 --> Security Class Initialized
DEBUG - 2020-09-22 07:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:08:14 --> Input Class Initialized
INFO - 2020-09-22 07:08:14 --> Language Class Initialized
INFO - 2020-09-22 07:08:14 --> Loader Class Initialized
INFO - 2020-09-22 07:08:14 --> Helper loaded: url_helper
INFO - 2020-09-22 07:08:14 --> Database Driver Class Initialized
INFO - 2020-09-22 07:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:08:14 --> Email Class Initialized
INFO - 2020-09-22 07:08:14 --> Controller Class Initialized
DEBUG - 2020-09-22 07:08:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:08:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:08:14 --> Model Class Initialized
INFO - 2020-09-22 07:08:14 --> Model Class Initialized
INFO - 2020-09-22 07:08:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 07:08:14 --> Final output sent to browser
DEBUG - 2020-09-22 07:08:14 --> Total execution time: 0.0222
ERROR - 2020-09-22 07:08:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:08:16 --> Config Class Initialized
INFO - 2020-09-22 07:08:16 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:08:16 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:08:16 --> Utf8 Class Initialized
INFO - 2020-09-22 07:08:16 --> URI Class Initialized
INFO - 2020-09-22 07:08:16 --> Router Class Initialized
INFO - 2020-09-22 07:08:16 --> Output Class Initialized
INFO - 2020-09-22 07:08:16 --> Security Class Initialized
DEBUG - 2020-09-22 07:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:08:16 --> Input Class Initialized
INFO - 2020-09-22 07:08:16 --> Language Class Initialized
INFO - 2020-09-22 07:08:16 --> Loader Class Initialized
INFO - 2020-09-22 07:08:16 --> Helper loaded: url_helper
INFO - 2020-09-22 07:08:16 --> Database Driver Class Initialized
INFO - 2020-09-22 07:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:08:16 --> Email Class Initialized
INFO - 2020-09-22 07:08:16 --> Controller Class Initialized
DEBUG - 2020-09-22 07:08:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:08:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:08:16 --> Model Class Initialized
INFO - 2020-09-22 07:08:16 --> Model Class Initialized
INFO - 2020-09-22 07:08:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 07:08:16 --> Final output sent to browser
DEBUG - 2020-09-22 07:08:16 --> Total execution time: 0.0259
ERROR - 2020-09-22 07:11:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:11:38 --> Config Class Initialized
INFO - 2020-09-22 07:11:38 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:11:38 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:11:38 --> Utf8 Class Initialized
INFO - 2020-09-22 07:11:38 --> URI Class Initialized
INFO - 2020-09-22 07:11:38 --> Router Class Initialized
INFO - 2020-09-22 07:11:38 --> Output Class Initialized
INFO - 2020-09-22 07:11:38 --> Security Class Initialized
DEBUG - 2020-09-22 07:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:11:38 --> Input Class Initialized
INFO - 2020-09-22 07:11:38 --> Language Class Initialized
INFO - 2020-09-22 07:11:38 --> Loader Class Initialized
INFO - 2020-09-22 07:11:38 --> Helper loaded: url_helper
INFO - 2020-09-22 07:11:38 --> Database Driver Class Initialized
INFO - 2020-09-22 07:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:11:38 --> Email Class Initialized
INFO - 2020-09-22 07:11:38 --> Controller Class Initialized
DEBUG - 2020-09-22 07:11:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:11:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:11:38 --> Model Class Initialized
INFO - 2020-09-22 07:11:38 --> Model Class Initialized
INFO - 2020-09-22 07:11:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 07:11:38 --> Final output sent to browser
DEBUG - 2020-09-22 07:11:38 --> Total execution time: 0.0262
ERROR - 2020-09-22 07:11:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:11:55 --> Config Class Initialized
INFO - 2020-09-22 07:11:55 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:11:55 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:11:55 --> Utf8 Class Initialized
INFO - 2020-09-22 07:11:55 --> URI Class Initialized
INFO - 2020-09-22 07:11:55 --> Router Class Initialized
INFO - 2020-09-22 07:11:55 --> Output Class Initialized
INFO - 2020-09-22 07:11:55 --> Security Class Initialized
DEBUG - 2020-09-22 07:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:11:55 --> Input Class Initialized
INFO - 2020-09-22 07:11:55 --> Language Class Initialized
INFO - 2020-09-22 07:11:55 --> Loader Class Initialized
INFO - 2020-09-22 07:11:55 --> Helper loaded: url_helper
INFO - 2020-09-22 07:11:55 --> Database Driver Class Initialized
INFO - 2020-09-22 07:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:11:55 --> Email Class Initialized
INFO - 2020-09-22 07:11:55 --> Controller Class Initialized
DEBUG - 2020-09-22 07:11:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:11:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:11:55 --> Model Class Initialized
INFO - 2020-09-22 07:11:55 --> Model Class Initialized
INFO - 2020-09-22 07:11:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_view_for_client.php
INFO - 2020-09-22 07:11:55 --> Final output sent to browser
DEBUG - 2020-09-22 07:11:55 --> Total execution time: 0.0201
ERROR - 2020-09-22 07:12:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:12:00 --> Config Class Initialized
INFO - 2020-09-22 07:12:00 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:12:00 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:12:00 --> Utf8 Class Initialized
INFO - 2020-09-22 07:12:00 --> URI Class Initialized
INFO - 2020-09-22 07:12:00 --> Router Class Initialized
INFO - 2020-09-22 07:12:00 --> Output Class Initialized
INFO - 2020-09-22 07:12:00 --> Security Class Initialized
DEBUG - 2020-09-22 07:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:12:00 --> Input Class Initialized
INFO - 2020-09-22 07:12:00 --> Language Class Initialized
INFO - 2020-09-22 07:12:00 --> Loader Class Initialized
INFO - 2020-09-22 07:12:00 --> Helper loaded: url_helper
INFO - 2020-09-22 07:12:00 --> Database Driver Class Initialized
INFO - 2020-09-22 07:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:12:00 --> Email Class Initialized
INFO - 2020-09-22 07:12:00 --> Controller Class Initialized
DEBUG - 2020-09-22 07:12:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:12:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:12:00 --> Model Class Initialized
INFO - 2020-09-22 07:12:00 --> Model Class Initialized
INFO - 2020-09-22 07:12:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 07:12:00 --> Final output sent to browser
DEBUG - 2020-09-22 07:12:00 --> Total execution time: 0.0262
ERROR - 2020-09-22 07:12:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:12:02 --> Config Class Initialized
INFO - 2020-09-22 07:12:02 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:12:02 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:12:02 --> Utf8 Class Initialized
INFO - 2020-09-22 07:12:02 --> URI Class Initialized
INFO - 2020-09-22 07:12:02 --> Router Class Initialized
INFO - 2020-09-22 07:12:02 --> Output Class Initialized
INFO - 2020-09-22 07:12:02 --> Security Class Initialized
DEBUG - 2020-09-22 07:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:12:02 --> Input Class Initialized
INFO - 2020-09-22 07:12:02 --> Language Class Initialized
INFO - 2020-09-22 07:12:02 --> Loader Class Initialized
INFO - 2020-09-22 07:12:02 --> Helper loaded: url_helper
INFO - 2020-09-22 07:12:02 --> Database Driver Class Initialized
INFO - 2020-09-22 07:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:12:02 --> Email Class Initialized
INFO - 2020-09-22 07:12:02 --> Controller Class Initialized
DEBUG - 2020-09-22 07:12:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:12:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:12:02 --> Model Class Initialized
INFO - 2020-09-22 07:12:02 --> Model Class Initialized
INFO - 2020-09-22 07:12:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_view_for_client.php
INFO - 2020-09-22 07:12:02 --> Final output sent to browser
DEBUG - 2020-09-22 07:12:02 --> Total execution time: 0.0298
ERROR - 2020-09-22 07:12:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:12:05 --> Config Class Initialized
INFO - 2020-09-22 07:12:05 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:12:05 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:12:05 --> Utf8 Class Initialized
INFO - 2020-09-22 07:12:05 --> URI Class Initialized
INFO - 2020-09-22 07:12:05 --> Router Class Initialized
INFO - 2020-09-22 07:12:05 --> Output Class Initialized
INFO - 2020-09-22 07:12:05 --> Security Class Initialized
DEBUG - 2020-09-22 07:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:12:05 --> Input Class Initialized
INFO - 2020-09-22 07:12:05 --> Language Class Initialized
INFO - 2020-09-22 07:12:05 --> Loader Class Initialized
INFO - 2020-09-22 07:12:05 --> Helper loaded: url_helper
INFO - 2020-09-22 07:12:05 --> Database Driver Class Initialized
INFO - 2020-09-22 07:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:12:05 --> Email Class Initialized
INFO - 2020-09-22 07:12:05 --> Controller Class Initialized
DEBUG - 2020-09-22 07:12:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:12:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:12:05 --> Model Class Initialized
INFO - 2020-09-22 07:12:05 --> Model Class Initialized
INFO - 2020-09-22 07:12:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 07:12:05 --> Final output sent to browser
DEBUG - 2020-09-22 07:12:05 --> Total execution time: 0.1261
ERROR - 2020-09-22 07:12:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:12:08 --> Config Class Initialized
INFO - 2020-09-22 07:12:08 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:12:08 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:12:08 --> Utf8 Class Initialized
INFO - 2020-09-22 07:12:08 --> URI Class Initialized
INFO - 2020-09-22 07:12:08 --> Router Class Initialized
INFO - 2020-09-22 07:12:08 --> Output Class Initialized
INFO - 2020-09-22 07:12:08 --> Security Class Initialized
DEBUG - 2020-09-22 07:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:12:08 --> Input Class Initialized
INFO - 2020-09-22 07:12:08 --> Language Class Initialized
INFO - 2020-09-22 07:12:08 --> Loader Class Initialized
INFO - 2020-09-22 07:12:08 --> Helper loaded: url_helper
INFO - 2020-09-22 07:12:08 --> Database Driver Class Initialized
INFO - 2020-09-22 07:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:12:08 --> Email Class Initialized
INFO - 2020-09-22 07:12:08 --> Controller Class Initialized
DEBUG - 2020-09-22 07:12:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:12:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:12:08 --> Model Class Initialized
INFO - 2020-09-22 07:12:08 --> Model Class Initialized
INFO - 2020-09-22 07:12:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_view_for_client.php
INFO - 2020-09-22 07:12:08 --> Final output sent to browser
DEBUG - 2020-09-22 07:12:08 --> Total execution time: 0.0256
ERROR - 2020-09-22 07:12:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:12:10 --> Config Class Initialized
INFO - 2020-09-22 07:12:10 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:12:10 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:12:10 --> Utf8 Class Initialized
INFO - 2020-09-22 07:12:10 --> URI Class Initialized
INFO - 2020-09-22 07:12:10 --> Router Class Initialized
INFO - 2020-09-22 07:12:10 --> Output Class Initialized
INFO - 2020-09-22 07:12:10 --> Security Class Initialized
DEBUG - 2020-09-22 07:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:12:10 --> Input Class Initialized
INFO - 2020-09-22 07:12:10 --> Language Class Initialized
INFO - 2020-09-22 07:12:10 --> Loader Class Initialized
INFO - 2020-09-22 07:12:10 --> Helper loaded: url_helper
INFO - 2020-09-22 07:12:10 --> Database Driver Class Initialized
INFO - 2020-09-22 07:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:12:10 --> Email Class Initialized
INFO - 2020-09-22 07:12:10 --> Controller Class Initialized
DEBUG - 2020-09-22 07:12:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:12:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:12:10 --> Model Class Initialized
INFO - 2020-09-22 07:12:10 --> Model Class Initialized
INFO - 2020-09-22 07:12:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 07:12:10 --> Final output sent to browser
DEBUG - 2020-09-22 07:12:10 --> Total execution time: 0.0266
ERROR - 2020-09-22 07:14:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:14:30 --> Config Class Initialized
INFO - 2020-09-22 07:14:30 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:14:30 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:14:30 --> Utf8 Class Initialized
INFO - 2020-09-22 07:14:30 --> URI Class Initialized
INFO - 2020-09-22 07:14:30 --> Router Class Initialized
INFO - 2020-09-22 07:14:30 --> Output Class Initialized
INFO - 2020-09-22 07:14:30 --> Security Class Initialized
DEBUG - 2020-09-22 07:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:14:30 --> Input Class Initialized
INFO - 2020-09-22 07:14:30 --> Language Class Initialized
INFO - 2020-09-22 07:14:30 --> Loader Class Initialized
INFO - 2020-09-22 07:14:30 --> Helper loaded: url_helper
INFO - 2020-09-22 07:14:30 --> Database Driver Class Initialized
INFO - 2020-09-22 07:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:14:30 --> Email Class Initialized
INFO - 2020-09-22 07:14:30 --> Controller Class Initialized
DEBUG - 2020-09-22 07:14:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:14:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:14:30 --> Model Class Initialized
INFO - 2020-09-22 07:14:30 --> Model Class Initialized
INFO - 2020-09-22 07:14:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 07:14:30 --> Final output sent to browser
DEBUG - 2020-09-22 07:14:30 --> Total execution time: 0.0315
ERROR - 2020-09-22 07:14:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:14:31 --> Config Class Initialized
INFO - 2020-09-22 07:14:31 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:14:31 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:14:31 --> Utf8 Class Initialized
INFO - 2020-09-22 07:14:31 --> URI Class Initialized
INFO - 2020-09-22 07:14:31 --> Router Class Initialized
INFO - 2020-09-22 07:14:31 --> Output Class Initialized
INFO - 2020-09-22 07:14:31 --> Security Class Initialized
DEBUG - 2020-09-22 07:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:14:31 --> Input Class Initialized
INFO - 2020-09-22 07:14:31 --> Language Class Initialized
INFO - 2020-09-22 07:14:31 --> Loader Class Initialized
INFO - 2020-09-22 07:14:31 --> Helper loaded: url_helper
INFO - 2020-09-22 07:14:31 --> Database Driver Class Initialized
INFO - 2020-09-22 07:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:14:31 --> Email Class Initialized
INFO - 2020-09-22 07:14:31 --> Controller Class Initialized
DEBUG - 2020-09-22 07:14:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:14:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:14:31 --> Model Class Initialized
INFO - 2020-09-22 07:14:31 --> Model Class Initialized
INFO - 2020-09-22 07:14:31 --> Final output sent to browser
DEBUG - 2020-09-22 07:14:31 --> Total execution time: 0.0206
ERROR - 2020-09-22 07:14:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:14:39 --> Config Class Initialized
INFO - 2020-09-22 07:14:39 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:14:39 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:14:39 --> Utf8 Class Initialized
INFO - 2020-09-22 07:14:39 --> URI Class Initialized
INFO - 2020-09-22 07:14:39 --> Router Class Initialized
INFO - 2020-09-22 07:14:39 --> Output Class Initialized
INFO - 2020-09-22 07:14:39 --> Security Class Initialized
DEBUG - 2020-09-22 07:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:14:39 --> Input Class Initialized
INFO - 2020-09-22 07:14:39 --> Language Class Initialized
INFO - 2020-09-22 07:14:39 --> Loader Class Initialized
INFO - 2020-09-22 07:14:39 --> Helper loaded: url_helper
INFO - 2020-09-22 07:14:39 --> Database Driver Class Initialized
INFO - 2020-09-22 07:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:14:39 --> Email Class Initialized
INFO - 2020-09-22 07:14:39 --> Controller Class Initialized
DEBUG - 2020-09-22 07:14:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:14:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:14:39 --> Model Class Initialized
INFO - 2020-09-22 07:14:39 --> Model Class Initialized
INFO - 2020-09-22 07:14:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 07:14:39 --> Final output sent to browser
DEBUG - 2020-09-22 07:14:39 --> Total execution time: 0.0264
ERROR - 2020-09-22 07:41:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:41:14 --> Config Class Initialized
INFO - 2020-09-22 07:41:14 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:41:14 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:41:14 --> Utf8 Class Initialized
INFO - 2020-09-22 07:41:14 --> URI Class Initialized
INFO - 2020-09-22 07:41:14 --> Router Class Initialized
INFO - 2020-09-22 07:41:14 --> Output Class Initialized
INFO - 2020-09-22 07:41:14 --> Security Class Initialized
DEBUG - 2020-09-22 07:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:41:14 --> Input Class Initialized
INFO - 2020-09-22 07:41:14 --> Language Class Initialized
INFO - 2020-09-22 07:41:14 --> Loader Class Initialized
INFO - 2020-09-22 07:41:14 --> Helper loaded: url_helper
INFO - 2020-09-22 07:41:14 --> Database Driver Class Initialized
INFO - 2020-09-22 07:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:41:14 --> Email Class Initialized
INFO - 2020-09-22 07:41:14 --> Controller Class Initialized
DEBUG - 2020-09-22 07:41:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:41:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:41:14 --> Model Class Initialized
INFO - 2020-09-22 07:41:14 --> Model Class Initialized
INFO - 2020-09-22 07:41:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-22 07:41:14 --> Final output sent to browser
DEBUG - 2020-09-22 07:41:14 --> Total execution time: 0.0256
ERROR - 2020-09-22 07:41:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:41:16 --> Config Class Initialized
INFO - 2020-09-22 07:41:16 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:41:16 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:41:16 --> Utf8 Class Initialized
INFO - 2020-09-22 07:41:16 --> URI Class Initialized
INFO - 2020-09-22 07:41:16 --> Router Class Initialized
INFO - 2020-09-22 07:41:16 --> Output Class Initialized
INFO - 2020-09-22 07:41:16 --> Security Class Initialized
DEBUG - 2020-09-22 07:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:41:16 --> Input Class Initialized
INFO - 2020-09-22 07:41:16 --> Language Class Initialized
INFO - 2020-09-22 07:41:16 --> Loader Class Initialized
INFO - 2020-09-22 07:41:16 --> Helper loaded: url_helper
INFO - 2020-09-22 07:41:16 --> Database Driver Class Initialized
INFO - 2020-09-22 07:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:41:16 --> Email Class Initialized
INFO - 2020-09-22 07:41:16 --> Controller Class Initialized
DEBUG - 2020-09-22 07:41:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:41:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:41:16 --> Model Class Initialized
INFO - 2020-09-22 07:41:16 --> Model Class Initialized
INFO - 2020-09-22 07:41:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 07:41:16 --> Final output sent to browser
DEBUG - 2020-09-22 07:41:16 --> Total execution time: 0.0255
ERROR - 2020-09-22 07:41:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:41:26 --> Config Class Initialized
INFO - 2020-09-22 07:41:26 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:41:26 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:41:26 --> Utf8 Class Initialized
INFO - 2020-09-22 07:41:26 --> URI Class Initialized
INFO - 2020-09-22 07:41:26 --> Router Class Initialized
INFO - 2020-09-22 07:41:26 --> Output Class Initialized
INFO - 2020-09-22 07:41:26 --> Security Class Initialized
DEBUG - 2020-09-22 07:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:41:26 --> Input Class Initialized
INFO - 2020-09-22 07:41:26 --> Language Class Initialized
INFO - 2020-09-22 07:41:26 --> Loader Class Initialized
INFO - 2020-09-22 07:41:26 --> Helper loaded: url_helper
INFO - 2020-09-22 07:41:26 --> Database Driver Class Initialized
INFO - 2020-09-22 07:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:41:26 --> Email Class Initialized
INFO - 2020-09-22 07:41:26 --> Controller Class Initialized
DEBUG - 2020-09-22 07:41:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:41:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:41:26 --> Model Class Initialized
INFO - 2020-09-22 07:41:26 --> Model Class Initialized
INFO - 2020-09-22 07:41:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 07:41:26 --> Final output sent to browser
DEBUG - 2020-09-22 07:41:26 --> Total execution time: 0.0374
ERROR - 2020-09-22 07:41:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:41:27 --> Config Class Initialized
INFO - 2020-09-22 07:41:27 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:41:27 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:41:27 --> Utf8 Class Initialized
INFO - 2020-09-22 07:41:27 --> URI Class Initialized
INFO - 2020-09-22 07:41:27 --> Router Class Initialized
INFO - 2020-09-22 07:41:27 --> Output Class Initialized
INFO - 2020-09-22 07:41:27 --> Security Class Initialized
DEBUG - 2020-09-22 07:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:41:27 --> Input Class Initialized
INFO - 2020-09-22 07:41:27 --> Language Class Initialized
INFO - 2020-09-22 07:41:27 --> Loader Class Initialized
INFO - 2020-09-22 07:41:27 --> Helper loaded: url_helper
INFO - 2020-09-22 07:41:27 --> Database Driver Class Initialized
INFO - 2020-09-22 07:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:41:27 --> Email Class Initialized
INFO - 2020-09-22 07:41:27 --> Controller Class Initialized
DEBUG - 2020-09-22 07:41:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:41:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:41:27 --> Model Class Initialized
INFO - 2020-09-22 07:41:27 --> Model Class Initialized
INFO - 2020-09-22 07:41:27 --> Final output sent to browser
DEBUG - 2020-09-22 07:41:27 --> Total execution time: 0.0265
ERROR - 2020-09-22 07:41:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:41:38 --> Config Class Initialized
INFO - 2020-09-22 07:41:38 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:41:38 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:41:38 --> Utf8 Class Initialized
INFO - 2020-09-22 07:41:38 --> URI Class Initialized
INFO - 2020-09-22 07:41:38 --> Router Class Initialized
INFO - 2020-09-22 07:41:38 --> Output Class Initialized
INFO - 2020-09-22 07:41:38 --> Security Class Initialized
DEBUG - 2020-09-22 07:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:41:38 --> Input Class Initialized
INFO - 2020-09-22 07:41:38 --> Language Class Initialized
INFO - 2020-09-22 07:41:38 --> Loader Class Initialized
INFO - 2020-09-22 07:41:38 --> Helper loaded: url_helper
INFO - 2020-09-22 07:41:38 --> Database Driver Class Initialized
INFO - 2020-09-22 07:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:41:38 --> Email Class Initialized
INFO - 2020-09-22 07:41:38 --> Controller Class Initialized
DEBUG - 2020-09-22 07:41:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:41:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:41:38 --> Model Class Initialized
INFO - 2020-09-22 07:41:38 --> Model Class Initialized
INFO - 2020-09-22 07:41:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 07:41:38 --> Final output sent to browser
DEBUG - 2020-09-22 07:41:38 --> Total execution time: 0.0255
ERROR - 2020-09-22 07:41:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:41:52 --> Config Class Initialized
INFO - 2020-09-22 07:41:52 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:41:52 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:41:52 --> Utf8 Class Initialized
INFO - 2020-09-22 07:41:52 --> URI Class Initialized
INFO - 2020-09-22 07:41:52 --> Router Class Initialized
INFO - 2020-09-22 07:41:52 --> Output Class Initialized
INFO - 2020-09-22 07:41:52 --> Security Class Initialized
DEBUG - 2020-09-22 07:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:41:52 --> Input Class Initialized
INFO - 2020-09-22 07:41:52 --> Language Class Initialized
INFO - 2020-09-22 07:41:52 --> Loader Class Initialized
INFO - 2020-09-22 07:41:52 --> Helper loaded: url_helper
INFO - 2020-09-22 07:41:52 --> Database Driver Class Initialized
INFO - 2020-09-22 07:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:41:52 --> Email Class Initialized
INFO - 2020-09-22 07:41:52 --> Controller Class Initialized
DEBUG - 2020-09-22 07:41:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:41:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:41:52 --> Model Class Initialized
INFO - 2020-09-22 07:41:52 --> Model Class Initialized
INFO - 2020-09-22 07:41:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-22 07:41:52 --> Final output sent to browser
DEBUG - 2020-09-22 07:41:52 --> Total execution time: 0.0251
ERROR - 2020-09-22 07:42:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:42:07 --> Config Class Initialized
INFO - 2020-09-22 07:42:07 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:42:07 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:42:07 --> Utf8 Class Initialized
INFO - 2020-09-22 07:42:07 --> URI Class Initialized
INFO - 2020-09-22 07:42:07 --> Router Class Initialized
INFO - 2020-09-22 07:42:07 --> Output Class Initialized
INFO - 2020-09-22 07:42:07 --> Security Class Initialized
DEBUG - 2020-09-22 07:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:42:07 --> Input Class Initialized
INFO - 2020-09-22 07:42:07 --> Language Class Initialized
INFO - 2020-09-22 07:42:07 --> Loader Class Initialized
INFO - 2020-09-22 07:42:07 --> Helper loaded: url_helper
INFO - 2020-09-22 07:42:07 --> Database Driver Class Initialized
INFO - 2020-09-22 07:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:42:07 --> Email Class Initialized
INFO - 2020-09-22 07:42:07 --> Controller Class Initialized
DEBUG - 2020-09-22 07:42:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:42:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:42:07 --> Model Class Initialized
INFO - 2020-09-22 07:42:07 --> Model Class Initialized
INFO - 2020-09-22 07:42:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-22 07:42:07 --> Final output sent to browser
DEBUG - 2020-09-22 07:42:07 --> Total execution time: 0.0237
ERROR - 2020-09-22 07:42:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:42:09 --> Config Class Initialized
INFO - 2020-09-22 07:42:09 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:42:09 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:42:09 --> Utf8 Class Initialized
INFO - 2020-09-22 07:42:09 --> URI Class Initialized
INFO - 2020-09-22 07:42:09 --> Router Class Initialized
INFO - 2020-09-22 07:42:09 --> Output Class Initialized
INFO - 2020-09-22 07:42:09 --> Security Class Initialized
DEBUG - 2020-09-22 07:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:42:09 --> Input Class Initialized
INFO - 2020-09-22 07:42:09 --> Language Class Initialized
INFO - 2020-09-22 07:42:09 --> Loader Class Initialized
INFO - 2020-09-22 07:42:09 --> Helper loaded: url_helper
INFO - 2020-09-22 07:42:09 --> Database Driver Class Initialized
INFO - 2020-09-22 07:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:42:09 --> Email Class Initialized
INFO - 2020-09-22 07:42:09 --> Controller Class Initialized
DEBUG - 2020-09-22 07:42:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:42:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:42:09 --> Model Class Initialized
INFO - 2020-09-22 07:42:09 --> Model Class Initialized
INFO - 2020-09-22 07:42:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 07:42:09 --> Final output sent to browser
DEBUG - 2020-09-22 07:42:09 --> Total execution time: 0.0246
ERROR - 2020-09-22 07:43:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:43:55 --> Config Class Initialized
INFO - 2020-09-22 07:43:55 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:43:55 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:43:55 --> Utf8 Class Initialized
INFO - 2020-09-22 07:43:55 --> URI Class Initialized
INFO - 2020-09-22 07:43:55 --> Router Class Initialized
INFO - 2020-09-22 07:43:55 --> Output Class Initialized
INFO - 2020-09-22 07:43:55 --> Security Class Initialized
DEBUG - 2020-09-22 07:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:43:55 --> Input Class Initialized
INFO - 2020-09-22 07:43:55 --> Language Class Initialized
INFO - 2020-09-22 07:43:55 --> Loader Class Initialized
INFO - 2020-09-22 07:43:55 --> Helper loaded: url_helper
INFO - 2020-09-22 07:43:55 --> Database Driver Class Initialized
INFO - 2020-09-22 07:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:43:55 --> Email Class Initialized
INFO - 2020-09-22 07:43:55 --> Controller Class Initialized
DEBUG - 2020-09-22 07:43:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:43:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:43:55 --> Model Class Initialized
INFO - 2020-09-22 07:43:55 --> Model Class Initialized
INFO - 2020-09-22 07:43:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 07:43:55 --> Final output sent to browser
DEBUG - 2020-09-22 07:43:55 --> Total execution time: 0.0338
ERROR - 2020-09-22 07:43:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:43:56 --> Config Class Initialized
INFO - 2020-09-22 07:43:56 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:43:56 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:43:56 --> Utf8 Class Initialized
INFO - 2020-09-22 07:43:56 --> URI Class Initialized
INFO - 2020-09-22 07:43:56 --> Router Class Initialized
INFO - 2020-09-22 07:43:56 --> Output Class Initialized
INFO - 2020-09-22 07:43:56 --> Security Class Initialized
DEBUG - 2020-09-22 07:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:43:56 --> Input Class Initialized
INFO - 2020-09-22 07:43:56 --> Language Class Initialized
INFO - 2020-09-22 07:43:56 --> Loader Class Initialized
INFO - 2020-09-22 07:43:56 --> Helper loaded: url_helper
INFO - 2020-09-22 07:43:56 --> Database Driver Class Initialized
INFO - 2020-09-22 07:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:43:56 --> Email Class Initialized
INFO - 2020-09-22 07:43:56 --> Controller Class Initialized
DEBUG - 2020-09-22 07:43:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:43:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:43:56 --> Model Class Initialized
INFO - 2020-09-22 07:43:56 --> Model Class Initialized
INFO - 2020-09-22 07:43:56 --> Final output sent to browser
DEBUG - 2020-09-22 07:43:56 --> Total execution time: 0.0215
ERROR - 2020-09-22 07:45:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:45:01 --> Config Class Initialized
INFO - 2020-09-22 07:45:01 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:45:01 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:45:01 --> Utf8 Class Initialized
INFO - 2020-09-22 07:45:01 --> URI Class Initialized
INFO - 2020-09-22 07:45:01 --> Router Class Initialized
INFO - 2020-09-22 07:45:01 --> Output Class Initialized
INFO - 2020-09-22 07:45:01 --> Security Class Initialized
DEBUG - 2020-09-22 07:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:45:01 --> Input Class Initialized
INFO - 2020-09-22 07:45:01 --> Language Class Initialized
INFO - 2020-09-22 07:45:01 --> Loader Class Initialized
INFO - 2020-09-22 07:45:01 --> Helper loaded: url_helper
INFO - 2020-09-22 07:45:01 --> Database Driver Class Initialized
INFO - 2020-09-22 07:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:45:01 --> Email Class Initialized
INFO - 2020-09-22 07:45:01 --> Controller Class Initialized
DEBUG - 2020-09-22 07:45:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:45:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:45:01 --> Model Class Initialized
INFO - 2020-09-22 07:45:02 --> Model Class Initialized
INFO - 2020-09-22 07:45:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 07:45:02 --> Final output sent to browser
DEBUG - 2020-09-22 07:45:02 --> Total execution time: 0.0283
ERROR - 2020-09-22 07:45:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:45:03 --> Config Class Initialized
INFO - 2020-09-22 07:45:03 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:45:03 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:45:03 --> Utf8 Class Initialized
INFO - 2020-09-22 07:45:03 --> URI Class Initialized
INFO - 2020-09-22 07:45:03 --> Router Class Initialized
INFO - 2020-09-22 07:45:03 --> Output Class Initialized
INFO - 2020-09-22 07:45:03 --> Security Class Initialized
DEBUG - 2020-09-22 07:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:45:03 --> Input Class Initialized
INFO - 2020-09-22 07:45:03 --> Language Class Initialized
INFO - 2020-09-22 07:45:03 --> Loader Class Initialized
INFO - 2020-09-22 07:45:03 --> Helper loaded: url_helper
INFO - 2020-09-22 07:45:03 --> Database Driver Class Initialized
INFO - 2020-09-22 07:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:45:03 --> Email Class Initialized
INFO - 2020-09-22 07:45:03 --> Controller Class Initialized
DEBUG - 2020-09-22 07:45:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:45:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:45:03 --> Model Class Initialized
INFO - 2020-09-22 07:45:03 --> Model Class Initialized
INFO - 2020-09-22 07:45:03 --> Final output sent to browser
DEBUG - 2020-09-22 07:45:03 --> Total execution time: 0.0252
ERROR - 2020-09-22 07:45:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:45:05 --> Config Class Initialized
INFO - 2020-09-22 07:45:05 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:45:05 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:45:05 --> Utf8 Class Initialized
INFO - 2020-09-22 07:45:05 --> URI Class Initialized
INFO - 2020-09-22 07:45:05 --> Router Class Initialized
INFO - 2020-09-22 07:45:05 --> Output Class Initialized
INFO - 2020-09-22 07:45:05 --> Security Class Initialized
DEBUG - 2020-09-22 07:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:45:05 --> Input Class Initialized
INFO - 2020-09-22 07:45:05 --> Language Class Initialized
INFO - 2020-09-22 07:45:05 --> Loader Class Initialized
INFO - 2020-09-22 07:45:05 --> Helper loaded: url_helper
INFO - 2020-09-22 07:45:05 --> Database Driver Class Initialized
INFO - 2020-09-22 07:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:45:05 --> Email Class Initialized
INFO - 2020-09-22 07:45:05 --> Controller Class Initialized
DEBUG - 2020-09-22 07:45:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:45:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:45:05 --> Model Class Initialized
INFO - 2020-09-22 07:45:05 --> Model Class Initialized
INFO - 2020-09-22 07:45:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 07:45:05 --> Final output sent to browser
DEBUG - 2020-09-22 07:45:05 --> Total execution time: 0.0236
ERROR - 2020-09-22 07:46:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:46:41 --> Config Class Initialized
INFO - 2020-09-22 07:46:41 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:46:41 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:46:41 --> Utf8 Class Initialized
INFO - 2020-09-22 07:46:41 --> URI Class Initialized
INFO - 2020-09-22 07:46:41 --> Router Class Initialized
INFO - 2020-09-22 07:46:41 --> Output Class Initialized
INFO - 2020-09-22 07:46:41 --> Security Class Initialized
DEBUG - 2020-09-22 07:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:46:41 --> Input Class Initialized
INFO - 2020-09-22 07:46:41 --> Language Class Initialized
INFO - 2020-09-22 07:46:41 --> Loader Class Initialized
INFO - 2020-09-22 07:46:41 --> Helper loaded: url_helper
INFO - 2020-09-22 07:46:41 --> Database Driver Class Initialized
INFO - 2020-09-22 07:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:46:41 --> Email Class Initialized
INFO - 2020-09-22 07:46:41 --> Controller Class Initialized
DEBUG - 2020-09-22 07:46:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:46:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:46:41 --> Model Class Initialized
INFO - 2020-09-22 07:46:41 --> Model Class Initialized
INFO - 2020-09-22 07:46:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 07:46:41 --> Final output sent to browser
DEBUG - 2020-09-22 07:46:41 --> Total execution time: 0.0307
ERROR - 2020-09-22 07:47:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:47:26 --> Config Class Initialized
INFO - 2020-09-22 07:47:26 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:47:26 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:47:26 --> Utf8 Class Initialized
INFO - 2020-09-22 07:47:26 --> URI Class Initialized
INFO - 2020-09-22 07:47:26 --> Router Class Initialized
INFO - 2020-09-22 07:47:26 --> Output Class Initialized
INFO - 2020-09-22 07:47:26 --> Security Class Initialized
DEBUG - 2020-09-22 07:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:47:26 --> Input Class Initialized
INFO - 2020-09-22 07:47:26 --> Language Class Initialized
INFO - 2020-09-22 07:47:26 --> Loader Class Initialized
INFO - 2020-09-22 07:47:26 --> Helper loaded: url_helper
INFO - 2020-09-22 07:47:26 --> Database Driver Class Initialized
INFO - 2020-09-22 07:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:47:26 --> Email Class Initialized
INFO - 2020-09-22 07:47:26 --> Controller Class Initialized
DEBUG - 2020-09-22 07:47:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:47:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:47:26 --> Model Class Initialized
INFO - 2020-09-22 07:47:26 --> Model Class Initialized
INFO - 2020-09-22 07:47:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 07:47:26 --> Final output sent to browser
DEBUG - 2020-09-22 07:47:26 --> Total execution time: 0.0200
ERROR - 2020-09-22 07:47:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:47:27 --> Config Class Initialized
INFO - 2020-09-22 07:47:27 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:47:27 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:47:27 --> Utf8 Class Initialized
INFO - 2020-09-22 07:47:27 --> URI Class Initialized
INFO - 2020-09-22 07:47:27 --> Router Class Initialized
INFO - 2020-09-22 07:47:27 --> Output Class Initialized
INFO - 2020-09-22 07:47:27 --> Security Class Initialized
DEBUG - 2020-09-22 07:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:47:27 --> Input Class Initialized
INFO - 2020-09-22 07:47:27 --> Language Class Initialized
INFO - 2020-09-22 07:47:27 --> Loader Class Initialized
INFO - 2020-09-22 07:47:27 --> Helper loaded: url_helper
INFO - 2020-09-22 07:47:27 --> Database Driver Class Initialized
INFO - 2020-09-22 07:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:47:27 --> Email Class Initialized
INFO - 2020-09-22 07:47:27 --> Controller Class Initialized
DEBUG - 2020-09-22 07:47:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:47:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:47:27 --> Model Class Initialized
INFO - 2020-09-22 07:47:27 --> Model Class Initialized
INFO - 2020-09-22 07:47:27 --> Final output sent to browser
DEBUG - 2020-09-22 07:47:27 --> Total execution time: 0.0227
ERROR - 2020-09-22 07:47:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:47:29 --> Config Class Initialized
INFO - 2020-09-22 07:47:29 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:47:29 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:47:29 --> Utf8 Class Initialized
INFO - 2020-09-22 07:47:29 --> URI Class Initialized
INFO - 2020-09-22 07:47:29 --> Router Class Initialized
INFO - 2020-09-22 07:47:29 --> Output Class Initialized
INFO - 2020-09-22 07:47:29 --> Security Class Initialized
DEBUG - 2020-09-22 07:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:47:29 --> Input Class Initialized
INFO - 2020-09-22 07:47:29 --> Language Class Initialized
INFO - 2020-09-22 07:47:29 --> Loader Class Initialized
INFO - 2020-09-22 07:47:29 --> Helper loaded: url_helper
INFO - 2020-09-22 07:47:29 --> Database Driver Class Initialized
INFO - 2020-09-22 07:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:47:29 --> Email Class Initialized
INFO - 2020-09-22 07:47:29 --> Controller Class Initialized
DEBUG - 2020-09-22 07:47:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:47:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:47:29 --> Model Class Initialized
INFO - 2020-09-22 07:47:29 --> Model Class Initialized
INFO - 2020-09-22 07:47:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 07:47:29 --> Final output sent to browser
DEBUG - 2020-09-22 07:47:29 --> Total execution time: 0.0257
ERROR - 2020-09-22 07:48:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:48:12 --> Config Class Initialized
INFO - 2020-09-22 07:48:12 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:48:12 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:48:12 --> Utf8 Class Initialized
INFO - 2020-09-22 07:48:12 --> URI Class Initialized
INFO - 2020-09-22 07:48:12 --> Router Class Initialized
INFO - 2020-09-22 07:48:12 --> Output Class Initialized
INFO - 2020-09-22 07:48:12 --> Security Class Initialized
DEBUG - 2020-09-22 07:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:48:12 --> Input Class Initialized
INFO - 2020-09-22 07:48:12 --> Language Class Initialized
INFO - 2020-09-22 07:48:12 --> Loader Class Initialized
INFO - 2020-09-22 07:48:12 --> Helper loaded: url_helper
INFO - 2020-09-22 07:48:12 --> Database Driver Class Initialized
INFO - 2020-09-22 07:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:48:12 --> Email Class Initialized
INFO - 2020-09-22 07:48:12 --> Controller Class Initialized
DEBUG - 2020-09-22 07:48:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:48:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:48:12 --> Model Class Initialized
INFO - 2020-09-22 07:48:12 --> Model Class Initialized
INFO - 2020-09-22 07:48:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 07:48:12 --> Final output sent to browser
DEBUG - 2020-09-22 07:48:12 --> Total execution time: 0.2658
ERROR - 2020-09-22 07:48:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:48:13 --> Config Class Initialized
INFO - 2020-09-22 07:48:13 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:48:13 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:48:13 --> Utf8 Class Initialized
INFO - 2020-09-22 07:48:13 --> URI Class Initialized
INFO - 2020-09-22 07:48:13 --> Router Class Initialized
INFO - 2020-09-22 07:48:13 --> Output Class Initialized
INFO - 2020-09-22 07:48:13 --> Security Class Initialized
DEBUG - 2020-09-22 07:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:48:13 --> Input Class Initialized
INFO - 2020-09-22 07:48:13 --> Language Class Initialized
INFO - 2020-09-22 07:48:13 --> Loader Class Initialized
INFO - 2020-09-22 07:48:13 --> Helper loaded: url_helper
INFO - 2020-09-22 07:48:13 --> Database Driver Class Initialized
INFO - 2020-09-22 07:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:48:13 --> Email Class Initialized
INFO - 2020-09-22 07:48:13 --> Controller Class Initialized
DEBUG - 2020-09-22 07:48:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:48:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:48:13 --> Model Class Initialized
INFO - 2020-09-22 07:48:13 --> Model Class Initialized
INFO - 2020-09-22 07:48:13 --> Final output sent to browser
DEBUG - 2020-09-22 07:48:13 --> Total execution time: 0.0393
ERROR - 2020-09-22 07:48:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:48:22 --> Config Class Initialized
INFO - 2020-09-22 07:48:22 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:48:22 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:48:22 --> Utf8 Class Initialized
INFO - 2020-09-22 07:48:22 --> URI Class Initialized
INFO - 2020-09-22 07:48:22 --> Router Class Initialized
INFO - 2020-09-22 07:48:22 --> Output Class Initialized
INFO - 2020-09-22 07:48:22 --> Security Class Initialized
DEBUG - 2020-09-22 07:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:48:22 --> Input Class Initialized
INFO - 2020-09-22 07:48:22 --> Language Class Initialized
INFO - 2020-09-22 07:48:22 --> Loader Class Initialized
INFO - 2020-09-22 07:48:22 --> Helper loaded: url_helper
INFO - 2020-09-22 07:48:22 --> Database Driver Class Initialized
INFO - 2020-09-22 07:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:48:22 --> Email Class Initialized
INFO - 2020-09-22 07:48:22 --> Controller Class Initialized
DEBUG - 2020-09-22 07:48:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:48:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:48:22 --> Model Class Initialized
INFO - 2020-09-22 07:48:22 --> Model Class Initialized
INFO - 2020-09-22 07:48:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 07:48:22 --> Final output sent to browser
DEBUG - 2020-09-22 07:48:22 --> Total execution time: 0.0300
ERROR - 2020-09-22 07:48:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:48:22 --> Config Class Initialized
INFO - 2020-09-22 07:48:22 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:48:22 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:48:22 --> Utf8 Class Initialized
INFO - 2020-09-22 07:48:22 --> URI Class Initialized
INFO - 2020-09-22 07:48:22 --> Router Class Initialized
INFO - 2020-09-22 07:48:22 --> Output Class Initialized
INFO - 2020-09-22 07:48:22 --> Security Class Initialized
DEBUG - 2020-09-22 07:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:48:22 --> Input Class Initialized
INFO - 2020-09-22 07:48:22 --> Language Class Initialized
INFO - 2020-09-22 07:48:22 --> Loader Class Initialized
INFO - 2020-09-22 07:48:22 --> Helper loaded: url_helper
INFO - 2020-09-22 07:48:22 --> Database Driver Class Initialized
INFO - 2020-09-22 07:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:48:22 --> Email Class Initialized
INFO - 2020-09-22 07:48:22 --> Controller Class Initialized
DEBUG - 2020-09-22 07:48:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:48:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:48:22 --> Model Class Initialized
INFO - 2020-09-22 07:48:22 --> Model Class Initialized
INFO - 2020-09-22 07:48:22 --> Final output sent to browser
DEBUG - 2020-09-22 07:48:22 --> Total execution time: 0.0263
ERROR - 2020-09-22 07:50:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:50:37 --> Config Class Initialized
INFO - 2020-09-22 07:50:37 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:50:37 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:50:37 --> Utf8 Class Initialized
INFO - 2020-09-22 07:50:37 --> URI Class Initialized
INFO - 2020-09-22 07:50:37 --> Router Class Initialized
INFO - 2020-09-22 07:50:37 --> Output Class Initialized
INFO - 2020-09-22 07:50:37 --> Security Class Initialized
DEBUG - 2020-09-22 07:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:50:37 --> Input Class Initialized
INFO - 2020-09-22 07:50:37 --> Language Class Initialized
INFO - 2020-09-22 07:50:37 --> Loader Class Initialized
INFO - 2020-09-22 07:50:37 --> Helper loaded: url_helper
INFO - 2020-09-22 07:50:37 --> Database Driver Class Initialized
INFO - 2020-09-22 07:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:50:37 --> Email Class Initialized
INFO - 2020-09-22 07:50:37 --> Controller Class Initialized
DEBUG - 2020-09-22 07:50:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:50:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:50:37 --> Model Class Initialized
INFO - 2020-09-22 07:50:37 --> Model Class Initialized
INFO - 2020-09-22 07:50:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 07:50:37 --> Final output sent to browser
DEBUG - 2020-09-22 07:50:37 --> Total execution time: 0.0198
ERROR - 2020-09-22 07:50:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:50:38 --> Config Class Initialized
INFO - 2020-09-22 07:50:38 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:50:38 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:50:38 --> Utf8 Class Initialized
INFO - 2020-09-22 07:50:38 --> URI Class Initialized
INFO - 2020-09-22 07:50:38 --> Router Class Initialized
INFO - 2020-09-22 07:50:38 --> Output Class Initialized
INFO - 2020-09-22 07:50:38 --> Security Class Initialized
DEBUG - 2020-09-22 07:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:50:38 --> Input Class Initialized
INFO - 2020-09-22 07:50:38 --> Language Class Initialized
INFO - 2020-09-22 07:50:38 --> Loader Class Initialized
INFO - 2020-09-22 07:50:38 --> Helper loaded: url_helper
INFO - 2020-09-22 07:50:38 --> Database Driver Class Initialized
INFO - 2020-09-22 07:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:50:38 --> Email Class Initialized
INFO - 2020-09-22 07:50:38 --> Controller Class Initialized
DEBUG - 2020-09-22 07:50:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:50:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:50:38 --> Model Class Initialized
INFO - 2020-09-22 07:50:38 --> Model Class Initialized
INFO - 2020-09-22 07:50:38 --> Final output sent to browser
DEBUG - 2020-09-22 07:50:38 --> Total execution time: 0.0260
ERROR - 2020-09-22 07:51:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:51:57 --> Config Class Initialized
INFO - 2020-09-22 07:51:57 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:51:57 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:51:57 --> Utf8 Class Initialized
INFO - 2020-09-22 07:51:57 --> URI Class Initialized
INFO - 2020-09-22 07:51:57 --> Router Class Initialized
INFO - 2020-09-22 07:51:57 --> Output Class Initialized
INFO - 2020-09-22 07:51:57 --> Security Class Initialized
DEBUG - 2020-09-22 07:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:51:57 --> Input Class Initialized
INFO - 2020-09-22 07:51:57 --> Language Class Initialized
INFO - 2020-09-22 07:51:57 --> Loader Class Initialized
INFO - 2020-09-22 07:51:57 --> Helper loaded: url_helper
INFO - 2020-09-22 07:51:57 --> Database Driver Class Initialized
INFO - 2020-09-22 07:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:51:57 --> Email Class Initialized
INFO - 2020-09-22 07:51:57 --> Controller Class Initialized
DEBUG - 2020-09-22 07:51:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:51:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:51:57 --> Model Class Initialized
INFO - 2020-09-22 07:51:57 --> Model Class Initialized
INFO - 2020-09-22 07:51:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 07:51:57 --> Final output sent to browser
DEBUG - 2020-09-22 07:51:57 --> Total execution time: 0.0269
ERROR - 2020-09-22 07:51:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:51:57 --> Config Class Initialized
INFO - 2020-09-22 07:51:57 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:51:57 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:51:57 --> Utf8 Class Initialized
INFO - 2020-09-22 07:51:57 --> URI Class Initialized
INFO - 2020-09-22 07:51:57 --> Router Class Initialized
INFO - 2020-09-22 07:51:57 --> Output Class Initialized
INFO - 2020-09-22 07:51:57 --> Security Class Initialized
DEBUG - 2020-09-22 07:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:51:57 --> Input Class Initialized
INFO - 2020-09-22 07:51:57 --> Language Class Initialized
INFO - 2020-09-22 07:51:57 --> Loader Class Initialized
INFO - 2020-09-22 07:51:57 --> Helper loaded: url_helper
INFO - 2020-09-22 07:51:57 --> Database Driver Class Initialized
INFO - 2020-09-22 07:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:51:57 --> Email Class Initialized
INFO - 2020-09-22 07:51:57 --> Controller Class Initialized
DEBUG - 2020-09-22 07:51:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:51:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:51:57 --> Model Class Initialized
INFO - 2020-09-22 07:51:57 --> Model Class Initialized
INFO - 2020-09-22 07:51:57 --> Final output sent to browser
DEBUG - 2020-09-22 07:51:57 --> Total execution time: 0.0255
ERROR - 2020-09-22 07:52:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:52:18 --> Config Class Initialized
INFO - 2020-09-22 07:52:18 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:52:18 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:52:18 --> Utf8 Class Initialized
INFO - 2020-09-22 07:52:18 --> URI Class Initialized
INFO - 2020-09-22 07:52:18 --> Router Class Initialized
INFO - 2020-09-22 07:52:18 --> Output Class Initialized
INFO - 2020-09-22 07:52:18 --> Security Class Initialized
DEBUG - 2020-09-22 07:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:52:18 --> Input Class Initialized
INFO - 2020-09-22 07:52:18 --> Language Class Initialized
INFO - 2020-09-22 07:52:18 --> Loader Class Initialized
INFO - 2020-09-22 07:52:18 --> Helper loaded: url_helper
INFO - 2020-09-22 07:52:18 --> Database Driver Class Initialized
INFO - 2020-09-22 07:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:52:18 --> Email Class Initialized
INFO - 2020-09-22 07:52:18 --> Controller Class Initialized
DEBUG - 2020-09-22 07:52:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:52:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:52:18 --> Model Class Initialized
INFO - 2020-09-22 07:52:18 --> Model Class Initialized
INFO - 2020-09-22 07:52:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 07:52:18 --> Final output sent to browser
DEBUG - 2020-09-22 07:52:18 --> Total execution time: 0.0277
ERROR - 2020-09-22 07:52:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 07:52:19 --> Config Class Initialized
INFO - 2020-09-22 07:52:19 --> Hooks Class Initialized
DEBUG - 2020-09-22 07:52:19 --> UTF-8 Support Enabled
INFO - 2020-09-22 07:52:19 --> Utf8 Class Initialized
INFO - 2020-09-22 07:52:19 --> URI Class Initialized
INFO - 2020-09-22 07:52:19 --> Router Class Initialized
INFO - 2020-09-22 07:52:19 --> Output Class Initialized
INFO - 2020-09-22 07:52:19 --> Security Class Initialized
DEBUG - 2020-09-22 07:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 07:52:19 --> Input Class Initialized
INFO - 2020-09-22 07:52:19 --> Language Class Initialized
INFO - 2020-09-22 07:52:19 --> Loader Class Initialized
INFO - 2020-09-22 07:52:19 --> Helper loaded: url_helper
INFO - 2020-09-22 07:52:19 --> Database Driver Class Initialized
INFO - 2020-09-22 07:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 07:52:19 --> Email Class Initialized
INFO - 2020-09-22 07:52:19 --> Controller Class Initialized
DEBUG - 2020-09-22 07:52:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 07:52:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 07:52:19 --> Model Class Initialized
INFO - 2020-09-22 07:52:19 --> Model Class Initialized
INFO - 2020-09-22 07:52:19 --> Final output sent to browser
DEBUG - 2020-09-22 07:52:19 --> Total execution time: 0.0246
ERROR - 2020-09-22 08:09:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:09:11 --> Config Class Initialized
INFO - 2020-09-22 08:09:11 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:09:11 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:09:11 --> Utf8 Class Initialized
INFO - 2020-09-22 08:09:11 --> URI Class Initialized
INFO - 2020-09-22 08:09:11 --> Router Class Initialized
INFO - 2020-09-22 08:09:11 --> Output Class Initialized
INFO - 2020-09-22 08:09:11 --> Security Class Initialized
DEBUG - 2020-09-22 08:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:09:11 --> Input Class Initialized
INFO - 2020-09-22 08:09:11 --> Language Class Initialized
INFO - 2020-09-22 08:09:11 --> Loader Class Initialized
INFO - 2020-09-22 08:09:11 --> Helper loaded: url_helper
INFO - 2020-09-22 08:09:11 --> Database Driver Class Initialized
INFO - 2020-09-22 08:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:09:11 --> Email Class Initialized
INFO - 2020-09-22 08:09:11 --> Controller Class Initialized
DEBUG - 2020-09-22 08:09:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:09:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:09:11 --> Model Class Initialized
INFO - 2020-09-22 08:09:11 --> Model Class Initialized
INFO - 2020-09-22 08:09:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 08:09:11 --> Final output sent to browser
DEBUG - 2020-09-22 08:09:11 --> Total execution time: 0.0232
ERROR - 2020-09-22 08:09:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:09:12 --> Config Class Initialized
INFO - 2020-09-22 08:09:12 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:09:12 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:09:12 --> Utf8 Class Initialized
INFO - 2020-09-22 08:09:12 --> URI Class Initialized
INFO - 2020-09-22 08:09:12 --> Router Class Initialized
INFO - 2020-09-22 08:09:12 --> Output Class Initialized
INFO - 2020-09-22 08:09:12 --> Security Class Initialized
DEBUG - 2020-09-22 08:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:09:12 --> Input Class Initialized
INFO - 2020-09-22 08:09:12 --> Language Class Initialized
INFO - 2020-09-22 08:09:12 --> Loader Class Initialized
INFO - 2020-09-22 08:09:12 --> Helper loaded: url_helper
INFO - 2020-09-22 08:09:12 --> Database Driver Class Initialized
INFO - 2020-09-22 08:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:09:12 --> Email Class Initialized
INFO - 2020-09-22 08:09:12 --> Controller Class Initialized
DEBUG - 2020-09-22 08:09:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:09:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:09:12 --> Model Class Initialized
INFO - 2020-09-22 08:09:12 --> Model Class Initialized
INFO - 2020-09-22 08:09:12 --> Final output sent to browser
DEBUG - 2020-09-22 08:09:12 --> Total execution time: 0.0210
ERROR - 2020-09-22 08:09:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:09:48 --> Config Class Initialized
INFO - 2020-09-22 08:09:48 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:09:48 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:09:48 --> Utf8 Class Initialized
INFO - 2020-09-22 08:09:48 --> URI Class Initialized
INFO - 2020-09-22 08:09:48 --> Router Class Initialized
INFO - 2020-09-22 08:09:48 --> Output Class Initialized
INFO - 2020-09-22 08:09:48 --> Security Class Initialized
DEBUG - 2020-09-22 08:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:09:48 --> Input Class Initialized
INFO - 2020-09-22 08:09:48 --> Language Class Initialized
INFO - 2020-09-22 08:09:48 --> Loader Class Initialized
INFO - 2020-09-22 08:09:48 --> Helper loaded: url_helper
INFO - 2020-09-22 08:09:48 --> Database Driver Class Initialized
INFO - 2020-09-22 08:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:09:48 --> Email Class Initialized
INFO - 2020-09-22 08:09:48 --> Controller Class Initialized
DEBUG - 2020-09-22 08:09:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:09:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:09:48 --> Model Class Initialized
INFO - 2020-09-22 08:09:48 --> Model Class Initialized
INFO - 2020-09-22 08:09:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 08:09:48 --> Final output sent to browser
DEBUG - 2020-09-22 08:09:48 --> Total execution time: 0.0323
ERROR - 2020-09-22 08:09:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:09:57 --> Config Class Initialized
INFO - 2020-09-22 08:09:57 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:09:57 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:09:57 --> Utf8 Class Initialized
INFO - 2020-09-22 08:09:57 --> URI Class Initialized
INFO - 2020-09-22 08:09:57 --> Router Class Initialized
INFO - 2020-09-22 08:09:57 --> Output Class Initialized
INFO - 2020-09-22 08:09:57 --> Security Class Initialized
DEBUG - 2020-09-22 08:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:09:57 --> Input Class Initialized
INFO - 2020-09-22 08:09:57 --> Language Class Initialized
INFO - 2020-09-22 08:09:57 --> Loader Class Initialized
INFO - 2020-09-22 08:09:57 --> Helper loaded: url_helper
INFO - 2020-09-22 08:09:57 --> Database Driver Class Initialized
INFO - 2020-09-22 08:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:09:57 --> Email Class Initialized
INFO - 2020-09-22 08:09:57 --> Controller Class Initialized
DEBUG - 2020-09-22 08:09:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:09:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:09:57 --> Model Class Initialized
INFO - 2020-09-22 08:09:57 --> Model Class Initialized
INFO - 2020-09-22 08:09:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 08:09:57 --> Final output sent to browser
DEBUG - 2020-09-22 08:09:57 --> Total execution time: 0.0300
ERROR - 2020-09-22 08:09:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:09:58 --> Config Class Initialized
INFO - 2020-09-22 08:09:58 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:09:58 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:09:58 --> Utf8 Class Initialized
INFO - 2020-09-22 08:09:58 --> URI Class Initialized
INFO - 2020-09-22 08:09:58 --> Router Class Initialized
INFO - 2020-09-22 08:09:58 --> Output Class Initialized
INFO - 2020-09-22 08:09:58 --> Security Class Initialized
DEBUG - 2020-09-22 08:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:09:58 --> Input Class Initialized
INFO - 2020-09-22 08:09:58 --> Language Class Initialized
INFO - 2020-09-22 08:09:58 --> Loader Class Initialized
INFO - 2020-09-22 08:09:58 --> Helper loaded: url_helper
INFO - 2020-09-22 08:09:58 --> Database Driver Class Initialized
INFO - 2020-09-22 08:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:09:58 --> Email Class Initialized
INFO - 2020-09-22 08:09:58 --> Controller Class Initialized
DEBUG - 2020-09-22 08:09:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:09:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:09:58 --> Model Class Initialized
INFO - 2020-09-22 08:09:58 --> Model Class Initialized
INFO - 2020-09-22 08:09:58 --> Final output sent to browser
DEBUG - 2020-09-22 08:09:58 --> Total execution time: 0.0221
ERROR - 2020-09-22 08:10:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:10:02 --> Config Class Initialized
INFO - 2020-09-22 08:10:02 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:10:02 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:10:02 --> Utf8 Class Initialized
INFO - 2020-09-22 08:10:02 --> URI Class Initialized
INFO - 2020-09-22 08:10:02 --> Router Class Initialized
INFO - 2020-09-22 08:10:02 --> Output Class Initialized
INFO - 2020-09-22 08:10:02 --> Security Class Initialized
DEBUG - 2020-09-22 08:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:10:02 --> Input Class Initialized
INFO - 2020-09-22 08:10:02 --> Language Class Initialized
INFO - 2020-09-22 08:10:02 --> Loader Class Initialized
INFO - 2020-09-22 08:10:02 --> Helper loaded: url_helper
INFO - 2020-09-22 08:10:02 --> Database Driver Class Initialized
INFO - 2020-09-22 08:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:10:02 --> Email Class Initialized
INFO - 2020-09-22 08:10:02 --> Controller Class Initialized
DEBUG - 2020-09-22 08:10:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:10:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:10:02 --> Model Class Initialized
INFO - 2020-09-22 08:10:02 --> Model Class Initialized
INFO - 2020-09-22 08:10:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 08:10:02 --> Final output sent to browser
DEBUG - 2020-09-22 08:10:02 --> Total execution time: 0.0321
ERROR - 2020-09-22 08:10:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:10:33 --> Config Class Initialized
INFO - 2020-09-22 08:10:33 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:10:33 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:10:33 --> Utf8 Class Initialized
INFO - 2020-09-22 08:10:33 --> URI Class Initialized
INFO - 2020-09-22 08:10:33 --> Router Class Initialized
INFO - 2020-09-22 08:10:33 --> Output Class Initialized
INFO - 2020-09-22 08:10:33 --> Security Class Initialized
DEBUG - 2020-09-22 08:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:10:33 --> Input Class Initialized
INFO - 2020-09-22 08:10:33 --> Language Class Initialized
INFO - 2020-09-22 08:10:33 --> Loader Class Initialized
INFO - 2020-09-22 08:10:33 --> Helper loaded: url_helper
INFO - 2020-09-22 08:10:33 --> Database Driver Class Initialized
INFO - 2020-09-22 08:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:10:33 --> Email Class Initialized
INFO - 2020-09-22 08:10:33 --> Controller Class Initialized
DEBUG - 2020-09-22 08:10:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:10:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:10:33 --> Model Class Initialized
INFO - 2020-09-22 08:10:33 --> Model Class Initialized
INFO - 2020-09-22 08:10:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 08:10:33 --> Final output sent to browser
DEBUG - 2020-09-22 08:10:33 --> Total execution time: 0.0254
ERROR - 2020-09-22 08:10:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:10:34 --> Config Class Initialized
INFO - 2020-09-22 08:10:34 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:10:34 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:10:34 --> Utf8 Class Initialized
INFO - 2020-09-22 08:10:34 --> URI Class Initialized
INFO - 2020-09-22 08:10:34 --> Router Class Initialized
INFO - 2020-09-22 08:10:34 --> Output Class Initialized
INFO - 2020-09-22 08:10:34 --> Security Class Initialized
DEBUG - 2020-09-22 08:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:10:34 --> Input Class Initialized
INFO - 2020-09-22 08:10:34 --> Language Class Initialized
INFO - 2020-09-22 08:10:34 --> Loader Class Initialized
INFO - 2020-09-22 08:10:34 --> Helper loaded: url_helper
INFO - 2020-09-22 08:10:34 --> Database Driver Class Initialized
INFO - 2020-09-22 08:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:10:34 --> Email Class Initialized
INFO - 2020-09-22 08:10:34 --> Controller Class Initialized
DEBUG - 2020-09-22 08:10:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:10:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:10:34 --> Model Class Initialized
INFO - 2020-09-22 08:10:34 --> Model Class Initialized
INFO - 2020-09-22 08:10:34 --> Final output sent to browser
DEBUG - 2020-09-22 08:10:34 --> Total execution time: 0.0321
ERROR - 2020-09-22 08:12:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:12:00 --> Config Class Initialized
INFO - 2020-09-22 08:12:00 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:12:00 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:12:00 --> Utf8 Class Initialized
INFO - 2020-09-22 08:12:00 --> URI Class Initialized
INFO - 2020-09-22 08:12:00 --> Router Class Initialized
INFO - 2020-09-22 08:12:00 --> Output Class Initialized
INFO - 2020-09-22 08:12:00 --> Security Class Initialized
DEBUG - 2020-09-22 08:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:12:00 --> Input Class Initialized
INFO - 2020-09-22 08:12:00 --> Language Class Initialized
INFO - 2020-09-22 08:12:00 --> Loader Class Initialized
INFO - 2020-09-22 08:12:00 --> Helper loaded: url_helper
INFO - 2020-09-22 08:12:00 --> Database Driver Class Initialized
INFO - 2020-09-22 08:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:12:00 --> Email Class Initialized
INFO - 2020-09-22 08:12:00 --> Controller Class Initialized
DEBUG - 2020-09-22 08:12:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:12:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:12:00 --> Model Class Initialized
INFO - 2020-09-22 08:12:00 --> Model Class Initialized
INFO - 2020-09-22 08:12:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 08:12:00 --> Final output sent to browser
DEBUG - 2020-09-22 08:12:00 --> Total execution time: 0.0385
ERROR - 2020-09-22 08:12:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:12:01 --> Config Class Initialized
INFO - 2020-09-22 08:12:01 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:12:01 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:12:01 --> Utf8 Class Initialized
INFO - 2020-09-22 08:12:01 --> URI Class Initialized
INFO - 2020-09-22 08:12:01 --> Router Class Initialized
INFO - 2020-09-22 08:12:01 --> Output Class Initialized
INFO - 2020-09-22 08:12:01 --> Security Class Initialized
DEBUG - 2020-09-22 08:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:12:01 --> Input Class Initialized
INFO - 2020-09-22 08:12:01 --> Language Class Initialized
INFO - 2020-09-22 08:12:01 --> Loader Class Initialized
INFO - 2020-09-22 08:12:01 --> Helper loaded: url_helper
INFO - 2020-09-22 08:12:01 --> Database Driver Class Initialized
INFO - 2020-09-22 08:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:12:01 --> Email Class Initialized
INFO - 2020-09-22 08:12:01 --> Controller Class Initialized
DEBUG - 2020-09-22 08:12:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:12:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:12:01 --> Model Class Initialized
INFO - 2020-09-22 08:12:01 --> Model Class Initialized
INFO - 2020-09-22 08:12:01 --> Final output sent to browser
DEBUG - 2020-09-22 08:12:01 --> Total execution time: 0.0346
ERROR - 2020-09-22 08:12:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:12:43 --> Config Class Initialized
INFO - 2020-09-22 08:12:43 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:12:43 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:12:43 --> Utf8 Class Initialized
INFO - 2020-09-22 08:12:43 --> URI Class Initialized
INFO - 2020-09-22 08:12:43 --> Router Class Initialized
INFO - 2020-09-22 08:12:43 --> Output Class Initialized
INFO - 2020-09-22 08:12:43 --> Security Class Initialized
DEBUG - 2020-09-22 08:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:12:43 --> Input Class Initialized
INFO - 2020-09-22 08:12:43 --> Language Class Initialized
INFO - 2020-09-22 08:12:43 --> Loader Class Initialized
INFO - 2020-09-22 08:12:43 --> Helper loaded: url_helper
INFO - 2020-09-22 08:12:43 --> Database Driver Class Initialized
INFO - 2020-09-22 08:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:12:43 --> Email Class Initialized
INFO - 2020-09-22 08:12:43 --> Controller Class Initialized
DEBUG - 2020-09-22 08:12:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:12:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:12:43 --> Model Class Initialized
INFO - 2020-09-22 08:12:43 --> Model Class Initialized
INFO - 2020-09-22 08:12:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 08:12:43 --> Final output sent to browser
DEBUG - 2020-09-22 08:12:43 --> Total execution time: 0.0275
ERROR - 2020-09-22 08:12:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:12:44 --> Config Class Initialized
INFO - 2020-09-22 08:12:44 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:12:44 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:12:44 --> Utf8 Class Initialized
INFO - 2020-09-22 08:12:44 --> URI Class Initialized
INFO - 2020-09-22 08:12:44 --> Router Class Initialized
INFO - 2020-09-22 08:12:44 --> Output Class Initialized
INFO - 2020-09-22 08:12:44 --> Security Class Initialized
DEBUG - 2020-09-22 08:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:12:44 --> Input Class Initialized
INFO - 2020-09-22 08:12:44 --> Language Class Initialized
INFO - 2020-09-22 08:12:44 --> Loader Class Initialized
INFO - 2020-09-22 08:12:44 --> Helper loaded: url_helper
INFO - 2020-09-22 08:12:44 --> Database Driver Class Initialized
INFO - 2020-09-22 08:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:12:44 --> Email Class Initialized
INFO - 2020-09-22 08:12:44 --> Controller Class Initialized
DEBUG - 2020-09-22 08:12:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:12:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:12:44 --> Model Class Initialized
INFO - 2020-09-22 08:12:44 --> Model Class Initialized
INFO - 2020-09-22 08:12:44 --> Final output sent to browser
DEBUG - 2020-09-22 08:12:44 --> Total execution time: 0.0234
ERROR - 2020-09-22 08:13:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:13:03 --> Config Class Initialized
INFO - 2020-09-22 08:13:03 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:13:03 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:13:03 --> Utf8 Class Initialized
INFO - 2020-09-22 08:13:03 --> URI Class Initialized
INFO - 2020-09-22 08:13:03 --> Router Class Initialized
INFO - 2020-09-22 08:13:03 --> Output Class Initialized
INFO - 2020-09-22 08:13:03 --> Security Class Initialized
DEBUG - 2020-09-22 08:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:13:03 --> Input Class Initialized
INFO - 2020-09-22 08:13:03 --> Language Class Initialized
INFO - 2020-09-22 08:13:03 --> Loader Class Initialized
INFO - 2020-09-22 08:13:03 --> Helper loaded: url_helper
INFO - 2020-09-22 08:13:03 --> Database Driver Class Initialized
INFO - 2020-09-22 08:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:13:03 --> Email Class Initialized
INFO - 2020-09-22 08:13:03 --> Controller Class Initialized
DEBUG - 2020-09-22 08:13:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:13:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:13:03 --> Model Class Initialized
INFO - 2020-09-22 08:13:03 --> Model Class Initialized
INFO - 2020-09-22 08:13:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 08:13:03 --> Final output sent to browser
DEBUG - 2020-09-22 08:13:03 --> Total execution time: 0.0285
ERROR - 2020-09-22 08:13:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:13:58 --> Config Class Initialized
INFO - 2020-09-22 08:13:58 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:13:58 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:13:58 --> Utf8 Class Initialized
INFO - 2020-09-22 08:13:58 --> URI Class Initialized
INFO - 2020-09-22 08:13:58 --> Router Class Initialized
INFO - 2020-09-22 08:13:58 --> Output Class Initialized
INFO - 2020-09-22 08:13:58 --> Security Class Initialized
DEBUG - 2020-09-22 08:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:13:58 --> Input Class Initialized
INFO - 2020-09-22 08:13:58 --> Language Class Initialized
INFO - 2020-09-22 08:13:59 --> Loader Class Initialized
INFO - 2020-09-22 08:13:59 --> Helper loaded: url_helper
INFO - 2020-09-22 08:13:59 --> Database Driver Class Initialized
INFO - 2020-09-22 08:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:13:59 --> Email Class Initialized
INFO - 2020-09-22 08:13:59 --> Controller Class Initialized
DEBUG - 2020-09-22 08:13:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:13:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:13:59 --> Model Class Initialized
INFO - 2020-09-22 08:13:59 --> Model Class Initialized
INFO - 2020-09-22 08:13:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 08:13:59 --> Final output sent to browser
DEBUG - 2020-09-22 08:13:59 --> Total execution time: 0.0226
ERROR - 2020-09-22 08:15:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:15:38 --> Config Class Initialized
INFO - 2020-09-22 08:15:38 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:15:38 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:15:38 --> Utf8 Class Initialized
INFO - 2020-09-22 08:15:38 --> URI Class Initialized
INFO - 2020-09-22 08:15:38 --> Router Class Initialized
INFO - 2020-09-22 08:15:38 --> Output Class Initialized
INFO - 2020-09-22 08:15:38 --> Security Class Initialized
DEBUG - 2020-09-22 08:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:15:38 --> Input Class Initialized
INFO - 2020-09-22 08:15:38 --> Language Class Initialized
INFO - 2020-09-22 08:15:38 --> Loader Class Initialized
INFO - 2020-09-22 08:15:38 --> Helper loaded: url_helper
INFO - 2020-09-22 08:15:38 --> Database Driver Class Initialized
INFO - 2020-09-22 08:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:15:38 --> Email Class Initialized
INFO - 2020-09-22 08:15:38 --> Controller Class Initialized
DEBUG - 2020-09-22 08:15:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:15:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:15:38 --> Model Class Initialized
INFO - 2020-09-22 08:15:38 --> Model Class Initialized
INFO - 2020-09-22 08:15:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 08:15:38 --> Final output sent to browser
DEBUG - 2020-09-22 08:15:38 --> Total execution time: 0.0259
ERROR - 2020-09-22 08:17:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:17:11 --> Config Class Initialized
INFO - 2020-09-22 08:17:11 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:17:11 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:17:11 --> Utf8 Class Initialized
INFO - 2020-09-22 08:17:11 --> URI Class Initialized
INFO - 2020-09-22 08:17:11 --> Router Class Initialized
INFO - 2020-09-22 08:17:11 --> Output Class Initialized
INFO - 2020-09-22 08:17:11 --> Security Class Initialized
DEBUG - 2020-09-22 08:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:17:11 --> Input Class Initialized
INFO - 2020-09-22 08:17:11 --> Language Class Initialized
INFO - 2020-09-22 08:17:11 --> Loader Class Initialized
INFO - 2020-09-22 08:17:11 --> Helper loaded: url_helper
INFO - 2020-09-22 08:17:11 --> Database Driver Class Initialized
INFO - 2020-09-22 08:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:17:11 --> Email Class Initialized
INFO - 2020-09-22 08:17:11 --> Controller Class Initialized
DEBUG - 2020-09-22 08:17:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:17:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:17:11 --> Model Class Initialized
INFO - 2020-09-22 08:17:11 --> Model Class Initialized
INFO - 2020-09-22 08:17:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 08:17:11 --> Final output sent to browser
DEBUG - 2020-09-22 08:17:11 --> Total execution time: 0.0273
ERROR - 2020-09-22 08:18:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:18:17 --> Config Class Initialized
INFO - 2020-09-22 08:18:17 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:18:17 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:18:17 --> Utf8 Class Initialized
INFO - 2020-09-22 08:18:17 --> URI Class Initialized
INFO - 2020-09-22 08:18:17 --> Router Class Initialized
INFO - 2020-09-22 08:18:17 --> Output Class Initialized
INFO - 2020-09-22 08:18:17 --> Security Class Initialized
DEBUG - 2020-09-22 08:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:18:17 --> Input Class Initialized
INFO - 2020-09-22 08:18:17 --> Language Class Initialized
INFO - 2020-09-22 08:18:17 --> Loader Class Initialized
INFO - 2020-09-22 08:18:17 --> Helper loaded: url_helper
INFO - 2020-09-22 08:18:17 --> Database Driver Class Initialized
INFO - 2020-09-22 08:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:18:17 --> Email Class Initialized
INFO - 2020-09-22 08:18:17 --> Controller Class Initialized
DEBUG - 2020-09-22 08:18:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:18:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:18:17 --> Model Class Initialized
INFO - 2020-09-22 08:18:17 --> Model Class Initialized
INFO - 2020-09-22 08:18:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 08:18:17 --> Final output sent to browser
DEBUG - 2020-09-22 08:18:17 --> Total execution time: 0.0270
ERROR - 2020-09-22 08:18:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:18:55 --> Config Class Initialized
INFO - 2020-09-22 08:18:55 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:18:55 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:18:55 --> Utf8 Class Initialized
INFO - 2020-09-22 08:18:55 --> URI Class Initialized
INFO - 2020-09-22 08:18:55 --> Router Class Initialized
INFO - 2020-09-22 08:18:55 --> Output Class Initialized
INFO - 2020-09-22 08:18:55 --> Security Class Initialized
DEBUG - 2020-09-22 08:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:18:55 --> Input Class Initialized
INFO - 2020-09-22 08:18:55 --> Language Class Initialized
INFO - 2020-09-22 08:18:55 --> Loader Class Initialized
INFO - 2020-09-22 08:18:55 --> Helper loaded: url_helper
INFO - 2020-09-22 08:18:55 --> Database Driver Class Initialized
INFO - 2020-09-22 08:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:18:55 --> Email Class Initialized
INFO - 2020-09-22 08:18:55 --> Controller Class Initialized
DEBUG - 2020-09-22 08:18:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:18:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:18:55 --> Model Class Initialized
INFO - 2020-09-22 08:18:55 --> Model Class Initialized
INFO - 2020-09-22 08:18:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 08:18:55 --> Final output sent to browser
DEBUG - 2020-09-22 08:18:55 --> Total execution time: 0.0215
ERROR - 2020-09-22 08:20:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:20:44 --> Config Class Initialized
INFO - 2020-09-22 08:20:44 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:20:44 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:20:44 --> Utf8 Class Initialized
INFO - 2020-09-22 08:20:44 --> URI Class Initialized
INFO - 2020-09-22 08:20:44 --> Router Class Initialized
INFO - 2020-09-22 08:20:44 --> Output Class Initialized
INFO - 2020-09-22 08:20:44 --> Security Class Initialized
DEBUG - 2020-09-22 08:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:20:44 --> Input Class Initialized
INFO - 2020-09-22 08:20:44 --> Language Class Initialized
INFO - 2020-09-22 08:20:44 --> Loader Class Initialized
INFO - 2020-09-22 08:20:44 --> Helper loaded: url_helper
INFO - 2020-09-22 08:20:44 --> Database Driver Class Initialized
INFO - 2020-09-22 08:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:20:44 --> Email Class Initialized
INFO - 2020-09-22 08:20:44 --> Controller Class Initialized
DEBUG - 2020-09-22 08:20:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:20:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:20:44 --> Model Class Initialized
INFO - 2020-09-22 08:20:44 --> Model Class Initialized
INFO - 2020-09-22 08:20:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 08:20:44 --> Final output sent to browser
DEBUG - 2020-09-22 08:20:44 --> Total execution time: 0.0258
ERROR - 2020-09-22 08:21:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:21:10 --> Config Class Initialized
INFO - 2020-09-22 08:21:10 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:21:10 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:21:10 --> Utf8 Class Initialized
INFO - 2020-09-22 08:21:10 --> URI Class Initialized
INFO - 2020-09-22 08:21:10 --> Router Class Initialized
INFO - 2020-09-22 08:21:10 --> Output Class Initialized
INFO - 2020-09-22 08:21:10 --> Security Class Initialized
DEBUG - 2020-09-22 08:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:21:10 --> Input Class Initialized
INFO - 2020-09-22 08:21:10 --> Language Class Initialized
INFO - 2020-09-22 08:21:10 --> Loader Class Initialized
INFO - 2020-09-22 08:21:10 --> Helper loaded: url_helper
INFO - 2020-09-22 08:21:10 --> Database Driver Class Initialized
INFO - 2020-09-22 08:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:21:10 --> Email Class Initialized
INFO - 2020-09-22 08:21:10 --> Controller Class Initialized
DEBUG - 2020-09-22 08:21:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:21:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:21:10 --> Model Class Initialized
INFO - 2020-09-22 08:21:10 --> Model Class Initialized
INFO - 2020-09-22 08:21:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 08:21:10 --> Final output sent to browser
DEBUG - 2020-09-22 08:21:10 --> Total execution time: 0.0301
ERROR - 2020-09-22 08:21:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:21:12 --> Config Class Initialized
INFO - 2020-09-22 08:21:12 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:21:12 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:21:12 --> Utf8 Class Initialized
INFO - 2020-09-22 08:21:12 --> URI Class Initialized
INFO - 2020-09-22 08:21:12 --> Router Class Initialized
INFO - 2020-09-22 08:21:12 --> Output Class Initialized
INFO - 2020-09-22 08:21:12 --> Security Class Initialized
DEBUG - 2020-09-22 08:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:21:12 --> Input Class Initialized
INFO - 2020-09-22 08:21:12 --> Language Class Initialized
INFO - 2020-09-22 08:21:12 --> Loader Class Initialized
INFO - 2020-09-22 08:21:12 --> Helper loaded: url_helper
INFO - 2020-09-22 08:21:12 --> Database Driver Class Initialized
INFO - 2020-09-22 08:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:21:12 --> Email Class Initialized
INFO - 2020-09-22 08:21:12 --> Controller Class Initialized
DEBUG - 2020-09-22 08:21:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:21:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:21:12 --> Model Class Initialized
INFO - 2020-09-22 08:21:12 --> Model Class Initialized
INFO - 2020-09-22 08:21:12 --> Final output sent to browser
DEBUG - 2020-09-22 08:21:12 --> Total execution time: 0.0235
ERROR - 2020-09-22 08:21:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:21:15 --> Config Class Initialized
INFO - 2020-09-22 08:21:15 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:21:15 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:21:15 --> Utf8 Class Initialized
INFO - 2020-09-22 08:21:15 --> URI Class Initialized
INFO - 2020-09-22 08:21:15 --> Router Class Initialized
INFO - 2020-09-22 08:21:15 --> Output Class Initialized
INFO - 2020-09-22 08:21:15 --> Security Class Initialized
DEBUG - 2020-09-22 08:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:21:15 --> Input Class Initialized
INFO - 2020-09-22 08:21:15 --> Language Class Initialized
INFO - 2020-09-22 08:21:15 --> Loader Class Initialized
INFO - 2020-09-22 08:21:15 --> Helper loaded: url_helper
INFO - 2020-09-22 08:21:15 --> Database Driver Class Initialized
INFO - 2020-09-22 08:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:21:15 --> Email Class Initialized
INFO - 2020-09-22 08:21:15 --> Controller Class Initialized
DEBUG - 2020-09-22 08:21:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:21:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:21:15 --> Model Class Initialized
INFO - 2020-09-22 08:21:15 --> Model Class Initialized
INFO - 2020-09-22 08:21:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 08:21:15 --> Final output sent to browser
DEBUG - 2020-09-22 08:21:15 --> Total execution time: 0.0215
ERROR - 2020-09-22 08:23:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:23:16 --> Config Class Initialized
INFO - 2020-09-22 08:23:16 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:23:16 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:23:16 --> Utf8 Class Initialized
INFO - 2020-09-22 08:23:16 --> URI Class Initialized
INFO - 2020-09-22 08:23:16 --> Router Class Initialized
INFO - 2020-09-22 08:23:16 --> Output Class Initialized
INFO - 2020-09-22 08:23:16 --> Security Class Initialized
DEBUG - 2020-09-22 08:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:23:16 --> Input Class Initialized
INFO - 2020-09-22 08:23:16 --> Language Class Initialized
INFO - 2020-09-22 08:23:16 --> Loader Class Initialized
INFO - 2020-09-22 08:23:16 --> Helper loaded: url_helper
INFO - 2020-09-22 08:23:16 --> Database Driver Class Initialized
INFO - 2020-09-22 08:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:23:16 --> Email Class Initialized
INFO - 2020-09-22 08:23:16 --> Controller Class Initialized
DEBUG - 2020-09-22 08:23:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:23:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:23:16 --> Model Class Initialized
INFO - 2020-09-22 08:23:16 --> Model Class Initialized
INFO - 2020-09-22 08:23:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 08:23:16 --> Final output sent to browser
DEBUG - 2020-09-22 08:23:16 --> Total execution time: 0.0263
ERROR - 2020-09-22 08:24:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:24:34 --> Config Class Initialized
INFO - 2020-09-22 08:24:34 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:24:34 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:24:34 --> Utf8 Class Initialized
INFO - 2020-09-22 08:24:34 --> URI Class Initialized
INFO - 2020-09-22 08:24:34 --> Router Class Initialized
INFO - 2020-09-22 08:24:34 --> Output Class Initialized
INFO - 2020-09-22 08:24:34 --> Security Class Initialized
DEBUG - 2020-09-22 08:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:24:34 --> Input Class Initialized
INFO - 2020-09-22 08:24:34 --> Language Class Initialized
INFO - 2020-09-22 08:24:34 --> Loader Class Initialized
INFO - 2020-09-22 08:24:34 --> Helper loaded: url_helper
INFO - 2020-09-22 08:24:34 --> Database Driver Class Initialized
INFO - 2020-09-22 08:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:24:34 --> Email Class Initialized
INFO - 2020-09-22 08:24:34 --> Controller Class Initialized
DEBUG - 2020-09-22 08:24:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:24:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:24:34 --> Model Class Initialized
INFO - 2020-09-22 08:24:34 --> Model Class Initialized
INFO - 2020-09-22 08:24:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 08:24:34 --> Final output sent to browser
DEBUG - 2020-09-22 08:24:34 --> Total execution time: 0.0273
ERROR - 2020-09-22 08:24:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:24:57 --> Config Class Initialized
INFO - 2020-09-22 08:24:57 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:24:57 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:24:57 --> Utf8 Class Initialized
INFO - 2020-09-22 08:24:57 --> URI Class Initialized
INFO - 2020-09-22 08:24:57 --> Router Class Initialized
INFO - 2020-09-22 08:24:57 --> Output Class Initialized
INFO - 2020-09-22 08:24:57 --> Security Class Initialized
DEBUG - 2020-09-22 08:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:24:57 --> Input Class Initialized
INFO - 2020-09-22 08:24:57 --> Language Class Initialized
INFO - 2020-09-22 08:24:57 --> Loader Class Initialized
INFO - 2020-09-22 08:24:57 --> Helper loaded: url_helper
INFO - 2020-09-22 08:24:57 --> Database Driver Class Initialized
INFO - 2020-09-22 08:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:24:57 --> Email Class Initialized
INFO - 2020-09-22 08:24:57 --> Controller Class Initialized
DEBUG - 2020-09-22 08:24:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:24:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:24:57 --> Model Class Initialized
INFO - 2020-09-22 08:24:57 --> Model Class Initialized
INFO - 2020-09-22 08:24:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 08:24:57 --> Final output sent to browser
DEBUG - 2020-09-22 08:24:57 --> Total execution time: 0.0254
ERROR - 2020-09-22 08:25:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:25:30 --> Config Class Initialized
INFO - 2020-09-22 08:25:30 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:25:30 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:25:30 --> Utf8 Class Initialized
INFO - 2020-09-22 08:25:30 --> URI Class Initialized
INFO - 2020-09-22 08:25:30 --> Router Class Initialized
INFO - 2020-09-22 08:25:30 --> Output Class Initialized
INFO - 2020-09-22 08:25:30 --> Security Class Initialized
DEBUG - 2020-09-22 08:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:25:30 --> Input Class Initialized
INFO - 2020-09-22 08:25:30 --> Language Class Initialized
INFO - 2020-09-22 08:25:30 --> Loader Class Initialized
INFO - 2020-09-22 08:25:30 --> Helper loaded: url_helper
INFO - 2020-09-22 08:25:30 --> Database Driver Class Initialized
INFO - 2020-09-22 08:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:25:30 --> Email Class Initialized
INFO - 2020-09-22 08:25:30 --> Controller Class Initialized
DEBUG - 2020-09-22 08:25:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:25:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:25:30 --> Model Class Initialized
INFO - 2020-09-22 08:25:30 --> Model Class Initialized
INFO - 2020-09-22 08:25:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 08:25:30 --> Final output sent to browser
DEBUG - 2020-09-22 08:25:30 --> Total execution time: 0.0358
ERROR - 2020-09-22 08:26:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:26:07 --> Config Class Initialized
INFO - 2020-09-22 08:26:07 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:26:07 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:26:07 --> Utf8 Class Initialized
INFO - 2020-09-22 08:26:07 --> URI Class Initialized
INFO - 2020-09-22 08:26:07 --> Router Class Initialized
INFO - 2020-09-22 08:26:07 --> Output Class Initialized
INFO - 2020-09-22 08:26:07 --> Security Class Initialized
DEBUG - 2020-09-22 08:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:26:07 --> Input Class Initialized
INFO - 2020-09-22 08:26:07 --> Language Class Initialized
INFO - 2020-09-22 08:26:07 --> Loader Class Initialized
INFO - 2020-09-22 08:26:07 --> Helper loaded: url_helper
INFO - 2020-09-22 08:26:07 --> Database Driver Class Initialized
INFO - 2020-09-22 08:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:26:07 --> Email Class Initialized
INFO - 2020-09-22 08:26:07 --> Controller Class Initialized
DEBUG - 2020-09-22 08:26:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:26:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:26:07 --> Model Class Initialized
INFO - 2020-09-22 08:26:07 --> Model Class Initialized
INFO - 2020-09-22 08:26:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 08:26:07 --> Final output sent to browser
DEBUG - 2020-09-22 08:26:07 --> Total execution time: 0.0213
ERROR - 2020-09-22 08:27:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:27:18 --> Config Class Initialized
INFO - 2020-09-22 08:27:18 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:27:18 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:27:18 --> Utf8 Class Initialized
INFO - 2020-09-22 08:27:18 --> URI Class Initialized
INFO - 2020-09-22 08:27:18 --> Router Class Initialized
INFO - 2020-09-22 08:27:18 --> Output Class Initialized
INFO - 2020-09-22 08:27:18 --> Security Class Initialized
DEBUG - 2020-09-22 08:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:27:18 --> Input Class Initialized
INFO - 2020-09-22 08:27:18 --> Language Class Initialized
INFO - 2020-09-22 08:27:18 --> Loader Class Initialized
INFO - 2020-09-22 08:27:18 --> Helper loaded: url_helper
INFO - 2020-09-22 08:27:18 --> Database Driver Class Initialized
INFO - 2020-09-22 08:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:27:18 --> Email Class Initialized
INFO - 2020-09-22 08:27:18 --> Controller Class Initialized
DEBUG - 2020-09-22 08:27:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:27:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:27:18 --> Model Class Initialized
INFO - 2020-09-22 08:27:18 --> Model Class Initialized
INFO - 2020-09-22 08:27:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 08:27:18 --> Final output sent to browser
DEBUG - 2020-09-22 08:27:18 --> Total execution time: 0.0241
ERROR - 2020-09-22 08:28:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:28:05 --> Config Class Initialized
INFO - 2020-09-22 08:28:05 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:28:05 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:28:05 --> Utf8 Class Initialized
INFO - 2020-09-22 08:28:05 --> URI Class Initialized
INFO - 2020-09-22 08:28:05 --> Router Class Initialized
INFO - 2020-09-22 08:28:05 --> Output Class Initialized
INFO - 2020-09-22 08:28:05 --> Security Class Initialized
DEBUG - 2020-09-22 08:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:28:05 --> Input Class Initialized
INFO - 2020-09-22 08:28:05 --> Language Class Initialized
INFO - 2020-09-22 08:28:05 --> Loader Class Initialized
INFO - 2020-09-22 08:28:05 --> Helper loaded: url_helper
INFO - 2020-09-22 08:28:05 --> Database Driver Class Initialized
INFO - 2020-09-22 08:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:28:05 --> Email Class Initialized
INFO - 2020-09-22 08:28:05 --> Controller Class Initialized
DEBUG - 2020-09-22 08:28:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:28:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:28:05 --> Model Class Initialized
INFO - 2020-09-22 08:28:05 --> Model Class Initialized
INFO - 2020-09-22 08:28:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 08:28:05 --> Final output sent to browser
DEBUG - 2020-09-22 08:28:05 --> Total execution time: 0.0255
ERROR - 2020-09-22 08:28:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:28:09 --> Config Class Initialized
INFO - 2020-09-22 08:28:09 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:28:09 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:28:09 --> Utf8 Class Initialized
INFO - 2020-09-22 08:28:09 --> URI Class Initialized
INFO - 2020-09-22 08:28:09 --> Router Class Initialized
INFO - 2020-09-22 08:28:09 --> Output Class Initialized
INFO - 2020-09-22 08:28:09 --> Security Class Initialized
DEBUG - 2020-09-22 08:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:28:09 --> Input Class Initialized
INFO - 2020-09-22 08:28:09 --> Language Class Initialized
INFO - 2020-09-22 08:28:09 --> Loader Class Initialized
INFO - 2020-09-22 08:28:09 --> Helper loaded: url_helper
INFO - 2020-09-22 08:28:09 --> Database Driver Class Initialized
INFO - 2020-09-22 08:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:28:09 --> Email Class Initialized
INFO - 2020-09-22 08:28:09 --> Controller Class Initialized
DEBUG - 2020-09-22 08:28:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:28:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:28:09 --> Model Class Initialized
INFO - 2020-09-22 08:28:09 --> Model Class Initialized
INFO - 2020-09-22 08:28:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 08:28:09 --> Final output sent to browser
DEBUG - 2020-09-22 08:28:09 --> Total execution time: 0.0255
ERROR - 2020-09-22 08:28:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:28:10 --> Config Class Initialized
INFO - 2020-09-22 08:28:10 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:28:10 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:28:10 --> Utf8 Class Initialized
INFO - 2020-09-22 08:28:10 --> URI Class Initialized
INFO - 2020-09-22 08:28:10 --> Router Class Initialized
INFO - 2020-09-22 08:28:10 --> Output Class Initialized
INFO - 2020-09-22 08:28:10 --> Security Class Initialized
DEBUG - 2020-09-22 08:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:28:10 --> Input Class Initialized
INFO - 2020-09-22 08:28:10 --> Language Class Initialized
INFO - 2020-09-22 08:28:10 --> Loader Class Initialized
INFO - 2020-09-22 08:28:10 --> Helper loaded: url_helper
INFO - 2020-09-22 08:28:10 --> Database Driver Class Initialized
INFO - 2020-09-22 08:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:28:10 --> Email Class Initialized
INFO - 2020-09-22 08:28:10 --> Controller Class Initialized
DEBUG - 2020-09-22 08:28:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:28:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:28:10 --> Model Class Initialized
INFO - 2020-09-22 08:28:10 --> Model Class Initialized
INFO - 2020-09-22 08:28:10 --> Final output sent to browser
DEBUG - 2020-09-22 08:28:10 --> Total execution time: 0.0243
ERROR - 2020-09-22 08:28:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:28:13 --> Config Class Initialized
INFO - 2020-09-22 08:28:13 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:28:13 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:28:13 --> Utf8 Class Initialized
INFO - 2020-09-22 08:28:13 --> URI Class Initialized
INFO - 2020-09-22 08:28:13 --> Router Class Initialized
INFO - 2020-09-22 08:28:13 --> Output Class Initialized
INFO - 2020-09-22 08:28:13 --> Security Class Initialized
DEBUG - 2020-09-22 08:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:28:13 --> Input Class Initialized
INFO - 2020-09-22 08:28:13 --> Language Class Initialized
INFO - 2020-09-22 08:28:13 --> Loader Class Initialized
INFO - 2020-09-22 08:28:13 --> Helper loaded: url_helper
INFO - 2020-09-22 08:28:13 --> Database Driver Class Initialized
INFO - 2020-09-22 08:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:28:13 --> Email Class Initialized
INFO - 2020-09-22 08:28:13 --> Controller Class Initialized
DEBUG - 2020-09-22 08:28:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:28:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:28:13 --> Model Class Initialized
INFO - 2020-09-22 08:28:13 --> Model Class Initialized
INFO - 2020-09-22 08:28:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 08:28:13 --> Final output sent to browser
DEBUG - 2020-09-22 08:28:13 --> Total execution time: 0.0256
ERROR - 2020-09-22 08:28:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:28:30 --> Config Class Initialized
INFO - 2020-09-22 08:28:30 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:28:30 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:28:30 --> Utf8 Class Initialized
INFO - 2020-09-22 08:28:30 --> URI Class Initialized
INFO - 2020-09-22 08:28:30 --> Router Class Initialized
INFO - 2020-09-22 08:28:30 --> Output Class Initialized
INFO - 2020-09-22 08:28:30 --> Security Class Initialized
DEBUG - 2020-09-22 08:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:28:30 --> Input Class Initialized
INFO - 2020-09-22 08:28:30 --> Language Class Initialized
INFO - 2020-09-22 08:28:30 --> Loader Class Initialized
INFO - 2020-09-22 08:28:30 --> Helper loaded: url_helper
INFO - 2020-09-22 08:28:30 --> Database Driver Class Initialized
INFO - 2020-09-22 08:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:28:30 --> Email Class Initialized
INFO - 2020-09-22 08:28:30 --> Controller Class Initialized
DEBUG - 2020-09-22 08:28:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:28:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:28:30 --> Model Class Initialized
INFO - 2020-09-22 08:28:30 --> Model Class Initialized
INFO - 2020-09-22 08:28:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-22 08:28:30 --> Final output sent to browser
DEBUG - 2020-09-22 08:28:30 --> Total execution time: 0.0216
ERROR - 2020-09-22 08:28:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:28:46 --> Config Class Initialized
INFO - 2020-09-22 08:28:46 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:28:46 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:28:46 --> Utf8 Class Initialized
INFO - 2020-09-22 08:28:46 --> URI Class Initialized
INFO - 2020-09-22 08:28:46 --> Router Class Initialized
INFO - 2020-09-22 08:28:46 --> Output Class Initialized
INFO - 2020-09-22 08:28:46 --> Security Class Initialized
DEBUG - 2020-09-22 08:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:28:46 --> Input Class Initialized
INFO - 2020-09-22 08:28:46 --> Language Class Initialized
INFO - 2020-09-22 08:28:46 --> Loader Class Initialized
INFO - 2020-09-22 08:28:46 --> Helper loaded: url_helper
INFO - 2020-09-22 08:28:46 --> Database Driver Class Initialized
INFO - 2020-09-22 08:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:28:46 --> Email Class Initialized
INFO - 2020-09-22 08:28:46 --> Controller Class Initialized
DEBUG - 2020-09-22 08:28:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:28:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:28:46 --> Model Class Initialized
INFO - 2020-09-22 08:28:46 --> Model Class Initialized
INFO - 2020-09-22 08:28:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 08:28:46 --> Final output sent to browser
DEBUG - 2020-09-22 08:28:46 --> Total execution time: 0.0256
ERROR - 2020-09-22 08:28:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:28:47 --> Config Class Initialized
INFO - 2020-09-22 08:28:47 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:28:47 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:28:47 --> Utf8 Class Initialized
INFO - 2020-09-22 08:28:47 --> URI Class Initialized
INFO - 2020-09-22 08:28:47 --> Router Class Initialized
INFO - 2020-09-22 08:28:47 --> Output Class Initialized
INFO - 2020-09-22 08:28:47 --> Security Class Initialized
DEBUG - 2020-09-22 08:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:28:47 --> Input Class Initialized
INFO - 2020-09-22 08:28:47 --> Language Class Initialized
INFO - 2020-09-22 08:28:47 --> Loader Class Initialized
INFO - 2020-09-22 08:28:47 --> Helper loaded: url_helper
INFO - 2020-09-22 08:28:47 --> Database Driver Class Initialized
INFO - 2020-09-22 08:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:28:47 --> Email Class Initialized
INFO - 2020-09-22 08:28:47 --> Controller Class Initialized
DEBUG - 2020-09-22 08:28:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:28:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:28:47 --> Model Class Initialized
INFO - 2020-09-22 08:28:47 --> Model Class Initialized
INFO - 2020-09-22 08:28:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-22 08:28:47 --> Final output sent to browser
DEBUG - 2020-09-22 08:28:47 --> Total execution time: 0.0216
ERROR - 2020-09-22 08:28:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:28:50 --> Config Class Initialized
INFO - 2020-09-22 08:28:50 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:28:50 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:28:50 --> Utf8 Class Initialized
INFO - 2020-09-22 08:28:50 --> URI Class Initialized
INFO - 2020-09-22 08:28:50 --> Router Class Initialized
INFO - 2020-09-22 08:28:50 --> Output Class Initialized
INFO - 2020-09-22 08:28:50 --> Security Class Initialized
DEBUG - 2020-09-22 08:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:28:50 --> Input Class Initialized
INFO - 2020-09-22 08:28:50 --> Language Class Initialized
INFO - 2020-09-22 08:28:50 --> Loader Class Initialized
INFO - 2020-09-22 08:28:50 --> Helper loaded: url_helper
INFO - 2020-09-22 08:28:50 --> Database Driver Class Initialized
INFO - 2020-09-22 08:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:28:50 --> Email Class Initialized
INFO - 2020-09-22 08:28:50 --> Controller Class Initialized
DEBUG - 2020-09-22 08:28:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:28:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:28:50 --> Model Class Initialized
INFO - 2020-09-22 08:28:50 --> Model Class Initialized
INFO - 2020-09-22 08:28:50 --> Final output sent to browser
DEBUG - 2020-09-22 08:28:50 --> Total execution time: 0.0244
ERROR - 2020-09-22 08:28:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:28:58 --> Config Class Initialized
INFO - 2020-09-22 08:28:58 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:28:58 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:28:58 --> Utf8 Class Initialized
INFO - 2020-09-22 08:28:58 --> URI Class Initialized
INFO - 2020-09-22 08:28:58 --> Router Class Initialized
INFO - 2020-09-22 08:28:58 --> Output Class Initialized
INFO - 2020-09-22 08:28:58 --> Security Class Initialized
DEBUG - 2020-09-22 08:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:28:58 --> Input Class Initialized
INFO - 2020-09-22 08:28:58 --> Language Class Initialized
INFO - 2020-09-22 08:28:58 --> Loader Class Initialized
INFO - 2020-09-22 08:28:58 --> Helper loaded: url_helper
INFO - 2020-09-22 08:28:58 --> Database Driver Class Initialized
INFO - 2020-09-22 08:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:28:58 --> Email Class Initialized
INFO - 2020-09-22 08:28:58 --> Controller Class Initialized
DEBUG - 2020-09-22 08:28:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:28:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:28:58 --> Model Class Initialized
INFO - 2020-09-22 08:28:58 --> Model Class Initialized
INFO - 2020-09-22 08:28:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 08:28:58 --> Final output sent to browser
DEBUG - 2020-09-22 08:28:58 --> Total execution time: 0.0264
ERROR - 2020-09-22 08:47:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:47:06 --> Config Class Initialized
INFO - 2020-09-22 08:47:06 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:47:06 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:47:06 --> Utf8 Class Initialized
INFO - 2020-09-22 08:47:06 --> URI Class Initialized
INFO - 2020-09-22 08:47:06 --> Router Class Initialized
INFO - 2020-09-22 08:47:06 --> Output Class Initialized
INFO - 2020-09-22 08:47:06 --> Security Class Initialized
DEBUG - 2020-09-22 08:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:47:06 --> Input Class Initialized
INFO - 2020-09-22 08:47:06 --> Language Class Initialized
INFO - 2020-09-22 08:47:06 --> Loader Class Initialized
INFO - 2020-09-22 08:47:06 --> Helper loaded: url_helper
INFO - 2020-09-22 08:47:06 --> Database Driver Class Initialized
INFO - 2020-09-22 08:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:47:06 --> Email Class Initialized
INFO - 2020-09-22 08:47:06 --> Controller Class Initialized
DEBUG - 2020-09-22 08:47:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:47:06 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-22 08:47:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/purpu1ex/public_html/carsm/application/controllers/Sale_rep.php 311
INFO - 2020-09-22 08:47:06 --> Model Class Initialized
INFO - 2020-09-22 08:47:06 --> Model Class Initialized
ERROR - 2020-09-22 08:47:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: CALL rep_assign_update('',)
INFO - 2020-09-22 08:47:06 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-22 08:47:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-09-22 08:47:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:47:15 --> Config Class Initialized
INFO - 2020-09-22 08:47:15 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:47:15 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:47:15 --> Utf8 Class Initialized
INFO - 2020-09-22 08:47:15 --> URI Class Initialized
INFO - 2020-09-22 08:47:15 --> Router Class Initialized
INFO - 2020-09-22 08:47:15 --> Output Class Initialized
INFO - 2020-09-22 08:47:15 --> Security Class Initialized
DEBUG - 2020-09-22 08:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:47:15 --> Input Class Initialized
INFO - 2020-09-22 08:47:15 --> Language Class Initialized
INFO - 2020-09-22 08:47:15 --> Loader Class Initialized
INFO - 2020-09-22 08:47:15 --> Helper loaded: url_helper
INFO - 2020-09-22 08:47:15 --> Database Driver Class Initialized
INFO - 2020-09-22 08:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:47:15 --> Email Class Initialized
INFO - 2020-09-22 08:47:15 --> Controller Class Initialized
DEBUG - 2020-09-22 08:47:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:47:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:47:15 --> Model Class Initialized
INFO - 2020-09-22 08:47:15 --> Model Class Initialized
INFO - 2020-09-22 08:47:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 08:47:15 --> Final output sent to browser
DEBUG - 2020-09-22 08:47:15 --> Total execution time: 0.0228
ERROR - 2020-09-22 08:47:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:47:34 --> Config Class Initialized
INFO - 2020-09-22 08:47:34 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:47:34 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:47:34 --> Utf8 Class Initialized
INFO - 2020-09-22 08:47:34 --> URI Class Initialized
DEBUG - 2020-09-22 08:47:34 --> No URI present. Default controller set.
INFO - 2020-09-22 08:47:34 --> Router Class Initialized
INFO - 2020-09-22 08:47:34 --> Output Class Initialized
INFO - 2020-09-22 08:47:34 --> Security Class Initialized
DEBUG - 2020-09-22 08:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:47:34 --> Input Class Initialized
INFO - 2020-09-22 08:47:34 --> Language Class Initialized
INFO - 2020-09-22 08:47:34 --> Loader Class Initialized
INFO - 2020-09-22 08:47:34 --> Helper loaded: url_helper
INFO - 2020-09-22 08:47:34 --> Database Driver Class Initialized
INFO - 2020-09-22 08:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:47:34 --> Email Class Initialized
INFO - 2020-09-22 08:47:34 --> Controller Class Initialized
INFO - 2020-09-22 08:47:34 --> Model Class Initialized
INFO - 2020-09-22 08:47:34 --> Model Class Initialized
DEBUG - 2020-09-22 08:47:34 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:47:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 08:47:34 --> Final output sent to browser
DEBUG - 2020-09-22 08:47:34 --> Total execution time: 0.0209
ERROR - 2020-09-22 08:50:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:50:50 --> Config Class Initialized
INFO - 2020-09-22 08:50:50 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:50:50 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:50:50 --> Utf8 Class Initialized
INFO - 2020-09-22 08:50:50 --> URI Class Initialized
INFO - 2020-09-22 08:50:50 --> Router Class Initialized
INFO - 2020-09-22 08:50:50 --> Output Class Initialized
INFO - 2020-09-22 08:50:50 --> Security Class Initialized
DEBUG - 2020-09-22 08:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:50:50 --> Input Class Initialized
INFO - 2020-09-22 08:50:50 --> Language Class Initialized
INFO - 2020-09-22 08:50:50 --> Loader Class Initialized
INFO - 2020-09-22 08:50:50 --> Helper loaded: url_helper
INFO - 2020-09-22 08:50:50 --> Database Driver Class Initialized
INFO - 2020-09-22 08:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:50:50 --> Email Class Initialized
INFO - 2020-09-22 08:50:50 --> Controller Class Initialized
DEBUG - 2020-09-22 08:50:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:50:50 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-22 08:50:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:50:50 --> Config Class Initialized
INFO - 2020-09-22 08:50:50 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:50:50 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:50:50 --> Utf8 Class Initialized
INFO - 2020-09-22 08:50:50 --> URI Class Initialized
DEBUG - 2020-09-22 08:50:50 --> No URI present. Default controller set.
INFO - 2020-09-22 08:50:50 --> Router Class Initialized
INFO - 2020-09-22 08:50:50 --> Output Class Initialized
INFO - 2020-09-22 08:50:50 --> Security Class Initialized
DEBUG - 2020-09-22 08:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:50:50 --> Input Class Initialized
INFO - 2020-09-22 08:50:50 --> Language Class Initialized
INFO - 2020-09-22 08:50:50 --> Loader Class Initialized
INFO - 2020-09-22 08:50:50 --> Helper loaded: url_helper
INFO - 2020-09-22 08:50:50 --> Database Driver Class Initialized
INFO - 2020-09-22 08:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:50:50 --> Email Class Initialized
INFO - 2020-09-22 08:50:50 --> Controller Class Initialized
INFO - 2020-09-22 08:50:50 --> Model Class Initialized
INFO - 2020-09-22 08:50:50 --> Model Class Initialized
DEBUG - 2020-09-22 08:50:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:50:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 08:50:50 --> Final output sent to browser
DEBUG - 2020-09-22 08:50:50 --> Total execution time: 0.0173
ERROR - 2020-09-22 08:50:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:50:53 --> Config Class Initialized
INFO - 2020-09-22 08:50:53 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:50:53 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:50:53 --> Utf8 Class Initialized
INFO - 2020-09-22 08:50:53 --> URI Class Initialized
INFO - 2020-09-22 08:50:53 --> Router Class Initialized
INFO - 2020-09-22 08:50:53 --> Output Class Initialized
INFO - 2020-09-22 08:50:53 --> Security Class Initialized
DEBUG - 2020-09-22 08:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:50:53 --> Input Class Initialized
INFO - 2020-09-22 08:50:53 --> Language Class Initialized
INFO - 2020-09-22 08:50:53 --> Loader Class Initialized
INFO - 2020-09-22 08:50:53 --> Helper loaded: url_helper
INFO - 2020-09-22 08:50:53 --> Database Driver Class Initialized
INFO - 2020-09-22 08:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:50:53 --> Email Class Initialized
INFO - 2020-09-22 08:50:53 --> Controller Class Initialized
INFO - 2020-09-22 08:50:53 --> Model Class Initialized
INFO - 2020-09-22 08:50:53 --> Model Class Initialized
DEBUG - 2020-09-22 08:50:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:50:53 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-22 08:50:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:50:53 --> Config Class Initialized
INFO - 2020-09-22 08:50:53 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:50:53 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:50:53 --> Utf8 Class Initialized
INFO - 2020-09-22 08:50:53 --> URI Class Initialized
INFO - 2020-09-22 08:50:53 --> Router Class Initialized
INFO - 2020-09-22 08:50:53 --> Output Class Initialized
INFO - 2020-09-22 08:50:53 --> Security Class Initialized
DEBUG - 2020-09-22 08:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:50:53 --> Input Class Initialized
INFO - 2020-09-22 08:50:53 --> Language Class Initialized
INFO - 2020-09-22 08:50:53 --> Loader Class Initialized
INFO - 2020-09-22 08:50:53 --> Helper loaded: url_helper
INFO - 2020-09-22 08:50:53 --> Database Driver Class Initialized
INFO - 2020-09-22 08:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:50:53 --> Email Class Initialized
INFO - 2020-09-22 08:50:53 --> Controller Class Initialized
INFO - 2020-09-22 08:50:53 --> Model Class Initialized
INFO - 2020-09-22 08:50:53 --> Model Class Initialized
DEBUG - 2020-09-22 08:50:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-22 08:50:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:50:53 --> Config Class Initialized
INFO - 2020-09-22 08:50:53 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:50:53 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:50:53 --> Utf8 Class Initialized
INFO - 2020-09-22 08:50:53 --> URI Class Initialized
DEBUG - 2020-09-22 08:50:53 --> No URI present. Default controller set.
INFO - 2020-09-22 08:50:53 --> Router Class Initialized
INFO - 2020-09-22 08:50:53 --> Output Class Initialized
INFO - 2020-09-22 08:50:53 --> Security Class Initialized
DEBUG - 2020-09-22 08:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:50:53 --> Input Class Initialized
INFO - 2020-09-22 08:50:53 --> Language Class Initialized
INFO - 2020-09-22 08:50:53 --> Loader Class Initialized
INFO - 2020-09-22 08:50:53 --> Helper loaded: url_helper
INFO - 2020-09-22 08:50:53 --> Database Driver Class Initialized
INFO - 2020-09-22 08:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:50:53 --> Email Class Initialized
INFO - 2020-09-22 08:50:53 --> Controller Class Initialized
INFO - 2020-09-22 08:50:53 --> Model Class Initialized
INFO - 2020-09-22 08:50:53 --> Model Class Initialized
DEBUG - 2020-09-22 08:50:53 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:50:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 08:50:53 --> Final output sent to browser
DEBUG - 2020-09-22 08:50:53 --> Total execution time: 0.0187
ERROR - 2020-09-22 08:50:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:50:54 --> Config Class Initialized
INFO - 2020-09-22 08:50:54 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:50:54 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:50:54 --> Utf8 Class Initialized
INFO - 2020-09-22 08:50:54 --> URI Class Initialized
DEBUG - 2020-09-22 08:50:54 --> No URI present. Default controller set.
INFO - 2020-09-22 08:50:54 --> Router Class Initialized
INFO - 2020-09-22 08:50:54 --> Output Class Initialized
INFO - 2020-09-22 08:50:54 --> Security Class Initialized
DEBUG - 2020-09-22 08:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:50:54 --> Input Class Initialized
INFO - 2020-09-22 08:50:54 --> Language Class Initialized
INFO - 2020-09-22 08:50:54 --> Loader Class Initialized
INFO - 2020-09-22 08:50:54 --> Helper loaded: url_helper
INFO - 2020-09-22 08:50:54 --> Database Driver Class Initialized
INFO - 2020-09-22 08:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:50:54 --> Email Class Initialized
INFO - 2020-09-22 08:50:54 --> Controller Class Initialized
INFO - 2020-09-22 08:50:54 --> Model Class Initialized
INFO - 2020-09-22 08:50:54 --> Model Class Initialized
DEBUG - 2020-09-22 08:50:54 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:50:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 08:50:54 --> Final output sent to browser
DEBUG - 2020-09-22 08:50:54 --> Total execution time: 0.0204
ERROR - 2020-09-22 08:50:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:50:56 --> Config Class Initialized
INFO - 2020-09-22 08:50:56 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:50:56 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:50:56 --> Utf8 Class Initialized
INFO - 2020-09-22 08:50:56 --> URI Class Initialized
INFO - 2020-09-22 08:50:56 --> Router Class Initialized
INFO - 2020-09-22 08:50:56 --> Output Class Initialized
INFO - 2020-09-22 08:50:56 --> Security Class Initialized
DEBUG - 2020-09-22 08:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:50:56 --> Input Class Initialized
INFO - 2020-09-22 08:50:56 --> Language Class Initialized
INFO - 2020-09-22 08:50:56 --> Loader Class Initialized
INFO - 2020-09-22 08:50:56 --> Helper loaded: url_helper
INFO - 2020-09-22 08:50:56 --> Database Driver Class Initialized
ERROR - 2020-09-22 08:50:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:50:56 --> Config Class Initialized
INFO - 2020-09-22 08:50:56 --> Hooks Class Initialized
INFO - 2020-09-22 08:50:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-09-22 08:50:56 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:50:56 --> Utf8 Class Initialized
INFO - 2020-09-22 08:50:56 --> URI Class Initialized
INFO - 2020-09-22 08:50:56 --> Email Class Initialized
INFO - 2020-09-22 08:50:56 --> Router Class Initialized
INFO - 2020-09-22 08:50:56 --> Controller Class Initialized
INFO - 2020-09-22 08:50:56 --> Model Class Initialized
INFO - 2020-09-22 08:50:56 --> Model Class Initialized
INFO - 2020-09-22 08:50:56 --> Output Class Initialized
DEBUG - 2020-09-22 08:50:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:50:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:50:56 --> Security Class Initialized
DEBUG - 2020-09-22 08:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:50:56 --> Input Class Initialized
INFO - 2020-09-22 08:50:56 --> Language Class Initialized
INFO - 2020-09-22 08:50:56 --> Loader Class Initialized
INFO - 2020-09-22 08:50:56 --> Helper loaded: url_helper
INFO - 2020-09-22 08:50:56 --> Database Driver Class Initialized
INFO - 2020-09-22 08:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:50:56 --> Email Class Initialized
INFO - 2020-09-22 08:50:56 --> Controller Class Initialized
INFO - 2020-09-22 08:50:56 --> Model Class Initialized
INFO - 2020-09-22 08:50:56 --> Model Class Initialized
DEBUG - 2020-09-22 08:50:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-22 08:50:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:50:56 --> Config Class Initialized
INFO - 2020-09-22 08:50:56 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:50:56 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:50:56 --> Utf8 Class Initialized
INFO - 2020-09-22 08:50:56 --> URI Class Initialized
DEBUG - 2020-09-22 08:50:56 --> No URI present. Default controller set.
INFO - 2020-09-22 08:50:56 --> Router Class Initialized
INFO - 2020-09-22 08:50:56 --> Output Class Initialized
INFO - 2020-09-22 08:50:56 --> Security Class Initialized
DEBUG - 2020-09-22 08:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:50:56 --> Input Class Initialized
INFO - 2020-09-22 08:50:56 --> Language Class Initialized
INFO - 2020-09-22 08:50:56 --> Loader Class Initialized
INFO - 2020-09-22 08:50:56 --> Helper loaded: url_helper
INFO - 2020-09-22 08:50:56 --> Database Driver Class Initialized
INFO - 2020-09-22 08:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:50:56 --> Email Class Initialized
INFO - 2020-09-22 08:50:56 --> Controller Class Initialized
INFO - 2020-09-22 08:50:56 --> Model Class Initialized
INFO - 2020-09-22 08:50:56 --> Model Class Initialized
DEBUG - 2020-09-22 08:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:50:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 08:50:56 --> Final output sent to browser
DEBUG - 2020-09-22 08:50:56 --> Total execution time: 0.0192
ERROR - 2020-09-22 08:50:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:50:57 --> Config Class Initialized
INFO - 2020-09-22 08:50:57 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:50:57 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:50:57 --> Utf8 Class Initialized
INFO - 2020-09-22 08:50:57 --> URI Class Initialized
DEBUG - 2020-09-22 08:50:57 --> No URI present. Default controller set.
INFO - 2020-09-22 08:50:57 --> Router Class Initialized
INFO - 2020-09-22 08:50:57 --> Output Class Initialized
INFO - 2020-09-22 08:50:57 --> Security Class Initialized
DEBUG - 2020-09-22 08:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:50:57 --> Input Class Initialized
INFO - 2020-09-22 08:50:57 --> Language Class Initialized
INFO - 2020-09-22 08:50:57 --> Loader Class Initialized
INFO - 2020-09-22 08:50:57 --> Helper loaded: url_helper
INFO - 2020-09-22 08:50:57 --> Database Driver Class Initialized
INFO - 2020-09-22 08:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:50:57 --> Email Class Initialized
INFO - 2020-09-22 08:50:57 --> Controller Class Initialized
INFO - 2020-09-22 08:50:57 --> Model Class Initialized
INFO - 2020-09-22 08:50:57 --> Model Class Initialized
DEBUG - 2020-09-22 08:50:57 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:50:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 08:50:57 --> Final output sent to browser
DEBUG - 2020-09-22 08:50:57 --> Total execution time: 0.0200
ERROR - 2020-09-22 08:51:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:51:02 --> Config Class Initialized
INFO - 2020-09-22 08:51:02 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:51:02 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:51:02 --> Utf8 Class Initialized
INFO - 2020-09-22 08:51:02 --> URI Class Initialized
DEBUG - 2020-09-22 08:51:02 --> No URI present. Default controller set.
INFO - 2020-09-22 08:51:02 --> Router Class Initialized
INFO - 2020-09-22 08:51:02 --> Output Class Initialized
INFO - 2020-09-22 08:51:02 --> Security Class Initialized
DEBUG - 2020-09-22 08:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:51:02 --> Input Class Initialized
INFO - 2020-09-22 08:51:02 --> Language Class Initialized
INFO - 2020-09-22 08:51:02 --> Loader Class Initialized
INFO - 2020-09-22 08:51:02 --> Helper loaded: url_helper
INFO - 2020-09-22 08:51:02 --> Database Driver Class Initialized
INFO - 2020-09-22 08:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:51:02 --> Email Class Initialized
INFO - 2020-09-22 08:51:02 --> Controller Class Initialized
INFO - 2020-09-22 08:51:02 --> Model Class Initialized
INFO - 2020-09-22 08:51:02 --> Model Class Initialized
DEBUG - 2020-09-22 08:51:02 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:51:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 08:51:02 --> Final output sent to browser
DEBUG - 2020-09-22 08:51:02 --> Total execution time: 0.0213
ERROR - 2020-09-22 08:51:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:51:05 --> Config Class Initialized
INFO - 2020-09-22 08:51:05 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:51:05 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:51:05 --> Utf8 Class Initialized
INFO - 2020-09-22 08:51:05 --> URI Class Initialized
DEBUG - 2020-09-22 08:51:05 --> No URI present. Default controller set.
INFO - 2020-09-22 08:51:05 --> Router Class Initialized
INFO - 2020-09-22 08:51:05 --> Output Class Initialized
INFO - 2020-09-22 08:51:05 --> Security Class Initialized
DEBUG - 2020-09-22 08:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:51:05 --> Input Class Initialized
INFO - 2020-09-22 08:51:05 --> Language Class Initialized
INFO - 2020-09-22 08:51:05 --> Loader Class Initialized
INFO - 2020-09-22 08:51:05 --> Helper loaded: url_helper
INFO - 2020-09-22 08:51:05 --> Database Driver Class Initialized
INFO - 2020-09-22 08:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:51:05 --> Email Class Initialized
INFO - 2020-09-22 08:51:05 --> Controller Class Initialized
INFO - 2020-09-22 08:51:05 --> Model Class Initialized
INFO - 2020-09-22 08:51:05 --> Model Class Initialized
DEBUG - 2020-09-22 08:51:05 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:51:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 08:51:05 --> Final output sent to browser
DEBUG - 2020-09-22 08:51:05 --> Total execution time: 0.0193
ERROR - 2020-09-22 08:51:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:51:07 --> Config Class Initialized
INFO - 2020-09-22 08:51:07 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:51:07 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:51:07 --> Utf8 Class Initialized
INFO - 2020-09-22 08:51:07 --> URI Class Initialized
INFO - 2020-09-22 08:51:07 --> Router Class Initialized
INFO - 2020-09-22 08:51:07 --> Output Class Initialized
ERROR - 2020-09-22 08:51:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:51:07 --> Security Class Initialized
INFO - 2020-09-22 08:51:07 --> Config Class Initialized
INFO - 2020-09-22 08:51:07 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:51:07 --> Input Class Initialized
INFO - 2020-09-22 08:51:07 --> Language Class Initialized
DEBUG - 2020-09-22 08:51:07 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:51:07 --> Utf8 Class Initialized
INFO - 2020-09-22 08:51:07 --> URI Class Initialized
INFO - 2020-09-22 08:51:07 --> Loader Class Initialized
INFO - 2020-09-22 08:51:07 --> Router Class Initialized
INFO - 2020-09-22 08:51:07 --> Helper loaded: url_helper
INFO - 2020-09-22 08:51:07 --> Output Class Initialized
INFO - 2020-09-22 08:51:07 --> Security Class Initialized
DEBUG - 2020-09-22 08:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:51:07 --> Input Class Initialized
INFO - 2020-09-22 08:51:07 --> Language Class Initialized
INFO - 2020-09-22 08:51:07 --> Loader Class Initialized
INFO - 2020-09-22 08:51:07 --> Database Driver Class Initialized
INFO - 2020-09-22 08:51:07 --> Helper loaded: url_helper
INFO - 2020-09-22 08:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:51:07 --> Database Driver Class Initialized
INFO - 2020-09-22 08:51:07 --> Email Class Initialized
INFO - 2020-09-22 08:51:07 --> Controller Class Initialized
INFO - 2020-09-22 08:51:07 --> Model Class Initialized
INFO - 2020-09-22 08:51:07 --> Model Class Initialized
DEBUG - 2020-09-22 08:51:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:51:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:51:07 --> Email Class Initialized
INFO - 2020-09-22 08:51:07 --> Controller Class Initialized
INFO - 2020-09-22 08:51:07 --> Model Class Initialized
INFO - 2020-09-22 08:51:07 --> Model Class Initialized
DEBUG - 2020-09-22 08:51:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-22 08:51:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:51:08 --> Config Class Initialized
INFO - 2020-09-22 08:51:08 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:51:08 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:51:08 --> Utf8 Class Initialized
INFO - 2020-09-22 08:51:08 --> URI Class Initialized
DEBUG - 2020-09-22 08:51:08 --> No URI present. Default controller set.
INFO - 2020-09-22 08:51:08 --> Router Class Initialized
INFO - 2020-09-22 08:51:08 --> Output Class Initialized
INFO - 2020-09-22 08:51:08 --> Security Class Initialized
DEBUG - 2020-09-22 08:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:51:08 --> Input Class Initialized
INFO - 2020-09-22 08:51:08 --> Language Class Initialized
INFO - 2020-09-22 08:51:08 --> Loader Class Initialized
INFO - 2020-09-22 08:51:08 --> Helper loaded: url_helper
INFO - 2020-09-22 08:51:08 --> Database Driver Class Initialized
INFO - 2020-09-22 08:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:51:08 --> Email Class Initialized
INFO - 2020-09-22 08:51:08 --> Controller Class Initialized
INFO - 2020-09-22 08:51:08 --> Model Class Initialized
INFO - 2020-09-22 08:51:08 --> Model Class Initialized
DEBUG - 2020-09-22 08:51:08 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:51:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 08:51:08 --> Final output sent to browser
DEBUG - 2020-09-22 08:51:08 --> Total execution time: 0.0202
ERROR - 2020-09-22 08:51:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:51:09 --> Config Class Initialized
INFO - 2020-09-22 08:51:09 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:51:09 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:51:09 --> Utf8 Class Initialized
INFO - 2020-09-22 08:51:09 --> URI Class Initialized
DEBUG - 2020-09-22 08:51:09 --> No URI present. Default controller set.
INFO - 2020-09-22 08:51:09 --> Router Class Initialized
INFO - 2020-09-22 08:51:09 --> Output Class Initialized
INFO - 2020-09-22 08:51:09 --> Security Class Initialized
DEBUG - 2020-09-22 08:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:51:09 --> Input Class Initialized
INFO - 2020-09-22 08:51:09 --> Language Class Initialized
INFO - 2020-09-22 08:51:09 --> Loader Class Initialized
INFO - 2020-09-22 08:51:09 --> Helper loaded: url_helper
INFO - 2020-09-22 08:51:09 --> Database Driver Class Initialized
INFO - 2020-09-22 08:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:51:09 --> Email Class Initialized
INFO - 2020-09-22 08:51:09 --> Controller Class Initialized
INFO - 2020-09-22 08:51:09 --> Model Class Initialized
INFO - 2020-09-22 08:51:09 --> Model Class Initialized
DEBUG - 2020-09-22 08:51:09 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:51:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 08:51:09 --> Final output sent to browser
DEBUG - 2020-09-22 08:51:09 --> Total execution time: 0.0228
ERROR - 2020-09-22 08:51:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:51:18 --> Config Class Initialized
INFO - 2020-09-22 08:51:18 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:51:18 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:51:18 --> Utf8 Class Initialized
INFO - 2020-09-22 08:51:18 --> URI Class Initialized
INFO - 2020-09-22 08:51:18 --> Router Class Initialized
INFO - 2020-09-22 08:51:18 --> Output Class Initialized
INFO - 2020-09-22 08:51:18 --> Security Class Initialized
DEBUG - 2020-09-22 08:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:51:18 --> Input Class Initialized
INFO - 2020-09-22 08:51:18 --> Language Class Initialized
INFO - 2020-09-22 08:51:18 --> Loader Class Initialized
INFO - 2020-09-22 08:51:18 --> Helper loaded: url_helper
INFO - 2020-09-22 08:51:18 --> Database Driver Class Initialized
INFO - 2020-09-22 08:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:51:18 --> Email Class Initialized
INFO - 2020-09-22 08:51:18 --> Controller Class Initialized
INFO - 2020-09-22 08:51:18 --> Model Class Initialized
INFO - 2020-09-22 08:51:18 --> Model Class Initialized
DEBUG - 2020-09-22 08:51:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-22 08:51:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:51:18 --> Config Class Initialized
INFO - 2020-09-22 08:51:18 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:51:18 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:51:18 --> Utf8 Class Initialized
INFO - 2020-09-22 08:51:18 --> URI Class Initialized
INFO - 2020-09-22 08:51:18 --> Router Class Initialized
INFO - 2020-09-22 08:51:18 --> Output Class Initialized
INFO - 2020-09-22 08:51:18 --> Security Class Initialized
DEBUG - 2020-09-22 08:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:51:18 --> Input Class Initialized
INFO - 2020-09-22 08:51:18 --> Language Class Initialized
INFO - 2020-09-22 08:51:18 --> Loader Class Initialized
INFO - 2020-09-22 08:51:18 --> Helper loaded: url_helper
INFO - 2020-09-22 08:51:18 --> Database Driver Class Initialized
INFO - 2020-09-22 08:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:51:18 --> Email Class Initialized
INFO - 2020-09-22 08:51:18 --> Controller Class Initialized
INFO - 2020-09-22 08:51:18 --> Model Class Initialized
INFO - 2020-09-22 08:51:18 --> Model Class Initialized
DEBUG - 2020-09-22 08:51:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:51:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:51:18 --> Model Class Initialized
INFO - 2020-09-22 08:51:18 --> Final output sent to browser
DEBUG - 2020-09-22 08:51:18 --> Total execution time: 0.0192
ERROR - 2020-09-22 08:51:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:51:18 --> Config Class Initialized
INFO - 2020-09-22 08:51:18 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:51:18 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:51:18 --> Utf8 Class Initialized
INFO - 2020-09-22 08:51:18 --> URI Class Initialized
INFO - 2020-09-22 08:51:18 --> Router Class Initialized
INFO - 2020-09-22 08:51:18 --> Output Class Initialized
INFO - 2020-09-22 08:51:18 --> Security Class Initialized
DEBUG - 2020-09-22 08:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:51:18 --> Input Class Initialized
INFO - 2020-09-22 08:51:18 --> Language Class Initialized
INFO - 2020-09-22 08:51:18 --> Loader Class Initialized
INFO - 2020-09-22 08:51:18 --> Helper loaded: url_helper
INFO - 2020-09-22 08:51:18 --> Database Driver Class Initialized
INFO - 2020-09-22 08:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:51:18 --> Email Class Initialized
INFO - 2020-09-22 08:51:18 --> Controller Class Initialized
DEBUG - 2020-09-22 08:51:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:51:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:51:18 --> Model Class Initialized
INFO - 2020-09-22 08:51:18 --> Model Class Initialized
INFO - 2020-09-22 08:51:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-22 08:51:18 --> Final output sent to browser
DEBUG - 2020-09-22 08:51:18 --> Total execution time: 0.0227
ERROR - 2020-09-22 08:51:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:51:24 --> Config Class Initialized
INFO - 2020-09-22 08:51:24 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:51:24 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:51:24 --> Utf8 Class Initialized
INFO - 2020-09-22 08:51:24 --> URI Class Initialized
INFO - 2020-09-22 08:51:24 --> Router Class Initialized
INFO - 2020-09-22 08:51:24 --> Output Class Initialized
INFO - 2020-09-22 08:51:24 --> Security Class Initialized
DEBUG - 2020-09-22 08:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:51:24 --> Input Class Initialized
INFO - 2020-09-22 08:51:24 --> Language Class Initialized
INFO - 2020-09-22 08:51:24 --> Loader Class Initialized
INFO - 2020-09-22 08:51:24 --> Helper loaded: url_helper
INFO - 2020-09-22 08:51:24 --> Database Driver Class Initialized
INFO - 2020-09-22 08:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:51:24 --> Email Class Initialized
INFO - 2020-09-22 08:51:24 --> Controller Class Initialized
DEBUG - 2020-09-22 08:51:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:51:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:51:24 --> Model Class Initialized
INFO - 2020-09-22 08:51:24 --> Model Class Initialized
INFO - 2020-09-22 08:51:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 08:51:24 --> Final output sent to browser
DEBUG - 2020-09-22 08:51:24 --> Total execution time: 0.0260
ERROR - 2020-09-22 08:52:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:52:33 --> Config Class Initialized
INFO - 2020-09-22 08:52:33 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:52:33 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:52:33 --> Utf8 Class Initialized
INFO - 2020-09-22 08:52:33 --> URI Class Initialized
INFO - 2020-09-22 08:52:33 --> Router Class Initialized
INFO - 2020-09-22 08:52:33 --> Output Class Initialized
INFO - 2020-09-22 08:52:33 --> Security Class Initialized
DEBUG - 2020-09-22 08:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:52:33 --> Input Class Initialized
INFO - 2020-09-22 08:52:33 --> Language Class Initialized
INFO - 2020-09-22 08:52:33 --> Loader Class Initialized
INFO - 2020-09-22 08:52:33 --> Helper loaded: url_helper
INFO - 2020-09-22 08:52:33 --> Database Driver Class Initialized
INFO - 2020-09-22 08:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:52:33 --> Email Class Initialized
INFO - 2020-09-22 08:52:33 --> Controller Class Initialized
DEBUG - 2020-09-22 08:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:52:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:52:33 --> Model Class Initialized
INFO - 2020-09-22 08:52:33 --> Model Class Initialized
INFO - 2020-09-22 08:52:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 08:52:33 --> Final output sent to browser
DEBUG - 2020-09-22 08:52:33 --> Total execution time: 0.2422
ERROR - 2020-09-22 08:53:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:53:16 --> Config Class Initialized
INFO - 2020-09-22 08:53:16 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:53:16 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:53:16 --> Utf8 Class Initialized
INFO - 2020-09-22 08:53:16 --> URI Class Initialized
INFO - 2020-09-22 08:53:16 --> Router Class Initialized
INFO - 2020-09-22 08:53:16 --> Output Class Initialized
INFO - 2020-09-22 08:53:16 --> Security Class Initialized
DEBUG - 2020-09-22 08:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:53:16 --> Input Class Initialized
INFO - 2020-09-22 08:53:16 --> Language Class Initialized
INFO - 2020-09-22 08:53:16 --> Loader Class Initialized
INFO - 2020-09-22 08:53:16 --> Helper loaded: url_helper
INFO - 2020-09-22 08:53:16 --> Database Driver Class Initialized
INFO - 2020-09-22 08:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:53:16 --> Email Class Initialized
INFO - 2020-09-22 08:53:16 --> Controller Class Initialized
DEBUG - 2020-09-22 08:53:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:53:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:53:16 --> Model Class Initialized
INFO - 2020-09-22 08:53:16 --> Model Class Initialized
INFO - 2020-09-22 08:53:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 08:53:16 --> Final output sent to browser
DEBUG - 2020-09-22 08:53:16 --> Total execution time: 0.0257
ERROR - 2020-09-22 08:54:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:54:13 --> Config Class Initialized
INFO - 2020-09-22 08:54:13 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:54:13 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:54:13 --> Utf8 Class Initialized
INFO - 2020-09-22 08:54:13 --> URI Class Initialized
INFO - 2020-09-22 08:54:13 --> Router Class Initialized
INFO - 2020-09-22 08:54:13 --> Output Class Initialized
INFO - 2020-09-22 08:54:13 --> Security Class Initialized
DEBUG - 2020-09-22 08:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:54:13 --> Input Class Initialized
INFO - 2020-09-22 08:54:13 --> Language Class Initialized
INFO - 2020-09-22 08:54:13 --> Loader Class Initialized
INFO - 2020-09-22 08:54:13 --> Helper loaded: url_helper
INFO - 2020-09-22 08:54:13 --> Database Driver Class Initialized
INFO - 2020-09-22 08:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:54:13 --> Email Class Initialized
INFO - 2020-09-22 08:54:13 --> Controller Class Initialized
DEBUG - 2020-09-22 08:54:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:54:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:54:13 --> Model Class Initialized
INFO - 2020-09-22 08:54:13 --> Model Class Initialized
INFO - 2020-09-22 08:54:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 08:54:13 --> Final output sent to browser
DEBUG - 2020-09-22 08:54:13 --> Total execution time: 0.0550
ERROR - 2020-09-22 08:54:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:54:45 --> Config Class Initialized
INFO - 2020-09-22 08:54:45 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:54:45 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:54:45 --> Utf8 Class Initialized
INFO - 2020-09-22 08:54:45 --> URI Class Initialized
INFO - 2020-09-22 08:54:45 --> Router Class Initialized
INFO - 2020-09-22 08:54:45 --> Output Class Initialized
INFO - 2020-09-22 08:54:45 --> Security Class Initialized
DEBUG - 2020-09-22 08:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:54:45 --> Input Class Initialized
INFO - 2020-09-22 08:54:45 --> Language Class Initialized
INFO - 2020-09-22 08:54:45 --> Loader Class Initialized
INFO - 2020-09-22 08:54:45 --> Helper loaded: url_helper
INFO - 2020-09-22 08:54:45 --> Database Driver Class Initialized
INFO - 2020-09-22 08:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:54:45 --> Email Class Initialized
INFO - 2020-09-22 08:54:45 --> Controller Class Initialized
DEBUG - 2020-09-22 08:54:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:54:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:54:45 --> Model Class Initialized
INFO - 2020-09-22 08:54:45 --> Model Class Initialized
INFO - 2020-09-22 08:54:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 08:54:45 --> Final output sent to browser
DEBUG - 2020-09-22 08:54:45 --> Total execution time: 0.0315
ERROR - 2020-09-22 08:54:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:54:46 --> Config Class Initialized
INFO - 2020-09-22 08:54:46 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:54:46 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:54:46 --> Utf8 Class Initialized
INFO - 2020-09-22 08:54:46 --> URI Class Initialized
INFO - 2020-09-22 08:54:46 --> Router Class Initialized
INFO - 2020-09-22 08:54:46 --> Output Class Initialized
INFO - 2020-09-22 08:54:46 --> Security Class Initialized
DEBUG - 2020-09-22 08:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:54:46 --> Input Class Initialized
INFO - 2020-09-22 08:54:46 --> Language Class Initialized
INFO - 2020-09-22 08:54:46 --> Loader Class Initialized
INFO - 2020-09-22 08:54:46 --> Helper loaded: url_helper
INFO - 2020-09-22 08:54:46 --> Database Driver Class Initialized
INFO - 2020-09-22 08:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:54:46 --> Email Class Initialized
INFO - 2020-09-22 08:54:46 --> Controller Class Initialized
DEBUG - 2020-09-22 08:54:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:54:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:54:46 --> Model Class Initialized
INFO - 2020-09-22 08:54:46 --> Model Class Initialized
INFO - 2020-09-22 08:54:46 --> Final output sent to browser
DEBUG - 2020-09-22 08:54:46 --> Total execution time: 0.1131
ERROR - 2020-09-22 08:55:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:55:33 --> Config Class Initialized
INFO - 2020-09-22 08:55:33 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:55:33 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:55:33 --> Utf8 Class Initialized
INFO - 2020-09-22 08:55:33 --> URI Class Initialized
INFO - 2020-09-22 08:55:33 --> Router Class Initialized
INFO - 2020-09-22 08:55:33 --> Output Class Initialized
INFO - 2020-09-22 08:55:33 --> Security Class Initialized
DEBUG - 2020-09-22 08:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:55:33 --> Input Class Initialized
INFO - 2020-09-22 08:55:33 --> Language Class Initialized
INFO - 2020-09-22 08:55:33 --> Loader Class Initialized
INFO - 2020-09-22 08:55:33 --> Helper loaded: url_helper
INFO - 2020-09-22 08:55:33 --> Database Driver Class Initialized
INFO - 2020-09-22 08:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:55:33 --> Email Class Initialized
INFO - 2020-09-22 08:55:33 --> Controller Class Initialized
DEBUG - 2020-09-22 08:55:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:55:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:55:33 --> Model Class Initialized
INFO - 2020-09-22 08:55:33 --> Model Class Initialized
INFO - 2020-09-22 08:55:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 08:55:33 --> Final output sent to browser
DEBUG - 2020-09-22 08:55:33 --> Total execution time: 0.0217
ERROR - 2020-09-22 08:55:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:55:33 --> Config Class Initialized
INFO - 2020-09-22 08:55:33 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:55:33 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:55:33 --> Utf8 Class Initialized
INFO - 2020-09-22 08:55:33 --> URI Class Initialized
INFO - 2020-09-22 08:55:33 --> Router Class Initialized
INFO - 2020-09-22 08:55:33 --> Output Class Initialized
INFO - 2020-09-22 08:55:33 --> Security Class Initialized
DEBUG - 2020-09-22 08:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:55:33 --> Input Class Initialized
INFO - 2020-09-22 08:55:33 --> Language Class Initialized
INFO - 2020-09-22 08:55:33 --> Loader Class Initialized
INFO - 2020-09-22 08:55:33 --> Helper loaded: url_helper
INFO - 2020-09-22 08:55:33 --> Database Driver Class Initialized
INFO - 2020-09-22 08:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:55:33 --> Email Class Initialized
INFO - 2020-09-22 08:55:33 --> Controller Class Initialized
DEBUG - 2020-09-22 08:55:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:55:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:55:33 --> Model Class Initialized
INFO - 2020-09-22 08:55:33 --> Model Class Initialized
INFO - 2020-09-22 08:55:33 --> Final output sent to browser
DEBUG - 2020-09-22 08:55:33 --> Total execution time: 0.0250
ERROR - 2020-09-22 08:57:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:57:14 --> Config Class Initialized
INFO - 2020-09-22 08:57:14 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:57:14 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:57:14 --> Utf8 Class Initialized
INFO - 2020-09-22 08:57:14 --> URI Class Initialized
INFO - 2020-09-22 08:57:14 --> Router Class Initialized
INFO - 2020-09-22 08:57:14 --> Output Class Initialized
INFO - 2020-09-22 08:57:14 --> Security Class Initialized
DEBUG - 2020-09-22 08:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:57:14 --> Input Class Initialized
INFO - 2020-09-22 08:57:14 --> Language Class Initialized
INFO - 2020-09-22 08:57:14 --> Loader Class Initialized
INFO - 2020-09-22 08:57:14 --> Helper loaded: url_helper
INFO - 2020-09-22 08:57:14 --> Database Driver Class Initialized
INFO - 2020-09-22 08:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:57:14 --> Email Class Initialized
INFO - 2020-09-22 08:57:14 --> Controller Class Initialized
DEBUG - 2020-09-22 08:57:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:57:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:57:14 --> Model Class Initialized
INFO - 2020-09-22 08:57:14 --> Model Class Initialized
INFO - 2020-09-22 08:57:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 08:57:14 --> Final output sent to browser
DEBUG - 2020-09-22 08:57:14 --> Total execution time: 0.0224
ERROR - 2020-09-22 08:57:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:57:15 --> Config Class Initialized
INFO - 2020-09-22 08:57:15 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:57:15 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:57:15 --> Utf8 Class Initialized
INFO - 2020-09-22 08:57:15 --> URI Class Initialized
INFO - 2020-09-22 08:57:15 --> Router Class Initialized
INFO - 2020-09-22 08:57:15 --> Output Class Initialized
INFO - 2020-09-22 08:57:15 --> Security Class Initialized
DEBUG - 2020-09-22 08:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:57:15 --> Input Class Initialized
INFO - 2020-09-22 08:57:15 --> Language Class Initialized
INFO - 2020-09-22 08:57:15 --> Loader Class Initialized
INFO - 2020-09-22 08:57:15 --> Helper loaded: url_helper
INFO - 2020-09-22 08:57:15 --> Database Driver Class Initialized
INFO - 2020-09-22 08:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:57:15 --> Email Class Initialized
INFO - 2020-09-22 08:57:15 --> Controller Class Initialized
DEBUG - 2020-09-22 08:57:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:57:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:57:15 --> Model Class Initialized
INFO - 2020-09-22 08:57:15 --> Model Class Initialized
INFO - 2020-09-22 08:57:15 --> Final output sent to browser
DEBUG - 2020-09-22 08:57:15 --> Total execution time: 0.0210
ERROR - 2020-09-22 08:57:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:57:19 --> Config Class Initialized
INFO - 2020-09-22 08:57:19 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:57:19 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:57:19 --> Utf8 Class Initialized
INFO - 2020-09-22 08:57:19 --> URI Class Initialized
INFO - 2020-09-22 08:57:19 --> Router Class Initialized
INFO - 2020-09-22 08:57:19 --> Output Class Initialized
INFO - 2020-09-22 08:57:19 --> Security Class Initialized
DEBUG - 2020-09-22 08:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:57:19 --> Input Class Initialized
INFO - 2020-09-22 08:57:19 --> Language Class Initialized
INFO - 2020-09-22 08:57:19 --> Loader Class Initialized
INFO - 2020-09-22 08:57:19 --> Helper loaded: url_helper
INFO - 2020-09-22 08:57:19 --> Database Driver Class Initialized
INFO - 2020-09-22 08:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:57:19 --> Email Class Initialized
INFO - 2020-09-22 08:57:19 --> Controller Class Initialized
DEBUG - 2020-09-22 08:57:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:57:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:57:19 --> Model Class Initialized
INFO - 2020-09-22 08:57:19 --> Model Class Initialized
INFO - 2020-09-22 08:57:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 08:57:19 --> Final output sent to browser
DEBUG - 2020-09-22 08:57:19 --> Total execution time: 0.0230
ERROR - 2020-09-22 08:57:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:57:19 --> Config Class Initialized
INFO - 2020-09-22 08:57:19 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:57:19 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:57:19 --> Utf8 Class Initialized
INFO - 2020-09-22 08:57:19 --> URI Class Initialized
INFO - 2020-09-22 08:57:19 --> Router Class Initialized
INFO - 2020-09-22 08:57:19 --> Output Class Initialized
INFO - 2020-09-22 08:57:19 --> Security Class Initialized
DEBUG - 2020-09-22 08:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:57:19 --> Input Class Initialized
INFO - 2020-09-22 08:57:19 --> Language Class Initialized
INFO - 2020-09-22 08:57:19 --> Loader Class Initialized
INFO - 2020-09-22 08:57:19 --> Helper loaded: url_helper
INFO - 2020-09-22 08:57:19 --> Database Driver Class Initialized
INFO - 2020-09-22 08:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:57:19 --> Email Class Initialized
INFO - 2020-09-22 08:57:19 --> Controller Class Initialized
DEBUG - 2020-09-22 08:57:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:57:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:57:19 --> Model Class Initialized
INFO - 2020-09-22 08:57:19 --> Model Class Initialized
INFO - 2020-09-22 08:57:19 --> Final output sent to browser
DEBUG - 2020-09-22 08:57:19 --> Total execution time: 0.0249
ERROR - 2020-09-22 08:57:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:57:49 --> Config Class Initialized
INFO - 2020-09-22 08:57:49 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:57:49 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:57:49 --> Utf8 Class Initialized
INFO - 2020-09-22 08:57:49 --> URI Class Initialized
INFO - 2020-09-22 08:57:49 --> Router Class Initialized
INFO - 2020-09-22 08:57:49 --> Output Class Initialized
INFO - 2020-09-22 08:57:49 --> Security Class Initialized
DEBUG - 2020-09-22 08:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:57:49 --> Input Class Initialized
INFO - 2020-09-22 08:57:49 --> Language Class Initialized
INFO - 2020-09-22 08:57:49 --> Loader Class Initialized
INFO - 2020-09-22 08:57:49 --> Helper loaded: url_helper
INFO - 2020-09-22 08:57:49 --> Database Driver Class Initialized
INFO - 2020-09-22 08:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:57:49 --> Email Class Initialized
INFO - 2020-09-22 08:57:49 --> Controller Class Initialized
DEBUG - 2020-09-22 08:57:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:57:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:57:49 --> Model Class Initialized
INFO - 2020-09-22 08:57:49 --> Model Class Initialized
INFO - 2020-09-22 08:57:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 08:57:49 --> Final output sent to browser
DEBUG - 2020-09-22 08:57:49 --> Total execution time: 0.0239
ERROR - 2020-09-22 08:57:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 08:57:50 --> Config Class Initialized
INFO - 2020-09-22 08:57:50 --> Hooks Class Initialized
DEBUG - 2020-09-22 08:57:50 --> UTF-8 Support Enabled
INFO - 2020-09-22 08:57:50 --> Utf8 Class Initialized
INFO - 2020-09-22 08:57:50 --> URI Class Initialized
INFO - 2020-09-22 08:57:50 --> Router Class Initialized
INFO - 2020-09-22 08:57:50 --> Output Class Initialized
INFO - 2020-09-22 08:57:50 --> Security Class Initialized
DEBUG - 2020-09-22 08:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 08:57:50 --> Input Class Initialized
INFO - 2020-09-22 08:57:50 --> Language Class Initialized
INFO - 2020-09-22 08:57:50 --> Loader Class Initialized
INFO - 2020-09-22 08:57:50 --> Helper loaded: url_helper
INFO - 2020-09-22 08:57:50 --> Database Driver Class Initialized
INFO - 2020-09-22 08:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 08:57:50 --> Email Class Initialized
INFO - 2020-09-22 08:57:50 --> Controller Class Initialized
DEBUG - 2020-09-22 08:57:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 08:57:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 08:57:50 --> Model Class Initialized
INFO - 2020-09-22 08:57:50 --> Model Class Initialized
INFO - 2020-09-22 08:57:50 --> Final output sent to browser
DEBUG - 2020-09-22 08:57:50 --> Total execution time: 0.0253
ERROR - 2020-09-22 09:00:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:00:22 --> Config Class Initialized
INFO - 2020-09-22 09:00:22 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:00:22 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:00:22 --> Utf8 Class Initialized
INFO - 2020-09-22 09:00:22 --> URI Class Initialized
INFO - 2020-09-22 09:00:22 --> Router Class Initialized
INFO - 2020-09-22 09:00:22 --> Output Class Initialized
INFO - 2020-09-22 09:00:22 --> Security Class Initialized
DEBUG - 2020-09-22 09:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:00:22 --> Input Class Initialized
INFO - 2020-09-22 09:00:22 --> Language Class Initialized
INFO - 2020-09-22 09:00:22 --> Loader Class Initialized
INFO - 2020-09-22 09:00:22 --> Helper loaded: url_helper
INFO - 2020-09-22 09:00:22 --> Database Driver Class Initialized
INFO - 2020-09-22 09:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:00:22 --> Email Class Initialized
INFO - 2020-09-22 09:00:22 --> Controller Class Initialized
DEBUG - 2020-09-22 09:00:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:00:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:00:22 --> Model Class Initialized
INFO - 2020-09-22 09:00:22 --> Model Class Initialized
INFO - 2020-09-22 09:00:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 09:00:22 --> Final output sent to browser
DEBUG - 2020-09-22 09:00:22 --> Total execution time: 0.0309
ERROR - 2020-09-22 09:00:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:00:22 --> Config Class Initialized
INFO - 2020-09-22 09:00:22 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:00:22 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:00:22 --> Utf8 Class Initialized
INFO - 2020-09-22 09:00:22 --> URI Class Initialized
INFO - 2020-09-22 09:00:22 --> Router Class Initialized
INFO - 2020-09-22 09:00:22 --> Output Class Initialized
INFO - 2020-09-22 09:00:22 --> Security Class Initialized
DEBUG - 2020-09-22 09:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:00:22 --> Input Class Initialized
INFO - 2020-09-22 09:00:22 --> Language Class Initialized
INFO - 2020-09-22 09:00:23 --> Loader Class Initialized
INFO - 2020-09-22 09:00:23 --> Helper loaded: url_helper
INFO - 2020-09-22 09:00:23 --> Database Driver Class Initialized
INFO - 2020-09-22 09:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:00:23 --> Email Class Initialized
INFO - 2020-09-22 09:00:23 --> Controller Class Initialized
DEBUG - 2020-09-22 09:00:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:00:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:00:23 --> Model Class Initialized
INFO - 2020-09-22 09:00:23 --> Model Class Initialized
INFO - 2020-09-22 09:00:23 --> Final output sent to browser
DEBUG - 2020-09-22 09:00:23 --> Total execution time: 0.1507
ERROR - 2020-09-22 09:05:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:05:01 --> Config Class Initialized
INFO - 2020-09-22 09:05:01 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:05:01 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:05:01 --> Utf8 Class Initialized
INFO - 2020-09-22 09:05:01 --> URI Class Initialized
INFO - 2020-09-22 09:05:01 --> Router Class Initialized
INFO - 2020-09-22 09:05:01 --> Output Class Initialized
INFO - 2020-09-22 09:05:01 --> Security Class Initialized
DEBUG - 2020-09-22 09:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:05:01 --> Input Class Initialized
INFO - 2020-09-22 09:05:01 --> Language Class Initialized
INFO - 2020-09-22 09:05:01 --> Loader Class Initialized
INFO - 2020-09-22 09:05:01 --> Helper loaded: url_helper
INFO - 2020-09-22 09:05:01 --> Database Driver Class Initialized
INFO - 2020-09-22 09:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:05:01 --> Email Class Initialized
INFO - 2020-09-22 09:05:01 --> Controller Class Initialized
DEBUG - 2020-09-22 09:05:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:05:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:05:01 --> Model Class Initialized
INFO - 2020-09-22 09:05:01 --> Model Class Initialized
INFO - 2020-09-22 09:05:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 09:05:01 --> Final output sent to browser
DEBUG - 2020-09-22 09:05:01 --> Total execution time: 0.0389
ERROR - 2020-09-22 09:05:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:05:01 --> Config Class Initialized
INFO - 2020-09-22 09:05:01 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:05:01 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:05:01 --> Utf8 Class Initialized
INFO - 2020-09-22 09:05:01 --> URI Class Initialized
INFO - 2020-09-22 09:05:01 --> Router Class Initialized
INFO - 2020-09-22 09:05:01 --> Output Class Initialized
INFO - 2020-09-22 09:05:01 --> Security Class Initialized
DEBUG - 2020-09-22 09:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:05:01 --> Input Class Initialized
INFO - 2020-09-22 09:05:01 --> Language Class Initialized
INFO - 2020-09-22 09:05:01 --> Loader Class Initialized
INFO - 2020-09-22 09:05:01 --> Helper loaded: url_helper
INFO - 2020-09-22 09:05:01 --> Database Driver Class Initialized
INFO - 2020-09-22 09:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:05:01 --> Email Class Initialized
INFO - 2020-09-22 09:05:01 --> Controller Class Initialized
DEBUG - 2020-09-22 09:05:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:05:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:05:01 --> Model Class Initialized
INFO - 2020-09-22 09:05:01 --> Model Class Initialized
INFO - 2020-09-22 09:05:02 --> Final output sent to browser
DEBUG - 2020-09-22 09:05:02 --> Total execution time: 0.2215
ERROR - 2020-09-22 09:08:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:08:47 --> Config Class Initialized
INFO - 2020-09-22 09:08:47 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:08:47 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:08:47 --> Utf8 Class Initialized
INFO - 2020-09-22 09:08:47 --> URI Class Initialized
INFO - 2020-09-22 09:08:47 --> Router Class Initialized
INFO - 2020-09-22 09:08:47 --> Output Class Initialized
INFO - 2020-09-22 09:08:47 --> Security Class Initialized
DEBUG - 2020-09-22 09:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:08:47 --> Input Class Initialized
INFO - 2020-09-22 09:08:47 --> Language Class Initialized
INFO - 2020-09-22 09:08:47 --> Loader Class Initialized
INFO - 2020-09-22 09:08:47 --> Helper loaded: url_helper
INFO - 2020-09-22 09:08:47 --> Database Driver Class Initialized
INFO - 2020-09-22 09:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:08:47 --> Email Class Initialized
INFO - 2020-09-22 09:08:47 --> Controller Class Initialized
DEBUG - 2020-09-22 09:08:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:08:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:08:47 --> Model Class Initialized
INFO - 2020-09-22 09:08:47 --> Model Class Initialized
INFO - 2020-09-22 09:08:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 09:08:47 --> Final output sent to browser
DEBUG - 2020-09-22 09:08:47 --> Total execution time: 0.0288
ERROR - 2020-09-22 09:08:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:08:47 --> Config Class Initialized
INFO - 2020-09-22 09:08:47 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:08:47 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:08:47 --> Utf8 Class Initialized
INFO - 2020-09-22 09:08:47 --> URI Class Initialized
INFO - 2020-09-22 09:08:47 --> Router Class Initialized
INFO - 2020-09-22 09:08:47 --> Output Class Initialized
INFO - 2020-09-22 09:08:47 --> Security Class Initialized
DEBUG - 2020-09-22 09:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:08:47 --> Input Class Initialized
INFO - 2020-09-22 09:08:47 --> Language Class Initialized
INFO - 2020-09-22 09:08:47 --> Loader Class Initialized
INFO - 2020-09-22 09:08:47 --> Helper loaded: url_helper
INFO - 2020-09-22 09:08:47 --> Database Driver Class Initialized
INFO - 2020-09-22 09:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:08:47 --> Email Class Initialized
INFO - 2020-09-22 09:08:47 --> Controller Class Initialized
DEBUG - 2020-09-22 09:08:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:08:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:08:47 --> Model Class Initialized
INFO - 2020-09-22 09:08:47 --> Model Class Initialized
INFO - 2020-09-22 09:08:47 --> Final output sent to browser
DEBUG - 2020-09-22 09:08:47 --> Total execution time: 0.0257
ERROR - 2020-09-22 09:09:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:09:20 --> Config Class Initialized
INFO - 2020-09-22 09:09:20 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:09:20 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:09:20 --> Utf8 Class Initialized
INFO - 2020-09-22 09:09:20 --> URI Class Initialized
INFO - 2020-09-22 09:09:20 --> Router Class Initialized
INFO - 2020-09-22 09:09:20 --> Output Class Initialized
INFO - 2020-09-22 09:09:20 --> Security Class Initialized
DEBUG - 2020-09-22 09:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:09:20 --> Input Class Initialized
INFO - 2020-09-22 09:09:20 --> Language Class Initialized
INFO - 2020-09-22 09:09:20 --> Loader Class Initialized
INFO - 2020-09-22 09:09:20 --> Helper loaded: url_helper
INFO - 2020-09-22 09:09:20 --> Database Driver Class Initialized
INFO - 2020-09-22 09:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:09:20 --> Email Class Initialized
INFO - 2020-09-22 09:09:20 --> Controller Class Initialized
DEBUG - 2020-09-22 09:09:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:09:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:09:20 --> Model Class Initialized
INFO - 2020-09-22 09:09:20 --> Model Class Initialized
INFO - 2020-09-22 09:09:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 09:09:20 --> Final output sent to browser
DEBUG - 2020-09-22 09:09:20 --> Total execution time: 0.0251
ERROR - 2020-09-22 09:09:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:09:20 --> Config Class Initialized
INFO - 2020-09-22 09:09:20 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:09:20 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:09:20 --> Utf8 Class Initialized
INFO - 2020-09-22 09:09:20 --> URI Class Initialized
INFO - 2020-09-22 09:09:20 --> Router Class Initialized
INFO - 2020-09-22 09:09:20 --> Output Class Initialized
INFO - 2020-09-22 09:09:20 --> Security Class Initialized
DEBUG - 2020-09-22 09:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:09:20 --> Input Class Initialized
INFO - 2020-09-22 09:09:20 --> Language Class Initialized
INFO - 2020-09-22 09:09:20 --> Loader Class Initialized
INFO - 2020-09-22 09:09:20 --> Helper loaded: url_helper
INFO - 2020-09-22 09:09:20 --> Database Driver Class Initialized
INFO - 2020-09-22 09:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:09:20 --> Email Class Initialized
INFO - 2020-09-22 09:09:20 --> Controller Class Initialized
DEBUG - 2020-09-22 09:09:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:09:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:09:20 --> Model Class Initialized
INFO - 2020-09-22 09:09:20 --> Model Class Initialized
INFO - 2020-09-22 09:09:20 --> Final output sent to browser
DEBUG - 2020-09-22 09:09:20 --> Total execution time: 0.0217
ERROR - 2020-09-22 09:10:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:10:36 --> Config Class Initialized
INFO - 2020-09-22 09:10:36 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:10:36 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:10:36 --> Utf8 Class Initialized
INFO - 2020-09-22 09:10:36 --> URI Class Initialized
INFO - 2020-09-22 09:10:36 --> Router Class Initialized
INFO - 2020-09-22 09:10:36 --> Output Class Initialized
INFO - 2020-09-22 09:10:36 --> Security Class Initialized
DEBUG - 2020-09-22 09:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:10:36 --> Input Class Initialized
INFO - 2020-09-22 09:10:36 --> Language Class Initialized
INFO - 2020-09-22 09:10:36 --> Loader Class Initialized
INFO - 2020-09-22 09:10:36 --> Helper loaded: url_helper
INFO - 2020-09-22 09:10:36 --> Database Driver Class Initialized
INFO - 2020-09-22 09:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:10:36 --> Email Class Initialized
INFO - 2020-09-22 09:10:36 --> Controller Class Initialized
DEBUG - 2020-09-22 09:10:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:10:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:10:36 --> Model Class Initialized
INFO - 2020-09-22 09:10:36 --> Model Class Initialized
INFO - 2020-09-22 09:10:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 09:10:36 --> Final output sent to browser
DEBUG - 2020-09-22 09:10:36 --> Total execution time: 0.0254
ERROR - 2020-09-22 09:10:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:10:37 --> Config Class Initialized
INFO - 2020-09-22 09:10:37 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:10:37 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:10:37 --> Utf8 Class Initialized
INFO - 2020-09-22 09:10:37 --> URI Class Initialized
INFO - 2020-09-22 09:10:37 --> Router Class Initialized
INFO - 2020-09-22 09:10:37 --> Output Class Initialized
INFO - 2020-09-22 09:10:37 --> Security Class Initialized
DEBUG - 2020-09-22 09:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:10:37 --> Input Class Initialized
INFO - 2020-09-22 09:10:37 --> Language Class Initialized
INFO - 2020-09-22 09:10:37 --> Loader Class Initialized
INFO - 2020-09-22 09:10:37 --> Helper loaded: url_helper
INFO - 2020-09-22 09:10:37 --> Database Driver Class Initialized
INFO - 2020-09-22 09:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:10:37 --> Email Class Initialized
INFO - 2020-09-22 09:10:37 --> Controller Class Initialized
DEBUG - 2020-09-22 09:10:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:10:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:10:37 --> Model Class Initialized
INFO - 2020-09-22 09:10:37 --> Model Class Initialized
INFO - 2020-09-22 09:10:37 --> Final output sent to browser
DEBUG - 2020-09-22 09:10:37 --> Total execution time: 0.0212
ERROR - 2020-09-22 09:11:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:11:44 --> Config Class Initialized
INFO - 2020-09-22 09:11:44 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:11:44 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:11:44 --> Utf8 Class Initialized
INFO - 2020-09-22 09:11:44 --> URI Class Initialized
INFO - 2020-09-22 09:11:44 --> Router Class Initialized
INFO - 2020-09-22 09:11:44 --> Output Class Initialized
INFO - 2020-09-22 09:11:44 --> Security Class Initialized
DEBUG - 2020-09-22 09:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:11:44 --> Input Class Initialized
INFO - 2020-09-22 09:11:44 --> Language Class Initialized
INFO - 2020-09-22 09:11:44 --> Loader Class Initialized
INFO - 2020-09-22 09:11:44 --> Helper loaded: url_helper
INFO - 2020-09-22 09:11:44 --> Database Driver Class Initialized
INFO - 2020-09-22 09:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:11:44 --> Email Class Initialized
INFO - 2020-09-22 09:11:44 --> Controller Class Initialized
DEBUG - 2020-09-22 09:11:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:11:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:11:44 --> Model Class Initialized
INFO - 2020-09-22 09:11:44 --> Model Class Initialized
INFO - 2020-09-22 09:11:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 09:11:44 --> Final output sent to browser
DEBUG - 2020-09-22 09:11:44 --> Total execution time: 0.0272
ERROR - 2020-09-22 09:11:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:11:45 --> Config Class Initialized
INFO - 2020-09-22 09:11:45 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:11:45 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:11:45 --> Utf8 Class Initialized
INFO - 2020-09-22 09:11:45 --> URI Class Initialized
INFO - 2020-09-22 09:11:45 --> Router Class Initialized
INFO - 2020-09-22 09:11:45 --> Output Class Initialized
INFO - 2020-09-22 09:11:45 --> Security Class Initialized
DEBUG - 2020-09-22 09:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:11:45 --> Input Class Initialized
INFO - 2020-09-22 09:11:45 --> Language Class Initialized
INFO - 2020-09-22 09:11:45 --> Loader Class Initialized
INFO - 2020-09-22 09:11:45 --> Helper loaded: url_helper
INFO - 2020-09-22 09:11:45 --> Database Driver Class Initialized
INFO - 2020-09-22 09:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:11:45 --> Email Class Initialized
INFO - 2020-09-22 09:11:45 --> Controller Class Initialized
DEBUG - 2020-09-22 09:11:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:11:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:11:45 --> Model Class Initialized
INFO - 2020-09-22 09:11:45 --> Model Class Initialized
INFO - 2020-09-22 09:11:45 --> Final output sent to browser
DEBUG - 2020-09-22 09:11:45 --> Total execution time: 0.0239
ERROR - 2020-09-22 09:12:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:12:29 --> Config Class Initialized
INFO - 2020-09-22 09:12:29 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:12:29 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:12:29 --> Utf8 Class Initialized
INFO - 2020-09-22 09:12:29 --> URI Class Initialized
INFO - 2020-09-22 09:12:29 --> Router Class Initialized
INFO - 2020-09-22 09:12:29 --> Output Class Initialized
INFO - 2020-09-22 09:12:29 --> Security Class Initialized
DEBUG - 2020-09-22 09:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:12:29 --> Input Class Initialized
INFO - 2020-09-22 09:12:29 --> Language Class Initialized
INFO - 2020-09-22 09:12:29 --> Loader Class Initialized
INFO - 2020-09-22 09:12:29 --> Helper loaded: url_helper
INFO - 2020-09-22 09:12:29 --> Database Driver Class Initialized
INFO - 2020-09-22 09:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:12:29 --> Email Class Initialized
INFO - 2020-09-22 09:12:29 --> Controller Class Initialized
DEBUG - 2020-09-22 09:12:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:12:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:12:29 --> Model Class Initialized
INFO - 2020-09-22 09:12:29 --> Model Class Initialized
INFO - 2020-09-22 09:12:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 09:12:29 --> Final output sent to browser
DEBUG - 2020-09-22 09:12:29 --> Total execution time: 0.0324
ERROR - 2020-09-22 09:12:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:12:30 --> Config Class Initialized
INFO - 2020-09-22 09:12:30 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:12:30 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:12:30 --> Utf8 Class Initialized
INFO - 2020-09-22 09:12:30 --> URI Class Initialized
INFO - 2020-09-22 09:12:30 --> Router Class Initialized
INFO - 2020-09-22 09:12:30 --> Output Class Initialized
INFO - 2020-09-22 09:12:30 --> Security Class Initialized
DEBUG - 2020-09-22 09:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:12:30 --> Input Class Initialized
INFO - 2020-09-22 09:12:30 --> Language Class Initialized
INFO - 2020-09-22 09:12:30 --> Loader Class Initialized
INFO - 2020-09-22 09:12:30 --> Helper loaded: url_helper
INFO - 2020-09-22 09:12:30 --> Database Driver Class Initialized
INFO - 2020-09-22 09:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:12:30 --> Email Class Initialized
INFO - 2020-09-22 09:12:30 --> Controller Class Initialized
DEBUG - 2020-09-22 09:12:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:12:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:12:30 --> Model Class Initialized
INFO - 2020-09-22 09:12:30 --> Model Class Initialized
INFO - 2020-09-22 09:12:30 --> Final output sent to browser
DEBUG - 2020-09-22 09:12:30 --> Total execution time: 0.0230
ERROR - 2020-09-22 09:12:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:12:34 --> Config Class Initialized
INFO - 2020-09-22 09:12:34 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:12:34 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:12:34 --> Utf8 Class Initialized
INFO - 2020-09-22 09:12:34 --> URI Class Initialized
INFO - 2020-09-22 09:12:34 --> Router Class Initialized
INFO - 2020-09-22 09:12:34 --> Output Class Initialized
INFO - 2020-09-22 09:12:34 --> Security Class Initialized
DEBUG - 2020-09-22 09:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:12:34 --> Input Class Initialized
INFO - 2020-09-22 09:12:34 --> Language Class Initialized
INFO - 2020-09-22 09:12:34 --> Loader Class Initialized
INFO - 2020-09-22 09:12:34 --> Helper loaded: url_helper
INFO - 2020-09-22 09:12:34 --> Database Driver Class Initialized
INFO - 2020-09-22 09:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:12:34 --> Email Class Initialized
INFO - 2020-09-22 09:12:34 --> Controller Class Initialized
DEBUG - 2020-09-22 09:12:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:12:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:12:34 --> Model Class Initialized
INFO - 2020-09-22 09:12:34 --> Model Class Initialized
INFO - 2020-09-22 09:12:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 09:12:34 --> Final output sent to browser
DEBUG - 2020-09-22 09:12:34 --> Total execution time: 0.0234
ERROR - 2020-09-22 09:12:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:12:34 --> Config Class Initialized
INFO - 2020-09-22 09:12:34 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:12:34 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:12:34 --> Utf8 Class Initialized
INFO - 2020-09-22 09:12:34 --> URI Class Initialized
INFO - 2020-09-22 09:12:34 --> Router Class Initialized
INFO - 2020-09-22 09:12:34 --> Output Class Initialized
INFO - 2020-09-22 09:12:34 --> Security Class Initialized
DEBUG - 2020-09-22 09:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:12:34 --> Input Class Initialized
INFO - 2020-09-22 09:12:34 --> Language Class Initialized
INFO - 2020-09-22 09:12:34 --> Loader Class Initialized
INFO - 2020-09-22 09:12:34 --> Helper loaded: url_helper
INFO - 2020-09-22 09:12:34 --> Database Driver Class Initialized
INFO - 2020-09-22 09:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:12:34 --> Email Class Initialized
INFO - 2020-09-22 09:12:34 --> Controller Class Initialized
DEBUG - 2020-09-22 09:12:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:12:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:12:34 --> Model Class Initialized
INFO - 2020-09-22 09:12:34 --> Model Class Initialized
INFO - 2020-09-22 09:12:34 --> Final output sent to browser
DEBUG - 2020-09-22 09:12:34 --> Total execution time: 0.0227
ERROR - 2020-09-22 09:12:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:12:44 --> Config Class Initialized
INFO - 2020-09-22 09:12:44 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:12:44 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:12:44 --> Utf8 Class Initialized
INFO - 2020-09-22 09:12:44 --> URI Class Initialized
DEBUG - 2020-09-22 09:12:44 --> No URI present. Default controller set.
INFO - 2020-09-22 09:12:44 --> Router Class Initialized
INFO - 2020-09-22 09:12:44 --> Output Class Initialized
INFO - 2020-09-22 09:12:44 --> Security Class Initialized
DEBUG - 2020-09-22 09:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:12:44 --> Input Class Initialized
INFO - 2020-09-22 09:12:44 --> Language Class Initialized
INFO - 2020-09-22 09:12:44 --> Loader Class Initialized
INFO - 2020-09-22 09:12:44 --> Helper loaded: url_helper
INFO - 2020-09-22 09:12:44 --> Database Driver Class Initialized
INFO - 2020-09-22 09:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:12:44 --> Email Class Initialized
INFO - 2020-09-22 09:12:44 --> Controller Class Initialized
INFO - 2020-09-22 09:12:44 --> Model Class Initialized
INFO - 2020-09-22 09:12:44 --> Model Class Initialized
DEBUG - 2020-09-22 09:12:44 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:12:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 09:12:44 --> Final output sent to browser
DEBUG - 2020-09-22 09:12:44 --> Total execution time: 0.0205
ERROR - 2020-09-22 09:12:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:12:54 --> Config Class Initialized
INFO - 2020-09-22 09:12:54 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:12:54 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:12:54 --> Utf8 Class Initialized
INFO - 2020-09-22 09:12:54 --> URI Class Initialized
INFO - 2020-09-22 09:12:54 --> Router Class Initialized
INFO - 2020-09-22 09:12:54 --> Output Class Initialized
INFO - 2020-09-22 09:12:54 --> Security Class Initialized
DEBUG - 2020-09-22 09:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:12:54 --> Input Class Initialized
INFO - 2020-09-22 09:12:54 --> Language Class Initialized
INFO - 2020-09-22 09:12:54 --> Loader Class Initialized
INFO - 2020-09-22 09:12:54 --> Helper loaded: url_helper
INFO - 2020-09-22 09:12:54 --> Database Driver Class Initialized
INFO - 2020-09-22 09:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:12:54 --> Email Class Initialized
INFO - 2020-09-22 09:12:54 --> Controller Class Initialized
INFO - 2020-09-22 09:12:54 --> Model Class Initialized
ERROR - 2020-09-22 09:12:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:12:54 --> Model Class Initialized
DEBUG - 2020-09-22 09:12:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:12:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:12:54 --> Model Class Initialized
INFO - 2020-09-22 09:12:54 --> Config Class Initialized
INFO - 2020-09-22 09:12:54 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:12:54 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:12:54 --> Utf8 Class Initialized
INFO - 2020-09-22 09:12:54 --> URI Class Initialized
INFO - 2020-09-22 09:12:54 --> Router Class Initialized
INFO - 2020-09-22 09:12:54 --> Final output sent to browser
DEBUG - 2020-09-22 09:12:54 --> Total execution time: 0.0289
INFO - 2020-09-22 09:12:54 --> Output Class Initialized
INFO - 2020-09-22 09:12:54 --> Security Class Initialized
DEBUG - 2020-09-22 09:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:12:54 --> Input Class Initialized
INFO - 2020-09-22 09:12:54 --> Language Class Initialized
INFO - 2020-09-22 09:12:54 --> Loader Class Initialized
INFO - 2020-09-22 09:12:54 --> Helper loaded: url_helper
INFO - 2020-09-22 09:12:54 --> Database Driver Class Initialized
INFO - 2020-09-22 09:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:12:54 --> Email Class Initialized
INFO - 2020-09-22 09:12:54 --> Controller Class Initialized
INFO - 2020-09-22 09:12:54 --> Model Class Initialized
INFO - 2020-09-22 09:12:54 --> Model Class Initialized
DEBUG - 2020-09-22 09:12:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-22 09:12:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:12:54 --> Config Class Initialized
INFO - 2020-09-22 09:12:54 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:12:54 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:12:54 --> Utf8 Class Initialized
INFO - 2020-09-22 09:12:54 --> URI Class Initialized
INFO - 2020-09-22 09:12:54 --> Router Class Initialized
INFO - 2020-09-22 09:12:54 --> Output Class Initialized
INFO - 2020-09-22 09:12:54 --> Security Class Initialized
DEBUG - 2020-09-22 09:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:12:54 --> Input Class Initialized
INFO - 2020-09-22 09:12:54 --> Language Class Initialized
INFO - 2020-09-22 09:12:54 --> Loader Class Initialized
INFO - 2020-09-22 09:12:54 --> Helper loaded: url_helper
INFO - 2020-09-22 09:12:54 --> Database Driver Class Initialized
INFO - 2020-09-22 09:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:12:54 --> Email Class Initialized
INFO - 2020-09-22 09:12:54 --> Controller Class Initialized
DEBUG - 2020-09-22 09:12:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:12:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:12:54 --> Model Class Initialized
INFO - 2020-09-22 09:12:54 --> Model Class Initialized
INFO - 2020-09-22 09:12:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-22 09:12:54 --> Final output sent to browser
DEBUG - 2020-09-22 09:12:54 --> Total execution time: 0.0287
ERROR - 2020-09-22 09:13:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:13:00 --> Config Class Initialized
INFO - 2020-09-22 09:13:00 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:13:00 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:13:00 --> Utf8 Class Initialized
INFO - 2020-09-22 09:13:00 --> URI Class Initialized
INFO - 2020-09-22 09:13:00 --> Router Class Initialized
INFO - 2020-09-22 09:13:00 --> Output Class Initialized
INFO - 2020-09-22 09:13:00 --> Security Class Initialized
DEBUG - 2020-09-22 09:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:13:00 --> Input Class Initialized
INFO - 2020-09-22 09:13:00 --> Language Class Initialized
INFO - 2020-09-22 09:13:00 --> Loader Class Initialized
INFO - 2020-09-22 09:13:00 --> Helper loaded: url_helper
INFO - 2020-09-22 09:13:00 --> Database Driver Class Initialized
INFO - 2020-09-22 09:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:13:00 --> Email Class Initialized
INFO - 2020-09-22 09:13:00 --> Controller Class Initialized
DEBUG - 2020-09-22 09:13:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:13:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:13:00 --> Model Class Initialized
INFO - 2020-09-22 09:13:00 --> Model Class Initialized
INFO - 2020-09-22 09:13:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-22 09:13:00 --> Final output sent to browser
DEBUG - 2020-09-22 09:13:00 --> Total execution time: 0.0377
ERROR - 2020-09-22 09:13:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:13:05 --> Config Class Initialized
INFO - 2020-09-22 09:13:05 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:13:05 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:13:05 --> Utf8 Class Initialized
INFO - 2020-09-22 09:13:05 --> URI Class Initialized
INFO - 2020-09-22 09:13:05 --> Router Class Initialized
INFO - 2020-09-22 09:13:05 --> Output Class Initialized
INFO - 2020-09-22 09:13:05 --> Security Class Initialized
DEBUG - 2020-09-22 09:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:13:05 --> Input Class Initialized
INFO - 2020-09-22 09:13:05 --> Language Class Initialized
INFO - 2020-09-22 09:13:05 --> Loader Class Initialized
INFO - 2020-09-22 09:13:05 --> Helper loaded: url_helper
INFO - 2020-09-22 09:13:05 --> Database Driver Class Initialized
INFO - 2020-09-22 09:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:13:05 --> Email Class Initialized
INFO - 2020-09-22 09:13:05 --> Controller Class Initialized
DEBUG - 2020-09-22 09:13:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:13:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:13:05 --> Model Class Initialized
INFO - 2020-09-22 09:13:05 --> Model Class Initialized
INFO - 2020-09-22 09:13:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-22 09:13:05 --> Final output sent to browser
DEBUG - 2020-09-22 09:13:05 --> Total execution time: 0.0381
ERROR - 2020-09-22 09:14:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:14:35 --> Config Class Initialized
INFO - 2020-09-22 09:14:35 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:14:35 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:14:35 --> Utf8 Class Initialized
INFO - 2020-09-22 09:14:35 --> URI Class Initialized
DEBUG - 2020-09-22 09:14:35 --> No URI present. Default controller set.
INFO - 2020-09-22 09:14:35 --> Router Class Initialized
INFO - 2020-09-22 09:14:35 --> Output Class Initialized
INFO - 2020-09-22 09:14:35 --> Security Class Initialized
DEBUG - 2020-09-22 09:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:14:35 --> Input Class Initialized
INFO - 2020-09-22 09:14:35 --> Language Class Initialized
INFO - 2020-09-22 09:14:35 --> Loader Class Initialized
INFO - 2020-09-22 09:14:35 --> Helper loaded: url_helper
INFO - 2020-09-22 09:14:35 --> Database Driver Class Initialized
INFO - 2020-09-22 09:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:14:35 --> Email Class Initialized
INFO - 2020-09-22 09:14:35 --> Controller Class Initialized
INFO - 2020-09-22 09:14:35 --> Model Class Initialized
INFO - 2020-09-22 09:14:35 --> Model Class Initialized
DEBUG - 2020-09-22 09:14:35 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:14:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 09:14:35 --> Final output sent to browser
DEBUG - 2020-09-22 09:14:35 --> Total execution time: 0.0238
ERROR - 2020-09-22 09:14:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:14:38 --> Config Class Initialized
INFO - 2020-09-22 09:14:38 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:14:38 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:14:38 --> Utf8 Class Initialized
INFO - 2020-09-22 09:14:38 --> URI Class Initialized
INFO - 2020-09-22 09:14:38 --> Router Class Initialized
INFO - 2020-09-22 09:14:38 --> Output Class Initialized
INFO - 2020-09-22 09:14:38 --> Security Class Initialized
DEBUG - 2020-09-22 09:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:14:38 --> Input Class Initialized
INFO - 2020-09-22 09:14:38 --> Language Class Initialized
INFO - 2020-09-22 09:14:38 --> Loader Class Initialized
INFO - 2020-09-22 09:14:38 --> Helper loaded: url_helper
ERROR - 2020-09-22 09:14:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:14:38 --> Config Class Initialized
INFO - 2020-09-22 09:14:38 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:14:38 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:14:38 --> Utf8 Class Initialized
INFO - 2020-09-22 09:14:38 --> Database Driver Class Initialized
INFO - 2020-09-22 09:14:38 --> URI Class Initialized
INFO - 2020-09-22 09:14:38 --> Router Class Initialized
INFO - 2020-09-22 09:14:38 --> Output Class Initialized
INFO - 2020-09-22 09:14:38 --> Security Class Initialized
INFO - 2020-09-22 09:14:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-09-22 09:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:14:38 --> Input Class Initialized
INFO - 2020-09-22 09:14:38 --> Language Class Initialized
INFO - 2020-09-22 09:14:38 --> Email Class Initialized
INFO - 2020-09-22 09:14:38 --> Controller Class Initialized
INFO - 2020-09-22 09:14:38 --> Model Class Initialized
INFO - 2020-09-22 09:14:38 --> Loader Class Initialized
INFO - 2020-09-22 09:14:38 --> Model Class Initialized
DEBUG - 2020-09-22 09:14:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:14:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:14:38 --> Model Class Initialized
INFO - 2020-09-22 09:14:38 --> Helper loaded: url_helper
INFO - 2020-09-22 09:14:38 --> Final output sent to browser
DEBUG - 2020-09-22 09:14:38 --> Total execution time: 0.0240
INFO - 2020-09-22 09:14:38 --> Database Driver Class Initialized
INFO - 2020-09-22 09:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:14:38 --> Email Class Initialized
INFO - 2020-09-22 09:14:38 --> Controller Class Initialized
INFO - 2020-09-22 09:14:38 --> Model Class Initialized
INFO - 2020-09-22 09:14:38 --> Model Class Initialized
DEBUG - 2020-09-22 09:14:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-22 09:14:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:14:38 --> Config Class Initialized
INFO - 2020-09-22 09:14:38 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:14:38 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:14:38 --> Utf8 Class Initialized
INFO - 2020-09-22 09:14:38 --> URI Class Initialized
INFO - 2020-09-22 09:14:38 --> Router Class Initialized
INFO - 2020-09-22 09:14:38 --> Output Class Initialized
INFO - 2020-09-22 09:14:38 --> Security Class Initialized
DEBUG - 2020-09-22 09:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:14:38 --> Input Class Initialized
INFO - 2020-09-22 09:14:38 --> Language Class Initialized
INFO - 2020-09-22 09:14:38 --> Loader Class Initialized
INFO - 2020-09-22 09:14:38 --> Helper loaded: url_helper
INFO - 2020-09-22 09:14:38 --> Database Driver Class Initialized
INFO - 2020-09-22 09:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:14:38 --> Email Class Initialized
INFO - 2020-09-22 09:14:38 --> Controller Class Initialized
DEBUG - 2020-09-22 09:14:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:14:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:14:38 --> Model Class Initialized
INFO - 2020-09-22 09:14:38 --> Model Class Initialized
INFO - 2020-09-22 09:14:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-22 09:14:38 --> Final output sent to browser
DEBUG - 2020-09-22 09:14:38 --> Total execution time: 0.0413
ERROR - 2020-09-22 09:14:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:14:42 --> Config Class Initialized
INFO - 2020-09-22 09:14:42 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:14:42 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:14:42 --> Utf8 Class Initialized
INFO - 2020-09-22 09:14:42 --> URI Class Initialized
INFO - 2020-09-22 09:14:42 --> Router Class Initialized
INFO - 2020-09-22 09:14:42 --> Output Class Initialized
INFO - 2020-09-22 09:14:42 --> Security Class Initialized
DEBUG - 2020-09-22 09:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:14:42 --> Input Class Initialized
INFO - 2020-09-22 09:14:42 --> Language Class Initialized
INFO - 2020-09-22 09:14:42 --> Loader Class Initialized
INFO - 2020-09-22 09:14:42 --> Helper loaded: url_helper
INFO - 2020-09-22 09:14:42 --> Database Driver Class Initialized
INFO - 2020-09-22 09:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:14:42 --> Email Class Initialized
INFO - 2020-09-22 09:14:42 --> Controller Class Initialized
DEBUG - 2020-09-22 09:14:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:14:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:14:42 --> Model Class Initialized
INFO - 2020-09-22 09:14:42 --> Model Class Initialized
INFO - 2020-09-22 09:14:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 09:14:42 --> Final output sent to browser
DEBUG - 2020-09-22 09:14:42 --> Total execution time: 0.0270
ERROR - 2020-09-22 09:14:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:14:42 --> Config Class Initialized
INFO - 2020-09-22 09:14:42 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:14:42 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:14:42 --> Utf8 Class Initialized
INFO - 2020-09-22 09:14:42 --> URI Class Initialized
INFO - 2020-09-22 09:14:42 --> Router Class Initialized
INFO - 2020-09-22 09:14:42 --> Output Class Initialized
INFO - 2020-09-22 09:14:42 --> Security Class Initialized
DEBUG - 2020-09-22 09:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:14:42 --> Input Class Initialized
INFO - 2020-09-22 09:14:42 --> Language Class Initialized
INFO - 2020-09-22 09:14:42 --> Loader Class Initialized
INFO - 2020-09-22 09:14:42 --> Helper loaded: url_helper
INFO - 2020-09-22 09:14:42 --> Database Driver Class Initialized
INFO - 2020-09-22 09:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:14:42 --> Email Class Initialized
INFO - 2020-09-22 09:14:42 --> Controller Class Initialized
DEBUG - 2020-09-22 09:14:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:14:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:14:42 --> Model Class Initialized
INFO - 2020-09-22 09:14:42 --> Model Class Initialized
INFO - 2020-09-22 09:14:42 --> Final output sent to browser
DEBUG - 2020-09-22 09:14:42 --> Total execution time: 0.0284
ERROR - 2020-09-22 09:14:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:14:44 --> Config Class Initialized
INFO - 2020-09-22 09:14:44 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:14:44 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:14:44 --> Utf8 Class Initialized
INFO - 2020-09-22 09:14:44 --> URI Class Initialized
INFO - 2020-09-22 09:14:44 --> Router Class Initialized
INFO - 2020-09-22 09:14:44 --> Output Class Initialized
INFO - 2020-09-22 09:14:44 --> Security Class Initialized
DEBUG - 2020-09-22 09:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:14:44 --> Input Class Initialized
INFO - 2020-09-22 09:14:44 --> Language Class Initialized
INFO - 2020-09-22 09:14:44 --> Loader Class Initialized
INFO - 2020-09-22 09:14:44 --> Helper loaded: url_helper
INFO - 2020-09-22 09:14:44 --> Database Driver Class Initialized
INFO - 2020-09-22 09:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:14:44 --> Email Class Initialized
INFO - 2020-09-22 09:14:44 --> Controller Class Initialized
DEBUG - 2020-09-22 09:14:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:14:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:14:44 --> Model Class Initialized
INFO - 2020-09-22 09:14:44 --> Model Class Initialized
INFO - 2020-09-22 09:14:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 09:14:44 --> Final output sent to browser
DEBUG - 2020-09-22 09:14:44 --> Total execution time: 0.0243
ERROR - 2020-09-22 09:14:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:14:45 --> Config Class Initialized
INFO - 2020-09-22 09:14:45 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:14:45 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:14:45 --> Utf8 Class Initialized
INFO - 2020-09-22 09:14:45 --> URI Class Initialized
INFO - 2020-09-22 09:14:45 --> Router Class Initialized
INFO - 2020-09-22 09:14:45 --> Output Class Initialized
INFO - 2020-09-22 09:14:45 --> Security Class Initialized
DEBUG - 2020-09-22 09:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:14:45 --> Input Class Initialized
INFO - 2020-09-22 09:14:45 --> Language Class Initialized
INFO - 2020-09-22 09:14:45 --> Loader Class Initialized
INFO - 2020-09-22 09:14:45 --> Helper loaded: url_helper
INFO - 2020-09-22 09:14:45 --> Database Driver Class Initialized
INFO - 2020-09-22 09:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:14:45 --> Email Class Initialized
INFO - 2020-09-22 09:14:45 --> Controller Class Initialized
DEBUG - 2020-09-22 09:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:14:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:14:45 --> Model Class Initialized
INFO - 2020-09-22 09:14:45 --> Model Class Initialized
INFO - 2020-09-22 09:14:45 --> Final output sent to browser
DEBUG - 2020-09-22 09:14:45 --> Total execution time: 0.0250
ERROR - 2020-09-22 09:15:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:15:23 --> Config Class Initialized
INFO - 2020-09-22 09:15:23 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:15:23 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:15:23 --> Utf8 Class Initialized
INFO - 2020-09-22 09:15:23 --> URI Class Initialized
INFO - 2020-09-22 09:15:23 --> Router Class Initialized
INFO - 2020-09-22 09:15:23 --> Output Class Initialized
INFO - 2020-09-22 09:15:23 --> Security Class Initialized
DEBUG - 2020-09-22 09:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:15:23 --> Input Class Initialized
INFO - 2020-09-22 09:15:23 --> Language Class Initialized
INFO - 2020-09-22 09:15:23 --> Loader Class Initialized
INFO - 2020-09-22 09:15:23 --> Helper loaded: url_helper
INFO - 2020-09-22 09:15:23 --> Database Driver Class Initialized
INFO - 2020-09-22 09:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:15:23 --> Email Class Initialized
INFO - 2020-09-22 09:15:23 --> Controller Class Initialized
DEBUG - 2020-09-22 09:15:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:15:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:15:23 --> Model Class Initialized
INFO - 2020-09-22 09:15:23 --> Model Class Initialized
INFO - 2020-09-22 09:15:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 09:15:23 --> Final output sent to browser
DEBUG - 2020-09-22 09:15:23 --> Total execution time: 0.0244
ERROR - 2020-09-22 09:15:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:15:24 --> Config Class Initialized
INFO - 2020-09-22 09:15:24 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:15:24 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:15:24 --> Utf8 Class Initialized
INFO - 2020-09-22 09:15:24 --> URI Class Initialized
INFO - 2020-09-22 09:15:24 --> Router Class Initialized
INFO - 2020-09-22 09:15:24 --> Output Class Initialized
INFO - 2020-09-22 09:15:24 --> Security Class Initialized
DEBUG - 2020-09-22 09:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:15:24 --> Input Class Initialized
INFO - 2020-09-22 09:15:24 --> Language Class Initialized
INFO - 2020-09-22 09:15:24 --> Loader Class Initialized
INFO - 2020-09-22 09:15:24 --> Helper loaded: url_helper
INFO - 2020-09-22 09:15:24 --> Database Driver Class Initialized
INFO - 2020-09-22 09:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:15:24 --> Email Class Initialized
INFO - 2020-09-22 09:15:24 --> Controller Class Initialized
DEBUG - 2020-09-22 09:15:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:15:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:15:24 --> Model Class Initialized
INFO - 2020-09-22 09:15:24 --> Model Class Initialized
INFO - 2020-09-22 09:15:24 --> Final output sent to browser
DEBUG - 2020-09-22 09:15:24 --> Total execution time: 0.0252
ERROR - 2020-09-22 09:26:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:26:07 --> Config Class Initialized
INFO - 2020-09-22 09:26:07 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:26:07 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:26:07 --> Utf8 Class Initialized
INFO - 2020-09-22 09:26:07 --> URI Class Initialized
INFO - 2020-09-22 09:26:07 --> Router Class Initialized
INFO - 2020-09-22 09:26:07 --> Output Class Initialized
INFO - 2020-09-22 09:26:07 --> Security Class Initialized
DEBUG - 2020-09-22 09:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:26:07 --> Input Class Initialized
INFO - 2020-09-22 09:26:07 --> Language Class Initialized
INFO - 2020-09-22 09:26:07 --> Loader Class Initialized
INFO - 2020-09-22 09:26:07 --> Helper loaded: url_helper
INFO - 2020-09-22 09:26:07 --> Database Driver Class Initialized
INFO - 2020-09-22 09:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:26:07 --> Email Class Initialized
INFO - 2020-09-22 09:26:07 --> Controller Class Initialized
DEBUG - 2020-09-22 09:26:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:26:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:26:07 --> Model Class Initialized
INFO - 2020-09-22 09:26:07 --> Model Class Initialized
INFO - 2020-09-22 09:26:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 09:26:07 --> Final output sent to browser
DEBUG - 2020-09-22 09:26:07 --> Total execution time: 0.0239
ERROR - 2020-09-22 09:26:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:26:07 --> Config Class Initialized
INFO - 2020-09-22 09:26:07 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:26:07 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:26:07 --> Utf8 Class Initialized
INFO - 2020-09-22 09:26:07 --> URI Class Initialized
INFO - 2020-09-22 09:26:07 --> Router Class Initialized
INFO - 2020-09-22 09:26:07 --> Output Class Initialized
INFO - 2020-09-22 09:26:07 --> Security Class Initialized
DEBUG - 2020-09-22 09:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:26:07 --> Input Class Initialized
INFO - 2020-09-22 09:26:07 --> Language Class Initialized
INFO - 2020-09-22 09:26:07 --> Loader Class Initialized
INFO - 2020-09-22 09:26:07 --> Helper loaded: url_helper
INFO - 2020-09-22 09:26:07 --> Database Driver Class Initialized
INFO - 2020-09-22 09:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:26:07 --> Email Class Initialized
INFO - 2020-09-22 09:26:07 --> Controller Class Initialized
DEBUG - 2020-09-22 09:26:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:26:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:26:07 --> Model Class Initialized
INFO - 2020-09-22 09:26:07 --> Model Class Initialized
INFO - 2020-09-22 09:26:07 --> Final output sent to browser
DEBUG - 2020-09-22 09:26:07 --> Total execution time: 0.0222
ERROR - 2020-09-22 09:26:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:26:14 --> Config Class Initialized
INFO - 2020-09-22 09:26:14 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:26:14 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:26:14 --> Utf8 Class Initialized
INFO - 2020-09-22 09:26:14 --> URI Class Initialized
INFO - 2020-09-22 09:26:14 --> Router Class Initialized
INFO - 2020-09-22 09:26:14 --> Output Class Initialized
INFO - 2020-09-22 09:26:14 --> Security Class Initialized
DEBUG - 2020-09-22 09:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:26:14 --> Input Class Initialized
INFO - 2020-09-22 09:26:14 --> Language Class Initialized
INFO - 2020-09-22 09:26:14 --> Loader Class Initialized
INFO - 2020-09-22 09:26:14 --> Helper loaded: url_helper
INFO - 2020-09-22 09:26:14 --> Database Driver Class Initialized
INFO - 2020-09-22 09:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:26:14 --> Email Class Initialized
INFO - 2020-09-22 09:26:14 --> Controller Class Initialized
DEBUG - 2020-09-22 09:26:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:26:14 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-22 09:26:14 --> Severity: Warning --> Invalid argument supplied for foreach() /home/purpu1ex/public_html/carsm/application/controllers/Sale_rep.php 311
INFO - 2020-09-22 09:26:14 --> Model Class Initialized
INFO - 2020-09-22 09:26:14 --> Model Class Initialized
INFO - 2020-09-22 09:26:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 09:26:14 --> Final output sent to browser
DEBUG - 2020-09-22 09:26:14 --> Total execution time: 0.0272
ERROR - 2020-09-22 09:26:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:26:14 --> Config Class Initialized
INFO - 2020-09-22 09:26:14 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:26:14 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:26:14 --> Utf8 Class Initialized
INFO - 2020-09-22 09:26:14 --> URI Class Initialized
INFO - 2020-09-22 09:26:14 --> Router Class Initialized
INFO - 2020-09-22 09:26:14 --> Output Class Initialized
INFO - 2020-09-22 09:26:14 --> Security Class Initialized
DEBUG - 2020-09-22 09:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:26:14 --> Input Class Initialized
INFO - 2020-09-22 09:26:14 --> Language Class Initialized
INFO - 2020-09-22 09:26:14 --> Loader Class Initialized
INFO - 2020-09-22 09:26:14 --> Helper loaded: url_helper
INFO - 2020-09-22 09:26:14 --> Database Driver Class Initialized
INFO - 2020-09-22 09:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:26:14 --> Email Class Initialized
INFO - 2020-09-22 09:26:14 --> Controller Class Initialized
DEBUG - 2020-09-22 09:26:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:26:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:26:14 --> Model Class Initialized
INFO - 2020-09-22 09:26:14 --> Model Class Initialized
INFO - 2020-09-22 09:26:14 --> Final output sent to browser
DEBUG - 2020-09-22 09:26:14 --> Total execution time: 0.0271
ERROR - 2020-09-22 09:27:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:27:02 --> Config Class Initialized
INFO - 2020-09-22 09:27:02 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:27:02 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:27:02 --> Utf8 Class Initialized
INFO - 2020-09-22 09:27:02 --> URI Class Initialized
INFO - 2020-09-22 09:27:02 --> Router Class Initialized
INFO - 2020-09-22 09:27:02 --> Output Class Initialized
INFO - 2020-09-22 09:27:02 --> Security Class Initialized
DEBUG - 2020-09-22 09:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:27:02 --> Input Class Initialized
INFO - 2020-09-22 09:27:02 --> Language Class Initialized
INFO - 2020-09-22 09:27:02 --> Loader Class Initialized
INFO - 2020-09-22 09:27:02 --> Helper loaded: url_helper
INFO - 2020-09-22 09:27:02 --> Database Driver Class Initialized
INFO - 2020-09-22 09:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:27:02 --> Email Class Initialized
INFO - 2020-09-22 09:27:02 --> Controller Class Initialized
DEBUG - 2020-09-22 09:27:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:27:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:27:02 --> Model Class Initialized
INFO - 2020-09-22 09:27:02 --> Model Class Initialized
INFO - 2020-09-22 09:27:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 09:27:02 --> Final output sent to browser
DEBUG - 2020-09-22 09:27:02 --> Total execution time: 0.0253
ERROR - 2020-09-22 09:27:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:27:02 --> Config Class Initialized
INFO - 2020-09-22 09:27:02 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:27:02 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:27:02 --> Utf8 Class Initialized
INFO - 2020-09-22 09:27:02 --> URI Class Initialized
INFO - 2020-09-22 09:27:02 --> Router Class Initialized
INFO - 2020-09-22 09:27:02 --> Output Class Initialized
INFO - 2020-09-22 09:27:02 --> Security Class Initialized
DEBUG - 2020-09-22 09:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:27:02 --> Input Class Initialized
INFO - 2020-09-22 09:27:02 --> Language Class Initialized
INFO - 2020-09-22 09:27:02 --> Loader Class Initialized
INFO - 2020-09-22 09:27:02 --> Helper loaded: url_helper
INFO - 2020-09-22 09:27:02 --> Database Driver Class Initialized
INFO - 2020-09-22 09:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:27:02 --> Email Class Initialized
INFO - 2020-09-22 09:27:02 --> Controller Class Initialized
DEBUG - 2020-09-22 09:27:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:27:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:27:02 --> Model Class Initialized
INFO - 2020-09-22 09:27:02 --> Model Class Initialized
INFO - 2020-09-22 09:27:02 --> Final output sent to browser
DEBUG - 2020-09-22 09:27:02 --> Total execution time: 0.0233
ERROR - 2020-09-22 09:27:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:27:06 --> Config Class Initialized
INFO - 2020-09-22 09:27:06 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:27:06 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:27:06 --> Utf8 Class Initialized
INFO - 2020-09-22 09:27:06 --> URI Class Initialized
INFO - 2020-09-22 09:27:06 --> Router Class Initialized
INFO - 2020-09-22 09:27:06 --> Output Class Initialized
INFO - 2020-09-22 09:27:06 --> Security Class Initialized
DEBUG - 2020-09-22 09:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:27:06 --> Input Class Initialized
INFO - 2020-09-22 09:27:06 --> Language Class Initialized
INFO - 2020-09-22 09:27:06 --> Loader Class Initialized
INFO - 2020-09-22 09:27:06 --> Helper loaded: url_helper
INFO - 2020-09-22 09:27:06 --> Database Driver Class Initialized
INFO - 2020-09-22 09:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:27:06 --> Email Class Initialized
INFO - 2020-09-22 09:27:06 --> Controller Class Initialized
DEBUG - 2020-09-22 09:27:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:27:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:27:06 --> Model Class Initialized
INFO - 2020-09-22 09:27:06 --> Model Class Initialized
INFO - 2020-09-22 09:27:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 09:27:06 --> Final output sent to browser
DEBUG - 2020-09-22 09:27:06 --> Total execution time: 0.0233
ERROR - 2020-09-22 09:27:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:27:07 --> Config Class Initialized
INFO - 2020-09-22 09:27:07 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:27:07 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:27:07 --> Utf8 Class Initialized
INFO - 2020-09-22 09:27:07 --> URI Class Initialized
INFO - 2020-09-22 09:27:07 --> Router Class Initialized
INFO - 2020-09-22 09:27:07 --> Output Class Initialized
INFO - 2020-09-22 09:27:07 --> Security Class Initialized
DEBUG - 2020-09-22 09:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:27:07 --> Input Class Initialized
INFO - 2020-09-22 09:27:07 --> Language Class Initialized
INFO - 2020-09-22 09:27:07 --> Loader Class Initialized
INFO - 2020-09-22 09:27:07 --> Helper loaded: url_helper
INFO - 2020-09-22 09:27:07 --> Database Driver Class Initialized
INFO - 2020-09-22 09:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:27:07 --> Email Class Initialized
INFO - 2020-09-22 09:27:07 --> Controller Class Initialized
DEBUG - 2020-09-22 09:27:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:27:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:27:07 --> Model Class Initialized
INFO - 2020-09-22 09:27:07 --> Model Class Initialized
INFO - 2020-09-22 09:27:07 --> Final output sent to browser
DEBUG - 2020-09-22 09:27:07 --> Total execution time: 0.0238
ERROR - 2020-09-22 09:29:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:29:27 --> Config Class Initialized
INFO - 2020-09-22 09:29:27 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:29:27 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:29:27 --> Utf8 Class Initialized
INFO - 2020-09-22 09:29:27 --> URI Class Initialized
INFO - 2020-09-22 09:29:27 --> Router Class Initialized
INFO - 2020-09-22 09:29:27 --> Output Class Initialized
INFO - 2020-09-22 09:29:27 --> Security Class Initialized
DEBUG - 2020-09-22 09:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:29:27 --> Input Class Initialized
INFO - 2020-09-22 09:29:27 --> Language Class Initialized
INFO - 2020-09-22 09:29:27 --> Loader Class Initialized
INFO - 2020-09-22 09:29:27 --> Helper loaded: url_helper
INFO - 2020-09-22 09:29:27 --> Database Driver Class Initialized
INFO - 2020-09-22 09:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:29:27 --> Email Class Initialized
INFO - 2020-09-22 09:29:27 --> Controller Class Initialized
DEBUG - 2020-09-22 09:29:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:29:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:29:27 --> Model Class Initialized
INFO - 2020-09-22 09:29:27 --> Model Class Initialized
INFO - 2020-09-22 09:29:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 09:29:27 --> Final output sent to browser
DEBUG - 2020-09-22 09:29:27 --> Total execution time: 0.0239
ERROR - 2020-09-22 09:29:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:29:27 --> Config Class Initialized
INFO - 2020-09-22 09:29:27 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:29:27 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:29:27 --> Utf8 Class Initialized
INFO - 2020-09-22 09:29:27 --> URI Class Initialized
INFO - 2020-09-22 09:29:27 --> Router Class Initialized
INFO - 2020-09-22 09:29:27 --> Output Class Initialized
INFO - 2020-09-22 09:29:27 --> Security Class Initialized
DEBUG - 2020-09-22 09:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:29:27 --> Input Class Initialized
INFO - 2020-09-22 09:29:27 --> Language Class Initialized
INFO - 2020-09-22 09:29:27 --> Loader Class Initialized
INFO - 2020-09-22 09:29:27 --> Helper loaded: url_helper
INFO - 2020-09-22 09:29:27 --> Database Driver Class Initialized
INFO - 2020-09-22 09:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:29:27 --> Email Class Initialized
INFO - 2020-09-22 09:29:27 --> Controller Class Initialized
DEBUG - 2020-09-22 09:29:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:29:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:29:27 --> Model Class Initialized
INFO - 2020-09-22 09:29:27 --> Model Class Initialized
INFO - 2020-09-22 09:29:27 --> Final output sent to browser
DEBUG - 2020-09-22 09:29:27 --> Total execution time: 0.0219
ERROR - 2020-09-22 09:30:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:30:07 --> Config Class Initialized
INFO - 2020-09-22 09:30:07 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:30:07 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:30:07 --> Utf8 Class Initialized
INFO - 2020-09-22 09:30:07 --> URI Class Initialized
INFO - 2020-09-22 09:30:07 --> Router Class Initialized
INFO - 2020-09-22 09:30:07 --> Output Class Initialized
INFO - 2020-09-22 09:30:07 --> Security Class Initialized
DEBUG - 2020-09-22 09:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:30:07 --> Input Class Initialized
INFO - 2020-09-22 09:30:07 --> Language Class Initialized
INFO - 2020-09-22 09:30:07 --> Loader Class Initialized
INFO - 2020-09-22 09:30:07 --> Helper loaded: url_helper
INFO - 2020-09-22 09:30:07 --> Database Driver Class Initialized
INFO - 2020-09-22 09:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:30:07 --> Email Class Initialized
INFO - 2020-09-22 09:30:07 --> Controller Class Initialized
DEBUG - 2020-09-22 09:30:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:30:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:30:07 --> Model Class Initialized
INFO - 2020-09-22 09:30:07 --> Model Class Initialized
INFO - 2020-09-22 09:30:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 09:30:07 --> Final output sent to browser
DEBUG - 2020-09-22 09:30:07 --> Total execution time: 0.0285
ERROR - 2020-09-22 09:30:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:30:07 --> Config Class Initialized
INFO - 2020-09-22 09:30:07 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:30:07 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:30:07 --> Utf8 Class Initialized
INFO - 2020-09-22 09:30:07 --> URI Class Initialized
INFO - 2020-09-22 09:30:07 --> Router Class Initialized
INFO - 2020-09-22 09:30:07 --> Output Class Initialized
INFO - 2020-09-22 09:30:07 --> Security Class Initialized
DEBUG - 2020-09-22 09:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:30:07 --> Input Class Initialized
INFO - 2020-09-22 09:30:07 --> Language Class Initialized
INFO - 2020-09-22 09:30:07 --> Loader Class Initialized
INFO - 2020-09-22 09:30:07 --> Helper loaded: url_helper
INFO - 2020-09-22 09:30:07 --> Database Driver Class Initialized
INFO - 2020-09-22 09:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:30:07 --> Email Class Initialized
INFO - 2020-09-22 09:30:07 --> Controller Class Initialized
DEBUG - 2020-09-22 09:30:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:30:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:30:07 --> Model Class Initialized
INFO - 2020-09-22 09:30:07 --> Model Class Initialized
INFO - 2020-09-22 09:30:07 --> Final output sent to browser
DEBUG - 2020-09-22 09:30:07 --> Total execution time: 0.0221
ERROR - 2020-09-22 09:31:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:31:25 --> Config Class Initialized
INFO - 2020-09-22 09:31:25 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:31:25 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:31:25 --> Utf8 Class Initialized
INFO - 2020-09-22 09:31:25 --> URI Class Initialized
INFO - 2020-09-22 09:31:25 --> Router Class Initialized
INFO - 2020-09-22 09:31:25 --> Output Class Initialized
INFO - 2020-09-22 09:31:25 --> Security Class Initialized
DEBUG - 2020-09-22 09:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:31:25 --> Input Class Initialized
INFO - 2020-09-22 09:31:25 --> Language Class Initialized
INFO - 2020-09-22 09:31:25 --> Loader Class Initialized
INFO - 2020-09-22 09:31:25 --> Helper loaded: url_helper
INFO - 2020-09-22 09:31:25 --> Database Driver Class Initialized
INFO - 2020-09-22 09:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:31:25 --> Email Class Initialized
INFO - 2020-09-22 09:31:25 --> Controller Class Initialized
DEBUG - 2020-09-22 09:31:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:31:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:31:25 --> Model Class Initialized
INFO - 2020-09-22 09:31:25 --> Model Class Initialized
INFO - 2020-09-22 09:31:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 09:31:25 --> Final output sent to browser
DEBUG - 2020-09-22 09:31:25 --> Total execution time: 0.0256
ERROR - 2020-09-22 09:31:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:31:26 --> Config Class Initialized
INFO - 2020-09-22 09:31:26 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:31:26 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:31:26 --> Utf8 Class Initialized
INFO - 2020-09-22 09:31:26 --> URI Class Initialized
INFO - 2020-09-22 09:31:26 --> Router Class Initialized
INFO - 2020-09-22 09:31:26 --> Output Class Initialized
INFO - 2020-09-22 09:31:26 --> Security Class Initialized
DEBUG - 2020-09-22 09:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:31:26 --> Input Class Initialized
INFO - 2020-09-22 09:31:26 --> Language Class Initialized
INFO - 2020-09-22 09:31:26 --> Loader Class Initialized
INFO - 2020-09-22 09:31:26 --> Helper loaded: url_helper
INFO - 2020-09-22 09:31:26 --> Database Driver Class Initialized
INFO - 2020-09-22 09:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:31:26 --> Email Class Initialized
INFO - 2020-09-22 09:31:26 --> Controller Class Initialized
DEBUG - 2020-09-22 09:31:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:31:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:31:26 --> Model Class Initialized
INFO - 2020-09-22 09:31:26 --> Model Class Initialized
INFO - 2020-09-22 09:31:26 --> Final output sent to browser
DEBUG - 2020-09-22 09:31:26 --> Total execution time: 0.0239
ERROR - 2020-09-22 09:31:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:31:43 --> Config Class Initialized
INFO - 2020-09-22 09:31:43 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:31:43 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:31:43 --> Utf8 Class Initialized
INFO - 2020-09-22 09:31:43 --> URI Class Initialized
INFO - 2020-09-22 09:31:43 --> Router Class Initialized
INFO - 2020-09-22 09:31:43 --> Output Class Initialized
INFO - 2020-09-22 09:31:43 --> Security Class Initialized
DEBUG - 2020-09-22 09:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:31:43 --> Input Class Initialized
INFO - 2020-09-22 09:31:43 --> Language Class Initialized
INFO - 2020-09-22 09:31:43 --> Loader Class Initialized
INFO - 2020-09-22 09:31:43 --> Helper loaded: url_helper
INFO - 2020-09-22 09:31:43 --> Database Driver Class Initialized
INFO - 2020-09-22 09:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:31:43 --> Email Class Initialized
INFO - 2020-09-22 09:31:43 --> Controller Class Initialized
DEBUG - 2020-09-22 09:31:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:31:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:31:43 --> Model Class Initialized
INFO - 2020-09-22 09:31:43 --> Model Class Initialized
INFO - 2020-09-22 09:31:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 09:31:43 --> Final output sent to browser
DEBUG - 2020-09-22 09:31:43 --> Total execution time: 0.0297
ERROR - 2020-09-22 09:31:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:31:43 --> Config Class Initialized
INFO - 2020-09-22 09:31:43 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:31:43 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:31:43 --> Utf8 Class Initialized
INFO - 2020-09-22 09:31:43 --> URI Class Initialized
INFO - 2020-09-22 09:31:43 --> Router Class Initialized
INFO - 2020-09-22 09:31:43 --> Output Class Initialized
INFO - 2020-09-22 09:31:43 --> Security Class Initialized
DEBUG - 2020-09-22 09:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:31:43 --> Input Class Initialized
INFO - 2020-09-22 09:31:43 --> Language Class Initialized
INFO - 2020-09-22 09:31:43 --> Loader Class Initialized
INFO - 2020-09-22 09:31:43 --> Helper loaded: url_helper
INFO - 2020-09-22 09:31:43 --> Database Driver Class Initialized
INFO - 2020-09-22 09:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:31:43 --> Email Class Initialized
INFO - 2020-09-22 09:31:43 --> Controller Class Initialized
DEBUG - 2020-09-22 09:31:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:31:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:31:43 --> Model Class Initialized
INFO - 2020-09-22 09:31:43 --> Model Class Initialized
INFO - 2020-09-22 09:31:43 --> Final output sent to browser
DEBUG - 2020-09-22 09:31:43 --> Total execution time: 0.0272
ERROR - 2020-09-22 09:32:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:32:22 --> Config Class Initialized
INFO - 2020-09-22 09:32:22 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:32:22 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:32:22 --> Utf8 Class Initialized
INFO - 2020-09-22 09:32:22 --> URI Class Initialized
INFO - 2020-09-22 09:32:22 --> Router Class Initialized
INFO - 2020-09-22 09:32:22 --> Output Class Initialized
INFO - 2020-09-22 09:32:22 --> Security Class Initialized
DEBUG - 2020-09-22 09:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:32:22 --> Input Class Initialized
INFO - 2020-09-22 09:32:22 --> Language Class Initialized
INFO - 2020-09-22 09:32:22 --> Loader Class Initialized
INFO - 2020-09-22 09:32:22 --> Helper loaded: url_helper
INFO - 2020-09-22 09:32:22 --> Database Driver Class Initialized
INFO - 2020-09-22 09:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:32:22 --> Email Class Initialized
INFO - 2020-09-22 09:32:22 --> Controller Class Initialized
DEBUG - 2020-09-22 09:32:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:32:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:32:22 --> Model Class Initialized
INFO - 2020-09-22 09:32:22 --> Model Class Initialized
INFO - 2020-09-22 09:32:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 09:32:22 --> Final output sent to browser
DEBUG - 2020-09-22 09:32:22 --> Total execution time: 0.0289
ERROR - 2020-09-22 09:32:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:32:23 --> Config Class Initialized
INFO - 2020-09-22 09:32:23 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:32:23 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:32:23 --> Utf8 Class Initialized
INFO - 2020-09-22 09:32:23 --> URI Class Initialized
INFO - 2020-09-22 09:32:23 --> Router Class Initialized
INFO - 2020-09-22 09:32:23 --> Output Class Initialized
INFO - 2020-09-22 09:32:23 --> Security Class Initialized
DEBUG - 2020-09-22 09:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:32:23 --> Input Class Initialized
INFO - 2020-09-22 09:32:23 --> Language Class Initialized
INFO - 2020-09-22 09:32:23 --> Loader Class Initialized
INFO - 2020-09-22 09:32:23 --> Helper loaded: url_helper
INFO - 2020-09-22 09:32:23 --> Database Driver Class Initialized
INFO - 2020-09-22 09:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:32:23 --> Email Class Initialized
INFO - 2020-09-22 09:32:23 --> Controller Class Initialized
DEBUG - 2020-09-22 09:32:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:32:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:32:23 --> Model Class Initialized
INFO - 2020-09-22 09:32:23 --> Model Class Initialized
INFO - 2020-09-22 09:32:23 --> Final output sent to browser
DEBUG - 2020-09-22 09:32:23 --> Total execution time: 0.0220
ERROR - 2020-09-22 09:33:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:33:09 --> Config Class Initialized
INFO - 2020-09-22 09:33:09 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:33:09 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:33:09 --> Utf8 Class Initialized
INFO - 2020-09-22 09:33:09 --> URI Class Initialized
INFO - 2020-09-22 09:33:09 --> Router Class Initialized
INFO - 2020-09-22 09:33:09 --> Output Class Initialized
INFO - 2020-09-22 09:33:09 --> Security Class Initialized
DEBUG - 2020-09-22 09:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:33:09 --> Input Class Initialized
INFO - 2020-09-22 09:33:09 --> Language Class Initialized
INFO - 2020-09-22 09:33:09 --> Loader Class Initialized
INFO - 2020-09-22 09:33:09 --> Helper loaded: url_helper
INFO - 2020-09-22 09:33:09 --> Database Driver Class Initialized
INFO - 2020-09-22 09:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:33:09 --> Email Class Initialized
INFO - 2020-09-22 09:33:09 --> Controller Class Initialized
DEBUG - 2020-09-22 09:33:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:33:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:33:09 --> Model Class Initialized
INFO - 2020-09-22 09:33:09 --> Model Class Initialized
INFO - 2020-09-22 09:33:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 09:33:09 --> Final output sent to browser
DEBUG - 2020-09-22 09:33:09 --> Total execution time: 0.0230
ERROR - 2020-09-22 09:33:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:33:10 --> Config Class Initialized
INFO - 2020-09-22 09:33:10 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:33:10 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:33:10 --> Utf8 Class Initialized
INFO - 2020-09-22 09:33:10 --> URI Class Initialized
INFO - 2020-09-22 09:33:10 --> Router Class Initialized
INFO - 2020-09-22 09:33:10 --> Output Class Initialized
INFO - 2020-09-22 09:33:10 --> Security Class Initialized
DEBUG - 2020-09-22 09:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:33:10 --> Input Class Initialized
INFO - 2020-09-22 09:33:10 --> Language Class Initialized
INFO - 2020-09-22 09:33:10 --> Loader Class Initialized
INFO - 2020-09-22 09:33:10 --> Helper loaded: url_helper
INFO - 2020-09-22 09:33:10 --> Database Driver Class Initialized
INFO - 2020-09-22 09:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:33:10 --> Email Class Initialized
INFO - 2020-09-22 09:33:10 --> Controller Class Initialized
DEBUG - 2020-09-22 09:33:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:33:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:33:10 --> Model Class Initialized
INFO - 2020-09-22 09:33:10 --> Model Class Initialized
INFO - 2020-09-22 09:33:10 --> Final output sent to browser
DEBUG - 2020-09-22 09:33:10 --> Total execution time: 0.0223
ERROR - 2020-09-22 09:33:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:33:34 --> Config Class Initialized
INFO - 2020-09-22 09:33:34 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:33:34 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:33:34 --> Utf8 Class Initialized
INFO - 2020-09-22 09:33:34 --> URI Class Initialized
INFO - 2020-09-22 09:33:34 --> Router Class Initialized
INFO - 2020-09-22 09:33:34 --> Output Class Initialized
INFO - 2020-09-22 09:33:34 --> Security Class Initialized
DEBUG - 2020-09-22 09:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:33:34 --> Input Class Initialized
INFO - 2020-09-22 09:33:34 --> Language Class Initialized
INFO - 2020-09-22 09:33:34 --> Loader Class Initialized
INFO - 2020-09-22 09:33:34 --> Helper loaded: url_helper
INFO - 2020-09-22 09:33:34 --> Database Driver Class Initialized
INFO - 2020-09-22 09:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:33:34 --> Email Class Initialized
INFO - 2020-09-22 09:33:34 --> Controller Class Initialized
DEBUG - 2020-09-22 09:33:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:33:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:33:34 --> Model Class Initialized
INFO - 2020-09-22 09:33:34 --> Model Class Initialized
INFO - 2020-09-22 09:33:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 09:33:34 --> Final output sent to browser
DEBUG - 2020-09-22 09:33:34 --> Total execution time: 0.0265
ERROR - 2020-09-22 09:33:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:33:34 --> Config Class Initialized
INFO - 2020-09-22 09:33:34 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:33:34 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:33:34 --> Utf8 Class Initialized
INFO - 2020-09-22 09:33:34 --> URI Class Initialized
INFO - 2020-09-22 09:33:34 --> Router Class Initialized
INFO - 2020-09-22 09:33:34 --> Output Class Initialized
INFO - 2020-09-22 09:33:34 --> Security Class Initialized
DEBUG - 2020-09-22 09:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:33:34 --> Input Class Initialized
INFO - 2020-09-22 09:33:34 --> Language Class Initialized
INFO - 2020-09-22 09:33:34 --> Loader Class Initialized
INFO - 2020-09-22 09:33:34 --> Helper loaded: url_helper
INFO - 2020-09-22 09:33:34 --> Database Driver Class Initialized
INFO - 2020-09-22 09:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:33:34 --> Email Class Initialized
INFO - 2020-09-22 09:33:34 --> Controller Class Initialized
DEBUG - 2020-09-22 09:33:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:33:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:33:34 --> Model Class Initialized
INFO - 2020-09-22 09:33:34 --> Model Class Initialized
INFO - 2020-09-22 09:33:34 --> Final output sent to browser
DEBUG - 2020-09-22 09:33:34 --> Total execution time: 0.0253
ERROR - 2020-09-22 09:33:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:33:57 --> Config Class Initialized
INFO - 2020-09-22 09:33:57 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:33:57 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:33:57 --> Utf8 Class Initialized
INFO - 2020-09-22 09:33:57 --> URI Class Initialized
INFO - 2020-09-22 09:33:57 --> Router Class Initialized
INFO - 2020-09-22 09:33:57 --> Output Class Initialized
INFO - 2020-09-22 09:33:57 --> Security Class Initialized
DEBUG - 2020-09-22 09:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:33:57 --> Input Class Initialized
INFO - 2020-09-22 09:33:57 --> Language Class Initialized
INFO - 2020-09-22 09:33:57 --> Loader Class Initialized
INFO - 2020-09-22 09:33:57 --> Helper loaded: url_helper
INFO - 2020-09-22 09:33:57 --> Database Driver Class Initialized
INFO - 2020-09-22 09:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:33:57 --> Email Class Initialized
INFO - 2020-09-22 09:33:57 --> Controller Class Initialized
DEBUG - 2020-09-22 09:33:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:33:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:33:57 --> Model Class Initialized
INFO - 2020-09-22 09:33:57 --> Model Class Initialized
INFO - 2020-09-22 09:33:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 09:33:57 --> Final output sent to browser
DEBUG - 2020-09-22 09:33:57 --> Total execution time: 0.0338
ERROR - 2020-09-22 09:33:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:33:57 --> Config Class Initialized
INFO - 2020-09-22 09:33:57 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:33:57 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:33:57 --> Utf8 Class Initialized
INFO - 2020-09-22 09:33:57 --> URI Class Initialized
INFO - 2020-09-22 09:33:57 --> Router Class Initialized
INFO - 2020-09-22 09:33:57 --> Output Class Initialized
INFO - 2020-09-22 09:33:57 --> Security Class Initialized
DEBUG - 2020-09-22 09:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:33:57 --> Input Class Initialized
INFO - 2020-09-22 09:33:57 --> Language Class Initialized
INFO - 2020-09-22 09:33:57 --> Loader Class Initialized
INFO - 2020-09-22 09:33:57 --> Helper loaded: url_helper
INFO - 2020-09-22 09:33:57 --> Database Driver Class Initialized
INFO - 2020-09-22 09:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:33:57 --> Email Class Initialized
INFO - 2020-09-22 09:33:57 --> Controller Class Initialized
DEBUG - 2020-09-22 09:33:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:33:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:33:57 --> Model Class Initialized
INFO - 2020-09-22 09:33:57 --> Model Class Initialized
INFO - 2020-09-22 09:33:57 --> Final output sent to browser
DEBUG - 2020-09-22 09:33:57 --> Total execution time: 0.0271
ERROR - 2020-09-22 09:38:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:38:48 --> Config Class Initialized
INFO - 2020-09-22 09:38:48 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:38:48 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:38:48 --> Utf8 Class Initialized
INFO - 2020-09-22 09:38:48 --> URI Class Initialized
INFO - 2020-09-22 09:38:48 --> Router Class Initialized
INFO - 2020-09-22 09:38:48 --> Output Class Initialized
INFO - 2020-09-22 09:38:48 --> Security Class Initialized
DEBUG - 2020-09-22 09:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:38:48 --> Input Class Initialized
INFO - 2020-09-22 09:38:48 --> Language Class Initialized
INFO - 2020-09-22 09:38:48 --> Loader Class Initialized
INFO - 2020-09-22 09:38:48 --> Helper loaded: url_helper
INFO - 2020-09-22 09:38:48 --> Database Driver Class Initialized
INFO - 2020-09-22 09:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:38:48 --> Email Class Initialized
INFO - 2020-09-22 09:38:48 --> Controller Class Initialized
DEBUG - 2020-09-22 09:38:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:38:48 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-22 09:38:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:38:48 --> Config Class Initialized
INFO - 2020-09-22 09:38:48 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:38:48 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:38:48 --> Utf8 Class Initialized
INFO - 2020-09-22 09:38:48 --> URI Class Initialized
DEBUG - 2020-09-22 09:38:48 --> No URI present. Default controller set.
INFO - 2020-09-22 09:38:48 --> Router Class Initialized
INFO - 2020-09-22 09:38:48 --> Output Class Initialized
INFO - 2020-09-22 09:38:48 --> Security Class Initialized
DEBUG - 2020-09-22 09:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:38:48 --> Input Class Initialized
INFO - 2020-09-22 09:38:48 --> Language Class Initialized
INFO - 2020-09-22 09:38:48 --> Loader Class Initialized
INFO - 2020-09-22 09:38:48 --> Helper loaded: url_helper
INFO - 2020-09-22 09:38:48 --> Database Driver Class Initialized
INFO - 2020-09-22 09:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:38:48 --> Email Class Initialized
INFO - 2020-09-22 09:38:48 --> Controller Class Initialized
INFO - 2020-09-22 09:38:48 --> Model Class Initialized
INFO - 2020-09-22 09:38:48 --> Model Class Initialized
DEBUG - 2020-09-22 09:38:48 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:38:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 09:38:48 --> Final output sent to browser
DEBUG - 2020-09-22 09:38:48 --> Total execution time: 0.0190
ERROR - 2020-09-22 09:52:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:52:17 --> Config Class Initialized
INFO - 2020-09-22 09:52:17 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:52:17 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:52:17 --> Utf8 Class Initialized
INFO - 2020-09-22 09:52:17 --> URI Class Initialized
INFO - 2020-09-22 09:52:17 --> Router Class Initialized
INFO - 2020-09-22 09:52:17 --> Output Class Initialized
INFO - 2020-09-22 09:52:17 --> Security Class Initialized
DEBUG - 2020-09-22 09:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:52:17 --> Input Class Initialized
INFO - 2020-09-22 09:52:17 --> Language Class Initialized
INFO - 2020-09-22 09:52:17 --> Loader Class Initialized
INFO - 2020-09-22 09:52:17 --> Helper loaded: url_helper
INFO - 2020-09-22 09:52:17 --> Database Driver Class Initialized
INFO - 2020-09-22 09:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:52:17 --> Email Class Initialized
INFO - 2020-09-22 09:52:17 --> Controller Class Initialized
INFO - 2020-09-22 09:52:17 --> Model Class Initialized
INFO - 2020-09-22 09:52:17 --> Model Class Initialized
DEBUG - 2020-09-22 09:52:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-22 09:52:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:52:18 --> Config Class Initialized
INFO - 2020-09-22 09:52:18 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:52:18 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:52:18 --> Utf8 Class Initialized
INFO - 2020-09-22 09:52:18 --> URI Class Initialized
INFO - 2020-09-22 09:52:18 --> Router Class Initialized
INFO - 2020-09-22 09:52:18 --> Output Class Initialized
INFO - 2020-09-22 09:52:18 --> Security Class Initialized
DEBUG - 2020-09-22 09:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:52:18 --> Input Class Initialized
INFO - 2020-09-22 09:52:18 --> Language Class Initialized
INFO - 2020-09-22 09:52:18 --> Loader Class Initialized
INFO - 2020-09-22 09:52:18 --> Helper loaded: url_helper
INFO - 2020-09-22 09:52:18 --> Database Driver Class Initialized
INFO - 2020-09-22 09:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:52:18 --> Email Class Initialized
INFO - 2020-09-22 09:52:18 --> Controller Class Initialized
INFO - 2020-09-22 09:52:18 --> Model Class Initialized
INFO - 2020-09-22 09:52:18 --> Model Class Initialized
DEBUG - 2020-09-22 09:52:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:52:18 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-22 09:52:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:52:18 --> Config Class Initialized
INFO - 2020-09-22 09:52:18 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:52:18 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:52:18 --> Utf8 Class Initialized
INFO - 2020-09-22 09:52:18 --> URI Class Initialized
INFO - 2020-09-22 09:52:18 --> Router Class Initialized
INFO - 2020-09-22 09:52:18 --> Output Class Initialized
INFO - 2020-09-22 09:52:18 --> Security Class Initialized
DEBUG - 2020-09-22 09:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:52:18 --> Input Class Initialized
INFO - 2020-09-22 09:52:18 --> Language Class Initialized
INFO - 2020-09-22 09:52:18 --> Loader Class Initialized
INFO - 2020-09-22 09:52:18 --> Helper loaded: url_helper
INFO - 2020-09-22 09:52:18 --> Database Driver Class Initialized
INFO - 2020-09-22 09:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:52:18 --> Email Class Initialized
INFO - 2020-09-22 09:52:18 --> Controller Class Initialized
DEBUG - 2020-09-22 09:52:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:52:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:52:18 --> Model Class Initialized
INFO - 2020-09-22 09:52:18 --> Model Class Initialized
INFO - 2020-09-22 09:52:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-22 09:52:18 --> Final output sent to browser
DEBUG - 2020-09-22 09:52:18 --> Total execution time: 0.0331
ERROR - 2020-09-22 09:52:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:52:18 --> Config Class Initialized
INFO - 2020-09-22 09:52:18 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:52:18 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:52:18 --> Utf8 Class Initialized
INFO - 2020-09-22 09:52:18 --> URI Class Initialized
DEBUG - 2020-09-22 09:52:18 --> No URI present. Default controller set.
INFO - 2020-09-22 09:52:18 --> Router Class Initialized
INFO - 2020-09-22 09:52:18 --> Output Class Initialized
INFO - 2020-09-22 09:52:18 --> Security Class Initialized
DEBUG - 2020-09-22 09:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:52:18 --> Input Class Initialized
INFO - 2020-09-22 09:52:18 --> Language Class Initialized
INFO - 2020-09-22 09:52:18 --> Loader Class Initialized
INFO - 2020-09-22 09:52:18 --> Helper loaded: url_helper
INFO - 2020-09-22 09:52:18 --> Database Driver Class Initialized
INFO - 2020-09-22 09:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:52:18 --> Email Class Initialized
INFO - 2020-09-22 09:52:18 --> Controller Class Initialized
INFO - 2020-09-22 09:52:18 --> Model Class Initialized
INFO - 2020-09-22 09:52:18 --> Model Class Initialized
DEBUG - 2020-09-22 09:52:18 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:52:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 09:52:18 --> Final output sent to browser
DEBUG - 2020-09-22 09:52:18 --> Total execution time: 0.0204
ERROR - 2020-09-22 09:52:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:52:21 --> Config Class Initialized
INFO - 2020-09-22 09:52:21 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:52:21 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:52:21 --> Utf8 Class Initialized
INFO - 2020-09-22 09:52:21 --> URI Class Initialized
INFO - 2020-09-22 09:52:21 --> Router Class Initialized
INFO - 2020-09-22 09:52:21 --> Output Class Initialized
INFO - 2020-09-22 09:52:21 --> Security Class Initialized
DEBUG - 2020-09-22 09:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:52:21 --> Input Class Initialized
INFO - 2020-09-22 09:52:21 --> Language Class Initialized
INFO - 2020-09-22 09:52:21 --> Loader Class Initialized
INFO - 2020-09-22 09:52:21 --> Helper loaded: url_helper
INFO - 2020-09-22 09:52:21 --> Database Driver Class Initialized
INFO - 2020-09-22 09:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:52:21 --> Email Class Initialized
INFO - 2020-09-22 09:52:21 --> Controller Class Initialized
DEBUG - 2020-09-22 09:52:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:52:21 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-22 09:52:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:52:21 --> Config Class Initialized
INFO - 2020-09-22 09:52:21 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:52:21 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:52:21 --> Utf8 Class Initialized
INFO - 2020-09-22 09:52:21 --> URI Class Initialized
DEBUG - 2020-09-22 09:52:21 --> No URI present. Default controller set.
INFO - 2020-09-22 09:52:21 --> Router Class Initialized
INFO - 2020-09-22 09:52:21 --> Output Class Initialized
INFO - 2020-09-22 09:52:21 --> Security Class Initialized
DEBUG - 2020-09-22 09:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:52:21 --> Input Class Initialized
INFO - 2020-09-22 09:52:21 --> Language Class Initialized
INFO - 2020-09-22 09:52:21 --> Loader Class Initialized
INFO - 2020-09-22 09:52:21 --> Helper loaded: url_helper
INFO - 2020-09-22 09:52:21 --> Database Driver Class Initialized
INFO - 2020-09-22 09:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:52:21 --> Email Class Initialized
INFO - 2020-09-22 09:52:21 --> Controller Class Initialized
INFO - 2020-09-22 09:52:21 --> Model Class Initialized
INFO - 2020-09-22 09:52:21 --> Model Class Initialized
DEBUG - 2020-09-22 09:52:21 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:52:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 09:52:21 --> Final output sent to browser
DEBUG - 2020-09-22 09:52:21 --> Total execution time: 0.0182
ERROR - 2020-09-22 09:52:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:52:24 --> Config Class Initialized
INFO - 2020-09-22 09:52:24 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:52:24 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:52:24 --> Utf8 Class Initialized
INFO - 2020-09-22 09:52:24 --> URI Class Initialized
INFO - 2020-09-22 09:52:24 --> Router Class Initialized
INFO - 2020-09-22 09:52:24 --> Output Class Initialized
INFO - 2020-09-22 09:52:24 --> Security Class Initialized
DEBUG - 2020-09-22 09:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:52:24 --> Input Class Initialized
INFO - 2020-09-22 09:52:24 --> Language Class Initialized
INFO - 2020-09-22 09:52:24 --> Loader Class Initialized
INFO - 2020-09-22 09:52:24 --> Helper loaded: url_helper
INFO - 2020-09-22 09:52:24 --> Database Driver Class Initialized
INFO - 2020-09-22 09:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:52:24 --> Email Class Initialized
INFO - 2020-09-22 09:52:24 --> Controller Class Initialized
INFO - 2020-09-22 09:52:24 --> Model Class Initialized
INFO - 2020-09-22 09:52:24 --> Model Class Initialized
DEBUG - 2020-09-22 09:52:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:52:24 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-22 09:52:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:52:25 --> Config Class Initialized
INFO - 2020-09-22 09:52:25 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:52:25 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:52:25 --> Utf8 Class Initialized
INFO - 2020-09-22 09:52:25 --> URI Class Initialized
INFO - 2020-09-22 09:52:25 --> Router Class Initialized
INFO - 2020-09-22 09:52:25 --> Output Class Initialized
INFO - 2020-09-22 09:52:25 --> Security Class Initialized
DEBUG - 2020-09-22 09:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:52:25 --> Input Class Initialized
INFO - 2020-09-22 09:52:25 --> Language Class Initialized
INFO - 2020-09-22 09:52:25 --> Loader Class Initialized
INFO - 2020-09-22 09:52:25 --> Helper loaded: url_helper
INFO - 2020-09-22 09:52:25 --> Database Driver Class Initialized
INFO - 2020-09-22 09:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:52:25 --> Email Class Initialized
INFO - 2020-09-22 09:52:25 --> Controller Class Initialized
INFO - 2020-09-22 09:52:25 --> Model Class Initialized
INFO - 2020-09-22 09:52:25 --> Model Class Initialized
DEBUG - 2020-09-22 09:52:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-22 09:52:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:52:25 --> Config Class Initialized
INFO - 2020-09-22 09:52:25 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:52:25 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:52:25 --> Utf8 Class Initialized
INFO - 2020-09-22 09:52:25 --> URI Class Initialized
DEBUG - 2020-09-22 09:52:25 --> No URI present. Default controller set.
INFO - 2020-09-22 09:52:25 --> Router Class Initialized
INFO - 2020-09-22 09:52:25 --> Output Class Initialized
INFO - 2020-09-22 09:52:25 --> Security Class Initialized
DEBUG - 2020-09-22 09:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:52:25 --> Input Class Initialized
INFO - 2020-09-22 09:52:25 --> Language Class Initialized
INFO - 2020-09-22 09:52:25 --> Loader Class Initialized
INFO - 2020-09-22 09:52:25 --> Helper loaded: url_helper
INFO - 2020-09-22 09:52:25 --> Database Driver Class Initialized
INFO - 2020-09-22 09:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:52:25 --> Email Class Initialized
INFO - 2020-09-22 09:52:25 --> Controller Class Initialized
INFO - 2020-09-22 09:52:25 --> Model Class Initialized
INFO - 2020-09-22 09:52:25 --> Model Class Initialized
DEBUG - 2020-09-22 09:52:25 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:52:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 09:52:25 --> Final output sent to browser
DEBUG - 2020-09-22 09:52:25 --> Total execution time: 0.0207
ERROR - 2020-09-22 09:52:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:52:25 --> Config Class Initialized
INFO - 2020-09-22 09:52:25 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:52:25 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:52:25 --> Utf8 Class Initialized
INFO - 2020-09-22 09:52:25 --> URI Class Initialized
INFO - 2020-09-22 09:52:25 --> Router Class Initialized
INFO - 2020-09-22 09:52:25 --> Output Class Initialized
INFO - 2020-09-22 09:52:25 --> Security Class Initialized
DEBUG - 2020-09-22 09:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:52:25 --> Input Class Initialized
INFO - 2020-09-22 09:52:25 --> Language Class Initialized
INFO - 2020-09-22 09:52:25 --> Loader Class Initialized
INFO - 2020-09-22 09:52:25 --> Helper loaded: url_helper
INFO - 2020-09-22 09:52:25 --> Database Driver Class Initialized
INFO - 2020-09-22 09:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:52:25 --> Email Class Initialized
INFO - 2020-09-22 09:52:25 --> Controller Class Initialized
DEBUG - 2020-09-22 09:52:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:52:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:52:25 --> Model Class Initialized
INFO - 2020-09-22 09:52:25 --> Model Class Initialized
INFO - 2020-09-22 09:52:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-22 09:52:25 --> Final output sent to browser
DEBUG - 2020-09-22 09:52:25 --> Total execution time: 0.0282
ERROR - 2020-09-22 09:52:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:52:28 --> Config Class Initialized
INFO - 2020-09-22 09:52:28 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:52:28 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:52:28 --> Utf8 Class Initialized
INFO - 2020-09-22 09:52:28 --> URI Class Initialized
INFO - 2020-09-22 09:52:28 --> Router Class Initialized
INFO - 2020-09-22 09:52:28 --> Output Class Initialized
INFO - 2020-09-22 09:52:28 --> Security Class Initialized
DEBUG - 2020-09-22 09:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:52:28 --> Input Class Initialized
INFO - 2020-09-22 09:52:28 --> Language Class Initialized
INFO - 2020-09-22 09:52:28 --> Loader Class Initialized
INFO - 2020-09-22 09:52:28 --> Helper loaded: url_helper
INFO - 2020-09-22 09:52:28 --> Database Driver Class Initialized
INFO - 2020-09-22 09:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:52:28 --> Email Class Initialized
INFO - 2020-09-22 09:52:28 --> Controller Class Initialized
DEBUG - 2020-09-22 09:52:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:52:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:52:28 --> Model Class Initialized
INFO - 2020-09-22 09:52:28 --> Model Class Initialized
INFO - 2020-09-22 09:52:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 09:52:28 --> Final output sent to browser
DEBUG - 2020-09-22 09:52:28 --> Total execution time: 0.0252
ERROR - 2020-09-22 09:52:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:52:29 --> Config Class Initialized
INFO - 2020-09-22 09:52:29 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:52:29 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:52:29 --> Utf8 Class Initialized
INFO - 2020-09-22 09:52:29 --> URI Class Initialized
INFO - 2020-09-22 09:52:29 --> Router Class Initialized
INFO - 2020-09-22 09:52:29 --> Output Class Initialized
INFO - 2020-09-22 09:52:29 --> Security Class Initialized
DEBUG - 2020-09-22 09:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:52:29 --> Input Class Initialized
INFO - 2020-09-22 09:52:29 --> Language Class Initialized
INFO - 2020-09-22 09:52:29 --> Loader Class Initialized
INFO - 2020-09-22 09:52:29 --> Helper loaded: url_helper
INFO - 2020-09-22 09:52:29 --> Database Driver Class Initialized
INFO - 2020-09-22 09:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:52:29 --> Email Class Initialized
INFO - 2020-09-22 09:52:29 --> Controller Class Initialized
DEBUG - 2020-09-22 09:52:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:52:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:52:29 --> Model Class Initialized
INFO - 2020-09-22 09:52:29 --> Model Class Initialized
INFO - 2020-09-22 09:52:29 --> Final output sent to browser
DEBUG - 2020-09-22 09:52:29 --> Total execution time: 0.0236
ERROR - 2020-09-22 09:52:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:52:30 --> Config Class Initialized
INFO - 2020-09-22 09:52:30 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:52:30 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:52:30 --> Utf8 Class Initialized
INFO - 2020-09-22 09:52:30 --> URI Class Initialized
INFO - 2020-09-22 09:52:30 --> Router Class Initialized
INFO - 2020-09-22 09:52:30 --> Output Class Initialized
INFO - 2020-09-22 09:52:30 --> Security Class Initialized
DEBUG - 2020-09-22 09:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:52:30 --> Input Class Initialized
INFO - 2020-09-22 09:52:30 --> Language Class Initialized
INFO - 2020-09-22 09:52:30 --> Loader Class Initialized
INFO - 2020-09-22 09:52:30 --> Helper loaded: url_helper
INFO - 2020-09-22 09:52:30 --> Database Driver Class Initialized
INFO - 2020-09-22 09:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:52:30 --> Email Class Initialized
INFO - 2020-09-22 09:52:30 --> Controller Class Initialized
DEBUG - 2020-09-22 09:52:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:52:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:52:30 --> Model Class Initialized
INFO - 2020-09-22 09:52:30 --> Model Class Initialized
INFO - 2020-09-22 09:52:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 09:52:30 --> Final output sent to browser
DEBUG - 2020-09-22 09:52:30 --> Total execution time: 0.0264
ERROR - 2020-09-22 09:52:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:52:31 --> Config Class Initialized
INFO - 2020-09-22 09:52:31 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:52:31 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:52:31 --> Utf8 Class Initialized
INFO - 2020-09-22 09:52:31 --> URI Class Initialized
INFO - 2020-09-22 09:52:31 --> Router Class Initialized
INFO - 2020-09-22 09:52:31 --> Output Class Initialized
INFO - 2020-09-22 09:52:31 --> Security Class Initialized
DEBUG - 2020-09-22 09:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:52:31 --> Input Class Initialized
INFO - 2020-09-22 09:52:31 --> Language Class Initialized
INFO - 2020-09-22 09:52:31 --> Loader Class Initialized
INFO - 2020-09-22 09:52:31 --> Helper loaded: url_helper
INFO - 2020-09-22 09:52:31 --> Database Driver Class Initialized
INFO - 2020-09-22 09:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:52:31 --> Email Class Initialized
INFO - 2020-09-22 09:52:31 --> Controller Class Initialized
DEBUG - 2020-09-22 09:52:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:52:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:52:31 --> Model Class Initialized
INFO - 2020-09-22 09:52:31 --> Model Class Initialized
INFO - 2020-09-22 09:52:31 --> Final output sent to browser
DEBUG - 2020-09-22 09:52:31 --> Total execution time: 0.0275
ERROR - 2020-09-22 09:52:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:52:36 --> Config Class Initialized
INFO - 2020-09-22 09:52:36 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:52:36 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:52:36 --> Utf8 Class Initialized
INFO - 2020-09-22 09:52:36 --> URI Class Initialized
INFO - 2020-09-22 09:52:36 --> Router Class Initialized
INFO - 2020-09-22 09:52:36 --> Output Class Initialized
INFO - 2020-09-22 09:52:36 --> Security Class Initialized
DEBUG - 2020-09-22 09:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:52:36 --> Input Class Initialized
INFO - 2020-09-22 09:52:36 --> Language Class Initialized
INFO - 2020-09-22 09:52:36 --> Loader Class Initialized
INFO - 2020-09-22 09:52:36 --> Helper loaded: url_helper
INFO - 2020-09-22 09:52:36 --> Database Driver Class Initialized
INFO - 2020-09-22 09:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:52:36 --> Email Class Initialized
INFO - 2020-09-22 09:52:36 --> Controller Class Initialized
DEBUG - 2020-09-22 09:52:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:52:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:52:36 --> Model Class Initialized
INFO - 2020-09-22 09:52:36 --> Model Class Initialized
INFO - 2020-09-22 09:52:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 09:52:36 --> Final output sent to browser
DEBUG - 2020-09-22 09:52:36 --> Total execution time: 0.0300
ERROR - 2020-09-22 09:52:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:52:37 --> Config Class Initialized
INFO - 2020-09-22 09:52:37 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:52:37 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:52:37 --> Utf8 Class Initialized
INFO - 2020-09-22 09:52:37 --> URI Class Initialized
INFO - 2020-09-22 09:52:37 --> Router Class Initialized
INFO - 2020-09-22 09:52:37 --> Output Class Initialized
INFO - 2020-09-22 09:52:37 --> Security Class Initialized
DEBUG - 2020-09-22 09:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:52:37 --> Input Class Initialized
INFO - 2020-09-22 09:52:37 --> Language Class Initialized
INFO - 2020-09-22 09:52:37 --> Loader Class Initialized
INFO - 2020-09-22 09:52:37 --> Helper loaded: url_helper
INFO - 2020-09-22 09:52:37 --> Database Driver Class Initialized
INFO - 2020-09-22 09:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:52:37 --> Email Class Initialized
INFO - 2020-09-22 09:52:37 --> Controller Class Initialized
DEBUG - 2020-09-22 09:52:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:52:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:52:37 --> Model Class Initialized
INFO - 2020-09-22 09:52:37 --> Model Class Initialized
INFO - 2020-09-22 09:52:37 --> Final output sent to browser
DEBUG - 2020-09-22 09:52:37 --> Total execution time: 0.0245
ERROR - 2020-09-22 09:55:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:55:37 --> Config Class Initialized
INFO - 2020-09-22 09:55:37 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:55:37 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:55:37 --> Utf8 Class Initialized
INFO - 2020-09-22 09:55:37 --> URI Class Initialized
INFO - 2020-09-22 09:55:37 --> Router Class Initialized
INFO - 2020-09-22 09:55:37 --> Output Class Initialized
INFO - 2020-09-22 09:55:37 --> Security Class Initialized
DEBUG - 2020-09-22 09:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:55:37 --> Input Class Initialized
INFO - 2020-09-22 09:55:37 --> Language Class Initialized
INFO - 2020-09-22 09:55:37 --> Loader Class Initialized
INFO - 2020-09-22 09:55:37 --> Helper loaded: url_helper
INFO - 2020-09-22 09:55:37 --> Database Driver Class Initialized
INFO - 2020-09-22 09:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:55:37 --> Email Class Initialized
INFO - 2020-09-22 09:55:37 --> Controller Class Initialized
DEBUG - 2020-09-22 09:55:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:55:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:55:37 --> Model Class Initialized
INFO - 2020-09-22 09:55:37 --> Model Class Initialized
INFO - 2020-09-22 09:55:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 09:55:37 --> Final output sent to browser
DEBUG - 2020-09-22 09:55:37 --> Total execution time: 0.0263
ERROR - 2020-09-22 09:55:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:55:38 --> Config Class Initialized
INFO - 2020-09-22 09:55:38 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:55:38 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:55:38 --> Utf8 Class Initialized
INFO - 2020-09-22 09:55:38 --> URI Class Initialized
INFO - 2020-09-22 09:55:38 --> Router Class Initialized
INFO - 2020-09-22 09:55:38 --> Output Class Initialized
INFO - 2020-09-22 09:55:38 --> Security Class Initialized
DEBUG - 2020-09-22 09:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:55:38 --> Input Class Initialized
INFO - 2020-09-22 09:55:38 --> Language Class Initialized
INFO - 2020-09-22 09:55:38 --> Loader Class Initialized
INFO - 2020-09-22 09:55:38 --> Helper loaded: url_helper
INFO - 2020-09-22 09:55:38 --> Database Driver Class Initialized
INFO - 2020-09-22 09:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:55:38 --> Email Class Initialized
INFO - 2020-09-22 09:55:38 --> Controller Class Initialized
DEBUG - 2020-09-22 09:55:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:55:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:55:38 --> Model Class Initialized
INFO - 2020-09-22 09:55:38 --> Model Class Initialized
INFO - 2020-09-22 09:55:38 --> Final output sent to browser
DEBUG - 2020-09-22 09:55:38 --> Total execution time: 0.0258
ERROR - 2020-09-22 09:55:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:55:55 --> Config Class Initialized
INFO - 2020-09-22 09:55:55 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:55:55 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:55:55 --> Utf8 Class Initialized
INFO - 2020-09-22 09:55:55 --> URI Class Initialized
INFO - 2020-09-22 09:55:55 --> Router Class Initialized
INFO - 2020-09-22 09:55:55 --> Output Class Initialized
INFO - 2020-09-22 09:55:55 --> Security Class Initialized
DEBUG - 2020-09-22 09:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:55:55 --> Input Class Initialized
INFO - 2020-09-22 09:55:55 --> Language Class Initialized
INFO - 2020-09-22 09:55:55 --> Loader Class Initialized
INFO - 2020-09-22 09:55:55 --> Helper loaded: url_helper
INFO - 2020-09-22 09:55:55 --> Database Driver Class Initialized
INFO - 2020-09-22 09:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:55:55 --> Email Class Initialized
INFO - 2020-09-22 09:55:55 --> Controller Class Initialized
DEBUG - 2020-09-22 09:55:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:55:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:55:55 --> Model Class Initialized
INFO - 2020-09-22 09:55:55 --> Model Class Initialized
INFO - 2020-09-22 09:55:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 09:55:55 --> Final output sent to browser
DEBUG - 2020-09-22 09:55:55 --> Total execution time: 0.0295
ERROR - 2020-09-22 09:55:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:55:55 --> Config Class Initialized
INFO - 2020-09-22 09:55:55 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:55:55 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:55:55 --> Utf8 Class Initialized
INFO - 2020-09-22 09:55:55 --> URI Class Initialized
INFO - 2020-09-22 09:55:55 --> Router Class Initialized
INFO - 2020-09-22 09:55:55 --> Output Class Initialized
INFO - 2020-09-22 09:55:55 --> Security Class Initialized
DEBUG - 2020-09-22 09:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:55:55 --> Input Class Initialized
INFO - 2020-09-22 09:55:55 --> Language Class Initialized
INFO - 2020-09-22 09:55:55 --> Loader Class Initialized
INFO - 2020-09-22 09:55:55 --> Helper loaded: url_helper
INFO - 2020-09-22 09:55:55 --> Database Driver Class Initialized
INFO - 2020-09-22 09:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:55:55 --> Email Class Initialized
INFO - 2020-09-22 09:55:55 --> Controller Class Initialized
DEBUG - 2020-09-22 09:55:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:55:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:55:55 --> Model Class Initialized
INFO - 2020-09-22 09:55:55 --> Model Class Initialized
INFO - 2020-09-22 09:55:55 --> Final output sent to browser
DEBUG - 2020-09-22 09:55:55 --> Total execution time: 0.0242
ERROR - 2020-09-22 09:56:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:56:10 --> Config Class Initialized
INFO - 2020-09-22 09:56:10 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:56:10 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:56:10 --> Utf8 Class Initialized
INFO - 2020-09-22 09:56:10 --> URI Class Initialized
INFO - 2020-09-22 09:56:10 --> Router Class Initialized
INFO - 2020-09-22 09:56:10 --> Output Class Initialized
INFO - 2020-09-22 09:56:10 --> Security Class Initialized
DEBUG - 2020-09-22 09:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:56:10 --> Input Class Initialized
INFO - 2020-09-22 09:56:10 --> Language Class Initialized
INFO - 2020-09-22 09:56:10 --> Loader Class Initialized
INFO - 2020-09-22 09:56:10 --> Helper loaded: url_helper
INFO - 2020-09-22 09:56:10 --> Database Driver Class Initialized
INFO - 2020-09-22 09:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:56:10 --> Email Class Initialized
INFO - 2020-09-22 09:56:10 --> Controller Class Initialized
DEBUG - 2020-09-22 09:56:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:56:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:56:10 --> Model Class Initialized
INFO - 2020-09-22 09:56:10 --> Model Class Initialized
INFO - 2020-09-22 09:56:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 09:56:10 --> Final output sent to browser
DEBUG - 2020-09-22 09:56:10 --> Total execution time: 0.0266
ERROR - 2020-09-22 09:56:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:56:11 --> Config Class Initialized
INFO - 2020-09-22 09:56:11 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:56:11 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:56:11 --> Utf8 Class Initialized
INFO - 2020-09-22 09:56:11 --> URI Class Initialized
INFO - 2020-09-22 09:56:11 --> Router Class Initialized
INFO - 2020-09-22 09:56:11 --> Output Class Initialized
INFO - 2020-09-22 09:56:11 --> Security Class Initialized
DEBUG - 2020-09-22 09:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:56:11 --> Input Class Initialized
INFO - 2020-09-22 09:56:11 --> Language Class Initialized
INFO - 2020-09-22 09:56:11 --> Loader Class Initialized
INFO - 2020-09-22 09:56:11 --> Helper loaded: url_helper
INFO - 2020-09-22 09:56:11 --> Database Driver Class Initialized
INFO - 2020-09-22 09:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:56:11 --> Email Class Initialized
INFO - 2020-09-22 09:56:11 --> Controller Class Initialized
DEBUG - 2020-09-22 09:56:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:56:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:56:11 --> Model Class Initialized
INFO - 2020-09-22 09:56:11 --> Model Class Initialized
INFO - 2020-09-22 09:56:11 --> Final output sent to browser
DEBUG - 2020-09-22 09:56:11 --> Total execution time: 0.0240
ERROR - 2020-09-22 09:56:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:56:31 --> Config Class Initialized
INFO - 2020-09-22 09:56:31 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:56:31 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:56:31 --> Utf8 Class Initialized
INFO - 2020-09-22 09:56:31 --> URI Class Initialized
INFO - 2020-09-22 09:56:31 --> Router Class Initialized
INFO - 2020-09-22 09:56:31 --> Output Class Initialized
INFO - 2020-09-22 09:56:31 --> Security Class Initialized
DEBUG - 2020-09-22 09:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:56:31 --> Input Class Initialized
INFO - 2020-09-22 09:56:31 --> Language Class Initialized
INFO - 2020-09-22 09:56:31 --> Loader Class Initialized
INFO - 2020-09-22 09:56:31 --> Helper loaded: url_helper
INFO - 2020-09-22 09:56:31 --> Database Driver Class Initialized
INFO - 2020-09-22 09:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:56:31 --> Email Class Initialized
INFO - 2020-09-22 09:56:31 --> Controller Class Initialized
DEBUG - 2020-09-22 09:56:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:56:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:56:31 --> Model Class Initialized
INFO - 2020-09-22 09:56:31 --> Model Class Initialized
INFO - 2020-09-22 09:56:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 09:56:31 --> Final output sent to browser
DEBUG - 2020-09-22 09:56:31 --> Total execution time: 0.4269
ERROR - 2020-09-22 09:56:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:56:32 --> Config Class Initialized
INFO - 2020-09-22 09:56:32 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:56:32 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:56:32 --> Utf8 Class Initialized
INFO - 2020-09-22 09:56:32 --> URI Class Initialized
INFO - 2020-09-22 09:56:32 --> Router Class Initialized
INFO - 2020-09-22 09:56:32 --> Output Class Initialized
INFO - 2020-09-22 09:56:32 --> Security Class Initialized
DEBUG - 2020-09-22 09:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:56:32 --> Input Class Initialized
INFO - 2020-09-22 09:56:32 --> Language Class Initialized
INFO - 2020-09-22 09:56:32 --> Loader Class Initialized
INFO - 2020-09-22 09:56:32 --> Helper loaded: url_helper
INFO - 2020-09-22 09:56:32 --> Database Driver Class Initialized
INFO - 2020-09-22 09:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:56:32 --> Email Class Initialized
INFO - 2020-09-22 09:56:32 --> Controller Class Initialized
DEBUG - 2020-09-22 09:56:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:56:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:56:32 --> Model Class Initialized
INFO - 2020-09-22 09:56:32 --> Model Class Initialized
INFO - 2020-09-22 09:56:32 --> Final output sent to browser
DEBUG - 2020-09-22 09:56:32 --> Total execution time: 0.0275
ERROR - 2020-09-22 09:56:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:56:35 --> Config Class Initialized
INFO - 2020-09-22 09:56:35 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:56:35 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:56:35 --> Utf8 Class Initialized
INFO - 2020-09-22 09:56:35 --> URI Class Initialized
INFO - 2020-09-22 09:56:35 --> Router Class Initialized
INFO - 2020-09-22 09:56:35 --> Output Class Initialized
INFO - 2020-09-22 09:56:35 --> Security Class Initialized
DEBUG - 2020-09-22 09:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:56:35 --> Input Class Initialized
INFO - 2020-09-22 09:56:35 --> Language Class Initialized
INFO - 2020-09-22 09:56:35 --> Loader Class Initialized
INFO - 2020-09-22 09:56:35 --> Helper loaded: url_helper
INFO - 2020-09-22 09:56:35 --> Database Driver Class Initialized
INFO - 2020-09-22 09:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:56:35 --> Email Class Initialized
INFO - 2020-09-22 09:56:35 --> Controller Class Initialized
DEBUG - 2020-09-22 09:56:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:56:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:56:35 --> Model Class Initialized
INFO - 2020-09-22 09:56:35 --> Model Class Initialized
INFO - 2020-09-22 09:56:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 09:56:35 --> Final output sent to browser
DEBUG - 2020-09-22 09:56:35 --> Total execution time: 0.0223
ERROR - 2020-09-22 09:56:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:56:36 --> Config Class Initialized
INFO - 2020-09-22 09:56:36 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:56:36 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:56:36 --> Utf8 Class Initialized
INFO - 2020-09-22 09:56:36 --> URI Class Initialized
INFO - 2020-09-22 09:56:36 --> Router Class Initialized
INFO - 2020-09-22 09:56:36 --> Output Class Initialized
INFO - 2020-09-22 09:56:36 --> Security Class Initialized
DEBUG - 2020-09-22 09:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:56:36 --> Input Class Initialized
INFO - 2020-09-22 09:56:36 --> Language Class Initialized
INFO - 2020-09-22 09:56:36 --> Loader Class Initialized
INFO - 2020-09-22 09:56:36 --> Helper loaded: url_helper
INFO - 2020-09-22 09:56:36 --> Database Driver Class Initialized
INFO - 2020-09-22 09:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:56:36 --> Email Class Initialized
INFO - 2020-09-22 09:56:36 --> Controller Class Initialized
DEBUG - 2020-09-22 09:56:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:56:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:56:36 --> Model Class Initialized
INFO - 2020-09-22 09:56:36 --> Model Class Initialized
INFO - 2020-09-22 09:56:36 --> Final output sent to browser
DEBUG - 2020-09-22 09:56:36 --> Total execution time: 0.0229
ERROR - 2020-09-22 09:58:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:58:28 --> Config Class Initialized
INFO - 2020-09-22 09:58:28 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:58:28 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:58:28 --> Utf8 Class Initialized
INFO - 2020-09-22 09:58:28 --> URI Class Initialized
INFO - 2020-09-22 09:58:28 --> Router Class Initialized
INFO - 2020-09-22 09:58:28 --> Output Class Initialized
INFO - 2020-09-22 09:58:28 --> Security Class Initialized
DEBUG - 2020-09-22 09:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:58:28 --> Input Class Initialized
INFO - 2020-09-22 09:58:28 --> Language Class Initialized
INFO - 2020-09-22 09:58:28 --> Loader Class Initialized
INFO - 2020-09-22 09:58:28 --> Helper loaded: url_helper
INFO - 2020-09-22 09:58:28 --> Database Driver Class Initialized
INFO - 2020-09-22 09:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:58:28 --> Email Class Initialized
INFO - 2020-09-22 09:58:28 --> Controller Class Initialized
DEBUG - 2020-09-22 09:58:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:58:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:58:28 --> Model Class Initialized
INFO - 2020-09-22 09:58:28 --> Model Class Initialized
INFO - 2020-09-22 09:58:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 09:58:28 --> Final output sent to browser
DEBUG - 2020-09-22 09:58:28 --> Total execution time: 0.0310
ERROR - 2020-09-22 09:58:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:58:29 --> Config Class Initialized
INFO - 2020-09-22 09:58:29 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:58:29 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:58:29 --> Utf8 Class Initialized
INFO - 2020-09-22 09:58:29 --> URI Class Initialized
INFO - 2020-09-22 09:58:29 --> Router Class Initialized
INFO - 2020-09-22 09:58:29 --> Output Class Initialized
INFO - 2020-09-22 09:58:29 --> Security Class Initialized
DEBUG - 2020-09-22 09:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:58:29 --> Input Class Initialized
INFO - 2020-09-22 09:58:29 --> Language Class Initialized
INFO - 2020-09-22 09:58:29 --> Loader Class Initialized
INFO - 2020-09-22 09:58:29 --> Helper loaded: url_helper
INFO - 2020-09-22 09:58:29 --> Database Driver Class Initialized
INFO - 2020-09-22 09:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:58:29 --> Email Class Initialized
INFO - 2020-09-22 09:58:29 --> Controller Class Initialized
DEBUG - 2020-09-22 09:58:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:58:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:58:29 --> Model Class Initialized
INFO - 2020-09-22 09:58:29 --> Model Class Initialized
INFO - 2020-09-22 09:58:29 --> Final output sent to browser
DEBUG - 2020-09-22 09:58:29 --> Total execution time: 0.0248
ERROR - 2020-09-22 09:58:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:58:39 --> Config Class Initialized
INFO - 2020-09-22 09:58:39 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:58:39 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:58:39 --> Utf8 Class Initialized
INFO - 2020-09-22 09:58:39 --> URI Class Initialized
INFO - 2020-09-22 09:58:39 --> Router Class Initialized
INFO - 2020-09-22 09:58:39 --> Output Class Initialized
INFO - 2020-09-22 09:58:39 --> Security Class Initialized
DEBUG - 2020-09-22 09:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:58:39 --> Input Class Initialized
INFO - 2020-09-22 09:58:39 --> Language Class Initialized
INFO - 2020-09-22 09:58:39 --> Loader Class Initialized
INFO - 2020-09-22 09:58:39 --> Helper loaded: url_helper
INFO - 2020-09-22 09:58:39 --> Database Driver Class Initialized
INFO - 2020-09-22 09:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:58:39 --> Email Class Initialized
INFO - 2020-09-22 09:58:39 --> Controller Class Initialized
DEBUG - 2020-09-22 09:58:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:58:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:58:39 --> Model Class Initialized
INFO - 2020-09-22 09:58:39 --> Model Class Initialized
INFO - 2020-09-22 09:58:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 09:58:39 --> Final output sent to browser
DEBUG - 2020-09-22 09:58:39 --> Total execution time: 0.0367
ERROR - 2020-09-22 09:58:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 09:58:39 --> Config Class Initialized
INFO - 2020-09-22 09:58:39 --> Hooks Class Initialized
DEBUG - 2020-09-22 09:58:39 --> UTF-8 Support Enabled
INFO - 2020-09-22 09:58:39 --> Utf8 Class Initialized
INFO - 2020-09-22 09:58:39 --> URI Class Initialized
INFO - 2020-09-22 09:58:39 --> Router Class Initialized
INFO - 2020-09-22 09:58:39 --> Output Class Initialized
INFO - 2020-09-22 09:58:39 --> Security Class Initialized
DEBUG - 2020-09-22 09:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 09:58:39 --> Input Class Initialized
INFO - 2020-09-22 09:58:39 --> Language Class Initialized
INFO - 2020-09-22 09:58:39 --> Loader Class Initialized
INFO - 2020-09-22 09:58:39 --> Helper loaded: url_helper
INFO - 2020-09-22 09:58:39 --> Database Driver Class Initialized
INFO - 2020-09-22 09:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 09:58:39 --> Email Class Initialized
INFO - 2020-09-22 09:58:39 --> Controller Class Initialized
DEBUG - 2020-09-22 09:58:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 09:58:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 09:58:39 --> Model Class Initialized
INFO - 2020-09-22 09:58:39 --> Model Class Initialized
INFO - 2020-09-22 09:58:39 --> Final output sent to browser
DEBUG - 2020-09-22 09:58:39 --> Total execution time: 0.0299
ERROR - 2020-09-22 10:02:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:02:04 --> Config Class Initialized
INFO - 2020-09-22 10:02:04 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:02:04 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:02:04 --> Utf8 Class Initialized
INFO - 2020-09-22 10:02:04 --> URI Class Initialized
INFO - 2020-09-22 10:02:04 --> Router Class Initialized
INFO - 2020-09-22 10:02:04 --> Output Class Initialized
INFO - 2020-09-22 10:02:04 --> Security Class Initialized
DEBUG - 2020-09-22 10:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:02:04 --> Input Class Initialized
INFO - 2020-09-22 10:02:04 --> Language Class Initialized
INFO - 2020-09-22 10:02:04 --> Loader Class Initialized
INFO - 2020-09-22 10:02:04 --> Helper loaded: url_helper
INFO - 2020-09-22 10:02:04 --> Database Driver Class Initialized
INFO - 2020-09-22 10:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:02:04 --> Email Class Initialized
INFO - 2020-09-22 10:02:04 --> Controller Class Initialized
DEBUG - 2020-09-22 10:02:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:02:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:02:04 --> Model Class Initialized
INFO - 2020-09-22 10:02:04 --> Model Class Initialized
INFO - 2020-09-22 10:02:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 10:02:04 --> Final output sent to browser
DEBUG - 2020-09-22 10:02:04 --> Total execution time: 0.0263
ERROR - 2020-09-22 10:02:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:02:05 --> Config Class Initialized
INFO - 2020-09-22 10:02:05 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:02:05 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:02:05 --> Utf8 Class Initialized
INFO - 2020-09-22 10:02:05 --> URI Class Initialized
INFO - 2020-09-22 10:02:05 --> Router Class Initialized
INFO - 2020-09-22 10:02:05 --> Output Class Initialized
INFO - 2020-09-22 10:02:05 --> Security Class Initialized
DEBUG - 2020-09-22 10:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:02:05 --> Input Class Initialized
INFO - 2020-09-22 10:02:05 --> Language Class Initialized
INFO - 2020-09-22 10:02:05 --> Loader Class Initialized
INFO - 2020-09-22 10:02:05 --> Helper loaded: url_helper
INFO - 2020-09-22 10:02:05 --> Database Driver Class Initialized
INFO - 2020-09-22 10:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:02:05 --> Email Class Initialized
INFO - 2020-09-22 10:02:05 --> Controller Class Initialized
DEBUG - 2020-09-22 10:02:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:02:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:02:05 --> Model Class Initialized
INFO - 2020-09-22 10:02:05 --> Model Class Initialized
INFO - 2020-09-22 10:02:05 --> Final output sent to browser
DEBUG - 2020-09-22 10:02:05 --> Total execution time: 0.0254
ERROR - 2020-09-22 10:02:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:02:16 --> Config Class Initialized
INFO - 2020-09-22 10:02:16 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:02:16 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:02:16 --> Utf8 Class Initialized
INFO - 2020-09-22 10:02:16 --> URI Class Initialized
INFO - 2020-09-22 10:02:16 --> Router Class Initialized
INFO - 2020-09-22 10:02:16 --> Output Class Initialized
INFO - 2020-09-22 10:02:16 --> Security Class Initialized
DEBUG - 2020-09-22 10:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:02:16 --> Input Class Initialized
INFO - 2020-09-22 10:02:16 --> Language Class Initialized
INFO - 2020-09-22 10:02:16 --> Loader Class Initialized
INFO - 2020-09-22 10:02:16 --> Helper loaded: url_helper
INFO - 2020-09-22 10:02:16 --> Database Driver Class Initialized
INFO - 2020-09-22 10:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:02:16 --> Email Class Initialized
INFO - 2020-09-22 10:02:16 --> Controller Class Initialized
DEBUG - 2020-09-22 10:02:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:02:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:02:16 --> Model Class Initialized
INFO - 2020-09-22 10:02:16 --> Model Class Initialized
INFO - 2020-09-22 10:02:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 10:02:16 --> Final output sent to browser
DEBUG - 2020-09-22 10:02:16 --> Total execution time: 0.0276
ERROR - 2020-09-22 10:02:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:02:16 --> Config Class Initialized
INFO - 2020-09-22 10:02:16 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:02:16 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:02:16 --> Utf8 Class Initialized
INFO - 2020-09-22 10:02:16 --> URI Class Initialized
INFO - 2020-09-22 10:02:16 --> Router Class Initialized
INFO - 2020-09-22 10:02:16 --> Output Class Initialized
INFO - 2020-09-22 10:02:16 --> Security Class Initialized
DEBUG - 2020-09-22 10:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:02:16 --> Input Class Initialized
INFO - 2020-09-22 10:02:16 --> Language Class Initialized
INFO - 2020-09-22 10:02:16 --> Loader Class Initialized
INFO - 2020-09-22 10:02:16 --> Helper loaded: url_helper
INFO - 2020-09-22 10:02:16 --> Database Driver Class Initialized
INFO - 2020-09-22 10:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:02:16 --> Email Class Initialized
INFO - 2020-09-22 10:02:16 --> Controller Class Initialized
DEBUG - 2020-09-22 10:02:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:02:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:02:16 --> Model Class Initialized
INFO - 2020-09-22 10:02:16 --> Model Class Initialized
INFO - 2020-09-22 10:02:16 --> Final output sent to browser
DEBUG - 2020-09-22 10:02:16 --> Total execution time: 0.0222
ERROR - 2020-09-22 10:02:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:02:31 --> Config Class Initialized
INFO - 2020-09-22 10:02:31 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:02:31 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:02:31 --> Utf8 Class Initialized
INFO - 2020-09-22 10:02:31 --> URI Class Initialized
INFO - 2020-09-22 10:02:31 --> Router Class Initialized
INFO - 2020-09-22 10:02:31 --> Output Class Initialized
INFO - 2020-09-22 10:02:31 --> Security Class Initialized
DEBUG - 2020-09-22 10:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:02:31 --> Input Class Initialized
INFO - 2020-09-22 10:02:31 --> Language Class Initialized
INFO - 2020-09-22 10:02:31 --> Loader Class Initialized
INFO - 2020-09-22 10:02:31 --> Helper loaded: url_helper
INFO - 2020-09-22 10:02:31 --> Database Driver Class Initialized
INFO - 2020-09-22 10:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:02:31 --> Email Class Initialized
INFO - 2020-09-22 10:02:31 --> Controller Class Initialized
DEBUG - 2020-09-22 10:02:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:02:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:02:31 --> Model Class Initialized
INFO - 2020-09-22 10:02:31 --> Model Class Initialized
INFO - 2020-09-22 10:02:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 10:02:31 --> Final output sent to browser
DEBUG - 2020-09-22 10:02:31 --> Total execution time: 0.0282
ERROR - 2020-09-22 10:02:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:02:32 --> Config Class Initialized
INFO - 2020-09-22 10:02:32 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:02:32 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:02:32 --> Utf8 Class Initialized
INFO - 2020-09-22 10:02:32 --> URI Class Initialized
INFO - 2020-09-22 10:02:32 --> Router Class Initialized
INFO - 2020-09-22 10:02:32 --> Output Class Initialized
INFO - 2020-09-22 10:02:32 --> Security Class Initialized
DEBUG - 2020-09-22 10:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:02:32 --> Input Class Initialized
INFO - 2020-09-22 10:02:32 --> Language Class Initialized
INFO - 2020-09-22 10:02:32 --> Loader Class Initialized
INFO - 2020-09-22 10:02:32 --> Helper loaded: url_helper
INFO - 2020-09-22 10:02:32 --> Database Driver Class Initialized
INFO - 2020-09-22 10:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:02:32 --> Email Class Initialized
INFO - 2020-09-22 10:02:32 --> Controller Class Initialized
DEBUG - 2020-09-22 10:02:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:02:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:02:32 --> Model Class Initialized
INFO - 2020-09-22 10:02:32 --> Model Class Initialized
INFO - 2020-09-22 10:02:32 --> Final output sent to browser
DEBUG - 2020-09-22 10:02:32 --> Total execution time: 0.0270
ERROR - 2020-09-22 10:02:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:02:39 --> Config Class Initialized
INFO - 2020-09-22 10:02:39 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:02:39 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:02:39 --> Utf8 Class Initialized
INFO - 2020-09-22 10:02:39 --> URI Class Initialized
INFO - 2020-09-22 10:02:39 --> Router Class Initialized
INFO - 2020-09-22 10:02:39 --> Output Class Initialized
INFO - 2020-09-22 10:02:39 --> Security Class Initialized
DEBUG - 2020-09-22 10:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:02:39 --> Input Class Initialized
INFO - 2020-09-22 10:02:39 --> Language Class Initialized
INFO - 2020-09-22 10:02:39 --> Loader Class Initialized
INFO - 2020-09-22 10:02:39 --> Helper loaded: url_helper
INFO - 2020-09-22 10:02:39 --> Database Driver Class Initialized
INFO - 2020-09-22 10:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:02:39 --> Email Class Initialized
INFO - 2020-09-22 10:02:39 --> Controller Class Initialized
DEBUG - 2020-09-22 10:02:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:02:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:02:39 --> Model Class Initialized
INFO - 2020-09-22 10:02:39 --> Model Class Initialized
INFO - 2020-09-22 10:02:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 10:02:39 --> Final output sent to browser
DEBUG - 2020-09-22 10:02:39 --> Total execution time: 0.0271
ERROR - 2020-09-22 10:02:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:02:40 --> Config Class Initialized
INFO - 2020-09-22 10:02:40 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:02:40 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:02:40 --> Utf8 Class Initialized
INFO - 2020-09-22 10:02:40 --> URI Class Initialized
INFO - 2020-09-22 10:02:40 --> Router Class Initialized
INFO - 2020-09-22 10:02:40 --> Output Class Initialized
INFO - 2020-09-22 10:02:40 --> Security Class Initialized
DEBUG - 2020-09-22 10:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:02:40 --> Input Class Initialized
INFO - 2020-09-22 10:02:40 --> Language Class Initialized
INFO - 2020-09-22 10:02:40 --> Loader Class Initialized
INFO - 2020-09-22 10:02:40 --> Helper loaded: url_helper
INFO - 2020-09-22 10:02:40 --> Database Driver Class Initialized
INFO - 2020-09-22 10:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:02:40 --> Email Class Initialized
INFO - 2020-09-22 10:02:40 --> Controller Class Initialized
DEBUG - 2020-09-22 10:02:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:02:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:02:40 --> Model Class Initialized
INFO - 2020-09-22 10:02:40 --> Model Class Initialized
INFO - 2020-09-22 10:02:40 --> Final output sent to browser
DEBUG - 2020-09-22 10:02:40 --> Total execution time: 0.0273
ERROR - 2020-09-22 10:03:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:03:48 --> Config Class Initialized
INFO - 2020-09-22 10:03:48 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:03:48 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:03:48 --> Utf8 Class Initialized
INFO - 2020-09-22 10:03:48 --> URI Class Initialized
INFO - 2020-09-22 10:03:48 --> Router Class Initialized
INFO - 2020-09-22 10:03:48 --> Output Class Initialized
INFO - 2020-09-22 10:03:48 --> Security Class Initialized
DEBUG - 2020-09-22 10:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:03:48 --> Input Class Initialized
INFO - 2020-09-22 10:03:48 --> Language Class Initialized
INFO - 2020-09-22 10:03:48 --> Loader Class Initialized
INFO - 2020-09-22 10:03:48 --> Helper loaded: url_helper
INFO - 2020-09-22 10:03:48 --> Database Driver Class Initialized
INFO - 2020-09-22 10:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:03:48 --> Email Class Initialized
INFO - 2020-09-22 10:03:48 --> Controller Class Initialized
DEBUG - 2020-09-22 10:03:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:03:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:03:48 --> Model Class Initialized
INFO - 2020-09-22 10:03:48 --> Model Class Initialized
INFO - 2020-09-22 10:03:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 10:03:48 --> Final output sent to browser
DEBUG - 2020-09-22 10:03:48 --> Total execution time: 0.0269
ERROR - 2020-09-22 10:03:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:03:49 --> Config Class Initialized
INFO - 2020-09-22 10:03:49 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:03:49 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:03:49 --> Utf8 Class Initialized
INFO - 2020-09-22 10:03:49 --> URI Class Initialized
INFO - 2020-09-22 10:03:49 --> Router Class Initialized
INFO - 2020-09-22 10:03:49 --> Output Class Initialized
INFO - 2020-09-22 10:03:49 --> Security Class Initialized
DEBUG - 2020-09-22 10:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:03:49 --> Input Class Initialized
INFO - 2020-09-22 10:03:49 --> Language Class Initialized
INFO - 2020-09-22 10:03:49 --> Loader Class Initialized
INFO - 2020-09-22 10:03:49 --> Helper loaded: url_helper
INFO - 2020-09-22 10:03:49 --> Database Driver Class Initialized
INFO - 2020-09-22 10:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:03:49 --> Email Class Initialized
INFO - 2020-09-22 10:03:49 --> Controller Class Initialized
DEBUG - 2020-09-22 10:03:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:03:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:03:49 --> Model Class Initialized
INFO - 2020-09-22 10:03:49 --> Model Class Initialized
INFO - 2020-09-22 10:03:49 --> Final output sent to browser
DEBUG - 2020-09-22 10:03:49 --> Total execution time: 0.0244
ERROR - 2020-09-22 10:04:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:04:49 --> Config Class Initialized
INFO - 2020-09-22 10:04:49 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:04:49 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:04:49 --> Utf8 Class Initialized
INFO - 2020-09-22 10:04:49 --> URI Class Initialized
INFO - 2020-09-22 10:04:49 --> Router Class Initialized
INFO - 2020-09-22 10:04:49 --> Output Class Initialized
INFO - 2020-09-22 10:04:49 --> Security Class Initialized
DEBUG - 2020-09-22 10:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:04:49 --> Input Class Initialized
INFO - 2020-09-22 10:04:49 --> Language Class Initialized
INFO - 2020-09-22 10:04:49 --> Loader Class Initialized
INFO - 2020-09-22 10:04:49 --> Helper loaded: url_helper
INFO - 2020-09-22 10:04:49 --> Database Driver Class Initialized
INFO - 2020-09-22 10:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:04:49 --> Email Class Initialized
INFO - 2020-09-22 10:04:49 --> Controller Class Initialized
DEBUG - 2020-09-22 10:04:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:04:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:04:49 --> Model Class Initialized
INFO - 2020-09-22 10:04:49 --> Model Class Initialized
INFO - 2020-09-22 10:04:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 10:04:49 --> Final output sent to browser
DEBUG - 2020-09-22 10:04:49 --> Total execution time: 0.0248
ERROR - 2020-09-22 10:04:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:04:49 --> Config Class Initialized
INFO - 2020-09-22 10:04:49 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:04:49 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:04:49 --> Utf8 Class Initialized
INFO - 2020-09-22 10:04:49 --> URI Class Initialized
INFO - 2020-09-22 10:04:49 --> Router Class Initialized
INFO - 2020-09-22 10:04:49 --> Output Class Initialized
INFO - 2020-09-22 10:04:49 --> Security Class Initialized
DEBUG - 2020-09-22 10:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:04:49 --> Input Class Initialized
INFO - 2020-09-22 10:04:49 --> Language Class Initialized
INFO - 2020-09-22 10:04:49 --> Loader Class Initialized
INFO - 2020-09-22 10:04:49 --> Helper loaded: url_helper
INFO - 2020-09-22 10:04:49 --> Database Driver Class Initialized
INFO - 2020-09-22 10:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:04:49 --> Email Class Initialized
INFO - 2020-09-22 10:04:49 --> Controller Class Initialized
DEBUG - 2020-09-22 10:04:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:04:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:04:49 --> Model Class Initialized
INFO - 2020-09-22 10:04:49 --> Model Class Initialized
INFO - 2020-09-22 10:04:49 --> Final output sent to browser
DEBUG - 2020-09-22 10:04:49 --> Total execution time: 0.0251
ERROR - 2020-09-22 10:05:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:05:38 --> Config Class Initialized
INFO - 2020-09-22 10:05:38 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:05:38 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:05:38 --> Utf8 Class Initialized
INFO - 2020-09-22 10:05:38 --> URI Class Initialized
INFO - 2020-09-22 10:05:38 --> Router Class Initialized
INFO - 2020-09-22 10:05:38 --> Output Class Initialized
INFO - 2020-09-22 10:05:38 --> Security Class Initialized
DEBUG - 2020-09-22 10:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:05:38 --> Input Class Initialized
INFO - 2020-09-22 10:05:38 --> Language Class Initialized
INFO - 2020-09-22 10:05:38 --> Loader Class Initialized
INFO - 2020-09-22 10:05:38 --> Helper loaded: url_helper
INFO - 2020-09-22 10:05:38 --> Database Driver Class Initialized
INFO - 2020-09-22 10:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:05:38 --> Email Class Initialized
INFO - 2020-09-22 10:05:38 --> Controller Class Initialized
DEBUG - 2020-09-22 10:05:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:05:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:05:38 --> Model Class Initialized
INFO - 2020-09-22 10:05:38 --> Model Class Initialized
INFO - 2020-09-22 10:05:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 10:05:38 --> Final output sent to browser
DEBUG - 2020-09-22 10:05:38 --> Total execution time: 0.0294
ERROR - 2020-09-22 10:05:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:05:39 --> Config Class Initialized
INFO - 2020-09-22 10:05:39 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:05:39 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:05:39 --> Utf8 Class Initialized
INFO - 2020-09-22 10:05:39 --> URI Class Initialized
INFO - 2020-09-22 10:05:39 --> Router Class Initialized
INFO - 2020-09-22 10:05:39 --> Output Class Initialized
INFO - 2020-09-22 10:05:39 --> Security Class Initialized
DEBUG - 2020-09-22 10:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:05:39 --> Input Class Initialized
INFO - 2020-09-22 10:05:39 --> Language Class Initialized
INFO - 2020-09-22 10:05:39 --> Loader Class Initialized
INFO - 2020-09-22 10:05:39 --> Helper loaded: url_helper
INFO - 2020-09-22 10:05:39 --> Database Driver Class Initialized
INFO - 2020-09-22 10:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:05:39 --> Email Class Initialized
INFO - 2020-09-22 10:05:39 --> Controller Class Initialized
DEBUG - 2020-09-22 10:05:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:05:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:05:39 --> Model Class Initialized
INFO - 2020-09-22 10:05:39 --> Model Class Initialized
INFO - 2020-09-22 10:05:39 --> Final output sent to browser
DEBUG - 2020-09-22 10:05:39 --> Total execution time: 0.0249
ERROR - 2020-09-22 10:07:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:07:03 --> Config Class Initialized
INFO - 2020-09-22 10:07:03 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:07:03 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:07:03 --> Utf8 Class Initialized
INFO - 2020-09-22 10:07:03 --> URI Class Initialized
INFO - 2020-09-22 10:07:03 --> Router Class Initialized
INFO - 2020-09-22 10:07:03 --> Output Class Initialized
INFO - 2020-09-22 10:07:03 --> Security Class Initialized
DEBUG - 2020-09-22 10:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:07:03 --> Input Class Initialized
INFO - 2020-09-22 10:07:03 --> Language Class Initialized
INFO - 2020-09-22 10:07:03 --> Loader Class Initialized
INFO - 2020-09-22 10:07:03 --> Helper loaded: url_helper
INFO - 2020-09-22 10:07:03 --> Database Driver Class Initialized
INFO - 2020-09-22 10:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:07:03 --> Email Class Initialized
INFO - 2020-09-22 10:07:03 --> Controller Class Initialized
DEBUG - 2020-09-22 10:07:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:07:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:07:03 --> Model Class Initialized
INFO - 2020-09-22 10:07:03 --> Model Class Initialized
INFO - 2020-09-22 10:07:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-22 10:07:04 --> Final output sent to browser
DEBUG - 2020-09-22 10:07:04 --> Total execution time: 0.0265
ERROR - 2020-09-22 10:07:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:07:43 --> Config Class Initialized
INFO - 2020-09-22 10:07:43 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:07:43 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:07:43 --> Utf8 Class Initialized
INFO - 2020-09-22 10:07:43 --> URI Class Initialized
INFO - 2020-09-22 10:07:43 --> Router Class Initialized
INFO - 2020-09-22 10:07:43 --> Output Class Initialized
INFO - 2020-09-22 10:07:43 --> Security Class Initialized
DEBUG - 2020-09-22 10:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:07:43 --> Input Class Initialized
INFO - 2020-09-22 10:07:43 --> Language Class Initialized
INFO - 2020-09-22 10:07:43 --> Loader Class Initialized
INFO - 2020-09-22 10:07:43 --> Helper loaded: url_helper
INFO - 2020-09-22 10:07:43 --> Database Driver Class Initialized
INFO - 2020-09-22 10:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:07:43 --> Email Class Initialized
INFO - 2020-09-22 10:07:43 --> Controller Class Initialized
DEBUG - 2020-09-22 10:07:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:07:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:07:43 --> Model Class Initialized
INFO - 2020-09-22 10:07:43 --> Model Class Initialized
INFO - 2020-09-22 10:07:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-22 10:07:43 --> Final output sent to browser
DEBUG - 2020-09-22 10:07:43 --> Total execution time: 0.0251
ERROR - 2020-09-22 10:08:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:08:56 --> Config Class Initialized
INFO - 2020-09-22 10:08:56 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:08:56 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:08:56 --> Utf8 Class Initialized
INFO - 2020-09-22 10:08:56 --> URI Class Initialized
INFO - 2020-09-22 10:08:56 --> Router Class Initialized
INFO - 2020-09-22 10:08:56 --> Output Class Initialized
INFO - 2020-09-22 10:08:56 --> Security Class Initialized
DEBUG - 2020-09-22 10:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:08:56 --> Input Class Initialized
INFO - 2020-09-22 10:08:56 --> Language Class Initialized
INFO - 2020-09-22 10:08:56 --> Loader Class Initialized
INFO - 2020-09-22 10:08:56 --> Helper loaded: url_helper
INFO - 2020-09-22 10:08:56 --> Database Driver Class Initialized
INFO - 2020-09-22 10:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:08:56 --> Email Class Initialized
INFO - 2020-09-22 10:08:56 --> Controller Class Initialized
DEBUG - 2020-09-22 10:08:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:08:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:08:56 --> Model Class Initialized
INFO - 2020-09-22 10:08:56 --> Model Class Initialized
INFO - 2020-09-22 10:08:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-22 10:08:56 --> Final output sent to browser
DEBUG - 2020-09-22 10:08:56 --> Total execution time: 0.0338
ERROR - 2020-09-22 10:09:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:09:47 --> Config Class Initialized
INFO - 2020-09-22 10:09:47 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:09:47 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:09:47 --> Utf8 Class Initialized
INFO - 2020-09-22 10:09:47 --> URI Class Initialized
INFO - 2020-09-22 10:09:47 --> Router Class Initialized
INFO - 2020-09-22 10:09:47 --> Output Class Initialized
INFO - 2020-09-22 10:09:47 --> Security Class Initialized
DEBUG - 2020-09-22 10:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:09:47 --> Input Class Initialized
INFO - 2020-09-22 10:09:47 --> Language Class Initialized
INFO - 2020-09-22 10:09:47 --> Loader Class Initialized
INFO - 2020-09-22 10:09:47 --> Helper loaded: url_helper
INFO - 2020-09-22 10:09:47 --> Database Driver Class Initialized
INFO - 2020-09-22 10:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:09:47 --> Email Class Initialized
INFO - 2020-09-22 10:09:47 --> Controller Class Initialized
DEBUG - 2020-09-22 10:09:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:09:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:09:47 --> Model Class Initialized
INFO - 2020-09-22 10:09:47 --> Model Class Initialized
INFO - 2020-09-22 10:09:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-22 10:09:47 --> Final output sent to browser
DEBUG - 2020-09-22 10:09:47 --> Total execution time: 0.0238
ERROR - 2020-09-22 10:09:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:09:55 --> Config Class Initialized
INFO - 2020-09-22 10:09:55 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:09:55 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:09:55 --> Utf8 Class Initialized
INFO - 2020-09-22 10:09:55 --> URI Class Initialized
INFO - 2020-09-22 10:09:55 --> Router Class Initialized
INFO - 2020-09-22 10:09:55 --> Output Class Initialized
INFO - 2020-09-22 10:09:55 --> Security Class Initialized
DEBUG - 2020-09-22 10:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:09:55 --> Input Class Initialized
INFO - 2020-09-22 10:09:55 --> Language Class Initialized
INFO - 2020-09-22 10:09:55 --> Loader Class Initialized
INFO - 2020-09-22 10:09:55 --> Helper loaded: url_helper
INFO - 2020-09-22 10:09:55 --> Database Driver Class Initialized
INFO - 2020-09-22 10:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:09:55 --> Email Class Initialized
INFO - 2020-09-22 10:09:55 --> Controller Class Initialized
DEBUG - 2020-09-22 10:09:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:09:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:09:55 --> Model Class Initialized
INFO - 2020-09-22 10:09:55 --> Model Class Initialized
INFO - 2020-09-22 10:09:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-09-22 10:09:55 --> Final output sent to browser
DEBUG - 2020-09-22 10:09:55 --> Total execution time: 0.0343
ERROR - 2020-09-22 10:10:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:10:40 --> Config Class Initialized
INFO - 2020-09-22 10:10:40 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:10:40 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:10:40 --> Utf8 Class Initialized
INFO - 2020-09-22 10:10:40 --> URI Class Initialized
INFO - 2020-09-22 10:10:40 --> Router Class Initialized
INFO - 2020-09-22 10:10:40 --> Output Class Initialized
INFO - 2020-09-22 10:10:40 --> Security Class Initialized
DEBUG - 2020-09-22 10:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:10:40 --> Input Class Initialized
INFO - 2020-09-22 10:10:40 --> Language Class Initialized
INFO - 2020-09-22 10:10:40 --> Loader Class Initialized
INFO - 2020-09-22 10:10:40 --> Helper loaded: url_helper
INFO - 2020-09-22 10:10:40 --> Database Driver Class Initialized
INFO - 2020-09-22 10:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:10:40 --> Email Class Initialized
INFO - 2020-09-22 10:10:40 --> Controller Class Initialized
DEBUG - 2020-09-22 10:10:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:10:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:10:40 --> Model Class Initialized
INFO - 2020-09-22 10:10:40 --> Model Class Initialized
INFO - 2020-09-22 10:10:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-09-22 10:10:40 --> Final output sent to browser
DEBUG - 2020-09-22 10:10:40 --> Total execution time: 0.0239
ERROR - 2020-09-22 10:10:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:10:58 --> Config Class Initialized
INFO - 2020-09-22 10:10:58 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:10:58 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:10:58 --> Utf8 Class Initialized
INFO - 2020-09-22 10:10:58 --> URI Class Initialized
INFO - 2020-09-22 10:10:58 --> Router Class Initialized
INFO - 2020-09-22 10:10:58 --> Output Class Initialized
INFO - 2020-09-22 10:10:58 --> Security Class Initialized
DEBUG - 2020-09-22 10:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:10:58 --> Input Class Initialized
INFO - 2020-09-22 10:10:58 --> Language Class Initialized
INFO - 2020-09-22 10:10:58 --> Loader Class Initialized
INFO - 2020-09-22 10:10:58 --> Helper loaded: url_helper
INFO - 2020-09-22 10:10:58 --> Database Driver Class Initialized
INFO - 2020-09-22 10:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:10:58 --> Email Class Initialized
INFO - 2020-09-22 10:10:58 --> Controller Class Initialized
DEBUG - 2020-09-22 10:10:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:10:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:10:58 --> Model Class Initialized
INFO - 2020-09-22 10:10:58 --> Model Class Initialized
INFO - 2020-09-22 10:10:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-22 10:10:58 --> Final output sent to browser
DEBUG - 2020-09-22 10:10:58 --> Total execution time: 0.0247
ERROR - 2020-09-22 10:11:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:11:00 --> Config Class Initialized
INFO - 2020-09-22 10:11:00 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:11:00 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:11:00 --> Utf8 Class Initialized
INFO - 2020-09-22 10:11:00 --> URI Class Initialized
INFO - 2020-09-22 10:11:00 --> Router Class Initialized
INFO - 2020-09-22 10:11:00 --> Output Class Initialized
INFO - 2020-09-22 10:11:00 --> Security Class Initialized
DEBUG - 2020-09-22 10:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:11:00 --> Input Class Initialized
INFO - 2020-09-22 10:11:00 --> Language Class Initialized
INFO - 2020-09-22 10:11:00 --> Loader Class Initialized
INFO - 2020-09-22 10:11:00 --> Helper loaded: url_helper
INFO - 2020-09-22 10:11:00 --> Database Driver Class Initialized
INFO - 2020-09-22 10:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:11:00 --> Email Class Initialized
INFO - 2020-09-22 10:11:00 --> Controller Class Initialized
DEBUG - 2020-09-22 10:11:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:11:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:11:00 --> Model Class Initialized
INFO - 2020-09-22 10:11:00 --> Model Class Initialized
INFO - 2020-09-22 10:11:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-09-22 10:11:00 --> Final output sent to browser
DEBUG - 2020-09-22 10:11:00 --> Total execution time: 0.0369
ERROR - 2020-09-22 10:11:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:11:38 --> Config Class Initialized
INFO - 2020-09-22 10:11:38 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:11:38 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:11:38 --> Utf8 Class Initialized
INFO - 2020-09-22 10:11:38 --> URI Class Initialized
INFO - 2020-09-22 10:11:38 --> Router Class Initialized
INFO - 2020-09-22 10:11:38 --> Output Class Initialized
INFO - 2020-09-22 10:11:38 --> Security Class Initialized
DEBUG - 2020-09-22 10:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:11:38 --> Input Class Initialized
INFO - 2020-09-22 10:11:38 --> Language Class Initialized
INFO - 2020-09-22 10:11:38 --> Loader Class Initialized
INFO - 2020-09-22 10:11:38 --> Helper loaded: url_helper
INFO - 2020-09-22 10:11:38 --> Database Driver Class Initialized
INFO - 2020-09-22 10:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:11:38 --> Email Class Initialized
INFO - 2020-09-22 10:11:38 --> Controller Class Initialized
DEBUG - 2020-09-22 10:11:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:11:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:11:38 --> Model Class Initialized
INFO - 2020-09-22 10:11:38 --> Model Class Initialized
INFO - 2020-09-22 10:11:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-09-22 10:11:38 --> Final output sent to browser
DEBUG - 2020-09-22 10:11:38 --> Total execution time: 0.0259
ERROR - 2020-09-22 10:11:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:11:55 --> Config Class Initialized
INFO - 2020-09-22 10:11:55 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:11:55 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:11:55 --> Utf8 Class Initialized
INFO - 2020-09-22 10:11:55 --> URI Class Initialized
INFO - 2020-09-22 10:11:55 --> Router Class Initialized
INFO - 2020-09-22 10:11:55 --> Output Class Initialized
INFO - 2020-09-22 10:11:55 --> Security Class Initialized
DEBUG - 2020-09-22 10:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:11:55 --> Input Class Initialized
INFO - 2020-09-22 10:11:55 --> Language Class Initialized
INFO - 2020-09-22 10:11:55 --> Loader Class Initialized
INFO - 2020-09-22 10:11:55 --> Helper loaded: url_helper
INFO - 2020-09-22 10:11:55 --> Database Driver Class Initialized
INFO - 2020-09-22 10:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:11:55 --> Email Class Initialized
INFO - 2020-09-22 10:11:55 --> Controller Class Initialized
DEBUG - 2020-09-22 10:11:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:11:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:11:55 --> Model Class Initialized
INFO - 2020-09-22 10:11:55 --> Model Class Initialized
INFO - 2020-09-22 10:11:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-22 10:11:55 --> Final output sent to browser
DEBUG - 2020-09-22 10:11:55 --> Total execution time: 0.0296
ERROR - 2020-09-22 10:12:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:12:44 --> Config Class Initialized
INFO - 2020-09-22 10:12:44 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:12:44 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:12:44 --> Utf8 Class Initialized
INFO - 2020-09-22 10:12:44 --> URI Class Initialized
INFO - 2020-09-22 10:12:44 --> Router Class Initialized
INFO - 2020-09-22 10:12:44 --> Output Class Initialized
INFO - 2020-09-22 10:12:44 --> Security Class Initialized
DEBUG - 2020-09-22 10:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:12:44 --> Input Class Initialized
INFO - 2020-09-22 10:12:44 --> Language Class Initialized
INFO - 2020-09-22 10:12:44 --> Loader Class Initialized
INFO - 2020-09-22 10:12:44 --> Helper loaded: url_helper
INFO - 2020-09-22 10:12:44 --> Database Driver Class Initialized
INFO - 2020-09-22 10:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:12:44 --> Email Class Initialized
INFO - 2020-09-22 10:12:44 --> Controller Class Initialized
DEBUG - 2020-09-22 10:12:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:12:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:12:44 --> Model Class Initialized
INFO - 2020-09-22 10:12:44 --> Model Class Initialized
INFO - 2020-09-22 10:12:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-22 10:12:44 --> Final output sent to browser
DEBUG - 2020-09-22 10:12:44 --> Total execution time: 0.0304
ERROR - 2020-09-22 10:12:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:12:47 --> Config Class Initialized
INFO - 2020-09-22 10:12:47 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:12:47 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:12:47 --> Utf8 Class Initialized
INFO - 2020-09-22 10:12:47 --> URI Class Initialized
INFO - 2020-09-22 10:12:47 --> Router Class Initialized
INFO - 2020-09-22 10:12:47 --> Output Class Initialized
INFO - 2020-09-22 10:12:47 --> Security Class Initialized
DEBUG - 2020-09-22 10:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:12:47 --> Input Class Initialized
INFO - 2020-09-22 10:12:47 --> Language Class Initialized
INFO - 2020-09-22 10:12:47 --> Loader Class Initialized
INFO - 2020-09-22 10:12:47 --> Helper loaded: url_helper
INFO - 2020-09-22 10:12:47 --> Database Driver Class Initialized
INFO - 2020-09-22 10:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:12:47 --> Email Class Initialized
INFO - 2020-09-22 10:12:47 --> Controller Class Initialized
DEBUG - 2020-09-22 10:12:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:12:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:12:47 --> Model Class Initialized
INFO - 2020-09-22 10:12:47 --> Model Class Initialized
INFO - 2020-09-22 10:12:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-09-22 10:12:47 --> Final output sent to browser
DEBUG - 2020-09-22 10:12:47 --> Total execution time: 0.0415
ERROR - 2020-09-22 10:13:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:13:29 --> Config Class Initialized
INFO - 2020-09-22 10:13:29 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:13:29 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:13:29 --> Utf8 Class Initialized
INFO - 2020-09-22 10:13:29 --> URI Class Initialized
INFO - 2020-09-22 10:13:29 --> Router Class Initialized
INFO - 2020-09-22 10:13:29 --> Output Class Initialized
INFO - 2020-09-22 10:13:29 --> Security Class Initialized
DEBUG - 2020-09-22 10:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:13:29 --> Input Class Initialized
INFO - 2020-09-22 10:13:29 --> Language Class Initialized
INFO - 2020-09-22 10:13:29 --> Loader Class Initialized
INFO - 2020-09-22 10:13:29 --> Helper loaded: url_helper
INFO - 2020-09-22 10:13:29 --> Database Driver Class Initialized
INFO - 2020-09-22 10:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:13:29 --> Email Class Initialized
INFO - 2020-09-22 10:13:29 --> Controller Class Initialized
DEBUG - 2020-09-22 10:13:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:13:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:13:29 --> Model Class Initialized
INFO - 2020-09-22 10:13:29 --> Model Class Initialized
INFO - 2020-09-22 10:13:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-09-22 10:13:29 --> Final output sent to browser
DEBUG - 2020-09-22 10:13:29 --> Total execution time: 0.0268
ERROR - 2020-09-22 10:13:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:13:31 --> Config Class Initialized
INFO - 2020-09-22 10:13:31 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:13:31 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:13:31 --> Utf8 Class Initialized
INFO - 2020-09-22 10:13:31 --> URI Class Initialized
INFO - 2020-09-22 10:13:31 --> Router Class Initialized
INFO - 2020-09-22 10:13:31 --> Output Class Initialized
INFO - 2020-09-22 10:13:31 --> Security Class Initialized
DEBUG - 2020-09-22 10:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:13:31 --> Input Class Initialized
INFO - 2020-09-22 10:13:31 --> Language Class Initialized
INFO - 2020-09-22 10:13:31 --> Loader Class Initialized
INFO - 2020-09-22 10:13:31 --> Helper loaded: url_helper
INFO - 2020-09-22 10:13:31 --> Database Driver Class Initialized
INFO - 2020-09-22 10:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:13:31 --> Email Class Initialized
INFO - 2020-09-22 10:13:31 --> Controller Class Initialized
DEBUG - 2020-09-22 10:13:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:13:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:13:31 --> Model Class Initialized
INFO - 2020-09-22 10:13:31 --> Model Class Initialized
INFO - 2020-09-22 10:13:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-22 10:13:31 --> Final output sent to browser
DEBUG - 2020-09-22 10:13:31 --> Total execution time: 0.0253
ERROR - 2020-09-22 10:13:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:13:35 --> Config Class Initialized
INFO - 2020-09-22 10:13:35 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:13:35 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:13:35 --> Utf8 Class Initialized
INFO - 2020-09-22 10:13:35 --> URI Class Initialized
INFO - 2020-09-22 10:13:35 --> Router Class Initialized
INFO - 2020-09-22 10:13:35 --> Output Class Initialized
INFO - 2020-09-22 10:13:35 --> Security Class Initialized
DEBUG - 2020-09-22 10:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:13:35 --> Input Class Initialized
INFO - 2020-09-22 10:13:35 --> Language Class Initialized
INFO - 2020-09-22 10:13:35 --> Loader Class Initialized
INFO - 2020-09-22 10:13:35 --> Helper loaded: url_helper
INFO - 2020-09-22 10:13:35 --> Database Driver Class Initialized
INFO - 2020-09-22 10:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:13:35 --> Email Class Initialized
INFO - 2020-09-22 10:13:35 --> Controller Class Initialized
DEBUG - 2020-09-22 10:13:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:13:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:13:35 --> Model Class Initialized
INFO - 2020-09-22 10:13:35 --> Model Class Initialized
INFO - 2020-09-22 10:13:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_view.php
INFO - 2020-09-22 10:13:35 --> Final output sent to browser
DEBUG - 2020-09-22 10:13:35 --> Total execution time: 0.0331
ERROR - 2020-09-22 10:14:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:14:27 --> Config Class Initialized
INFO - 2020-09-22 10:14:27 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:14:27 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:14:27 --> Utf8 Class Initialized
INFO - 2020-09-22 10:14:27 --> URI Class Initialized
INFO - 2020-09-22 10:14:27 --> Router Class Initialized
INFO - 2020-09-22 10:14:27 --> Output Class Initialized
INFO - 2020-09-22 10:14:27 --> Security Class Initialized
DEBUG - 2020-09-22 10:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:14:27 --> Input Class Initialized
INFO - 2020-09-22 10:14:27 --> Language Class Initialized
INFO - 2020-09-22 10:14:27 --> Loader Class Initialized
INFO - 2020-09-22 10:14:27 --> Helper loaded: url_helper
INFO - 2020-09-22 10:14:27 --> Database Driver Class Initialized
INFO - 2020-09-22 10:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:14:27 --> Email Class Initialized
INFO - 2020-09-22 10:14:27 --> Controller Class Initialized
DEBUG - 2020-09-22 10:14:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:14:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:14:27 --> Model Class Initialized
INFO - 2020-09-22 10:14:27 --> Model Class Initialized
INFO - 2020-09-22 10:14:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_view.php
INFO - 2020-09-22 10:14:27 --> Final output sent to browser
DEBUG - 2020-09-22 10:14:27 --> Total execution time: 0.0230
ERROR - 2020-09-22 10:14:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:14:29 --> Config Class Initialized
INFO - 2020-09-22 10:14:29 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:14:29 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:14:29 --> Utf8 Class Initialized
INFO - 2020-09-22 10:14:29 --> URI Class Initialized
INFO - 2020-09-22 10:14:29 --> Router Class Initialized
INFO - 2020-09-22 10:14:29 --> Output Class Initialized
INFO - 2020-09-22 10:14:29 --> Security Class Initialized
DEBUG - 2020-09-22 10:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:14:29 --> Input Class Initialized
INFO - 2020-09-22 10:14:29 --> Language Class Initialized
INFO - 2020-09-22 10:14:29 --> Loader Class Initialized
INFO - 2020-09-22 10:14:29 --> Helper loaded: url_helper
INFO - 2020-09-22 10:14:29 --> Database Driver Class Initialized
INFO - 2020-09-22 10:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:14:29 --> Email Class Initialized
INFO - 2020-09-22 10:14:29 --> Controller Class Initialized
DEBUG - 2020-09-22 10:14:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:14:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:14:29 --> Model Class Initialized
INFO - 2020-09-22 10:14:29 --> Model Class Initialized
INFO - 2020-09-22 10:14:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-22 10:14:29 --> Final output sent to browser
DEBUG - 2020-09-22 10:14:29 --> Total execution time: 0.0268
ERROR - 2020-09-22 10:14:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:14:33 --> Config Class Initialized
INFO - 2020-09-22 10:14:33 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:14:33 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:14:33 --> Utf8 Class Initialized
INFO - 2020-09-22 10:14:33 --> URI Class Initialized
INFO - 2020-09-22 10:14:33 --> Router Class Initialized
INFO - 2020-09-22 10:14:33 --> Output Class Initialized
INFO - 2020-09-22 10:14:33 --> Security Class Initialized
DEBUG - 2020-09-22 10:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:14:33 --> Input Class Initialized
INFO - 2020-09-22 10:14:33 --> Language Class Initialized
INFO - 2020-09-22 10:14:33 --> Loader Class Initialized
INFO - 2020-09-22 10:14:33 --> Helper loaded: url_helper
INFO - 2020-09-22 10:14:33 --> Database Driver Class Initialized
INFO - 2020-09-22 10:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:14:33 --> Email Class Initialized
INFO - 2020-09-22 10:14:33 --> Controller Class Initialized
DEBUG - 2020-09-22 10:14:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:14:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:14:33 --> Model Class Initialized
INFO - 2020-09-22 10:14:33 --> Model Class Initialized
INFO - 2020-09-22 10:14:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-09-22 10:14:33 --> Final output sent to browser
DEBUG - 2020-09-22 10:14:33 --> Total execution time: 0.0400
ERROR - 2020-09-22 10:15:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:15:18 --> Config Class Initialized
INFO - 2020-09-22 10:15:18 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:15:18 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:15:18 --> Utf8 Class Initialized
INFO - 2020-09-22 10:15:18 --> URI Class Initialized
INFO - 2020-09-22 10:15:18 --> Router Class Initialized
INFO - 2020-09-22 10:15:18 --> Output Class Initialized
INFO - 2020-09-22 10:15:18 --> Security Class Initialized
DEBUG - 2020-09-22 10:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:15:18 --> Input Class Initialized
INFO - 2020-09-22 10:15:18 --> Language Class Initialized
INFO - 2020-09-22 10:15:18 --> Loader Class Initialized
INFO - 2020-09-22 10:15:18 --> Helper loaded: url_helper
INFO - 2020-09-22 10:15:18 --> Database Driver Class Initialized
INFO - 2020-09-22 10:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:15:18 --> Email Class Initialized
INFO - 2020-09-22 10:15:18 --> Controller Class Initialized
DEBUG - 2020-09-22 10:15:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:15:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:15:18 --> Model Class Initialized
INFO - 2020-09-22 10:15:18 --> Model Class Initialized
INFO - 2020-09-22 10:15:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-09-22 10:15:18 --> Final output sent to browser
DEBUG - 2020-09-22 10:15:18 --> Total execution time: 0.0228
ERROR - 2020-09-22 10:15:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:15:37 --> Config Class Initialized
INFO - 2020-09-22 10:15:37 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:15:37 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:15:37 --> Utf8 Class Initialized
INFO - 2020-09-22 10:15:37 --> URI Class Initialized
INFO - 2020-09-22 10:15:37 --> Router Class Initialized
INFO - 2020-09-22 10:15:37 --> Output Class Initialized
INFO - 2020-09-22 10:15:37 --> Security Class Initialized
DEBUG - 2020-09-22 10:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:15:37 --> Input Class Initialized
INFO - 2020-09-22 10:15:37 --> Language Class Initialized
INFO - 2020-09-22 10:15:37 --> Loader Class Initialized
INFO - 2020-09-22 10:15:37 --> Helper loaded: url_helper
INFO - 2020-09-22 10:15:37 --> Database Driver Class Initialized
INFO - 2020-09-22 10:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:15:37 --> Email Class Initialized
INFO - 2020-09-22 10:15:37 --> Controller Class Initialized
DEBUG - 2020-09-22 10:15:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:15:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:15:37 --> Model Class Initialized
INFO - 2020-09-22 10:15:37 --> Model Class Initialized
INFO - 2020-09-22 10:15:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-22 10:15:37 --> Final output sent to browser
DEBUG - 2020-09-22 10:15:37 --> Total execution time: 0.0199
ERROR - 2020-09-22 10:15:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:15:42 --> Config Class Initialized
INFO - 2020-09-22 10:15:42 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:15:42 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:15:42 --> Utf8 Class Initialized
INFO - 2020-09-22 10:15:42 --> URI Class Initialized
INFO - 2020-09-22 10:15:42 --> Router Class Initialized
INFO - 2020-09-22 10:15:42 --> Output Class Initialized
INFO - 2020-09-22 10:15:42 --> Security Class Initialized
DEBUG - 2020-09-22 10:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:15:42 --> Input Class Initialized
INFO - 2020-09-22 10:15:42 --> Language Class Initialized
INFO - 2020-09-22 10:15:42 --> Loader Class Initialized
INFO - 2020-09-22 10:15:42 --> Helper loaded: url_helper
INFO - 2020-09-22 10:15:42 --> Database Driver Class Initialized
INFO - 2020-09-22 10:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:15:42 --> Email Class Initialized
INFO - 2020-09-22 10:15:42 --> Controller Class Initialized
DEBUG - 2020-09-22 10:15:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:15:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:15:42 --> Model Class Initialized
INFO - 2020-09-22 10:15:42 --> Model Class Initialized
INFO - 2020-09-22 10:15:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 10:15:42 --> Final output sent to browser
DEBUG - 2020-09-22 10:15:42 --> Total execution time: 0.0282
ERROR - 2020-09-22 10:15:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:15:42 --> Config Class Initialized
INFO - 2020-09-22 10:15:42 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:15:42 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:15:42 --> Utf8 Class Initialized
INFO - 2020-09-22 10:15:42 --> URI Class Initialized
INFO - 2020-09-22 10:15:42 --> Router Class Initialized
INFO - 2020-09-22 10:15:42 --> Output Class Initialized
INFO - 2020-09-22 10:15:42 --> Security Class Initialized
DEBUG - 2020-09-22 10:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:15:42 --> Input Class Initialized
INFO - 2020-09-22 10:15:42 --> Language Class Initialized
INFO - 2020-09-22 10:15:42 --> Loader Class Initialized
INFO - 2020-09-22 10:15:42 --> Helper loaded: url_helper
INFO - 2020-09-22 10:15:42 --> Database Driver Class Initialized
INFO - 2020-09-22 10:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:15:42 --> Email Class Initialized
INFO - 2020-09-22 10:15:42 --> Controller Class Initialized
DEBUG - 2020-09-22 10:15:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:15:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:15:42 --> Model Class Initialized
INFO - 2020-09-22 10:15:42 --> Model Class Initialized
INFO - 2020-09-22 10:15:42 --> Final output sent to browser
DEBUG - 2020-09-22 10:15:42 --> Total execution time: 0.0262
ERROR - 2020-09-22 10:15:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:15:48 --> Config Class Initialized
INFO - 2020-09-22 10:15:48 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:15:48 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:15:48 --> Utf8 Class Initialized
INFO - 2020-09-22 10:15:48 --> URI Class Initialized
INFO - 2020-09-22 10:15:48 --> Router Class Initialized
INFO - 2020-09-22 10:15:48 --> Output Class Initialized
INFO - 2020-09-22 10:15:48 --> Security Class Initialized
DEBUG - 2020-09-22 10:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:15:48 --> Input Class Initialized
INFO - 2020-09-22 10:15:48 --> Language Class Initialized
INFO - 2020-09-22 10:15:48 --> Loader Class Initialized
INFO - 2020-09-22 10:15:48 --> Helper loaded: url_helper
INFO - 2020-09-22 10:15:48 --> Database Driver Class Initialized
INFO - 2020-09-22 10:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:15:48 --> Email Class Initialized
INFO - 2020-09-22 10:15:48 --> Controller Class Initialized
DEBUG - 2020-09-22 10:15:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:15:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:15:48 --> Model Class Initialized
INFO - 2020-09-22 10:15:48 --> Model Class Initialized
INFO - 2020-09-22 10:15:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 10:15:48 --> Final output sent to browser
DEBUG - 2020-09-22 10:15:48 --> Total execution time: 0.0265
ERROR - 2020-09-22 10:15:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:15:49 --> Config Class Initialized
INFO - 2020-09-22 10:15:49 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:15:49 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:15:49 --> Utf8 Class Initialized
INFO - 2020-09-22 10:15:49 --> URI Class Initialized
INFO - 2020-09-22 10:15:49 --> Router Class Initialized
INFO - 2020-09-22 10:15:49 --> Output Class Initialized
INFO - 2020-09-22 10:15:49 --> Security Class Initialized
DEBUG - 2020-09-22 10:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:15:49 --> Input Class Initialized
INFO - 2020-09-22 10:15:49 --> Language Class Initialized
INFO - 2020-09-22 10:15:49 --> Loader Class Initialized
INFO - 2020-09-22 10:15:49 --> Helper loaded: url_helper
INFO - 2020-09-22 10:15:49 --> Database Driver Class Initialized
INFO - 2020-09-22 10:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:15:49 --> Email Class Initialized
INFO - 2020-09-22 10:15:49 --> Controller Class Initialized
DEBUG - 2020-09-22 10:15:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:15:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:15:49 --> Model Class Initialized
INFO - 2020-09-22 10:15:49 --> Model Class Initialized
INFO - 2020-09-22 10:15:49 --> Final output sent to browser
DEBUG - 2020-09-22 10:15:49 --> Total execution time: 0.0234
ERROR - 2020-09-22 10:15:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:15:57 --> Config Class Initialized
INFO - 2020-09-22 10:15:57 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:15:57 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:15:57 --> Utf8 Class Initialized
INFO - 2020-09-22 10:15:57 --> URI Class Initialized
INFO - 2020-09-22 10:15:57 --> Router Class Initialized
INFO - 2020-09-22 10:15:57 --> Output Class Initialized
INFO - 2020-09-22 10:15:57 --> Security Class Initialized
DEBUG - 2020-09-22 10:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:15:57 --> Input Class Initialized
INFO - 2020-09-22 10:15:57 --> Language Class Initialized
INFO - 2020-09-22 10:15:57 --> Loader Class Initialized
INFO - 2020-09-22 10:15:57 --> Helper loaded: url_helper
INFO - 2020-09-22 10:15:57 --> Database Driver Class Initialized
INFO - 2020-09-22 10:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:15:57 --> Email Class Initialized
INFO - 2020-09-22 10:15:57 --> Controller Class Initialized
DEBUG - 2020-09-22 10:15:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:15:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:15:57 --> Model Class Initialized
INFO - 2020-09-22 10:15:57 --> Model Class Initialized
INFO - 2020-09-22 10:15:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 10:15:57 --> Final output sent to browser
DEBUG - 2020-09-22 10:15:57 --> Total execution time: 0.0351
ERROR - 2020-09-22 10:15:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:15:57 --> Config Class Initialized
INFO - 2020-09-22 10:15:57 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:15:57 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:15:57 --> Utf8 Class Initialized
INFO - 2020-09-22 10:15:57 --> URI Class Initialized
INFO - 2020-09-22 10:15:57 --> Router Class Initialized
INFO - 2020-09-22 10:15:57 --> Output Class Initialized
INFO - 2020-09-22 10:15:57 --> Security Class Initialized
DEBUG - 2020-09-22 10:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:15:57 --> Input Class Initialized
INFO - 2020-09-22 10:15:57 --> Language Class Initialized
INFO - 2020-09-22 10:15:57 --> Loader Class Initialized
INFO - 2020-09-22 10:15:57 --> Helper loaded: url_helper
INFO - 2020-09-22 10:15:57 --> Database Driver Class Initialized
INFO - 2020-09-22 10:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:15:57 --> Email Class Initialized
INFO - 2020-09-22 10:15:57 --> Controller Class Initialized
DEBUG - 2020-09-22 10:15:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:15:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:15:57 --> Model Class Initialized
INFO - 2020-09-22 10:15:57 --> Model Class Initialized
INFO - 2020-09-22 10:15:57 --> Final output sent to browser
DEBUG - 2020-09-22 10:15:57 --> Total execution time: 0.0275
ERROR - 2020-09-22 10:16:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:16:02 --> Config Class Initialized
INFO - 2020-09-22 10:16:02 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:16:02 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:16:02 --> Utf8 Class Initialized
INFO - 2020-09-22 10:16:02 --> URI Class Initialized
INFO - 2020-09-22 10:16:02 --> Router Class Initialized
INFO - 2020-09-22 10:16:02 --> Output Class Initialized
INFO - 2020-09-22 10:16:02 --> Security Class Initialized
DEBUG - 2020-09-22 10:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:16:02 --> Input Class Initialized
INFO - 2020-09-22 10:16:02 --> Language Class Initialized
INFO - 2020-09-22 10:16:02 --> Loader Class Initialized
INFO - 2020-09-22 10:16:02 --> Helper loaded: url_helper
INFO - 2020-09-22 10:16:02 --> Database Driver Class Initialized
INFO - 2020-09-22 10:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:16:02 --> Email Class Initialized
INFO - 2020-09-22 10:16:02 --> Controller Class Initialized
DEBUG - 2020-09-22 10:16:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:16:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:16:02 --> Model Class Initialized
INFO - 2020-09-22 10:16:02 --> Model Class Initialized
INFO - 2020-09-22 10:16:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 10:16:02 --> Final output sent to browser
DEBUG - 2020-09-22 10:16:02 --> Total execution time: 0.0279
ERROR - 2020-09-22 10:16:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:16:03 --> Config Class Initialized
INFO - 2020-09-22 10:16:03 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:16:03 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:16:03 --> Utf8 Class Initialized
INFO - 2020-09-22 10:16:03 --> URI Class Initialized
INFO - 2020-09-22 10:16:03 --> Router Class Initialized
INFO - 2020-09-22 10:16:03 --> Output Class Initialized
INFO - 2020-09-22 10:16:03 --> Security Class Initialized
DEBUG - 2020-09-22 10:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:16:03 --> Input Class Initialized
INFO - 2020-09-22 10:16:03 --> Language Class Initialized
INFO - 2020-09-22 10:16:03 --> Loader Class Initialized
INFO - 2020-09-22 10:16:03 --> Helper loaded: url_helper
INFO - 2020-09-22 10:16:03 --> Database Driver Class Initialized
INFO - 2020-09-22 10:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:16:03 --> Email Class Initialized
INFO - 2020-09-22 10:16:03 --> Controller Class Initialized
DEBUG - 2020-09-22 10:16:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:16:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:16:03 --> Model Class Initialized
INFO - 2020-09-22 10:16:03 --> Model Class Initialized
INFO - 2020-09-22 10:16:03 --> Final output sent to browser
DEBUG - 2020-09-22 10:16:03 --> Total execution time: 0.0207
ERROR - 2020-09-22 10:17:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:17:07 --> Config Class Initialized
INFO - 2020-09-22 10:17:07 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:17:07 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:17:07 --> Utf8 Class Initialized
INFO - 2020-09-22 10:17:07 --> URI Class Initialized
INFO - 2020-09-22 10:17:07 --> Router Class Initialized
INFO - 2020-09-22 10:17:07 --> Output Class Initialized
INFO - 2020-09-22 10:17:07 --> Security Class Initialized
DEBUG - 2020-09-22 10:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:17:07 --> Input Class Initialized
INFO - 2020-09-22 10:17:07 --> Language Class Initialized
INFO - 2020-09-22 10:17:07 --> Loader Class Initialized
INFO - 2020-09-22 10:17:07 --> Helper loaded: url_helper
INFO - 2020-09-22 10:17:07 --> Database Driver Class Initialized
INFO - 2020-09-22 10:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:17:07 --> Email Class Initialized
INFO - 2020-09-22 10:17:07 --> Controller Class Initialized
DEBUG - 2020-09-22 10:17:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:17:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:17:07 --> Model Class Initialized
INFO - 2020-09-22 10:17:07 --> Model Class Initialized
INFO - 2020-09-22 10:17:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 10:17:07 --> Final output sent to browser
DEBUG - 2020-09-22 10:17:07 --> Total execution time: 0.0329
ERROR - 2020-09-22 10:17:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:17:08 --> Config Class Initialized
INFO - 2020-09-22 10:17:08 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:17:08 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:17:08 --> Utf8 Class Initialized
INFO - 2020-09-22 10:17:08 --> URI Class Initialized
INFO - 2020-09-22 10:17:08 --> Router Class Initialized
INFO - 2020-09-22 10:17:08 --> Output Class Initialized
INFO - 2020-09-22 10:17:08 --> Security Class Initialized
DEBUG - 2020-09-22 10:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:17:08 --> Input Class Initialized
INFO - 2020-09-22 10:17:08 --> Language Class Initialized
INFO - 2020-09-22 10:17:08 --> Loader Class Initialized
INFO - 2020-09-22 10:17:08 --> Helper loaded: url_helper
INFO - 2020-09-22 10:17:08 --> Database Driver Class Initialized
INFO - 2020-09-22 10:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:17:08 --> Email Class Initialized
INFO - 2020-09-22 10:17:08 --> Controller Class Initialized
DEBUG - 2020-09-22 10:17:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:17:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:17:08 --> Model Class Initialized
INFO - 2020-09-22 10:17:08 --> Model Class Initialized
INFO - 2020-09-22 10:17:08 --> Final output sent to browser
DEBUG - 2020-09-22 10:17:08 --> Total execution time: 0.0247
ERROR - 2020-09-22 10:17:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:17:16 --> Config Class Initialized
INFO - 2020-09-22 10:17:16 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:17:16 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:17:16 --> Utf8 Class Initialized
INFO - 2020-09-22 10:17:16 --> URI Class Initialized
INFO - 2020-09-22 10:17:16 --> Router Class Initialized
INFO - 2020-09-22 10:17:16 --> Output Class Initialized
INFO - 2020-09-22 10:17:16 --> Security Class Initialized
DEBUG - 2020-09-22 10:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:17:16 --> Input Class Initialized
INFO - 2020-09-22 10:17:16 --> Language Class Initialized
INFO - 2020-09-22 10:17:16 --> Loader Class Initialized
INFO - 2020-09-22 10:17:16 --> Helper loaded: url_helper
INFO - 2020-09-22 10:17:16 --> Database Driver Class Initialized
INFO - 2020-09-22 10:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:17:16 --> Email Class Initialized
INFO - 2020-09-22 10:17:16 --> Controller Class Initialized
DEBUG - 2020-09-22 10:17:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:17:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:17:16 --> Model Class Initialized
INFO - 2020-09-22 10:17:16 --> Model Class Initialized
INFO - 2020-09-22 10:17:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 10:17:16 --> Final output sent to browser
DEBUG - 2020-09-22 10:17:16 --> Total execution time: 0.0275
ERROR - 2020-09-22 10:17:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:17:16 --> Config Class Initialized
INFO - 2020-09-22 10:17:16 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:17:16 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:17:16 --> Utf8 Class Initialized
INFO - 2020-09-22 10:17:16 --> URI Class Initialized
INFO - 2020-09-22 10:17:16 --> Router Class Initialized
INFO - 2020-09-22 10:17:16 --> Output Class Initialized
INFO - 2020-09-22 10:17:16 --> Security Class Initialized
DEBUG - 2020-09-22 10:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:17:16 --> Input Class Initialized
INFO - 2020-09-22 10:17:16 --> Language Class Initialized
INFO - 2020-09-22 10:17:16 --> Loader Class Initialized
INFO - 2020-09-22 10:17:16 --> Helper loaded: url_helper
INFO - 2020-09-22 10:17:16 --> Database Driver Class Initialized
INFO - 2020-09-22 10:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:17:16 --> Email Class Initialized
INFO - 2020-09-22 10:17:16 --> Controller Class Initialized
DEBUG - 2020-09-22 10:17:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:17:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:17:16 --> Model Class Initialized
INFO - 2020-09-22 10:17:16 --> Model Class Initialized
INFO - 2020-09-22 10:17:16 --> Final output sent to browser
DEBUG - 2020-09-22 10:17:16 --> Total execution time: 0.0239
ERROR - 2020-09-22 10:17:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:17:20 --> Config Class Initialized
INFO - 2020-09-22 10:17:20 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:17:20 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:17:20 --> Utf8 Class Initialized
INFO - 2020-09-22 10:17:20 --> URI Class Initialized
INFO - 2020-09-22 10:17:20 --> Router Class Initialized
INFO - 2020-09-22 10:17:20 --> Output Class Initialized
INFO - 2020-09-22 10:17:20 --> Security Class Initialized
DEBUG - 2020-09-22 10:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:17:20 --> Input Class Initialized
INFO - 2020-09-22 10:17:20 --> Language Class Initialized
INFO - 2020-09-22 10:17:20 --> Loader Class Initialized
INFO - 2020-09-22 10:17:20 --> Helper loaded: url_helper
INFO - 2020-09-22 10:17:20 --> Database Driver Class Initialized
INFO - 2020-09-22 10:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:17:20 --> Email Class Initialized
INFO - 2020-09-22 10:17:20 --> Controller Class Initialized
DEBUG - 2020-09-22 10:17:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:17:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:17:20 --> Model Class Initialized
INFO - 2020-09-22 10:17:20 --> Model Class Initialized
INFO - 2020-09-22 10:17:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 10:17:20 --> Final output sent to browser
DEBUG - 2020-09-22 10:17:20 --> Total execution time: 0.0271
ERROR - 2020-09-22 10:17:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:17:21 --> Config Class Initialized
INFO - 2020-09-22 10:17:21 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:17:21 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:17:21 --> Utf8 Class Initialized
INFO - 2020-09-22 10:17:21 --> URI Class Initialized
INFO - 2020-09-22 10:17:21 --> Router Class Initialized
INFO - 2020-09-22 10:17:21 --> Output Class Initialized
INFO - 2020-09-22 10:17:21 --> Security Class Initialized
DEBUG - 2020-09-22 10:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:17:21 --> Input Class Initialized
INFO - 2020-09-22 10:17:21 --> Language Class Initialized
INFO - 2020-09-22 10:17:21 --> Loader Class Initialized
INFO - 2020-09-22 10:17:21 --> Helper loaded: url_helper
INFO - 2020-09-22 10:17:21 --> Database Driver Class Initialized
INFO - 2020-09-22 10:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:17:21 --> Email Class Initialized
INFO - 2020-09-22 10:17:21 --> Controller Class Initialized
DEBUG - 2020-09-22 10:17:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:17:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:17:21 --> Model Class Initialized
INFO - 2020-09-22 10:17:21 --> Model Class Initialized
INFO - 2020-09-22 10:17:21 --> Final output sent to browser
DEBUG - 2020-09-22 10:17:21 --> Total execution time: 0.0255
ERROR - 2020-09-22 10:17:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:17:30 --> Config Class Initialized
INFO - 2020-09-22 10:17:30 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:17:30 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:17:30 --> Utf8 Class Initialized
INFO - 2020-09-22 10:17:30 --> URI Class Initialized
INFO - 2020-09-22 10:17:30 --> Router Class Initialized
INFO - 2020-09-22 10:17:30 --> Output Class Initialized
INFO - 2020-09-22 10:17:30 --> Security Class Initialized
DEBUG - 2020-09-22 10:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:17:30 --> Input Class Initialized
INFO - 2020-09-22 10:17:30 --> Language Class Initialized
INFO - 2020-09-22 10:17:30 --> Loader Class Initialized
INFO - 2020-09-22 10:17:30 --> Helper loaded: url_helper
INFO - 2020-09-22 10:17:30 --> Database Driver Class Initialized
INFO - 2020-09-22 10:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:17:30 --> Email Class Initialized
INFO - 2020-09-22 10:17:30 --> Controller Class Initialized
DEBUG - 2020-09-22 10:17:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:17:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:17:30 --> Model Class Initialized
INFO - 2020-09-22 10:17:30 --> Model Class Initialized
INFO - 2020-09-22 10:17:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-22 10:17:30 --> Final output sent to browser
DEBUG - 2020-09-22 10:17:30 --> Total execution time: 0.0251
ERROR - 2020-09-22 10:17:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:17:36 --> Config Class Initialized
INFO - 2020-09-22 10:17:36 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:17:36 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:17:36 --> Utf8 Class Initialized
INFO - 2020-09-22 10:17:36 --> URI Class Initialized
INFO - 2020-09-22 10:17:36 --> Router Class Initialized
INFO - 2020-09-22 10:17:36 --> Output Class Initialized
INFO - 2020-09-22 10:17:36 --> Security Class Initialized
DEBUG - 2020-09-22 10:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:17:36 --> Input Class Initialized
INFO - 2020-09-22 10:17:36 --> Language Class Initialized
INFO - 2020-09-22 10:17:36 --> Loader Class Initialized
INFO - 2020-09-22 10:17:36 --> Helper loaded: url_helper
INFO - 2020-09-22 10:17:36 --> Database Driver Class Initialized
INFO - 2020-09-22 10:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:17:36 --> Email Class Initialized
INFO - 2020-09-22 10:17:36 --> Controller Class Initialized
DEBUG - 2020-09-22 10:17:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:17:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:17:36 --> Model Class Initialized
INFO - 2020-09-22 10:17:36 --> Model Class Initialized
INFO - 2020-09-22 10:17:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 10:17:36 --> Final output sent to browser
DEBUG - 2020-09-22 10:17:36 --> Total execution time: 0.0324
ERROR - 2020-09-22 10:17:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:17:36 --> Config Class Initialized
INFO - 2020-09-22 10:17:36 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:17:36 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:17:36 --> Utf8 Class Initialized
INFO - 2020-09-22 10:17:36 --> URI Class Initialized
INFO - 2020-09-22 10:17:36 --> Router Class Initialized
INFO - 2020-09-22 10:17:36 --> Output Class Initialized
INFO - 2020-09-22 10:17:36 --> Security Class Initialized
DEBUG - 2020-09-22 10:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:17:36 --> Input Class Initialized
INFO - 2020-09-22 10:17:36 --> Language Class Initialized
INFO - 2020-09-22 10:17:36 --> Loader Class Initialized
INFO - 2020-09-22 10:17:36 --> Helper loaded: url_helper
INFO - 2020-09-22 10:17:36 --> Database Driver Class Initialized
INFO - 2020-09-22 10:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:17:36 --> Email Class Initialized
INFO - 2020-09-22 10:17:36 --> Controller Class Initialized
DEBUG - 2020-09-22 10:17:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:17:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:17:36 --> Model Class Initialized
INFO - 2020-09-22 10:17:36 --> Model Class Initialized
INFO - 2020-09-22 10:17:36 --> Final output sent to browser
DEBUG - 2020-09-22 10:17:36 --> Total execution time: 0.0269
ERROR - 2020-09-22 10:17:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:17:38 --> Config Class Initialized
INFO - 2020-09-22 10:17:38 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:17:38 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:17:38 --> Utf8 Class Initialized
INFO - 2020-09-22 10:17:38 --> URI Class Initialized
INFO - 2020-09-22 10:17:38 --> Router Class Initialized
INFO - 2020-09-22 10:17:38 --> Output Class Initialized
INFO - 2020-09-22 10:17:38 --> Security Class Initialized
DEBUG - 2020-09-22 10:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:17:38 --> Input Class Initialized
INFO - 2020-09-22 10:17:38 --> Language Class Initialized
INFO - 2020-09-22 10:17:38 --> Loader Class Initialized
INFO - 2020-09-22 10:17:38 --> Helper loaded: url_helper
INFO - 2020-09-22 10:17:38 --> Database Driver Class Initialized
INFO - 2020-09-22 10:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:17:38 --> Email Class Initialized
INFO - 2020-09-22 10:17:38 --> Controller Class Initialized
DEBUG - 2020-09-22 10:17:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:17:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:17:38 --> Model Class Initialized
INFO - 2020-09-22 10:17:38 --> Model Class Initialized
INFO - 2020-09-22 10:17:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 10:17:38 --> Final output sent to browser
DEBUG - 2020-09-22 10:17:38 --> Total execution time: 0.0297
ERROR - 2020-09-22 10:17:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:17:38 --> Config Class Initialized
INFO - 2020-09-22 10:17:38 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:17:38 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:17:38 --> Utf8 Class Initialized
INFO - 2020-09-22 10:17:38 --> URI Class Initialized
INFO - 2020-09-22 10:17:38 --> Router Class Initialized
INFO - 2020-09-22 10:17:38 --> Output Class Initialized
INFO - 2020-09-22 10:17:38 --> Security Class Initialized
DEBUG - 2020-09-22 10:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:17:38 --> Input Class Initialized
INFO - 2020-09-22 10:17:38 --> Language Class Initialized
INFO - 2020-09-22 10:17:38 --> Loader Class Initialized
INFO - 2020-09-22 10:17:38 --> Helper loaded: url_helper
INFO - 2020-09-22 10:17:38 --> Database Driver Class Initialized
INFO - 2020-09-22 10:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:17:38 --> Email Class Initialized
INFO - 2020-09-22 10:17:38 --> Controller Class Initialized
DEBUG - 2020-09-22 10:17:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:17:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:17:38 --> Model Class Initialized
INFO - 2020-09-22 10:17:38 --> Model Class Initialized
INFO - 2020-09-22 10:17:38 --> Final output sent to browser
DEBUG - 2020-09-22 10:17:38 --> Total execution time: 0.0277
ERROR - 2020-09-22 10:18:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:18:30 --> Config Class Initialized
INFO - 2020-09-22 10:18:30 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:18:30 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:18:30 --> Utf8 Class Initialized
INFO - 2020-09-22 10:18:30 --> URI Class Initialized
DEBUG - 2020-09-22 10:18:30 --> No URI present. Default controller set.
INFO - 2020-09-22 10:18:30 --> Router Class Initialized
INFO - 2020-09-22 10:18:30 --> Output Class Initialized
INFO - 2020-09-22 10:18:30 --> Security Class Initialized
DEBUG - 2020-09-22 10:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:18:30 --> Input Class Initialized
INFO - 2020-09-22 10:18:30 --> Language Class Initialized
INFO - 2020-09-22 10:18:30 --> Loader Class Initialized
INFO - 2020-09-22 10:18:30 --> Helper loaded: url_helper
INFO - 2020-09-22 10:18:30 --> Database Driver Class Initialized
INFO - 2020-09-22 10:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:18:30 --> Email Class Initialized
INFO - 2020-09-22 10:18:30 --> Controller Class Initialized
INFO - 2020-09-22 10:18:30 --> Model Class Initialized
INFO - 2020-09-22 10:18:30 --> Model Class Initialized
DEBUG - 2020-09-22 10:18:30 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:18:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 10:18:30 --> Final output sent to browser
DEBUG - 2020-09-22 10:18:30 --> Total execution time: 0.0265
ERROR - 2020-09-22 10:18:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:18:37 --> Config Class Initialized
INFO - 2020-09-22 10:18:37 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:18:37 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:18:37 --> Utf8 Class Initialized
INFO - 2020-09-22 10:18:37 --> URI Class Initialized
INFO - 2020-09-22 10:18:37 --> Router Class Initialized
INFO - 2020-09-22 10:18:37 --> Output Class Initialized
INFO - 2020-09-22 10:18:37 --> Security Class Initialized
DEBUG - 2020-09-22 10:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:18:37 --> Input Class Initialized
INFO - 2020-09-22 10:18:37 --> Language Class Initialized
INFO - 2020-09-22 10:18:37 --> Loader Class Initialized
INFO - 2020-09-22 10:18:37 --> Helper loaded: url_helper
INFO - 2020-09-22 10:18:37 --> Database Driver Class Initialized
INFO - 2020-09-22 10:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:18:37 --> Email Class Initialized
INFO - 2020-09-22 10:18:37 --> Controller Class Initialized
INFO - 2020-09-22 10:18:37 --> Model Class Initialized
INFO - 2020-09-22 10:18:37 --> Model Class Initialized
DEBUG - 2020-09-22 10:18:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:18:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:18:37 --> Model Class Initialized
INFO - 2020-09-22 10:18:37 --> Final output sent to browser
DEBUG - 2020-09-22 10:18:37 --> Total execution time: 0.0246
ERROR - 2020-09-22 10:18:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:18:37 --> Config Class Initialized
INFO - 2020-09-22 10:18:37 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:18:37 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:18:37 --> Utf8 Class Initialized
INFO - 2020-09-22 10:18:37 --> URI Class Initialized
INFO - 2020-09-22 10:18:37 --> Router Class Initialized
INFO - 2020-09-22 10:18:37 --> Output Class Initialized
INFO - 2020-09-22 10:18:37 --> Security Class Initialized
DEBUG - 2020-09-22 10:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:18:37 --> Input Class Initialized
INFO - 2020-09-22 10:18:37 --> Language Class Initialized
INFO - 2020-09-22 10:18:37 --> Loader Class Initialized
INFO - 2020-09-22 10:18:37 --> Helper loaded: url_helper
INFO - 2020-09-22 10:18:37 --> Database Driver Class Initialized
INFO - 2020-09-22 10:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:18:37 --> Email Class Initialized
INFO - 2020-09-22 10:18:37 --> Controller Class Initialized
INFO - 2020-09-22 10:18:37 --> Model Class Initialized
INFO - 2020-09-22 10:18:37 --> Model Class Initialized
DEBUG - 2020-09-22 10:18:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-22 10:18:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:18:37 --> Config Class Initialized
INFO - 2020-09-22 10:18:37 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:18:37 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:18:37 --> Utf8 Class Initialized
INFO - 2020-09-22 10:18:37 --> URI Class Initialized
INFO - 2020-09-22 10:18:37 --> Router Class Initialized
INFO - 2020-09-22 10:18:37 --> Output Class Initialized
INFO - 2020-09-22 10:18:37 --> Security Class Initialized
DEBUG - 2020-09-22 10:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:18:37 --> Input Class Initialized
INFO - 2020-09-22 10:18:37 --> Language Class Initialized
INFO - 2020-09-22 10:18:37 --> Loader Class Initialized
INFO - 2020-09-22 10:18:37 --> Helper loaded: url_helper
INFO - 2020-09-22 10:18:37 --> Database Driver Class Initialized
INFO - 2020-09-22 10:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:18:37 --> Email Class Initialized
INFO - 2020-09-22 10:18:37 --> Controller Class Initialized
DEBUG - 2020-09-22 10:18:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:18:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:18:37 --> Model Class Initialized
INFO - 2020-09-22 10:18:37 --> Model Class Initialized
INFO - 2020-09-22 10:18:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-22 10:18:37 --> Final output sent to browser
DEBUG - 2020-09-22 10:18:37 --> Total execution time: 0.0238
ERROR - 2020-09-22 10:18:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:18:40 --> Config Class Initialized
INFO - 2020-09-22 10:18:40 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:18:40 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:18:40 --> Utf8 Class Initialized
INFO - 2020-09-22 10:18:40 --> URI Class Initialized
INFO - 2020-09-22 10:18:40 --> Router Class Initialized
INFO - 2020-09-22 10:18:40 --> Output Class Initialized
INFO - 2020-09-22 10:18:40 --> Security Class Initialized
DEBUG - 2020-09-22 10:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:18:40 --> Input Class Initialized
INFO - 2020-09-22 10:18:40 --> Language Class Initialized
INFO - 2020-09-22 10:18:40 --> Loader Class Initialized
INFO - 2020-09-22 10:18:40 --> Helper loaded: url_helper
INFO - 2020-09-22 10:18:40 --> Database Driver Class Initialized
INFO - 2020-09-22 10:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:18:40 --> Email Class Initialized
INFO - 2020-09-22 10:18:40 --> Controller Class Initialized
DEBUG - 2020-09-22 10:18:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:18:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:18:40 --> Model Class Initialized
INFO - 2020-09-22 10:18:40 --> Model Class Initialized
INFO - 2020-09-22 10:18:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 10:18:40 --> Final output sent to browser
DEBUG - 2020-09-22 10:18:40 --> Total execution time: 0.0215
ERROR - 2020-09-22 10:18:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:18:41 --> Config Class Initialized
INFO - 2020-09-22 10:18:41 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:18:41 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:18:41 --> Utf8 Class Initialized
INFO - 2020-09-22 10:18:41 --> URI Class Initialized
INFO - 2020-09-22 10:18:41 --> Router Class Initialized
INFO - 2020-09-22 10:18:41 --> Output Class Initialized
INFO - 2020-09-22 10:18:41 --> Security Class Initialized
DEBUG - 2020-09-22 10:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:18:41 --> Input Class Initialized
INFO - 2020-09-22 10:18:41 --> Language Class Initialized
INFO - 2020-09-22 10:18:41 --> Loader Class Initialized
INFO - 2020-09-22 10:18:41 --> Helper loaded: url_helper
INFO - 2020-09-22 10:18:41 --> Database Driver Class Initialized
INFO - 2020-09-22 10:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:18:41 --> Email Class Initialized
INFO - 2020-09-22 10:18:41 --> Controller Class Initialized
DEBUG - 2020-09-22 10:18:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:18:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:18:41 --> Model Class Initialized
INFO - 2020-09-22 10:18:41 --> Model Class Initialized
INFO - 2020-09-22 10:18:41 --> Final output sent to browser
DEBUG - 2020-09-22 10:18:41 --> Total execution time: 0.0238
ERROR - 2020-09-22 10:19:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:19:14 --> Config Class Initialized
INFO - 2020-09-22 10:19:14 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:19:14 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:19:14 --> Utf8 Class Initialized
INFO - 2020-09-22 10:19:14 --> URI Class Initialized
INFO - 2020-09-22 10:19:14 --> Router Class Initialized
INFO - 2020-09-22 10:19:14 --> Output Class Initialized
INFO - 2020-09-22 10:19:14 --> Security Class Initialized
DEBUG - 2020-09-22 10:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:19:14 --> Input Class Initialized
INFO - 2020-09-22 10:19:14 --> Language Class Initialized
INFO - 2020-09-22 10:19:14 --> Loader Class Initialized
INFO - 2020-09-22 10:19:14 --> Helper loaded: url_helper
INFO - 2020-09-22 10:19:14 --> Database Driver Class Initialized
INFO - 2020-09-22 10:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:19:14 --> Email Class Initialized
INFO - 2020-09-22 10:19:14 --> Controller Class Initialized
DEBUG - 2020-09-22 10:19:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:19:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:19:14 --> Model Class Initialized
INFO - 2020-09-22 10:19:14 --> Model Class Initialized
INFO - 2020-09-22 10:19:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 10:19:14 --> Final output sent to browser
DEBUG - 2020-09-22 10:19:14 --> Total execution time: 0.0311
ERROR - 2020-09-22 10:19:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:19:15 --> Config Class Initialized
INFO - 2020-09-22 10:19:15 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:19:15 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:19:15 --> Utf8 Class Initialized
INFO - 2020-09-22 10:19:15 --> URI Class Initialized
INFO - 2020-09-22 10:19:15 --> Router Class Initialized
INFO - 2020-09-22 10:19:15 --> Output Class Initialized
INFO - 2020-09-22 10:19:15 --> Security Class Initialized
DEBUG - 2020-09-22 10:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:19:15 --> Input Class Initialized
INFO - 2020-09-22 10:19:15 --> Language Class Initialized
INFO - 2020-09-22 10:19:15 --> Loader Class Initialized
INFO - 2020-09-22 10:19:15 --> Helper loaded: url_helper
INFO - 2020-09-22 10:19:15 --> Database Driver Class Initialized
INFO - 2020-09-22 10:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:19:15 --> Email Class Initialized
INFO - 2020-09-22 10:19:15 --> Controller Class Initialized
DEBUG - 2020-09-22 10:19:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:19:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:19:15 --> Model Class Initialized
INFO - 2020-09-22 10:19:15 --> Model Class Initialized
INFO - 2020-09-22 10:19:15 --> Final output sent to browser
DEBUG - 2020-09-22 10:19:15 --> Total execution time: 0.0253
ERROR - 2020-09-22 10:19:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:19:40 --> Config Class Initialized
INFO - 2020-09-22 10:19:40 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:19:40 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:19:40 --> Utf8 Class Initialized
INFO - 2020-09-22 10:19:40 --> URI Class Initialized
INFO - 2020-09-22 10:19:40 --> Router Class Initialized
INFO - 2020-09-22 10:19:40 --> Output Class Initialized
INFO - 2020-09-22 10:19:40 --> Security Class Initialized
DEBUG - 2020-09-22 10:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:19:40 --> Input Class Initialized
INFO - 2020-09-22 10:19:40 --> Language Class Initialized
INFO - 2020-09-22 10:19:40 --> Loader Class Initialized
INFO - 2020-09-22 10:19:40 --> Helper loaded: url_helper
INFO - 2020-09-22 10:19:40 --> Database Driver Class Initialized
INFO - 2020-09-22 10:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:19:41 --> Email Class Initialized
INFO - 2020-09-22 10:19:41 --> Controller Class Initialized
DEBUG - 2020-09-22 10:19:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:19:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:19:41 --> Model Class Initialized
INFO - 2020-09-22 10:19:41 --> Model Class Initialized
INFO - 2020-09-22 10:19:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 10:19:41 --> Final output sent to browser
DEBUG - 2020-09-22 10:19:41 --> Total execution time: 0.0246
ERROR - 2020-09-22 10:19:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:19:41 --> Config Class Initialized
INFO - 2020-09-22 10:19:41 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:19:41 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:19:41 --> Utf8 Class Initialized
INFO - 2020-09-22 10:19:41 --> URI Class Initialized
INFO - 2020-09-22 10:19:41 --> Router Class Initialized
INFO - 2020-09-22 10:19:41 --> Output Class Initialized
INFO - 2020-09-22 10:19:41 --> Security Class Initialized
DEBUG - 2020-09-22 10:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:19:41 --> Input Class Initialized
INFO - 2020-09-22 10:19:41 --> Language Class Initialized
INFO - 2020-09-22 10:19:41 --> Loader Class Initialized
INFO - 2020-09-22 10:19:41 --> Helper loaded: url_helper
INFO - 2020-09-22 10:19:41 --> Database Driver Class Initialized
INFO - 2020-09-22 10:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:19:41 --> Email Class Initialized
INFO - 2020-09-22 10:19:41 --> Controller Class Initialized
DEBUG - 2020-09-22 10:19:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:19:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:19:41 --> Model Class Initialized
INFO - 2020-09-22 10:19:41 --> Model Class Initialized
INFO - 2020-09-22 10:19:41 --> Final output sent to browser
DEBUG - 2020-09-22 10:19:41 --> Total execution time: 0.0289
ERROR - 2020-09-22 10:19:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:19:49 --> Config Class Initialized
INFO - 2020-09-22 10:19:49 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:19:49 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:19:49 --> Utf8 Class Initialized
INFO - 2020-09-22 10:19:49 --> URI Class Initialized
INFO - 2020-09-22 10:19:49 --> Router Class Initialized
INFO - 2020-09-22 10:19:49 --> Output Class Initialized
INFO - 2020-09-22 10:19:49 --> Security Class Initialized
DEBUG - 2020-09-22 10:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:19:49 --> Input Class Initialized
INFO - 2020-09-22 10:19:49 --> Language Class Initialized
INFO - 2020-09-22 10:19:49 --> Loader Class Initialized
INFO - 2020-09-22 10:19:49 --> Helper loaded: url_helper
INFO - 2020-09-22 10:19:49 --> Database Driver Class Initialized
INFO - 2020-09-22 10:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:19:49 --> Email Class Initialized
INFO - 2020-09-22 10:19:49 --> Controller Class Initialized
DEBUG - 2020-09-22 10:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:19:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:19:49 --> Model Class Initialized
INFO - 2020-09-22 10:19:49 --> Model Class Initialized
INFO - 2020-09-22 10:19:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 10:19:49 --> Final output sent to browser
DEBUG - 2020-09-22 10:19:49 --> Total execution time: 0.0241
ERROR - 2020-09-22 10:19:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:19:49 --> Config Class Initialized
INFO - 2020-09-22 10:19:49 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:19:49 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:19:49 --> Utf8 Class Initialized
INFO - 2020-09-22 10:19:49 --> URI Class Initialized
INFO - 2020-09-22 10:19:49 --> Router Class Initialized
INFO - 2020-09-22 10:19:49 --> Output Class Initialized
INFO - 2020-09-22 10:19:49 --> Security Class Initialized
DEBUG - 2020-09-22 10:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:19:49 --> Input Class Initialized
INFO - 2020-09-22 10:19:49 --> Language Class Initialized
INFO - 2020-09-22 10:19:49 --> Loader Class Initialized
INFO - 2020-09-22 10:19:49 --> Helper loaded: url_helper
INFO - 2020-09-22 10:19:49 --> Database Driver Class Initialized
INFO - 2020-09-22 10:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:19:49 --> Email Class Initialized
INFO - 2020-09-22 10:19:49 --> Controller Class Initialized
DEBUG - 2020-09-22 10:19:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:19:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:19:49 --> Model Class Initialized
INFO - 2020-09-22 10:19:49 --> Model Class Initialized
INFO - 2020-09-22 10:19:49 --> Final output sent to browser
DEBUG - 2020-09-22 10:19:49 --> Total execution time: 0.0217
ERROR - 2020-09-22 10:20:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:20:17 --> Config Class Initialized
INFO - 2020-09-22 10:20:17 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:20:17 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:20:17 --> Utf8 Class Initialized
INFO - 2020-09-22 10:20:17 --> URI Class Initialized
INFO - 2020-09-22 10:20:17 --> Router Class Initialized
INFO - 2020-09-22 10:20:17 --> Output Class Initialized
INFO - 2020-09-22 10:20:17 --> Security Class Initialized
DEBUG - 2020-09-22 10:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:20:17 --> Input Class Initialized
INFO - 2020-09-22 10:20:17 --> Language Class Initialized
INFO - 2020-09-22 10:20:17 --> Loader Class Initialized
INFO - 2020-09-22 10:20:17 --> Helper loaded: url_helper
INFO - 2020-09-22 10:20:17 --> Database Driver Class Initialized
INFO - 2020-09-22 10:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:20:17 --> Email Class Initialized
INFO - 2020-09-22 10:20:17 --> Controller Class Initialized
DEBUG - 2020-09-22 10:20:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:20:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:20:17 --> Model Class Initialized
INFO - 2020-09-22 10:20:17 --> Model Class Initialized
INFO - 2020-09-22 10:20:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-22 10:20:17 --> Final output sent to browser
DEBUG - 2020-09-22 10:20:17 --> Total execution time: 0.0227
ERROR - 2020-09-22 10:20:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:20:26 --> Config Class Initialized
INFO - 2020-09-22 10:20:26 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:20:26 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:20:26 --> Utf8 Class Initialized
INFO - 2020-09-22 10:20:26 --> URI Class Initialized
DEBUG - 2020-09-22 10:20:26 --> No URI present. Default controller set.
INFO - 2020-09-22 10:20:26 --> Router Class Initialized
INFO - 2020-09-22 10:20:26 --> Output Class Initialized
INFO - 2020-09-22 10:20:26 --> Security Class Initialized
DEBUG - 2020-09-22 10:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:20:26 --> Input Class Initialized
INFO - 2020-09-22 10:20:26 --> Language Class Initialized
INFO - 2020-09-22 10:20:26 --> Loader Class Initialized
INFO - 2020-09-22 10:20:26 --> Helper loaded: url_helper
INFO - 2020-09-22 10:20:26 --> Database Driver Class Initialized
INFO - 2020-09-22 10:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:20:26 --> Email Class Initialized
INFO - 2020-09-22 10:20:26 --> Controller Class Initialized
INFO - 2020-09-22 10:20:26 --> Model Class Initialized
INFO - 2020-09-22 10:20:26 --> Model Class Initialized
DEBUG - 2020-09-22 10:20:26 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:20:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 10:20:26 --> Final output sent to browser
DEBUG - 2020-09-22 10:20:26 --> Total execution time: 0.0228
ERROR - 2020-09-22 10:20:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:20:36 --> Config Class Initialized
INFO - 2020-09-22 10:20:36 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:20:36 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:20:36 --> Utf8 Class Initialized
INFO - 2020-09-22 10:20:36 --> URI Class Initialized
INFO - 2020-09-22 10:20:36 --> Router Class Initialized
INFO - 2020-09-22 10:20:36 --> Output Class Initialized
INFO - 2020-09-22 10:20:36 --> Security Class Initialized
DEBUG - 2020-09-22 10:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:20:36 --> Input Class Initialized
INFO - 2020-09-22 10:20:36 --> Language Class Initialized
INFO - 2020-09-22 10:20:36 --> Loader Class Initialized
INFO - 2020-09-22 10:20:36 --> Helper loaded: url_helper
INFO - 2020-09-22 10:20:36 --> Database Driver Class Initialized
INFO - 2020-09-22 10:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:20:36 --> Email Class Initialized
INFO - 2020-09-22 10:20:36 --> Controller Class Initialized
INFO - 2020-09-22 10:20:36 --> Model Class Initialized
INFO - 2020-09-22 10:20:36 --> Model Class Initialized
DEBUG - 2020-09-22 10:20:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:20:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:20:36 --> Model Class Initialized
INFO - 2020-09-22 10:20:36 --> Final output sent to browser
DEBUG - 2020-09-22 10:20:36 --> Total execution time: 0.0298
ERROR - 2020-09-22 10:20:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:20:36 --> Config Class Initialized
INFO - 2020-09-22 10:20:36 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:20:36 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:20:36 --> Utf8 Class Initialized
INFO - 2020-09-22 10:20:36 --> URI Class Initialized
INFO - 2020-09-22 10:20:36 --> Router Class Initialized
INFO - 2020-09-22 10:20:36 --> Output Class Initialized
INFO - 2020-09-22 10:20:36 --> Security Class Initialized
DEBUG - 2020-09-22 10:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:20:36 --> Input Class Initialized
INFO - 2020-09-22 10:20:36 --> Language Class Initialized
INFO - 2020-09-22 10:20:36 --> Loader Class Initialized
INFO - 2020-09-22 10:20:36 --> Helper loaded: url_helper
INFO - 2020-09-22 10:20:36 --> Database Driver Class Initialized
INFO - 2020-09-22 10:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:20:36 --> Email Class Initialized
INFO - 2020-09-22 10:20:36 --> Controller Class Initialized
INFO - 2020-09-22 10:20:36 --> Model Class Initialized
INFO - 2020-09-22 10:20:36 --> Model Class Initialized
DEBUG - 2020-09-22 10:20:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-22 10:20:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:20:36 --> Config Class Initialized
INFO - 2020-09-22 10:20:36 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:20:36 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:20:36 --> Utf8 Class Initialized
INFO - 2020-09-22 10:20:36 --> URI Class Initialized
INFO - 2020-09-22 10:20:36 --> Router Class Initialized
INFO - 2020-09-22 10:20:36 --> Output Class Initialized
INFO - 2020-09-22 10:20:36 --> Security Class Initialized
DEBUG - 2020-09-22 10:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:20:36 --> Input Class Initialized
INFO - 2020-09-22 10:20:36 --> Language Class Initialized
INFO - 2020-09-22 10:20:36 --> Loader Class Initialized
INFO - 2020-09-22 10:20:36 --> Helper loaded: url_helper
INFO - 2020-09-22 10:20:36 --> Database Driver Class Initialized
INFO - 2020-09-22 10:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:20:36 --> Email Class Initialized
INFO - 2020-09-22 10:20:36 --> Controller Class Initialized
DEBUG - 2020-09-22 10:20:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:20:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:20:36 --> Model Class Initialized
INFO - 2020-09-22 10:20:36 --> Model Class Initialized
INFO - 2020-09-22 10:20:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-22 10:20:36 --> Final output sent to browser
DEBUG - 2020-09-22 10:20:36 --> Total execution time: 0.0251
ERROR - 2020-09-22 10:20:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:20:42 --> Config Class Initialized
INFO - 2020-09-22 10:20:42 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:20:42 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:20:42 --> Utf8 Class Initialized
INFO - 2020-09-22 10:20:42 --> URI Class Initialized
INFO - 2020-09-22 10:20:42 --> Router Class Initialized
INFO - 2020-09-22 10:20:42 --> Output Class Initialized
INFO - 2020-09-22 10:20:42 --> Security Class Initialized
DEBUG - 2020-09-22 10:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:20:42 --> Input Class Initialized
INFO - 2020-09-22 10:20:42 --> Language Class Initialized
INFO - 2020-09-22 10:20:42 --> Loader Class Initialized
INFO - 2020-09-22 10:20:42 --> Helper loaded: url_helper
INFO - 2020-09-22 10:20:42 --> Database Driver Class Initialized
INFO - 2020-09-22 10:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:20:42 --> Email Class Initialized
INFO - 2020-09-22 10:20:42 --> Controller Class Initialized
DEBUG - 2020-09-22 10:20:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:20:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:20:42 --> Model Class Initialized
INFO - 2020-09-22 10:20:42 --> Model Class Initialized
INFO - 2020-09-22 10:20:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-22 10:20:42 --> Final output sent to browser
DEBUG - 2020-09-22 10:20:42 --> Total execution time: 0.0243
ERROR - 2020-09-22 10:20:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:20:44 --> Config Class Initialized
INFO - 2020-09-22 10:20:44 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:20:44 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:20:44 --> Utf8 Class Initialized
INFO - 2020-09-22 10:20:44 --> URI Class Initialized
INFO - 2020-09-22 10:20:44 --> Router Class Initialized
INFO - 2020-09-22 10:20:44 --> Output Class Initialized
INFO - 2020-09-22 10:20:44 --> Security Class Initialized
DEBUG - 2020-09-22 10:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:20:44 --> Input Class Initialized
INFO - 2020-09-22 10:20:44 --> Language Class Initialized
INFO - 2020-09-22 10:20:44 --> Loader Class Initialized
INFO - 2020-09-22 10:20:44 --> Helper loaded: url_helper
INFO - 2020-09-22 10:20:44 --> Database Driver Class Initialized
INFO - 2020-09-22 10:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:20:44 --> Email Class Initialized
INFO - 2020-09-22 10:20:44 --> Controller Class Initialized
DEBUG - 2020-09-22 10:20:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:20:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:20:44 --> Model Class Initialized
INFO - 2020-09-22 10:20:44 --> Model Class Initialized
INFO - 2020-09-22 10:20:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-22 10:20:44 --> Final output sent to browser
DEBUG - 2020-09-22 10:20:44 --> Total execution time: 0.0273
ERROR - 2020-09-22 10:20:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:20:50 --> Config Class Initialized
INFO - 2020-09-22 10:20:50 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:20:50 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:20:50 --> Utf8 Class Initialized
INFO - 2020-09-22 10:20:50 --> URI Class Initialized
INFO - 2020-09-22 10:20:50 --> Router Class Initialized
INFO - 2020-09-22 10:20:50 --> Output Class Initialized
INFO - 2020-09-22 10:20:50 --> Security Class Initialized
DEBUG - 2020-09-22 10:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:20:50 --> Input Class Initialized
INFO - 2020-09-22 10:20:50 --> Language Class Initialized
INFO - 2020-09-22 10:20:50 --> Loader Class Initialized
INFO - 2020-09-22 10:20:50 --> Helper loaded: url_helper
INFO - 2020-09-22 10:20:50 --> Database Driver Class Initialized
INFO - 2020-09-22 10:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:20:50 --> Email Class Initialized
INFO - 2020-09-22 10:20:50 --> Controller Class Initialized
DEBUG - 2020-09-22 10:20:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:20:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:20:50 --> Model Class Initialized
INFO - 2020-09-22 10:20:50 --> Model Class Initialized
INFO - 2020-09-22 10:20:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-22 10:20:50 --> Final output sent to browser
DEBUG - 2020-09-22 10:20:50 --> Total execution time: 0.0213
ERROR - 2020-09-22 10:20:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:20:53 --> Config Class Initialized
INFO - 2020-09-22 10:20:53 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:20:53 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:20:53 --> Utf8 Class Initialized
INFO - 2020-09-22 10:20:53 --> URI Class Initialized
INFO - 2020-09-22 10:20:53 --> Router Class Initialized
INFO - 2020-09-22 10:20:53 --> Output Class Initialized
INFO - 2020-09-22 10:20:53 --> Security Class Initialized
DEBUG - 2020-09-22 10:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:20:53 --> Input Class Initialized
INFO - 2020-09-22 10:20:53 --> Language Class Initialized
INFO - 2020-09-22 10:20:53 --> Loader Class Initialized
INFO - 2020-09-22 10:20:53 --> Helper loaded: url_helper
INFO - 2020-09-22 10:20:53 --> Database Driver Class Initialized
INFO - 2020-09-22 10:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:20:53 --> Email Class Initialized
INFO - 2020-09-22 10:20:53 --> Controller Class Initialized
DEBUG - 2020-09-22 10:20:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:20:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:20:53 --> Model Class Initialized
INFO - 2020-09-22 10:20:53 --> Model Class Initialized
INFO - 2020-09-22 10:20:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-22 10:20:53 --> Final output sent to browser
DEBUG - 2020-09-22 10:20:53 --> Total execution time: 0.0303
ERROR - 2020-09-22 10:21:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:21:10 --> Config Class Initialized
INFO - 2020-09-22 10:21:10 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:21:10 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:21:10 --> Utf8 Class Initialized
INFO - 2020-09-22 10:21:10 --> URI Class Initialized
INFO - 2020-09-22 10:21:10 --> Router Class Initialized
INFO - 2020-09-22 10:21:10 --> Output Class Initialized
INFO - 2020-09-22 10:21:10 --> Security Class Initialized
DEBUG - 2020-09-22 10:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:21:10 --> Input Class Initialized
INFO - 2020-09-22 10:21:10 --> Language Class Initialized
INFO - 2020-09-22 10:21:10 --> Loader Class Initialized
INFO - 2020-09-22 10:21:10 --> Helper loaded: url_helper
INFO - 2020-09-22 10:21:10 --> Database Driver Class Initialized
INFO - 2020-09-22 10:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:21:10 --> Email Class Initialized
INFO - 2020-09-22 10:21:10 --> Controller Class Initialized
DEBUG - 2020-09-22 10:21:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:21:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:21:10 --> Model Class Initialized
INFO - 2020-09-22 10:21:10 --> Model Class Initialized
INFO - 2020-09-22 10:21:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-22 10:21:10 --> Final output sent to browser
DEBUG - 2020-09-22 10:21:10 --> Total execution time: 0.0235
ERROR - 2020-09-22 10:21:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:21:14 --> Config Class Initialized
INFO - 2020-09-22 10:21:14 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:21:14 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:21:14 --> Utf8 Class Initialized
INFO - 2020-09-22 10:21:14 --> URI Class Initialized
INFO - 2020-09-22 10:21:14 --> Router Class Initialized
INFO - 2020-09-22 10:21:14 --> Output Class Initialized
INFO - 2020-09-22 10:21:14 --> Security Class Initialized
DEBUG - 2020-09-22 10:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:21:14 --> Input Class Initialized
INFO - 2020-09-22 10:21:14 --> Language Class Initialized
INFO - 2020-09-22 10:21:14 --> Loader Class Initialized
INFO - 2020-09-22 10:21:14 --> Helper loaded: url_helper
INFO - 2020-09-22 10:21:14 --> Database Driver Class Initialized
INFO - 2020-09-22 10:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:21:14 --> Email Class Initialized
INFO - 2020-09-22 10:21:14 --> Controller Class Initialized
DEBUG - 2020-09-22 10:21:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:21:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:21:14 --> Model Class Initialized
INFO - 2020-09-22 10:21:14 --> Model Class Initialized
INFO - 2020-09-22 10:21:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-22 10:21:14 --> Final output sent to browser
DEBUG - 2020-09-22 10:21:14 --> Total execution time: 0.0237
ERROR - 2020-09-22 10:21:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:21:21 --> Config Class Initialized
INFO - 2020-09-22 10:21:21 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:21:21 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:21:21 --> Utf8 Class Initialized
INFO - 2020-09-22 10:21:21 --> URI Class Initialized
INFO - 2020-09-22 10:21:21 --> Router Class Initialized
INFO - 2020-09-22 10:21:21 --> Output Class Initialized
INFO - 2020-09-22 10:21:21 --> Security Class Initialized
DEBUG - 2020-09-22 10:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:21:21 --> Input Class Initialized
INFO - 2020-09-22 10:21:21 --> Language Class Initialized
INFO - 2020-09-22 10:21:21 --> Loader Class Initialized
INFO - 2020-09-22 10:21:21 --> Helper loaded: url_helper
INFO - 2020-09-22 10:21:21 --> Database Driver Class Initialized
INFO - 2020-09-22 10:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:21:21 --> Email Class Initialized
INFO - 2020-09-22 10:21:21 --> Controller Class Initialized
DEBUG - 2020-09-22 10:21:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:21:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:21:21 --> Model Class Initialized
INFO - 2020-09-22 10:21:21 --> Model Class Initialized
INFO - 2020-09-22 10:21:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-22 10:21:21 --> Final output sent to browser
DEBUG - 2020-09-22 10:21:21 --> Total execution time: 0.0259
ERROR - 2020-09-22 10:21:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:21:35 --> Config Class Initialized
INFO - 2020-09-22 10:21:35 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:21:35 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:21:35 --> Utf8 Class Initialized
INFO - 2020-09-22 10:21:35 --> URI Class Initialized
INFO - 2020-09-22 10:21:35 --> Router Class Initialized
INFO - 2020-09-22 10:21:35 --> Output Class Initialized
INFO - 2020-09-22 10:21:35 --> Security Class Initialized
DEBUG - 2020-09-22 10:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:21:35 --> Input Class Initialized
INFO - 2020-09-22 10:21:35 --> Language Class Initialized
INFO - 2020-09-22 10:21:35 --> Loader Class Initialized
INFO - 2020-09-22 10:21:35 --> Helper loaded: url_helper
INFO - 2020-09-22 10:21:35 --> Database Driver Class Initialized
INFO - 2020-09-22 10:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:21:35 --> Email Class Initialized
INFO - 2020-09-22 10:21:35 --> Controller Class Initialized
DEBUG - 2020-09-22 10:21:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:21:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:21:35 --> Model Class Initialized
INFO - 2020-09-22 10:21:35 --> Model Class Initialized
INFO - 2020-09-22 10:21:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-22 10:21:35 --> Final output sent to browser
DEBUG - 2020-09-22 10:21:35 --> Total execution time: 0.0272
ERROR - 2020-09-22 10:21:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:21:40 --> Config Class Initialized
INFO - 2020-09-22 10:21:40 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:21:40 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:21:40 --> Utf8 Class Initialized
INFO - 2020-09-22 10:21:40 --> URI Class Initialized
INFO - 2020-09-22 10:21:40 --> Router Class Initialized
INFO - 2020-09-22 10:21:40 --> Output Class Initialized
INFO - 2020-09-22 10:21:40 --> Security Class Initialized
DEBUG - 2020-09-22 10:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:21:40 --> Input Class Initialized
INFO - 2020-09-22 10:21:40 --> Language Class Initialized
INFO - 2020-09-22 10:21:40 --> Loader Class Initialized
INFO - 2020-09-22 10:21:40 --> Helper loaded: url_helper
INFO - 2020-09-22 10:21:40 --> Database Driver Class Initialized
INFO - 2020-09-22 10:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:21:40 --> Email Class Initialized
INFO - 2020-09-22 10:21:40 --> Controller Class Initialized
DEBUG - 2020-09-22 10:21:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:21:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:21:40 --> Model Class Initialized
INFO - 2020-09-22 10:21:40 --> Model Class Initialized
INFO - 2020-09-22 10:21:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-22 10:21:40 --> Final output sent to browser
DEBUG - 2020-09-22 10:21:40 --> Total execution time: 0.0236
ERROR - 2020-09-22 10:21:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:21:54 --> Config Class Initialized
INFO - 2020-09-22 10:21:54 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:21:54 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:21:54 --> Utf8 Class Initialized
INFO - 2020-09-22 10:21:54 --> URI Class Initialized
INFO - 2020-09-22 10:21:54 --> Router Class Initialized
INFO - 2020-09-22 10:21:54 --> Output Class Initialized
INFO - 2020-09-22 10:21:54 --> Security Class Initialized
DEBUG - 2020-09-22 10:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:21:54 --> Input Class Initialized
INFO - 2020-09-22 10:21:54 --> Language Class Initialized
INFO - 2020-09-22 10:21:54 --> Loader Class Initialized
INFO - 2020-09-22 10:21:54 --> Helper loaded: url_helper
INFO - 2020-09-22 10:21:54 --> Database Driver Class Initialized
INFO - 2020-09-22 10:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:21:54 --> Email Class Initialized
INFO - 2020-09-22 10:21:54 --> Controller Class Initialized
DEBUG - 2020-09-22 10:21:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:21:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:21:54 --> Model Class Initialized
INFO - 2020-09-22 10:21:54 --> Model Class Initialized
INFO - 2020-09-22 10:21:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-22 10:21:54 --> Final output sent to browser
DEBUG - 2020-09-22 10:21:54 --> Total execution time: 0.0241
ERROR - 2020-09-22 10:24:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:24:32 --> Config Class Initialized
INFO - 2020-09-22 10:24:32 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:24:32 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:24:32 --> Utf8 Class Initialized
INFO - 2020-09-22 10:24:32 --> URI Class Initialized
INFO - 2020-09-22 10:24:32 --> Router Class Initialized
INFO - 2020-09-22 10:24:32 --> Output Class Initialized
INFO - 2020-09-22 10:24:32 --> Security Class Initialized
DEBUG - 2020-09-22 10:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:24:32 --> Input Class Initialized
INFO - 2020-09-22 10:24:32 --> Language Class Initialized
INFO - 2020-09-22 10:24:32 --> Loader Class Initialized
INFO - 2020-09-22 10:24:32 --> Helper loaded: url_helper
INFO - 2020-09-22 10:24:32 --> Database Driver Class Initialized
INFO - 2020-09-22 10:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:24:32 --> Email Class Initialized
INFO - 2020-09-22 10:24:32 --> Controller Class Initialized
DEBUG - 2020-09-22 10:24:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:24:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:24:32 --> Model Class Initialized
INFO - 2020-09-22 10:24:32 --> Model Class Initialized
INFO - 2020-09-22 10:24:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-22 10:24:32 --> Final output sent to browser
DEBUG - 2020-09-22 10:24:32 --> Total execution time: 0.0295
ERROR - 2020-09-22 10:24:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:24:38 --> Config Class Initialized
INFO - 2020-09-22 10:24:38 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:24:38 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:24:38 --> Utf8 Class Initialized
INFO - 2020-09-22 10:24:38 --> URI Class Initialized
INFO - 2020-09-22 10:24:38 --> Router Class Initialized
INFO - 2020-09-22 10:24:38 --> Output Class Initialized
INFO - 2020-09-22 10:24:38 --> Security Class Initialized
DEBUG - 2020-09-22 10:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:24:38 --> Input Class Initialized
INFO - 2020-09-22 10:24:38 --> Language Class Initialized
INFO - 2020-09-22 10:24:38 --> Loader Class Initialized
INFO - 2020-09-22 10:24:38 --> Helper loaded: url_helper
INFO - 2020-09-22 10:24:38 --> Database Driver Class Initialized
INFO - 2020-09-22 10:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:24:38 --> Email Class Initialized
INFO - 2020-09-22 10:24:38 --> Controller Class Initialized
DEBUG - 2020-09-22 10:24:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:24:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:24:38 --> Model Class Initialized
INFO - 2020-09-22 10:24:38 --> Model Class Initialized
INFO - 2020-09-22 10:24:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-22 10:24:38 --> Final output sent to browser
DEBUG - 2020-09-22 10:24:38 --> Total execution time: 0.0304
ERROR - 2020-09-22 10:27:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:27:20 --> Config Class Initialized
INFO - 2020-09-22 10:27:20 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:27:20 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:27:20 --> Utf8 Class Initialized
INFO - 2020-09-22 10:27:20 --> URI Class Initialized
INFO - 2020-09-22 10:27:20 --> Router Class Initialized
INFO - 2020-09-22 10:27:20 --> Output Class Initialized
INFO - 2020-09-22 10:27:20 --> Security Class Initialized
DEBUG - 2020-09-22 10:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:27:20 --> Input Class Initialized
INFO - 2020-09-22 10:27:20 --> Language Class Initialized
INFO - 2020-09-22 10:27:20 --> Loader Class Initialized
INFO - 2020-09-22 10:27:20 --> Helper loaded: url_helper
INFO - 2020-09-22 10:27:20 --> Database Driver Class Initialized
INFO - 2020-09-22 10:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:27:20 --> Email Class Initialized
INFO - 2020-09-22 10:27:20 --> Controller Class Initialized
DEBUG - 2020-09-22 10:27:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:27:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:27:20 --> Model Class Initialized
INFO - 2020-09-22 10:27:20 --> Model Class Initialized
INFO - 2020-09-22 10:27:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-22 10:27:20 --> Final output sent to browser
DEBUG - 2020-09-22 10:27:20 --> Total execution time: 0.0242
ERROR - 2020-09-22 10:27:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:27:39 --> Config Class Initialized
INFO - 2020-09-22 10:27:39 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:27:39 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:27:39 --> Utf8 Class Initialized
INFO - 2020-09-22 10:27:39 --> URI Class Initialized
INFO - 2020-09-22 10:27:39 --> Router Class Initialized
INFO - 2020-09-22 10:27:39 --> Output Class Initialized
INFO - 2020-09-22 10:27:39 --> Security Class Initialized
DEBUG - 2020-09-22 10:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:27:39 --> Input Class Initialized
INFO - 2020-09-22 10:27:39 --> Language Class Initialized
INFO - 2020-09-22 10:27:39 --> Loader Class Initialized
INFO - 2020-09-22 10:27:39 --> Helper loaded: url_helper
INFO - 2020-09-22 10:27:39 --> Database Driver Class Initialized
INFO - 2020-09-22 10:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:27:39 --> Email Class Initialized
INFO - 2020-09-22 10:27:39 --> Controller Class Initialized
DEBUG - 2020-09-22 10:27:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:27:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:27:39 --> Model Class Initialized
INFO - 2020-09-22 10:27:39 --> Model Class Initialized
INFO - 2020-09-22 10:27:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-22 10:27:39 --> Final output sent to browser
DEBUG - 2020-09-22 10:27:39 --> Total execution time: 0.0273
ERROR - 2020-09-22 10:28:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:28:38 --> Config Class Initialized
INFO - 2020-09-22 10:28:38 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:28:38 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:28:38 --> Utf8 Class Initialized
INFO - 2020-09-22 10:28:38 --> URI Class Initialized
DEBUG - 2020-09-22 10:28:38 --> No URI present. Default controller set.
INFO - 2020-09-22 10:28:38 --> Router Class Initialized
INFO - 2020-09-22 10:28:38 --> Output Class Initialized
INFO - 2020-09-22 10:28:38 --> Security Class Initialized
DEBUG - 2020-09-22 10:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:28:38 --> Input Class Initialized
INFO - 2020-09-22 10:28:38 --> Language Class Initialized
INFO - 2020-09-22 10:28:38 --> Loader Class Initialized
INFO - 2020-09-22 10:28:38 --> Helper loaded: url_helper
INFO - 2020-09-22 10:28:38 --> Database Driver Class Initialized
INFO - 2020-09-22 10:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:28:38 --> Email Class Initialized
INFO - 2020-09-22 10:28:38 --> Controller Class Initialized
INFO - 2020-09-22 10:28:38 --> Model Class Initialized
INFO - 2020-09-22 10:28:38 --> Model Class Initialized
DEBUG - 2020-09-22 10:28:38 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:28:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 10:28:38 --> Final output sent to browser
DEBUG - 2020-09-22 10:28:38 --> Total execution time: 0.0217
ERROR - 2020-09-22 10:28:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:28:58 --> Config Class Initialized
INFO - 2020-09-22 10:28:58 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:28:58 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:28:58 --> Utf8 Class Initialized
INFO - 2020-09-22 10:28:58 --> URI Class Initialized
INFO - 2020-09-22 10:28:58 --> Router Class Initialized
INFO - 2020-09-22 10:28:58 --> Output Class Initialized
INFO - 2020-09-22 10:28:58 --> Security Class Initialized
DEBUG - 2020-09-22 10:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:28:58 --> Input Class Initialized
INFO - 2020-09-22 10:28:58 --> Language Class Initialized
INFO - 2020-09-22 10:28:58 --> Loader Class Initialized
INFO - 2020-09-22 10:28:58 --> Helper loaded: url_helper
INFO - 2020-09-22 10:28:58 --> Database Driver Class Initialized
INFO - 2020-09-22 10:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:28:58 --> Email Class Initialized
INFO - 2020-09-22 10:28:58 --> Controller Class Initialized
INFO - 2020-09-22 10:28:58 --> Model Class Initialized
INFO - 2020-09-22 10:28:58 --> Model Class Initialized
DEBUG - 2020-09-22 10:28:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:28:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:28:58 --> Model Class Initialized
INFO - 2020-09-22 10:28:58 --> Final output sent to browser
DEBUG - 2020-09-22 10:28:58 --> Total execution time: 0.0277
ERROR - 2020-09-22 10:28:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:28:58 --> Config Class Initialized
INFO - 2020-09-22 10:28:58 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:28:58 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:28:58 --> Utf8 Class Initialized
INFO - 2020-09-22 10:28:58 --> URI Class Initialized
INFO - 2020-09-22 10:28:58 --> Router Class Initialized
INFO - 2020-09-22 10:28:58 --> Output Class Initialized
INFO - 2020-09-22 10:28:58 --> Security Class Initialized
DEBUG - 2020-09-22 10:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:28:58 --> Input Class Initialized
INFO - 2020-09-22 10:28:58 --> Language Class Initialized
INFO - 2020-09-22 10:28:58 --> Loader Class Initialized
INFO - 2020-09-22 10:28:58 --> Helper loaded: url_helper
INFO - 2020-09-22 10:28:58 --> Database Driver Class Initialized
INFO - 2020-09-22 10:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:28:58 --> Email Class Initialized
INFO - 2020-09-22 10:28:58 --> Controller Class Initialized
INFO - 2020-09-22 10:28:58 --> Model Class Initialized
INFO - 2020-09-22 10:28:58 --> Model Class Initialized
DEBUG - 2020-09-22 10:28:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-22 10:28:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:28:58 --> Config Class Initialized
INFO - 2020-09-22 10:28:58 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:28:58 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:28:58 --> Utf8 Class Initialized
INFO - 2020-09-22 10:28:58 --> URI Class Initialized
INFO - 2020-09-22 10:28:58 --> Router Class Initialized
INFO - 2020-09-22 10:28:58 --> Output Class Initialized
INFO - 2020-09-22 10:28:58 --> Security Class Initialized
DEBUG - 2020-09-22 10:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:28:58 --> Input Class Initialized
INFO - 2020-09-22 10:28:58 --> Language Class Initialized
INFO - 2020-09-22 10:28:58 --> Loader Class Initialized
INFO - 2020-09-22 10:28:58 --> Helper loaded: url_helper
INFO - 2020-09-22 10:28:58 --> Database Driver Class Initialized
INFO - 2020-09-22 10:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:28:58 --> Email Class Initialized
INFO - 2020-09-22 10:28:58 --> Controller Class Initialized
DEBUG - 2020-09-22 10:28:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:28:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:28:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-22 10:28:58 --> Final output sent to browser
DEBUG - 2020-09-22 10:28:58 --> Total execution time: 0.0460
ERROR - 2020-09-22 10:29:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:29:08 --> Config Class Initialized
INFO - 2020-09-22 10:29:08 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:29:08 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:29:08 --> Utf8 Class Initialized
INFO - 2020-09-22 10:29:08 --> URI Class Initialized
INFO - 2020-09-22 10:29:08 --> Router Class Initialized
INFO - 2020-09-22 10:29:08 --> Output Class Initialized
INFO - 2020-09-22 10:29:08 --> Security Class Initialized
DEBUG - 2020-09-22 10:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:29:08 --> Input Class Initialized
INFO - 2020-09-22 10:29:08 --> Language Class Initialized
INFO - 2020-09-22 10:29:08 --> Loader Class Initialized
INFO - 2020-09-22 10:29:08 --> Helper loaded: url_helper
INFO - 2020-09-22 10:29:08 --> Database Driver Class Initialized
INFO - 2020-09-22 10:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:29:08 --> Email Class Initialized
INFO - 2020-09-22 10:29:08 --> Controller Class Initialized
INFO - 2020-09-22 10:29:08 --> Model Class Initialized
INFO - 2020-09-22 10:29:08 --> Model Class Initialized
INFO - 2020-09-22 10:29:08 --> Model Class Initialized
INFO - 2020-09-22 10:29:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-22 10:29:08 --> Final output sent to browser
DEBUG - 2020-09-22 10:29:08 --> Total execution time: 0.1824
ERROR - 2020-09-22 10:29:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:29:08 --> Config Class Initialized
INFO - 2020-09-22 10:29:08 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:29:08 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:29:08 --> Utf8 Class Initialized
INFO - 2020-09-22 10:29:08 --> URI Class Initialized
INFO - 2020-09-22 10:29:08 --> Router Class Initialized
INFO - 2020-09-22 10:29:08 --> Output Class Initialized
INFO - 2020-09-22 10:29:08 --> Security Class Initialized
DEBUG - 2020-09-22 10:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:29:08 --> Input Class Initialized
INFO - 2020-09-22 10:29:08 --> Language Class Initialized
INFO - 2020-09-22 10:29:08 --> Loader Class Initialized
INFO - 2020-09-22 10:29:08 --> Helper loaded: url_helper
INFO - 2020-09-22 10:29:08 --> Database Driver Class Initialized
INFO - 2020-09-22 10:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:29:08 --> Email Class Initialized
INFO - 2020-09-22 10:29:08 --> Controller Class Initialized
INFO - 2020-09-22 10:29:08 --> Model Class Initialized
INFO - 2020-09-22 10:29:08 --> Model Class Initialized
INFO - 2020-09-22 10:29:08 --> Final output sent to browser
DEBUG - 2020-09-22 10:29:08 --> Total execution time: 0.0446
ERROR - 2020-09-22 10:29:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:29:17 --> Config Class Initialized
INFO - 2020-09-22 10:29:17 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:29:17 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:29:17 --> Utf8 Class Initialized
INFO - 2020-09-22 10:29:17 --> URI Class Initialized
DEBUG - 2020-09-22 10:29:17 --> No URI present. Default controller set.
INFO - 2020-09-22 10:29:17 --> Router Class Initialized
INFO - 2020-09-22 10:29:17 --> Output Class Initialized
INFO - 2020-09-22 10:29:17 --> Security Class Initialized
DEBUG - 2020-09-22 10:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:29:17 --> Input Class Initialized
INFO - 2020-09-22 10:29:17 --> Language Class Initialized
INFO - 2020-09-22 10:29:17 --> Loader Class Initialized
INFO - 2020-09-22 10:29:17 --> Helper loaded: url_helper
INFO - 2020-09-22 10:29:17 --> Database Driver Class Initialized
INFO - 2020-09-22 10:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:29:17 --> Email Class Initialized
INFO - 2020-09-22 10:29:17 --> Controller Class Initialized
INFO - 2020-09-22 10:29:17 --> Model Class Initialized
INFO - 2020-09-22 10:29:17 --> Model Class Initialized
DEBUG - 2020-09-22 10:29:17 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:29:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 10:29:17 --> Final output sent to browser
DEBUG - 2020-09-22 10:29:17 --> Total execution time: 0.0176
ERROR - 2020-09-22 10:29:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:29:20 --> Config Class Initialized
INFO - 2020-09-22 10:29:20 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:29:20 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:29:20 --> Utf8 Class Initialized
INFO - 2020-09-22 10:29:20 --> URI Class Initialized
INFO - 2020-09-22 10:29:20 --> Router Class Initialized
INFO - 2020-09-22 10:29:20 --> Output Class Initialized
INFO - 2020-09-22 10:29:20 --> Security Class Initialized
DEBUG - 2020-09-22 10:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:29:20 --> Input Class Initialized
INFO - 2020-09-22 10:29:20 --> Language Class Initialized
INFO - 2020-09-22 10:29:20 --> Loader Class Initialized
INFO - 2020-09-22 10:29:20 --> Helper loaded: url_helper
INFO - 2020-09-22 10:29:20 --> Database Driver Class Initialized
INFO - 2020-09-22 10:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:29:20 --> Email Class Initialized
INFO - 2020-09-22 10:29:20 --> Controller Class Initialized
INFO - 2020-09-22 10:29:20 --> Model Class Initialized
INFO - 2020-09-22 10:29:20 --> Model Class Initialized
DEBUG - 2020-09-22 10:29:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:29:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:29:20 --> Model Class Initialized
INFO - 2020-09-22 10:29:20 --> Final output sent to browser
DEBUG - 2020-09-22 10:29:20 --> Total execution time: 0.0227
ERROR - 2020-09-22 10:29:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:29:20 --> Config Class Initialized
INFO - 2020-09-22 10:29:20 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:29:20 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:29:20 --> Utf8 Class Initialized
INFO - 2020-09-22 10:29:20 --> URI Class Initialized
INFO - 2020-09-22 10:29:20 --> Router Class Initialized
INFO - 2020-09-22 10:29:20 --> Output Class Initialized
INFO - 2020-09-22 10:29:20 --> Security Class Initialized
DEBUG - 2020-09-22 10:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:29:20 --> Input Class Initialized
INFO - 2020-09-22 10:29:20 --> Language Class Initialized
INFO - 2020-09-22 10:29:20 --> Loader Class Initialized
INFO - 2020-09-22 10:29:20 --> Helper loaded: url_helper
INFO - 2020-09-22 10:29:20 --> Database Driver Class Initialized
INFO - 2020-09-22 10:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:29:20 --> Email Class Initialized
INFO - 2020-09-22 10:29:20 --> Controller Class Initialized
INFO - 2020-09-22 10:29:20 --> Model Class Initialized
INFO - 2020-09-22 10:29:20 --> Model Class Initialized
DEBUG - 2020-09-22 10:29:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-22 10:29:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:29:20 --> Config Class Initialized
INFO - 2020-09-22 10:29:20 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:29:20 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:29:20 --> Utf8 Class Initialized
INFO - 2020-09-22 10:29:20 --> URI Class Initialized
INFO - 2020-09-22 10:29:20 --> Router Class Initialized
INFO - 2020-09-22 10:29:20 --> Output Class Initialized
INFO - 2020-09-22 10:29:20 --> Security Class Initialized
DEBUG - 2020-09-22 10:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:29:20 --> Input Class Initialized
INFO - 2020-09-22 10:29:20 --> Language Class Initialized
INFO - 2020-09-22 10:29:20 --> Loader Class Initialized
INFO - 2020-09-22 10:29:20 --> Helper loaded: url_helper
INFO - 2020-09-22 10:29:20 --> Database Driver Class Initialized
INFO - 2020-09-22 10:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:29:20 --> Email Class Initialized
INFO - 2020-09-22 10:29:20 --> Controller Class Initialized
DEBUG - 2020-09-22 10:29:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:29:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:29:20 --> Model Class Initialized
INFO - 2020-09-22 10:29:20 --> Model Class Initialized
INFO - 2020-09-22 10:29:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-22 10:29:20 --> Final output sent to browser
DEBUG - 2020-09-22 10:29:20 --> Total execution time: 0.0252
ERROR - 2020-09-22 10:29:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:29:24 --> Config Class Initialized
INFO - 2020-09-22 10:29:24 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:29:24 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:29:24 --> Utf8 Class Initialized
INFO - 2020-09-22 10:29:24 --> URI Class Initialized
INFO - 2020-09-22 10:29:24 --> Router Class Initialized
INFO - 2020-09-22 10:29:24 --> Output Class Initialized
INFO - 2020-09-22 10:29:24 --> Security Class Initialized
DEBUG - 2020-09-22 10:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:29:24 --> Input Class Initialized
INFO - 2020-09-22 10:29:24 --> Language Class Initialized
INFO - 2020-09-22 10:29:24 --> Loader Class Initialized
INFO - 2020-09-22 10:29:24 --> Helper loaded: url_helper
INFO - 2020-09-22 10:29:24 --> Database Driver Class Initialized
INFO - 2020-09-22 10:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:29:24 --> Email Class Initialized
INFO - 2020-09-22 10:29:24 --> Controller Class Initialized
DEBUG - 2020-09-22 10:29:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:29:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:29:24 --> Model Class Initialized
INFO - 2020-09-22 10:29:24 --> Model Class Initialized
INFO - 2020-09-22 10:29:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-22 10:29:24 --> Final output sent to browser
DEBUG - 2020-09-22 10:29:24 --> Total execution time: 0.0231
ERROR - 2020-09-22 10:29:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:29:28 --> Config Class Initialized
INFO - 2020-09-22 10:29:28 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:29:28 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:29:28 --> Utf8 Class Initialized
INFO - 2020-09-22 10:29:28 --> URI Class Initialized
INFO - 2020-09-22 10:29:28 --> Router Class Initialized
INFO - 2020-09-22 10:29:28 --> Output Class Initialized
INFO - 2020-09-22 10:29:28 --> Security Class Initialized
DEBUG - 2020-09-22 10:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:29:28 --> Input Class Initialized
INFO - 2020-09-22 10:29:28 --> Language Class Initialized
INFO - 2020-09-22 10:29:28 --> Loader Class Initialized
INFO - 2020-09-22 10:29:28 --> Helper loaded: url_helper
INFO - 2020-09-22 10:29:28 --> Database Driver Class Initialized
INFO - 2020-09-22 10:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:29:28 --> Email Class Initialized
INFO - 2020-09-22 10:29:28 --> Controller Class Initialized
DEBUG - 2020-09-22 10:29:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:29:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:29:28 --> Model Class Initialized
INFO - 2020-09-22 10:29:28 --> Model Class Initialized
INFO - 2020-09-22 10:29:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-22 10:29:28 --> Final output sent to browser
DEBUG - 2020-09-22 10:29:28 --> Total execution time: 0.0250
ERROR - 2020-09-22 10:29:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:29:47 --> Config Class Initialized
INFO - 2020-09-22 10:29:47 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:29:47 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:29:47 --> Utf8 Class Initialized
INFO - 2020-09-22 10:29:47 --> URI Class Initialized
INFO - 2020-09-22 10:29:47 --> Router Class Initialized
INFO - 2020-09-22 10:29:47 --> Output Class Initialized
INFO - 2020-09-22 10:29:47 --> Security Class Initialized
DEBUG - 2020-09-22 10:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:29:47 --> Input Class Initialized
INFO - 2020-09-22 10:29:47 --> Language Class Initialized
INFO - 2020-09-22 10:29:47 --> Loader Class Initialized
INFO - 2020-09-22 10:29:47 --> Helper loaded: url_helper
INFO - 2020-09-22 10:29:47 --> Database Driver Class Initialized
INFO - 2020-09-22 10:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:29:47 --> Email Class Initialized
INFO - 2020-09-22 10:29:47 --> Controller Class Initialized
DEBUG - 2020-09-22 10:29:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:29:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:29:47 --> Model Class Initialized
INFO - 2020-09-22 10:29:47 --> Model Class Initialized
INFO - 2020-09-22 10:29:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 10:29:47 --> Final output sent to browser
DEBUG - 2020-09-22 10:29:47 --> Total execution time: 0.0266
ERROR - 2020-09-22 10:29:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:29:48 --> Config Class Initialized
INFO - 2020-09-22 10:29:48 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:29:48 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:29:48 --> Utf8 Class Initialized
INFO - 2020-09-22 10:29:48 --> URI Class Initialized
INFO - 2020-09-22 10:29:48 --> Router Class Initialized
INFO - 2020-09-22 10:29:48 --> Output Class Initialized
INFO - 2020-09-22 10:29:48 --> Security Class Initialized
DEBUG - 2020-09-22 10:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:29:48 --> Input Class Initialized
INFO - 2020-09-22 10:29:48 --> Language Class Initialized
INFO - 2020-09-22 10:29:48 --> Loader Class Initialized
INFO - 2020-09-22 10:29:48 --> Helper loaded: url_helper
INFO - 2020-09-22 10:29:48 --> Database Driver Class Initialized
INFO - 2020-09-22 10:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:29:48 --> Email Class Initialized
INFO - 2020-09-22 10:29:48 --> Controller Class Initialized
DEBUG - 2020-09-22 10:29:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:29:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:29:48 --> Model Class Initialized
INFO - 2020-09-22 10:29:48 --> Model Class Initialized
INFO - 2020-09-22 10:29:48 --> Final output sent to browser
DEBUG - 2020-09-22 10:29:48 --> Total execution time: 0.0249
ERROR - 2020-09-22 10:30:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:30:33 --> Config Class Initialized
INFO - 2020-09-22 10:30:33 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:30:33 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:30:33 --> Utf8 Class Initialized
INFO - 2020-09-22 10:30:33 --> URI Class Initialized
INFO - 2020-09-22 10:30:33 --> Router Class Initialized
INFO - 2020-09-22 10:30:33 --> Output Class Initialized
INFO - 2020-09-22 10:30:33 --> Security Class Initialized
DEBUG - 2020-09-22 10:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:30:33 --> Input Class Initialized
INFO - 2020-09-22 10:30:33 --> Language Class Initialized
INFO - 2020-09-22 10:30:33 --> Loader Class Initialized
INFO - 2020-09-22 10:30:33 --> Helper loaded: url_helper
INFO - 2020-09-22 10:30:33 --> Database Driver Class Initialized
INFO - 2020-09-22 10:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:30:33 --> Email Class Initialized
INFO - 2020-09-22 10:30:33 --> Controller Class Initialized
DEBUG - 2020-09-22 10:30:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:30:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:30:33 --> Model Class Initialized
INFO - 2020-09-22 10:30:33 --> Model Class Initialized
INFO - 2020-09-22 10:30:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 10:30:33 --> Final output sent to browser
DEBUG - 2020-09-22 10:30:33 --> Total execution time: 0.0310
ERROR - 2020-09-22 10:30:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:30:34 --> Config Class Initialized
INFO - 2020-09-22 10:30:34 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:30:34 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:30:34 --> Utf8 Class Initialized
INFO - 2020-09-22 10:30:34 --> URI Class Initialized
INFO - 2020-09-22 10:30:34 --> Router Class Initialized
INFO - 2020-09-22 10:30:34 --> Output Class Initialized
INFO - 2020-09-22 10:30:34 --> Security Class Initialized
DEBUG - 2020-09-22 10:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:30:34 --> Input Class Initialized
INFO - 2020-09-22 10:30:34 --> Language Class Initialized
INFO - 2020-09-22 10:30:34 --> Loader Class Initialized
INFO - 2020-09-22 10:30:34 --> Helper loaded: url_helper
INFO - 2020-09-22 10:30:34 --> Database Driver Class Initialized
INFO - 2020-09-22 10:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:30:34 --> Email Class Initialized
INFO - 2020-09-22 10:30:34 --> Controller Class Initialized
DEBUG - 2020-09-22 10:30:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:30:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:30:34 --> Model Class Initialized
INFO - 2020-09-22 10:30:34 --> Model Class Initialized
INFO - 2020-09-22 10:30:34 --> Final output sent to browser
DEBUG - 2020-09-22 10:30:34 --> Total execution time: 0.0313
ERROR - 2020-09-22 10:30:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:30:41 --> Config Class Initialized
INFO - 2020-09-22 10:30:41 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:30:41 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:30:41 --> Utf8 Class Initialized
INFO - 2020-09-22 10:30:41 --> URI Class Initialized
INFO - 2020-09-22 10:30:41 --> Router Class Initialized
INFO - 2020-09-22 10:30:41 --> Output Class Initialized
INFO - 2020-09-22 10:30:41 --> Security Class Initialized
DEBUG - 2020-09-22 10:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:30:41 --> Input Class Initialized
INFO - 2020-09-22 10:30:41 --> Language Class Initialized
INFO - 2020-09-22 10:30:41 --> Loader Class Initialized
INFO - 2020-09-22 10:30:41 --> Helper loaded: url_helper
INFO - 2020-09-22 10:30:41 --> Database Driver Class Initialized
INFO - 2020-09-22 10:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:30:41 --> Email Class Initialized
INFO - 2020-09-22 10:30:41 --> Controller Class Initialized
DEBUG - 2020-09-22 10:30:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:30:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:30:41 --> Model Class Initialized
INFO - 2020-09-22 10:30:41 --> Model Class Initialized
INFO - 2020-09-22 10:30:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 10:30:41 --> Final output sent to browser
DEBUG - 2020-09-22 10:30:41 --> Total execution time: 0.0266
ERROR - 2020-09-22 10:30:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:30:42 --> Config Class Initialized
INFO - 2020-09-22 10:30:42 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:30:42 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:30:42 --> Utf8 Class Initialized
INFO - 2020-09-22 10:30:42 --> URI Class Initialized
INFO - 2020-09-22 10:30:42 --> Router Class Initialized
INFO - 2020-09-22 10:30:42 --> Output Class Initialized
INFO - 2020-09-22 10:30:42 --> Security Class Initialized
DEBUG - 2020-09-22 10:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:30:42 --> Input Class Initialized
INFO - 2020-09-22 10:30:42 --> Language Class Initialized
INFO - 2020-09-22 10:30:42 --> Loader Class Initialized
INFO - 2020-09-22 10:30:42 --> Helper loaded: url_helper
INFO - 2020-09-22 10:30:42 --> Database Driver Class Initialized
INFO - 2020-09-22 10:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:30:42 --> Email Class Initialized
INFO - 2020-09-22 10:30:42 --> Controller Class Initialized
DEBUG - 2020-09-22 10:30:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:30:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:30:42 --> Model Class Initialized
INFO - 2020-09-22 10:30:42 --> Model Class Initialized
INFO - 2020-09-22 10:30:42 --> Final output sent to browser
DEBUG - 2020-09-22 10:30:42 --> Total execution time: 0.0236
ERROR - 2020-09-22 10:31:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:31:59 --> Config Class Initialized
INFO - 2020-09-22 10:31:59 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:31:59 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:31:59 --> Utf8 Class Initialized
INFO - 2020-09-22 10:31:59 --> URI Class Initialized
INFO - 2020-09-22 10:31:59 --> Router Class Initialized
INFO - 2020-09-22 10:31:59 --> Output Class Initialized
INFO - 2020-09-22 10:31:59 --> Security Class Initialized
DEBUG - 2020-09-22 10:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:31:59 --> Input Class Initialized
INFO - 2020-09-22 10:31:59 --> Language Class Initialized
INFO - 2020-09-22 10:31:59 --> Loader Class Initialized
INFO - 2020-09-22 10:31:59 --> Helper loaded: url_helper
INFO - 2020-09-22 10:31:59 --> Database Driver Class Initialized
INFO - 2020-09-22 10:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:31:59 --> Email Class Initialized
INFO - 2020-09-22 10:31:59 --> Controller Class Initialized
DEBUG - 2020-09-22 10:31:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:31:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:31:59 --> Model Class Initialized
INFO - 2020-09-22 10:31:59 --> Model Class Initialized
INFO - 2020-09-22 10:31:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 10:31:59 --> Final output sent to browser
DEBUG - 2020-09-22 10:31:59 --> Total execution time: 0.0321
ERROR - 2020-09-22 10:32:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:32:00 --> Config Class Initialized
INFO - 2020-09-22 10:32:00 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:32:00 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:32:00 --> Utf8 Class Initialized
INFO - 2020-09-22 10:32:00 --> URI Class Initialized
INFO - 2020-09-22 10:32:00 --> Router Class Initialized
INFO - 2020-09-22 10:32:00 --> Output Class Initialized
INFO - 2020-09-22 10:32:00 --> Security Class Initialized
DEBUG - 2020-09-22 10:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:32:00 --> Input Class Initialized
INFO - 2020-09-22 10:32:00 --> Language Class Initialized
INFO - 2020-09-22 10:32:00 --> Loader Class Initialized
INFO - 2020-09-22 10:32:00 --> Helper loaded: url_helper
INFO - 2020-09-22 10:32:00 --> Database Driver Class Initialized
INFO - 2020-09-22 10:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:32:00 --> Email Class Initialized
INFO - 2020-09-22 10:32:00 --> Controller Class Initialized
DEBUG - 2020-09-22 10:32:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:32:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:32:00 --> Model Class Initialized
INFO - 2020-09-22 10:32:00 --> Model Class Initialized
INFO - 2020-09-22 10:32:00 --> Final output sent to browser
DEBUG - 2020-09-22 10:32:00 --> Total execution time: 0.0230
ERROR - 2020-09-22 10:32:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:32:31 --> Config Class Initialized
INFO - 2020-09-22 10:32:31 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:32:31 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:32:31 --> Utf8 Class Initialized
INFO - 2020-09-22 10:32:31 --> URI Class Initialized
INFO - 2020-09-22 10:32:31 --> Router Class Initialized
INFO - 2020-09-22 10:32:31 --> Output Class Initialized
INFO - 2020-09-22 10:32:31 --> Security Class Initialized
DEBUG - 2020-09-22 10:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:32:31 --> Input Class Initialized
INFO - 2020-09-22 10:32:31 --> Language Class Initialized
INFO - 2020-09-22 10:32:31 --> Loader Class Initialized
INFO - 2020-09-22 10:32:31 --> Helper loaded: url_helper
INFO - 2020-09-22 10:32:31 --> Database Driver Class Initialized
INFO - 2020-09-22 10:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:32:31 --> Email Class Initialized
INFO - 2020-09-22 10:32:31 --> Controller Class Initialized
DEBUG - 2020-09-22 10:32:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:32:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:32:31 --> Model Class Initialized
INFO - 2020-09-22 10:32:31 --> Model Class Initialized
INFO - 2020-09-22 10:32:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 10:32:32 --> Final output sent to browser
DEBUG - 2020-09-22 10:32:32 --> Total execution time: 0.4832
ERROR - 2020-09-22 10:32:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:32:32 --> Config Class Initialized
INFO - 2020-09-22 10:32:32 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:32:32 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:32:32 --> Utf8 Class Initialized
INFO - 2020-09-22 10:32:32 --> URI Class Initialized
INFO - 2020-09-22 10:32:32 --> Router Class Initialized
INFO - 2020-09-22 10:32:32 --> Output Class Initialized
INFO - 2020-09-22 10:32:32 --> Security Class Initialized
DEBUG - 2020-09-22 10:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:32:32 --> Input Class Initialized
INFO - 2020-09-22 10:32:32 --> Language Class Initialized
INFO - 2020-09-22 10:32:32 --> Loader Class Initialized
INFO - 2020-09-22 10:32:32 --> Helper loaded: url_helper
INFO - 2020-09-22 10:32:32 --> Database Driver Class Initialized
INFO - 2020-09-22 10:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:32:32 --> Email Class Initialized
INFO - 2020-09-22 10:32:32 --> Controller Class Initialized
DEBUG - 2020-09-22 10:32:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:32:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:32:32 --> Model Class Initialized
INFO - 2020-09-22 10:32:32 --> Model Class Initialized
INFO - 2020-09-22 10:32:32 --> Final output sent to browser
DEBUG - 2020-09-22 10:32:32 --> Total execution time: 0.0252
ERROR - 2020-09-22 10:32:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:32:36 --> Config Class Initialized
INFO - 2020-09-22 10:32:36 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:32:36 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:32:36 --> Utf8 Class Initialized
INFO - 2020-09-22 10:32:36 --> URI Class Initialized
INFO - 2020-09-22 10:32:36 --> Router Class Initialized
INFO - 2020-09-22 10:32:36 --> Output Class Initialized
INFO - 2020-09-22 10:32:36 --> Security Class Initialized
DEBUG - 2020-09-22 10:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:32:36 --> Input Class Initialized
INFO - 2020-09-22 10:32:36 --> Language Class Initialized
INFO - 2020-09-22 10:32:36 --> Loader Class Initialized
INFO - 2020-09-22 10:32:36 --> Helper loaded: url_helper
INFO - 2020-09-22 10:32:36 --> Database Driver Class Initialized
INFO - 2020-09-22 10:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:32:36 --> Email Class Initialized
INFO - 2020-09-22 10:32:36 --> Controller Class Initialized
DEBUG - 2020-09-22 10:32:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:32:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:32:36 --> Model Class Initialized
INFO - 2020-09-22 10:32:36 --> Model Class Initialized
INFO - 2020-09-22 10:32:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 10:32:36 --> Final output sent to browser
DEBUG - 2020-09-22 10:32:36 --> Total execution time: 0.0326
ERROR - 2020-09-22 10:32:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:32:36 --> Config Class Initialized
INFO - 2020-09-22 10:32:36 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:32:36 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:32:36 --> Utf8 Class Initialized
INFO - 2020-09-22 10:32:36 --> URI Class Initialized
INFO - 2020-09-22 10:32:36 --> Router Class Initialized
INFO - 2020-09-22 10:32:36 --> Output Class Initialized
INFO - 2020-09-22 10:32:36 --> Security Class Initialized
DEBUG - 2020-09-22 10:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:32:36 --> Input Class Initialized
INFO - 2020-09-22 10:32:36 --> Language Class Initialized
INFO - 2020-09-22 10:32:36 --> Loader Class Initialized
INFO - 2020-09-22 10:32:36 --> Helper loaded: url_helper
INFO - 2020-09-22 10:32:36 --> Database Driver Class Initialized
INFO - 2020-09-22 10:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:32:36 --> Email Class Initialized
INFO - 2020-09-22 10:32:36 --> Controller Class Initialized
DEBUG - 2020-09-22 10:32:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:32:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:32:36 --> Model Class Initialized
INFO - 2020-09-22 10:32:36 --> Model Class Initialized
INFO - 2020-09-22 10:32:36 --> Final output sent to browser
DEBUG - 2020-09-22 10:32:36 --> Total execution time: 0.0245
ERROR - 2020-09-22 10:33:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:33:15 --> Config Class Initialized
INFO - 2020-09-22 10:33:15 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:33:15 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:33:15 --> Utf8 Class Initialized
INFO - 2020-09-22 10:33:15 --> URI Class Initialized
INFO - 2020-09-22 10:33:15 --> Router Class Initialized
INFO - 2020-09-22 10:33:15 --> Output Class Initialized
INFO - 2020-09-22 10:33:15 --> Security Class Initialized
DEBUG - 2020-09-22 10:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:33:15 --> Input Class Initialized
INFO - 2020-09-22 10:33:15 --> Language Class Initialized
INFO - 2020-09-22 10:33:15 --> Loader Class Initialized
INFO - 2020-09-22 10:33:15 --> Helper loaded: url_helper
INFO - 2020-09-22 10:33:15 --> Database Driver Class Initialized
INFO - 2020-09-22 10:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:33:15 --> Email Class Initialized
INFO - 2020-09-22 10:33:15 --> Controller Class Initialized
DEBUG - 2020-09-22 10:33:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:33:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:33:15 --> Model Class Initialized
INFO - 2020-09-22 10:33:15 --> Model Class Initialized
INFO - 2020-09-22 10:33:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 10:33:15 --> Final output sent to browser
DEBUG - 2020-09-22 10:33:15 --> Total execution time: 0.0219
ERROR - 2020-09-22 10:33:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:33:16 --> Config Class Initialized
INFO - 2020-09-22 10:33:16 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:33:16 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:33:16 --> Utf8 Class Initialized
INFO - 2020-09-22 10:33:16 --> URI Class Initialized
INFO - 2020-09-22 10:33:16 --> Router Class Initialized
INFO - 2020-09-22 10:33:16 --> Output Class Initialized
INFO - 2020-09-22 10:33:16 --> Security Class Initialized
DEBUG - 2020-09-22 10:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:33:16 --> Input Class Initialized
INFO - 2020-09-22 10:33:16 --> Language Class Initialized
INFO - 2020-09-22 10:33:16 --> Loader Class Initialized
INFO - 2020-09-22 10:33:16 --> Helper loaded: url_helper
INFO - 2020-09-22 10:33:16 --> Database Driver Class Initialized
INFO - 2020-09-22 10:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:33:16 --> Email Class Initialized
INFO - 2020-09-22 10:33:16 --> Controller Class Initialized
DEBUG - 2020-09-22 10:33:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:33:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:33:16 --> Model Class Initialized
INFO - 2020-09-22 10:33:16 --> Model Class Initialized
INFO - 2020-09-22 10:33:16 --> Final output sent to browser
DEBUG - 2020-09-22 10:33:16 --> Total execution time: 0.0200
ERROR - 2020-09-22 10:33:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:33:48 --> Config Class Initialized
INFO - 2020-09-22 10:33:48 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:33:48 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:33:48 --> Utf8 Class Initialized
INFO - 2020-09-22 10:33:48 --> URI Class Initialized
INFO - 2020-09-22 10:33:48 --> Router Class Initialized
INFO - 2020-09-22 10:33:48 --> Output Class Initialized
INFO - 2020-09-22 10:33:48 --> Security Class Initialized
DEBUG - 2020-09-22 10:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:33:48 --> Input Class Initialized
INFO - 2020-09-22 10:33:48 --> Language Class Initialized
INFO - 2020-09-22 10:33:48 --> Loader Class Initialized
INFO - 2020-09-22 10:33:48 --> Helper loaded: url_helper
INFO - 2020-09-22 10:33:48 --> Database Driver Class Initialized
INFO - 2020-09-22 10:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:33:48 --> Email Class Initialized
INFO - 2020-09-22 10:33:48 --> Controller Class Initialized
DEBUG - 2020-09-22 10:33:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:33:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:33:48 --> Model Class Initialized
INFO - 2020-09-22 10:33:48 --> Model Class Initialized
INFO - 2020-09-22 10:33:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 10:33:48 --> Final output sent to browser
DEBUG - 2020-09-22 10:33:48 --> Total execution time: 0.0278
ERROR - 2020-09-22 10:33:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:33:49 --> Config Class Initialized
INFO - 2020-09-22 10:33:49 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:33:49 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:33:49 --> Utf8 Class Initialized
INFO - 2020-09-22 10:33:49 --> URI Class Initialized
INFO - 2020-09-22 10:33:49 --> Router Class Initialized
INFO - 2020-09-22 10:33:49 --> Output Class Initialized
INFO - 2020-09-22 10:33:49 --> Security Class Initialized
DEBUG - 2020-09-22 10:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:33:49 --> Input Class Initialized
INFO - 2020-09-22 10:33:49 --> Language Class Initialized
INFO - 2020-09-22 10:33:49 --> Loader Class Initialized
INFO - 2020-09-22 10:33:49 --> Helper loaded: url_helper
INFO - 2020-09-22 10:33:49 --> Database Driver Class Initialized
INFO - 2020-09-22 10:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:33:49 --> Email Class Initialized
INFO - 2020-09-22 10:33:49 --> Controller Class Initialized
DEBUG - 2020-09-22 10:33:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:33:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:33:49 --> Model Class Initialized
INFO - 2020-09-22 10:33:49 --> Model Class Initialized
INFO - 2020-09-22 10:33:49 --> Final output sent to browser
DEBUG - 2020-09-22 10:33:49 --> Total execution time: 0.0270
ERROR - 2020-09-22 10:33:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:33:54 --> Config Class Initialized
INFO - 2020-09-22 10:33:54 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:33:54 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:33:54 --> Utf8 Class Initialized
INFO - 2020-09-22 10:33:54 --> URI Class Initialized
INFO - 2020-09-22 10:33:54 --> Router Class Initialized
INFO - 2020-09-22 10:33:54 --> Output Class Initialized
INFO - 2020-09-22 10:33:54 --> Security Class Initialized
DEBUG - 2020-09-22 10:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:33:54 --> Input Class Initialized
INFO - 2020-09-22 10:33:54 --> Language Class Initialized
INFO - 2020-09-22 10:33:54 --> Loader Class Initialized
INFO - 2020-09-22 10:33:54 --> Helper loaded: url_helper
INFO - 2020-09-22 10:33:54 --> Database Driver Class Initialized
INFO - 2020-09-22 10:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:33:54 --> Email Class Initialized
INFO - 2020-09-22 10:33:54 --> Controller Class Initialized
DEBUG - 2020-09-22 10:33:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:33:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:33:54 --> Model Class Initialized
INFO - 2020-09-22 10:33:54 --> Model Class Initialized
INFO - 2020-09-22 10:33:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 10:33:54 --> Final output sent to browser
DEBUG - 2020-09-22 10:33:54 --> Total execution time: 0.0252
ERROR - 2020-09-22 10:33:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:33:55 --> Config Class Initialized
INFO - 2020-09-22 10:33:55 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:33:55 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:33:55 --> Utf8 Class Initialized
INFO - 2020-09-22 10:33:55 --> URI Class Initialized
INFO - 2020-09-22 10:33:55 --> Router Class Initialized
INFO - 2020-09-22 10:33:55 --> Output Class Initialized
INFO - 2020-09-22 10:33:55 --> Security Class Initialized
DEBUG - 2020-09-22 10:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:33:55 --> Input Class Initialized
INFO - 2020-09-22 10:33:55 --> Language Class Initialized
INFO - 2020-09-22 10:33:55 --> Loader Class Initialized
INFO - 2020-09-22 10:33:55 --> Helper loaded: url_helper
INFO - 2020-09-22 10:33:55 --> Database Driver Class Initialized
INFO - 2020-09-22 10:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:33:55 --> Email Class Initialized
INFO - 2020-09-22 10:33:55 --> Controller Class Initialized
DEBUG - 2020-09-22 10:33:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:33:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:33:55 --> Model Class Initialized
INFO - 2020-09-22 10:33:55 --> Model Class Initialized
INFO - 2020-09-22 10:33:55 --> Final output sent to browser
DEBUG - 2020-09-22 10:33:55 --> Total execution time: 0.0210
ERROR - 2020-09-22 10:33:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:33:59 --> Config Class Initialized
INFO - 2020-09-22 10:33:59 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:33:59 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:33:59 --> Utf8 Class Initialized
INFO - 2020-09-22 10:33:59 --> URI Class Initialized
INFO - 2020-09-22 10:33:59 --> Router Class Initialized
INFO - 2020-09-22 10:33:59 --> Output Class Initialized
INFO - 2020-09-22 10:33:59 --> Security Class Initialized
DEBUG - 2020-09-22 10:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:33:59 --> Input Class Initialized
INFO - 2020-09-22 10:33:59 --> Language Class Initialized
INFO - 2020-09-22 10:33:59 --> Loader Class Initialized
INFO - 2020-09-22 10:33:59 --> Helper loaded: url_helper
INFO - 2020-09-22 10:33:59 --> Database Driver Class Initialized
INFO - 2020-09-22 10:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:33:59 --> Email Class Initialized
INFO - 2020-09-22 10:33:59 --> Controller Class Initialized
DEBUG - 2020-09-22 10:33:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:33:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:33:59 --> Model Class Initialized
INFO - 2020-09-22 10:33:59 --> Model Class Initialized
INFO - 2020-09-22 10:33:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 10:33:59 --> Final output sent to browser
DEBUG - 2020-09-22 10:33:59 --> Total execution time: 0.0232
ERROR - 2020-09-22 10:33:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:33:59 --> Config Class Initialized
INFO - 2020-09-22 10:33:59 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:33:59 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:33:59 --> Utf8 Class Initialized
INFO - 2020-09-22 10:33:59 --> URI Class Initialized
INFO - 2020-09-22 10:33:59 --> Router Class Initialized
INFO - 2020-09-22 10:33:59 --> Output Class Initialized
INFO - 2020-09-22 10:33:59 --> Security Class Initialized
DEBUG - 2020-09-22 10:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:33:59 --> Input Class Initialized
INFO - 2020-09-22 10:33:59 --> Language Class Initialized
INFO - 2020-09-22 10:33:59 --> Loader Class Initialized
INFO - 2020-09-22 10:33:59 --> Helper loaded: url_helper
INFO - 2020-09-22 10:33:59 --> Database Driver Class Initialized
INFO - 2020-09-22 10:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:33:59 --> Email Class Initialized
INFO - 2020-09-22 10:33:59 --> Controller Class Initialized
DEBUG - 2020-09-22 10:33:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:33:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:33:59 --> Model Class Initialized
INFO - 2020-09-22 10:33:59 --> Model Class Initialized
INFO - 2020-09-22 10:33:59 --> Final output sent to browser
DEBUG - 2020-09-22 10:33:59 --> Total execution time: 0.0211
ERROR - 2020-09-22 10:34:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:34:32 --> Config Class Initialized
INFO - 2020-09-22 10:34:32 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:34:32 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:34:32 --> Utf8 Class Initialized
INFO - 2020-09-22 10:34:32 --> URI Class Initialized
INFO - 2020-09-22 10:34:32 --> Router Class Initialized
INFO - 2020-09-22 10:34:32 --> Output Class Initialized
INFO - 2020-09-22 10:34:32 --> Security Class Initialized
DEBUG - 2020-09-22 10:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:34:32 --> Input Class Initialized
INFO - 2020-09-22 10:34:32 --> Language Class Initialized
INFO - 2020-09-22 10:34:32 --> Loader Class Initialized
INFO - 2020-09-22 10:34:32 --> Helper loaded: url_helper
INFO - 2020-09-22 10:34:32 --> Database Driver Class Initialized
INFO - 2020-09-22 10:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:34:32 --> Email Class Initialized
INFO - 2020-09-22 10:34:32 --> Controller Class Initialized
DEBUG - 2020-09-22 10:34:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:34:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:34:32 --> Model Class Initialized
INFO - 2020-09-22 10:34:32 --> Model Class Initialized
INFO - 2020-09-22 10:34:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 10:34:32 --> Final output sent to browser
DEBUG - 2020-09-22 10:34:32 --> Total execution time: 0.0285
ERROR - 2020-09-22 10:34:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:34:33 --> Config Class Initialized
INFO - 2020-09-22 10:34:33 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:34:33 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:34:33 --> Utf8 Class Initialized
INFO - 2020-09-22 10:34:33 --> URI Class Initialized
INFO - 2020-09-22 10:34:33 --> Router Class Initialized
INFO - 2020-09-22 10:34:33 --> Output Class Initialized
INFO - 2020-09-22 10:34:33 --> Security Class Initialized
DEBUG - 2020-09-22 10:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:34:33 --> Input Class Initialized
INFO - 2020-09-22 10:34:33 --> Language Class Initialized
INFO - 2020-09-22 10:34:33 --> Loader Class Initialized
INFO - 2020-09-22 10:34:33 --> Helper loaded: url_helper
INFO - 2020-09-22 10:34:33 --> Database Driver Class Initialized
INFO - 2020-09-22 10:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:34:33 --> Email Class Initialized
INFO - 2020-09-22 10:34:33 --> Controller Class Initialized
DEBUG - 2020-09-22 10:34:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:34:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:34:33 --> Model Class Initialized
INFO - 2020-09-22 10:34:33 --> Model Class Initialized
INFO - 2020-09-22 10:34:33 --> Final output sent to browser
DEBUG - 2020-09-22 10:34:33 --> Total execution time: 0.0254
ERROR - 2020-09-22 10:34:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:34:36 --> Config Class Initialized
INFO - 2020-09-22 10:34:36 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:34:36 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:34:36 --> Utf8 Class Initialized
INFO - 2020-09-22 10:34:36 --> URI Class Initialized
INFO - 2020-09-22 10:34:36 --> Router Class Initialized
INFO - 2020-09-22 10:34:36 --> Output Class Initialized
INFO - 2020-09-22 10:34:36 --> Security Class Initialized
DEBUG - 2020-09-22 10:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:34:36 --> Input Class Initialized
INFO - 2020-09-22 10:34:36 --> Language Class Initialized
INFO - 2020-09-22 10:34:36 --> Loader Class Initialized
INFO - 2020-09-22 10:34:36 --> Helper loaded: url_helper
INFO - 2020-09-22 10:34:36 --> Database Driver Class Initialized
INFO - 2020-09-22 10:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:34:36 --> Email Class Initialized
INFO - 2020-09-22 10:34:36 --> Controller Class Initialized
DEBUG - 2020-09-22 10:34:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:34:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:34:36 --> Model Class Initialized
INFO - 2020-09-22 10:34:36 --> Model Class Initialized
INFO - 2020-09-22 10:34:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 10:34:36 --> Final output sent to browser
DEBUG - 2020-09-22 10:34:36 --> Total execution time: 0.0255
ERROR - 2020-09-22 10:34:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:34:37 --> Config Class Initialized
INFO - 2020-09-22 10:34:37 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:34:37 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:34:37 --> Utf8 Class Initialized
INFO - 2020-09-22 10:34:37 --> URI Class Initialized
INFO - 2020-09-22 10:34:37 --> Router Class Initialized
INFO - 2020-09-22 10:34:37 --> Output Class Initialized
INFO - 2020-09-22 10:34:37 --> Security Class Initialized
DEBUG - 2020-09-22 10:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:34:37 --> Input Class Initialized
INFO - 2020-09-22 10:34:37 --> Language Class Initialized
INFO - 2020-09-22 10:34:37 --> Loader Class Initialized
INFO - 2020-09-22 10:34:37 --> Helper loaded: url_helper
INFO - 2020-09-22 10:34:37 --> Database Driver Class Initialized
INFO - 2020-09-22 10:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:34:37 --> Email Class Initialized
INFO - 2020-09-22 10:34:37 --> Controller Class Initialized
DEBUG - 2020-09-22 10:34:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:34:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:34:37 --> Model Class Initialized
INFO - 2020-09-22 10:34:37 --> Model Class Initialized
INFO - 2020-09-22 10:34:37 --> Final output sent to browser
DEBUG - 2020-09-22 10:34:37 --> Total execution time: 0.0243
ERROR - 2020-09-22 10:34:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:34:38 --> Config Class Initialized
INFO - 2020-09-22 10:34:38 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:34:38 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:34:38 --> Utf8 Class Initialized
INFO - 2020-09-22 10:34:38 --> URI Class Initialized
INFO - 2020-09-22 10:34:38 --> Router Class Initialized
INFO - 2020-09-22 10:34:38 --> Output Class Initialized
INFO - 2020-09-22 10:34:38 --> Security Class Initialized
DEBUG - 2020-09-22 10:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:34:38 --> Input Class Initialized
INFO - 2020-09-22 10:34:38 --> Language Class Initialized
INFO - 2020-09-22 10:34:38 --> Loader Class Initialized
INFO - 2020-09-22 10:34:38 --> Helper loaded: url_helper
INFO - 2020-09-22 10:34:38 --> Database Driver Class Initialized
INFO - 2020-09-22 10:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:34:38 --> Email Class Initialized
INFO - 2020-09-22 10:34:38 --> Controller Class Initialized
DEBUG - 2020-09-22 10:34:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:34:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:34:38 --> Model Class Initialized
INFO - 2020-09-22 10:34:38 --> Model Class Initialized
INFO - 2020-09-22 10:34:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 10:34:38 --> Final output sent to browser
DEBUG - 2020-09-22 10:34:38 --> Total execution time: 0.0266
ERROR - 2020-09-22 10:34:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:34:39 --> Config Class Initialized
INFO - 2020-09-22 10:34:39 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:34:39 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:34:39 --> Utf8 Class Initialized
INFO - 2020-09-22 10:34:39 --> URI Class Initialized
INFO - 2020-09-22 10:34:39 --> Router Class Initialized
INFO - 2020-09-22 10:34:39 --> Output Class Initialized
INFO - 2020-09-22 10:34:39 --> Security Class Initialized
DEBUG - 2020-09-22 10:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:34:39 --> Input Class Initialized
INFO - 2020-09-22 10:34:39 --> Language Class Initialized
INFO - 2020-09-22 10:34:39 --> Loader Class Initialized
INFO - 2020-09-22 10:34:39 --> Helper loaded: url_helper
INFO - 2020-09-22 10:34:39 --> Database Driver Class Initialized
INFO - 2020-09-22 10:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:34:39 --> Email Class Initialized
INFO - 2020-09-22 10:34:39 --> Controller Class Initialized
DEBUG - 2020-09-22 10:34:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:34:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:34:39 --> Model Class Initialized
INFO - 2020-09-22 10:34:39 --> Model Class Initialized
INFO - 2020-09-22 10:34:39 --> Final output sent to browser
DEBUG - 2020-09-22 10:34:39 --> Total execution time: 0.0225
ERROR - 2020-09-22 10:34:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:34:40 --> Config Class Initialized
INFO - 2020-09-22 10:34:40 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:34:40 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:34:40 --> Utf8 Class Initialized
INFO - 2020-09-22 10:34:40 --> URI Class Initialized
INFO - 2020-09-22 10:34:40 --> Router Class Initialized
INFO - 2020-09-22 10:34:40 --> Output Class Initialized
INFO - 2020-09-22 10:34:40 --> Security Class Initialized
DEBUG - 2020-09-22 10:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:34:40 --> Input Class Initialized
INFO - 2020-09-22 10:34:40 --> Language Class Initialized
INFO - 2020-09-22 10:34:40 --> Loader Class Initialized
INFO - 2020-09-22 10:34:40 --> Helper loaded: url_helper
INFO - 2020-09-22 10:34:40 --> Database Driver Class Initialized
INFO - 2020-09-22 10:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:34:40 --> Email Class Initialized
INFO - 2020-09-22 10:34:40 --> Controller Class Initialized
DEBUG - 2020-09-22 10:34:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:34:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:34:40 --> Model Class Initialized
INFO - 2020-09-22 10:34:40 --> Model Class Initialized
INFO - 2020-09-22 10:34:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-22 10:34:40 --> Final output sent to browser
DEBUG - 2020-09-22 10:34:40 --> Total execution time: 0.0226
ERROR - 2020-09-22 10:34:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:34:45 --> Config Class Initialized
INFO - 2020-09-22 10:34:45 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:34:45 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:34:45 --> Utf8 Class Initialized
INFO - 2020-09-22 10:34:45 --> URI Class Initialized
INFO - 2020-09-22 10:34:45 --> Router Class Initialized
INFO - 2020-09-22 10:34:45 --> Output Class Initialized
INFO - 2020-09-22 10:34:45 --> Security Class Initialized
DEBUG - 2020-09-22 10:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:34:45 --> Input Class Initialized
INFO - 2020-09-22 10:34:45 --> Language Class Initialized
INFO - 2020-09-22 10:34:45 --> Loader Class Initialized
INFO - 2020-09-22 10:34:45 --> Helper loaded: url_helper
INFO - 2020-09-22 10:34:45 --> Database Driver Class Initialized
INFO - 2020-09-22 10:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:34:45 --> Email Class Initialized
INFO - 2020-09-22 10:34:45 --> Controller Class Initialized
DEBUG - 2020-09-22 10:34:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:34:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:34:45 --> Model Class Initialized
INFO - 2020-09-22 10:34:45 --> Model Class Initialized
INFO - 2020-09-22 10:34:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-22 10:34:45 --> Final output sent to browser
DEBUG - 2020-09-22 10:34:45 --> Total execution time: 0.0258
ERROR - 2020-09-22 10:34:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:34:48 --> Config Class Initialized
INFO - 2020-09-22 10:34:48 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:34:48 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:34:48 --> Utf8 Class Initialized
INFO - 2020-09-22 10:34:48 --> URI Class Initialized
INFO - 2020-09-22 10:34:48 --> Router Class Initialized
INFO - 2020-09-22 10:34:48 --> Output Class Initialized
INFO - 2020-09-22 10:34:48 --> Security Class Initialized
DEBUG - 2020-09-22 10:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:34:49 --> Input Class Initialized
INFO - 2020-09-22 10:34:49 --> Language Class Initialized
INFO - 2020-09-22 10:34:49 --> Loader Class Initialized
INFO - 2020-09-22 10:34:49 --> Helper loaded: url_helper
INFO - 2020-09-22 10:34:49 --> Database Driver Class Initialized
INFO - 2020-09-22 10:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:34:49 --> Email Class Initialized
INFO - 2020-09-22 10:34:49 --> Controller Class Initialized
DEBUG - 2020-09-22 10:34:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:34:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:34:49 --> Model Class Initialized
INFO - 2020-09-22 10:34:49 --> Model Class Initialized
INFO - 2020-09-22 10:34:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-22 10:34:49 --> Final output sent to browser
DEBUG - 2020-09-22 10:34:49 --> Total execution time: 0.0235
ERROR - 2020-09-22 10:36:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:36:49 --> Config Class Initialized
INFO - 2020-09-22 10:36:49 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:36:49 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:36:49 --> Utf8 Class Initialized
INFO - 2020-09-22 10:36:49 --> URI Class Initialized
INFO - 2020-09-22 10:36:49 --> Router Class Initialized
INFO - 2020-09-22 10:36:49 --> Output Class Initialized
INFO - 2020-09-22 10:36:49 --> Security Class Initialized
DEBUG - 2020-09-22 10:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:36:49 --> Input Class Initialized
INFO - 2020-09-22 10:36:49 --> Language Class Initialized
INFO - 2020-09-22 10:36:49 --> Loader Class Initialized
INFO - 2020-09-22 10:36:49 --> Helper loaded: url_helper
INFO - 2020-09-22 10:36:49 --> Database Driver Class Initialized
INFO - 2020-09-22 10:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:36:49 --> Email Class Initialized
INFO - 2020-09-22 10:36:49 --> Controller Class Initialized
DEBUG - 2020-09-22 10:36:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:36:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:36:49 --> Model Class Initialized
INFO - 2020-09-22 10:36:49 --> Model Class Initialized
INFO - 2020-09-22 10:36:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-22 10:36:49 --> Final output sent to browser
DEBUG - 2020-09-22 10:36:49 --> Total execution time: 0.0254
ERROR - 2020-09-22 10:36:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:36:54 --> Config Class Initialized
INFO - 2020-09-22 10:36:54 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:36:54 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:36:54 --> Utf8 Class Initialized
INFO - 2020-09-22 10:36:54 --> URI Class Initialized
INFO - 2020-09-22 10:36:54 --> Router Class Initialized
INFO - 2020-09-22 10:36:54 --> Output Class Initialized
INFO - 2020-09-22 10:36:54 --> Security Class Initialized
DEBUG - 2020-09-22 10:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:36:54 --> Input Class Initialized
INFO - 2020-09-22 10:36:54 --> Language Class Initialized
INFO - 2020-09-22 10:36:54 --> Loader Class Initialized
INFO - 2020-09-22 10:36:54 --> Helper loaded: url_helper
INFO - 2020-09-22 10:36:54 --> Database Driver Class Initialized
INFO - 2020-09-22 10:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:36:54 --> Email Class Initialized
INFO - 2020-09-22 10:36:54 --> Controller Class Initialized
DEBUG - 2020-09-22 10:36:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:36:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:36:54 --> Model Class Initialized
INFO - 2020-09-22 10:36:54 --> Model Class Initialized
INFO - 2020-09-22 10:36:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 10:36:54 --> Final output sent to browser
DEBUG - 2020-09-22 10:36:54 --> Total execution time: 0.0272
ERROR - 2020-09-22 10:36:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:36:55 --> Config Class Initialized
INFO - 2020-09-22 10:36:55 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:36:55 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:36:55 --> Utf8 Class Initialized
INFO - 2020-09-22 10:36:55 --> URI Class Initialized
INFO - 2020-09-22 10:36:55 --> Router Class Initialized
INFO - 2020-09-22 10:36:55 --> Output Class Initialized
INFO - 2020-09-22 10:36:55 --> Security Class Initialized
DEBUG - 2020-09-22 10:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:36:55 --> Input Class Initialized
INFO - 2020-09-22 10:36:55 --> Language Class Initialized
INFO - 2020-09-22 10:36:55 --> Loader Class Initialized
INFO - 2020-09-22 10:36:55 --> Helper loaded: url_helper
INFO - 2020-09-22 10:36:55 --> Database Driver Class Initialized
INFO - 2020-09-22 10:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:36:55 --> Email Class Initialized
INFO - 2020-09-22 10:36:55 --> Controller Class Initialized
DEBUG - 2020-09-22 10:36:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:36:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:36:55 --> Model Class Initialized
INFO - 2020-09-22 10:36:55 --> Model Class Initialized
INFO - 2020-09-22 10:36:55 --> Final output sent to browser
DEBUG - 2020-09-22 10:36:55 --> Total execution time: 0.0244
ERROR - 2020-09-22 10:37:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:37:03 --> Config Class Initialized
INFO - 2020-09-22 10:37:03 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:37:03 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:37:03 --> Utf8 Class Initialized
INFO - 2020-09-22 10:37:03 --> URI Class Initialized
INFO - 2020-09-22 10:37:03 --> Router Class Initialized
INFO - 2020-09-22 10:37:03 --> Output Class Initialized
INFO - 2020-09-22 10:37:03 --> Security Class Initialized
DEBUG - 2020-09-22 10:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:37:03 --> Input Class Initialized
INFO - 2020-09-22 10:37:03 --> Language Class Initialized
INFO - 2020-09-22 10:37:03 --> Loader Class Initialized
INFO - 2020-09-22 10:37:03 --> Helper loaded: url_helper
INFO - 2020-09-22 10:37:03 --> Database Driver Class Initialized
INFO - 2020-09-22 10:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:37:03 --> Email Class Initialized
INFO - 2020-09-22 10:37:03 --> Controller Class Initialized
DEBUG - 2020-09-22 10:37:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:37:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:37:03 --> Model Class Initialized
INFO - 2020-09-22 10:37:03 --> Model Class Initialized
INFO - 2020-09-22 10:37:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 10:37:03 --> Final output sent to browser
DEBUG - 2020-09-22 10:37:03 --> Total execution time: 0.0233
ERROR - 2020-09-22 10:37:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 10:37:03 --> Config Class Initialized
INFO - 2020-09-22 10:37:03 --> Hooks Class Initialized
DEBUG - 2020-09-22 10:37:03 --> UTF-8 Support Enabled
INFO - 2020-09-22 10:37:03 --> Utf8 Class Initialized
INFO - 2020-09-22 10:37:03 --> URI Class Initialized
INFO - 2020-09-22 10:37:03 --> Router Class Initialized
INFO - 2020-09-22 10:37:03 --> Output Class Initialized
INFO - 2020-09-22 10:37:03 --> Security Class Initialized
DEBUG - 2020-09-22 10:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 10:37:03 --> Input Class Initialized
INFO - 2020-09-22 10:37:03 --> Language Class Initialized
INFO - 2020-09-22 10:37:03 --> Loader Class Initialized
INFO - 2020-09-22 10:37:03 --> Helper loaded: url_helper
INFO - 2020-09-22 10:37:03 --> Database Driver Class Initialized
INFO - 2020-09-22 10:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 10:37:03 --> Email Class Initialized
INFO - 2020-09-22 10:37:03 --> Controller Class Initialized
DEBUG - 2020-09-22 10:37:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 10:37:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 10:37:03 --> Model Class Initialized
INFO - 2020-09-22 10:37:03 --> Model Class Initialized
INFO - 2020-09-22 10:37:03 --> Final output sent to browser
DEBUG - 2020-09-22 10:37:03 --> Total execution time: 0.0232
ERROR - 2020-09-22 11:03:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:03:20 --> Config Class Initialized
INFO - 2020-09-22 11:03:20 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:03:20 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:03:20 --> Utf8 Class Initialized
INFO - 2020-09-22 11:03:20 --> URI Class Initialized
DEBUG - 2020-09-22 11:03:20 --> No URI present. Default controller set.
INFO - 2020-09-22 11:03:20 --> Router Class Initialized
INFO - 2020-09-22 11:03:20 --> Output Class Initialized
INFO - 2020-09-22 11:03:20 --> Security Class Initialized
DEBUG - 2020-09-22 11:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:03:20 --> Input Class Initialized
INFO - 2020-09-22 11:03:20 --> Language Class Initialized
INFO - 2020-09-22 11:03:20 --> Loader Class Initialized
INFO - 2020-09-22 11:03:20 --> Helper loaded: url_helper
INFO - 2020-09-22 11:03:20 --> Database Driver Class Initialized
INFO - 2020-09-22 11:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:03:20 --> Email Class Initialized
INFO - 2020-09-22 11:03:20 --> Controller Class Initialized
INFO - 2020-09-22 11:03:20 --> Model Class Initialized
INFO - 2020-09-22 11:03:20 --> Model Class Initialized
DEBUG - 2020-09-22 11:03:20 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:03:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 11:03:20 --> Final output sent to browser
DEBUG - 2020-09-22 11:03:20 --> Total execution time: 0.0177
ERROR - 2020-09-22 11:04:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:04:56 --> Config Class Initialized
INFO - 2020-09-22 11:04:56 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:04:56 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:04:56 --> Utf8 Class Initialized
INFO - 2020-09-22 11:04:56 --> URI Class Initialized
INFO - 2020-09-22 11:04:56 --> Router Class Initialized
INFO - 2020-09-22 11:04:56 --> Output Class Initialized
INFO - 2020-09-22 11:04:56 --> Security Class Initialized
DEBUG - 2020-09-22 11:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:04:56 --> Input Class Initialized
INFO - 2020-09-22 11:04:56 --> Language Class Initialized
INFO - 2020-09-22 11:04:56 --> Loader Class Initialized
INFO - 2020-09-22 11:04:56 --> Helper loaded: url_helper
INFO - 2020-09-22 11:04:56 --> Database Driver Class Initialized
INFO - 2020-09-22 11:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:04:56 --> Email Class Initialized
INFO - 2020-09-22 11:04:56 --> Controller Class Initialized
INFO - 2020-09-22 11:04:56 --> Model Class Initialized
INFO - 2020-09-22 11:04:56 --> Model Class Initialized
DEBUG - 2020-09-22 11:04:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-22 11:04:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:04:56 --> Config Class Initialized
INFO - 2020-09-22 11:04:56 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:04:56 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:04:56 --> Utf8 Class Initialized
INFO - 2020-09-22 11:04:56 --> URI Class Initialized
INFO - 2020-09-22 11:04:56 --> Router Class Initialized
INFO - 2020-09-22 11:04:56 --> Output Class Initialized
INFO - 2020-09-22 11:04:56 --> Security Class Initialized
DEBUG - 2020-09-22 11:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:04:56 --> Input Class Initialized
INFO - 2020-09-22 11:04:56 --> Language Class Initialized
INFO - 2020-09-22 11:04:56 --> Loader Class Initialized
INFO - 2020-09-22 11:04:56 --> Helper loaded: url_helper
INFO - 2020-09-22 11:04:56 --> Database Driver Class Initialized
INFO - 2020-09-22 11:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:04:56 --> Email Class Initialized
INFO - 2020-09-22 11:04:56 --> Controller Class Initialized
INFO - 2020-09-22 11:04:56 --> Model Class Initialized
INFO - 2020-09-22 11:04:56 --> Model Class Initialized
DEBUG - 2020-09-22 11:04:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:04:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:04:56 --> Model Class Initialized
INFO - 2020-09-22 11:04:56 --> Final output sent to browser
DEBUG - 2020-09-22 11:04:56 --> Total execution time: 0.0245
ERROR - 2020-09-22 11:04:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:04:57 --> Config Class Initialized
INFO - 2020-09-22 11:04:57 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:04:57 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:04:57 --> Utf8 Class Initialized
INFO - 2020-09-22 11:04:57 --> URI Class Initialized
INFO - 2020-09-22 11:04:57 --> Router Class Initialized
INFO - 2020-09-22 11:04:57 --> Output Class Initialized
INFO - 2020-09-22 11:04:57 --> Security Class Initialized
DEBUG - 2020-09-22 11:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:04:57 --> Input Class Initialized
INFO - 2020-09-22 11:04:57 --> Language Class Initialized
INFO - 2020-09-22 11:04:57 --> Loader Class Initialized
INFO - 2020-09-22 11:04:57 --> Helper loaded: url_helper
INFO - 2020-09-22 11:04:57 --> Database Driver Class Initialized
INFO - 2020-09-22 11:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:04:57 --> Email Class Initialized
INFO - 2020-09-22 11:04:57 --> Controller Class Initialized
DEBUG - 2020-09-22 11:04:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:04:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:04:57 --> Model Class Initialized
INFO - 2020-09-22 11:04:57 --> Model Class Initialized
INFO - 2020-09-22 11:04:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-22 11:04:57 --> Final output sent to browser
DEBUG - 2020-09-22 11:04:57 --> Total execution time: 0.0209
ERROR - 2020-09-22 11:05:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:05:30 --> Config Class Initialized
INFO - 2020-09-22 11:05:30 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:05:30 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:05:30 --> Utf8 Class Initialized
INFO - 2020-09-22 11:05:30 --> URI Class Initialized
INFO - 2020-09-22 11:05:30 --> Router Class Initialized
INFO - 2020-09-22 11:05:30 --> Output Class Initialized
INFO - 2020-09-22 11:05:30 --> Security Class Initialized
DEBUG - 2020-09-22 11:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:05:30 --> Input Class Initialized
INFO - 2020-09-22 11:05:30 --> Language Class Initialized
INFO - 2020-09-22 11:05:30 --> Loader Class Initialized
INFO - 2020-09-22 11:05:30 --> Helper loaded: url_helper
INFO - 2020-09-22 11:05:30 --> Database Driver Class Initialized
INFO - 2020-09-22 11:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:05:30 --> Email Class Initialized
INFO - 2020-09-22 11:05:30 --> Controller Class Initialized
DEBUG - 2020-09-22 11:05:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:05:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:05:30 --> Model Class Initialized
INFO - 2020-09-22 11:05:30 --> Model Class Initialized
INFO - 2020-09-22 11:05:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 11:05:30 --> Final output sent to browser
DEBUG - 2020-09-22 11:05:30 --> Total execution time: 0.0311
ERROR - 2020-09-22 11:05:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:05:31 --> Config Class Initialized
INFO - 2020-09-22 11:05:31 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:05:31 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:05:31 --> Utf8 Class Initialized
INFO - 2020-09-22 11:05:31 --> URI Class Initialized
INFO - 2020-09-22 11:05:31 --> Router Class Initialized
INFO - 2020-09-22 11:05:31 --> Output Class Initialized
INFO - 2020-09-22 11:05:31 --> Security Class Initialized
DEBUG - 2020-09-22 11:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:05:31 --> Input Class Initialized
INFO - 2020-09-22 11:05:31 --> Language Class Initialized
INFO - 2020-09-22 11:05:31 --> Loader Class Initialized
INFO - 2020-09-22 11:05:31 --> Helper loaded: url_helper
INFO - 2020-09-22 11:05:31 --> Database Driver Class Initialized
INFO - 2020-09-22 11:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:05:31 --> Email Class Initialized
INFO - 2020-09-22 11:05:31 --> Controller Class Initialized
DEBUG - 2020-09-22 11:05:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:05:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:05:31 --> Model Class Initialized
INFO - 2020-09-22 11:05:31 --> Model Class Initialized
INFO - 2020-09-22 11:05:31 --> Final output sent to browser
DEBUG - 2020-09-22 11:05:31 --> Total execution time: 0.0261
ERROR - 2020-09-22 11:05:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:05:59 --> Config Class Initialized
INFO - 2020-09-22 11:05:59 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:05:59 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:05:59 --> Utf8 Class Initialized
INFO - 2020-09-22 11:05:59 --> URI Class Initialized
INFO - 2020-09-22 11:05:59 --> Router Class Initialized
INFO - 2020-09-22 11:05:59 --> Output Class Initialized
INFO - 2020-09-22 11:05:59 --> Security Class Initialized
DEBUG - 2020-09-22 11:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:05:59 --> Input Class Initialized
INFO - 2020-09-22 11:05:59 --> Language Class Initialized
INFO - 2020-09-22 11:05:59 --> Loader Class Initialized
INFO - 2020-09-22 11:05:59 --> Helper loaded: url_helper
INFO - 2020-09-22 11:05:59 --> Database Driver Class Initialized
INFO - 2020-09-22 11:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:05:59 --> Email Class Initialized
INFO - 2020-09-22 11:05:59 --> Controller Class Initialized
DEBUG - 2020-09-22 11:05:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:05:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:05:59 --> Model Class Initialized
INFO - 2020-09-22 11:05:59 --> Model Class Initialized
INFO - 2020-09-22 11:05:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 11:05:59 --> Final output sent to browser
DEBUG - 2020-09-22 11:05:59 --> Total execution time: 0.0337
ERROR - 2020-09-22 11:06:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:06:00 --> Config Class Initialized
INFO - 2020-09-22 11:06:00 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:06:00 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:06:00 --> Utf8 Class Initialized
INFO - 2020-09-22 11:06:00 --> URI Class Initialized
INFO - 2020-09-22 11:06:00 --> Router Class Initialized
INFO - 2020-09-22 11:06:00 --> Output Class Initialized
INFO - 2020-09-22 11:06:00 --> Security Class Initialized
DEBUG - 2020-09-22 11:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:06:00 --> Input Class Initialized
INFO - 2020-09-22 11:06:00 --> Language Class Initialized
INFO - 2020-09-22 11:06:00 --> Loader Class Initialized
INFO - 2020-09-22 11:06:00 --> Helper loaded: url_helper
INFO - 2020-09-22 11:06:00 --> Database Driver Class Initialized
INFO - 2020-09-22 11:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:06:00 --> Email Class Initialized
INFO - 2020-09-22 11:06:00 --> Controller Class Initialized
DEBUG - 2020-09-22 11:06:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:06:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:06:00 --> Model Class Initialized
INFO - 2020-09-22 11:06:00 --> Model Class Initialized
INFO - 2020-09-22 11:06:00 --> Final output sent to browser
DEBUG - 2020-09-22 11:06:00 --> Total execution time: 0.0284
ERROR - 2020-09-22 11:09:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:09:21 --> Config Class Initialized
INFO - 2020-09-22 11:09:21 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:09:21 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:09:21 --> Utf8 Class Initialized
INFO - 2020-09-22 11:09:21 --> URI Class Initialized
INFO - 2020-09-22 11:09:21 --> Router Class Initialized
INFO - 2020-09-22 11:09:21 --> Output Class Initialized
INFO - 2020-09-22 11:09:21 --> Security Class Initialized
DEBUG - 2020-09-22 11:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:09:21 --> Input Class Initialized
INFO - 2020-09-22 11:09:21 --> Language Class Initialized
INFO - 2020-09-22 11:09:21 --> Loader Class Initialized
INFO - 2020-09-22 11:09:21 --> Helper loaded: url_helper
INFO - 2020-09-22 11:09:21 --> Database Driver Class Initialized
ERROR - 2020-09-22 11:09:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:09:21 --> Config Class Initialized
INFO - 2020-09-22 11:09:21 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:09:21 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:09:21 --> Utf8 Class Initialized
INFO - 2020-09-22 11:09:21 --> URI Class Initialized
INFO - 2020-09-22 11:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:09:21 --> Router Class Initialized
INFO - 2020-09-22 11:09:21 --> Output Class Initialized
INFO - 2020-09-22 11:09:21 --> Email Class Initialized
INFO - 2020-09-22 11:09:21 --> Controller Class Initialized
DEBUG - 2020-09-22 11:09:21 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:09:21 --> Security Class Initialized
DEBUG - 2020-09-22 11:09:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:09:21 --> Model Class Initialized
INFO - 2020-09-22 11:09:21 --> Model Class Initialized
DEBUG - 2020-09-22 11:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:09:21 --> Input Class Initialized
INFO - 2020-09-22 11:09:21 --> Language Class Initialized
INFO - 2020-09-22 11:09:21 --> Loader Class Initialized
INFO - 2020-09-22 11:09:21 --> Helper loaded: url_helper
INFO - 2020-09-22 11:09:21 --> Database Driver Class Initialized
INFO - 2020-09-22 11:09:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 11:09:21 --> Final output sent to browser
DEBUG - 2020-09-22 11:09:21 --> Total execution time: 0.0493
INFO - 2020-09-22 11:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:09:21 --> Email Class Initialized
INFO - 2020-09-22 11:09:21 --> Controller Class Initialized
DEBUG - 2020-09-22 11:09:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:09:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:09:21 --> Model Class Initialized
INFO - 2020-09-22 11:09:21 --> Model Class Initialized
INFO - 2020-09-22 11:09:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 11:09:21 --> Final output sent to browser
DEBUG - 2020-09-22 11:09:21 --> Total execution time: 0.0435
ERROR - 2020-09-22 11:09:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:09:23 --> Config Class Initialized
INFO - 2020-09-22 11:09:23 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:09:23 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:09:23 --> Utf8 Class Initialized
INFO - 2020-09-22 11:09:23 --> URI Class Initialized
INFO - 2020-09-22 11:09:23 --> Router Class Initialized
INFO - 2020-09-22 11:09:23 --> Output Class Initialized
INFO - 2020-09-22 11:09:23 --> Security Class Initialized
DEBUG - 2020-09-22 11:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:09:23 --> Input Class Initialized
INFO - 2020-09-22 11:09:23 --> Language Class Initialized
INFO - 2020-09-22 11:09:23 --> Loader Class Initialized
INFO - 2020-09-22 11:09:23 --> Helper loaded: url_helper
INFO - 2020-09-22 11:09:23 --> Database Driver Class Initialized
INFO - 2020-09-22 11:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:09:23 --> Email Class Initialized
INFO - 2020-09-22 11:09:23 --> Controller Class Initialized
DEBUG - 2020-09-22 11:09:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:09:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:09:23 --> Model Class Initialized
INFO - 2020-09-22 11:09:23 --> Model Class Initialized
INFO - 2020-09-22 11:09:23 --> Final output sent to browser
DEBUG - 2020-09-22 11:09:23 --> Total execution time: 0.0409
ERROR - 2020-09-22 11:09:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:09:36 --> Config Class Initialized
INFO - 2020-09-22 11:09:36 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:09:36 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:09:36 --> Utf8 Class Initialized
INFO - 2020-09-22 11:09:36 --> URI Class Initialized
INFO - 2020-09-22 11:09:36 --> Router Class Initialized
INFO - 2020-09-22 11:09:36 --> Output Class Initialized
INFO - 2020-09-22 11:09:36 --> Security Class Initialized
DEBUG - 2020-09-22 11:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:09:36 --> Input Class Initialized
INFO - 2020-09-22 11:09:36 --> Language Class Initialized
INFO - 2020-09-22 11:09:36 --> Loader Class Initialized
INFO - 2020-09-22 11:09:36 --> Helper loaded: url_helper
INFO - 2020-09-22 11:09:36 --> Database Driver Class Initialized
INFO - 2020-09-22 11:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:09:36 --> Email Class Initialized
INFO - 2020-09-22 11:09:36 --> Controller Class Initialized
DEBUG - 2020-09-22 11:09:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:09:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:09:36 --> Model Class Initialized
INFO - 2020-09-22 11:09:36 --> Model Class Initialized
INFO - 2020-09-22 11:09:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 11:09:36 --> Final output sent to browser
DEBUG - 2020-09-22 11:09:36 --> Total execution time: 0.0302
ERROR - 2020-09-22 11:09:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:09:37 --> Config Class Initialized
INFO - 2020-09-22 11:09:37 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:09:37 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:09:37 --> Utf8 Class Initialized
INFO - 2020-09-22 11:09:37 --> URI Class Initialized
INFO - 2020-09-22 11:09:37 --> Router Class Initialized
INFO - 2020-09-22 11:09:37 --> Output Class Initialized
INFO - 2020-09-22 11:09:37 --> Security Class Initialized
DEBUG - 2020-09-22 11:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:09:37 --> Input Class Initialized
INFO - 2020-09-22 11:09:37 --> Language Class Initialized
INFO - 2020-09-22 11:09:37 --> Loader Class Initialized
INFO - 2020-09-22 11:09:37 --> Helper loaded: url_helper
INFO - 2020-09-22 11:09:37 --> Database Driver Class Initialized
INFO - 2020-09-22 11:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:09:37 --> Email Class Initialized
INFO - 2020-09-22 11:09:37 --> Controller Class Initialized
DEBUG - 2020-09-22 11:09:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:09:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:09:37 --> Model Class Initialized
INFO - 2020-09-22 11:09:37 --> Model Class Initialized
INFO - 2020-09-22 11:09:37 --> Final output sent to browser
DEBUG - 2020-09-22 11:09:37 --> Total execution time: 0.0318
ERROR - 2020-09-22 11:09:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:09:53 --> Config Class Initialized
INFO - 2020-09-22 11:09:53 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:09:53 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:09:53 --> Utf8 Class Initialized
INFO - 2020-09-22 11:09:53 --> URI Class Initialized
DEBUG - 2020-09-22 11:09:53 --> No URI present. Default controller set.
INFO - 2020-09-22 11:09:53 --> Router Class Initialized
INFO - 2020-09-22 11:09:53 --> Output Class Initialized
INFO - 2020-09-22 11:09:53 --> Security Class Initialized
DEBUG - 2020-09-22 11:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:09:53 --> Input Class Initialized
INFO - 2020-09-22 11:09:53 --> Language Class Initialized
INFO - 2020-09-22 11:09:53 --> Loader Class Initialized
INFO - 2020-09-22 11:09:53 --> Helper loaded: url_helper
INFO - 2020-09-22 11:09:53 --> Database Driver Class Initialized
INFO - 2020-09-22 11:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:09:53 --> Email Class Initialized
INFO - 2020-09-22 11:09:53 --> Controller Class Initialized
INFO - 2020-09-22 11:09:53 --> Model Class Initialized
INFO - 2020-09-22 11:09:53 --> Model Class Initialized
DEBUG - 2020-09-22 11:09:53 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:09:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 11:09:53 --> Final output sent to browser
DEBUG - 2020-09-22 11:09:53 --> Total execution time: 0.0186
ERROR - 2020-09-22 11:10:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:10:03 --> Config Class Initialized
INFO - 2020-09-22 11:10:03 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:10:03 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:10:03 --> Utf8 Class Initialized
INFO - 2020-09-22 11:10:03 --> URI Class Initialized
INFO - 2020-09-22 11:10:03 --> Router Class Initialized
INFO - 2020-09-22 11:10:03 --> Output Class Initialized
INFO - 2020-09-22 11:10:03 --> Security Class Initialized
DEBUG - 2020-09-22 11:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:10:03 --> Input Class Initialized
INFO - 2020-09-22 11:10:03 --> Language Class Initialized
INFO - 2020-09-22 11:10:03 --> Loader Class Initialized
INFO - 2020-09-22 11:10:03 --> Helper loaded: url_helper
INFO - 2020-09-22 11:10:03 --> Database Driver Class Initialized
INFO - 2020-09-22 11:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:10:03 --> Email Class Initialized
INFO - 2020-09-22 11:10:03 --> Controller Class Initialized
INFO - 2020-09-22 11:10:03 --> Model Class Initialized
INFO - 2020-09-22 11:10:03 --> Model Class Initialized
DEBUG - 2020-09-22 11:10:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:10:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:10:03 --> Model Class Initialized
INFO - 2020-09-22 11:10:03 --> Final output sent to browser
DEBUG - 2020-09-22 11:10:03 --> Total execution time: 0.0243
ERROR - 2020-09-22 11:10:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:10:04 --> Config Class Initialized
INFO - 2020-09-22 11:10:04 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:10:04 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:10:04 --> Utf8 Class Initialized
INFO - 2020-09-22 11:10:04 --> URI Class Initialized
INFO - 2020-09-22 11:10:04 --> Router Class Initialized
INFO - 2020-09-22 11:10:04 --> Output Class Initialized
INFO - 2020-09-22 11:10:04 --> Security Class Initialized
DEBUG - 2020-09-22 11:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:10:04 --> Input Class Initialized
INFO - 2020-09-22 11:10:04 --> Language Class Initialized
INFO - 2020-09-22 11:10:04 --> Loader Class Initialized
INFO - 2020-09-22 11:10:04 --> Helper loaded: url_helper
INFO - 2020-09-22 11:10:04 --> Database Driver Class Initialized
INFO - 2020-09-22 11:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:10:04 --> Email Class Initialized
INFO - 2020-09-22 11:10:04 --> Controller Class Initialized
INFO - 2020-09-22 11:10:04 --> Model Class Initialized
INFO - 2020-09-22 11:10:04 --> Model Class Initialized
DEBUG - 2020-09-22 11:10:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-22 11:10:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:10:04 --> Config Class Initialized
INFO - 2020-09-22 11:10:04 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:10:04 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:10:04 --> Utf8 Class Initialized
INFO - 2020-09-22 11:10:04 --> URI Class Initialized
INFO - 2020-09-22 11:10:04 --> Router Class Initialized
INFO - 2020-09-22 11:10:04 --> Output Class Initialized
INFO - 2020-09-22 11:10:04 --> Security Class Initialized
DEBUG - 2020-09-22 11:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:10:04 --> Input Class Initialized
INFO - 2020-09-22 11:10:04 --> Language Class Initialized
INFO - 2020-09-22 11:10:04 --> Loader Class Initialized
INFO - 2020-09-22 11:10:04 --> Helper loaded: url_helper
INFO - 2020-09-22 11:10:04 --> Database Driver Class Initialized
INFO - 2020-09-22 11:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:10:04 --> Email Class Initialized
INFO - 2020-09-22 11:10:04 --> Controller Class Initialized
DEBUG - 2020-09-22 11:10:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:10:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:10:04 --> Model Class Initialized
INFO - 2020-09-22 11:10:04 --> Model Class Initialized
INFO - 2020-09-22 11:10:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-22 11:10:04 --> Final output sent to browser
DEBUG - 2020-09-22 11:10:04 --> Total execution time: 0.0271
ERROR - 2020-09-22 11:10:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:10:26 --> Config Class Initialized
INFO - 2020-09-22 11:10:26 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:10:26 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:10:26 --> Utf8 Class Initialized
INFO - 2020-09-22 11:10:26 --> URI Class Initialized
INFO - 2020-09-22 11:10:26 --> Router Class Initialized
INFO - 2020-09-22 11:10:26 --> Output Class Initialized
INFO - 2020-09-22 11:10:26 --> Security Class Initialized
DEBUG - 2020-09-22 11:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:10:26 --> Input Class Initialized
INFO - 2020-09-22 11:10:26 --> Language Class Initialized
INFO - 2020-09-22 11:10:26 --> Loader Class Initialized
INFO - 2020-09-22 11:10:26 --> Helper loaded: url_helper
INFO - 2020-09-22 11:10:26 --> Database Driver Class Initialized
INFO - 2020-09-22 11:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:10:26 --> Email Class Initialized
INFO - 2020-09-22 11:10:26 --> Controller Class Initialized
DEBUG - 2020-09-22 11:10:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:10:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:10:26 --> Model Class Initialized
INFO - 2020-09-22 11:10:26 --> Model Class Initialized
INFO - 2020-09-22 11:10:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-22 11:10:26 --> Final output sent to browser
DEBUG - 2020-09-22 11:10:26 --> Total execution time: 0.0246
ERROR - 2020-09-22 11:10:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:10:32 --> Config Class Initialized
INFO - 2020-09-22 11:10:32 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:10:32 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:10:32 --> Utf8 Class Initialized
INFO - 2020-09-22 11:10:32 --> URI Class Initialized
INFO - 2020-09-22 11:10:32 --> Router Class Initialized
INFO - 2020-09-22 11:10:32 --> Output Class Initialized
INFO - 2020-09-22 11:10:32 --> Security Class Initialized
DEBUG - 2020-09-22 11:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:10:32 --> Input Class Initialized
INFO - 2020-09-22 11:10:32 --> Language Class Initialized
INFO - 2020-09-22 11:10:32 --> Loader Class Initialized
INFO - 2020-09-22 11:10:32 --> Helper loaded: url_helper
INFO - 2020-09-22 11:10:32 --> Database Driver Class Initialized
INFO - 2020-09-22 11:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:10:32 --> Email Class Initialized
INFO - 2020-09-22 11:10:32 --> Controller Class Initialized
DEBUG - 2020-09-22 11:10:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:10:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:10:32 --> Model Class Initialized
INFO - 2020-09-22 11:10:32 --> Model Class Initialized
INFO - 2020-09-22 11:10:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-22 11:10:32 --> Final output sent to browser
DEBUG - 2020-09-22 11:10:32 --> Total execution time: 0.0255
ERROR - 2020-09-22 11:10:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:10:37 --> Config Class Initialized
INFO - 2020-09-22 11:10:37 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:10:37 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:10:37 --> Utf8 Class Initialized
INFO - 2020-09-22 11:10:37 --> URI Class Initialized
INFO - 2020-09-22 11:10:37 --> Router Class Initialized
INFO - 2020-09-22 11:10:37 --> Output Class Initialized
INFO - 2020-09-22 11:10:37 --> Security Class Initialized
DEBUG - 2020-09-22 11:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:10:37 --> Input Class Initialized
INFO - 2020-09-22 11:10:37 --> Language Class Initialized
INFO - 2020-09-22 11:10:37 --> Loader Class Initialized
INFO - 2020-09-22 11:10:37 --> Helper loaded: url_helper
INFO - 2020-09-22 11:10:37 --> Database Driver Class Initialized
INFO - 2020-09-22 11:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:10:37 --> Email Class Initialized
INFO - 2020-09-22 11:10:37 --> Controller Class Initialized
DEBUG - 2020-09-22 11:10:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:10:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:10:37 --> Model Class Initialized
INFO - 2020-09-22 11:10:37 --> Model Class Initialized
INFO - 2020-09-22 11:10:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-22 11:10:37 --> Final output sent to browser
DEBUG - 2020-09-22 11:10:37 --> Total execution time: 0.0250
ERROR - 2020-09-22 11:10:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:10:47 --> Config Class Initialized
INFO - 2020-09-22 11:10:47 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:10:47 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:10:47 --> Utf8 Class Initialized
INFO - 2020-09-22 11:10:47 --> URI Class Initialized
INFO - 2020-09-22 11:10:47 --> Router Class Initialized
INFO - 2020-09-22 11:10:47 --> Output Class Initialized
INFO - 2020-09-22 11:10:47 --> Security Class Initialized
DEBUG - 2020-09-22 11:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:10:47 --> Input Class Initialized
INFO - 2020-09-22 11:10:47 --> Language Class Initialized
INFO - 2020-09-22 11:10:47 --> Loader Class Initialized
INFO - 2020-09-22 11:10:47 --> Helper loaded: url_helper
INFO - 2020-09-22 11:10:47 --> Database Driver Class Initialized
INFO - 2020-09-22 11:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:10:47 --> Email Class Initialized
INFO - 2020-09-22 11:10:47 --> Controller Class Initialized
DEBUG - 2020-09-22 11:10:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:10:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:10:47 --> Model Class Initialized
INFO - 2020-09-22 11:10:47 --> Model Class Initialized
INFO - 2020-09-22 11:10:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-22 11:10:47 --> Final output sent to browser
DEBUG - 2020-09-22 11:10:47 --> Total execution time: 0.0229
ERROR - 2020-09-22 11:11:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:11:10 --> Config Class Initialized
INFO - 2020-09-22 11:11:10 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:11:10 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:11:10 --> Utf8 Class Initialized
INFO - 2020-09-22 11:11:10 --> URI Class Initialized
INFO - 2020-09-22 11:11:10 --> Router Class Initialized
INFO - 2020-09-22 11:11:10 --> Output Class Initialized
INFO - 2020-09-22 11:11:10 --> Security Class Initialized
DEBUG - 2020-09-22 11:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:11:10 --> Input Class Initialized
INFO - 2020-09-22 11:11:10 --> Language Class Initialized
INFO - 2020-09-22 11:11:10 --> Loader Class Initialized
INFO - 2020-09-22 11:11:10 --> Helper loaded: url_helper
INFO - 2020-09-22 11:11:10 --> Database Driver Class Initialized
INFO - 2020-09-22 11:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:11:10 --> Email Class Initialized
INFO - 2020-09-22 11:11:10 --> Controller Class Initialized
DEBUG - 2020-09-22 11:11:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:11:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:11:10 --> Model Class Initialized
INFO - 2020-09-22 11:11:10 --> Model Class Initialized
INFO - 2020-09-22 11:11:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-22 11:11:10 --> Final output sent to browser
DEBUG - 2020-09-22 11:11:10 --> Total execution time: 0.0271
ERROR - 2020-09-22 11:11:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:11:16 --> Config Class Initialized
INFO - 2020-09-22 11:11:16 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:11:16 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:11:16 --> Utf8 Class Initialized
INFO - 2020-09-22 11:11:16 --> URI Class Initialized
INFO - 2020-09-22 11:11:16 --> Router Class Initialized
INFO - 2020-09-22 11:11:16 --> Output Class Initialized
INFO - 2020-09-22 11:11:16 --> Security Class Initialized
DEBUG - 2020-09-22 11:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:11:16 --> Input Class Initialized
INFO - 2020-09-22 11:11:16 --> Language Class Initialized
INFO - 2020-09-22 11:11:16 --> Loader Class Initialized
INFO - 2020-09-22 11:11:16 --> Helper loaded: url_helper
INFO - 2020-09-22 11:11:16 --> Database Driver Class Initialized
INFO - 2020-09-22 11:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:11:16 --> Email Class Initialized
INFO - 2020-09-22 11:11:16 --> Controller Class Initialized
DEBUG - 2020-09-22 11:11:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:11:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:11:16 --> Model Class Initialized
INFO - 2020-09-22 11:11:16 --> Model Class Initialized
INFO - 2020-09-22 11:11:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-22 11:11:16 --> Final output sent to browser
DEBUG - 2020-09-22 11:11:16 --> Total execution time: 0.0310
ERROR - 2020-09-22 11:11:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:11:28 --> Config Class Initialized
INFO - 2020-09-22 11:11:28 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:11:28 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:11:28 --> Utf8 Class Initialized
INFO - 2020-09-22 11:11:28 --> URI Class Initialized
INFO - 2020-09-22 11:11:28 --> Router Class Initialized
INFO - 2020-09-22 11:11:28 --> Output Class Initialized
INFO - 2020-09-22 11:11:28 --> Security Class Initialized
DEBUG - 2020-09-22 11:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:11:28 --> Input Class Initialized
INFO - 2020-09-22 11:11:28 --> Language Class Initialized
INFO - 2020-09-22 11:11:28 --> Loader Class Initialized
INFO - 2020-09-22 11:11:28 --> Helper loaded: url_helper
INFO - 2020-09-22 11:11:28 --> Database Driver Class Initialized
INFO - 2020-09-22 11:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:11:28 --> Email Class Initialized
INFO - 2020-09-22 11:11:28 --> Controller Class Initialized
DEBUG - 2020-09-22 11:11:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:11:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:11:28 --> Model Class Initialized
INFO - 2020-09-22 11:11:28 --> Model Class Initialized
INFO - 2020-09-22 11:11:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-22 11:11:28 --> Final output sent to browser
DEBUG - 2020-09-22 11:11:28 --> Total execution time: 0.0266
ERROR - 2020-09-22 11:11:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:11:34 --> Config Class Initialized
INFO - 2020-09-22 11:11:34 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:11:34 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:11:34 --> Utf8 Class Initialized
INFO - 2020-09-22 11:11:34 --> URI Class Initialized
INFO - 2020-09-22 11:11:34 --> Router Class Initialized
INFO - 2020-09-22 11:11:34 --> Output Class Initialized
INFO - 2020-09-22 11:11:34 --> Security Class Initialized
DEBUG - 2020-09-22 11:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:11:34 --> Input Class Initialized
INFO - 2020-09-22 11:11:34 --> Language Class Initialized
INFO - 2020-09-22 11:11:34 --> Loader Class Initialized
INFO - 2020-09-22 11:11:34 --> Helper loaded: url_helper
INFO - 2020-09-22 11:11:34 --> Database Driver Class Initialized
INFO - 2020-09-22 11:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:11:34 --> Email Class Initialized
INFO - 2020-09-22 11:11:34 --> Controller Class Initialized
DEBUG - 2020-09-22 11:11:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:11:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:11:34 --> Model Class Initialized
INFO - 2020-09-22 11:11:34 --> Model Class Initialized
INFO - 2020-09-22 11:11:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-22 11:11:34 --> Final output sent to browser
DEBUG - 2020-09-22 11:11:34 --> Total execution time: 0.0296
ERROR - 2020-09-22 11:11:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:11:52 --> Config Class Initialized
INFO - 2020-09-22 11:11:52 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:11:52 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:11:52 --> Utf8 Class Initialized
INFO - 2020-09-22 11:11:52 --> URI Class Initialized
INFO - 2020-09-22 11:11:52 --> Router Class Initialized
INFO - 2020-09-22 11:11:52 --> Output Class Initialized
INFO - 2020-09-22 11:11:52 --> Security Class Initialized
DEBUG - 2020-09-22 11:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:11:52 --> Input Class Initialized
INFO - 2020-09-22 11:11:52 --> Language Class Initialized
INFO - 2020-09-22 11:11:52 --> Loader Class Initialized
INFO - 2020-09-22 11:11:52 --> Helper loaded: url_helper
INFO - 2020-09-22 11:11:52 --> Database Driver Class Initialized
INFO - 2020-09-22 11:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:11:52 --> Email Class Initialized
INFO - 2020-09-22 11:11:52 --> Controller Class Initialized
DEBUG - 2020-09-22 11:11:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:11:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:11:52 --> Model Class Initialized
INFO - 2020-09-22 11:11:52 --> Model Class Initialized
INFO - 2020-09-22 11:11:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-22 11:11:52 --> Final output sent to browser
DEBUG - 2020-09-22 11:11:52 --> Total execution time: 0.0235
ERROR - 2020-09-22 11:11:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:11:57 --> Config Class Initialized
INFO - 2020-09-22 11:11:57 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:11:57 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:11:57 --> Utf8 Class Initialized
INFO - 2020-09-22 11:11:57 --> URI Class Initialized
INFO - 2020-09-22 11:11:57 --> Router Class Initialized
INFO - 2020-09-22 11:11:57 --> Output Class Initialized
INFO - 2020-09-22 11:11:57 --> Security Class Initialized
DEBUG - 2020-09-22 11:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:11:57 --> Input Class Initialized
INFO - 2020-09-22 11:11:57 --> Language Class Initialized
INFO - 2020-09-22 11:11:57 --> Loader Class Initialized
INFO - 2020-09-22 11:11:57 --> Helper loaded: url_helper
INFO - 2020-09-22 11:11:57 --> Database Driver Class Initialized
INFO - 2020-09-22 11:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:11:57 --> Email Class Initialized
INFO - 2020-09-22 11:11:57 --> Controller Class Initialized
DEBUG - 2020-09-22 11:11:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:11:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:11:57 --> Model Class Initialized
INFO - 2020-09-22 11:11:57 --> Model Class Initialized
INFO - 2020-09-22 11:11:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-22 11:11:57 --> Final output sent to browser
DEBUG - 2020-09-22 11:11:57 --> Total execution time: 0.0262
ERROR - 2020-09-22 11:12:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:12:40 --> Config Class Initialized
INFO - 2020-09-22 11:12:40 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:12:40 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:12:40 --> Utf8 Class Initialized
INFO - 2020-09-22 11:12:40 --> URI Class Initialized
DEBUG - 2020-09-22 11:12:40 --> No URI present. Default controller set.
INFO - 2020-09-22 11:12:40 --> Router Class Initialized
INFO - 2020-09-22 11:12:40 --> Output Class Initialized
INFO - 2020-09-22 11:12:40 --> Security Class Initialized
DEBUG - 2020-09-22 11:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:12:40 --> Input Class Initialized
INFO - 2020-09-22 11:12:40 --> Language Class Initialized
INFO - 2020-09-22 11:12:40 --> Loader Class Initialized
INFO - 2020-09-22 11:12:40 --> Helper loaded: url_helper
INFO - 2020-09-22 11:12:40 --> Database Driver Class Initialized
INFO - 2020-09-22 11:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:12:41 --> Email Class Initialized
INFO - 2020-09-22 11:12:41 --> Controller Class Initialized
INFO - 2020-09-22 11:12:41 --> Model Class Initialized
INFO - 2020-09-22 11:12:41 --> Model Class Initialized
DEBUG - 2020-09-22 11:12:41 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:12:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 11:12:41 --> Final output sent to browser
DEBUG - 2020-09-22 11:12:41 --> Total execution time: 0.0237
ERROR - 2020-09-22 11:12:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:12:43 --> Config Class Initialized
INFO - 2020-09-22 11:12:43 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:12:43 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:12:43 --> Utf8 Class Initialized
INFO - 2020-09-22 11:12:43 --> URI Class Initialized
INFO - 2020-09-22 11:12:43 --> Router Class Initialized
INFO - 2020-09-22 11:12:43 --> Output Class Initialized
INFO - 2020-09-22 11:12:43 --> Security Class Initialized
DEBUG - 2020-09-22 11:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:12:43 --> Input Class Initialized
INFO - 2020-09-22 11:12:43 --> Language Class Initialized
INFO - 2020-09-22 11:12:43 --> Loader Class Initialized
INFO - 2020-09-22 11:12:43 --> Helper loaded: url_helper
INFO - 2020-09-22 11:12:43 --> Database Driver Class Initialized
INFO - 2020-09-22 11:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:12:44 --> Email Class Initialized
INFO - 2020-09-22 11:12:44 --> Controller Class Initialized
INFO - 2020-09-22 11:12:44 --> Model Class Initialized
INFO - 2020-09-22 11:12:44 --> Model Class Initialized
DEBUG - 2020-09-22 11:12:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:12:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:12:44 --> Model Class Initialized
INFO - 2020-09-22 11:12:44 --> Final output sent to browser
DEBUG - 2020-09-22 11:12:44 --> Total execution time: 0.0245
ERROR - 2020-09-22 11:12:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:12:44 --> Config Class Initialized
INFO - 2020-09-22 11:12:44 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:12:44 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:12:44 --> Utf8 Class Initialized
INFO - 2020-09-22 11:12:44 --> URI Class Initialized
INFO - 2020-09-22 11:12:44 --> Router Class Initialized
INFO - 2020-09-22 11:12:44 --> Output Class Initialized
INFO - 2020-09-22 11:12:44 --> Security Class Initialized
DEBUG - 2020-09-22 11:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:12:44 --> Input Class Initialized
INFO - 2020-09-22 11:12:44 --> Language Class Initialized
INFO - 2020-09-22 11:12:44 --> Loader Class Initialized
INFO - 2020-09-22 11:12:44 --> Helper loaded: url_helper
INFO - 2020-09-22 11:12:44 --> Database Driver Class Initialized
INFO - 2020-09-22 11:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:12:44 --> Email Class Initialized
INFO - 2020-09-22 11:12:44 --> Controller Class Initialized
INFO - 2020-09-22 11:12:44 --> Model Class Initialized
INFO - 2020-09-22 11:12:44 --> Model Class Initialized
DEBUG - 2020-09-22 11:12:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-22 11:12:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:12:44 --> Config Class Initialized
INFO - 2020-09-22 11:12:44 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:12:44 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:12:44 --> Utf8 Class Initialized
INFO - 2020-09-22 11:12:44 --> URI Class Initialized
INFO - 2020-09-22 11:12:44 --> Router Class Initialized
INFO - 2020-09-22 11:12:44 --> Output Class Initialized
INFO - 2020-09-22 11:12:44 --> Security Class Initialized
DEBUG - 2020-09-22 11:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:12:44 --> Input Class Initialized
INFO - 2020-09-22 11:12:44 --> Language Class Initialized
INFO - 2020-09-22 11:12:44 --> Loader Class Initialized
INFO - 2020-09-22 11:12:44 --> Helper loaded: url_helper
INFO - 2020-09-22 11:12:44 --> Database Driver Class Initialized
INFO - 2020-09-22 11:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:12:44 --> Email Class Initialized
INFO - 2020-09-22 11:12:44 --> Controller Class Initialized
DEBUG - 2020-09-22 11:12:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:12:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:12:44 --> Model Class Initialized
INFO - 2020-09-22 11:12:44 --> Model Class Initialized
INFO - 2020-09-22 11:12:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-22 11:12:44 --> Final output sent to browser
DEBUG - 2020-09-22 11:12:44 --> Total execution time: 0.0269
ERROR - 2020-09-22 11:13:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:13:28 --> Config Class Initialized
INFO - 2020-09-22 11:13:28 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:13:28 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:13:28 --> Utf8 Class Initialized
INFO - 2020-09-22 11:13:28 --> URI Class Initialized
INFO - 2020-09-22 11:13:28 --> Router Class Initialized
INFO - 2020-09-22 11:13:28 --> Output Class Initialized
INFO - 2020-09-22 11:13:28 --> Security Class Initialized
DEBUG - 2020-09-22 11:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:13:28 --> Input Class Initialized
INFO - 2020-09-22 11:13:28 --> Language Class Initialized
INFO - 2020-09-22 11:13:28 --> Loader Class Initialized
INFO - 2020-09-22 11:13:28 --> Helper loaded: url_helper
INFO - 2020-09-22 11:13:28 --> Database Driver Class Initialized
INFO - 2020-09-22 11:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:13:28 --> Email Class Initialized
INFO - 2020-09-22 11:13:28 --> Controller Class Initialized
DEBUG - 2020-09-22 11:13:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:13:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:13:28 --> Model Class Initialized
INFO - 2020-09-22 11:13:28 --> Model Class Initialized
INFO - 2020-09-22 11:13:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 11:13:28 --> Final output sent to browser
DEBUG - 2020-09-22 11:13:28 --> Total execution time: 0.0324
ERROR - 2020-09-22 11:13:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:13:29 --> Config Class Initialized
INFO - 2020-09-22 11:13:29 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:13:29 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:13:29 --> Utf8 Class Initialized
INFO - 2020-09-22 11:13:29 --> URI Class Initialized
INFO - 2020-09-22 11:13:29 --> Router Class Initialized
INFO - 2020-09-22 11:13:29 --> Output Class Initialized
INFO - 2020-09-22 11:13:29 --> Security Class Initialized
DEBUG - 2020-09-22 11:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:13:29 --> Input Class Initialized
INFO - 2020-09-22 11:13:29 --> Language Class Initialized
INFO - 2020-09-22 11:13:29 --> Loader Class Initialized
INFO - 2020-09-22 11:13:29 --> Helper loaded: url_helper
INFO - 2020-09-22 11:13:29 --> Database Driver Class Initialized
INFO - 2020-09-22 11:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:13:29 --> Email Class Initialized
INFO - 2020-09-22 11:13:29 --> Controller Class Initialized
DEBUG - 2020-09-22 11:13:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:13:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:13:29 --> Model Class Initialized
INFO - 2020-09-22 11:13:29 --> Model Class Initialized
INFO - 2020-09-22 11:13:29 --> Final output sent to browser
DEBUG - 2020-09-22 11:13:29 --> Total execution time: 0.0285
ERROR - 2020-09-22 11:16:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:16:27 --> Config Class Initialized
INFO - 2020-09-22 11:16:27 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:16:27 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:16:27 --> Utf8 Class Initialized
INFO - 2020-09-22 11:16:27 --> URI Class Initialized
INFO - 2020-09-22 11:16:27 --> Router Class Initialized
INFO - 2020-09-22 11:16:27 --> Output Class Initialized
INFO - 2020-09-22 11:16:27 --> Security Class Initialized
DEBUG - 2020-09-22 11:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:16:27 --> Input Class Initialized
INFO - 2020-09-22 11:16:27 --> Language Class Initialized
INFO - 2020-09-22 11:16:27 --> Loader Class Initialized
INFO - 2020-09-22 11:16:27 --> Helper loaded: url_helper
INFO - 2020-09-22 11:16:27 --> Database Driver Class Initialized
INFO - 2020-09-22 11:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:16:27 --> Email Class Initialized
INFO - 2020-09-22 11:16:27 --> Controller Class Initialized
DEBUG - 2020-09-22 11:16:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:16:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:16:27 --> Model Class Initialized
INFO - 2020-09-22 11:16:27 --> Model Class Initialized
INFO - 2020-09-22 11:16:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 11:16:27 --> Final output sent to browser
DEBUG - 2020-09-22 11:16:27 --> Total execution time: 0.0292
ERROR - 2020-09-22 11:16:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:16:27 --> Config Class Initialized
INFO - 2020-09-22 11:16:27 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:16:27 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:16:27 --> Utf8 Class Initialized
INFO - 2020-09-22 11:16:27 --> URI Class Initialized
INFO - 2020-09-22 11:16:27 --> Router Class Initialized
INFO - 2020-09-22 11:16:27 --> Output Class Initialized
INFO - 2020-09-22 11:16:27 --> Security Class Initialized
DEBUG - 2020-09-22 11:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:16:27 --> Input Class Initialized
INFO - 2020-09-22 11:16:27 --> Language Class Initialized
INFO - 2020-09-22 11:16:27 --> Loader Class Initialized
INFO - 2020-09-22 11:16:27 --> Helper loaded: url_helper
INFO - 2020-09-22 11:16:27 --> Database Driver Class Initialized
INFO - 2020-09-22 11:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:16:27 --> Email Class Initialized
INFO - 2020-09-22 11:16:27 --> Controller Class Initialized
DEBUG - 2020-09-22 11:16:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:16:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:16:27 --> Model Class Initialized
INFO - 2020-09-22 11:16:27 --> Model Class Initialized
INFO - 2020-09-22 11:16:27 --> Final output sent to browser
DEBUG - 2020-09-22 11:16:27 --> Total execution time: 0.0256
ERROR - 2020-09-22 11:17:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:17:31 --> Config Class Initialized
INFO - 2020-09-22 11:17:31 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:17:31 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:17:31 --> Utf8 Class Initialized
INFO - 2020-09-22 11:17:31 --> URI Class Initialized
INFO - 2020-09-22 11:17:31 --> Router Class Initialized
INFO - 2020-09-22 11:17:31 --> Output Class Initialized
INFO - 2020-09-22 11:17:31 --> Security Class Initialized
DEBUG - 2020-09-22 11:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:17:31 --> Input Class Initialized
INFO - 2020-09-22 11:17:31 --> Language Class Initialized
INFO - 2020-09-22 11:17:31 --> Loader Class Initialized
INFO - 2020-09-22 11:17:31 --> Helper loaded: url_helper
INFO - 2020-09-22 11:17:31 --> Database Driver Class Initialized
INFO - 2020-09-22 11:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:17:31 --> Email Class Initialized
INFO - 2020-09-22 11:17:31 --> Controller Class Initialized
DEBUG - 2020-09-22 11:17:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:17:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:17:31 --> Model Class Initialized
INFO - 2020-09-22 11:17:31 --> Model Class Initialized
INFO - 2020-09-22 11:17:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 11:17:31 --> Final output sent to browser
DEBUG - 2020-09-22 11:17:31 --> Total execution time: 0.0227
ERROR - 2020-09-22 11:17:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:17:31 --> Config Class Initialized
INFO - 2020-09-22 11:17:31 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:17:31 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:17:31 --> Utf8 Class Initialized
INFO - 2020-09-22 11:17:31 --> URI Class Initialized
INFO - 2020-09-22 11:17:31 --> Router Class Initialized
INFO - 2020-09-22 11:17:31 --> Output Class Initialized
INFO - 2020-09-22 11:17:31 --> Security Class Initialized
DEBUG - 2020-09-22 11:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:17:31 --> Input Class Initialized
INFO - 2020-09-22 11:17:31 --> Language Class Initialized
INFO - 2020-09-22 11:17:31 --> Loader Class Initialized
INFO - 2020-09-22 11:17:31 --> Helper loaded: url_helper
INFO - 2020-09-22 11:17:31 --> Database Driver Class Initialized
INFO - 2020-09-22 11:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:17:31 --> Email Class Initialized
INFO - 2020-09-22 11:17:31 --> Controller Class Initialized
DEBUG - 2020-09-22 11:17:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:17:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:17:31 --> Model Class Initialized
INFO - 2020-09-22 11:17:31 --> Model Class Initialized
INFO - 2020-09-22 11:17:31 --> Final output sent to browser
DEBUG - 2020-09-22 11:17:31 --> Total execution time: 0.0254
ERROR - 2020-09-22 11:18:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:18:00 --> Config Class Initialized
INFO - 2020-09-22 11:18:00 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:18:00 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:18:00 --> Utf8 Class Initialized
INFO - 2020-09-22 11:18:00 --> URI Class Initialized
INFO - 2020-09-22 11:18:00 --> Router Class Initialized
INFO - 2020-09-22 11:18:00 --> Output Class Initialized
INFO - 2020-09-22 11:18:00 --> Security Class Initialized
DEBUG - 2020-09-22 11:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:18:00 --> Input Class Initialized
INFO - 2020-09-22 11:18:00 --> Language Class Initialized
INFO - 2020-09-22 11:18:00 --> Loader Class Initialized
INFO - 2020-09-22 11:18:00 --> Helper loaded: url_helper
INFO - 2020-09-22 11:18:00 --> Database Driver Class Initialized
INFO - 2020-09-22 11:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:18:00 --> Email Class Initialized
INFO - 2020-09-22 11:18:00 --> Controller Class Initialized
DEBUG - 2020-09-22 11:18:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:18:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:18:00 --> Model Class Initialized
INFO - 2020-09-22 11:18:00 --> Model Class Initialized
INFO - 2020-09-22 11:18:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 11:18:00 --> Final output sent to browser
DEBUG - 2020-09-22 11:18:00 --> Total execution time: 0.0386
ERROR - 2020-09-22 11:18:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:18:01 --> Config Class Initialized
INFO - 2020-09-22 11:18:01 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:18:01 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:18:01 --> Utf8 Class Initialized
INFO - 2020-09-22 11:18:01 --> URI Class Initialized
INFO - 2020-09-22 11:18:01 --> Router Class Initialized
INFO - 2020-09-22 11:18:01 --> Output Class Initialized
INFO - 2020-09-22 11:18:01 --> Security Class Initialized
DEBUG - 2020-09-22 11:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:18:01 --> Input Class Initialized
INFO - 2020-09-22 11:18:01 --> Language Class Initialized
INFO - 2020-09-22 11:18:01 --> Loader Class Initialized
INFO - 2020-09-22 11:18:01 --> Helper loaded: url_helper
INFO - 2020-09-22 11:18:01 --> Database Driver Class Initialized
INFO - 2020-09-22 11:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:18:01 --> Email Class Initialized
INFO - 2020-09-22 11:18:01 --> Controller Class Initialized
DEBUG - 2020-09-22 11:18:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:18:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:18:01 --> Model Class Initialized
INFO - 2020-09-22 11:18:01 --> Model Class Initialized
INFO - 2020-09-22 11:18:01 --> Final output sent to browser
DEBUG - 2020-09-22 11:18:01 --> Total execution time: 0.0259
ERROR - 2020-09-22 11:20:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:20:37 --> Config Class Initialized
INFO - 2020-09-22 11:20:37 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:20:37 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:20:37 --> Utf8 Class Initialized
INFO - 2020-09-22 11:20:37 --> URI Class Initialized
INFO - 2020-09-22 11:20:37 --> Router Class Initialized
INFO - 2020-09-22 11:20:37 --> Output Class Initialized
INFO - 2020-09-22 11:20:37 --> Security Class Initialized
DEBUG - 2020-09-22 11:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:20:37 --> Input Class Initialized
INFO - 2020-09-22 11:20:37 --> Language Class Initialized
INFO - 2020-09-22 11:20:37 --> Loader Class Initialized
INFO - 2020-09-22 11:20:37 --> Helper loaded: url_helper
INFO - 2020-09-22 11:20:37 --> Database Driver Class Initialized
INFO - 2020-09-22 11:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:20:37 --> Email Class Initialized
INFO - 2020-09-22 11:20:37 --> Controller Class Initialized
DEBUG - 2020-09-22 11:20:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:20:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:20:37 --> Model Class Initialized
INFO - 2020-09-22 11:20:37 --> Model Class Initialized
INFO - 2020-09-22 11:20:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 11:20:37 --> Final output sent to browser
DEBUG - 2020-09-22 11:20:37 --> Total execution time: 0.0297
ERROR - 2020-09-22 11:20:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:20:37 --> Config Class Initialized
INFO - 2020-09-22 11:20:37 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:20:37 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:20:37 --> Utf8 Class Initialized
INFO - 2020-09-22 11:20:37 --> URI Class Initialized
INFO - 2020-09-22 11:20:37 --> Router Class Initialized
INFO - 2020-09-22 11:20:37 --> Output Class Initialized
INFO - 2020-09-22 11:20:37 --> Security Class Initialized
DEBUG - 2020-09-22 11:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:20:37 --> Input Class Initialized
INFO - 2020-09-22 11:20:37 --> Language Class Initialized
INFO - 2020-09-22 11:20:37 --> Loader Class Initialized
INFO - 2020-09-22 11:20:37 --> Helper loaded: url_helper
INFO - 2020-09-22 11:20:37 --> Database Driver Class Initialized
INFO - 2020-09-22 11:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:20:37 --> Email Class Initialized
INFO - 2020-09-22 11:20:37 --> Controller Class Initialized
DEBUG - 2020-09-22 11:20:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:20:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:20:37 --> Model Class Initialized
INFO - 2020-09-22 11:20:37 --> Model Class Initialized
INFO - 2020-09-22 11:20:37 --> Final output sent to browser
DEBUG - 2020-09-22 11:20:37 --> Total execution time: 0.0251
ERROR - 2020-09-22 11:21:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:21:14 --> Config Class Initialized
INFO - 2020-09-22 11:21:14 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:21:14 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:21:14 --> Utf8 Class Initialized
INFO - 2020-09-22 11:21:14 --> URI Class Initialized
INFO - 2020-09-22 11:21:14 --> Router Class Initialized
INFO - 2020-09-22 11:21:14 --> Output Class Initialized
INFO - 2020-09-22 11:21:14 --> Security Class Initialized
DEBUG - 2020-09-22 11:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:21:14 --> Input Class Initialized
INFO - 2020-09-22 11:21:14 --> Language Class Initialized
INFO - 2020-09-22 11:21:14 --> Loader Class Initialized
INFO - 2020-09-22 11:21:14 --> Helper loaded: url_helper
INFO - 2020-09-22 11:21:14 --> Database Driver Class Initialized
INFO - 2020-09-22 11:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:21:14 --> Email Class Initialized
INFO - 2020-09-22 11:21:14 --> Controller Class Initialized
DEBUG - 2020-09-22 11:21:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:21:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:21:14 --> Model Class Initialized
INFO - 2020-09-22 11:21:14 --> Model Class Initialized
INFO - 2020-09-22 11:21:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 11:21:14 --> Final output sent to browser
DEBUG - 2020-09-22 11:21:14 --> Total execution time: 0.0273
ERROR - 2020-09-22 11:21:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:21:14 --> Config Class Initialized
INFO - 2020-09-22 11:21:14 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:21:14 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:21:14 --> Utf8 Class Initialized
INFO - 2020-09-22 11:21:14 --> URI Class Initialized
INFO - 2020-09-22 11:21:14 --> Router Class Initialized
INFO - 2020-09-22 11:21:14 --> Output Class Initialized
INFO - 2020-09-22 11:21:14 --> Security Class Initialized
DEBUG - 2020-09-22 11:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:21:14 --> Input Class Initialized
INFO - 2020-09-22 11:21:14 --> Language Class Initialized
INFO - 2020-09-22 11:21:14 --> Loader Class Initialized
INFO - 2020-09-22 11:21:14 --> Helper loaded: url_helper
INFO - 2020-09-22 11:21:14 --> Database Driver Class Initialized
INFO - 2020-09-22 11:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:21:14 --> Email Class Initialized
INFO - 2020-09-22 11:21:14 --> Controller Class Initialized
DEBUG - 2020-09-22 11:21:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:21:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:21:14 --> Model Class Initialized
INFO - 2020-09-22 11:21:14 --> Model Class Initialized
INFO - 2020-09-22 11:21:14 --> Final output sent to browser
DEBUG - 2020-09-22 11:21:14 --> Total execution time: 0.0214
ERROR - 2020-09-22 11:21:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:21:55 --> Config Class Initialized
INFO - 2020-09-22 11:21:55 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:21:55 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:21:55 --> Utf8 Class Initialized
INFO - 2020-09-22 11:21:55 --> URI Class Initialized
INFO - 2020-09-22 11:21:55 --> Router Class Initialized
INFO - 2020-09-22 11:21:55 --> Output Class Initialized
INFO - 2020-09-22 11:21:55 --> Security Class Initialized
DEBUG - 2020-09-22 11:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:21:55 --> Input Class Initialized
INFO - 2020-09-22 11:21:55 --> Language Class Initialized
INFO - 2020-09-22 11:21:55 --> Loader Class Initialized
INFO - 2020-09-22 11:21:55 --> Helper loaded: url_helper
INFO - 2020-09-22 11:21:55 --> Database Driver Class Initialized
INFO - 2020-09-22 11:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:21:55 --> Email Class Initialized
INFO - 2020-09-22 11:21:55 --> Controller Class Initialized
DEBUG - 2020-09-22 11:21:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:21:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:21:55 --> Model Class Initialized
INFO - 2020-09-22 11:21:55 --> Model Class Initialized
INFO - 2020-09-22 11:21:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 11:21:55 --> Final output sent to browser
DEBUG - 2020-09-22 11:21:55 --> Total execution time: 0.0273
ERROR - 2020-09-22 11:21:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:21:56 --> Config Class Initialized
INFO - 2020-09-22 11:21:56 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:21:56 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:21:56 --> Utf8 Class Initialized
INFO - 2020-09-22 11:21:56 --> URI Class Initialized
INFO - 2020-09-22 11:21:56 --> Router Class Initialized
INFO - 2020-09-22 11:21:56 --> Output Class Initialized
INFO - 2020-09-22 11:21:56 --> Security Class Initialized
DEBUG - 2020-09-22 11:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:21:56 --> Input Class Initialized
INFO - 2020-09-22 11:21:56 --> Language Class Initialized
INFO - 2020-09-22 11:21:56 --> Loader Class Initialized
INFO - 2020-09-22 11:21:56 --> Helper loaded: url_helper
INFO - 2020-09-22 11:21:56 --> Database Driver Class Initialized
INFO - 2020-09-22 11:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:21:56 --> Email Class Initialized
INFO - 2020-09-22 11:21:56 --> Controller Class Initialized
DEBUG - 2020-09-22 11:21:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:21:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:21:56 --> Model Class Initialized
INFO - 2020-09-22 11:21:56 --> Model Class Initialized
INFO - 2020-09-22 11:21:56 --> Final output sent to browser
DEBUG - 2020-09-22 11:21:56 --> Total execution time: 0.0255
ERROR - 2020-09-22 11:25:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:25:35 --> Config Class Initialized
INFO - 2020-09-22 11:25:35 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:25:35 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:25:35 --> Utf8 Class Initialized
INFO - 2020-09-22 11:25:35 --> URI Class Initialized
INFO - 2020-09-22 11:25:35 --> Router Class Initialized
INFO - 2020-09-22 11:25:35 --> Output Class Initialized
INFO - 2020-09-22 11:25:35 --> Security Class Initialized
DEBUG - 2020-09-22 11:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:25:35 --> Input Class Initialized
INFO - 2020-09-22 11:25:35 --> Language Class Initialized
INFO - 2020-09-22 11:25:35 --> Loader Class Initialized
INFO - 2020-09-22 11:25:35 --> Helper loaded: url_helper
INFO - 2020-09-22 11:25:35 --> Database Driver Class Initialized
INFO - 2020-09-22 11:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:25:35 --> Email Class Initialized
INFO - 2020-09-22 11:25:35 --> Controller Class Initialized
DEBUG - 2020-09-22 11:25:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:25:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:25:35 --> Model Class Initialized
INFO - 2020-09-22 11:25:35 --> Model Class Initialized
INFO - 2020-09-22 11:25:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 11:25:35 --> Final output sent to browser
DEBUG - 2020-09-22 11:25:35 --> Total execution time: 0.0333
ERROR - 2020-09-22 11:25:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:25:56 --> Config Class Initialized
INFO - 2020-09-22 11:25:56 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:25:56 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:25:56 --> Utf8 Class Initialized
INFO - 2020-09-22 11:25:56 --> URI Class Initialized
INFO - 2020-09-22 11:25:56 --> Router Class Initialized
INFO - 2020-09-22 11:25:56 --> Output Class Initialized
INFO - 2020-09-22 11:25:56 --> Security Class Initialized
DEBUG - 2020-09-22 11:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:25:56 --> Input Class Initialized
INFO - 2020-09-22 11:25:56 --> Language Class Initialized
INFO - 2020-09-22 11:25:56 --> Loader Class Initialized
INFO - 2020-09-22 11:25:56 --> Helper loaded: url_helper
INFO - 2020-09-22 11:25:56 --> Database Driver Class Initialized
INFO - 2020-09-22 11:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:25:56 --> Email Class Initialized
INFO - 2020-09-22 11:25:56 --> Controller Class Initialized
DEBUG - 2020-09-22 11:25:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:25:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:25:56 --> Model Class Initialized
INFO - 2020-09-22 11:25:56 --> Model Class Initialized
INFO - 2020-09-22 11:25:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 11:25:56 --> Final output sent to browser
DEBUG - 2020-09-22 11:25:56 --> Total execution time: 0.0273
ERROR - 2020-09-22 11:25:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:25:57 --> Config Class Initialized
INFO - 2020-09-22 11:25:57 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:25:57 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:25:57 --> Utf8 Class Initialized
INFO - 2020-09-22 11:25:57 --> URI Class Initialized
INFO - 2020-09-22 11:25:57 --> Router Class Initialized
INFO - 2020-09-22 11:25:57 --> Output Class Initialized
INFO - 2020-09-22 11:25:57 --> Security Class Initialized
DEBUG - 2020-09-22 11:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:25:57 --> Input Class Initialized
INFO - 2020-09-22 11:25:57 --> Language Class Initialized
INFO - 2020-09-22 11:25:57 --> Loader Class Initialized
INFO - 2020-09-22 11:25:57 --> Helper loaded: url_helper
INFO - 2020-09-22 11:25:57 --> Database Driver Class Initialized
INFO - 2020-09-22 11:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:25:57 --> Email Class Initialized
INFO - 2020-09-22 11:25:57 --> Controller Class Initialized
DEBUG - 2020-09-22 11:25:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:25:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:25:57 --> Model Class Initialized
INFO - 2020-09-22 11:25:57 --> Model Class Initialized
INFO - 2020-09-22 11:25:57 --> Final output sent to browser
DEBUG - 2020-09-22 11:25:57 --> Total execution time: 0.0250
ERROR - 2020-09-22 11:26:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:26:25 --> Config Class Initialized
INFO - 2020-09-22 11:26:25 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:26:25 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:26:25 --> Utf8 Class Initialized
INFO - 2020-09-22 11:26:25 --> URI Class Initialized
INFO - 2020-09-22 11:26:25 --> Router Class Initialized
INFO - 2020-09-22 11:26:25 --> Output Class Initialized
INFO - 2020-09-22 11:26:25 --> Security Class Initialized
DEBUG - 2020-09-22 11:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:26:25 --> Input Class Initialized
INFO - 2020-09-22 11:26:25 --> Language Class Initialized
INFO - 2020-09-22 11:26:25 --> Loader Class Initialized
INFO - 2020-09-22 11:26:25 --> Helper loaded: url_helper
INFO - 2020-09-22 11:26:25 --> Database Driver Class Initialized
INFO - 2020-09-22 11:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:26:25 --> Email Class Initialized
INFO - 2020-09-22 11:26:25 --> Controller Class Initialized
DEBUG - 2020-09-22 11:26:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:26:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:26:25 --> Model Class Initialized
INFO - 2020-09-22 11:26:25 --> Model Class Initialized
INFO - 2020-09-22 11:26:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 11:26:25 --> Final output sent to browser
DEBUG - 2020-09-22 11:26:25 --> Total execution time: 0.0349
ERROR - 2020-09-22 11:26:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:26:25 --> Config Class Initialized
INFO - 2020-09-22 11:26:25 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:26:25 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:26:25 --> Utf8 Class Initialized
INFO - 2020-09-22 11:26:25 --> URI Class Initialized
INFO - 2020-09-22 11:26:25 --> Router Class Initialized
INFO - 2020-09-22 11:26:25 --> Output Class Initialized
INFO - 2020-09-22 11:26:25 --> Security Class Initialized
DEBUG - 2020-09-22 11:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:26:25 --> Input Class Initialized
INFO - 2020-09-22 11:26:25 --> Language Class Initialized
INFO - 2020-09-22 11:26:25 --> Loader Class Initialized
INFO - 2020-09-22 11:26:25 --> Helper loaded: url_helper
INFO - 2020-09-22 11:26:25 --> Database Driver Class Initialized
INFO - 2020-09-22 11:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:26:25 --> Email Class Initialized
INFO - 2020-09-22 11:26:25 --> Controller Class Initialized
DEBUG - 2020-09-22 11:26:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:26:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:26:25 --> Model Class Initialized
INFO - 2020-09-22 11:26:25 --> Model Class Initialized
INFO - 2020-09-22 11:26:25 --> Final output sent to browser
DEBUG - 2020-09-22 11:26:25 --> Total execution time: 0.0248
ERROR - 2020-09-22 11:30:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:30:44 --> Config Class Initialized
INFO - 2020-09-22 11:30:44 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:30:44 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:30:44 --> Utf8 Class Initialized
INFO - 2020-09-22 11:30:44 --> URI Class Initialized
INFO - 2020-09-22 11:30:44 --> Router Class Initialized
INFO - 2020-09-22 11:30:44 --> Output Class Initialized
INFO - 2020-09-22 11:30:44 --> Security Class Initialized
DEBUG - 2020-09-22 11:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:30:44 --> Input Class Initialized
INFO - 2020-09-22 11:30:44 --> Language Class Initialized
INFO - 2020-09-22 11:30:44 --> Loader Class Initialized
INFO - 2020-09-22 11:30:44 --> Helper loaded: url_helper
INFO - 2020-09-22 11:30:44 --> Database Driver Class Initialized
INFO - 2020-09-22 11:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:30:44 --> Email Class Initialized
INFO - 2020-09-22 11:30:44 --> Controller Class Initialized
DEBUG - 2020-09-22 11:30:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:30:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:30:44 --> Model Class Initialized
INFO - 2020-09-22 11:30:44 --> Model Class Initialized
INFO - 2020-09-22 11:30:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 11:30:44 --> Final output sent to browser
DEBUG - 2020-09-22 11:30:44 --> Total execution time: 0.0286
ERROR - 2020-09-22 11:30:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:30:45 --> Config Class Initialized
INFO - 2020-09-22 11:30:45 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:30:45 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:30:45 --> Utf8 Class Initialized
INFO - 2020-09-22 11:30:45 --> URI Class Initialized
INFO - 2020-09-22 11:30:45 --> Router Class Initialized
INFO - 2020-09-22 11:30:45 --> Output Class Initialized
INFO - 2020-09-22 11:30:45 --> Security Class Initialized
DEBUG - 2020-09-22 11:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:30:45 --> Input Class Initialized
INFO - 2020-09-22 11:30:45 --> Language Class Initialized
INFO - 2020-09-22 11:30:45 --> Loader Class Initialized
INFO - 2020-09-22 11:30:45 --> Helper loaded: url_helper
INFO - 2020-09-22 11:30:45 --> Database Driver Class Initialized
INFO - 2020-09-22 11:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:30:45 --> Email Class Initialized
INFO - 2020-09-22 11:30:45 --> Controller Class Initialized
DEBUG - 2020-09-22 11:30:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:30:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:30:45 --> Model Class Initialized
INFO - 2020-09-22 11:30:45 --> Model Class Initialized
INFO - 2020-09-22 11:30:45 --> Final output sent to browser
DEBUG - 2020-09-22 11:30:45 --> Total execution time: 0.0221
ERROR - 2020-09-22 11:30:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:30:52 --> Config Class Initialized
INFO - 2020-09-22 11:30:52 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:30:52 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:30:52 --> Utf8 Class Initialized
INFO - 2020-09-22 11:30:52 --> URI Class Initialized
INFO - 2020-09-22 11:30:52 --> Router Class Initialized
INFO - 2020-09-22 11:30:52 --> Output Class Initialized
INFO - 2020-09-22 11:30:52 --> Security Class Initialized
DEBUG - 2020-09-22 11:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:30:52 --> Input Class Initialized
INFO - 2020-09-22 11:30:52 --> Language Class Initialized
INFO - 2020-09-22 11:30:52 --> Loader Class Initialized
INFO - 2020-09-22 11:30:52 --> Helper loaded: url_helper
INFO - 2020-09-22 11:30:52 --> Database Driver Class Initialized
INFO - 2020-09-22 11:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:30:52 --> Email Class Initialized
INFO - 2020-09-22 11:30:52 --> Controller Class Initialized
DEBUG - 2020-09-22 11:30:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:30:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:30:52 --> Model Class Initialized
INFO - 2020-09-22 11:30:52 --> Model Class Initialized
INFO - 2020-09-22 11:30:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 11:30:52 --> Final output sent to browser
DEBUG - 2020-09-22 11:30:52 --> Total execution time: 0.0229
ERROR - 2020-09-22 11:30:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:30:54 --> Config Class Initialized
INFO - 2020-09-22 11:30:54 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:30:54 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:30:54 --> Utf8 Class Initialized
INFO - 2020-09-22 11:30:54 --> URI Class Initialized
INFO - 2020-09-22 11:30:54 --> Router Class Initialized
INFO - 2020-09-22 11:30:54 --> Output Class Initialized
INFO - 2020-09-22 11:30:54 --> Security Class Initialized
DEBUG - 2020-09-22 11:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:30:54 --> Input Class Initialized
INFO - 2020-09-22 11:30:54 --> Language Class Initialized
INFO - 2020-09-22 11:30:54 --> Loader Class Initialized
INFO - 2020-09-22 11:30:54 --> Helper loaded: url_helper
INFO - 2020-09-22 11:30:54 --> Database Driver Class Initialized
INFO - 2020-09-22 11:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:30:54 --> Email Class Initialized
INFO - 2020-09-22 11:30:54 --> Controller Class Initialized
DEBUG - 2020-09-22 11:30:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:30:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:30:54 --> Model Class Initialized
INFO - 2020-09-22 11:30:54 --> Model Class Initialized
INFO - 2020-09-22 11:30:54 --> Final output sent to browser
DEBUG - 2020-09-22 11:30:54 --> Total execution time: 0.0291
ERROR - 2020-09-22 11:36:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:36:29 --> Config Class Initialized
INFO - 2020-09-22 11:36:29 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:36:29 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:36:29 --> Utf8 Class Initialized
INFO - 2020-09-22 11:36:29 --> URI Class Initialized
INFO - 2020-09-22 11:36:29 --> Router Class Initialized
INFO - 2020-09-22 11:36:29 --> Output Class Initialized
INFO - 2020-09-22 11:36:29 --> Security Class Initialized
DEBUG - 2020-09-22 11:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:36:29 --> Input Class Initialized
INFO - 2020-09-22 11:36:29 --> Language Class Initialized
INFO - 2020-09-22 11:36:29 --> Loader Class Initialized
INFO - 2020-09-22 11:36:29 --> Helper loaded: url_helper
INFO - 2020-09-22 11:36:29 --> Database Driver Class Initialized
INFO - 2020-09-22 11:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:36:29 --> Email Class Initialized
INFO - 2020-09-22 11:36:29 --> Controller Class Initialized
DEBUG - 2020-09-22 11:36:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:36:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:36:29 --> Model Class Initialized
INFO - 2020-09-22 11:36:29 --> Model Class Initialized
INFO - 2020-09-22 11:36:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 11:36:29 --> Final output sent to browser
DEBUG - 2020-09-22 11:36:29 --> Total execution time: 0.0271
ERROR - 2020-09-22 11:36:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:36:30 --> Config Class Initialized
INFO - 2020-09-22 11:36:30 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:36:30 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:36:30 --> Utf8 Class Initialized
INFO - 2020-09-22 11:36:30 --> URI Class Initialized
INFO - 2020-09-22 11:36:30 --> Router Class Initialized
INFO - 2020-09-22 11:36:30 --> Output Class Initialized
INFO - 2020-09-22 11:36:30 --> Security Class Initialized
DEBUG - 2020-09-22 11:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:36:30 --> Input Class Initialized
INFO - 2020-09-22 11:36:30 --> Language Class Initialized
INFO - 2020-09-22 11:36:30 --> Loader Class Initialized
INFO - 2020-09-22 11:36:30 --> Helper loaded: url_helper
INFO - 2020-09-22 11:36:30 --> Database Driver Class Initialized
INFO - 2020-09-22 11:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:36:30 --> Email Class Initialized
INFO - 2020-09-22 11:36:30 --> Controller Class Initialized
DEBUG - 2020-09-22 11:36:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:36:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:36:30 --> Model Class Initialized
INFO - 2020-09-22 11:36:30 --> Model Class Initialized
INFO - 2020-09-22 11:36:30 --> Final output sent to browser
DEBUG - 2020-09-22 11:36:30 --> Total execution time: 0.0249
ERROR - 2020-09-22 11:39:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:39:11 --> Config Class Initialized
INFO - 2020-09-22 11:39:11 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:39:11 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:39:11 --> Utf8 Class Initialized
INFO - 2020-09-22 11:39:11 --> URI Class Initialized
INFO - 2020-09-22 11:39:11 --> Router Class Initialized
INFO - 2020-09-22 11:39:11 --> Output Class Initialized
INFO - 2020-09-22 11:39:11 --> Security Class Initialized
DEBUG - 2020-09-22 11:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:39:11 --> Input Class Initialized
INFO - 2020-09-22 11:39:11 --> Language Class Initialized
INFO - 2020-09-22 11:39:11 --> Loader Class Initialized
INFO - 2020-09-22 11:39:11 --> Helper loaded: url_helper
INFO - 2020-09-22 11:39:11 --> Database Driver Class Initialized
INFO - 2020-09-22 11:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:39:11 --> Email Class Initialized
INFO - 2020-09-22 11:39:11 --> Controller Class Initialized
DEBUG - 2020-09-22 11:39:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:39:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:39:11 --> Model Class Initialized
INFO - 2020-09-22 11:39:11 --> Model Class Initialized
INFO - 2020-09-22 11:39:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 11:39:11 --> Final output sent to browser
DEBUG - 2020-09-22 11:39:11 --> Total execution time: 0.0302
ERROR - 2020-09-22 11:39:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:39:11 --> Config Class Initialized
INFO - 2020-09-22 11:39:11 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:39:11 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:39:11 --> Utf8 Class Initialized
INFO - 2020-09-22 11:39:11 --> URI Class Initialized
INFO - 2020-09-22 11:39:11 --> Router Class Initialized
INFO - 2020-09-22 11:39:11 --> Output Class Initialized
INFO - 2020-09-22 11:39:11 --> Security Class Initialized
DEBUG - 2020-09-22 11:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:39:11 --> Input Class Initialized
INFO - 2020-09-22 11:39:11 --> Language Class Initialized
INFO - 2020-09-22 11:39:11 --> Loader Class Initialized
INFO - 2020-09-22 11:39:11 --> Helper loaded: url_helper
INFO - 2020-09-22 11:39:11 --> Database Driver Class Initialized
INFO - 2020-09-22 11:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:39:11 --> Email Class Initialized
INFO - 2020-09-22 11:39:11 --> Controller Class Initialized
DEBUG - 2020-09-22 11:39:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:39:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:39:11 --> Model Class Initialized
INFO - 2020-09-22 11:39:11 --> Model Class Initialized
INFO - 2020-09-22 11:39:11 --> Final output sent to browser
DEBUG - 2020-09-22 11:39:11 --> Total execution time: 0.0248
ERROR - 2020-09-22 11:39:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:39:27 --> Config Class Initialized
INFO - 2020-09-22 11:39:27 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:39:27 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:39:27 --> Utf8 Class Initialized
INFO - 2020-09-22 11:39:27 --> URI Class Initialized
INFO - 2020-09-22 11:39:27 --> Router Class Initialized
INFO - 2020-09-22 11:39:27 --> Output Class Initialized
INFO - 2020-09-22 11:39:27 --> Security Class Initialized
DEBUG - 2020-09-22 11:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:39:27 --> Input Class Initialized
INFO - 2020-09-22 11:39:27 --> Language Class Initialized
INFO - 2020-09-22 11:39:27 --> Loader Class Initialized
INFO - 2020-09-22 11:39:27 --> Helper loaded: url_helper
INFO - 2020-09-22 11:39:27 --> Database Driver Class Initialized
INFO - 2020-09-22 11:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:39:27 --> Email Class Initialized
INFO - 2020-09-22 11:39:27 --> Controller Class Initialized
DEBUG - 2020-09-22 11:39:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:39:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:39:27 --> Model Class Initialized
INFO - 2020-09-22 11:39:27 --> Model Class Initialized
INFO - 2020-09-22 11:39:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 11:39:27 --> Final output sent to browser
DEBUG - 2020-09-22 11:39:27 --> Total execution time: 0.0355
ERROR - 2020-09-22 11:39:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:39:28 --> Config Class Initialized
INFO - 2020-09-22 11:39:28 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:39:28 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:39:28 --> Utf8 Class Initialized
INFO - 2020-09-22 11:39:28 --> URI Class Initialized
INFO - 2020-09-22 11:39:28 --> Router Class Initialized
INFO - 2020-09-22 11:39:28 --> Output Class Initialized
INFO - 2020-09-22 11:39:28 --> Security Class Initialized
DEBUG - 2020-09-22 11:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:39:28 --> Input Class Initialized
INFO - 2020-09-22 11:39:28 --> Language Class Initialized
INFO - 2020-09-22 11:39:28 --> Loader Class Initialized
INFO - 2020-09-22 11:39:28 --> Helper loaded: url_helper
INFO - 2020-09-22 11:39:28 --> Database Driver Class Initialized
INFO - 2020-09-22 11:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:39:28 --> Email Class Initialized
INFO - 2020-09-22 11:39:28 --> Controller Class Initialized
DEBUG - 2020-09-22 11:39:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:39:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:39:28 --> Model Class Initialized
INFO - 2020-09-22 11:39:28 --> Model Class Initialized
INFO - 2020-09-22 11:39:28 --> Final output sent to browser
DEBUG - 2020-09-22 11:39:28 --> Total execution time: 0.0251
ERROR - 2020-09-22 11:41:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:41:02 --> Config Class Initialized
INFO - 2020-09-22 11:41:02 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:41:02 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:41:02 --> Utf8 Class Initialized
INFO - 2020-09-22 11:41:02 --> URI Class Initialized
INFO - 2020-09-22 11:41:02 --> Router Class Initialized
INFO - 2020-09-22 11:41:02 --> Output Class Initialized
INFO - 2020-09-22 11:41:02 --> Security Class Initialized
DEBUG - 2020-09-22 11:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:41:02 --> Input Class Initialized
INFO - 2020-09-22 11:41:02 --> Language Class Initialized
INFO - 2020-09-22 11:41:02 --> Loader Class Initialized
INFO - 2020-09-22 11:41:02 --> Helper loaded: url_helper
INFO - 2020-09-22 11:41:02 --> Database Driver Class Initialized
INFO - 2020-09-22 11:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:41:02 --> Email Class Initialized
INFO - 2020-09-22 11:41:02 --> Controller Class Initialized
DEBUG - 2020-09-22 11:41:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:41:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:41:02 --> Model Class Initialized
INFO - 2020-09-22 11:41:02 --> Model Class Initialized
INFO - 2020-09-22 11:41:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 11:41:02 --> Final output sent to browser
DEBUG - 2020-09-22 11:41:02 --> Total execution time: 0.0325
ERROR - 2020-09-22 11:41:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:41:03 --> Config Class Initialized
INFO - 2020-09-22 11:41:03 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:41:03 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:41:03 --> Utf8 Class Initialized
INFO - 2020-09-22 11:41:03 --> URI Class Initialized
INFO - 2020-09-22 11:41:03 --> Router Class Initialized
INFO - 2020-09-22 11:41:03 --> Output Class Initialized
INFO - 2020-09-22 11:41:03 --> Security Class Initialized
DEBUG - 2020-09-22 11:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:41:03 --> Input Class Initialized
INFO - 2020-09-22 11:41:03 --> Language Class Initialized
INFO - 2020-09-22 11:41:03 --> Loader Class Initialized
INFO - 2020-09-22 11:41:03 --> Helper loaded: url_helper
INFO - 2020-09-22 11:41:03 --> Database Driver Class Initialized
INFO - 2020-09-22 11:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:41:03 --> Email Class Initialized
INFO - 2020-09-22 11:41:03 --> Controller Class Initialized
DEBUG - 2020-09-22 11:41:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:41:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:41:03 --> Model Class Initialized
INFO - 2020-09-22 11:41:03 --> Model Class Initialized
INFO - 2020-09-22 11:41:03 --> Final output sent to browser
DEBUG - 2020-09-22 11:41:03 --> Total execution time: 0.0259
ERROR - 2020-09-22 11:47:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:47:16 --> Config Class Initialized
INFO - 2020-09-22 11:47:16 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:47:16 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:47:16 --> Utf8 Class Initialized
INFO - 2020-09-22 11:47:16 --> URI Class Initialized
INFO - 2020-09-22 11:47:16 --> Router Class Initialized
INFO - 2020-09-22 11:47:16 --> Output Class Initialized
INFO - 2020-09-22 11:47:16 --> Security Class Initialized
DEBUG - 2020-09-22 11:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:47:16 --> Input Class Initialized
INFO - 2020-09-22 11:47:16 --> Language Class Initialized
INFO - 2020-09-22 11:47:16 --> Loader Class Initialized
INFO - 2020-09-22 11:47:16 --> Helper loaded: url_helper
INFO - 2020-09-22 11:47:16 --> Database Driver Class Initialized
INFO - 2020-09-22 11:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:47:16 --> Email Class Initialized
INFO - 2020-09-22 11:47:16 --> Controller Class Initialized
DEBUG - 2020-09-22 11:47:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:47:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:47:16 --> Model Class Initialized
INFO - 2020-09-22 11:47:16 --> Model Class Initialized
INFO - 2020-09-22 11:47:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 11:47:16 --> Final output sent to browser
DEBUG - 2020-09-22 11:47:16 --> Total execution time: 0.0280
ERROR - 2020-09-22 11:47:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:47:17 --> Config Class Initialized
INFO - 2020-09-22 11:47:17 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:47:17 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:47:17 --> Utf8 Class Initialized
INFO - 2020-09-22 11:47:17 --> URI Class Initialized
INFO - 2020-09-22 11:47:17 --> Router Class Initialized
INFO - 2020-09-22 11:47:17 --> Output Class Initialized
INFO - 2020-09-22 11:47:17 --> Security Class Initialized
DEBUG - 2020-09-22 11:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:47:17 --> Input Class Initialized
INFO - 2020-09-22 11:47:17 --> Language Class Initialized
INFO - 2020-09-22 11:47:17 --> Loader Class Initialized
INFO - 2020-09-22 11:47:17 --> Helper loaded: url_helper
INFO - 2020-09-22 11:47:17 --> Database Driver Class Initialized
INFO - 2020-09-22 11:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:47:17 --> Email Class Initialized
INFO - 2020-09-22 11:47:17 --> Controller Class Initialized
DEBUG - 2020-09-22 11:47:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:47:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:47:17 --> Model Class Initialized
INFO - 2020-09-22 11:47:17 --> Model Class Initialized
INFO - 2020-09-22 11:47:17 --> Final output sent to browser
DEBUG - 2020-09-22 11:47:17 --> Total execution time: 0.0222
ERROR - 2020-09-22 11:47:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:47:47 --> Config Class Initialized
INFO - 2020-09-22 11:47:47 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:47:47 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:47:47 --> Utf8 Class Initialized
INFO - 2020-09-22 11:47:47 --> URI Class Initialized
INFO - 2020-09-22 11:47:47 --> Router Class Initialized
INFO - 2020-09-22 11:47:47 --> Output Class Initialized
INFO - 2020-09-22 11:47:47 --> Security Class Initialized
DEBUG - 2020-09-22 11:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:47:47 --> Input Class Initialized
INFO - 2020-09-22 11:47:47 --> Language Class Initialized
INFO - 2020-09-22 11:47:47 --> Loader Class Initialized
INFO - 2020-09-22 11:47:47 --> Helper loaded: url_helper
INFO - 2020-09-22 11:47:47 --> Database Driver Class Initialized
INFO - 2020-09-22 11:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:47:47 --> Email Class Initialized
INFO - 2020-09-22 11:47:47 --> Controller Class Initialized
DEBUG - 2020-09-22 11:47:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:47:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:47:47 --> Model Class Initialized
INFO - 2020-09-22 11:47:47 --> Model Class Initialized
INFO - 2020-09-22 11:47:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 11:47:47 --> Final output sent to browser
DEBUG - 2020-09-22 11:47:47 --> Total execution time: 0.0286
ERROR - 2020-09-22 11:47:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:47:49 --> Config Class Initialized
INFO - 2020-09-22 11:47:49 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:47:49 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:47:49 --> Utf8 Class Initialized
INFO - 2020-09-22 11:47:49 --> URI Class Initialized
INFO - 2020-09-22 11:47:49 --> Router Class Initialized
INFO - 2020-09-22 11:47:49 --> Output Class Initialized
INFO - 2020-09-22 11:47:49 --> Security Class Initialized
DEBUG - 2020-09-22 11:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:47:49 --> Input Class Initialized
INFO - 2020-09-22 11:47:49 --> Language Class Initialized
INFO - 2020-09-22 11:47:49 --> Loader Class Initialized
INFO - 2020-09-22 11:47:49 --> Helper loaded: url_helper
INFO - 2020-09-22 11:47:49 --> Database Driver Class Initialized
INFO - 2020-09-22 11:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:47:49 --> Email Class Initialized
INFO - 2020-09-22 11:47:49 --> Controller Class Initialized
DEBUG - 2020-09-22 11:47:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:47:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:47:49 --> Model Class Initialized
INFO - 2020-09-22 11:47:49 --> Model Class Initialized
INFO - 2020-09-22 11:47:49 --> Final output sent to browser
DEBUG - 2020-09-22 11:47:49 --> Total execution time: 0.0252
ERROR - 2020-09-22 11:48:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:48:15 --> Config Class Initialized
INFO - 2020-09-22 11:48:15 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:48:15 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:48:15 --> Utf8 Class Initialized
INFO - 2020-09-22 11:48:15 --> URI Class Initialized
INFO - 2020-09-22 11:48:15 --> Router Class Initialized
INFO - 2020-09-22 11:48:15 --> Output Class Initialized
INFO - 2020-09-22 11:48:15 --> Security Class Initialized
DEBUG - 2020-09-22 11:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:48:15 --> Input Class Initialized
INFO - 2020-09-22 11:48:15 --> Language Class Initialized
INFO - 2020-09-22 11:48:15 --> Loader Class Initialized
INFO - 2020-09-22 11:48:15 --> Helper loaded: url_helper
INFO - 2020-09-22 11:48:15 --> Database Driver Class Initialized
INFO - 2020-09-22 11:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:48:15 --> Email Class Initialized
INFO - 2020-09-22 11:48:15 --> Controller Class Initialized
DEBUG - 2020-09-22 11:48:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:48:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:48:15 --> Model Class Initialized
INFO - 2020-09-22 11:48:15 --> Model Class Initialized
INFO - 2020-09-22 11:48:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 11:48:15 --> Final output sent to browser
DEBUG - 2020-09-22 11:48:15 --> Total execution time: 0.0273
ERROR - 2020-09-22 11:48:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:48:16 --> Config Class Initialized
INFO - 2020-09-22 11:48:16 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:48:16 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:48:16 --> Utf8 Class Initialized
INFO - 2020-09-22 11:48:16 --> URI Class Initialized
INFO - 2020-09-22 11:48:16 --> Router Class Initialized
INFO - 2020-09-22 11:48:16 --> Output Class Initialized
INFO - 2020-09-22 11:48:16 --> Security Class Initialized
DEBUG - 2020-09-22 11:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:48:16 --> Input Class Initialized
INFO - 2020-09-22 11:48:16 --> Language Class Initialized
INFO - 2020-09-22 11:48:16 --> Loader Class Initialized
INFO - 2020-09-22 11:48:16 --> Helper loaded: url_helper
INFO - 2020-09-22 11:48:16 --> Database Driver Class Initialized
INFO - 2020-09-22 11:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:48:16 --> Email Class Initialized
INFO - 2020-09-22 11:48:16 --> Controller Class Initialized
DEBUG - 2020-09-22 11:48:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:48:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:48:16 --> Model Class Initialized
INFO - 2020-09-22 11:48:16 --> Model Class Initialized
INFO - 2020-09-22 11:48:16 --> Final output sent to browser
DEBUG - 2020-09-22 11:48:16 --> Total execution time: 0.0259
ERROR - 2020-09-22 11:49:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:49:48 --> Config Class Initialized
INFO - 2020-09-22 11:49:48 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:49:48 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:49:48 --> Utf8 Class Initialized
INFO - 2020-09-22 11:49:48 --> URI Class Initialized
INFO - 2020-09-22 11:49:48 --> Router Class Initialized
INFO - 2020-09-22 11:49:48 --> Output Class Initialized
INFO - 2020-09-22 11:49:48 --> Security Class Initialized
DEBUG - 2020-09-22 11:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:49:48 --> Input Class Initialized
INFO - 2020-09-22 11:49:48 --> Language Class Initialized
INFO - 2020-09-22 11:49:48 --> Loader Class Initialized
INFO - 2020-09-22 11:49:48 --> Helper loaded: url_helper
INFO - 2020-09-22 11:49:48 --> Database Driver Class Initialized
INFO - 2020-09-22 11:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:49:48 --> Email Class Initialized
INFO - 2020-09-22 11:49:48 --> Controller Class Initialized
DEBUG - 2020-09-22 11:49:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:49:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:49:48 --> Model Class Initialized
INFO - 2020-09-22 11:49:48 --> Model Class Initialized
INFO - 2020-09-22 11:49:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 11:49:48 --> Final output sent to browser
DEBUG - 2020-09-22 11:49:48 --> Total execution time: 0.0272
ERROR - 2020-09-22 11:49:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:49:48 --> Config Class Initialized
INFO - 2020-09-22 11:49:48 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:49:48 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:49:48 --> Utf8 Class Initialized
INFO - 2020-09-22 11:49:48 --> URI Class Initialized
INFO - 2020-09-22 11:49:48 --> Router Class Initialized
INFO - 2020-09-22 11:49:48 --> Output Class Initialized
INFO - 2020-09-22 11:49:48 --> Security Class Initialized
DEBUG - 2020-09-22 11:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:49:48 --> Input Class Initialized
INFO - 2020-09-22 11:49:48 --> Language Class Initialized
INFO - 2020-09-22 11:49:48 --> Loader Class Initialized
INFO - 2020-09-22 11:49:48 --> Helper loaded: url_helper
INFO - 2020-09-22 11:49:48 --> Database Driver Class Initialized
INFO - 2020-09-22 11:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:49:48 --> Email Class Initialized
INFO - 2020-09-22 11:49:48 --> Controller Class Initialized
DEBUG - 2020-09-22 11:49:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:49:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:49:48 --> Model Class Initialized
INFO - 2020-09-22 11:49:48 --> Model Class Initialized
INFO - 2020-09-22 11:49:48 --> Final output sent to browser
DEBUG - 2020-09-22 11:49:48 --> Total execution time: 0.0210
ERROR - 2020-09-22 11:50:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:50:41 --> Config Class Initialized
INFO - 2020-09-22 11:50:41 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:50:41 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:50:41 --> Utf8 Class Initialized
INFO - 2020-09-22 11:50:41 --> URI Class Initialized
INFO - 2020-09-22 11:50:41 --> Router Class Initialized
INFO - 2020-09-22 11:50:41 --> Output Class Initialized
INFO - 2020-09-22 11:50:41 --> Security Class Initialized
DEBUG - 2020-09-22 11:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:50:41 --> Input Class Initialized
INFO - 2020-09-22 11:50:41 --> Language Class Initialized
INFO - 2020-09-22 11:50:41 --> Loader Class Initialized
INFO - 2020-09-22 11:50:41 --> Helper loaded: url_helper
INFO - 2020-09-22 11:50:41 --> Database Driver Class Initialized
INFO - 2020-09-22 11:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:50:41 --> Email Class Initialized
INFO - 2020-09-22 11:50:41 --> Controller Class Initialized
DEBUG - 2020-09-22 11:50:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:50:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:50:41 --> Model Class Initialized
INFO - 2020-09-22 11:50:41 --> Model Class Initialized
INFO - 2020-09-22 11:50:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 11:50:41 --> Final output sent to browser
DEBUG - 2020-09-22 11:50:41 --> Total execution time: 0.0284
ERROR - 2020-09-22 11:50:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:50:42 --> Config Class Initialized
INFO - 2020-09-22 11:50:42 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:50:42 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:50:42 --> Utf8 Class Initialized
INFO - 2020-09-22 11:50:42 --> URI Class Initialized
INFO - 2020-09-22 11:50:42 --> Router Class Initialized
INFO - 2020-09-22 11:50:42 --> Output Class Initialized
INFO - 2020-09-22 11:50:42 --> Security Class Initialized
DEBUG - 2020-09-22 11:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:50:42 --> Input Class Initialized
INFO - 2020-09-22 11:50:42 --> Language Class Initialized
INFO - 2020-09-22 11:50:42 --> Loader Class Initialized
INFO - 2020-09-22 11:50:42 --> Helper loaded: url_helper
INFO - 2020-09-22 11:50:42 --> Database Driver Class Initialized
INFO - 2020-09-22 11:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:50:42 --> Email Class Initialized
INFO - 2020-09-22 11:50:42 --> Controller Class Initialized
DEBUG - 2020-09-22 11:50:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:50:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:50:42 --> Model Class Initialized
INFO - 2020-09-22 11:50:42 --> Model Class Initialized
INFO - 2020-09-22 11:50:42 --> Final output sent to browser
DEBUG - 2020-09-22 11:50:42 --> Total execution time: 0.0264
ERROR - 2020-09-22 11:51:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:51:30 --> Config Class Initialized
INFO - 2020-09-22 11:51:30 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:51:30 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:51:30 --> Utf8 Class Initialized
INFO - 2020-09-22 11:51:30 --> URI Class Initialized
INFO - 2020-09-22 11:51:30 --> Router Class Initialized
INFO - 2020-09-22 11:51:30 --> Output Class Initialized
INFO - 2020-09-22 11:51:30 --> Security Class Initialized
DEBUG - 2020-09-22 11:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:51:30 --> Input Class Initialized
INFO - 2020-09-22 11:51:30 --> Language Class Initialized
INFO - 2020-09-22 11:51:30 --> Loader Class Initialized
INFO - 2020-09-22 11:51:30 --> Helper loaded: url_helper
INFO - 2020-09-22 11:51:30 --> Database Driver Class Initialized
INFO - 2020-09-22 11:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:51:30 --> Email Class Initialized
INFO - 2020-09-22 11:51:30 --> Controller Class Initialized
DEBUG - 2020-09-22 11:51:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:51:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:51:30 --> Model Class Initialized
INFO - 2020-09-22 11:51:30 --> Model Class Initialized
INFO - 2020-09-22 11:51:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 11:51:30 --> Final output sent to browser
DEBUG - 2020-09-22 11:51:30 --> Total execution time: 0.0274
ERROR - 2020-09-22 11:51:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:51:31 --> Config Class Initialized
INFO - 2020-09-22 11:51:31 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:51:31 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:51:31 --> Utf8 Class Initialized
INFO - 2020-09-22 11:51:31 --> URI Class Initialized
INFO - 2020-09-22 11:51:31 --> Router Class Initialized
INFO - 2020-09-22 11:51:31 --> Output Class Initialized
INFO - 2020-09-22 11:51:31 --> Security Class Initialized
DEBUG - 2020-09-22 11:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:51:31 --> Input Class Initialized
INFO - 2020-09-22 11:51:31 --> Language Class Initialized
INFO - 2020-09-22 11:51:31 --> Loader Class Initialized
INFO - 2020-09-22 11:51:31 --> Helper loaded: url_helper
INFO - 2020-09-22 11:51:31 --> Database Driver Class Initialized
INFO - 2020-09-22 11:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:51:31 --> Email Class Initialized
INFO - 2020-09-22 11:51:31 --> Controller Class Initialized
DEBUG - 2020-09-22 11:51:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:51:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:51:31 --> Model Class Initialized
INFO - 2020-09-22 11:51:31 --> Model Class Initialized
INFO - 2020-09-22 11:51:31 --> Final output sent to browser
DEBUG - 2020-09-22 11:51:31 --> Total execution time: 0.0241
ERROR - 2020-09-22 11:51:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:51:43 --> Config Class Initialized
INFO - 2020-09-22 11:51:43 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:51:43 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:51:43 --> Utf8 Class Initialized
INFO - 2020-09-22 11:51:43 --> URI Class Initialized
INFO - 2020-09-22 11:51:43 --> Router Class Initialized
INFO - 2020-09-22 11:51:43 --> Output Class Initialized
INFO - 2020-09-22 11:51:43 --> Security Class Initialized
DEBUG - 2020-09-22 11:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:51:43 --> Input Class Initialized
INFO - 2020-09-22 11:51:43 --> Language Class Initialized
INFO - 2020-09-22 11:51:43 --> Loader Class Initialized
INFO - 2020-09-22 11:51:43 --> Helper loaded: url_helper
INFO - 2020-09-22 11:51:43 --> Database Driver Class Initialized
INFO - 2020-09-22 11:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:51:43 --> Email Class Initialized
INFO - 2020-09-22 11:51:43 --> Controller Class Initialized
DEBUG - 2020-09-22 11:51:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:51:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:51:43 --> Model Class Initialized
INFO - 2020-09-22 11:51:43 --> Model Class Initialized
INFO - 2020-09-22 11:51:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 11:51:44 --> Final output sent to browser
DEBUG - 2020-09-22 11:51:44 --> Total execution time: 0.0363
ERROR - 2020-09-22 11:51:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:51:45 --> Config Class Initialized
INFO - 2020-09-22 11:51:45 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:51:45 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:51:45 --> Utf8 Class Initialized
INFO - 2020-09-22 11:51:45 --> URI Class Initialized
INFO - 2020-09-22 11:51:45 --> Router Class Initialized
INFO - 2020-09-22 11:51:45 --> Output Class Initialized
INFO - 2020-09-22 11:51:45 --> Security Class Initialized
DEBUG - 2020-09-22 11:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:51:45 --> Input Class Initialized
INFO - 2020-09-22 11:51:45 --> Language Class Initialized
INFO - 2020-09-22 11:51:45 --> Loader Class Initialized
INFO - 2020-09-22 11:51:45 --> Helper loaded: url_helper
INFO - 2020-09-22 11:51:45 --> Database Driver Class Initialized
INFO - 2020-09-22 11:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:51:45 --> Email Class Initialized
INFO - 2020-09-22 11:51:45 --> Controller Class Initialized
DEBUG - 2020-09-22 11:51:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:51:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:51:45 --> Model Class Initialized
INFO - 2020-09-22 11:51:45 --> Model Class Initialized
INFO - 2020-09-22 11:51:45 --> Final output sent to browser
DEBUG - 2020-09-22 11:51:45 --> Total execution time: 0.0252
ERROR - 2020-09-22 11:52:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:52:23 --> Config Class Initialized
INFO - 2020-09-22 11:52:23 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:52:23 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:52:23 --> Utf8 Class Initialized
INFO - 2020-09-22 11:52:23 --> URI Class Initialized
INFO - 2020-09-22 11:52:23 --> Router Class Initialized
INFO - 2020-09-22 11:52:23 --> Output Class Initialized
INFO - 2020-09-22 11:52:23 --> Security Class Initialized
DEBUG - 2020-09-22 11:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:52:23 --> Input Class Initialized
INFO - 2020-09-22 11:52:23 --> Language Class Initialized
INFO - 2020-09-22 11:52:23 --> Loader Class Initialized
INFO - 2020-09-22 11:52:23 --> Helper loaded: url_helper
INFO - 2020-09-22 11:52:23 --> Database Driver Class Initialized
INFO - 2020-09-22 11:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:52:23 --> Email Class Initialized
INFO - 2020-09-22 11:52:23 --> Controller Class Initialized
DEBUG - 2020-09-22 11:52:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:52:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:52:23 --> Model Class Initialized
INFO - 2020-09-22 11:52:23 --> Model Class Initialized
INFO - 2020-09-22 11:52:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 11:52:23 --> Final output sent to browser
DEBUG - 2020-09-22 11:52:23 --> Total execution time: 0.0277
ERROR - 2020-09-22 11:52:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:52:24 --> Config Class Initialized
INFO - 2020-09-22 11:52:24 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:52:24 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:52:24 --> Utf8 Class Initialized
INFO - 2020-09-22 11:52:24 --> URI Class Initialized
INFO - 2020-09-22 11:52:24 --> Router Class Initialized
INFO - 2020-09-22 11:52:24 --> Output Class Initialized
INFO - 2020-09-22 11:52:24 --> Security Class Initialized
DEBUG - 2020-09-22 11:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:52:24 --> Input Class Initialized
INFO - 2020-09-22 11:52:24 --> Language Class Initialized
INFO - 2020-09-22 11:52:24 --> Loader Class Initialized
INFO - 2020-09-22 11:52:24 --> Helper loaded: url_helper
INFO - 2020-09-22 11:52:24 --> Database Driver Class Initialized
INFO - 2020-09-22 11:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:52:24 --> Email Class Initialized
INFO - 2020-09-22 11:52:24 --> Controller Class Initialized
DEBUG - 2020-09-22 11:52:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:52:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:52:24 --> Model Class Initialized
INFO - 2020-09-22 11:52:24 --> Model Class Initialized
INFO - 2020-09-22 11:52:24 --> Final output sent to browser
DEBUG - 2020-09-22 11:52:24 --> Total execution time: 0.0235
ERROR - 2020-09-22 11:53:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:53:17 --> Config Class Initialized
INFO - 2020-09-22 11:53:17 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:53:17 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:53:17 --> Utf8 Class Initialized
INFO - 2020-09-22 11:53:17 --> URI Class Initialized
INFO - 2020-09-22 11:53:17 --> Router Class Initialized
INFO - 2020-09-22 11:53:17 --> Output Class Initialized
INFO - 2020-09-22 11:53:17 --> Security Class Initialized
DEBUG - 2020-09-22 11:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:53:17 --> Input Class Initialized
INFO - 2020-09-22 11:53:17 --> Language Class Initialized
INFO - 2020-09-22 11:53:17 --> Loader Class Initialized
INFO - 2020-09-22 11:53:17 --> Helper loaded: url_helper
INFO - 2020-09-22 11:53:17 --> Database Driver Class Initialized
INFO - 2020-09-22 11:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:53:17 --> Email Class Initialized
INFO - 2020-09-22 11:53:17 --> Controller Class Initialized
DEBUG - 2020-09-22 11:53:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:53:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:53:17 --> Model Class Initialized
INFO - 2020-09-22 11:53:17 --> Model Class Initialized
INFO - 2020-09-22 11:53:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 11:53:17 --> Final output sent to browser
DEBUG - 2020-09-22 11:53:17 --> Total execution time: 0.0261
ERROR - 2020-09-22 11:53:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:53:18 --> Config Class Initialized
INFO - 2020-09-22 11:53:18 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:53:18 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:53:18 --> Utf8 Class Initialized
INFO - 2020-09-22 11:53:18 --> URI Class Initialized
INFO - 2020-09-22 11:53:18 --> Router Class Initialized
INFO - 2020-09-22 11:53:18 --> Output Class Initialized
INFO - 2020-09-22 11:53:18 --> Security Class Initialized
DEBUG - 2020-09-22 11:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:53:18 --> Input Class Initialized
INFO - 2020-09-22 11:53:18 --> Language Class Initialized
INFO - 2020-09-22 11:53:18 --> Loader Class Initialized
INFO - 2020-09-22 11:53:18 --> Helper loaded: url_helper
INFO - 2020-09-22 11:53:18 --> Database Driver Class Initialized
INFO - 2020-09-22 11:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:53:18 --> Email Class Initialized
INFO - 2020-09-22 11:53:18 --> Controller Class Initialized
DEBUG - 2020-09-22 11:53:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:53:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:53:18 --> Model Class Initialized
INFO - 2020-09-22 11:53:18 --> Model Class Initialized
INFO - 2020-09-22 11:53:18 --> Final output sent to browser
DEBUG - 2020-09-22 11:53:18 --> Total execution time: 0.0246
ERROR - 2020-09-22 11:53:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:53:25 --> Config Class Initialized
INFO - 2020-09-22 11:53:25 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:53:25 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:53:25 --> Utf8 Class Initialized
INFO - 2020-09-22 11:53:25 --> URI Class Initialized
INFO - 2020-09-22 11:53:25 --> Router Class Initialized
INFO - 2020-09-22 11:53:25 --> Output Class Initialized
INFO - 2020-09-22 11:53:25 --> Security Class Initialized
DEBUG - 2020-09-22 11:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:53:25 --> Input Class Initialized
INFO - 2020-09-22 11:53:25 --> Language Class Initialized
INFO - 2020-09-22 11:53:25 --> Loader Class Initialized
INFO - 2020-09-22 11:53:25 --> Helper loaded: url_helper
INFO - 2020-09-22 11:53:25 --> Database Driver Class Initialized
INFO - 2020-09-22 11:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:53:25 --> Email Class Initialized
INFO - 2020-09-22 11:53:25 --> Controller Class Initialized
DEBUG - 2020-09-22 11:53:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:53:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:53:25 --> Model Class Initialized
INFO - 2020-09-22 11:53:25 --> Model Class Initialized
INFO - 2020-09-22 11:53:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 11:53:25 --> Final output sent to browser
DEBUG - 2020-09-22 11:53:25 --> Total execution time: 0.0274
ERROR - 2020-09-22 11:53:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:53:25 --> Config Class Initialized
INFO - 2020-09-22 11:53:25 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:53:25 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:53:25 --> Utf8 Class Initialized
INFO - 2020-09-22 11:53:25 --> URI Class Initialized
INFO - 2020-09-22 11:53:25 --> Router Class Initialized
INFO - 2020-09-22 11:53:25 --> Output Class Initialized
INFO - 2020-09-22 11:53:25 --> Security Class Initialized
DEBUG - 2020-09-22 11:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:53:25 --> Input Class Initialized
INFO - 2020-09-22 11:53:25 --> Language Class Initialized
INFO - 2020-09-22 11:53:25 --> Loader Class Initialized
INFO - 2020-09-22 11:53:25 --> Helper loaded: url_helper
INFO - 2020-09-22 11:53:25 --> Database Driver Class Initialized
INFO - 2020-09-22 11:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:53:25 --> Email Class Initialized
INFO - 2020-09-22 11:53:25 --> Controller Class Initialized
DEBUG - 2020-09-22 11:53:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:53:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:53:25 --> Model Class Initialized
INFO - 2020-09-22 11:53:25 --> Model Class Initialized
INFO - 2020-09-22 11:53:25 --> Final output sent to browser
DEBUG - 2020-09-22 11:53:25 --> Total execution time: 0.0221
ERROR - 2020-09-22 11:53:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:53:30 --> Config Class Initialized
INFO - 2020-09-22 11:53:30 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:53:30 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:53:30 --> Utf8 Class Initialized
INFO - 2020-09-22 11:53:30 --> URI Class Initialized
INFO - 2020-09-22 11:53:30 --> Router Class Initialized
INFO - 2020-09-22 11:53:30 --> Output Class Initialized
INFO - 2020-09-22 11:53:30 --> Security Class Initialized
DEBUG - 2020-09-22 11:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:53:30 --> Input Class Initialized
INFO - 2020-09-22 11:53:30 --> Language Class Initialized
INFO - 2020-09-22 11:53:30 --> Loader Class Initialized
INFO - 2020-09-22 11:53:30 --> Helper loaded: url_helper
INFO - 2020-09-22 11:53:30 --> Database Driver Class Initialized
INFO - 2020-09-22 11:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:53:31 --> Email Class Initialized
INFO - 2020-09-22 11:53:31 --> Controller Class Initialized
DEBUG - 2020-09-22 11:53:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:53:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:53:31 --> Model Class Initialized
INFO - 2020-09-22 11:53:31 --> Model Class Initialized
INFO - 2020-09-22 11:53:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 11:53:31 --> Final output sent to browser
DEBUG - 2020-09-22 11:53:31 --> Total execution time: 0.0279
ERROR - 2020-09-22 11:53:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:53:32 --> Config Class Initialized
INFO - 2020-09-22 11:53:32 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:53:32 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:53:32 --> Utf8 Class Initialized
INFO - 2020-09-22 11:53:32 --> URI Class Initialized
INFO - 2020-09-22 11:53:32 --> Router Class Initialized
INFO - 2020-09-22 11:53:32 --> Output Class Initialized
INFO - 2020-09-22 11:53:32 --> Security Class Initialized
DEBUG - 2020-09-22 11:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:53:32 --> Input Class Initialized
INFO - 2020-09-22 11:53:32 --> Language Class Initialized
INFO - 2020-09-22 11:53:32 --> Loader Class Initialized
INFO - 2020-09-22 11:53:32 --> Helper loaded: url_helper
INFO - 2020-09-22 11:53:32 --> Database Driver Class Initialized
INFO - 2020-09-22 11:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:53:32 --> Email Class Initialized
INFO - 2020-09-22 11:53:32 --> Controller Class Initialized
DEBUG - 2020-09-22 11:53:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:53:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:53:32 --> Model Class Initialized
INFO - 2020-09-22 11:53:32 --> Model Class Initialized
INFO - 2020-09-22 11:53:32 --> Final output sent to browser
DEBUG - 2020-09-22 11:53:32 --> Total execution time: 0.0220
ERROR - 2020-09-22 11:54:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:54:07 --> Config Class Initialized
INFO - 2020-09-22 11:54:07 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:54:07 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:54:07 --> Utf8 Class Initialized
INFO - 2020-09-22 11:54:07 --> URI Class Initialized
INFO - 2020-09-22 11:54:07 --> Router Class Initialized
INFO - 2020-09-22 11:54:07 --> Output Class Initialized
INFO - 2020-09-22 11:54:07 --> Security Class Initialized
DEBUG - 2020-09-22 11:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:54:07 --> Input Class Initialized
INFO - 2020-09-22 11:54:07 --> Language Class Initialized
INFO - 2020-09-22 11:54:07 --> Loader Class Initialized
INFO - 2020-09-22 11:54:07 --> Helper loaded: url_helper
INFO - 2020-09-22 11:54:07 --> Database Driver Class Initialized
INFO - 2020-09-22 11:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:54:07 --> Email Class Initialized
INFO - 2020-09-22 11:54:07 --> Controller Class Initialized
DEBUG - 2020-09-22 11:54:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:54:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:54:07 --> Model Class Initialized
INFO - 2020-09-22 11:54:07 --> Model Class Initialized
INFO - 2020-09-22 11:54:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-09-22 11:54:07 --> Final output sent to browser
DEBUG - 2020-09-22 11:54:07 --> Total execution time: 0.0244
ERROR - 2020-09-22 11:54:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:54:08 --> Config Class Initialized
INFO - 2020-09-22 11:54:08 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:54:08 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:54:08 --> Utf8 Class Initialized
INFO - 2020-09-22 11:54:08 --> URI Class Initialized
INFO - 2020-09-22 11:54:08 --> Router Class Initialized
INFO - 2020-09-22 11:54:08 --> Output Class Initialized
INFO - 2020-09-22 11:54:08 --> Security Class Initialized
DEBUG - 2020-09-22 11:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:54:08 --> Input Class Initialized
INFO - 2020-09-22 11:54:08 --> Language Class Initialized
INFO - 2020-09-22 11:54:08 --> Loader Class Initialized
INFO - 2020-09-22 11:54:08 --> Helper loaded: url_helper
INFO - 2020-09-22 11:54:08 --> Database Driver Class Initialized
INFO - 2020-09-22 11:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:54:08 --> Email Class Initialized
INFO - 2020-09-22 11:54:08 --> Controller Class Initialized
DEBUG - 2020-09-22 11:54:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:54:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:54:08 --> Model Class Initialized
INFO - 2020-09-22 11:54:08 --> Model Class Initialized
INFO - 2020-09-22 11:54:08 --> Final output sent to browser
DEBUG - 2020-09-22 11:54:08 --> Total execution time: 0.0238
ERROR - 2020-09-22 11:54:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:54:09 --> Config Class Initialized
INFO - 2020-09-22 11:54:09 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:54:09 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:54:09 --> Utf8 Class Initialized
INFO - 2020-09-22 11:54:09 --> URI Class Initialized
INFO - 2020-09-22 11:54:09 --> Router Class Initialized
INFO - 2020-09-22 11:54:09 --> Output Class Initialized
INFO - 2020-09-22 11:54:09 --> Security Class Initialized
DEBUG - 2020-09-22 11:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:54:09 --> Input Class Initialized
INFO - 2020-09-22 11:54:09 --> Language Class Initialized
INFO - 2020-09-22 11:54:09 --> Loader Class Initialized
INFO - 2020-09-22 11:54:09 --> Helper loaded: url_helper
INFO - 2020-09-22 11:54:09 --> Database Driver Class Initialized
INFO - 2020-09-22 11:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:54:09 --> Email Class Initialized
INFO - 2020-09-22 11:54:09 --> Controller Class Initialized
DEBUG - 2020-09-22 11:54:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:54:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:54:09 --> Model Class Initialized
INFO - 2020-09-22 11:54:09 --> Model Class Initialized
INFO - 2020-09-22 11:54:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 11:54:09 --> Final output sent to browser
DEBUG - 2020-09-22 11:54:09 --> Total execution time: 0.0240
ERROR - 2020-09-22 11:54:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:54:10 --> Config Class Initialized
INFO - 2020-09-22 11:54:10 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:54:10 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:54:10 --> Utf8 Class Initialized
INFO - 2020-09-22 11:54:10 --> URI Class Initialized
INFO - 2020-09-22 11:54:10 --> Router Class Initialized
INFO - 2020-09-22 11:54:10 --> Output Class Initialized
INFO - 2020-09-22 11:54:10 --> Security Class Initialized
DEBUG - 2020-09-22 11:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:54:10 --> Input Class Initialized
INFO - 2020-09-22 11:54:10 --> Language Class Initialized
INFO - 2020-09-22 11:54:10 --> Loader Class Initialized
INFO - 2020-09-22 11:54:10 --> Helper loaded: url_helper
INFO - 2020-09-22 11:54:10 --> Database Driver Class Initialized
INFO - 2020-09-22 11:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:54:10 --> Email Class Initialized
INFO - 2020-09-22 11:54:10 --> Controller Class Initialized
DEBUG - 2020-09-22 11:54:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:54:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:54:10 --> Model Class Initialized
INFO - 2020-09-22 11:54:10 --> Model Class Initialized
INFO - 2020-09-22 11:54:10 --> Final output sent to browser
DEBUG - 2020-09-22 11:54:10 --> Total execution time: 0.0267
ERROR - 2020-09-22 11:54:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:54:29 --> Config Class Initialized
INFO - 2020-09-22 11:54:29 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:54:29 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:54:29 --> Utf8 Class Initialized
INFO - 2020-09-22 11:54:29 --> URI Class Initialized
INFO - 2020-09-22 11:54:29 --> Router Class Initialized
INFO - 2020-09-22 11:54:29 --> Output Class Initialized
INFO - 2020-09-22 11:54:29 --> Security Class Initialized
DEBUG - 2020-09-22 11:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:54:29 --> Input Class Initialized
INFO - 2020-09-22 11:54:29 --> Language Class Initialized
INFO - 2020-09-22 11:54:29 --> Loader Class Initialized
INFO - 2020-09-22 11:54:29 --> Helper loaded: url_helper
INFO - 2020-09-22 11:54:29 --> Database Driver Class Initialized
INFO - 2020-09-22 11:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:54:29 --> Email Class Initialized
INFO - 2020-09-22 11:54:29 --> Controller Class Initialized
DEBUG - 2020-09-22 11:54:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:54:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:54:29 --> Model Class Initialized
INFO - 2020-09-22 11:54:29 --> Model Class Initialized
INFO - 2020-09-22 11:54:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-22 11:54:29 --> Final output sent to browser
DEBUG - 2020-09-22 11:54:29 --> Total execution time: 0.0279
ERROR - 2020-09-22 11:54:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:54:30 --> Config Class Initialized
INFO - 2020-09-22 11:54:30 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:54:30 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:54:30 --> Utf8 Class Initialized
INFO - 2020-09-22 11:54:30 --> URI Class Initialized
INFO - 2020-09-22 11:54:30 --> Router Class Initialized
INFO - 2020-09-22 11:54:30 --> Output Class Initialized
INFO - 2020-09-22 11:54:30 --> Security Class Initialized
DEBUG - 2020-09-22 11:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:54:30 --> Input Class Initialized
INFO - 2020-09-22 11:54:30 --> Language Class Initialized
INFO - 2020-09-22 11:54:30 --> Loader Class Initialized
INFO - 2020-09-22 11:54:30 --> Helper loaded: url_helper
INFO - 2020-09-22 11:54:30 --> Database Driver Class Initialized
INFO - 2020-09-22 11:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:54:31 --> Email Class Initialized
INFO - 2020-09-22 11:54:31 --> Controller Class Initialized
DEBUG - 2020-09-22 11:54:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:54:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:54:31 --> Model Class Initialized
INFO - 2020-09-22 11:54:31 --> Model Class Initialized
INFO - 2020-09-22 11:54:31 --> Final output sent to browser
DEBUG - 2020-09-22 11:54:31 --> Total execution time: 0.0260
ERROR - 2020-09-22 11:54:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:54:40 --> Config Class Initialized
INFO - 2020-09-22 11:54:40 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:54:40 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:54:40 --> Utf8 Class Initialized
INFO - 2020-09-22 11:54:40 --> URI Class Initialized
INFO - 2020-09-22 11:54:40 --> Router Class Initialized
INFO - 2020-09-22 11:54:40 --> Output Class Initialized
INFO - 2020-09-22 11:54:40 --> Security Class Initialized
DEBUG - 2020-09-22 11:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:54:40 --> Input Class Initialized
INFO - 2020-09-22 11:54:40 --> Language Class Initialized
INFO - 2020-09-22 11:54:40 --> Loader Class Initialized
INFO - 2020-09-22 11:54:40 --> Helper loaded: url_helper
INFO - 2020-09-22 11:54:40 --> Database Driver Class Initialized
INFO - 2020-09-22 11:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:54:40 --> Email Class Initialized
INFO - 2020-09-22 11:54:40 --> Controller Class Initialized
DEBUG - 2020-09-22 11:54:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 11:54:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:54:40 --> Model Class Initialized
INFO - 2020-09-22 11:54:40 --> Model Class Initialized
INFO - 2020-09-22 11:54:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-22 11:54:40 --> Final output sent to browser
DEBUG - 2020-09-22 11:54:40 --> Total execution time: 0.0277
ERROR - 2020-09-22 11:55:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 11:55:42 --> Config Class Initialized
INFO - 2020-09-22 11:55:42 --> Hooks Class Initialized
DEBUG - 2020-09-22 11:55:42 --> UTF-8 Support Enabled
INFO - 2020-09-22 11:55:42 --> Utf8 Class Initialized
INFO - 2020-09-22 11:55:42 --> URI Class Initialized
DEBUG - 2020-09-22 11:55:42 --> No URI present. Default controller set.
INFO - 2020-09-22 11:55:42 --> Router Class Initialized
INFO - 2020-09-22 11:55:42 --> Output Class Initialized
INFO - 2020-09-22 11:55:42 --> Security Class Initialized
DEBUG - 2020-09-22 11:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 11:55:42 --> Input Class Initialized
INFO - 2020-09-22 11:55:42 --> Language Class Initialized
INFO - 2020-09-22 11:55:42 --> Loader Class Initialized
INFO - 2020-09-22 11:55:42 --> Helper loaded: url_helper
INFO - 2020-09-22 11:55:42 --> Database Driver Class Initialized
INFO - 2020-09-22 11:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 11:55:42 --> Email Class Initialized
INFO - 2020-09-22 11:55:42 --> Controller Class Initialized
INFO - 2020-09-22 11:55:42 --> Model Class Initialized
INFO - 2020-09-22 11:55:42 --> Model Class Initialized
DEBUG - 2020-09-22 11:55:42 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 11:55:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 11:55:42 --> Final output sent to browser
DEBUG - 2020-09-22 11:55:42 --> Total execution time: 0.0362
ERROR - 2020-09-22 15:35:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 15:35:24 --> Config Class Initialized
INFO - 2020-09-22 15:35:24 --> Hooks Class Initialized
DEBUG - 2020-09-22 15:35:24 --> UTF-8 Support Enabled
INFO - 2020-09-22 15:35:24 --> Utf8 Class Initialized
INFO - 2020-09-22 15:35:24 --> URI Class Initialized
DEBUG - 2020-09-22 15:35:24 --> No URI present. Default controller set.
INFO - 2020-09-22 15:35:24 --> Router Class Initialized
INFO - 2020-09-22 15:35:24 --> Output Class Initialized
INFO - 2020-09-22 15:35:24 --> Security Class Initialized
DEBUG - 2020-09-22 15:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 15:35:24 --> Input Class Initialized
INFO - 2020-09-22 15:35:24 --> Language Class Initialized
INFO - 2020-09-22 15:35:24 --> Loader Class Initialized
INFO - 2020-09-22 15:35:24 --> Helper loaded: url_helper
INFO - 2020-09-22 15:35:24 --> Database Driver Class Initialized
INFO - 2020-09-22 15:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 15:35:24 --> Email Class Initialized
INFO - 2020-09-22 15:35:24 --> Controller Class Initialized
INFO - 2020-09-22 15:35:24 --> Model Class Initialized
INFO - 2020-09-22 15:35:24 --> Model Class Initialized
DEBUG - 2020-09-22 15:35:24 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 15:35:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 15:35:24 --> Final output sent to browser
DEBUG - 2020-09-22 15:35:24 --> Total execution time: 0.0223
ERROR - 2020-09-22 15:35:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 15:35:26 --> Config Class Initialized
INFO - 2020-09-22 15:35:26 --> Hooks Class Initialized
DEBUG - 2020-09-22 15:35:26 --> UTF-8 Support Enabled
INFO - 2020-09-22 15:35:26 --> Utf8 Class Initialized
INFO - 2020-09-22 15:35:26 --> URI Class Initialized
INFO - 2020-09-22 15:35:26 --> Router Class Initialized
INFO - 2020-09-22 15:35:26 --> Output Class Initialized
INFO - 2020-09-22 15:35:26 --> Security Class Initialized
DEBUG - 2020-09-22 15:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 15:35:26 --> Input Class Initialized
INFO - 2020-09-22 15:35:26 --> Language Class Initialized
INFO - 2020-09-22 15:35:26 --> Loader Class Initialized
INFO - 2020-09-22 15:35:26 --> Helper loaded: url_helper
INFO - 2020-09-22 15:35:26 --> Database Driver Class Initialized
INFO - 2020-09-22 15:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 15:35:26 --> Email Class Initialized
INFO - 2020-09-22 15:35:26 --> Controller Class Initialized
INFO - 2020-09-22 15:35:26 --> Model Class Initialized
INFO - 2020-09-22 15:35:26 --> Model Class Initialized
DEBUG - 2020-09-22 15:35:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 15:35:26 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-22 15:35:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 15:35:26 --> Config Class Initialized
INFO - 2020-09-22 15:35:26 --> Hooks Class Initialized
DEBUG - 2020-09-22 15:35:26 --> UTF-8 Support Enabled
INFO - 2020-09-22 15:35:26 --> Utf8 Class Initialized
INFO - 2020-09-22 15:35:26 --> URI Class Initialized
INFO - 2020-09-22 15:35:26 --> Router Class Initialized
INFO - 2020-09-22 15:35:26 --> Output Class Initialized
INFO - 2020-09-22 15:35:26 --> Security Class Initialized
DEBUG - 2020-09-22 15:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 15:35:26 --> Input Class Initialized
INFO - 2020-09-22 15:35:26 --> Language Class Initialized
INFO - 2020-09-22 15:35:26 --> Loader Class Initialized
INFO - 2020-09-22 15:35:26 --> Helper loaded: url_helper
INFO - 2020-09-22 15:35:26 --> Database Driver Class Initialized
INFO - 2020-09-22 15:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 15:35:26 --> Email Class Initialized
INFO - 2020-09-22 15:35:26 --> Controller Class Initialized
INFO - 2020-09-22 15:35:26 --> Model Class Initialized
INFO - 2020-09-22 15:35:26 --> Model Class Initialized
DEBUG - 2020-09-22 15:35:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-22 15:35:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 15:35:27 --> Config Class Initialized
INFO - 2020-09-22 15:35:27 --> Hooks Class Initialized
DEBUG - 2020-09-22 15:35:27 --> UTF-8 Support Enabled
INFO - 2020-09-22 15:35:27 --> Utf8 Class Initialized
INFO - 2020-09-22 15:35:27 --> URI Class Initialized
DEBUG - 2020-09-22 15:35:27 --> No URI present. Default controller set.
INFO - 2020-09-22 15:35:27 --> Router Class Initialized
INFO - 2020-09-22 15:35:27 --> Output Class Initialized
INFO - 2020-09-22 15:35:27 --> Security Class Initialized
DEBUG - 2020-09-22 15:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 15:35:27 --> Input Class Initialized
INFO - 2020-09-22 15:35:27 --> Language Class Initialized
INFO - 2020-09-22 15:35:27 --> Loader Class Initialized
INFO - 2020-09-22 15:35:27 --> Helper loaded: url_helper
INFO - 2020-09-22 15:35:27 --> Database Driver Class Initialized
INFO - 2020-09-22 15:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 15:35:27 --> Email Class Initialized
INFO - 2020-09-22 15:35:27 --> Controller Class Initialized
INFO - 2020-09-22 15:35:27 --> Model Class Initialized
INFO - 2020-09-22 15:35:27 --> Model Class Initialized
DEBUG - 2020-09-22 15:35:27 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 15:35:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 15:35:27 --> Final output sent to browser
DEBUG - 2020-09-22 15:35:27 --> Total execution time: 0.0192
ERROR - 2020-09-22 15:35:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 15:35:27 --> Config Class Initialized
INFO - 2020-09-22 15:35:27 --> Hooks Class Initialized
DEBUG - 2020-09-22 15:35:27 --> UTF-8 Support Enabled
INFO - 2020-09-22 15:35:27 --> Utf8 Class Initialized
INFO - 2020-09-22 15:35:27 --> URI Class Initialized
INFO - 2020-09-22 15:35:27 --> Router Class Initialized
INFO - 2020-09-22 15:35:27 --> Output Class Initialized
INFO - 2020-09-22 15:35:27 --> Security Class Initialized
DEBUG - 2020-09-22 15:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 15:35:27 --> Input Class Initialized
INFO - 2020-09-22 15:35:27 --> Language Class Initialized
INFO - 2020-09-22 15:35:27 --> Loader Class Initialized
INFO - 2020-09-22 15:35:27 --> Helper loaded: url_helper
INFO - 2020-09-22 15:35:27 --> Database Driver Class Initialized
INFO - 2020-09-22 15:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 15:35:27 --> Email Class Initialized
INFO - 2020-09-22 15:35:27 --> Controller Class Initialized
DEBUG - 2020-09-22 15:35:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 15:35:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 15:35:27 --> Model Class Initialized
INFO - 2020-09-22 15:35:27 --> Model Class Initialized
INFO - 2020-09-22 15:35:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-22 15:35:27 --> Final output sent to browser
DEBUG - 2020-09-22 15:35:27 --> Total execution time: 0.0231
ERROR - 2020-09-22 15:40:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 15:40:11 --> Config Class Initialized
INFO - 2020-09-22 15:40:11 --> Hooks Class Initialized
DEBUG - 2020-09-22 15:40:11 --> UTF-8 Support Enabled
INFO - 2020-09-22 15:40:11 --> Utf8 Class Initialized
INFO - 2020-09-22 15:40:11 --> URI Class Initialized
DEBUG - 2020-09-22 15:40:11 --> No URI present. Default controller set.
INFO - 2020-09-22 15:40:11 --> Router Class Initialized
INFO - 2020-09-22 15:40:11 --> Output Class Initialized
INFO - 2020-09-22 15:40:11 --> Security Class Initialized
DEBUG - 2020-09-22 15:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 15:40:11 --> Input Class Initialized
INFO - 2020-09-22 15:40:11 --> Language Class Initialized
INFO - 2020-09-22 15:40:11 --> Loader Class Initialized
INFO - 2020-09-22 15:40:11 --> Helper loaded: url_helper
INFO - 2020-09-22 15:40:11 --> Database Driver Class Initialized
INFO - 2020-09-22 15:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 15:40:11 --> Email Class Initialized
INFO - 2020-09-22 15:40:11 --> Controller Class Initialized
INFO - 2020-09-22 15:40:11 --> Model Class Initialized
INFO - 2020-09-22 15:40:11 --> Model Class Initialized
DEBUG - 2020-09-22 15:40:11 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 15:40:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 15:40:11 --> Final output sent to browser
DEBUG - 2020-09-22 15:40:11 --> Total execution time: 0.0173
ERROR - 2020-09-22 15:40:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 15:40:30 --> Config Class Initialized
INFO - 2020-09-22 15:40:30 --> Hooks Class Initialized
DEBUG - 2020-09-22 15:40:30 --> UTF-8 Support Enabled
INFO - 2020-09-22 15:40:30 --> Utf8 Class Initialized
INFO - 2020-09-22 15:40:30 --> URI Class Initialized
INFO - 2020-09-22 15:40:30 --> Router Class Initialized
INFO - 2020-09-22 15:40:30 --> Output Class Initialized
INFO - 2020-09-22 15:40:30 --> Security Class Initialized
DEBUG - 2020-09-22 15:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 15:40:30 --> Input Class Initialized
INFO - 2020-09-22 15:40:30 --> Language Class Initialized
INFO - 2020-09-22 15:40:30 --> Loader Class Initialized
INFO - 2020-09-22 15:40:30 --> Helper loaded: url_helper
INFO - 2020-09-22 15:40:30 --> Database Driver Class Initialized
INFO - 2020-09-22 15:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 15:40:30 --> Email Class Initialized
INFO - 2020-09-22 15:40:30 --> Controller Class Initialized
INFO - 2020-09-22 15:40:30 --> Model Class Initialized
INFO - 2020-09-22 15:40:30 --> Model Class Initialized
DEBUG - 2020-09-22 15:40:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-22 15:40:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 15:40:30 --> Config Class Initialized
INFO - 2020-09-22 15:40:30 --> Hooks Class Initialized
DEBUG - 2020-09-22 15:40:30 --> UTF-8 Support Enabled
INFO - 2020-09-22 15:40:30 --> Utf8 Class Initialized
INFO - 2020-09-22 15:40:30 --> URI Class Initialized
INFO - 2020-09-22 15:40:30 --> Router Class Initialized
INFO - 2020-09-22 15:40:30 --> Output Class Initialized
INFO - 2020-09-22 15:40:30 --> Security Class Initialized
DEBUG - 2020-09-22 15:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 15:40:30 --> Input Class Initialized
INFO - 2020-09-22 15:40:30 --> Language Class Initialized
INFO - 2020-09-22 15:40:30 --> Loader Class Initialized
INFO - 2020-09-22 15:40:30 --> Helper loaded: url_helper
INFO - 2020-09-22 15:40:30 --> Database Driver Class Initialized
INFO - 2020-09-22 15:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 15:40:30 --> Email Class Initialized
INFO - 2020-09-22 15:40:30 --> Controller Class Initialized
INFO - 2020-09-22 15:40:30 --> Model Class Initialized
INFO - 2020-09-22 15:40:30 --> Model Class Initialized
DEBUG - 2020-09-22 15:40:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 15:40:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 15:40:30 --> Model Class Initialized
INFO - 2020-09-22 15:40:30 --> Final output sent to browser
DEBUG - 2020-09-22 15:40:30 --> Total execution time: 0.0192
ERROR - 2020-09-22 15:40:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 15:40:31 --> Config Class Initialized
INFO - 2020-09-22 15:40:31 --> Hooks Class Initialized
DEBUG - 2020-09-22 15:40:31 --> UTF-8 Support Enabled
INFO - 2020-09-22 15:40:31 --> Utf8 Class Initialized
INFO - 2020-09-22 15:40:31 --> URI Class Initialized
INFO - 2020-09-22 15:40:31 --> Router Class Initialized
INFO - 2020-09-22 15:40:31 --> Output Class Initialized
INFO - 2020-09-22 15:40:31 --> Security Class Initialized
DEBUG - 2020-09-22 15:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 15:40:31 --> Input Class Initialized
INFO - 2020-09-22 15:40:31 --> Language Class Initialized
INFO - 2020-09-22 15:40:31 --> Loader Class Initialized
INFO - 2020-09-22 15:40:31 --> Helper loaded: url_helper
INFO - 2020-09-22 15:40:31 --> Database Driver Class Initialized
INFO - 2020-09-22 15:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 15:40:31 --> Email Class Initialized
INFO - 2020-09-22 15:40:31 --> Controller Class Initialized
DEBUG - 2020-09-22 15:40:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 15:40:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 15:40:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-22 15:40:31 --> Final output sent to browser
DEBUG - 2020-09-22 15:40:31 --> Total execution time: 0.0200
ERROR - 2020-09-22 16:40:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 16:40:00 --> Config Class Initialized
INFO - 2020-09-22 16:40:00 --> Hooks Class Initialized
DEBUG - 2020-09-22 16:40:00 --> UTF-8 Support Enabled
INFO - 2020-09-22 16:40:00 --> Utf8 Class Initialized
INFO - 2020-09-22 16:40:00 --> URI Class Initialized
DEBUG - 2020-09-22 16:40:00 --> No URI present. Default controller set.
INFO - 2020-09-22 16:40:00 --> Router Class Initialized
INFO - 2020-09-22 16:40:00 --> Output Class Initialized
INFO - 2020-09-22 16:40:00 --> Security Class Initialized
DEBUG - 2020-09-22 16:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 16:40:00 --> Input Class Initialized
INFO - 2020-09-22 16:40:00 --> Language Class Initialized
INFO - 2020-09-22 16:40:00 --> Loader Class Initialized
INFO - 2020-09-22 16:40:00 --> Helper loaded: url_helper
INFO - 2020-09-22 16:40:00 --> Database Driver Class Initialized
INFO - 2020-09-22 16:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 16:40:00 --> Email Class Initialized
INFO - 2020-09-22 16:40:00 --> Controller Class Initialized
INFO - 2020-09-22 16:40:00 --> Model Class Initialized
INFO - 2020-09-22 16:40:00 --> Model Class Initialized
DEBUG - 2020-09-22 16:40:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 16:40:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 16:40:00 --> Final output sent to browser
DEBUG - 2020-09-22 16:40:00 --> Total execution time: 0.0251
ERROR - 2020-09-22 16:40:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 16:40:03 --> Config Class Initialized
INFO - 2020-09-22 16:40:03 --> Hooks Class Initialized
DEBUG - 2020-09-22 16:40:03 --> UTF-8 Support Enabled
INFO - 2020-09-22 16:40:03 --> Utf8 Class Initialized
INFO - 2020-09-22 16:40:03 --> URI Class Initialized
INFO - 2020-09-22 16:40:03 --> Router Class Initialized
INFO - 2020-09-22 16:40:03 --> Output Class Initialized
INFO - 2020-09-22 16:40:03 --> Security Class Initialized
DEBUG - 2020-09-22 16:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 16:40:03 --> Input Class Initialized
INFO - 2020-09-22 16:40:03 --> Language Class Initialized
INFO - 2020-09-22 16:40:03 --> Loader Class Initialized
INFO - 2020-09-22 16:40:03 --> Helper loaded: url_helper
INFO - 2020-09-22 16:40:03 --> Database Driver Class Initialized
ERROR - 2020-09-22 16:40:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 16:40:03 --> Config Class Initialized
INFO - 2020-09-22 16:40:03 --> Hooks Class Initialized
DEBUG - 2020-09-22 16:40:03 --> UTF-8 Support Enabled
INFO - 2020-09-22 16:40:03 --> Utf8 Class Initialized
INFO - 2020-09-22 16:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 16:40:03 --> URI Class Initialized
INFO - 2020-09-22 16:40:03 --> Router Class Initialized
INFO - 2020-09-22 16:40:03 --> Output Class Initialized
INFO - 2020-09-22 16:40:03 --> Email Class Initialized
INFO - 2020-09-22 16:40:03 --> Controller Class Initialized
INFO - 2020-09-22 16:40:03 --> Model Class Initialized
INFO - 2020-09-22 16:40:03 --> Security Class Initialized
INFO - 2020-09-22 16:40:03 --> Model Class Initialized
DEBUG - 2020-09-22 16:40:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 16:40:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 16:40:03 --> Model Class Initialized
DEBUG - 2020-09-22 16:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 16:40:03 --> Input Class Initialized
INFO - 2020-09-22 16:40:03 --> Language Class Initialized
INFO - 2020-09-22 16:40:03 --> Loader Class Initialized
INFO - 2020-09-22 16:40:03 --> Final output sent to browser
DEBUG - 2020-09-22 16:40:03 --> Total execution time: 0.0256
INFO - 2020-09-22 16:40:03 --> Helper loaded: url_helper
INFO - 2020-09-22 16:40:03 --> Database Driver Class Initialized
INFO - 2020-09-22 16:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 16:40:03 --> Email Class Initialized
INFO - 2020-09-22 16:40:03 --> Controller Class Initialized
INFO - 2020-09-22 16:40:03 --> Model Class Initialized
INFO - 2020-09-22 16:40:03 --> Model Class Initialized
DEBUG - 2020-09-22 16:40:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-22 16:40:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 16:40:03 --> Config Class Initialized
INFO - 2020-09-22 16:40:03 --> Hooks Class Initialized
DEBUG - 2020-09-22 16:40:03 --> UTF-8 Support Enabled
INFO - 2020-09-22 16:40:03 --> Utf8 Class Initialized
INFO - 2020-09-22 16:40:03 --> URI Class Initialized
INFO - 2020-09-22 16:40:03 --> Router Class Initialized
INFO - 2020-09-22 16:40:03 --> Output Class Initialized
INFO - 2020-09-22 16:40:03 --> Security Class Initialized
DEBUG - 2020-09-22 16:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 16:40:03 --> Input Class Initialized
INFO - 2020-09-22 16:40:03 --> Language Class Initialized
INFO - 2020-09-22 16:40:03 --> Loader Class Initialized
INFO - 2020-09-22 16:40:03 --> Helper loaded: url_helper
INFO - 2020-09-22 16:40:03 --> Database Driver Class Initialized
INFO - 2020-09-22 16:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 16:40:03 --> Email Class Initialized
INFO - 2020-09-22 16:40:03 --> Controller Class Initialized
DEBUG - 2020-09-22 16:40:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 16:40:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 16:40:03 --> Model Class Initialized
INFO - 2020-09-22 16:40:03 --> Model Class Initialized
INFO - 2020-09-22 16:40:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-22 16:40:03 --> Final output sent to browser
DEBUG - 2020-09-22 16:40:03 --> Total execution time: 0.0268
ERROR - 2020-09-22 16:57:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 16:57:37 --> Config Class Initialized
INFO - 2020-09-22 16:57:37 --> Hooks Class Initialized
DEBUG - 2020-09-22 16:57:37 --> UTF-8 Support Enabled
INFO - 2020-09-22 16:57:37 --> Utf8 Class Initialized
INFO - 2020-09-22 16:57:37 --> URI Class Initialized
INFO - 2020-09-22 16:57:37 --> Router Class Initialized
INFO - 2020-09-22 16:57:37 --> Output Class Initialized
INFO - 2020-09-22 16:57:37 --> Security Class Initialized
DEBUG - 2020-09-22 16:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 16:57:37 --> Input Class Initialized
INFO - 2020-09-22 16:57:37 --> Language Class Initialized
INFO - 2020-09-22 16:57:37 --> Loader Class Initialized
INFO - 2020-09-22 16:57:37 --> Helper loaded: url_helper
INFO - 2020-09-22 16:57:37 --> Database Driver Class Initialized
INFO - 2020-09-22 16:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 16:57:37 --> Email Class Initialized
INFO - 2020-09-22 16:57:37 --> Controller Class Initialized
DEBUG - 2020-09-22 16:57:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 16:57:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 16:57:37 --> Model Class Initialized
INFO - 2020-09-22 16:57:37 --> Model Class Initialized
INFO - 2020-09-22 16:57:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-22 16:57:37 --> Final output sent to browser
DEBUG - 2020-09-22 16:57:37 --> Total execution time: 0.0266
ERROR - 2020-09-22 17:21:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 17:21:29 --> Config Class Initialized
INFO - 2020-09-22 17:21:29 --> Hooks Class Initialized
DEBUG - 2020-09-22 17:21:29 --> UTF-8 Support Enabled
INFO - 2020-09-22 17:21:29 --> Utf8 Class Initialized
INFO - 2020-09-22 17:21:29 --> URI Class Initialized
DEBUG - 2020-09-22 17:21:29 --> No URI present. Default controller set.
INFO - 2020-09-22 17:21:29 --> Router Class Initialized
INFO - 2020-09-22 17:21:29 --> Output Class Initialized
INFO - 2020-09-22 17:21:29 --> Security Class Initialized
DEBUG - 2020-09-22 17:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 17:21:29 --> Input Class Initialized
INFO - 2020-09-22 17:21:29 --> Language Class Initialized
INFO - 2020-09-22 17:21:29 --> Loader Class Initialized
INFO - 2020-09-22 17:21:29 --> Helper loaded: url_helper
INFO - 2020-09-22 17:21:29 --> Database Driver Class Initialized
INFO - 2020-09-22 17:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 17:21:29 --> Email Class Initialized
INFO - 2020-09-22 17:21:29 --> Controller Class Initialized
INFO - 2020-09-22 17:21:29 --> Model Class Initialized
INFO - 2020-09-22 17:21:29 --> Model Class Initialized
DEBUG - 2020-09-22 17:21:29 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 17:21:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 17:21:29 --> Final output sent to browser
DEBUG - 2020-09-22 17:21:29 --> Total execution time: 0.0233
ERROR - 2020-09-22 17:22:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 17:22:00 --> Config Class Initialized
INFO - 2020-09-22 17:22:00 --> Hooks Class Initialized
DEBUG - 2020-09-22 17:22:00 --> UTF-8 Support Enabled
INFO - 2020-09-22 17:22:00 --> Utf8 Class Initialized
INFO - 2020-09-22 17:22:00 --> URI Class Initialized
INFO - 2020-09-22 17:22:00 --> Router Class Initialized
INFO - 2020-09-22 17:22:00 --> Output Class Initialized
INFO - 2020-09-22 17:22:00 --> Security Class Initialized
DEBUG - 2020-09-22 17:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 17:22:00 --> Input Class Initialized
INFO - 2020-09-22 17:22:00 --> Language Class Initialized
INFO - 2020-09-22 17:22:00 --> Loader Class Initialized
INFO - 2020-09-22 17:22:00 --> Helper loaded: url_helper
INFO - 2020-09-22 17:22:00 --> Database Driver Class Initialized
INFO - 2020-09-22 17:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 17:22:00 --> Email Class Initialized
INFO - 2020-09-22 17:22:00 --> Controller Class Initialized
INFO - 2020-09-22 17:22:00 --> Model Class Initialized
INFO - 2020-09-22 17:22:00 --> Model Class Initialized
DEBUG - 2020-09-22 17:22:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 17:22:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 17:22:00 --> Model Class Initialized
INFO - 2020-09-22 17:22:00 --> Final output sent to browser
DEBUG - 2020-09-22 17:22:00 --> Total execution time: 0.0230
ERROR - 2020-09-22 17:22:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 17:22:01 --> Config Class Initialized
INFO - 2020-09-22 17:22:01 --> Hooks Class Initialized
DEBUG - 2020-09-22 17:22:01 --> UTF-8 Support Enabled
INFO - 2020-09-22 17:22:01 --> Utf8 Class Initialized
INFO - 2020-09-22 17:22:01 --> URI Class Initialized
INFO - 2020-09-22 17:22:01 --> Router Class Initialized
INFO - 2020-09-22 17:22:01 --> Output Class Initialized
INFO - 2020-09-22 17:22:01 --> Security Class Initialized
DEBUG - 2020-09-22 17:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 17:22:01 --> Input Class Initialized
INFO - 2020-09-22 17:22:01 --> Language Class Initialized
INFO - 2020-09-22 17:22:01 --> Loader Class Initialized
INFO - 2020-09-22 17:22:01 --> Helper loaded: url_helper
INFO - 2020-09-22 17:22:01 --> Database Driver Class Initialized
INFO - 2020-09-22 17:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 17:22:01 --> Email Class Initialized
INFO - 2020-09-22 17:22:01 --> Controller Class Initialized
INFO - 2020-09-22 17:22:01 --> Model Class Initialized
INFO - 2020-09-22 17:22:01 --> Model Class Initialized
DEBUG - 2020-09-22 17:22:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-22 17:22:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 17:22:01 --> Config Class Initialized
INFO - 2020-09-22 17:22:01 --> Hooks Class Initialized
DEBUG - 2020-09-22 17:22:01 --> UTF-8 Support Enabled
INFO - 2020-09-22 17:22:01 --> Utf8 Class Initialized
INFO - 2020-09-22 17:22:01 --> URI Class Initialized
INFO - 2020-09-22 17:22:01 --> Router Class Initialized
INFO - 2020-09-22 17:22:01 --> Output Class Initialized
INFO - 2020-09-22 17:22:01 --> Security Class Initialized
DEBUG - 2020-09-22 17:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 17:22:01 --> Input Class Initialized
INFO - 2020-09-22 17:22:01 --> Language Class Initialized
INFO - 2020-09-22 17:22:01 --> Loader Class Initialized
INFO - 2020-09-22 17:22:01 --> Helper loaded: url_helper
INFO - 2020-09-22 17:22:01 --> Database Driver Class Initialized
INFO - 2020-09-22 17:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 17:22:01 --> Email Class Initialized
INFO - 2020-09-22 17:22:01 --> Controller Class Initialized
DEBUG - 2020-09-22 17:22:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-22 17:22:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-22 17:22:01 --> Model Class Initialized
INFO - 2020-09-22 17:22:01 --> Model Class Initialized
INFO - 2020-09-22 17:22:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-22 17:22:01 --> Final output sent to browser
DEBUG - 2020-09-22 17:22:01 --> Total execution time: 0.0253
ERROR - 2020-09-22 17:22:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-22 17:22:08 --> Config Class Initialized
INFO - 2020-09-22 17:22:08 --> Hooks Class Initialized
DEBUG - 2020-09-22 17:22:08 --> UTF-8 Support Enabled
INFO - 2020-09-22 17:22:08 --> Utf8 Class Initialized
INFO - 2020-09-22 17:22:08 --> URI Class Initialized
DEBUG - 2020-09-22 17:22:08 --> No URI present. Default controller set.
INFO - 2020-09-22 17:22:08 --> Router Class Initialized
INFO - 2020-09-22 17:22:08 --> Output Class Initialized
INFO - 2020-09-22 17:22:08 --> Security Class Initialized
DEBUG - 2020-09-22 17:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-22 17:22:08 --> Input Class Initialized
INFO - 2020-09-22 17:22:08 --> Language Class Initialized
INFO - 2020-09-22 17:22:08 --> Loader Class Initialized
INFO - 2020-09-22 17:22:08 --> Helper loaded: url_helper
INFO - 2020-09-22 17:22:08 --> Database Driver Class Initialized
INFO - 2020-09-22 17:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-22 17:22:08 --> Email Class Initialized
INFO - 2020-09-22 17:22:08 --> Controller Class Initialized
INFO - 2020-09-22 17:22:08 --> Model Class Initialized
INFO - 2020-09-22 17:22:08 --> Model Class Initialized
DEBUG - 2020-09-22 17:22:08 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-22 17:22:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-22 17:22:08 --> Final output sent to browser
DEBUG - 2020-09-22 17:22:08 --> Total execution time: 0.0260
