<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-16 15:41:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-16 15:41:36 --> Config Class Initialized
INFO - 2020-12-16 15:41:36 --> Hooks Class Initialized
DEBUG - 2020-12-16 15:41:36 --> UTF-8 Support Enabled
INFO - 2020-12-16 15:41:36 --> Utf8 Class Initialized
INFO - 2020-12-16 15:41:36 --> URI Class Initialized
DEBUG - 2020-12-16 15:41:36 --> No URI present. Default controller set.
INFO - 2020-12-16 15:41:36 --> Router Class Initialized
INFO - 2020-12-16 15:41:36 --> Output Class Initialized
INFO - 2020-12-16 15:41:36 --> Security Class Initialized
DEBUG - 2020-12-16 15:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-16 15:41:36 --> Input Class Initialized
INFO - 2020-12-16 15:41:36 --> Language Class Initialized
INFO - 2020-12-16 15:41:36 --> Loader Class Initialized
INFO - 2020-12-16 15:41:36 --> Helper loaded: url_helper
INFO - 2020-12-16 15:41:36 --> Database Driver Class Initialized
INFO - 2020-12-16 15:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-16 15:41:36 --> Email Class Initialized
INFO - 2020-12-16 15:41:36 --> Controller Class Initialized
INFO - 2020-12-16 15:41:36 --> Model Class Initialized
INFO - 2020-12-16 15:41:36 --> Model Class Initialized
DEBUG - 2020-12-16 15:41:36 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-16 15:41:36 --> File loaded: /home/portaldev2020/public_html/application/views/welcome_message.php
INFO - 2020-12-16 15:41:36 --> Final output sent to browser
DEBUG - 2020-12-16 15:41:36 --> Total execution time: 0.1814
ERROR - 2020-12-16 16:21:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-16 16:21:00 --> Config Class Initialized
INFO - 2020-12-16 16:21:00 --> Hooks Class Initialized
DEBUG - 2020-12-16 16:21:00 --> UTF-8 Support Enabled
INFO - 2020-12-16 16:21:00 --> Utf8 Class Initialized
INFO - 2020-12-16 16:21:00 --> URI Class Initialized
DEBUG - 2020-12-16 16:21:00 --> No URI present. Default controller set.
INFO - 2020-12-16 16:21:00 --> Router Class Initialized
INFO - 2020-12-16 16:21:00 --> Output Class Initialized
INFO - 2020-12-16 16:21:00 --> Security Class Initialized
DEBUG - 2020-12-16 16:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-16 16:21:00 --> Input Class Initialized
INFO - 2020-12-16 16:21:00 --> Language Class Initialized
INFO - 2020-12-16 16:21:00 --> Loader Class Initialized
INFO - 2020-12-16 16:21:00 --> Helper loaded: url_helper
INFO - 2020-12-16 16:21:00 --> Database Driver Class Initialized
INFO - 2020-12-16 16:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-16 16:21:00 --> Email Class Initialized
INFO - 2020-12-16 16:21:00 --> Controller Class Initialized
INFO - 2020-12-16 16:21:00 --> Model Class Initialized
INFO - 2020-12-16 16:21:00 --> Model Class Initialized
DEBUG - 2020-12-16 16:21:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-16 16:21:00 --> File loaded: /home/portaldev2020/public_html/application/views/welcome_message.php
INFO - 2020-12-16 16:21:00 --> Final output sent to browser
DEBUG - 2020-12-16 16:21:00 --> Total execution time: 0.0513
