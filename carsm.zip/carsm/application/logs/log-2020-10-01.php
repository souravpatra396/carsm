<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-01 05:47:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-01 05:47:20 --> Config Class Initialized
INFO - 2020-10-01 05:47:20 --> Hooks Class Initialized
DEBUG - 2020-10-01 05:47:20 --> UTF-8 Support Enabled
INFO - 2020-10-01 05:47:20 --> Utf8 Class Initialized
INFO - 2020-10-01 05:47:20 --> URI Class Initialized
DEBUG - 2020-10-01 05:47:20 --> No URI present. Default controller set.
INFO - 2020-10-01 05:47:20 --> Router Class Initialized
INFO - 2020-10-01 05:47:20 --> Output Class Initialized
INFO - 2020-10-01 05:47:20 --> Security Class Initialized
DEBUG - 2020-10-01 05:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-01 05:47:20 --> Input Class Initialized
INFO - 2020-10-01 05:47:20 --> Language Class Initialized
INFO - 2020-10-01 05:47:20 --> Loader Class Initialized
INFO - 2020-10-01 05:47:20 --> Helper loaded: url_helper
INFO - 2020-10-01 05:47:20 --> Database Driver Class Initialized
INFO - 2020-10-01 05:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-01 05:47:20 --> Email Class Initialized
INFO - 2020-10-01 05:47:20 --> Controller Class Initialized
INFO - 2020-10-01 05:47:20 --> Model Class Initialized
INFO - 2020-10-01 05:47:20 --> Model Class Initialized
DEBUG - 2020-10-01 05:47:20 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-01 05:47:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-01 05:47:20 --> Final output sent to browser
DEBUG - 2020-10-01 05:47:20 --> Total execution time: 0.0231
ERROR - 2020-10-01 05:55:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-01 05:55:38 --> Config Class Initialized
INFO - 2020-10-01 05:55:38 --> Hooks Class Initialized
DEBUG - 2020-10-01 05:55:38 --> UTF-8 Support Enabled
INFO - 2020-10-01 05:55:38 --> Utf8 Class Initialized
INFO - 2020-10-01 05:55:38 --> URI Class Initialized
DEBUG - 2020-10-01 05:55:38 --> No URI present. Default controller set.
INFO - 2020-10-01 05:55:38 --> Router Class Initialized
INFO - 2020-10-01 05:55:38 --> Output Class Initialized
INFO - 2020-10-01 05:55:38 --> Security Class Initialized
DEBUG - 2020-10-01 05:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-01 05:55:38 --> Input Class Initialized
INFO - 2020-10-01 05:55:38 --> Language Class Initialized
INFO - 2020-10-01 05:55:38 --> Loader Class Initialized
INFO - 2020-10-01 05:55:38 --> Helper loaded: url_helper
INFO - 2020-10-01 05:55:38 --> Database Driver Class Initialized
INFO - 2020-10-01 05:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-01 05:55:38 --> Email Class Initialized
INFO - 2020-10-01 05:55:38 --> Controller Class Initialized
INFO - 2020-10-01 05:55:38 --> Model Class Initialized
INFO - 2020-10-01 05:55:38 --> Model Class Initialized
DEBUG - 2020-10-01 05:55:38 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-01 05:55:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-01 05:55:38 --> Final output sent to browser
DEBUG - 2020-10-01 05:55:38 --> Total execution time: 0.0205
ERROR - 2020-10-01 06:26:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-01 06:26:52 --> Config Class Initialized
INFO - 2020-10-01 06:26:52 --> Hooks Class Initialized
DEBUG - 2020-10-01 06:26:52 --> UTF-8 Support Enabled
INFO - 2020-10-01 06:26:52 --> Utf8 Class Initialized
INFO - 2020-10-01 06:26:52 --> URI Class Initialized
DEBUG - 2020-10-01 06:26:52 --> No URI present. Default controller set.
INFO - 2020-10-01 06:26:52 --> Router Class Initialized
INFO - 2020-10-01 06:26:52 --> Output Class Initialized
INFO - 2020-10-01 06:26:52 --> Security Class Initialized
DEBUG - 2020-10-01 06:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-01 06:26:52 --> Input Class Initialized
INFO - 2020-10-01 06:26:52 --> Language Class Initialized
INFO - 2020-10-01 06:26:52 --> Loader Class Initialized
INFO - 2020-10-01 06:26:52 --> Helper loaded: url_helper
INFO - 2020-10-01 06:26:52 --> Database Driver Class Initialized
INFO - 2020-10-01 06:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-01 06:26:52 --> Email Class Initialized
INFO - 2020-10-01 06:26:52 --> Controller Class Initialized
INFO - 2020-10-01 06:26:52 --> Model Class Initialized
INFO - 2020-10-01 06:26:52 --> Model Class Initialized
DEBUG - 2020-10-01 06:26:52 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-01 06:26:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-01 06:26:52 --> Final output sent to browser
DEBUG - 2020-10-01 06:26:52 --> Total execution time: 0.1707
ERROR - 2020-10-01 07:47:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-01 07:47:59 --> Config Class Initialized
INFO - 2020-10-01 07:47:59 --> Hooks Class Initialized
DEBUG - 2020-10-01 07:47:59 --> UTF-8 Support Enabled
INFO - 2020-10-01 07:47:59 --> Utf8 Class Initialized
INFO - 2020-10-01 07:47:59 --> URI Class Initialized
DEBUG - 2020-10-01 07:47:59 --> No URI present. Default controller set.
INFO - 2020-10-01 07:47:59 --> Router Class Initialized
INFO - 2020-10-01 07:47:59 --> Output Class Initialized
INFO - 2020-10-01 07:47:59 --> Security Class Initialized
DEBUG - 2020-10-01 07:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-01 07:47:59 --> Input Class Initialized
INFO - 2020-10-01 07:47:59 --> Language Class Initialized
INFO - 2020-10-01 07:47:59 --> Loader Class Initialized
INFO - 2020-10-01 07:47:59 --> Helper loaded: url_helper
INFO - 2020-10-01 07:47:59 --> Database Driver Class Initialized
INFO - 2020-10-01 07:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-01 07:47:59 --> Email Class Initialized
INFO - 2020-10-01 07:47:59 --> Controller Class Initialized
INFO - 2020-10-01 07:47:59 --> Model Class Initialized
INFO - 2020-10-01 07:47:59 --> Model Class Initialized
DEBUG - 2020-10-01 07:47:59 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-01 07:47:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-01 07:47:59 --> Final output sent to browser
DEBUG - 2020-10-01 07:47:59 --> Total execution time: 0.0205
ERROR - 2020-10-01 07:48:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-01 07:48:29 --> Config Class Initialized
INFO - 2020-10-01 07:48:29 --> Hooks Class Initialized
DEBUG - 2020-10-01 07:48:29 --> UTF-8 Support Enabled
INFO - 2020-10-01 07:48:29 --> Utf8 Class Initialized
INFO - 2020-10-01 07:48:29 --> URI Class Initialized
DEBUG - 2020-10-01 07:48:29 --> No URI present. Default controller set.
INFO - 2020-10-01 07:48:29 --> Router Class Initialized
INFO - 2020-10-01 07:48:29 --> Output Class Initialized
INFO - 2020-10-01 07:48:29 --> Security Class Initialized
DEBUG - 2020-10-01 07:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-01 07:48:29 --> Input Class Initialized
INFO - 2020-10-01 07:48:29 --> Language Class Initialized
INFO - 2020-10-01 07:48:29 --> Loader Class Initialized
INFO - 2020-10-01 07:48:29 --> Helper loaded: url_helper
INFO - 2020-10-01 07:48:29 --> Database Driver Class Initialized
INFO - 2020-10-01 07:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-01 07:48:29 --> Email Class Initialized
INFO - 2020-10-01 07:48:29 --> Controller Class Initialized
INFO - 2020-10-01 07:48:29 --> Model Class Initialized
INFO - 2020-10-01 07:48:29 --> Model Class Initialized
DEBUG - 2020-10-01 07:48:29 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-01 07:48:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-01 07:48:29 --> Final output sent to browser
DEBUG - 2020-10-01 07:48:29 --> Total execution time: 0.0187
ERROR - 2020-10-01 14:12:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-01 14:12:49 --> Config Class Initialized
INFO - 2020-10-01 14:12:49 --> Hooks Class Initialized
DEBUG - 2020-10-01 14:12:49 --> UTF-8 Support Enabled
INFO - 2020-10-01 14:12:49 --> Utf8 Class Initialized
INFO - 2020-10-01 14:12:49 --> URI Class Initialized
DEBUG - 2020-10-01 14:12:49 --> No URI present. Default controller set.
INFO - 2020-10-01 14:12:49 --> Router Class Initialized
INFO - 2020-10-01 14:12:49 --> Output Class Initialized
INFO - 2020-10-01 14:12:49 --> Security Class Initialized
DEBUG - 2020-10-01 14:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-01 14:12:49 --> Input Class Initialized
INFO - 2020-10-01 14:12:49 --> Language Class Initialized
INFO - 2020-10-01 14:12:49 --> Loader Class Initialized
INFO - 2020-10-01 14:12:49 --> Helper loaded: url_helper
INFO - 2020-10-01 14:12:49 --> Database Driver Class Initialized
INFO - 2020-10-01 14:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-01 14:12:49 --> Email Class Initialized
INFO - 2020-10-01 14:12:49 --> Controller Class Initialized
INFO - 2020-10-01 14:12:49 --> Model Class Initialized
INFO - 2020-10-01 14:12:49 --> Model Class Initialized
DEBUG - 2020-10-01 14:12:49 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-01 14:12:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-01 14:12:49 --> Final output sent to browser
DEBUG - 2020-10-01 14:12:49 --> Total execution time: 0.0221
ERROR - 2020-10-01 14:49:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-01 14:49:49 --> Config Class Initialized
INFO - 2020-10-01 14:49:49 --> Hooks Class Initialized
DEBUG - 2020-10-01 14:49:49 --> UTF-8 Support Enabled
INFO - 2020-10-01 14:49:49 --> Utf8 Class Initialized
INFO - 2020-10-01 14:49:49 --> URI Class Initialized
INFO - 2020-10-01 14:49:49 --> Router Class Initialized
INFO - 2020-10-01 14:49:49 --> Output Class Initialized
INFO - 2020-10-01 14:49:49 --> Security Class Initialized
DEBUG - 2020-10-01 14:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-01 14:49:49 --> Input Class Initialized
INFO - 2020-10-01 14:49:49 --> Language Class Initialized
INFO - 2020-10-01 14:49:49 --> Loader Class Initialized
INFO - 2020-10-01 14:49:49 --> Helper loaded: url_helper
INFO - 2020-10-01 14:49:49 --> Database Driver Class Initialized
INFO - 2020-10-01 14:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-01 14:49:49 --> Email Class Initialized
INFO - 2020-10-01 14:49:49 --> Controller Class Initialized
DEBUG - 2020-10-01 14:49:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-01 14:49:49 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-10-01 14:49:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-01 14:49:51 --> Config Class Initialized
INFO - 2020-10-01 14:49:51 --> Hooks Class Initialized
DEBUG - 2020-10-01 14:49:51 --> UTF-8 Support Enabled
INFO - 2020-10-01 14:49:51 --> Utf8 Class Initialized
INFO - 2020-10-01 14:49:51 --> URI Class Initialized
DEBUG - 2020-10-01 14:49:51 --> No URI present. Default controller set.
INFO - 2020-10-01 14:49:51 --> Router Class Initialized
INFO - 2020-10-01 14:49:51 --> Output Class Initialized
INFO - 2020-10-01 14:49:51 --> Security Class Initialized
DEBUG - 2020-10-01 14:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-01 14:49:51 --> Input Class Initialized
INFO - 2020-10-01 14:49:51 --> Language Class Initialized
INFO - 2020-10-01 14:49:51 --> Loader Class Initialized
INFO - 2020-10-01 14:49:51 --> Helper loaded: url_helper
INFO - 2020-10-01 14:49:51 --> Database Driver Class Initialized
INFO - 2020-10-01 14:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-01 14:49:51 --> Email Class Initialized
INFO - 2020-10-01 14:49:51 --> Controller Class Initialized
INFO - 2020-10-01 14:49:51 --> Model Class Initialized
INFO - 2020-10-01 14:49:51 --> Model Class Initialized
DEBUG - 2020-10-01 14:49:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-01 14:49:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-01 14:49:51 --> Final output sent to browser
DEBUG - 2020-10-01 14:49:51 --> Total execution time: 0.0208
ERROR - 2020-10-01 14:49:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-01 14:49:52 --> Config Class Initialized
INFO - 2020-10-01 14:49:52 --> Hooks Class Initialized
DEBUG - 2020-10-01 14:49:52 --> UTF-8 Support Enabled
INFO - 2020-10-01 14:49:52 --> Utf8 Class Initialized
INFO - 2020-10-01 14:49:52 --> URI Class Initialized
DEBUG - 2020-10-01 14:49:52 --> No URI present. Default controller set.
INFO - 2020-10-01 14:49:52 --> Router Class Initialized
INFO - 2020-10-01 14:49:52 --> Output Class Initialized
ERROR - 2020-10-01 14:49:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-01 14:49:52 --> Security Class Initialized
INFO - 2020-10-01 14:49:52 --> Config Class Initialized
INFO - 2020-10-01 14:49:52 --> Hooks Class Initialized
DEBUG - 2020-10-01 14:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-01 14:49:52 --> Input Class Initialized
INFO - 2020-10-01 14:49:52 --> Language Class Initialized
DEBUG - 2020-10-01 14:49:52 --> UTF-8 Support Enabled
INFO - 2020-10-01 14:49:52 --> Utf8 Class Initialized
INFO - 2020-10-01 14:49:52 --> URI Class Initialized
INFO - 2020-10-01 14:49:52 --> Loader Class Initialized
INFO - 2020-10-01 14:49:52 --> Router Class Initialized
INFO - 2020-10-01 14:49:52 --> Helper loaded: url_helper
INFO - 2020-10-01 14:49:52 --> Output Class Initialized
INFO - 2020-10-01 14:49:52 --> Security Class Initialized
DEBUG - 2020-10-01 14:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-01 14:49:52 --> Input Class Initialized
INFO - 2020-10-01 14:49:52 --> Language Class Initialized
INFO - 2020-10-01 14:49:52 --> Database Driver Class Initialized
INFO - 2020-10-01 14:49:52 --> Loader Class Initialized
INFO - 2020-10-01 14:49:52 --> Helper loaded: url_helper
INFO - 2020-10-01 14:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-01 14:49:52 --> Email Class Initialized
INFO - 2020-10-01 14:49:52 --> Controller Class Initialized
INFO - 2020-10-01 14:49:52 --> Model Class Initialized
INFO - 2020-10-01 14:49:52 --> Database Driver Class Initialized
INFO - 2020-10-01 14:49:52 --> Model Class Initialized
DEBUG - 2020-10-01 14:49:52 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-01 14:49:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-01 14:49:52 --> Final output sent to browser
DEBUG - 2020-10-01 14:49:52 --> Total execution time: 0.0210
INFO - 2020-10-01 14:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-01 14:49:52 --> Email Class Initialized
INFO - 2020-10-01 14:49:52 --> Controller Class Initialized
DEBUG - 2020-10-01 14:49:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-01 14:49:52 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-10-01 14:49:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-01 14:49:53 --> Config Class Initialized
INFO - 2020-10-01 14:49:53 --> Hooks Class Initialized
DEBUG - 2020-10-01 14:49:53 --> UTF-8 Support Enabled
INFO - 2020-10-01 14:49:53 --> Utf8 Class Initialized
INFO - 2020-10-01 14:49:53 --> URI Class Initialized
DEBUG - 2020-10-01 14:49:53 --> No URI present. Default controller set.
INFO - 2020-10-01 14:49:53 --> Router Class Initialized
INFO - 2020-10-01 14:49:53 --> Output Class Initialized
INFO - 2020-10-01 14:49:53 --> Security Class Initialized
DEBUG - 2020-10-01 14:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-01 14:49:53 --> Input Class Initialized
INFO - 2020-10-01 14:49:53 --> Language Class Initialized
INFO - 2020-10-01 14:49:53 --> Loader Class Initialized
INFO - 2020-10-01 14:49:53 --> Helper loaded: url_helper
INFO - 2020-10-01 14:49:53 --> Database Driver Class Initialized
INFO - 2020-10-01 14:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-01 14:49:53 --> Email Class Initialized
INFO - 2020-10-01 14:49:53 --> Controller Class Initialized
INFO - 2020-10-01 14:49:53 --> Model Class Initialized
INFO - 2020-10-01 14:49:53 --> Model Class Initialized
DEBUG - 2020-10-01 14:49:53 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-01 14:49:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-01 14:49:53 --> Final output sent to browser
DEBUG - 2020-10-01 14:49:53 --> Total execution time: 0.0189
ERROR - 2020-10-01 14:50:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-01 14:50:01 --> Config Class Initialized
INFO - 2020-10-01 14:50:01 --> Hooks Class Initialized
DEBUG - 2020-10-01 14:50:01 --> UTF-8 Support Enabled
INFO - 2020-10-01 14:50:01 --> Utf8 Class Initialized
INFO - 2020-10-01 14:50:01 --> URI Class Initialized
INFO - 2020-10-01 14:50:01 --> Router Class Initialized
INFO - 2020-10-01 14:50:01 --> Output Class Initialized
INFO - 2020-10-01 14:50:01 --> Security Class Initialized
DEBUG - 2020-10-01 14:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-01 14:50:01 --> Input Class Initialized
INFO - 2020-10-01 14:50:01 --> Language Class Initialized
INFO - 2020-10-01 14:50:01 --> Loader Class Initialized
INFO - 2020-10-01 14:50:01 --> Helper loaded: url_helper
INFO - 2020-10-01 14:50:01 --> Database Driver Class Initialized
INFO - 2020-10-01 14:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-01 14:50:01 --> Email Class Initialized
INFO - 2020-10-01 14:50:01 --> Controller Class Initialized
INFO - 2020-10-01 14:50:01 --> Model Class Initialized
INFO - 2020-10-01 14:50:01 --> Model Class Initialized
DEBUG - 2020-10-01 14:50:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-01 14:50:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-01 14:50:02 --> Config Class Initialized
INFO - 2020-10-01 14:50:02 --> Hooks Class Initialized
DEBUG - 2020-10-01 14:50:02 --> UTF-8 Support Enabled
INFO - 2020-10-01 14:50:02 --> Utf8 Class Initialized
INFO - 2020-10-01 14:50:02 --> URI Class Initialized
INFO - 2020-10-01 14:50:02 --> Router Class Initialized
INFO - 2020-10-01 14:50:02 --> Output Class Initialized
INFO - 2020-10-01 14:50:02 --> Security Class Initialized
DEBUG - 2020-10-01 14:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-01 14:50:02 --> Input Class Initialized
INFO - 2020-10-01 14:50:02 --> Language Class Initialized
INFO - 2020-10-01 14:50:02 --> Loader Class Initialized
INFO - 2020-10-01 14:50:02 --> Helper loaded: url_helper
INFO - 2020-10-01 14:50:02 --> Database Driver Class Initialized
INFO - 2020-10-01 14:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-01 14:50:02 --> Email Class Initialized
INFO - 2020-10-01 14:50:02 --> Controller Class Initialized
DEBUG - 2020-10-01 14:50:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-01 14:50:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-01 14:50:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-01 14:50:02 --> Final output sent to browser
DEBUG - 2020-10-01 14:50:02 --> Total execution time: 0.0893
ERROR - 2020-10-01 14:50:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-01 14:50:03 --> Config Class Initialized
INFO - 2020-10-01 14:50:03 --> Hooks Class Initialized
DEBUG - 2020-10-01 14:50:03 --> UTF-8 Support Enabled
INFO - 2020-10-01 14:50:03 --> Utf8 Class Initialized
INFO - 2020-10-01 14:50:03 --> URI Class Initialized
INFO - 2020-10-01 14:50:03 --> Router Class Initialized
INFO - 2020-10-01 14:50:03 --> Output Class Initialized
INFO - 2020-10-01 14:50:03 --> Security Class Initialized
DEBUG - 2020-10-01 14:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-01 14:50:03 --> Input Class Initialized
INFO - 2020-10-01 14:50:03 --> Language Class Initialized
INFO - 2020-10-01 14:50:03 --> Loader Class Initialized
INFO - 2020-10-01 14:50:03 --> Helper loaded: url_helper
INFO - 2020-10-01 14:50:03 --> Database Driver Class Initialized
INFO - 2020-10-01 14:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-01 14:50:03 --> Email Class Initialized
INFO - 2020-10-01 14:50:03 --> Controller Class Initialized
INFO - 2020-10-01 14:50:03 --> Model Class Initialized
INFO - 2020-10-01 14:50:03 --> Model Class Initialized
DEBUG - 2020-10-01 14:50:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-01 14:50:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-01 14:50:04 --> Config Class Initialized
INFO - 2020-10-01 14:50:04 --> Hooks Class Initialized
DEBUG - 2020-10-01 14:50:04 --> UTF-8 Support Enabled
INFO - 2020-10-01 14:50:04 --> Utf8 Class Initialized
INFO - 2020-10-01 14:50:04 --> URI Class Initialized
DEBUG - 2020-10-01 14:50:04 --> No URI present. Default controller set.
INFO - 2020-10-01 14:50:04 --> Router Class Initialized
INFO - 2020-10-01 14:50:04 --> Output Class Initialized
INFO - 2020-10-01 14:50:04 --> Security Class Initialized
DEBUG - 2020-10-01 14:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-01 14:50:04 --> Input Class Initialized
INFO - 2020-10-01 14:50:04 --> Language Class Initialized
INFO - 2020-10-01 14:50:04 --> Loader Class Initialized
INFO - 2020-10-01 14:50:04 --> Helper loaded: url_helper
INFO - 2020-10-01 14:50:04 --> Database Driver Class Initialized
INFO - 2020-10-01 14:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-01 14:50:04 --> Email Class Initialized
INFO - 2020-10-01 14:50:04 --> Controller Class Initialized
INFO - 2020-10-01 14:50:04 --> Model Class Initialized
INFO - 2020-10-01 14:50:04 --> Model Class Initialized
DEBUG - 2020-10-01 14:50:04 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-01 14:50:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-01 14:50:04 --> Final output sent to browser
DEBUG - 2020-10-01 14:50:04 --> Total execution time: 0.0192
ERROR - 2020-10-01 14:50:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-01 14:50:04 --> Config Class Initialized
INFO - 2020-10-01 14:50:04 --> Hooks Class Initialized
DEBUG - 2020-10-01 14:50:04 --> UTF-8 Support Enabled
INFO - 2020-10-01 14:50:04 --> Utf8 Class Initialized
INFO - 2020-10-01 14:50:04 --> URI Class Initialized
INFO - 2020-10-01 14:50:04 --> Router Class Initialized
INFO - 2020-10-01 14:50:04 --> Output Class Initialized
INFO - 2020-10-01 14:50:04 --> Security Class Initialized
DEBUG - 2020-10-01 14:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-01 14:50:04 --> Input Class Initialized
INFO - 2020-10-01 14:50:04 --> Language Class Initialized
INFO - 2020-10-01 14:50:04 --> Loader Class Initialized
INFO - 2020-10-01 14:50:04 --> Helper loaded: url_helper
INFO - 2020-10-01 14:50:04 --> Database Driver Class Initialized
INFO - 2020-10-01 14:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-01 14:50:04 --> Email Class Initialized
INFO - 2020-10-01 14:50:04 --> Controller Class Initialized
DEBUG - 2020-10-01 14:50:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-01 14:50:04 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-10-01 14:50:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-01 14:50:05 --> Config Class Initialized
INFO - 2020-10-01 14:50:05 --> Hooks Class Initialized
DEBUG - 2020-10-01 14:50:05 --> UTF-8 Support Enabled
INFO - 2020-10-01 14:50:05 --> Utf8 Class Initialized
INFO - 2020-10-01 14:50:05 --> URI Class Initialized
DEBUG - 2020-10-01 14:50:05 --> No URI present. Default controller set.
INFO - 2020-10-01 14:50:05 --> Router Class Initialized
INFO - 2020-10-01 14:50:05 --> Output Class Initialized
INFO - 2020-10-01 14:50:05 --> Security Class Initialized
DEBUG - 2020-10-01 14:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-01 14:50:05 --> Input Class Initialized
INFO - 2020-10-01 14:50:05 --> Language Class Initialized
INFO - 2020-10-01 14:50:05 --> Loader Class Initialized
INFO - 2020-10-01 14:50:05 --> Helper loaded: url_helper
INFO - 2020-10-01 14:50:05 --> Database Driver Class Initialized
INFO - 2020-10-01 14:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-01 14:50:05 --> Email Class Initialized
INFO - 2020-10-01 14:50:05 --> Controller Class Initialized
INFO - 2020-10-01 14:50:05 --> Model Class Initialized
INFO - 2020-10-01 14:50:05 --> Model Class Initialized
DEBUG - 2020-10-01 14:50:05 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-01 14:50:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-01 14:50:05 --> Final output sent to browser
DEBUG - 2020-10-01 14:50:05 --> Total execution time: 0.1169
ERROR - 2020-10-01 14:50:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-01 14:50:47 --> Config Class Initialized
INFO - 2020-10-01 14:50:47 --> Hooks Class Initialized
DEBUG - 2020-10-01 14:50:47 --> UTF-8 Support Enabled
INFO - 2020-10-01 14:50:47 --> Utf8 Class Initialized
INFO - 2020-10-01 14:50:47 --> URI Class Initialized
INFO - 2020-10-01 14:50:47 --> Router Class Initialized
INFO - 2020-10-01 14:50:47 --> Output Class Initialized
INFO - 2020-10-01 14:50:47 --> Security Class Initialized
DEBUG - 2020-10-01 14:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-01 14:50:47 --> Input Class Initialized
INFO - 2020-10-01 14:50:47 --> Language Class Initialized
INFO - 2020-10-01 14:50:47 --> Loader Class Initialized
INFO - 2020-10-01 14:50:47 --> Helper loaded: url_helper
INFO - 2020-10-01 14:50:47 --> Database Driver Class Initialized
INFO - 2020-10-01 14:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-01 14:50:47 --> Email Class Initialized
INFO - 2020-10-01 14:50:47 --> Controller Class Initialized
DEBUG - 2020-10-01 14:50:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-01 14:50:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-01 14:50:47 --> Model Class Initialized
INFO - 2020-10-01 14:50:47 --> Model Class Initialized
INFO - 2020-10-01 14:50:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-01 14:50:47 --> Final output sent to browser
DEBUG - 2020-10-01 14:50:47 --> Total execution time: 0.0689
ERROR - 2020-10-01 14:50:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-01 14:50:48 --> Config Class Initialized
INFO - 2020-10-01 14:50:48 --> Hooks Class Initialized
DEBUG - 2020-10-01 14:50:48 --> UTF-8 Support Enabled
INFO - 2020-10-01 14:50:48 --> Utf8 Class Initialized
INFO - 2020-10-01 14:50:48 --> URI Class Initialized
INFO - 2020-10-01 14:50:48 --> Router Class Initialized
INFO - 2020-10-01 14:50:48 --> Output Class Initialized
INFO - 2020-10-01 14:50:48 --> Security Class Initialized
DEBUG - 2020-10-01 14:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-01 14:50:48 --> Input Class Initialized
INFO - 2020-10-01 14:50:48 --> Language Class Initialized
INFO - 2020-10-01 14:50:48 --> Loader Class Initialized
INFO - 2020-10-01 14:50:48 --> Helper loaded: url_helper
INFO - 2020-10-01 14:50:48 --> Database Driver Class Initialized
INFO - 2020-10-01 14:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-01 14:50:48 --> Email Class Initialized
INFO - 2020-10-01 14:50:48 --> Controller Class Initialized
DEBUG - 2020-10-01 14:50:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-01 14:50:48 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-10-01 14:50:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-01 14:50:49 --> Config Class Initialized
INFO - 2020-10-01 14:50:49 --> Hooks Class Initialized
DEBUG - 2020-10-01 14:50:49 --> UTF-8 Support Enabled
INFO - 2020-10-01 14:50:49 --> Utf8 Class Initialized
INFO - 2020-10-01 14:50:49 --> URI Class Initialized
DEBUG - 2020-10-01 14:50:49 --> No URI present. Default controller set.
INFO - 2020-10-01 14:50:49 --> Router Class Initialized
INFO - 2020-10-01 14:50:49 --> Output Class Initialized
INFO - 2020-10-01 14:50:49 --> Security Class Initialized
DEBUG - 2020-10-01 14:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-01 14:50:49 --> Input Class Initialized
INFO - 2020-10-01 14:50:49 --> Language Class Initialized
INFO - 2020-10-01 14:50:49 --> Loader Class Initialized
INFO - 2020-10-01 14:50:49 --> Helper loaded: url_helper
INFO - 2020-10-01 14:50:49 --> Database Driver Class Initialized
INFO - 2020-10-01 14:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-01 14:50:49 --> Email Class Initialized
INFO - 2020-10-01 14:50:49 --> Controller Class Initialized
INFO - 2020-10-01 14:50:49 --> Model Class Initialized
INFO - 2020-10-01 14:50:49 --> Model Class Initialized
DEBUG - 2020-10-01 14:50:49 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-01 14:50:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-01 14:50:49 --> Final output sent to browser
DEBUG - 2020-10-01 14:50:49 --> Total execution time: 0.0183
ERROR - 2020-10-01 14:50:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-01 14:50:53 --> Config Class Initialized
INFO - 2020-10-01 14:50:53 --> Hooks Class Initialized
DEBUG - 2020-10-01 14:50:53 --> UTF-8 Support Enabled
INFO - 2020-10-01 14:50:53 --> Utf8 Class Initialized
INFO - 2020-10-01 14:50:53 --> URI Class Initialized
INFO - 2020-10-01 14:50:53 --> Router Class Initialized
INFO - 2020-10-01 14:50:53 --> Output Class Initialized
INFO - 2020-10-01 14:50:53 --> Security Class Initialized
DEBUG - 2020-10-01 14:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-01 14:50:53 --> Input Class Initialized
INFO - 2020-10-01 14:50:53 --> Language Class Initialized
INFO - 2020-10-01 14:50:53 --> Loader Class Initialized
INFO - 2020-10-01 14:50:53 --> Helper loaded: url_helper
INFO - 2020-10-01 14:50:53 --> Database Driver Class Initialized
INFO - 2020-10-01 14:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-01 14:50:53 --> Email Class Initialized
INFO - 2020-10-01 14:50:53 --> Controller Class Initialized
DEBUG - 2020-10-01 14:50:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-01 14:50:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-01 14:50:53 --> Model Class Initialized
INFO - 2020-10-01 14:50:53 --> Model Class Initialized
INFO - 2020-10-01 14:50:53 --> Model Class Initialized
INFO - 2020-10-01 14:50:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-10-01 14:50:53 --> Final output sent to browser
DEBUG - 2020-10-01 14:50:53 --> Total execution time: 0.0556
ERROR - 2020-10-01 14:50:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-01 14:50:55 --> Config Class Initialized
INFO - 2020-10-01 14:50:55 --> Hooks Class Initialized
DEBUG - 2020-10-01 14:50:55 --> UTF-8 Support Enabled
INFO - 2020-10-01 14:50:55 --> Utf8 Class Initialized
INFO - 2020-10-01 14:50:55 --> URI Class Initialized
INFO - 2020-10-01 14:50:55 --> Router Class Initialized
INFO - 2020-10-01 14:50:55 --> Output Class Initialized
INFO - 2020-10-01 14:50:55 --> Security Class Initialized
DEBUG - 2020-10-01 14:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-01 14:50:55 --> Input Class Initialized
INFO - 2020-10-01 14:50:55 --> Language Class Initialized
INFO - 2020-10-01 14:50:55 --> Loader Class Initialized
INFO - 2020-10-01 14:50:55 --> Helper loaded: url_helper
INFO - 2020-10-01 14:50:55 --> Database Driver Class Initialized
INFO - 2020-10-01 14:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-01 14:50:55 --> Email Class Initialized
INFO - 2020-10-01 14:50:55 --> Controller Class Initialized
DEBUG - 2020-10-01 14:50:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-01 14:50:55 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-10-01 14:50:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-01 14:50:56 --> Config Class Initialized
INFO - 2020-10-01 14:50:56 --> Hooks Class Initialized
DEBUG - 2020-10-01 14:50:56 --> UTF-8 Support Enabled
INFO - 2020-10-01 14:50:56 --> Utf8 Class Initialized
INFO - 2020-10-01 14:50:56 --> URI Class Initialized
DEBUG - 2020-10-01 14:50:56 --> No URI present. Default controller set.
INFO - 2020-10-01 14:50:56 --> Router Class Initialized
INFO - 2020-10-01 14:50:56 --> Output Class Initialized
INFO - 2020-10-01 14:50:56 --> Security Class Initialized
DEBUG - 2020-10-01 14:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-01 14:50:56 --> Input Class Initialized
INFO - 2020-10-01 14:50:56 --> Language Class Initialized
INFO - 2020-10-01 14:50:56 --> Loader Class Initialized
INFO - 2020-10-01 14:50:56 --> Helper loaded: url_helper
INFO - 2020-10-01 14:50:56 --> Database Driver Class Initialized
INFO - 2020-10-01 14:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-01 14:50:56 --> Email Class Initialized
INFO - 2020-10-01 14:50:56 --> Controller Class Initialized
INFO - 2020-10-01 14:50:56 --> Model Class Initialized
INFO - 2020-10-01 14:50:56 --> Model Class Initialized
DEBUG - 2020-10-01 14:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-01 14:50:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-01 14:50:56 --> Final output sent to browser
DEBUG - 2020-10-01 14:50:56 --> Total execution time: 0.0317
ERROR - 2020-10-01 15:45:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-01 15:45:52 --> Config Class Initialized
INFO - 2020-10-01 15:45:52 --> Hooks Class Initialized
DEBUG - 2020-10-01 15:45:52 --> UTF-8 Support Enabled
INFO - 2020-10-01 15:45:52 --> Utf8 Class Initialized
INFO - 2020-10-01 15:45:52 --> URI Class Initialized
INFO - 2020-10-01 15:45:52 --> Router Class Initialized
INFO - 2020-10-01 15:45:52 --> Output Class Initialized
INFO - 2020-10-01 15:45:52 --> Security Class Initialized
DEBUG - 2020-10-01 15:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-01 15:45:52 --> Input Class Initialized
INFO - 2020-10-01 15:45:52 --> Language Class Initialized
INFO - 2020-10-01 15:45:52 --> Loader Class Initialized
INFO - 2020-10-01 15:45:52 --> Helper loaded: url_helper
INFO - 2020-10-01 15:45:52 --> Database Driver Class Initialized
INFO - 2020-10-01 15:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-01 15:45:52 --> Email Class Initialized
INFO - 2020-10-01 15:45:52 --> Controller Class Initialized
DEBUG - 2020-10-01 15:45:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-01 15:45:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-01 15:45:52 --> Model Class Initialized
INFO - 2020-10-01 15:45:52 --> Model Class Initialized
INFO - 2020-10-01 15:45:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-01 15:45:52 --> Final output sent to browser
DEBUG - 2020-10-01 15:45:52 --> Total execution time: 0.0207
ERROR - 2020-10-01 15:45:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-01 15:45:53 --> Config Class Initialized
INFO - 2020-10-01 15:45:53 --> Hooks Class Initialized
DEBUG - 2020-10-01 15:45:53 --> UTF-8 Support Enabled
INFO - 2020-10-01 15:45:53 --> Utf8 Class Initialized
INFO - 2020-10-01 15:45:53 --> URI Class Initialized
INFO - 2020-10-01 15:45:53 --> Router Class Initialized
INFO - 2020-10-01 15:45:53 --> Output Class Initialized
INFO - 2020-10-01 15:45:53 --> Security Class Initialized
DEBUG - 2020-10-01 15:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-01 15:45:53 --> Input Class Initialized
INFO - 2020-10-01 15:45:53 --> Language Class Initialized
INFO - 2020-10-01 15:45:53 --> Loader Class Initialized
INFO - 2020-10-01 15:45:53 --> Helper loaded: url_helper
INFO - 2020-10-01 15:45:53 --> Database Driver Class Initialized
INFO - 2020-10-01 15:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-01 15:45:53 --> Email Class Initialized
INFO - 2020-10-01 15:45:53 --> Controller Class Initialized
DEBUG - 2020-10-01 15:45:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-01 15:45:53 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-10-01 15:45:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-01 15:45:54 --> Config Class Initialized
INFO - 2020-10-01 15:45:54 --> Hooks Class Initialized
DEBUG - 2020-10-01 15:45:54 --> UTF-8 Support Enabled
INFO - 2020-10-01 15:45:54 --> Utf8 Class Initialized
INFO - 2020-10-01 15:45:54 --> URI Class Initialized
DEBUG - 2020-10-01 15:45:54 --> No URI present. Default controller set.
INFO - 2020-10-01 15:45:54 --> Router Class Initialized
INFO - 2020-10-01 15:45:54 --> Output Class Initialized
INFO - 2020-10-01 15:45:54 --> Security Class Initialized
DEBUG - 2020-10-01 15:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-01 15:45:54 --> Input Class Initialized
INFO - 2020-10-01 15:45:54 --> Language Class Initialized
INFO - 2020-10-01 15:45:54 --> Loader Class Initialized
INFO - 2020-10-01 15:45:54 --> Helper loaded: url_helper
INFO - 2020-10-01 15:45:54 --> Database Driver Class Initialized
INFO - 2020-10-01 15:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-01 15:45:54 --> Email Class Initialized
INFO - 2020-10-01 15:45:54 --> Controller Class Initialized
INFO - 2020-10-01 15:45:54 --> Model Class Initialized
INFO - 2020-10-01 15:45:54 --> Model Class Initialized
DEBUG - 2020-10-01 15:45:54 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-01 15:45:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-01 15:45:54 --> Final output sent to browser
DEBUG - 2020-10-01 15:45:54 --> Total execution time: 0.0278
ERROR - 2020-10-01 15:45:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-01 15:45:58 --> Config Class Initialized
INFO - 2020-10-01 15:45:58 --> Hooks Class Initialized
DEBUG - 2020-10-01 15:45:58 --> UTF-8 Support Enabled
INFO - 2020-10-01 15:45:58 --> Utf8 Class Initialized
INFO - 2020-10-01 15:45:58 --> URI Class Initialized
INFO - 2020-10-01 15:45:58 --> Router Class Initialized
INFO - 2020-10-01 15:45:58 --> Output Class Initialized
INFO - 2020-10-01 15:45:58 --> Security Class Initialized
DEBUG - 2020-10-01 15:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-01 15:45:58 --> Input Class Initialized
INFO - 2020-10-01 15:45:58 --> Language Class Initialized
INFO - 2020-10-01 15:45:58 --> Loader Class Initialized
INFO - 2020-10-01 15:45:58 --> Helper loaded: url_helper
INFO - 2020-10-01 15:45:58 --> Database Driver Class Initialized
INFO - 2020-10-01 15:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-01 15:45:58 --> Email Class Initialized
INFO - 2020-10-01 15:45:58 --> Controller Class Initialized
DEBUG - 2020-10-01 15:45:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-01 15:45:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-01 15:45:58 --> Model Class Initialized
INFO - 2020-10-01 15:45:58 --> Model Class Initialized
INFO - 2020-10-01 15:45:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_view.php
INFO - 2020-10-01 15:45:58 --> Final output sent to browser
DEBUG - 2020-10-01 15:45:58 --> Total execution time: 0.0371
ERROR - 2020-10-01 15:45:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-01 15:45:59 --> Config Class Initialized
INFO - 2020-10-01 15:45:59 --> Hooks Class Initialized
DEBUG - 2020-10-01 15:45:59 --> UTF-8 Support Enabled
INFO - 2020-10-01 15:45:59 --> Utf8 Class Initialized
INFO - 2020-10-01 15:45:59 --> URI Class Initialized
INFO - 2020-10-01 15:45:59 --> Router Class Initialized
INFO - 2020-10-01 15:45:59 --> Output Class Initialized
INFO - 2020-10-01 15:45:59 --> Security Class Initialized
DEBUG - 2020-10-01 15:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-01 15:45:59 --> Input Class Initialized
INFO - 2020-10-01 15:45:59 --> Language Class Initialized
INFO - 2020-10-01 15:45:59 --> Loader Class Initialized
INFO - 2020-10-01 15:45:59 --> Helper loaded: url_helper
INFO - 2020-10-01 15:45:59 --> Database Driver Class Initialized
INFO - 2020-10-01 15:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-01 15:45:59 --> Email Class Initialized
INFO - 2020-10-01 15:45:59 --> Controller Class Initialized
DEBUG - 2020-10-01 15:45:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-01 15:45:59 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-10-01 15:46:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-01 15:46:00 --> Config Class Initialized
INFO - 2020-10-01 15:46:00 --> Hooks Class Initialized
DEBUG - 2020-10-01 15:46:00 --> UTF-8 Support Enabled
INFO - 2020-10-01 15:46:00 --> Utf8 Class Initialized
INFO - 2020-10-01 15:46:00 --> URI Class Initialized
DEBUG - 2020-10-01 15:46:00 --> No URI present. Default controller set.
INFO - 2020-10-01 15:46:00 --> Router Class Initialized
INFO - 2020-10-01 15:46:00 --> Output Class Initialized
INFO - 2020-10-01 15:46:00 --> Security Class Initialized
DEBUG - 2020-10-01 15:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-01 15:46:00 --> Input Class Initialized
INFO - 2020-10-01 15:46:00 --> Language Class Initialized
INFO - 2020-10-01 15:46:00 --> Loader Class Initialized
INFO - 2020-10-01 15:46:00 --> Helper loaded: url_helper
INFO - 2020-10-01 15:46:00 --> Database Driver Class Initialized
INFO - 2020-10-01 15:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-01 15:46:00 --> Email Class Initialized
INFO - 2020-10-01 15:46:00 --> Controller Class Initialized
INFO - 2020-10-01 15:46:00 --> Model Class Initialized
INFO - 2020-10-01 15:46:00 --> Model Class Initialized
DEBUG - 2020-10-01 15:46:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-01 15:46:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-01 15:46:00 --> Final output sent to browser
DEBUG - 2020-10-01 15:46:00 --> Total execution time: 0.0266
