<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dealer extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
       
        $this->load->library('session');
        $this->load->helper('url');
        $this->load->library('email');
        
        if($this->session->userdata('email_id') == TRUE)
		{
			
			$data['email_id'] = $this->session->userdata('email_id');
			$this->access=$data['email_id'];
			$data['role_name'] = $this->session->userdata('role_name');
		}
		else
        {
             redirect($base_url);
        }
        
    }


	
	public function dealer_module()
	{
	    $data['email_id'] = $this->session->userdata('email_id');
        $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');
        $data['role_name'] = $this->session->userdata('role_name');
        $this->load->model('Dealer_model');
        $data['total_records']=$this->Dealer_model->total_client_list($data);
        $data['total_records2']=$this->Dealer_model->total_records_in_system($data);
        $this->load->view('dash2',$data);
	    
	   
	}
	
	public function client_master()
	{
        $data['email_id'] = $this->session->userdata('email_id');
        $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');
        $data['role_name'] = $this->session->userdata('role_name');
        $this->load->model('Dealer_model');
        $data['client_master_list']=$this->Dealer_model->client_list($data);
        $this->load->view('client_master_list',$data);
	}
	
	public function dealer_add()
	{
	    $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
        $this->load->model('Admin_model');
		$this->load->view('dealer_add',$data);
		
	}
	
	
	public function dealer_reg()
	{  
	   	if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{       
			
        		$data['role_id'] = $this->session->userdata('role_id');
        		$data['user_id'] = $this->session->userdata('user_id');
        		$data['role_name'] = $this->session->userdata('role_name');
        		 $data['email_id'] = $this->session->userdata('email_id');
        		$this->session->set_userdata('form_ts',$this->input->post('TS'));
        		$arrc =  $_POST['basic'];
        		$this->load->model('Admin_model');
        		$data['alert_flag'] = 0;
        		$data['alert_message'] = "";
        		$data['arrlength'] = $arrc;
        		$data['d_name']=$_POST['d_name'];
        		$data['d_ph_no']=$_POST['d_ph_no'];
        		$data['d_address1']=$_POST['d_address1'];
        		$data['d_address2']=$_POST['d_address2'];
        		$data['d_province']=$_POST['d_province'];
        		$data['d_city']=$_POST['d_city'];
        		$data['d_p_code']=$_POST['d_p_code'];
        		$data['d_website']=$_POST['d_website'];
        		$data['d_p_web_domain']=$_POST['d_p_web_domain'];
        		$data['d_p_email']=$_POST['d_p_email'];
        		$data['d_s_r_nm']=$_POST['d_s_r_nm'];
        		
                if($_POST['d_name'] !="")
                {
                $data['d_name']=$_POST['d_name'];
                $data['first_name']=$_POST['d_name'];
                
                }
                else
                {
                $data['d_name'] ='NA';
                }
        		
                if($_POST['d_ph_no'] !="")
                {
                $data['d_ph_no']=$_POST['d_ph_no'];
                $data['phone']=$_POST['d_ph_no'];
                }
                else
                {
                $data['d_ph_no'] ='NA';
                }
                
                if($_POST['d_p_email'] !="")
                {
                $data['d_p_email']=$_POST['d_p_email'];
                $data['email'] = $data['d_p_email'];
                }
                else
                {
                $data['d_p_email'] ='';
                }
                
                if($_POST['d_address1'] !="")
                {
                $data['d_address1']=$_POST['d_address1'];
                $data['address'] = $data['d_address1'];
                }
                else
                {
                $data['d_address1'] ='';
                }
                
                
               // echo"ss" .$data['role_id1'] ;
                
                $data['alert_flag'] = 0;
        	    $data['alert_message'] = "";
        	    
        	    $this->load->model('Admin_model');
                $data['alert_flag'] = 0;
                
            if($data['d_name']!="" && $data['d_p_email']!='')
            {
                
                $data['password'] = substr(md5(rand().rand()), 0, 8);
        		
        	    $data['d_list']=$this->Admin_model->dealer_reg($data);
        		
        		
        		if($data['d_list'])
        		{
        			foreach($data['d_list'] as $dealer_id_c)
        			{
						
        				$dealer_id_new = $dealer_id_c['dealer_id'];
        				$password = $dealer_id_c['password'];
						
						//echo $agent_id_new."/".$password;
        			  }
        			
        			$this->load->model('User');
					$data['dealer_id_new'] = $dealer_id_new;
					 $data['role_id1']=1;
        			$data['user_details'] = $this->User->user_registration($data);
        			if($data['user_details'])
        			{
        				foreach($data['user_details'] as $u_details)
        				{
        					$token = $u_details['token'];
        					$password = $u_details['password'];
        				}
        			}
        		    $data['dealer_id_new'] = $dealer_id_new;
        			$data['alert_flag'] = 1;
        		    $data['alert_message'] = " New Dealer Id  ".$data['dealer_id_new']." has been generated Successfully.";
        		}
        		
        		if($dealer_id_new >0)
        		{
        				$to = $data['email'];
				$subject = "Welcome to CARSM portal";
				
				$txt = "Welcome to the world of CARSM PORTAL!. Your request for accessing application is pending with Admin. You will be notified once approval is done. Your User New Password is ".$password."";
				$txt = $txt." Please go through the url purpuligo.com/carsm/index.php/User_reg/w344fd462/".$token;
				$headers = "From: webmaster@carsm.com";
	
				mail($to,$subject,$txt,$headers);
					
					
        
        			//mail($to,$subject,$txt,$headers);
        		}
        		
        		
            }
            else
        	{
        		$data['alert_flag'] = 0; 
        		$data['alert_message']="";
        	}
        		$data['d_name'] = "";
        	    $data['d_p_email'] = "";
        		
        		$this->load->model('Admin_model');
        		$data['dealer_master_list']=$this->Admin_model->dealer_list();
        		$this->load->view('dealer_master_list',$data);
		}
		else
			{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$data['role_name'] = $this->session->userdata('role_name');
        		 $data['email_id'] = $this->session->userdata('email_id');
				$this->load->model('Admin_model');
				$data['dealer_master_list']=$this->Admin_model->dealer_list();
        		$this->load->view('dealer_master_list',$data);
			}
		
	}
	
	public function client_view()
	{
        $data['email_id'] = $this->session->userdata('email_id');
        $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');
        $data['role_name'] = $this->session->userdata('role_name');
        $data['d_id'] = $_POST['d_id'];
        $this->load->model('Dealer_model');
        $data['client_master_view']=$this->Dealer_model->client_master_list_view($data);
        $this->load->view('client_view',$data);
	}
		
	public function client_edit()
	{
        $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
        $data['d_id2'] = $_POST['d_id2'];
        $this->load->model('Dealer_model');
        $data['client_master_edit']=$this->Dealer_model->client_master_edit($data);
        $this->load->view('client_edit',$data);
	}
	
	public function client_update()
	{  
	    if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{  
			
        		$data['role_id'] = $this->session->userdata('role_id');
        		$data['user_id'] = $this->session->userdata('user_id');	
        		$data['role_name'] = $this->session->userdata('role_name');
        		$data['email_id'] = $this->session->userdata('email_id');
        		$this->session->set_userdata('form_ts',$this->input->post('TS'));
        		$arrc =  $_POST['basic'];
        		$this->load->model('Dealer_model');
        		$data['alert_flag'] = 0;
        		$data['alert_message'] = "";
        		$data['arrlength'] = $arrc;
        		$data['cl_f_name']=$_POST['cl_f_name'];
        		$data['cl_l_name']=$_POST['cl_l_name'];
        		$data['cl_address1']=$_POST['cl_address1'];
        		$data['cl_address2']=$_POST['cl_address2'];
        		$data['cl_province']=$_POST['cl_province'];
        		$data['cl_city']=$_POST['cl_city'];
        		$data['cl_p_code']=$_POST['cl_p_code'];
        		$data['cl_h_ph_no']=$_POST['cl_h_ph_no'];
        		$data['cl_b_ph_no']=$_POST['cl_b_ph_no'];
        		$data['cl_c_ph_no']=$_POST['cl_c_ph_no'];
        		$data['cl_email']=$_POST['cl_email'];
        		$data['d_n_cont_f']=$_POST['d_n_cont_f'];
        		$data['d_n_email_f']=$_POST['d_n_email_f'];
        		$data['cl_v_make']=$_POST['cl_v_make'];
        		$data['cl_v_m_year']=$_POST['cl_v_m_year'];
        		$data['cl_v_m']=$_POST['cl_v_m'];
        		$data['cl_v_colour']=$_POST['cl_v_colour'];
        		$data['cl_v_mileage']=$_POST['cl_v_mileage'];
        		$data['cl_v_vin']=$_POST['cl_v_vin'];
        		$data['cl_v_del_date']=$_POST['cl_v_del_date'];
        		$data['cl_v_l_ser_date']=$_POST['cl_v_l_ser_date'];
        		$data['cl_lati']=$_POST['cl_lati'];
        		$data['cl_longi']=$_POST['cl_longi'];
        		$data['cl_dis_to_d']=$_POST['cl_dis_to_d'];
        		$data['cl_p_purl_code']=$_POST['cl_p_purl_code'];
        		$data['cl_e_purl_code']=$_POST['cl_e_purl_code'];
        		$data['cl_a_sale_rep']=$_POST['cl_a_sale_rep'];
        		$data['cl_l_c_d_w_s_rep']=$_POST['cl_l_c_d_w_s_rep'];
        		$data['cl_l_c_d_v_postal_c']=$_POST['cl_l_c_d_v_postal_c'];
        		$data['cl_l_c_d_v_email_c']=$_POST['cl_l_c_d_v_email_c'];
        		$data['cl_purl_v_no_of_tm']=$_POST['cl_purl_v_no_of_tm'];
        		$data['cl_purl_v_d_list']=$_POST['cl_purl_v_d_list'];
        		$data['cl_purl_v_app_set']=$_POST['cl_purl_v_app_set'];
        		$data['cl_p_new_vehicle']=$_POST['cl_p_new_vehicle'];
        		$data['cl_id']=$_POST['cl_id'];
        		$this->Dealer_model->client_update($data);
        		$data['alert_flag'] = 1;
        		$data['alert_message'] = " New Client Id ".$data['cl_id']." has been Updates Successfully.";
        		 $data['client_master_list']=$this->Dealer_model->client_list($data);
        		$this->load->view('client_master_list',$data);
		}
		else
			{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$data['role_name'] = $this->session->userdata('role_name');
				$data['email_id'] = $this->session->userdata('email_id');
				$this->load->model('Dealer_model');
				$data['client_master_list']=$this->Dealer_model->client_list($data);
        		$this->load->view('client_master_list',$data);
			}
		
	}
	
	public function user_view()
	{
	    $data['email_id'] = $this->session->userdata('email_id');
        $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');
        $data['role_name'] = $this->session->userdata('role_name');
        $this->load->model('Dealer_model');
	    $data['user_master_view']=$this->Dealer_model->user_master_view($data);
        $this->load->view('user_view',$data);
	    
	   
	}
	
	public function user_edit()
	{
	    $data['email_id'] = $this->session->userdata('email_id');
        $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');
        $data['role_name'] = $this->session->userdata('role_name');
        $this->load->model('Dealer_model');
	    $data['user_master_view']=$this->Dealer_model->user_master_view($data);
        $this->load->view('user_edit',$data);
	    
	   
	}
	
	
	public function user_update()
	{  
	    if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{  
			
        		$data['role_id'] = $this->session->userdata('role_id');
        		$data['user_id'] = $this->session->userdata('user_id');	
        		$data['role_name'] = $this->session->userdata('role_name');
        		$data['email_id'] = $this->session->userdata('email_id');
        		$this->session->set_userdata('form_ts',$this->input->post('TS'));
        		$arrc =  $_POST['basic'];
        		$this->load->model('Dealer_model');
        		$data['alert_flag'] = 0;
        		$data['alert_message'] = "";
        		$data['arrlength'] = $arrc;
        		$data['u_email']=$this->session->userdata('email_id');
        		$data['u_name']=$_POST['u_name'];
        		$data['u_ph_no']=$_POST['u_ph_no'];
        		$data['u_address']=$_POST['u_address'];

        		$data['u_id']=$_POST['u_id'];
        		$this->Dealer_model->user_update($data);
        		$data['alert_flag'] = 1;
        		$data['alert_message'] = " New User Id ".$data['u_id']." has been Updates Successfully.";
        		$data['user_master_view']=$this->Dealer_model->user_master_view($data);
                $this->load->view('user_view',$data);
		}
		else
			{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$data['role_name'] = $this->session->userdata('role_name');
				$data['email_id'] = $this->session->userdata('email_id');
				$this->load->model('Dealer_model');
				$data['user_master_view']=$this->Dealer_model->user_master_view($data);
                $this->load->view('user_view',$data);
			}
		
	}
	
	public function Client_add()
	{
	    $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
        $this->load->model('Dealer_model');
         $this->load->model('Admin_model');
        $data['province_list']=$this->Admin_model->province_master_list();
        $data['dealer_list']=$this->Admin_model->dealer_list();
		$this->load->view('client_add',$data);
		
	}
	
	public function client_reg()
	{  
	    if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{  
			
        		$data['role_id'] = $this->session->userdata('role_id');
        		$data['user_id'] = $this->session->userdata('user_id');	
        		$data['role_name'] = $this->session->userdata('role_name');
        		$data['email_id'] = $this->session->userdata('email_id');
        		$this->session->set_userdata('form_ts',$this->input->post('TS'));
        		$arrc =  $_POST['basic'];
        		$this->load->model('Dealer_model');
        		$data['alert_flag'] = 0;
        		$data['alert_message'] = "";
        		$data['arrlength'] = $arrc;
        		$data['cl_f_name']=$_POST['cl_f_name'];
        		$data['cl_l_name']=$_POST['cl_l_name'];
        		$data['cl_address1']=$_POST['cl_address1'];
        		$data['cl_address2']=$_POST['cl_address2'];
        		$data['cl_province']=$_POST['cl_province'];
        		$data['cl_city']=$_POST['cl_city'];
        		$data['cl_p_code']=$_POST['cl_p_code'];
        		$data['cl_h_ph_no']=$_POST['cl_h_ph_no'];
        		$data['cl_b_ph_no']=$_POST['cl_b_ph_no'];
        		$data['cl_c_ph_no']=$_POST['cl_c_ph_no'];
        		$data['cl_email']=$_POST['cl_email'];
        		$data['d_n_cont_f']=$_POST['d_n_cont_f'];
        		$data['d_n_email_f']=$_POST['d_n_email_f'];
        		$data['cl_v_make']=$_POST['cl_v_make'];
        		$data['cl_v_m_year']=$_POST['cl_v_m_year'];
        		$data['cl_v_m']=$_POST['cl_v_m'];
        		$data['cl_v_colour']=$_POST['cl_v_colour'];
        		$data['cl_v_mileage']=$_POST['cl_v_mileage'];
        		$data['cl_v_vin']=$_POST['cl_v_vin'];
        		$data['cl_v_del_date']=$_POST['cl_v_del_date'];
        		$data['cl_v_l_ser_date']=$_POST['cl_v_l_ser_date'];
        		$data['cl_lati']=$_POST['cl_lati'];
        		$data['cl_longi']=$_POST['cl_longi'];
        		$data['cl_dis_to_d']=$_POST['cl_dis_to_d'];
        		$data['cl_p_purl_code']=$_POST['cl_p_purl_code'];
        		$data['cl_e_purl_code']=$_POST['cl_e_purl_code'];
        		$data['cl_a_sale_rep']=$_POST['cl_a_sale_rep'];
        		$data['cl_l_c_d_w_s_rep']=$_POST['cl_l_c_d_w_s_rep'];
        		$data['cl_l_c_d_v_postal_c']=$_POST['cl_l_c_d_v_postal_c'];
        		$data['cl_l_c_d_v_email_c']=$_POST['cl_l_c_d_v_email_c'];
        		$data['cl_purl_v_no_of_tm']=$_POST['cl_purl_v_no_of_tm'];
        		$data['cl_purl_v_d_list']=$_POST['cl_purl_v_d_list'];
        		$data['cl_purl_v_app_set']=$_POST['cl_purl_v_app_set'];
        		$data['cl_p_new_vehicle']=$_POST['cl_p_new_vehicle'];
        		$data['cl_id']=$_POST['d_name'];
        		$this->Dealer_model->client_reg($data);
        		$data['alert_flag'] = 1;
        		$data['alert_message'] = " New Client Id  has been generated Successfully.";
        		 $this->load->model('Admin_model');
                $data['client_list_admin_wise']=$this->Admin_model->client_list_for_admin();
                $this->load->view('client_master_list_admin_wise',$data);
		}
		else
			{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$data['role_name'] = $this->session->userdata('role_name');
				$data['email_id'] = $this->session->userdata('email_id');
				$this->load->model('Admin_model');
                $data['client_list_admin_wise']=$this->Admin_model->client_list_for_admin();
                $this->load->view('client_master_list_admin_wise',$data);
			}
		
	}
	
	public function client_delete()
	{
	     if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{ 
		    	$this->session->set_userdata('form_ts',$this->input->post('TS'));
                $data['role_id'] = $this->session->userdata('role_id');
                $data['user_id'] = $this->session->userdata('user_id');	
                $data['role_name'] = $this->session->userdata('role_name');
                $data['email_id'] = $this->session->userdata('email_id');
                $data['cl_id2'] = $_POST['cl_id2'];
                $data['alert_flag'] = 0;
                $data['alert_message'] = "";
                $this->load->model('Dealer_model');
                $this->Dealer_model->client_data_delete($data);
                $data['alert_flag'] = 1;
                $data['alert_message'] = " Client Id ".$data['cl_id2']." has been deleted";
                $this->load->model('Admin_model');
                $data['client_list_admin_wise']=$this->Admin_model->client_list_for_admin();
                $this->load->view('client_master_list_admin_wise',$data);
		}
		else
			{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$data['role_name'] = $this->session->userdata('role_name');
				$data['email_id'] = $this->session->userdata('email_id');
				$this->load->model('Admin_model');
                $data['client_list_admin_wise']=$this->Admin_model->client_list_for_admin();
                $this->load->view('client_master_list_admin_wise',$data);
			}
	}
	
	public function client_data_delete()
	{
	     if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{ 
		    	$this->session->set_userdata('form_ts',$this->input->post('TS'));
                $data['role_id'] = $this->session->userdata('role_id');
                $data['user_id'] = $this->session->userdata('user_id');	
                $data['role_name'] = $this->session->userdata('role_name');
                $data['email_id'] = $this->session->userdata('email_id');
                $data['cl_id2'] = $_POST['cl_id2'];
                $data['alert_flag'] = 0;
                $data['alert_message'] = "";
                $this->load->model('Dealer_model');
                $this->Dealer_model->client_data_delete($data);
                $data['alert_flag'] = 1;
                $data['alert_message'] = " Client Id ".$data['cl_id2']." has been deleted";
                $this->load->model('Dealer_model');
                $data['client_master_list']=$this->Dealer_model->client_list($data);
                $this->load->view('client_master_list',$data);
		}
		else
			{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$data['role_name'] = $this->session->userdata('role_name');
				$data['email_id'] = $this->session->userdata('email_id');
				$this->load->model('Dealer_model');
                $data['client_master_list']=$this->Dealer_model->client_list($data);
                $this->load->view('client_master_list',$data);
			}
	}
	
	
	
}
