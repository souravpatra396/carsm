<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
       
        $this->load->library('session');
        $this->load->helper('url');
        $this->load->library('email');
        
        if($this->session->userdata('email_id') == TRUE)
		{
			
			$data['email_id'] = $this->session->userdata('email_id');
			$this->access=$data['email_id'];
			$data['role_name'] = $this->session->userdata('role_name');
		}
		else
        {
             redirect($base_url);
        }
        
    }


	
	public function admin_module()
	{
	    $data['email_id'] = $this->session->userdata('email_id');
        $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');
        $data['role_name'] = $this->session->userdata('role_name');
        $this->load->model('Admin_model');
        $data['dealer_list']=$this->Admin_model->dealer_list();
         $data['total_records']=$this->Admin_model->total_records();
        $data['total_records2']=$this->Admin_model->total_client_records();
        $data['total_records3']=$this->Admin_model->admin_dashboard_data_view();
        $this->load->view('dash',$data);
	    
	   
	}
	
	public function dealer_master()
	{
        $data['email_id'] = $this->session->userdata('email_id');
        $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');
        $data['role_name'] = $this->session->userdata('role_name');
        $this->load->model('Admin_model');
        $data['dealer_master_list']=$this->Admin_model->dealer_list();
        $this->load->view('dealer_master_list',$data);
	}
	
	public function dealer_add()
	{
	    $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
        $this->load->model('Admin_model');
         $data['province_master_list']=$this->Admin_model->province_master_list();
		$this->load->view('dealer_add',$data);
		
	}
	
	
	public function dealer_reg()
	{  
	   	if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{       
			
        		$data['role_id'] = $this->session->userdata('role_id');
        		$data['user_id'] = $this->session->userdata('user_id');
        		$data['role_name'] = $this->session->userdata('role_name');
        		 $data['email_id'] = $this->session->userdata('email_id');
        		$this->session->set_userdata('form_ts',$this->input->post('TS'));
        		$arrc =  $_POST['basic'];
        		$this->load->model('Admin_model');
        		$data['alert_flag'] = 0;
        		$data['alert_message'] = "";
        		$data['arrlength'] = $arrc;
        		$data['d_name']=$_POST['d_name'];
        		$data['d_ph_no']=$_POST['d_ph_no'];
        		$data['d_address1']=$_POST['d_address1'];
        		$data['d_address2']=$_POST['d_address2'];
        		$data['d_province']=$_POST['d_province'];
        		$data['d_city']=$_POST['d_city'];
        		$data['d_p_code']=$_POST['d_p_code'];
        		$data['d_website']=$_POST['d_website'];
        		$data['d_p_web_domain']=$_POST['d_p_web_domain'];
        		$data['d_p_email']=$_POST['d_p_email'];
        		$data['d_s_r_nm']=$_POST['d_s_r_nm'];
        		
                if($_POST['d_name'] !="")
                {
                $data['d_name']=$_POST['d_name'];
                $data['first_name']=$_POST['d_name'];
                
                }
                else
                {
                $data['d_name'] ='NA';
                }
        		
                if($_POST['d_ph_no'] !="")
                {
                $data['d_ph_no']=$_POST['d_ph_no'];
                $data['phone']=$_POST['d_ph_no'];
                }
                else
                {
                $data['d_ph_no'] ='NA';
                }
                
                if($_POST['d_p_email'] !="")
                {
                $data['d_p_email']=$_POST['d_p_email'];
                $data['email'] = $data['d_p_email'];
                }
                else
                {
                $data['d_p_email'] ='';
                }
                
                if($_POST['d_address1'] !="")
                {
                $data['d_address1']=$_POST['d_address1'];
                $data['address'] = $data['d_address1'];
                }
                else
                {
                $data['d_address1'] ='';
                }
                $data['role_id1']=1;
                $data['alert_flag'] = 0;
        	    $data['alert_message'] = "";
        	    
        	    $this->load->model('Admin_model');
                $data['alert_flag'] = 0;
                
            if($data['d_name']!="" && $data['d_p_email']!='')
            {
                
                $data['password'] = substr(md5(rand().rand()), 0, 8);
        		
        	    $data['d_list']=$this->Admin_model->dealer_reg($data);
        		
        		
        		if($data['d_list'])
        		{
        			foreach($data['d_list'] as $dealer_id_c)
        			{
						
        				$dealer_id_new = $dealer_id_c['dealer_id'];
        				$password = $dealer_id_c['password'];
						
						//echo $agent_id_new."/".$password;
        			  }
        			
        			$this->load->model('User');
					$data['dealer_id_new'] = $dealer_id_new;
        			$data['user_details'] = $this->User->user_registration($data);
        			if($data['user_details'])
        			{
        				foreach($data['user_details'] as $u_details)
        				{
        					$token = $u_details['token'];
        					$password = $u_details['password'];
        				}
        			}
        		    $data['dealer_id_new'] = $dealer_id_new;
        			$data['alert_flag'] = 1;
        		    $data['alert_message'] = " New Dealer Id  ".$data['dealer_id_new']." has been generated Successfully.";
        		}
        		
        		if($dealer_id_new >0)
        		{
        				$to = $data['email'];
				$subject = "Welcome to CARSM portal";
				
				$txt = "Welcome to the world of CARSM PORTAL!. Your request for accessing application is pending with Admin. You will be notified once approval is done. Your User New Password is ".$password."";
				$txt = $txt." Please go through the url purpuligo.com/carsm/index.php/User_reg/w344fd462/".$token;
				$headers = "From: webmaster@carsm.com";
	
				mail($to,$subject,$txt,$headers);
					
					
        
        			//mail($to,$subject,$txt,$headers);
        		}
        		
        		
            }
            else
        	{
        		$data['alert_flag'] = 0; 
        		$data['alert_message']="";
        	}
        		$data['d_name'] = "";
        	    $data['d_p_email'] = "";
        		
        		$this->load->model('Admin_model');
        		$data['dealer_master_list']=$this->Admin_model->dealer_list();
        		$this->load->view('dealer_master_list',$data);
		}
		else
			{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$data['role_name'] = $this->session->userdata('role_name');
        		 $data['email_id'] = $this->session->userdata('email_id');
				$this->load->model('Admin_model');
				$data['dealer_master_list']=$this->Admin_model->dealer_list();
        		$this->load->view('dealer_master_list',$data);
			}
		
	}
	
	public function dealer_view()
	{
        $data['email_id'] = $this->session->userdata('email_id');
        $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');
        $data['role_name'] = $this->session->userdata('role_name');
        $data['d_id'] = $_POST['d_id'];
        $this->load->model('Admin_model');
        $data['dealer_master_view']=$this->Admin_model->dealer_master_list_view($data);
        $this->load->view('dealer_view',$data);
	}
		
	public function dealer_edit()
	{
        $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
        $data['d_id2'] = $_POST['d_id2'];
        $this->load->model('Admin_model');
         $data['province_master_list']=$this->Admin_model->province_master_list();
        $data['dealer_master_edit']=$this->Admin_model->dealer_master_edit($data);
        $this->load->view('dealer_edit',$data);
	}
	
	public function dealer_update()
	{  
	    if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{  
			
        		$data['role_id'] = $this->session->userdata('role_id');
        		$data['user_id'] = $this->session->userdata('user_id');	
        		$data['role_name'] = $this->session->userdata('role_name');
        		$data['email_id'] = $this->session->userdata('email_id');
        		$this->session->set_userdata('form_ts',$this->input->post('TS'));
        		$arrc =  $_POST['basic'];
        		$this->load->model('Admin_model');
        		$data['alert_flag'] = 0;
        		$data['alert_message'] = "";
        		$data['arrlength'] = $arrc;
        		$data['d_name']=$_POST['d_name'];
        		$data['d_ph_no']=$_POST['d_ph_no'];
        		$data['d_address1']=$_POST['d_address1'];
        		$data['d_address2']=$_POST['d_address2'];
        		$data['d_province']=$_POST['d_province'];
        		$data['d_city']=$_POST['d_city'];
        		$data['d_p_code']=$_POST['d_p_code'];
        		$data['d_website']=$_POST['d_website'];
        		$data['d_p_web_domain']=$_POST['d_p_web_domain'];
        		$data['d_p_email']=$_POST['d_p_email'];
        		$data['d_s_r_nm']=$_POST['d_s_r_nm'];
        		$data['d_id']=$_POST['d_id'];
        		$this->Admin_model->dealer_update($data);
        		$data['alert_flag'] = 1;
        		$data['alert_message'] = " New Dealer Id ".$data['d_id']." has been Updates Successfully.";
        		 $data['dealer_master_list']=$this->Admin_model->dealer_list();
        		$this->load->view('dealer_master_list',$data);
		}
		else
			{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$data['role_name'] = $this->session->userdata('role_name');
				$data['email_id'] = $this->session->userdata('email_id');
				$this->load->model('Admin_model');
				$data['dealer_master_list']=$this->Admin_model->dealer_list();
        		$this->load->view('dealer_master_list',$data);
			}
		
	}
	
	
	public function client_master()
	{
        $data['email_id'] = $this->session->userdata('email_id');
        $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');
        $data['role_name'] = $this->session->userdata('role_name');
        $this->load->model('Admin_model');
        $data['client_list_admin_wise']=$this->Admin_model->client_list_for_admin();
       
        $this->load->view('client_master_list_admin_wise',$data);
	}
	
	
	public function get_fsa_by_zone()
	{

		if($this->session->userdata('email_id') == TRUE) 
		{ 	
			 $data['email_id'] = $this->session->userdata('email_id');
            $data['role_id'] = $this->session->userdata('role_id');
            $data['user_id'] = $this->session->userdata('user_id');
            $data['role_name'] = $this->session->userdata('role_name');
			$data['province_id'] = $this->input->post('id',TRUE);
			$this->load->model('Admin_model');
			$data = $this->Admin_model->bye_fsa_by_zone($data);
			echo json_encode($data);
		}
	}
	
	public function get_region_category_by_province()
    {
        
		if($this->session->userdata('email_id') == TRUE) 
        { 	
        $data['email_id'] = $this->session->userdata('email_id');
        $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');
        $data['role_name'] = $this->session->userdata('role_name');
        $data['province_id'] = $this->input->post('id',TRUE);
		$this->load->model('Admin_model');
		$data = $this->Admin_model->bye_zone_list_by_province($data);
        echo json_encode($data);
        }
    }
	
	
}
