<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//require_once ("/libraries/purlapi.php");
//require_once("/path/purlapi.php");
require_once(APPPATH.'libraries/purlapi.php');
class Campain extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
       
        $this->load->library('session');
        $this->load->helper('url');
        $this->load->library('email');
       
        if($this->session->userdata('email_id') == TRUE)
		{
			
			$data['email_id'] = $this->session->userdata('email_id');
			$this->access=$data['email_id'];
			$data['role_name'] = $this->session->userdata('role_name');
		}
		else
        {
             redirect($base_url);
        }
        
    }


	

	
	public function campain_master()
	{
        $data['email_id'] = $this->session->userdata('email_id');
        $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');
        $data['role_name'] = $this->session->userdata('role_name');
        $this->load->model('Campain_model');
        
        $data['campain_master_list']=$this->Campain_model->campain_list();
        $this->load->view('campain_master_list',$data);
	}
	
	public function campain_add()
	{
	    $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
        $this->load->model('Admin_model');
        $data['dealer_list']=$this->Admin_model->dealer_list();
        $this->load->model('Campain_model');
		$this->load->view('campain_add',$data);
		
	}
	
	public function campain_reg()
	{  
	    if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{  
			
        		$data['role_id'] = $this->session->userdata('role_id');
        		$data['user_id'] = $this->session->userdata('user_id');	
        		$data['role_name'] = $this->session->userdata('role_name');
        		$data['email_id'] = $this->session->userdata('email_id');
        		$this->session->set_userdata('form_ts',$this->input->post('TS'));
        		$arrc =  $_POST['basic'];
        		$this->load->model('Campain_model');
        		$data['alert_flag'] = 0;
        		$data['alert_message'] = "";
        		$data['arrlength'] = $arrc;
        		$data['c_name']=$_POST['c_name'];
        		$data['d_name']=$_POST['d_name'];
        		$data['rec_t_in_camp']=$_POST['rec_t_in_camp'];
        		$data['email_s_camp']=$_POST['email_s_camp'];
        		$data['no_of_p_vists']=$_POST['no_of_p_vists'];
        		$data['no_of_p_sub']=$_POST['no_of_p_sub'];
        		
        		$data['c_id']=$_POST['c_id'];
        		$this->Campain_model->campain_reg($data);
        		$data['alert_flag'] = 1;
        		$data['alert_message'] = " New Campaing Id  has been generated Successfully.";
        		  $data['campain_master_list']=$this->Campain_model->campain_list();
                $this->load->view('campain_master_list',$data);
		}
		else
			{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$data['role_name'] = $this->session->userdata('role_name');
				$data['email_id'] = $this->session->userdata('email_id');
				$this->load->model('Campain_model');
				 $data['campain_master_list']=$this->Campain_model->campain_list();
                $this->load->view('campain_master_list',$data);
			}
		
	}
	
	
	
	public function dealer_reg()
	{  
	   	if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{       
			
        		$data['role_id'] = $this->session->userdata('role_id');
        		$data['user_id'] = $this->session->userdata('user_id');
        		$data['role_name'] = $this->session->userdata('role_name');
        		 $data['email_id'] = $this->session->userdata('email_id');
        		$this->session->set_userdata('form_ts',$this->input->post('TS'));
        		$arrc =  $_POST['basic'];
        		$this->load->model('Admin_model');
        		$data['alert_flag'] = 0;
        		$data['alert_message'] = "";
        		$data['arrlength'] = $arrc;
        		$data['d_name']=$_POST['d_name'];
        		$data['d_ph_no']=$_POST['d_ph_no'];
        		$data['d_address1']=$_POST['d_address1'];
        		$data['d_address2']=$_POST['d_address2'];
        		$data['d_province']=$_POST['d_province'];
        		$data['d_city']=$_POST['d_city'];
        		$data['d_p_code']=$_POST['d_p_code'];
        		$data['d_website']=$_POST['d_website'];
        		$data['d_p_web_domain']=$_POST['d_p_web_domain'];
        		$data['d_p_email']=$_POST['d_p_email'];
        		$data['d_s_r_nm']=$_POST['d_s_r_nm'];
        		
                if($_POST['d_name'] !="")
                {
                $data['d_name']=$_POST['d_name'];
                $data['first_name']=$_POST['d_name'];
                
                }
                else
                {
                $data['d_name'] ='NA';
                }
        		
                if($_POST['d_ph_no'] !="")
                {
                $data['d_ph_no']=$_POST['d_ph_no'];
                $data['phone']=$_POST['d_ph_no'];
                }
                else
                {
                $data['d_ph_no'] ='NA';
                }
                
                if($_POST['d_p_email'] !="")
                {
                $data['d_p_email']=$_POST['d_p_email'];
                $data['email'] = $data['d_p_email'];
                }
                else
                {
                $data['d_p_email'] ='';
                }
                
                if($_POST['d_address1'] !="")
                {
                $data['d_address1']=$_POST['d_address1'];
                $data['address'] = $data['d_address1'];
                }
                else
                {
                $data['d_address1'] ='';
                }
                
                $data['alert_flag'] = 0;
        	    $data['alert_message'] = "";
        	    
        	    $this->load->model('Admin_model');
                $data['alert_flag'] = 0;
                
            if($data['d_name']!="" && $data['d_p_email']!='')
            {
                
                $data['password'] = substr(md5(rand().rand()), 0, 8);
        		
        	    $data['d_list']=$this->Admin_model->dealer_reg($data);
        		
        		
        		if($data['d_list'])
        		{
        			foreach($data['d_list'] as $dealer_id_c)
        			{
						
        				$dealer_id_new = $dealer_id_c['dealer_id'];
        				$password = $dealer_id_c['password'];
						
						//echo $agent_id_new."/".$password;
        			  }
        			
        			$this->load->model('User');
					$data['dealer_id_new'] = $dealer_id_new;
        			$data['user_details'] = $this->User->user_registration($data);
        			if($data['user_details'])
        			{
        				foreach($data['user_details'] as $u_details)
        				{
        					$token = $u_details['token'];
        					$password = $u_details['password'];
        				}
        			}
        		    $data['dealer_id_new'] = $dealer_id_new;
        			$data['alert_flag'] = 1;
        		    $data['alert_message'] = " New Dealer Id  ".$data['dealer_id_new']." has been generated Successfully.";
        		}
        		
        		if($dealer_id_new >0)
        		{
        				$to = $data['email'];
				$subject = "Welcome to CARSM portal";
				
				$txt = "Welcome to the world of CARSM PORTAL!. Your request for accessing application is pending with Admin. You will be notified once approval is done. Your User New Password is ".$password."";
				$txt = $txt." Please go through the url purpuligo.com/carsm/index.php/User_reg/w344fd462/".$token;
				$headers = "From: webmaster@carsm.com";
	
				mail($to,$subject,$txt,$headers);
					
					
        
        			//mail($to,$subject,$txt,$headers);
        		}
        		
        		
            }
            else
        	{
        		$data['alert_flag'] = 0; 
        		$data['alert_message']="";
        	}
        		$data['d_name'] = "";
        	    $data['d_p_email'] = "";
        		
        		$this->load->model('Admin_model');
        		$data['dealer_master_list']=$this->Admin_model->dealer_list();
        		$this->load->view('dealer_master_list',$data);
		}
		else
			{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$data['role_name'] = $this->session->userdata('role_name');
        		 $data['email_id'] = $this->session->userdata('email_id');
				$this->load->model('Admin_model');
				$data['dealer_master_list']=$this->Admin_model->dealer_list();
        		$this->load->view('dealer_master_list',$data);
			}
		
	}
	
	public function campain_view()
	{
        $data['email_id'] = $this->session->userdata('email_id');
        $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');
        $data['role_name'] = $this->session->userdata('role_name');
        $data['d_id'] = $_POST['d_id'];
        $this->load->model('Campain_model');
        $data['campain_master_view']=$this->Campain_model->campain_data_view($data);
        $this->load->view('campain_view',$data);
	}
		
	public function campain_edit()
	{
        $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
        $data['d_id2'] = $_POST['d_id2'];
        $this->load->model('Campain_model');
        $this->load->model('Admin_model');
        $data['dealer_list']=$this->Admin_model->dealer_list();
        $data['campain_master_edit']=$this->Campain_model->campain_data_edit($data);
        
        $this->load->view('campain_edit',$data);
	}
	
	public function campain_update()
	{  
	    if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{  
			
        		$data['role_id'] = $this->session->userdata('role_id');
        		$data['user_id'] = $this->session->userdata('user_id');	
        		$data['role_name'] = $this->session->userdata('role_name');
        		$data['email_id'] = $this->session->userdata('email_id');
        		$this->session->set_userdata('form_ts',$this->input->post('TS'));
        		$arrc =  $_POST['basic'];
        		$this->load->model('Campain_model');
        		$data['alert_flag'] = 0;
        		$data['alert_message'] = "";
        		$data['arrlength'] = $arrc;
        		$data['c_name']=$_POST['c_name'];
        		$data['d_name']=$_POST['d_name'];
        		$data['rec_t_in_camp']=$_POST['rec_t_in_camp'];
        		$data['email_s_camp']=$_POST['email_s_camp'];
        		$data['no_of_p_vists']=$_POST['no_of_p_vists'];
        		$data['no_of_p_sub']=$_POST['no_of_p_sub'];
        		
        		$data['c_id']=$_POST['c_id'];
        		$this->Campain_model->campain_update($data);
        		$data['alert_flag'] = 1;
        		$data['alert_message'] = " New Campaing Id ".$data['c_id']." has been Updates Successfully.";
        		  $data['campain_master_list']=$this->Campain_model->campain_list();
                $this->load->view('campain_master_list',$data);
		}
		else
			{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$data['role_name'] = $this->session->userdata('role_name');
				$data['email_id'] = $this->session->userdata('email_id');
				$this->load->model('Campain_model');
				 $data['campain_master_list']=$this->Campain_model->campain_list();
                $this->load->view('campain_master_list',$data);
			}
		
	}
	
	public function user_view()
	{
	    $data['email_id'] = $this->session->userdata('email_id');
        $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');
        $data['role_name'] = $this->session->userdata('role_name');
        $this->load->model('Dealer_model');
	    $data['user_master_view']=$this->Dealer_model->user_master_view($data);
        $this->load->view('user_view',$data);
	    
	   
	}
	
	public function user_edit()
	{
	    $data['email_id'] = $this->session->userdata('email_id');
        $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');
        $data['role_name'] = $this->session->userdata('role_name');
        $this->load->model('Dealer_model');
	    $data['user_master_view']=$this->Dealer_model->user_master_view($data);
        $this->load->view('user_edit',$data);
	    
	   
	}
	
	
	public function user_update()
	{  
	    if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{  
			
        		$data['role_id'] = $this->session->userdata('role_id');
        		$data['user_id'] = $this->session->userdata('user_id');	
        		$data['role_name'] = $this->session->userdata('role_name');
        		$data['email_id'] = $this->session->userdata('email_id');
        		$this->session->set_userdata('form_ts',$this->input->post('TS'));
        		$arrc =  $_POST['basic'];
        		$this->load->model('Dealer_model');
        		$data['alert_flag'] = 0;
        		$data['alert_message'] = "";
        		$data['arrlength'] = $arrc;
        		$data['u_email']=$this->session->userdata('email_id');
        		$data['u_name']=$_POST['u_name'];
        		$data['u_ph_no']=$_POST['u_ph_no'];
        		$data['u_address']=$_POST['u_address'];

        		$data['u_id']=$_POST['u_id'];
        		$this->Dealer_model->user_update($data);
        		$data['alert_flag'] = 1;
        		$data['alert_message'] = " New User Id ".$data['u_id']." has been Updates Successfully.";
        		$data['user_master_view']=$this->Dealer_model->user_master_view($data);
                $this->load->view('user_view',$data);
		}
		else
			{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$data['role_name'] = $this->session->userdata('role_name');
				$data['email_id'] = $this->session->userdata('email_id');
				$this->load->model('Dealer_model');
				$data['user_master_view']=$this->Dealer_model->user_master_view($data);
                $this->load->view('user_view',$data);
			}
		
	}
	
	 public function all_camapaign_add()
	{
	    $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
        $this->load->model('Campain_model');
        //$data['camp_list']=$this->Campain_model->campain_list2();
		$this->load->view('all_camapaign_add',$data);
		
	}
	
	
	
	public function get_campaigns()
	{
	    if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{ 
        $data['email_id'] = $this->session->userdata('email_id');
        $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');
        $data['role_name'] = $this->session->userdata('role_name');
        $this->session->set_userdata('form_ts',$this->input->post('TS'));
        $this->load->model('Campain_model');
        $purlObj = new Purlem();
        $userID = '5083'; //Enter your userID here
        $token ='10244899135e1803ff48cd6'; //Enter your API Token here
       $purlObj->connect($userID,$token);
        
        $response =$purlObj->get_all_campaigns();
        //echo $response;
        
        $jdata = json_decode($response ,true );
        // print_r($jdata);
        if($jdata)
            {
         foreach($jdata as $data1)
        { 
            
            $c_id.=$data1[campaignID].",";
            $name.=$data1[name].",";
            $url.=$data1[url].",";
            $purlpage.=$data1[purlpage].",";
            
       
        }
    
    
    		 $data['cam_id']=$c_id;
    		 $data['c_name']=$name;
    		 $data['c_url']=$url;
    		 $data['purlpage']=$purlpage;
			 $data['alert_flag'] = 0;
             $data['alert_message'] = "";	 	 
				
            $this->Campain_model->campaign_data_id($data);
            $data['alert_flag'] = 1;
            $data['alert_message'] = "All  Campaign  has been  Added Successfully.";
            
            	$this->load->view('all_camapaign_add',$data);
            }  
       
	}
	   else
			{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$data['role_name'] = $this->session->userdata('role_name');
				$data['email_id'] = $this->session->userdata('email_id');
				$this->load->view('all_camapaign_add',$data);
				
			} 
	}
	
	public function campain_data_add()
	{
	    if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{ 
        $data['email_id'] = $this->session->userdata('email_id');
        $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');
        $data['role_name'] = $this->session->userdata('role_name');
        $this->session->set_userdata('form_ts',$this->input->post('TS'));
        $this->load->model('Campain_model');
        $purlObj = new Purlem();
        $userID = '5083'; //Enter your userID here
        $token ='10244899135e1803ff48cd6'; //Enter your API Token here
        $purlObj->connect($userID,$token);
        
        $campaign_id =$_POST['campaign_id'];//The Campaign ID to get results for
        
        $response = $purlObj->get_results($campaign_id);
        //echo $response;
        
        $jdata2 = json_decode($response ,true );
        // print_r($jdata2);
        
         foreach($jdata2 as $data1)
        { 
            
            $id.=$data1[ID].",";
            $c_name.=$data1[campaignID].",";
            $c_id.=$data1[contactID].",";
            //$f_name.=$data1[firstName].",";
            //$l_name.=$data1[lastName].",";
            //$phone.=$data1[phone].",";
            $p_id.=$data1[pageID].",";
            $ip_address.=$data1[IP].",";
            
       
        }
    

				 $data['id']=$id;
				 $data['c_name']=$c_name;
				 $data['c_id']=$c_id;
				 $data['f_name']=0;
				 $data['l_name']=0;
				 $data['phone']=0;
				 $data['p_id']=$p_id;
				 $data['ip_address']=$ip_address;
				 $data['campaign_id']=$campaign_id;
			 $data['alert_flag'] = 0;
             $data['alert_message'] = "";	 
				
         $this->Campain_model->campaign_data_upload($data);
         $data['alert_flag'] = 1;
        $data['alert_message'] = " Campaign Id ".$campaign_id." Data has been  Updated Successfully.";
          $data['camp_list']=$this->Campain_model->campain_list2();
        $this->load->view('campaign_data_upload',$data);
		}
		
			else
			{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$data['role_name'] = $this->session->userdata('role_name');
				$data['email_id'] = $this->session->userdata('email_id');
				$this->load->model('Campain_model');
				$data['camp_list']=$this->Campain_model->campain_list2();
                $this->load->view('campaign_data_upload',$data);
			}
	}
	
	
	 public function campaign_data_upload()
	{
	    $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
        $this->load->model('Campain_model');
        $data['camp_list']=$this->Campain_model->campain_list2();
		$this->load->view('campaign_data_upload',$data);
		
	}
	
	 public function campaign_result()
	{
	    $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
        $this->load->model('Campain_model');
        // Connect
            $userID = '5083'; //Enter your userID here
            $token = '10244899135e1803ff48cd6'; //Enter your API Token here
            Purlem::connect($userID,$token);
            
            // Get Campaign
            $campaign_id = '20315'; //The Campaign ID to get
            $response = Purlem::get_results($campaign_id);
            // echo $response;
            $jdata3 = json_decode($response, true);
         print_r($jdata3);
		
	}
	
	
	
}
