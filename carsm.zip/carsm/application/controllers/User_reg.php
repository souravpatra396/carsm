<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_reg extends CI_Controller {

	 public function __construct()
    {
        parent::__construct();
        $this->load->model('user');
        $this->load->library('session');
        $this->load->helper('url');
        $this->load->library('email');
        
         if($this->session->userdata('email_id') == TRUE)
		{
			
			$data['email_id'] = $this->session->userdata('email_id');
			$this->access=$data['email_id'];
			$data['role_name'] = $this->session->userdata('role_name');
		}
		else
        {
             redirect($base_url);
        }
    }
    
    public function user_add()
	{
        $data['email_id'] = $this->session->userdata('email_id');
        $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');
         $data['role_name'] = $this->session->userdata('role_name');
        $this->load->model('User');
        $this->load->view('register',$data);
		
		
	}
	
	public function user_reg()
	{   
 		$data['role_id'] = $this->session->userdata('role_id');
		$data['user_id'] = $this->session->userdata('user_id');
		
		$data['email'] = $_POST['email'];
        $data['first_name'] =  $_POST['first_name'];
        $data['last_name'] =  $_POST['last_name'];
        $data['phone'] =  $_POST['c_telephone'];
        $data['address'] =  $_POST['address'];
		$data['role'] =  $_POST['role'];
		$data['dealer_id_new'] =0;
        $data['password'] = substr(md5(rand().rand()), 0, 8);
        $data['role_id1'] = $this->session->userdata('role_id');
        $this->load->model('User');	
        //$data['role_master_list'] = $this->User->role_master_list();
        
	    if($data['email'] != "")
	    {
			//echo "1";
			$user_cred = $this->User->user_registration($data);
			if($user_cred)
			{
				foreach($user_cred as $user_details)
				{
					$token = $user_details['token'];
					$password = $user_details['password'];
				}

				/* $to = $data['email'];
				$subject = "Welcome to IQOS portal";
				$txt = "Welcome to the world of IQOS!. Your User ID is for accessing application is ".$data['email']." and One time Password is ".$data['password'];
				$txt = $txt." Please go through the url purpuligo.com/iqos/index.php/User_reg/w344fd462/".$token;
                
                $from = $this->config->item('smtp_user');
                $this->email->set_newline("\r\n");
                $this->email->from($from);
                $this->email->to($to);
                $this->email->bcc('sukharanjan.mahata@gmail.com','getbenu@gmail.com');
                $this->email->subject($subject);
                $this->email->message($txt);

                $this->email->send(); */
				
				$to = $data['email'];
				$subject = "Welcome to CARSM portal";
				
				$txt = "Welcome to the world of CARSM PORTAL!. Your request for accessing application is pending with Admin. You will be notified once approval is done. Your User New Password is ".$password."";
				$txt = $txt." Please go through the url purpuligo.com/carsm/index.php/User_reg/w344fd462/".$token;
				$headers = "From: webmaster@carsm.com";
	
				mail($to,$subject,$txt,$headers);
			    //echo json_encode(1);
				

			}

			//$this->load->view('login_1',$data);
		}
	    /* else
	    {
			echo "1";
	        $this->load->view('user_add',$data);
	    } */
	
       redirect($base_url);
	}
	
	public function w344fd462($a)
    {
        $data['token'] = $a;
        //echo $data['token'];
        $this->load->model('User');
		$data['current_pwd']=$_POST['current_pwd'];
		$data['new_pwd']=$_POST['new_pwd'];
		$data['confrm_pwd']=$_POST['confrm_pwd'];
        $data['user_details'] = $this->User->token_verification($data);
        if($data['user_details'])
        {
          
            foreach($data['user_details'] as $u_details)
            {
                $data['user_id'] = $u_details['user_id'];
                $data['flag'] = $u_details['flag'];
            }
        }
        //echo "sou";
        $this->load->view('pwd_reset1',$data);
	 
    }
    
     public function password_update()
    {
        $this->load->model('User');
        $data['token']=$_POST['token'];
        $data['current_pwd']=$_POST['current_pwd'];
        $data['new_pwd']=$_POST['new_pwd'];
        $data['confrm_pwd']=$_POST['confrm_pwd'];
        $data['user_id']=$_POST['user_id'];
        $data['alert_message'] = "";
        if($data['new_pwd'] == $data['confrm_pwd'])
        {
			
            if($data['user_id']!="" && $data['token']!= "" && $data['current_pwd']!="" && $data['new_pwd']!="")
            {
                $data['reset_pwd'] = $this->User->password_reset($data);	
            }
            
            if($data['reset_pwd'])
            {
				
				echo $reset_pwd;
                foreach($data['reset_pwd'] as $usr_details)
                {
                    $data['ret_code'] = $usr_details['MSG'];
                }
            }
            
            if($data['ret_code'] == 1001)
            {   
		         
                $data['flag'] = "Your password has been updated. Please try with new password";
                $data['alert_message'] = '<font color="red">"Your password has been updated. Please try with new password".</font>';
				
				
                 redirect($base_url,$data);
            }
            else
            {
				
				
                $data['flag'] = 1001;
                $data['alert_message'] ='<font color="red">"Password entered by you is not correct."</font>';
                $this->load->view('pwd_reset1',$data);
                //redirect($base_url);
            }
        }
        else
        {    
	        
            $data['flag'] = 1001;
            $data['alert_message'] = '<font color="red">""Password not matching."</font>';
			
            $this->load->view('pwd_reset1',$data); 
        }
    }
    public function forget_password_entry()
    {
        $this->load->view('forget_password',$data);
    }
    
    public function forget_password()
    {
    $this->load->model('User');  
    $data['u_email'] = $_POST['u_email'];  
    
    
    
    if($data['u_email']!= "")
    {
        $data['password_data'] = $this->User->forget_password($data);
    } 
    if($data['password_data'])
    {
        foreach($data['password_data'] as $p_id_c)
        {
            
            
            
            $new_password_c = $p_id_c['new_password'];
            $new_token_c = $p_id_c['new_token'];
            $status = $p_id_c['OUTPUT'];
        }
        $data['status'] =$status;
        $data['flag'] =$status;
        if($status==1001)
        {
            $to =$data['u_email'];
            $subject = "New Password";
            $txt = "Welcome to the world of CARSM!. Your User New Password is ".$new_password_c." ";
    		
    		$txt = $txt." Please go through the url purpuligo.com/carsm/index.php/User_reg/w344fd462/".$new_token_c;
    		
            $headers = "From: webmaster@carsm.com";
            mail($to,$subject,$txt,$headers);
        }
        else
        {
            $data['status'] =$status;
        }
        //echo json_encode($data['status']);
       // echo "sourav";
    	 $this->load->view('forget_password',$data);
    }
    }
    
    
	
	
	
	 public function check_email()
	 {
        $this->load->model('User');
        $data['email']=$_POST['u_email'];
        $data['pass']=$_POST['u_pass'];
        $data['email_count']=$this->User->check_user_email($data);
        echo json_encode($data['email_count']);
        //echo $data['email_count'];
    }

}
