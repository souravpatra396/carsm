<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	 public function __construct()
    {
        parent::__construct();
        $this->load->model('user');
        $this->load->library('session');
        $this->load->helper('url');
        //$this->load->library('email');
    }
	public function index()
	{
	     //global $data;
	     
		$this->load->view('welcome_message',$data);
	}
	
	 public function temp()
    {    
        global $data;
        $this->load->view('agent-module',$data);
    }
	public function user_auth()
	{
        session_cache_limiter('private, must-revalidate');
        session_cache_expire(60);
        session_start();
        if(!isset($_SESSION['email']))
        $data['email'] =$_POST['email'];
        $data['password'] = $_POST['password'];
        $this->load->model('user');
        $rs = $this->user->user_auth($data);

		if($rs)
		{
			foreach($rs as $result)
			{
				$ret_code = $result['login_status'];
				//echo$data['email'];
				$role_id = $result['role_id'];
			}
		}
		
		
        $date2 = date_create($result['validity']);
        $date1 = date_create('now');
        $interval=date_diff($date2,$date1);
        $interval2 = $interval->format('%R%a days');
		
	    if($interval2 <=0)
	    {	
	        
	       
    		if($ret_code == 1001)
    		{
                $this->session->set_userdata(array('email_id' => $result['email_id'],
                             'role_id' => $result['role_id'],
                             'role_name' => $result['role_name'],
                             'user_id' => $result['user_id']));
    
                $data['email_id'] = $this->session->userdata('email_id');
    
                $data['role_id'] = $this->session->userdata('role_id');
                $data['user_id'] = $this->session->userdata('user_id');
                 $data['role_name'] =$this->session->userdata('role_name');
                
                //$url=base_url()."index.php/Admin/product_module";
    			//redirect($url);
    				
    			if($role_id == 1)
    			{   
    		         $url=base_url()."index.php/Dealer/dealer_module";
    				 redirect($url);
    			}
    			
    			elseif($role_id == 2)
    			{
    			//echo base_url();	
    				$url=base_url("index.php/Admin/admin_module");
    				 
    				 	//echo $url;
    				 	redirect($url, 'refresh');
    			}
    			elseif($role_id == 3)
    			{
    				//echo"sou4";	
    				$url=base_url()."index.php/Sale_rep/sale_rep_module";
    				 redirect($url);
    			}
    			else
    			{
    				$this->load->view('not-found');
    			}
    			
    		}
    		else
    		{
    			$this->session->set_flashdata('error', 'Please enter correct Password.');
    			redirect($base_url);
    			echo"kk";
    		}
	    }
	    
	    else
    		{
    			$this->session->set_flashdata('error', 'Please enter correct Password.');
    			redirect($base_url);
    			echo"kk";
    		}
	}
	

}
