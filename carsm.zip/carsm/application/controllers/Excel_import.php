<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Excel_import extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('excel_import_model');
		$this->load->library('excel');
		
		 if($this->session->userdata('email_id') == TRUE)
		{
			
			$data['email_id'] = $this->session->userdata('email_id');
			$this->access=$data['email_id'];
			$data['role_name'] = $this->session->userdata('role_name');
		}
		else
        {
             redirect($base_url);
        }
	}

	function excel_upload()
	{
	     $data['email_id'] = $this->session->userdata('email_id');
        $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');
        $data['role_name'] = $this->session->userdata('role_name');
        $this->load->model('Admin_model');
        $data['dealer_list']=$this->Admin_model->dealer_list();
        
		$this->load->view('excel_upload',$data);
	}
	
	function fetch()
	{
		$data = $this->excel_import_model->select();
		$output = '
		<h3 align="left"> Data Count - '.$data->num_rows().'</h3>
		<table class="footable table table-stripped toggle-arrow-tiny">
			<tr>
			    	<th>Record Id</th>
				<th>Client Name</th>
				<th>Address1</th>
					<th>Address2</th>
				<th>City</th>
				<th>State</th>
				<th>Postal Code</th>
				<th>Phone No</th>
				
					<th>Business Phone</th>
				<th>Email</th>
					<th>Make</th>
				<th>Model</th>
				<th>Make Year</th>
				<th>Model Colour</th>
				<th>Mileage</th>
				
				<th>VIN </th>
				<th>Last Service</th>
					<th>Delivery Date</th>
				<th>Sales Rep</th>
				<th>Distance to Dealership</th>
				
				
			</tr>
		';
		foreach($data->result() as $row)
		{
			$output .= '
			<tr>
			    <td>'.$row->id.'</td>
				<td>'.$row->first_name.'  '.$row->last_name.'</td>
				<td>'.$row->address1.'</td>
				<td>'.$row->address2.'</td>
				<td>'.$row->city.'</td>
				<td>'.$row->state.'</td>
				<td>'.$row->postal_code.'</td>
				<td>'.$row->ph_no.'</td>
				
				
				<td>'.$row->b_ph_no.'</td>
				<td>'.$row->email_id.'</td>
				<td>'.$row->make.'</td>
				<td>'.$row->model.'</td>
				<td>'.$row->make_yr.'</td>
				<td>'.$row->model_colour.'</td>
				
				<td>'.$row->mileage.'</td>
				<td>'.$row->vin.'</td>
				<td>'.$row->last_service.'</td>
				<td>'.$row->delivery_date.'</td>
				<td>'.$row->sales_rep.'</td>
				<td>'.$row->dis_to_dealership.'</td>
			</tr>
			
			
			';
		}
		$output .= '</table>';
		echo $output;
	}

	function import()
	{
	   //echo"hii";
		if(isset($_FILES["file"]["name"]))
		{
		    //echo"hii";
			$path = $_FILES["file"]["tmp_name"];
			$object = PHPExcel_IOFactory::load($path);
			foreach($object->getWorksheetIterator() as $worksheet)
			{
			     //echo"souraii";
				$highestRow = $worksheet->getHighestRow();
				$highestColumn = $worksheet->getHighestColumn();
				for($row=2; $row<=$highestRow; $row++)
				{
					$purl = $worksheet->getCellByColumnAndRow(0, $row)->getValue();
					$fast_name = $worksheet->getCellByColumnAndRow(1, $row)->getValue();
					$last_name = $worksheet->getCellByColumnAndRow(2, $row)->getValue();
					$address1 = $worksheet->getCellByColumnAndRow(3, $row)->getValue();
					$address2 = $worksheet->getCellByColumnAndRow(4, $row)->getValue();
					$city = $worksheet->getCellByColumnAndRow(5, $row)->getValue();
					$state = $worksheet->getCellByColumnAndRow(6, $row)->getValue();
					$postal_code = $worksheet->getCellByColumnAndRow(7, $row)->getValue();
					$phone_no = $worksheet->getCellByColumnAndRow(8, $row)->getValue();
					$b_ph_no = $worksheet->getCellByColumnAndRow(9, $row)->getValue();
					$email_id = $worksheet->getCellByColumnAndRow(10, $row)->getValue();
					$make = $worksheet->getCellByColumnAndRow(11, $row)->getValue();
					$model = $worksheet->getCellByColumnAndRow(12, $row)->getValue();
					$year = $worksheet->getCellByColumnAndRow(13, $row)->getValue();
					$model_colour = $worksheet->getCellByColumnAndRow(14, $row)->getValue();
					$mileage = $worksheet->getCellByColumnAndRow(15, $row)->getValue();
					$vin = $worksheet->getCellByColumnAndRow(16, $row)->getValue();
					$last_service = $worksheet->getCellByColumnAndRow(17, $row)->getValue();
					$delivery_date = $worksheet->getCellByColumnAndRow(18, $row)->getValue();
					$sales_rep = $worksheet->getCellByColumnAndRow(19, $row)->getValue();
					$distance_to_dealer = $worksheet->getCellByColumnAndRow(20, $row)->getValue();
					$data[] = array(
						'purl'				=>	$purl,
						'first_name'		=>	$fast_name,
						'last_name'			=>	$last_name,
						'address1'			=>	$address1,
						'address2'			=>	$address2,
						'city'				=>	$city,
						'state'				=>	$state,
						'postal_code'		=>	$postal_code,
						'ph_no'				=>	$phone_no,
						'b_ph_no'			=>	$b_ph_no,
						'email_id'			=>	$email_id,
						'make'				=>	$make,
						'model'				=>	$model,
						'make_yr'			=>	$year,
						'model_colour'		=>	$model_colour,
						'mileage'			=>	$mileage,
						'vin'				=>	$vin,
						'last_service'		=>	$last_service,
						'delivery_date'		=>	$delivery_date,
						'sales_rep'			=>	$sales_rep,
						'dis_to_dealership'	=>	$distance_to_dealer
					);
				}
			}
			$data['role_name']=$this->excel_import_model->insert($data);
			//echo"".$data['role_name'];
			$data['dataInfo']=$data;
			echo 'Data Imported successfully';
			//$this->load->view('excel_data_view2',$data);
		
		}	
		
		
	}
	
	public function client_list_assign()
	{  
	    if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{
		$data['email_id'] = $this->session->userdata('email_id');
        $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');
        $data['role_name'] = $this->session->userdata('role_name');
        $this->session->set_userdata('form_ts',$this->input->post('TS'));
         $this->load->model('Admin_model');
        $data['dealer_list']=$this->Admin_model->dealer_list();
		$this->load->view('dealer_assign',$data);
		}
			else
			{
            $data['email_id'] = $this->session->userdata('email_id');
            $data['role_id'] = $this->session->userdata('role_id');
            $data['user_id'] = $this->session->userdata('user_id');
            $data['role_name'] = $this->session->userdata('role_name');
             $this->load->model('Admin_model');
            $data['dealer_list']=$this->Admin_model->dealer_list();
           	$this->load->view('dealer_assign',$data);
			}
		
	}
	
	
	
	public function client_list_update()
	{  
	    if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{
		$data['email_id'] = $this->session->userdata('email_id');
        $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');
        $data['role_name'] = $this->session->userdata('role_name');
        $this->session->set_userdata('form_ts',$this->input->post('TS'));
        $data['alert_flag'] = 0;
        $data['alert_message'] = "";
         $this->load->model('Admin_model');
        $data['dealer_list']=$this->Admin_model->dealer_list();
        $data['user_id1']=$_POST['d_name'];
        $this->excel_import_model->client_data_update($data);
        $data['alert_flag'] = 1;
        $data['alert_message'] = " Data has been Updates Successfully.";
		$this->load->view('excel_upload',$data);
		}
			else
			{
            $data['email_id'] = $this->session->userdata('email_id');
            $data['role_id'] = $this->session->userdata('role_id');
            $data['user_id'] = $this->session->userdata('user_id');
            $data['role_name'] = $this->session->userdata('role_name');
            $this->load->view('excel_upload',$data);
			}
		
	}
	
	public function client_data_truncate()
	{  
	    if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{
		$data['email_id'] = $this->session->userdata('email_id');
        $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');
        $data['role_name'] = $this->session->userdata('role_name');
        $this->session->set_userdata('form_ts',$this->input->post('TS'));
        $data['alert_flag'] = 0;
        $data['alert_message'] = "";
        $this->excel_import_model->truncate();
        $data['alert_flag'] = 1;
        $data['alert_message'] = "All data has been delete Successfully.";
		$this->load->view('excel_upload',$data);
		}
		
		else
			{
            $data['email_id'] = $this->session->userdata('email_id');
            $data['role_id'] = $this->session->userdata('role_id');
            $data['user_id'] = $this->session->userdata('user_id');
            $data['role_name'] = $this->session->userdata('role_name');
            $this->load->view('excel_upload',$data);
			}
		
	}
}

?>