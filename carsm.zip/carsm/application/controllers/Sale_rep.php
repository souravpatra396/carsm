<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sale_rep extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
       
        $this->load->library('session');
        $this->load->helper('url');
        $this->load->library('email');
        
        if($this->session->userdata('email_id') == TRUE)
		{
			
			$data['email_id'] = $this->session->userdata('email_id');
			$this->access=$data['email_id'];
			$data['role_name'] = $this->session->userdata('role_name');
		}
		else
        {
             redirect($base_url);
        }
        
    }


	
	public function sale_rep_module()
	{
	    $data['email_id'] = $this->session->userdata('email_id');
        $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');
        $data['role_name'] = $this->session->userdata('role_name');
         $this->load->model('Sale_model');
        //$data['client_master_list']=$this->Sale_model->rep_wise_client_master_list($data);
        // $data['client_master_list']=$this->Sale_model->rep_wise_client_status_update_master_list($data);
        $data['total_records2']=$this->Sale_model->sale_rep_dashboard_view($data);
        $this->load->model('Sale_model');
       
        
        $this->load->view('dash3',$data);
	    
	   
	}
	
	public function sale_rep_master()
	{
        $data['email_id'] = $this->session->userdata('email_id');
        $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');
        $data['role_name'] = $this->session->userdata('role_name');
        $this->load->model('Sale_model');
        $data['sale_rep_master_list']=$this->Sale_model->sale_rep_list($data);
        $this->load->view('sale_rep_master_list',$data);
	}
	
	public function sale_rep_add()
	{
	    $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
        $this->load->model('Sale_model');
		$this->load->view('sale_rep_add',$data);
		
	}
	
	
	public function sale_rep_reg()
	{  
	   	if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{       
			
        		$data['role_id'] = $this->session->userdata('role_id');
        		$data['user_id'] = $this->session->userdata('user_id');
        		$data['role_name'] = $this->session->userdata('role_name');
        		 $data['email_id'] = $this->session->userdata('email_id');
        		$this->session->set_userdata('form_ts',$this->input->post('TS'));
        		$arrc =  $_POST['basic'];
        		$this->load->model('Sale_model');
        		$data['alert_flag'] = 0;
        		$data['alert_message'] = "";
        		$data['arrlength'] = $arrc;
        		$data['s_rep_name']=$_POST['s_rep_name'];
        		$data['s_rep_email']=$_POST['s_rep_email'];
        		$data['s_rep_address']=$_POST['s_rep_address'];
        		$data['s_rep_ph_no']=$_POST['s_rep_ph_no'];
        		
        		
                if($_POST['s_rep_name'] !="")
                {
                $data['s_rep_name']=$_POST['s_rep_name'];
                $data['first_name']=$_POST['s_rep_name'];
                
                }
                else
                {
                $data['s_rep_name'] ='NA';
                }
        		
                if($_POST['s_rep_ph_no'] !="")
                {
                $data['s_rep_ph_no']=$_POST['s_rep_ph_no'];
                $data['phone']=$_POST['s_rep_ph_no'];
                }
                else
                {
                $data['s_rep_ph_no'] ='NA';
                }
                
                if($_POST['s_rep_email'] !="")
                {
                $data['s_rep_email']=$_POST['s_rep_email'];
                $data['email'] = $data['s_rep_email'];
                }
                else
                {
                $data['s_rep_email'] ='';
                }
                
                if($_POST['s_rep_address'] !="")
                {
                $data['s_rep_address']=$_POST['s_rep_address'];
                $data['address'] = $data['s_rep_address'];
                }
                else
                {
                $data['s_rep_address'] ='';
                }
                
                $data['role_id1'] = 3;
                
                $data['alert_flag'] = 0;
        	    $data['alert_message'] = "";
        	    
        	    $this->load->model('Sale_model');
                $data['alert_flag'] = 0;
                
            if($data['s_rep_name']!="" && $data['s_rep_email']!='')
            {
                
                $data['password'] = substr(md5(rand().rand()), 0, 8);
        		
        	    $data['d_list']=$this->Sale_model->sale_rep_reg($data);
        		
        		
        		if($data['d_list'])
        		{
        			foreach($data['d_list'] as $sale_rep_id_c)
        			{
						
        				$sale_rep_id_new = $sale_rep_id_c['rep_id'];
        				$password = $sale_rep_id_c['password'];
						
						//echo $agent_id_new."/".$password;
        			  }
        			
        			$this->load->model('User');
					$data['dealer_id_new'] =$sale_rep_id_new;
        			$data['user_details'] = $this->User->user_registration2($data);
        			if($data['user_details'])
        			{
        				foreach($data['user_details'] as $u_details)
        				{
        					$token = $u_details['token'];
        					$password = $u_details['password'];
        				}
        			}
        		    $data['dealer_id_new'] = $sale_rep_id_new;
        			$data['alert_flag'] = 1;
        		    $data['alert_message'] = " New Sale Representative Id  ".$data['dealer_id_new']." has been generated Successfully.";
        		}
        		
        		if($sale_rep_id_new >0)
        		{
        				$to = $data['email'];
				$subject = "Welcome to CARSM portal";
				
				$txt = "Welcome to the world of CARSM PORTAL!. Your request for accessing application is pending with Admin. You will be notified once approval is done. Your User New Password is ".$password."";
				$txt = $txt." Please go through the url purpuligo.com/carsm/index.php/User_reg/w344fd462/".$token;
				$headers = "From: webmaster@carsm.com";
	
				mail($to,$subject,$txt,$headers);
					
					
        
        			//mail($to,$subject,$txt,$headers);
        		}
        		
        		
            }
            else
        	{
        		$data['alert_flag'] = 0; 
        		$data['alert_message']="";
        	}
        		$data['s_rep_name'] = "";
        	    $data['s_rep_email'] = "";
        		
        		$this->load->model('Sale_model');
                $data['sale_rep_master_list']=$this->Sale_model->sale_rep_list($data);
                $this->load->view('sale_rep_master_list',$data);
		}
		else
			{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$data['role_name'] = $this->session->userdata('role_name');
        		 $data['email_id'] = $this->session->userdata('email_id');
				$this->load->model('Sale_model');
                $data['sale_rep_master_list']=$this->Sale_model->sale_rep_list($data);
                $this->load->view('sale_rep_master_list',$data);
			}
		
	}
	
	public function sale_rep_view()
	{
        $data['email_id'] = $this->session->userdata('email_id');
        $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');
        $data['role_name'] = $this->session->userdata('role_name');
        $data['d_id'] = $_POST['d_id'];
        $this->load->model('Sale_model');
        $data['sale_rep_master_view']=$this->Sale_model->sale_rep_list_view($data);
        $this->load->view('sale_rep_view',$data);
	}
		
	public function sale_rep_edit()
	{
        $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
        $data['d_id2'] = $_POST['d_id2'];
        $this->load->model('Sale_model');
        $data['sale_rep_master_edit']=$this->Sale_model->sale_rep_edit($data);
        $this->load->view('sale_rep_edit',$data);
	}
	

	
	public function sale_rep_update()
	{  
	    if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{  
			
        		$data['role_id'] = $this->session->userdata('role_id');
        		$data['user_id'] = $this->session->userdata('user_id');	
        		$data['role_name'] = $this->session->userdata('role_name');
        		$data['email_id'] = $this->session->userdata('email_id');
        		$this->session->set_userdata('form_ts',$this->input->post('TS'));
        		$arrc =  $_POST['basic'];
        		$this->load->model('Sale_model');
        		$data['alert_flag'] = 0;
        		$data['alert_message'] = "";
        		$data['arrlength'] = $arrc;
        		$data['s_rep_name']=$_POST['s_rep_name'];
        		$data['s_rep_email']=$_POST['s_rep_email'];
        		$data['s_rep_address']=$_POST['s_rep_address'];
        		$data['s_rep_ph_no']=$_POST['s_rep_ph_no'];
        		
        		$data['s_rep_id']=$_POST['s_rep_id'];
        		$this->Sale_model->sale_rep_update($data);
        		$data['alert_flag'] = 1;
        		$data['alert_message'] = " Sale Representative Id ".$data['s_rep_id']." has been Updates Successfully.";
        		  $this->load->model('Sale_model');
                $data['sale_rep_master_list']=$this->Sale_model->sale_rep_list($data);
                $this->load->view('sale_rep_master_list',$data);
		}
		else
			{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$data['role_name'] = $this->session->userdata('role_name');
				$data['email_id'] = $this->session->userdata('email_id');
				$this->load->model('Sale_model');
                $data['sale_rep_master_list']=$this->Sale_model->sale_rep_list($data);
                $this->load->view('sale_rep_master_list',$data);
			}
		
	}
	

	public function sale_rep_assign()
	{
	    $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
        $this->load->model('Sale_model');
        $data['client_list']=$this->Sale_model->client_list_by_id($data);
        $data['sr_list']=$this->Sale_model->sale_rep_list_by_id($data);
		$this->load->view('sale_rep_assign',$data);
		
	}
	
	public function sale_rep_assign_update()
	{
	    if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{
	    $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
        $this->session->set_userdata('form_ts',$this->input->post('TS'));
        $data['alert_flag'] = 0;
        $data['alert_message'] = "";
        
        $arr =  $_POST['client'];
				foreach ($arr as $names)
				{
				$s_str .= $names.",";
				}

				$data['c_name']=$s_str;
        
        
        //$data['c_name']=$_POST['c_name'];
        $data['s_rep_name']=$_POST['s_rep_name'];
        $this->load->model('Sale_model');
        $data['alert_flag'] = 1;
        $data['alert_message'] = " Client Id ".$data['c_name']." has been Assigned Successfully.";
        $this->Sale_model->rep_assign_update($data);
        $data['sr_list']=$this->Sale_model->sale_rep_list_by_id($data);
        $data['client_master_list']=$this->Sale_model->assign_list_for_client($data);
		$this->load->view('rep_assign_list_for_client',$data);
		}
		else
			{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$data['role_name'] = $this->session->userdata('role_name');
				$data['email_id'] = $this->session->userdata('email_id');
				$this->load->model('Sale_model');
				$data['sr_list']=$this->Sale_model->sale_rep_list_by_id($data);
                $data['client_master_list']=$this->Sale_model->assign_list_for_client($data);
		        $this->load->view('rep_assign_list_for_client',$data);
			}
	}
	
	
	public function rep_assign_list_for_client()
	{
	    $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
         $this->load->model('Sale_model');
        $data['client_list']=$this->Sale_model->client_list_by_id($data);
        $data['sr_list']=$this->Sale_model->sale_rep_list_by_id($data);
       $data['client_master_list']=$this->Sale_model->assign_list_for_client($data);
		$this->load->view('rep_assign_list_for_client',$data);
		
	}

	 public function sale_rep_assign_view_for_client()
	{
        $data['email_id'] = $this->session->userdata('email_id');
        $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');
        $data['role_name'] = $this->session->userdata('role_name');
        $data['d_id'] = $_POST['d_id'];
        $this->load->model('Sale_model');
        $data['sale_rep_assign_view']=$this->Sale_model->sale_rep_assign_view_for_client($data);
        $this->load->view('sale_rep_assign_view_for_client',$data);
	}
	
	public function sale_rep_assign_edit()
	{
	    $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
        $this->load->model('Sale_model');
        $data['d_id'] = $_POST['d_id2'];
        $data['client_list']=$this->Sale_model->client_list_by_id($data);
        $data['sr_list']=$this->Sale_model->sale_rep_list_by_id($data);
        $data['sale_rep_assign_edit']=$this->Sale_model->sale_rep_assign_edit_for_client($data);
		$this->load->view('sale_rep_assign_edit',$data);
		
	}
	
	public function sale_rep_assign_update_for_client()
	{
	    if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{  
	    $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
        $this->session->set_userdata('form_ts',$this->input->post('TS'));
        $data['alert_flag'] = 0;
        $data['alert_message'] = "";
        $data['c_name']=$_POST['c_id'];
        $data['s_rep_name']=$_POST['s_rep_name'];
        $this->load->model('Sale_model');
        $data['alert_flag'] = 1;
        $data['alert_message'] = " Sale Representative Id ".$data['s_rep_name']." has been Assign Updated Successfully.";
        $this->Sale_model->rep_assign_update($data);
        $data['client_master_list']=$this->Sale_model->assign_list_for_client($data);
		$this->load->view('rep_assign_list_for_client',$data);
		}
		else
			{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$data['role_name'] = $this->session->userdata('role_name');
				$data['email_id'] = $this->session->userdata('email_id');
				$this->load->model('Sale_model');
                $data['client_master_list']=$this->Sale_model->assign_list_for_client($data);
		        $this->load->view('rep_assign_list_for_client',$data);
			}
	}

	
	public function client_list_for_rep_wise()
	{
	    $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
         $this->load->model('Sale_model');
         $data['status'] = 0;
        $data['client_master_list']=$this->Sale_model->rep_wise_client_status_update_master_list($data);
		$this->load->view('client_list_for_rep_wise',$data);
		
	}
	
	public function client_status()
	{
	    $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
        $this->load->model('Sale_model');
        
        $data['d_id'] = $data['user_id'];
        //$data['status_d_list']=$this->Sale_model->client_status_details_list($data);
        $data['s_id'] = $data['status_d_list'][0]['status'];
        
        
        $data['client_list']=$this->Sale_model->rep_wise_client_master_list2($data);;
        $data['status_list']=$this->Sale_model->status_master_list();
		$this->load->view('client_status_update',$data);
		
	}
	
	public function client_status_update()
	{
	    if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{  
	    $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
        $this->session->set_userdata('form_ts',$this->input->post('TS'));
        $data['alert_flag'] = 0;
        $data['alert_message'] = "";
        $data['c_name']=$_POST['c_id'];
        $data['status_id']=$_POST['status_id'];
        $this->load->model('Sale_model');
        $data['alert_flag'] = 1;
        $data['alert_message'] = " Client Id ".$data['c_name']." Status has been  Updated Successfully.";
        $this->Sale_model->client_status_update($data);
        $data['client_master_list']=$this->Sale_model->rep_wise_client_status_update_master_list($data);
		$this->load->view('client_list_for_rep_wise',$data);
		}
		else
			{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$data['role_name'] = $this->session->userdata('role_name');
				$data['email_id'] = $this->session->userdata('email_id');
				$this->load->model('Sale_model');
                 $data['client_master_list']=$this->Sale_model->rep_wise_client_status_update_master_list($data);
		        $this->load->view('client_list_for_rep_wise',$data);
			}
	}
	
	public function client_status_edit()
	{
	    $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
        $this->load->model('Sale_model');
        
        $data['d_id'] = $_POST['d_id2'];
        //$data['status_d_list']=$this->Sale_model->client_status_details_list($data);
        
        
        
        $data['client_s_e_list']=$this->Sale_model->client_status_edit($data);
        $data['s_id'] = $data['client_s_e_list'][0]['status'];
        
        //echo"ss".$data['s_id'] ;
        $data['status_list']=$this->Sale_model->status_master_list2($data);
		$this->load->view('client_status_edit',$data);
		
	}
	
	public function client_status_update2()
	{
	    if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{  
	    $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
        $this->session->set_userdata('form_ts',$this->input->post('TS'));
        $data['alert_flag'] = 0;
        $data['alert_message'] = "";
        $data['c_name']=$_POST['c_id'];
        $data['status_id']=$_POST['status_id'];
        $data['status']=0;
        //echo"ss".$data['status'];
        $this->load->model('Sale_model');
        $data['alert_flag'] = 1;
        $data['alert_message'] = " Client Id ".$data['c_name']." Status has been  Updated Successfully.";
        $this->Sale_model->client_status_update2($data);
        $data['client_master_list']=$this->Sale_model->rep_wise_client_status_update_master_list($data);
		$this->load->view('client_list_for_rep_wise',$data);
		}
		else
			{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$data['role_name'] = $this->session->userdata('role_name');
				$data['email_id'] = $this->session->userdata('email_id');
				$this->load->model('Sale_model');
                 $data['client_master_list']=$this->Sale_model->rep_wise_client_status_update_master_list($data);
		        $this->load->view('client_list_for_rep_wise',$data);
			}
	}
	
	
	public function client_list_ajx()
	{
	    $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
	     $this->load->model('Sale_model');
        
		$client_list=$this->Sale_model->client_list_by_id($data);
		echo json_encode($client_list);
	}
	
    public function client_list_for_rep_status_wise()
	{
	    $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
         $this->load->model('Sale_model');
         $data['s_id'] =0;
          $data['sr_list']=$this->Sale_model->sale_rep_list_by_id($data);
       // $data['client_master_list']=$this->Sale_model->rep_wise_client_status_update_master_list($data);
        $data['status_list']=$this->Sale_model->status_master_list2($data);
		$this->load->view('client_list_for_rep_status_wise',$data);
		
	}
	
	public function client_rep_status_wise_view()
	{
	    $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
         $this->load->model('Sale_model');
         $data['s_id'] =0;
         $data['s_rep_name']=$_POST['s_rep_name'];
        $data['status_id']=$_POST['status_id'];
          $data['client_master_list']=$this->Sale_model->client_rep_status_wise_view($data);
          $data['sr_list']=$this->Sale_model->sale_rep_list_by_id($data);
       // $data['client_master_list']=$this->Sale_model->rep_wise_client_status_update_master_list($data);
        $data['status_list']=$this->Sale_model->status_master_list2($data);
		$this->load->view('client_list_for_rep_status_wise',$data);
		
	}
	
	
	public function client_booked_appointment()
	{
	    $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
         $this->load->model('Sale_model');
         $data['status'] = 1;
        $data['client_master_list']=$this->Sale_model->rep_wise_client_status_update_master_list($data);
		$this->load->view('client_list_for_rep_wise2',$data);
		
	}
	
	public function client_confirmed_appointment()
	{
	    $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
         $this->load->model('Sale_model');
         $data['status'] = 2;
        $data['client_master_list']=$this->Sale_model->rep_wise_client_status_update_master_list($data);
		$this->load->view('client_list_for_rep_wise2',$data);
		
	}
	public function client_attended_appointment()
	{
	    $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
         $this->load->model('Sale_model');
         $data['status'] = 3;
        $data['client_master_list']=$this->Sale_model->rep_wise_client_status_update_master_list($data);
		$this->load->view('client_list_for_rep_wise2',$data);
		
	}
	
	public function client_purchased()
	{
	    $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
         $this->load->model('Sale_model');
         $data['status'] = 4;
        $data['client_master_list']=$this->Sale_model->rep_wise_client_status_update_master_list($data);
		$this->load->view('client_list_for_rep_wise2',$data);
		
	}
	
	public function client_completed()
	{
	    $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
         $this->load->model('Sale_model');
         $data['status'] = 5;
        $data['client_master_list']=$this->Sale_model->rep_wise_client_status_update_master_list($data);
		$this->load->view('client_list_for_rep_wise2',$data);
		
	}
	public function client_lost()
	{
	    $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
         $this->load->model('Sale_model');
         $data['status'] = 6;
        $data['client_master_list']=$this->Sale_model->rep_wise_client_status_update_master_list($data);
		$this->load->view('client_list_for_rep_wise2',$data);
		
	}
	
	public function client_status_edit2()
	{
	    $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
        $this->load->model('Sale_model');
        
        $data['d_id'] = $_POST['d_id2'];
        //$data['status_d_list']=$this->Sale_model->client_status_details_list($data);
        
        
        
        $data['client_s_e_list']=$this->Sale_model->client_status_edit($data);
        $data['s_id'] = $data['client_s_e_list'][0]['status'];
        
        //echo"ss".$data['s_id'] ;
        $data['status_list']=$this->Sale_model->status_master_list2($data);
		$this->load->view('client_status_edit2',$data);
		
	}
	
	public function client_status_update3()
	{
	    if($this->input->post('TS') != $this->session->userdata('form_ts'))
		{  
	    $data['role_id'] = $this->session->userdata('role_id');
        $data['user_id'] = $this->session->userdata('user_id');	
        $data['role_name'] = $this->session->userdata('role_name');
        $data['email_id'] = $this->session->userdata('email_id');
        $this->session->set_userdata('form_ts',$this->input->post('TS'));
        $data['alert_flag'] = 0;
        $data['alert_message'] = "";
        $data['c_name']=$_POST['c_id'];
        $data['status_id']=$_POST['status_id'];
        $data['status']=$data['status_id']-1;
        //echo"ss".$data['status'];
        $this->load->model('Sale_model');
        $data['alert_flag'] = 1;
        $data['alert_message'] = " Client Id ".$data['c_name']." Status has been  Updated Successfully.";
        $this->Sale_model->client_status_update2($data);
        $data['client_master_list']=$this->Sale_model->rep_wise_client_status_update_master_list($data);
		$this->load->view('client_list_for_rep_wise',$data);
		}
		else
			{
				$data['role_id'] = $this->session->userdata('role_id');
				$data['user_id'] = $this->session->userdata('user_id');
				$data['role_name'] = $this->session->userdata('role_name');
				$data['email_id'] = $this->session->userdata('email_id');
				$this->load->model('Sale_model');
                 $data['client_master_list']=$this->Sale_model->rep_wise_client_status_update_master_list($data);
		        $this->load->view('client_list_for_rep_wise',$data);
			}
	}
	
	
}
