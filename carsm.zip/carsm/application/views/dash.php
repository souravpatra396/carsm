<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>CARSM PORTAL | Dashboard</title>

    <link href="../../css/bootstrap.min.css" rel="stylesheet">
    <link href="../../font-awesome/css/font-awesome.css" rel="stylesheet">

    <!-- Toastr style -->
    <link href="../../css/plugins/toastr/toastr.min.css" rel="stylesheet">

    <!-- Gritter -->
    <link href="../../js/plugins/gritter/jquery.gritter.css" rel="stylesheet">

    <link href="../../css/animate.css" rel="stylesheet">
    <link href="../../css/style.css" rel="stylesheet">

</head>

<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav metismenu" id="side-menu">
                    <li class="nav-header">
                         <div class="dropdown profile-element">
                        <img alt="image" class="rounded-circle" src="<?php echo base_url(); ?>/img/shattered.png"/>
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="block m-t-xs font-bold"><?php echo $email_id;?></span>
                            <span class="text-muted text-xs block"><?php echo $role_name;?><b class="caret"></b></span>
                            
                            
                        </a>
                        <ul class="dropdown-menu animated fadeInRight m-t-xs">
                            <li><a class="dropdown-item" href="<?php echo site_url('Dealer/user_view'); ?>">Profile</a></li>
                             <li class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="<?php echo base_url(); ?>">Logout</a></li>
                        </ul>
                    </div>
                        <div class="logo-element">
                            CARSM PORTAL
                        </div>
                    </li>
                    <li >
                        <a href="index.html"><i class="fa fa-th-large"></i> <span class="nav-label">Campaign Master</span> <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                              <li><a href="<?php echo site_url('Campain/campain_master'); ?>">Campaign</a></li>
                              <li><a href="<?php echo site_url('Campain/all_camapaign_add'); ?>">Get Campaign</a></li>
                              <li><a href="<?php echo site_url('Campain/campaign_data_upload'); ?>">Campaign Data Upload</a></li>
                            
                        </ul>
                    </li>
                    <!--<li>
                        <a href="layouts.html"><i class="fa fa-diamond"></i> <span class="nav-label">Layouts</span></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-bar-chart-o"></i> <span class="nav-label">Graphs</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level collapse">
                            <li><a href="graph_flot.html">Flot Charts</a></li>
                            <li><a href="graph_morris.html">Morris.js Charts</a></li>
                            <li><a href="graph_rickshaw.html">Rickshaw Charts</a></li>
                            <li><a href="graph_chartjs.html">Chart.js</a></li>
                            <li><a href="graph_chartist.html">Chartist</a></li>
                            <li><a href="c3.html">c3 charts</a></li>
                            <li><a href="graph_peity.html">Peity Charts</a></li>
                            <li><a href="graph_sparkline.html">Sparkline Charts</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="mailbox.html"><i class="fa fa-envelope"></i> <span class="nav-label">Mailbox </span><span class="label label-warning float-right">16/24</span></a>
                        <ul class="nav nav-second-level collapse">
                            <li><a href="mailbox.html">Inbox</a></li>
                            <li><a href="mail_detail.html">Email view</a></li>
                            <li><a href="mail_compose.html">Compose email</a></li>
                            <li><a href="email_template.html">Email templates</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="metrics.html"><i class="fa fa-pie-chart"></i> <span class="nav-label">Metrics</span>  </a>
                    </li>
                    <li>
                        <a href="widgets.html"><i class="fa fa-flask"></i> <span class="nav-label">Widgets</span></a>
                    </li>//-->
                    <li >
                        <a href="dash.html"><i class="fa fa-edit"></i> <span class="nav-label">Dealer Master </span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level collapse">
                            <li><a href="<?php echo site_url('Admin/dealer_master'); ?>">Dealer List</a></li>
                            <!-- <li><a href="<?php echo site_url('Campain/campain_master'); ?>">Campaing</a></li>
                            <li><a href="form_basic.html">Basic form</a></li>
                            <li><a href="form_advanced.html">Advanced Plugins</a></li>
                            <li><a href="form_wizard.html">Wizard</a></li>
                            <li><a href="form_file_upload.html">File Upload</a></li>
                            <li><a href="form_editors.html">Text Editor</a></li>
                            <li><a href="form_autocomplete.html">Autocomplete</a></li>
                            <li><a href="form_markdown.html">Markdown</a></li>//-->
                        </ul>
                    </li>
                   <li>
                        <a href="#"><i class="fa fa-desktop"></i> <span class="nav-label">Client Master</span> </span><span class="fa arrow"></span> </a>
                        <ul class="nav nav-second-level collapse">
                           <li><a href="<?php echo site_url('Admin/client_master'); ?>">Client List</a></li>
                           <li><a href="<?php echo site_url('Excel_import/excel_upload'); ?>">Client File Upload</a></li>
                        </ul>
                    </li>
                    
                </ul>

            </div>
        </nav>

        <div id="page-wrapper" class="gray-bg dashbard-1">
        <div class="row border-bottom">
        <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
        <div class="navbar-header">
            <a class="navbar-minimalize minimalize-styl-2 btn btn-danger " href="#"><i class="fa fa-bars"></i> </a>
           
        </div>
            <ul class="nav navbar-top-links navbar-right">
                <li style="padding: 10px">
                    <span class="m-r-sm text-muted welcome-message">Welcome to Carsm Portal</span>
                </li>
                
                


                <li>
                    <a href="<?php echo base_url(); ?>">
                        <i class="fa fa-sign-out"></i> Log out
                    </a>
                </li>
                
            </ul>

        </nav>
        </div>
                
            
           <!-- <div class="wrapper wrapper-content animated fadeInRight">
            
             <form method="post" action=""   name="dealer_add" id="dealer_add" >
                               
                <div class="row">
                   
                    
                    <div class="col-sm-4">
                        <div class="form-group">
                           <b> <label class="col-form-label" for="d_name">Please Select Dealer </label></b>
                           
							<select name="d_name" id="d_name" class="form-control">
							    <option value="0"> All</option>
                                <?php if($dealer_list)
                                    {foreach($dealer_list as $d_list){ ?>
                                <option value="<?php echo $d_list['user_details_id'];?>"><?php echo $d_list['d_name']; ?></option>
                                    <?php }}?>
                            </select>
                        </div>
                    </div>
                    
                    
                </div>
				
	
                                
                              
                                 <div class="form-group row">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        
                                        <button class="btn btn-danger btn-sm" type="submit">Submit</button>
                                    </div>
                                </div>
				

                        <input type="hidden" id="TS" name="TS" value="<?php echo time();?>" />
                                
                                
                            </form>//-->
            
             <div class="wrapper wrapper-content animated fadeInRight">
            <div class="row">
                  <div class="col-lg-4">
                    <div class="widget lazur-bg p-xl">
                        <div class="row">
                            <div class="col-3">
                                <i class="fa fa-users fa-5x"></i>
                            </div>
                            <div class="col-9 text-right">
                                <span> Number Of Dealer In System </span>
                                <h2 class="font-bold"><?php echo $total_records[0]['dealer'];?></h2>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-4">
                    <div class="widget yellow-bg p-xl">
                        <div class="row">
                            <div class="col-3">
                                <i class="fa fa-users fa-5x"></i>
                            </div>
                            <div class="col-9 text-right">
                                <span> Number Of Client In System </span>
                                <h2 class="font-bold"><?php echo $total_records2[0]['client'];?></h2>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-4">
                <div class="widget navy-bg p-xl">
                    <div class="row">
                        <div class="col-2">
                            <i class="fa fa-trophy fa-5x"></i>
                        </div>
                        <div class="col-10 text-right">
                            <span> Number Of Records Trageted In Current Campaign </span>
                            <h2 class="font-bold"><?php echo $total_records3[0]['camp'];?></h2>
                        </div>
                    </div>
                </div>
            </div>
            
             
                
            </div>
            
            
            <div class="row">
                
                <div class="col-lg-4">
                <div class="widget red-bg p-xl">
                    <div class="row">
                        <div class="col-3">
                            <i class="fa fa-mail-forward fa-5x"></i>
                        </div>
                        <div class="col-9 text-right">
                            <span> Number Of Email Sent In Current Campaign </span>
                            <h2 class="font-bold"><?php echo $total_records3[0]['camp'];?></h2>
                        </div>
                    </div>
                </div>
            </div>
                
                  <div class="col-lg-4">
                    <div class="widget navy-bg p-xl">
                        <div class="row">
                            <div class="col-3">
                                <i class="fa fa-male fa-5x"></i>
                            </div>
                            <div class="col-9 text-right">
                                <span> Number Of PURL Visits</span>
                                <h2 class="font-bold"><?php echo $total_records3[0]['v_count'];?></h2>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-4">
                <div class="widget red-bg p-xl">
                    <div class="row">
                        <div class="col-4">
                            <i class="fa fa-check-square-o fa-5x"></i>
                        </div>
                        <div class="col-8 text-right">
                            <span> Number Of PURL Form Submissions </span>
                            <h2 class="font-bold"><?php echo $total_records3[0]['v_count2'];?></h2>
                        </div>
                    </div>
                </div>
            </div>
            
             
                
            </div>
            
            <div class="row">
                
                <div class="col-lg-4">
                <div class="widget navy-bg p-xl">
                    <div class="row">
                        <div class="col-4">
                            <i class="fa fa-lock fa-5x"></i>
                        </div>
                        <div class="col-8 text-right">
                            <span> Number Of Appoinments Booked </span>
                            <h2 class="font-bold">0</h2>
                        </div>
                    </div>
                </div>
            </div>
                
                
                
                
                  <div class="col-lg-4">
                    <div class="widget yellow-bg p-xl">
                        <div class="row">
                            <div class="col-3">
                                <i class="fa fa-taxi fa-5x"></i>
                            </div>
                            <div class="col-9 text-right">
                                <span> Number Of Cars Sold </span>
                                <h2 class="font-bold">0</h2>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-4">
                <div class="widget lazur-bg p-xl">
                    <div class="row">
                        <div class="col-3">
                            <i class="fa fa-location-arrow fa-5x"></i>
                        </div>
                        <div class="col-9 text-right">
                            <span> Total Of Client Locations In Canada </span>
                            <h2 class="font-bold">0</h2>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- <div class="col-lg-4">
                <div class="widget navy-bg p-xl">
                    <div class="row">
                        <div class="col-4">
                            <i class="fa fa-cloud fa-5x"></i>
                        </div>
                        <div class="col-8 text-right">
                            <span> Today degrees </span>
                            <h2 class="font-bold">26'C</h2>
                        </div>
                    </div>
                </div>
            </div>//-->
                
            </div>
            
            
            <input type="hidden" id="TS" name="TS" value="<?php echo time();?>" />
            
            

            
            </div>

            
           
            
            
             <div class="footer">
                
                <div>
                   <strong>Copyright</strong> Carsm Company &copy; 2020
                </div>
            </div>
            
            
                </div>

            </div>
        
           
        
       
        
        

    <!-- Mainly scripts -->
    <script src="../../js/jquery-3.1.1.min.js"></script>
    <script src="../../js/popper.min.js"></script>
    <script src="../../js/bootstrap.js"></script>
    <script src="../../js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="../../js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

    <!-- Flot -->
    <script src="../../js/plugins/flot/jquery.flot.js"></script>
    <script src="../../js/plugins/flot/jquery.flot.tooltip.min.js"></script>
    <script src="../../js/plugins/flot/jquery.flot.spline.js"></script>
    <script src="../../js/plugins/flot/jquery.flot.resize.js"></script>
    <script src="../../js/plugins/flot/jquery.flot.pie.js"></script>

    <!-- Peity -->
    <script src="../../js/plugins/peity/jquery.peity.min.js"></script>
    <script src="../../js/demo/peity-demo.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="../../js/inspinia.js"></script>
    <script src="../../js/plugins/pace/pace.min.js"></script>

    <!-- jQuery UI -->
    <script src="../../js/plugins/jquery-ui/jquery-ui.min.js"></script>

    <!-- GITTER -->
    <script src="../../js/plugins/gritter/jquery.gritter.min.js"></script>

    <!-- Sparkline -->
    <script src="../../js/plugins/sparkline/jquery.sparkline.min.js"></script>

    <!-- Sparkline demo data  -->
    <script src="../../js/demo/sparkline-demo.js"></script>

    <!-- ChartJS-->
    <script src="../../js/plugins/chartJs/Chart.min.js"></script>

    <!-- Toastr -->
    <script src="../../js/plugins/toastr/toastr.min.js"></script>
    
    
    
    <!-- Flot -->
    <script src="../../js/plugins/flot/jquery.flot.js"></script>
    <script src="../../js/plugins/flot/jquery.flot.tooltip.min.js"></script>
    <script src="../../js/plugins/flot/jquery.flot.resize.js"></script>
    <script src="../../js/plugins/flot/jquery.flot.pie.js"></script>
    <script src="../../js/plugins/flot/jquery.flot.time.js"></script>
	
	<!-- Flot demo data -->
    <script src="../../js/demo/flot-demo.js"></script>



    <script>
        $(document).ready(function() {
            setTimeout(function() {
                toastr.options = {
                    closeButton: true,
                    progressBar: true,
                    showMethod: 'slideDown',
                    timeOut: 4000
                };
                toastr.success( 'Welcome to Carsm Portal');

            }, 1300);


            var data1 = [
                [0,4],[1,8],[2,5],[3,10],[4,4],[5,16],[6,5],[7,11],[8,6],[9,11],[10,30],[11,10],[12,13],[13,4],[14,3],[15,3],[16,6]
            ];
            var data2 = [
                [0,1],[1,0],[2,2],[3,0],[4,1],[5,3],[6,1],[7,5],[8,2],[9,3],[10,2],[11,1],[12,0],[13,2],[14,8],[15,0],[16,0]
            ];
            $("#flot-dashboard-chart").length && $.plot($("#flot-dashboard-chart"), [
                data1, data2
            ],
                    {
                        series: {
                            lines: {
                                show: false,
                                fill: true
                            },
                            splines: {
                                show: true,
                                tension: 0.4,
                                lineWidth: 1,
                                fill: 0.4
                            },
                            points: {
                                radius: 0,
                                show: true
                            },
                            shadowSize: 2
                        },
                        grid: {
                            hoverable: true,
                            clickable: true,
                            tickColor: "#d5d5d5",
                            borderWidth: 1,
                            color: '#d5d5d5'
                        },
                        colors: ["#1ab394", "#1C84C6"],
                        xaxis:{
                        },
                        yaxis: {
                            ticks: 4
                        },
                        tooltip: false
                    }
            );

            var doughnutData = {
                labels: ["App","Software","Laptop" ],
                datasets: [{
                    data: [300,50,100],
                    backgroundColor: ["#a3e1d4","#dedede","#9CC3DA"]
                }]
            } ;


            var doughnutOptions = {
                responsive: false,
                legend: {
                    display: false
                }
            };


            var ctx4 = document.getElementById("doughnutChart").getContext("2d");
            new Chart(ctx4, {type: 'doughnut', data: doughnutData, options:doughnutOptions});

            var doughnutData = {
                labels: ["App","Software","Laptop" ],
                datasets: [{
                    data: [70,27,85],
                    backgroundColor: ["#a3e1d4","#dedede","#9CC3DA"]
                }]
            } ;


            var doughnutOptions = {
                responsive: false,
                legend: {
                    display: false
                }
            };


            var ctx4 = document.getElementById("doughnutChart2").getContext("2d");
            new Chart(ctx4, {type: 'doughnut', data: doughnutData, options:doughnutOptions});

        });
    </script>
</body>
</html>
