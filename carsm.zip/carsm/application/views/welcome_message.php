<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>CARSM | Login</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">

    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

</head>

 <link href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css" rel="stylesheet" />
   
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>  
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
   
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>

    
   <link href="https://cdnjs.cloudflare.com/ajax/libs/multiple-select/1.2.3/multiple-select.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.15/css/bootstrap-multiselect.css" rel="stylesheet" />
    
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    

<body class="gray-bg">

    <div class="middle-box text-center loginscreen animated fadeInDown">
        <div>
            
            <div>
                <img alt="image"  src="<?php echo base_url(); ?>/img/logo.jpeg"/>
                <!--<h6 class="logo-name">CARSM PORTAL</h6>//-->

            </div>
            <h3>Welcome to Carsm Portal</h3>
            
            <p>Login in. To see it in action.</p>
            <form class="m-t" role="form" action="index.php/Welcome/user_auth" method="post" id="login" >
                <div class="form-group">
                    <input type="email" class="form-control" placeholder="Username" id="UserEmail" name="email" required="">
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" placeholder="Password" id="pwd" name="password" required="">
                </div>
                <button type="submit"  onclick="checkemail();" class="btn btn-danger block full-width m-b">Login</button>
                <span id="email_status" style="color:red"></span>
                <a href="<?php echo site_url('User_reg/forget_password_entry'); ?>"><small><b>Forgot password?<b></small></a>
               <!--  <p class="text-muted text-center"><small>Do not have an account?</small></p>
                <a class="btn btn-sm btn-white btn-block" href="<?php echo site_url('User_reg/user_add'); ?>">Create an account</a>//-->
            </form>
           <!-- <p class="m-t"> <small>Inspinia we app framework base on Bootstrap 3 &copy; 2014</small> </p>//-->
        </div>
    </div>

    <!-- Mainly scripts -->
    <script>
     //document.getElementById('login').submit();
     </script>
    <script src="<?php echo base_url(); ?>/js/jquery-3.1.1.min.js"></script>
    <script src="<?php echo base_url(); ?>/js/popper.min.js"></script>
    <script src="<?php echo base_url(); ?>/js/bootstrap.js"></script>
    
    
<script type="text/javascript"> 

function checkemail()
{
  var user_email=document.getElementById("UserEmail").value;
  var user_pass = document.getElementById("pwd").value;
  
  if(user_email=='' || user_pass==''){
      $('#email_status').text('Enter valid Email/Password');
      return;
  }
  
 if(user_email)
 {
  $.ajax({
  method: 'post',
  dataType: 'json',
  url: 'http://dealeraddress.ca/index.php/User_reg/check_email',
  data: {
   u_email: user_email,
   u_pass: user_pass
  },
  success: function (response) {
    if(response[0].num<1){
   $('#email_status').text('Enter valid Email/Password');
   return;
    }else{
   $('#email_status').text('');
  document.getElementById('login').submit();
console.log('hi');
    }
   if(response=="OK")	
   {
       console.log(response);
     return true;	
   }
   else
   {
     return false;	
   }
  }
  });
 }
 else
 {
  $( '#email_status' ).html("");
  return false;
 }
}
</script>

</body>

</html>
