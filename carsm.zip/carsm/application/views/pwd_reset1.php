<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>CARSM | Login</title>

    <link href="<?php echo base_url(); ?>/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>/font-awesome/css/font-awesome.css" rel="stylesheet">

    <link href="<?php echo base_url(); ?>/css/animate.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>/css/style.css" rel="stylesheet">

</head>

<body class="gray-bg">

    <div class="middle-box text-center loginscreen animated fadeInDown">
        <div>
            <div>
            <span id="reg_message2"></span>
                 <div>
                <img alt="image"  src="<?php echo base_url(); ?>/img/logo.jpeg"/>
                <!--<h6 class="logo-name">CARSM PORTAL</h6>//-->

            </div>

            </div>
            <h3>Reset Password</h3>
            
            
            <?php 

            if($flag==1001)
            {?>
            <form class="m-t" role="form"  action="<?php echo base_url();?>index.php/User_reg/password_update"  method= "post" >
                
                <?php 
	  if(!empty($alert_message))
			{ echo $alert_message; }
							
							
						?>
						 <input type="hidden" id="token" name="token" value="<?php echo $token;?>">
                  <input type="hidden" id="user_id" name="user_id" value="<?php echo $user_id;?>">
                <div class="form-group">
                    <input type="password" value="" placeholder=" Enter Current Password" class="form-control" name="current_pwd" required> 
                </div>
                <div class="form-group">
                    <input type="password" value="" placeholder=" Enter New Password" class="form-control" name="new_pwd" required>
                </div>
                <div class="form-group">
                    <input type="password" value=""  placeholder=" Enter Confirm Password"class="form-control" name="confrm_pwd" required> 
                </div>
                
                
                <button type="submit" class="btn btn-danger block full-width m-b">Submit</button>

                 <!--<p class="text-muted text-center"><small>Already have an account?</small></p>
                <a class="btn btn-sm btn-white btn-block" href="<?php echo base_url(); ?>">Login</a>//-->
            </form><?php }?>
           <!-- <p class="m-t"> <small>Inspinia we app framework base on Bootstrap 3 &copy; 2014</small> </p>//-->
        </div>
    </div>
    
    
   

    <!-- Mainly scripts -->
    
    <script src="<?php echo base_url(); ?>/js/jquery-3.1.1.min.js"></script>
    <script src="<?php echo base_url(); ?>/js/popper.min.js"></script>
    <script src="<?php echo base_url(); ?>/js/bootstrap.js"></script>

</body>

</html>
