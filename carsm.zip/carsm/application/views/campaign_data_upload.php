<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

     <title>CARSM PORTAL | Dashboard</title>

    <link href="<?php echo base_url(); ?>/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>/font-awesome/css/font-awesome.css" rel="stylesheet">

    <!-- FooTable -->
    <link href="<?php echo base_url(); ?>/css/plugins/footable/footable.core.css" rel="stylesheet">

    <link href="<?php echo base_url(); ?>/css/animate.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>/css/style.css" rel="stylesheet">



</head>
<script>

 function view_p(d_id)
        {
            document.getElementById("d_id").value = d_id;
            document.getElementById("c6").submit();
        }
        
        function modi(c_id)
        {
            document.getElementById("d_id2").value = c_id;
            document.getElementById("c2").submit();
        }
</script>

<form name="c2" id="c2" action="sale_rep_assign_edit" method="post">
    <input type="hidden" id="d_id2" name="d_id2" />
</form>

<form name="c6" id="c6" action="sale_rep_assign_view_for_client"method="post">
    <input type="hidden" id="d_id" name="d_id"/>
</form>
<body>

    <div id="wrapper">

    <nav class="navbar-default navbar-static-side" role="navigation">
        <div class="sidebar-collapse">
            <ul class="nav metismenu" id="side-menu">
                <li class="nav-header">
                    <div class="dropdown profile-element">
                             <img alt="image" class="rounded-circle" src="<?php echo base_url(); ?>/img/shattered.png"/>
                            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                                
                                <span class="block m-t-xs font-bold"><?php echo $email_id;?></span>
                            <span class="text-muted text-xs block"><?php echo $role_name;?> <b class="caret"></b></span>
                            </a>
                            <ul class="dropdown-menu animated fadeInRight m-t-xs">
                                <li><a class="dropdown-item" href="<?php echo site_url('Dealer/user_view'); ?>">Profile</a></li>
                             <li class="dropdown-divider"></li>
                                
                                <li><a class="dropdown-item" href="<?php echo base_url(); ?>">Logout</a></li>
                            </ul>
                        </div>
                    <div class="logo-element">
                            CARSM PORTAL
                        </div>
                </li>
                
                <li class="active">
                        <a href="#"><i class="fa fa-th-large"></i> <span class="nav-label">Campaign Master</span> <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                              <li ><a href="<?php echo site_url('Campain/campain_master'); ?>">Campaign</a></li>
                              <li><a href="<?php echo site_url('Campain/all_camapaign_add'); ?>">Get Campaign</a></li>
                               <li class="active"><a href="<?php echo site_url('Campain/campaign_data_upload'); ?>">Campaign Data Upload</a></li>
                            
                        </ul>
                    </li>
                
                <li>
                        <a href="#"><i class="fa fa-edit"></i> <span class="nav-label">Dealer Master </span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level collapse">
                            <li><a href="<?php echo site_url('Admin/dealer_master'); ?>">Dealer List </a></li>
                            
                        </ul>
                    </li>
                    
                     <li>
                        <a href="#"><i class="fa fa-desktop"></i> <span class="nav-label">Client Master</span> </span><span class="fa arrow"></span> </a>
                        <ul class="nav nav-second-level collapse">
                           <li><a href="<?php echo site_url('Admin/client_master'); ?>">Client List</a></li>
                           <li><a href="<?php echo site_url('Excel_import/excel_upload'); ?>">Client File Upload</a></li>
                        </ul>
                    </li>
               
            </ul>

        </div>
    </nav>

        <div id="page-wrapper" class="gray-bg dashbard-1">
        <div class="row border-bottom">
        <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
        <div class="navbar-header">
            <a class="navbar-minimalize minimalize-styl-2 btn btn-danger " href="#"><i class="fa fa-bars"></i> </a>
            
        </div>
            <ul class="nav navbar-top-links navbar-right">
                <li class="breadcrumb-item">
                            <a href="<?php echo site_url('Admin/admin_module'); ?>"><strong>Home</strong></a>
                  
                       </li>
                <li style="padding: 10px">
                    <span class="m-r-sm text-muted welcome-message">Welcome to Carsm Portal</span>
                </li>
                


                <li>
                    <a href="<?php echo base_url(); ?>">
                        <i class="fa fa-sign-out"></i> Log out
                    </a>
                </li>
            </ul>

        </nav>
        </div>
        
        
                    <?php if($alert_flag == 1){?>
              <div class="alert alert-danger alert-dismissible">
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
              <?php echo $alert_message;?>
              </div>
              <?php }$alert_flag = 0;
              $alert_message = "" ?>
           
          <div class="wrapper wrapper-content animated fadeInRight ecommerce"> 
          
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox ">
                        <div class="ibox-title">
                            <h2><b>  Campaign Wise Data Upload</b></h2>
                            
                        </div>
                        <!--<div class="ibox-content">
                             <a class="btn btn-sm btn-danger " href="<?php echo site_url('Sale_rep/sale_rep_assign'); ?>">Assign</a>
                        </div>//-->
                        
                         <div class="ibox-content">
                            <form method="post" action="campain_data_add"   name="dealer_add" id="dealer_add" >
                               
                <div class="row">
                   
                    
                    <div class="col-sm-4">
                        <div class="form-group"  >
                           <b> <label class="col-form-label" for="c_name">Select Campaign</label></b>
                           
                           	<select name="campaign_id" id="campaign_id" class="form-control">
                                    
                            <?php if($campaign_id==''){?>
								<option selected="">Select Campaign</option>
								<?php if($camp_list)
                                    {foreach($camp_list as $d_list){ ?>
                                <option value="<?php echo $d_list['campaign_id'];?>"><?php echo $d_list['c_name']; ?></option>
                                    <?php }}?>
						<?php }else{?>
						<?php foreach($camp_list as $d_list){
						    if($d_list['campaign_id']==$campaign_id){?>
						    <option selected value="<?php echo $d_list['campaign_id'];?>"><?php echo  $d_list['c_name'];?></option>
						    <?php }else{?>
								<option value="<?php echo $d_list['campaign_id']; ?>"><?php echo  $d_list['c_name'];?></option>
								<?php }?>
						<?php }}?>
                                    
                                    
                                    
                                    
                                    
                            </select>
                        </div>
                    </div>
                    
                    
                    
                    
                </div>
				
				
			
				
				
                
				
		
                                         
                                         
                                    <!-- <input type="button" class="btn btn-secondary btn-lg my-2 pull-left" id="backk" value="Back" onclick="location.href='<?php echo base_url();?>index.php/Admin/dealer_master'"/>
                                       
                                       <input type="submit" class="btn btn-success  btn-lg my-2 pull-left" id="auto_click" value="Save" onclick="form_submit()"/>
                                    </div>
                                </div>//-->
                                
                                
                                 <div class="form-group row">
                                    <div class="col-sm-4 col-sm-offset-2">
                                       <!-- <button class="btn btn-dark btn-sm" type="button" onclick="location.href='<?php echo base_url();?>index.php/Sale_rep/rep_assign_list_for_client'">Back</button>-->
                                        <button class="btn btn-danger btn-sm" type="submit">Submit </button>
                                    </div>
                                </div>
				

                        <input type="hidden" id="TS" name="TS" value="<?php echo time();?>" />
                                
                                
                            </form>
                        </div>
                        
                    </div>
                </div>
                </div>
            

    
            
            
            
            

           


        </div>
        
        
        
        <div class="footer">
            
            <div>
                <strong>Copyright</strong> Carsm Company &copy; 2020
            </div>
        </div>

        </div>
        </div>



    <!-- Mainly scripts -->
    <script src="<?php echo base_url(); ?>/js/jquery-3.1.1.min.js"></script>
    <script src="<?php echo base_url(); ?>/js/popper.min.js"></script>
    <script src="<?php echo base_url(); ?>/js/bootstrap.js"></script>
    <script src="<?php echo base_url(); ?>/js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="<?php echo base_url(); ?>/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="<?php echo base_url(); ?>/js/inspinia.js"></script>
    <script src="<?php echo base_url(); ?>/js/plugins/pace/pace.min.js"></script>

    <!-- FooTable -->
    <script src="<?php echo base_url(); ?>/js/plugins/footable/footable.all.min.js"></script>

    <!-- Page-Level Scripts -->
    <script>
        $(document).ready(function() {

            $('.footable').footable();

        });

    </script>
    
     <script>
        
            $.ajax({
            url : "<?php echo site_url('Sale_rep/client_list_ajx');?>",
                    method : "POST",
                    async : true,
                    dataType : 'json',
                    success: function(data){
                        var html = '';
                        var i;
                        for(i=0; i<data.length; i++){
							
							
							
							
                            $("#client").append('<option value='+data[i].id+'>'+data[i].name+'</option>');
                            //html += '<option value='+data[i].client_id+'>'+data[i].client_name+'</option>';
                        }
                        $('#client').multiselect({
                        includeSelectAllOption: true,
                        buttonWidth: 500,
                        enableFiltering: true,
                        selectAll: true
						
                    });
                    
                    }
            });
			
			
    </script>

</body>

</html>
