<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>CARSM | Login</title>

    <link href="<?php echo base_url(); ?>/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>/font-awesome/css/font-awesome.css" rel="stylesheet">

    <link href="<?php echo base_url(); ?>/css/animate.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>/css/style.css" rel="stylesheet">

</head>

<body class="gray-bg">

    <div class="middle-box text-center loginscreen animated fadeInDown">
        <div>
            <div>
            <span id="reg_message2"></span>
                <h3 class="logo-name">CARSM PORTAL</h3>

            </div>
            <h3>Register to Carsm Portal</h3>
            
            <p>Create account to see it in action.</p>
            <form class="m-t" role="form"  method= "post">
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Name" id="Username" name="first_name" required="">
                </div>
                <div class="form-group">
                    <input type="email" class="form-control" placeholder="Email" id="email_reg" name="email" required="">
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Address" id="u_address" name="address" required="">
                </div>
                <div class="form-group">
                    <input type="number" class="form-control" placeholder="Phone No"  id="u_phone" name="c_telephone"required="">
                </div>
                
                <button type="submit" onclick="add_reg()" class="btn btn-primary block full-width m-b">Register</button>

                <p class="text-muted text-center"><small>Already have an account?</small></p>
                <a class="btn btn-sm btn-white btn-block" href="<?php echo base_url(); ?>">Login</a>
            </form>
           <!-- <p class="m-t"> <small>Inspinia we app framework base on Bootstrap 3 &copy; 2014</small> </p>//-->
        </div>
    </div>
    
    
    <script>
     //document.getElementById('login').submit();
     function add_reg(){
             var name=document.getElementById('Username').value;
             var email=document.getElementById('email_reg').value;
             var phone=document.getElementById('u_phone').value;
             var address=document.getElementById('u_address').value;
             if(name!='' && email!='' && phone!='' && address!=''){
                 $.ajax({
                    url: "http://purpuligo.com/carsm/index.php/User_reg/user_reg",
                    method: 'POST',
                    data: {email: email,
                        first_name: name,
                        c_telephone: phone,
                        address: address
                    },
                    //dataType : 'json',
                    async: 'true',
                    success: function(data){
                        console.log('data');
                        
                        if(data > 0){
                            document.getElementById('reg_message2').innerHTML="Registation Completed";
                            document.getElementById('reg_message2').style.color="green"
                    }else{
                        document.getElementById('reg_message2').innerHTML="Registation Not Completed";
                        document.getElementById('reg_message2').style.color="red";
                    }
                    }
              });
             }
         }
     
     </script>

    <!-- Mainly scripts -->
    
    <script src="<?php echo base_url(); ?>/js/jquery-3.1.1.min.js"></script>
    <script src="<?php echo base_url(); ?>/js/popper.min.js"></script>
    <script src="<?php echo base_url(); ?>/js/bootstrap.js"></script>

</body>

</html>
