<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

   <title>CARSM PORTAL | Dashboard</title>

    <link href="<?php echo base_url(); ?>/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>/font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>/css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>/css/animate.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>/css/style.css" rel="stylesheet">

    <link href="<?php echo base_url(); ?>/css/plugins/awesome-bootstrap-checkbox/awesome-bootstrap-checkbox.css" rel="stylesheet">

</head>

<body>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
      <script>

        $(document).ready(function(){
          $('#d_ph_no').mask('000-000-0000');
        });
        </script>

    <div id="wrapper">

    <nav class="navbar-default navbar-static-side" role="navigation">
        <div class="sidebar-collapse">
            <ul class="nav metismenu" id="side-menu">
                <li class="nav-header">
                    <div class="dropdown profile-element">
                        <img alt="image" class="rounded-circle" src="<?php echo base_url(); ?>/img/shattered.png"/>
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                           
                          <span class="block m-t-xs font-bold"><?php echo $email_id;?></span>
                            <span class="text-muted text-xs block"><?php echo $role_name;?> <b class="caret"></b></span>
                        </a>
                        <ul class="dropdown-menu animated fadeInRight m-t-xs">
                            <li><a class="dropdown-item" href="<?php echo site_url('Dealer/user_view'); ?>">Profile</a></li>
                             <li class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="<?php echo base_url(); ?>">Logout</a></li>
                        </ul>
                    </div>
                    <div class="logo-element">
                        CARSM PORTAL
                    </div>
                </li>
                
                <li class="active" >
                        <a href="#"><i class="fa fa-th-large"></i> <span class="nav-label">Campaign Master</span> <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                              <li class="active"><a href="<?php echo site_url('Campain/campain_master'); ?>">Campaign</a></li>
                              <li ><a href="<?php echo site_url('Campain/all_camapaign_add'); ?>">Get Campaign</a></li>
                               <li><a href="<?php echo site_url('Campain/campaign_data_upload'); ?>">Campaign Data Upload</a></li>
                            
                        </ul>
                    </li>

               <li>
                        <a href="#"><i class="fa fa-edit"></i> <span class="nav-label">Dealer Master</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level collapse">
                            <li><a href="<?php echo site_url('Admin/dealer_master'); ?>">Dealer List</a></li>
                            
                            
                        </ul>
                    </li>
                    
                     <li>
                        <a href="#"><i class="fa fa-desktop"></i> <span class="nav-label">Client Master</span> </span><span class="fa arrow"></span> </a>
                        <ul class="nav nav-second-level collapse">
                           <li><a href="<?php echo site_url('Admin/client_master'); ?>">Client List</a></li>
                           <li><a href="<?php echo site_url('Excel_import/excel_upload'); ?>">Client File Upload</a></li>
                        </ul>
                    </li>
               </ul>

        </div>
    </nav>

        <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
        <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
        <div class="navbar-header">
            <a class="navbar-minimalize minimalize-styl-2 btn btn-danger " href="#"><i class="fa fa-bars"></i> </a>
           
        </div>
            <ul class="nav navbar-top-links navbar-right">
                
                <li class="breadcrumb-item">
                            <a href="<?php echo site_url('Admin/admin_module'); ?>"><strong>Home</strong></a>
                  
                       </li>
                <li style="padding: 10px">
                    <span class="m-r-sm text-muted welcome-message">Welcome to Carsm Portal</span>
                </li>
                
                


                <li>
                    <a href="<?php echo base_url(); ?>">
                        <i class="fa fa-sign-out"></i> Log out
                    </a>
                </li>
            </ul>

        </nav>
        </div>
                    <div class="wrapper wrapper-content animated fadeInRight">
            
           
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox ">
                        <div class="ibox-title">
                            <h3>Campaign Edit</h3>
                            <div class="ibox-tools">
                                <a class="collapse-link">
                                    <i class="fa fa-chevron-up"></i>
                                </a>
                                
                                
                                
                            </div>
                        </div>
                        <div class="ibox-content">
                            
                        <?php 
                            if(!empty($campain_master_edit))
                            				
                            {
                            	foreach($campain_master_edit as $dealer){
                        ?> 
                        
                    <form method="post" name="dealer_add" id="dealer_add" action="campain_update">
                               
               <div class="row">
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label class="col-form-label" for="c_name"><b>Campaign Name</b></label>
                            <input type="text" id="c_name" name="c_name" value="<?php echo $dealer['campain_name'];?>" placeholder="Enter Campaign Name" class="form-control">
                        </div>
                    </div>
                    
                    <div class="col-sm-4">
                        <div class="form-group">
                           <b> <label class="col-form-label" for="d_name">Dealer name</label></b>
                           
							<select name="d_name" id="d_name" class="form-control">
							     <?php 
												 if(!empty($dealer_list))
												 {
												foreach($dealer_list as $p_list)
												 {
                                                    
										     if($p_list['user_details_id'] == $dealer['dealer_id'])               
                                            {
                                        ?>
                                    <option selected value="<?php echo $p_list['user_details_id'];?>"><?php echo $p_list['user_name'];?></option>
                                   <?php 
                                      }
                                    else
                                      {
                                   ?>
                                <option value="<?php echo $p_list['user_details_id'];?>"><?php echo $p_list['user_name'];?></option>
                               <?php 
                                 }
                                }
                               }                                           
                               ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label class="col-form-label" for="rec_t_in_camp"><b>Records Trageted In Current Campaign</b></label>
                            <input type="text" id="rec_t_in_camp" name="rec_t_in_camp"  value="<?php echo $dealer['records_t_in_campain'];?>"   placeholder="Enter Records Trageted In Current Campaign" class="form-control" required="required">
                        </div>
                    </div>
                    
                </div>
				
				
				<div class="row">
					
					<div class="col-sm-4">
                        <div class="form-group">
                            <label class="col-form-label" for="email_s_camp"><b>Email Sent In Current Campaign</b></label>
                            <input type="text" id="email_s_camp" name="email_s_camp" value="<?php echo $dealer['email_s_in_campain'];?>" placeholder="Enter Email Sent In Current Campaign" class="form-control">
                        </div>
                    </div>
					<div class="col-sm-4">
                        <div class="form-group">
                            <label class="col-form-label" for="no_of_p_vists"><b>Number Of PURL Visits</b></label>
                            <input type="text" id="no_of_p_vists" name="no_of_p_vists" value="<?php echo $dealer['no_of_purl_vists'];?>" placeholder="Enter Number Of PURL Visits" class="form-control">
                        </div>
                    </div>
                    
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label class="col-form-label" for="no_of_p_sub"><b>Number Of PURL Form Submissions</b></label>
                            <input type="text" id="no_of_p_sub" name="no_of_p_sub" value="<?php echo $dealer['no_of_purl_submission'];?>"  placeholder="Enter Number Of PURL Form Submissions" class="form-control">
                        </div>
                    </div>
				
				</div>
				<br>
				
                                <div class="form-group row">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <button class="btn btn-dark btn-sm" type="button" onclick="location.href='<?php echo base_url();?>index.php/Campain/campain_master'">Back</button>
                                        <button class="btn btn-danger btn-sm" type="submit">Save </button>
                                    </div>
                                </div>
                                
				

                        <input type="hidden" name="c_id" value="<?php echo $dealer['campain_id'];?>" >
                        <input type="hidden" id="TS" name="TS" value="<?php echo time();?>" />
                                
                                
                            </form><?php }} ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer">
            
            <div>
                <strong>Copyright</strong> Carsm Company &copy; 2020
            </div>
        </div>

        </div>
        </div>


    <!-- Mainly scripts -->
    <script src="<?php echo base_url(); ?>/js/jquery-3.1.1.min.js"></script>
    <script src="<?php echo base_url(); ?>/js/popper.min.js"></script>
    <script src="<?php echo base_url(); ?>/js/bootstrap.js"></script>
    <script src="<?php echo base_url(); ?>/js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="<?php echo base_url(); ?>/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="<?php echo base_url(); ?>/js/inspinia.js"></script>
    <script src="<?php echo base_url(); ?>/js/plugins/pace/pace.min.js"></script>

    <!-- iCheck -->
    <script src="<?php echo base_url(); ?>/js/plugins/iCheck/icheck.min.js"></script>
        <script>
            $(document).ready(function () {
                $('.i-checks').iCheck({
                    checkboxClass: 'icheckbox_square-green',
                    radioClass: 'iradio_square-green',
                });
            });
            
        </script>
        
        <script>
    $(document).ready(function(){
            $("#editcancel").click(function(){
                $("#dealer_add").submit(); // Submit the form
            });
            
        })
        
         </script>
      
</body>

</html>
