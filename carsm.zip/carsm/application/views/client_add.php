<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

   <title>CARSM PORTAL | Dashboard</title>

    <link href="<?php echo base_url(); ?>/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>/font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>/css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>/css/animate.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>/css/style.css" rel="stylesheet">

    <link href="<?php echo base_url(); ?>/css/plugins/awesome-bootstrap-checkbox/awesome-bootstrap-checkbox.css" rel="stylesheet">

</head>

<body>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
      <script>

        $(document).ready(function(){
          $('#d_ph_no').mask('000-000-0000');
        });
        </script>

    <div id="wrapper">

    <nav class="navbar-default navbar-static-side" role="navigation">
        <div class="sidebar-collapse">
            <ul class="nav metismenu" id="side-menu">
                <li class="nav-header">
                    <div class="dropdown profile-element">
                        <img alt="image" class="rounded-circle" src="<?php echo base_url(); ?>/img/shattered.png"/>
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                           
                          <span class="block m-t-xs font-bold"><?php echo $email_id;?></span>
                            <span class="text-muted text-xs block"><?php echo $role_name;?> <b class="caret"></b></span>
                        </a>
                        <ul class="dropdown-menu animated fadeInRight m-t-xs">
                             <li><a class="dropdown-item" href="<?php echo site_url('Dealer/user_view'); ?>">Profile</a></li>
                             <li class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="<?php echo base_url(); ?>">Logout</a></li>
                        </ul>
                    </div>
                    <div class="logo-element">
                        CARSM PORTAL
                    </div>
                </li>
                
                <li >
                        <a href="#"><i class="fa fa-th-large"></i> <span class="nav-label">Campaign Master</span> <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                              <li><a href="<?php echo site_url('Campain/campain_master'); ?>">Campaign</a></li>
                              <li ><a href="<?php echo site_url('Campain/all_camapaign_add'); ?>">Get Campaign</a></li>
                               <li><a href="<?php echo site_url('Campain/campaign_data_upload'); ?>">Campaign Data Upload</a></li>
                            
                        </ul>
                    </li>


               <li>
                        <a href="#"><i class="fa fa-edit"></i> <span class="nav-label">Dealer Master</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level collapse">
                            <li><a href="<?php echo site_url('Admin/dealer_master'); ?>">Dealer List </a></li>
                            
                        </ul>
                    </li>
                    
                    
                     <li class="active">
                        <a href="#"><i class="fa fa-desktop"></i> <span class="nav-label">Client Master</span> </span><span class="fa arrow"></span> </a>
                        <ul class="nav nav-second-level collapse">
                           <li class="active"><a href="<?php echo site_url('Admin/client_master'); ?>">Client List</a></li>
                           <li><a href="<?php echo site_url('Excel_import/excel_upload'); ?>">Client File Upload</a></li>
                        </ul>
                    </li>
               </ul>

        </div>
    </nav>

        <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
        <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
        <div class="navbar-header">
            <a class="navbar-minimalize minimalize-styl-2 btn btn-danger " href="#"><i class="fa fa-bars"></i> </a>
           
        </div>
            <ul class="nav navbar-top-links navbar-right">
                
                <li class="breadcrumb-item">
                            <a href="<?php echo site_url('Admin/admin_module'); ?>"><strong>Home</strong></a>
                  
                       </li>
                <li style="padding: 10px">
                    <span class="m-r-sm text-muted welcome-message">Welcome to Carsm Portal</span>
                </li>
                
                


                <li>
                    <a href="<?php echo base_url(); ?>">
                        <i class="fa fa-sign-out"></i> Log out
                    </a>
                </li>
            </ul>

        </nav>
        </div>
                    <div class="wrapper wrapper-content animated fadeInRight">
            
           
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox ">
                        <div class="ibox-title">
                            <h3>Client Add</h3>
                            <div class="ibox-tools">
                                <a class="collapse-link">
                                    <i class="fa fa-chevron-up"></i>
                                </a>
                                
                                
                                
                            </div>
                        </div>
                        <div class="ibox-content">
                            
                       
                        
                    <form method="post" name="dealer_add" id="dealer_add" action="client_reg">
                               
                <div class="row">
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label class="required" for="cl_f_name"><b>Client Frist Name</b></label>
                            <input type="text" id="cl_f_name" name="cl_f_name" value="<?php echo $client['first_name'];?>" placeholder="Enter Client Frist Name" class="form-control" required="required">
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label class="required" for="cl_l_name"><b>Client Last Name</b></label>
                            <input type="text" id="cl_l_name" name="cl_l_name" value="<?php echo $client['first_name'];?>"     placeholder="Enter Client Last Name" class="form-control" required="required">
                        </div>
                    </div>
                    
                    <div class="col-sm-4">
                        <div class="form-group">
                           <b> <label class="required" for="d_name">Dealer name</label></b>
                           
							<select name="d_name" id="d_name" class="form-control" required="required">
							    <option value="">Select Dealer name</option>
                                <?php if($dealer_list)
                                    {foreach($dealer_list as $d_list){ ?>
                                <option value="<?php echo $d_list['user_details_id'];?>"><?php echo $d_list['d_name']; ?></option>
                                    <?php }}?>
                            </select>
                        </div>
                    </div>
                    
                </div>
				
				
				<div class="row">
					
					<div class="col-sm-6">
                        <div class="form-group">
                            <label  class="required" for="cl_address1"><b>Client Address1</b></label>
                            <input type="text" id="cl_address1" name="cl_address1" value="<?php echo $client['address1'];?>" placeholder="Enter Client Address1" class="form-control" required="required">
                        </div>
                    </div>
					<div class="col-sm-6">
                        <div class="form-group">
                            <label class="required" for="cl_address2"><b>Client Address2</b></label>
                            <input type="text" id="cl_address2" name="cl_address2" value="<?php echo $client['address2'];?>" placeholder="Enter Client Address2" class="form-control" required="required">
                        </div>
                    </div>
				
				</div>
                <div class="row">
                    
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label class="required" for="cl_province"><b>Client Province</b></label>
                            
							<!--	<select name="cl_province" id="cl_province" class="form-control">
								    <option value="0" >Select Provience </option>
                                <option value="Alberta" selected>Alberta</option>
                                <option value="Ontario">Ontario</option>
								<option value="Yukon" >Yukon</option>
                                <option value="British Columbia">British Columbia</option>
                                <option value="Northwest Territory" >Northwest Territory</option>
                                <option value="Prince Edward Island">Prince Edward Island</option>
                            </select>//-->
                            <!--<input type="text" id="cl_province" name="cl_province" value="<?php echo $client['state'];?>" placeholder="Enter Client Province" class="form-control" required="required">-->
                        <select name="cl_province" id="cl_province" class="form-control">
                        <option value="">Select Province</option>
                                <?php if($province_list)
                                    {foreach($province_list as $d_list){ ?>
                                <option value="<?php echo $d_list['province_name'];?>"><?php echo $d_list['province_name']; ?></option>
                                    <?php }}?>
                                    
                                    </select>
                        </div>
                    </div>
                    
                    
                    
                     <div class="col-sm-4">
                        <div class="form-group">
                           <b> <label class="required" for="cl_city">Client City</label></b>
                           
							<!--<select name="cl_city" id="cl_city" class="form-control">
							     <option value="0" >Select City</option>
                                <option value="Eastern Alberta" selected>Eastern Alberta </option>
                                <option value="Calgary">Calgary</option>
								<option value="Banff" >Banff</option>
                                <option value="Barrhead">Barrhead</option>
                                <option value="Beaumont" >Beaumont</option>
                                <option value="Cold Lake">Cold Lake</option>
                            </select>//-->
                            <input type="text" id="cl_city" name="cl_city" value="<?php echo $client['city'];?>" placeholder="Enter Client city" class="form-control" required="required">
                       
                        </div>
                    </div>
				
					
                    
                   
                    
					<div class="col-sm-4">
                        <div class="form-group">
                            <label class="required" for="cl_p_code"><b>Client Postal Code</b></label>
                            <input type="text" id="cl_p_code" name="cl_p_code" value="<?php echo $client['postal_code'];?>" maxlength="6" placeholder="Enter Client Postal Code" class="form-control" required="required">
                        </div>
                    </div>
					
                </div>
				
				<div class="row">
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label class="col-form-label" for="cl_h_ph_no"><b>Client Home Phone No</b></label>
                            <input type="text" id="cl_h_ph_no" name="cl_h_ph_no" value="<?php echo $client['cl_h_ph_no'];?>" data-mask="999-999-9999" maxlength="10" placeholder="110-123-4567" class="form-control">
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label class="col-form-label" for="cl_b_ph_no"><b>Client Business Phone No</b></label>
                            <input type="text" id="cl_b_ph_no" name="cl_b_ph_no" value="<?php echo $client['b_ph_no'];?>" data-mask="999-999-9999" maxlength="10" placeholder="110-123-4567" class="form-control">
                        </div>
                    </div>
                    
                     <div class="col-sm-4">
                        <div class="form-group">
                            <label class="required" for="cl_c_ph_no"><b>Client Cell Phone No</b></label>
                            <input type="text" id="cl_c_ph_no" name="cl_c_ph_no" value="<?php echo $client['ph_no'];?>" data-mask="999-999-9999" maxlength="10" placeholder="110-123-4567" class="form-control" required="required">
                        </div>
                    </div>
                    
                </div>
				
				<div class="row">
                   
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label class="required" for="cl_email"><b>Client Email</b></label>
                            <input type="email" id="cl_email" name="cl_email" value="<?php echo $client['email_id'];?>" placeholder="Enter Client Email" class="form-control" required="required">
                        </div>
                    </div>
                    
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label class="col-form-label" for="d_n_cont_f"><b>Do Not Contact Field</b></label>
                            <input type="text" id="d_n_cont_f" name="d_n_cont_f" value="<?php echo $client['cl_do_not_contact_f'];?>" placeholder="Enter Do Not Contact Field" class="form-control">
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label class="col-form-label" for="d_n_email_f"><b>Do Not Email Field</b></label>
                            <input type="text" id="d_n_email_f" name="d_n_email_f" value="<?php echo $client['cl_do_no_email_f'];?>"   placeholder="Enter Do Not Email Field" class="form-control">
                        </div>
                    </div>
                    
                </div>
                
                
                
                 <div class="row">
                    
                    
                </div>
                
                 <div class="row">
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label class="col-form-label" for="cl_v_make"><b>Client Vehicle Make</b></label>
                            <input type="text" id="cl_v_make" name="cl_v_make" value="<?php echo $client['make'];?>" placeholder="Enter Client Vehicle Make" class="form-control">
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label class="col-form-label" for="cl_v_m_year"><b>Client Vehicle Model Year</b></label>
                            <input type="text" id="cl_v_m_year" name="cl_v_m_year" value="<?php echo $client['make_yr'];?>"   placeholder="Enter Client Vehicle Model Year" class="form-control">
                        </div>
                    </div>
                    
                     <div class="col-sm-4">
                        <div class="form-group">
                            <label class="col-form-label" for="cl_v_m"><b>Client Vehicle Model</b></label>
                            <input type="text" id="cl_v_m" name="cl_v_m" value="<?php echo $client['model'];?>" placeholder="Enter Client Vehicle Model" class="form-control">
                        </div>
                    </div>
                    
                </div>
                
                
                 <div class="row">
                    
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label class="col-form-label" for="cl_v_colour"><b>Client Vehicle Colour</b></label>
                            <input type="text" id="cl_v_colour" name="cl_v_colour" value="<?php echo $client['model_colour'];?>"   placeholder="Enter Client Vehicle Colour" class="form-control">
                        </div>
                    </div>
                    
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label class="col-form-label" for="cl_v_mileage"><b>Client Vehicle Mileage</b></label>
                            <input type="text" id="cl_v_mileage" name="cl_v_mileage" value="<?php echo $client['mileage'];?>" placeholder="Enter Client Vehicle Mileage" class="form-control">
                        </div>
                    </div>
                    
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label class="col-form-label" for="cl_v_vin"><b>Client Vehicle Vin</b></label>
                            <input type="text" id="cl_v_vin" name="cl_v_vin" value="<?php echo $client['vin'];?>" placeholder="Enter Client Vehicle Vin" class="form-control">
                        </div>
                    </div>
                    
                </div>
                
                
                
                 <div class="row">
                    
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="col-form-label" for="cl_v_del_date"><b>Client Vehicle Delivery Date</b></label>
                            <input type="text" id="cl_v_del_date" name="cl_v_del_date" value="<?php echo $client['delivery_date'];?>"   placeholder="Enter Client Vehicle Delivery Date" class="form-control">
                        </div>
                    </div>
                    
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="col-form-label" for="cl_v_l_ser_date"><b>Client Vehicle Last Service Date</b></label>
                            <input type="text" id="cl_v_l_ser_date" name="cl_v_l_ser_date" value="<?php echo $client['last_service'];?>" placeholder="Enter Client Vehicle Last Service Date" class="form-control">
                        </div>
                    </div>
                    
                </div>
                
				
				
				 <div class="row">
                    
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label class="col-form-label" for="cl_lati"><b>Client Latitude</b></label>
                            <input type="text" id="cl_lati" name="cl_lati" value="<?php echo $client['cl_latitude'];?>"   placeholder="Enter Client Latitude" class="form-control">
                        </div>
                    </div>
                    
                     <div class="col-sm-4">
                        <div class="form-group">
                            <label class="col-form-label" for="cl_longi"><b>Client Longitude</b></label>
                            <input type="text" id="cl_longi" name="cl_longi" value="<?php echo $client['cl_longitude'];?>" placeholder="Enter Client Longitude" class="form-control">
                        </div>
                    </div>
                    
                     <div class="col-sm-4">
                        <div class="form-group">
                            <label class="col-form-label" for="cl_dis_to_d"><b>Client Distance To Dealership</b></label>
                            <input type="text" id="cl_dis_to_d" name="cl_dis_to_d" value="<?php echo $client['dis_to_dealership'];?>"  placeholder="Enter Client Distance To Dealership" class="form-control">
                        </div>
                    </div>
                    
                </div>
				
				 <div class="row">
                   
                   
                    
                </div>
                
                 <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="col-form-label" for="cl_p_purl_code"><b>Client Postal Purl Code</b></label>
                            <input type="text" id="cl_p_purl_code" name="cl_p_purl_code" value="<?php echo $client['cl_postal_purl_code'];?>" placeholder="Enter Client Postal Purl Code" class="form-control">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="col-form-label" for="cl_e_purl_code"><b>Client Email Purl Code</b></label>
                            <input type="text" id="cl_e_purl_code" name="cl_e_purl_code" value="<?php echo $client['cl_email_purl_code'];?>"   placeholder="Enter Client Email Purl Code" class="form-control">
                        </div>
                    </div>
                    
                </div>
                
                 <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="col-form-label" for="cl_a_sale_rep"><b>Client Assigned Sales Rep</b></label>
                            <input type="text" id="cl_a_sale_rep" name="cl_a_sale_rep" value="<?php echo $client['sales_rep'];?>" placeholder="Enter Client Assigned Sales Rep" class="form-control">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="col-form-label" for="cl_l_c_d_w_s_rep"><b>Client Last Contact Date With Sales Rep</b></label>
                            <input type="text" id="cl_l_c_d_w_s_rep" name="cl_l_c_d_w_s_rep" value="<?php echo $client['cl_l_contact_with_s_rep'];?>"   placeholder="Enter Client Last Contact Date With Sales Rep" class="form-control">
                        </div>
                    </div>
                    
                </div>
                
                
                 <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="col-form-label" for="cl_l_c_d_v_postal_c"><b>Client Last Contact Date Via Postal Campaign</b></label>
                            <input type="text" id="cl_l_c_d_v_postal_c" name="cl_l_c_d_v_postal_c" value="<?php echo $client['cl_l_contact_v_p_comp'];?>" placeholder="Enter Client Last Contact Date Via Postal Campaign" class="form-control">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="col-form-label" for="cl_l_c_d_v_email_c"><b>Client Last Contact Date Via Email Campaign</b></label>
                            <input type="text" id="cl_l_c_d_v_email_c" name="cl_l_c_d_v_email_c" value="<?php echo $client['cl_l_contact_v_e_comp'];?>"   placeholder="Enter Client Last Contact Date Via Email Campaign"  class="form-control">
                        </div>
                    </div>
                    
                </div>
                
                 <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="col-form-label" for="cl_purl_v_no_of_tm"><b>Client Purl Visit Number Of Times</b></label>
                            <input type="text" id="cl_purl_v_no_of_tm" name="cl_purl_v_no_of_tm" value="<?php echo $client['cl_purl_v_no_of_item'];?>" placeholder="Enter Client Purl Visit Number Of Times" class="form-control">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="col-form-label" for="cl_purl_v_d_list"><b>Client Purl Visit Date List</b></label>
                            <input type="text" id="cl_purl_v_d_list" name="cl_purl_v_d_list" value="<?php echo $client['cl_purl_visit_date_list'];?>"   placeholder="Enter Client Purl Visit Date List" class="form-control">
                        </div>
                    </div>
                    
                </div>
                
                
                 <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="col-form-label" for="cl_purl_v_app_set"><b>Client Purl Visit Appoinment Set</b></label>
                            <input type="text" id="cl_purl_v_app_set" name="cl_purl_v_app_set" value="<?php echo $client['cl_purl_v_appointment_set'];?>" placeholder="Enter Client Purl Visit Appoinment Set" class="form-control">
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label class="col-form-label" for="cl_p_new_vehicle"><b>Client Purchased A New Vehicle</b></label>
                            <input type="text" id="cl_p_new_vehicle" name="cl_p_new_vehicle" value="<?php echo $client['cl_purchased_n_vehicle'];?>"   placeholder="Client Purchased A New Vehicle" class="form-control">
                        </div>
                    </div>
                    
                </div>
                
 
				
				
                                <div class="form-group row">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <button class="btn btn-dark btn-sm" type="button" onclick="location.href='<?php echo base_url();?>index.php/Admin/client_master'">Back</button>
                                        <button class="btn btn-danger btn-sm" id="submit-button" type="submit">Save </button>
                                    </div>
                                </div>
                                
				

                        
                        <input type="hidden" id="TS" name="TS" value="<?php echo time();?>" />
                                
                                
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer">
            
            <div>
                <strong>Copyright</strong> Carsm Company &copy; 2020
            </div>
        </div>

        </div>
        </div>


    <!-- Mainly scripts -->
    <script src="<?php echo base_url(); ?>/js/jquery-3.1.1.min.js"></script>
    <script src="<?php echo base_url(); ?>/js/popper.min.js"></script>
    <script src="<?php echo base_url(); ?>/js/bootstrap.js"></script>
    <script src="<?php echo base_url(); ?>/js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="<?php echo base_url(); ?>/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="<?php echo base_url(); ?>/js/inspinia.js"></script>
    <script src="<?php echo base_url(); ?>/js/plugins/pace/pace.min.js"></script>
    
    <!-- Input Mask-->
    <script src="<?php echo base_url(); ?>/js/plugins/jasny/jasny-bootstrap.min.js"></script>
    
    <!-- iCheck -->
    <script src="<?php echo base_url(); ?>/js/plugins/iCheck/icheck.min.js"></script>
        <script>
            $(document).ready(function () {
                $('.i-checks').iCheck({
                    checkboxClass: 'icheckbox_square-green',
                    radioClass: 'iradio_square-green',
                });
            });
            
        </script>
        
    <script>
    // $(document).ready(function(){
            // $("#editcancel").click(function(){
                // $("#dealer_add").submit(); // Submit the form
            // });
            
        // })
        
         </script>
         
<script>
    var form = document.getElementById('dealer_add');
    var submitButton = document.getElementById('submit-button');
    var sendButton = document.getElementById('send-button');
    
    sendButton.addEventListener('click', send);
    
    function send(e) {
        submitButton.click();
    }
        
</script>
 
      
<style>
  .required:after {
    content:" *";
    color: red;
  }
</style> 
      
</body>

</html>
