<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

   <title>CARSM PORTAL | Dashboard</title>

    <link href="<?php echo base_url(); ?>/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>/font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>/css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>/css/animate.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>/css/style.css" rel="stylesheet">

    <link href="<?php echo base_url(); ?>/css/plugins/awesome-bootstrap-checkbox/awesome-bootstrap-checkbox.css" rel="stylesheet">

</head>

<body>

    <div id="wrapper">

    <nav class="navbar-default navbar-static-side" role="navigation">
        <div class="sidebar-collapse">
            <ul class="nav metismenu" id="side-menu">
                <li class="nav-header">
                    <div class="dropdown profile-element">
                        <img alt="image" class="rounded-circle" src="<?php echo base_url(); ?>/img/shattered.png"/>
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                           
                           <span class="block m-t-xs font-bold"><?php echo $email_id;?></span>
                            <span class="text-muted text-xs block"><?php echo $role_name;?> <b class="caret"></b></span>
                        </a>
                        <ul class="dropdown-menu animated fadeInRight m-t-xs">
                             <li><a class="dropdown-item" href="<?php echo site_url('Dealer/user_view'); ?>">Profile</a></li>
                             <li class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="<?php echo base_url(); ?>">Logout</a></li>
                        </ul>
                    </div>
                    <div class="logo-element">
                        CARSM PORTAL
                    </div>
                </li>
                
                <li class="active">
                        <a href="dash.html"><i class="fa fa-edit"></i> <span class="nav-label">Client Master </span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level collapse">
                            <li class="active"><a href="<?php echo site_url('Dealer/client_master'); ?>">Client List</a></li>
                            <!--<li><a href="<?php echo site_url('Excel_import/excel_upload'); ?>">Client File Upload</a></li>//-->
                           
                        </ul>
                    </li>
                    
                    <li >
                        <a href="index.html"><i class="fa fa-th-large"></i> <span class="nav-label">SR Master</span> <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                              <li ><a href="<?php echo site_url('Sale_rep/sale_rep_master'); ?>">SR List</a></li>
                              <li ><a href="<?php echo site_url('Sale_rep/rep_assign_list_for_client'); ?>">Client Assign</a></li>
                            <li ><a href="<?php echo site_url('Sale_rep/client_list_for_rep_status_wise'); ?>">Client List</a></li>
                        </ul>
                    </li>
               </ul>

        </div>
    </nav>

        <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
        <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
        <div class="navbar-header">
            <a class="navbar-minimalize minimalize-styl-2 btn btn-danger " href="#"><i class="fa fa-bars"></i> </a>
           
        </div>
            <ul class="nav navbar-top-links navbar-right">
                <li class="breadcrumb-item">
                            <a href="<?php echo site_url('Dealer/dealer_module'); ?>"><strong>Home</strong></a>
                  
                       </li>
                <li style="padding: 10px">
                    <span class="m-r-sm text-muted welcome-message">Welcome to Carsm Portal</span>
                </li>
                
                


                <li>
                    <a href="<?php echo base_url(); ?>">
                        <i class="fa fa-sign-out"></i> Log out
                    </a>
                </li>
            </ul>

        </nav>
        </div>
                    <div class="wrapper wrapper-content animated fadeInRight">
            
           
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox ">
                        <div class="ibox-title">
                            <h3>Client Details View</h3>
                            <div class="ibox-tools">
                                <a class="collapse-link">
                                    <i class="fa fa-chevron-up"></i>
                                </a>
                                
                                
                                
                            </div>
                        </div>
                        
                         <?php 
            		                 if(!empty($client_master_view))
            							
            							{
            								foreach($client_master_view as $dealer){
						?>
                        
                        <div class="ibox-content">
                            <form method="get">
                                <div class="form-group  row">
                                    <div class="col-sm-3">
                                        <label ><b>Client Frist Name</b></label>
                                    </div>
                                       <div class="col-sm-3">
                                            <p><?php echo $dealer['first_name'];?></p>
                                        </div>
                                        
                                        
                                        <div class="col-sm-3">
									    <label><b>Client Last Name </b></label>
									</div>
                                        <div class="col-sm-3">
                                           <p><?php echo $dealer['last_name'];?></p>
                                        </div>
                                </div>
                                <div class="form-group  row">
                                    <div class="col-sm-3">
									    <label><b>Client Address1 </b></label>
									</div>
                                        <div class="col-sm-3">
                                           <p><?php echo $dealer['address1'];?></p>
                                        </div>
                                        
                                    <div class="col-sm-3">
									    <label><b>Client Address2 </b></label>
									</div>
                                        <div class="col-sm-3">
                                           <p><?php echo $dealer['address2'];?></p>
                                        </div>
                                </div>
                                
								<div class="form-group  row">
								    <div class="col-sm-3">
								     <label ><b>Client City</b></label>
								    </div>
                                        <div class="col-sm-3">
                                            <p><?php echo $dealer['city'];?></p>
                                        </div>
                                        
                                        <div class="col-sm-3">
								        <label><b>Client Province </b></label>
								    </div>
                                        <div class="col-sm-3">
                                             <p><?php echo $dealer['state'];?></p>
                                        </div>
									
                                </div>
                                
							
                                
							        <div class="form-group  row">
        								    <div class="col-sm-3">
        								        <label ><b>Client Postal Code</b></label>
        								        </div>
                                                <div class="col-sm-3">
                                                   <p><?php echo $dealer['postal_code'];?></p>
                                                </div>
                                                
                                                <div class="col-sm-3">
        								        <label ><b>Client Home Phone No</b></label>
        								        </div>
                                                <div class="col-sm-3">
                                                   <p><?php echo $dealer['cl_h_ph_no'];?></p>
                                                </div>
                                        </div>
                                        
                                        <div class="form-group  row">
                                                <div class="col-sm-3">
    									             <label><b>Client Business Phone No </b></label>
    									         </div>
                                                <div class="col-sm-3">
                                                    <p><?php echo $dealer['b_ph_no'];?></p>
                                                </div>
                                                
                                                <div class="col-sm-3">
    									             <label><b>Client Cell Phone No </b></label>
    									         </div>
                                                <div class="col-sm-3">
                                                    <p><?php echo $dealer['ph_no'];?></p>
                                                </div>
                                         </div>
                                         
                                        <div class="form-group  row">
                                            <div class="col-sm-3">
									            <label ><b>Client Email</b></label>
									        </div>
                                            <div class="col-sm-3">
                                                <p><?php echo $dealer['email_id'];?></p>
                                            </div>
                                            
                                            <div class="col-sm-3">
									            <label ><b>Do Not Contact Field</b></label>
									        </div>
                                            <div class="col-sm-3">
                                                <p><?php echo $dealer['cl_do_not_contact_f'];?></p>
                                            </div>
                                        </div>
                                
								
								<div class="form-group  row">
								    <div class="col-sm-3">
								    <label><b>Do Not Email Field</b></label>
								    </div>
                                        <div class="col-sm-3">
                                           <p><?php echo $dealer['cl_do_no_email_f'];?></p>
                                        </div>
                                        
                                        <div class="col-sm-3">
								    <label><b>Client Vehicle Make</b></label>
								    </div>
                                        <div class="col-sm-3">
                                           <p><?php echo $dealer['make'];?></p>
                                        </div>
                                </div>
                                <div class="form-group  row">
								    <div class="col-sm-3">
								   <label ><b>Client Vehicle Model Year</b></label>
								    </div>
                                        <div class="col-sm-3">
                                            <p><?php echo $dealer['make_yr'];?></p>
                                    </div>
                                    
                                    <div class="col-sm-3">
								   <label ><b>Client Vehicle Model</b></label>
								    </div>
                                        <div class="col-sm-3">
                                            <p><?php echo $dealer['model'];?></p>
                                    </div>
									
                                </div>
								
								<div class="form-group  row">
								     <div class="col-sm-3">
								    <label ><b>Client Vehicle Colour</b> </label>
								     </div>
                                        <div class="col-sm-3">
                                           <p><?php echo $dealer['model_colour'];?></p>
                                        </div>
                                        
                                    <div class="col-sm-3">
								        <label ><b>Client Vehicle Mileage</b> </label>
								     </div>
                                        <div class="col-sm-3">
                                           <p><?php echo $dealer['mileage'];?></p>
                                        </div>
									
                                </div>
								
							
                                
								<div class="form-group  row">
								     <div class="col-sm-3">
								    <label ><b>Client Vehicle Vin</b> </label>
								    </div>
                                         <div class="col-sm-3">
                                            <p><?php echo $dealer['vin'];?></p>
                                         </div>
                                         
                                         <div class="col-sm-3">
								    <label ><b>Client Vehicle Delivery Date</b> </label>
								    </div>
                                         <div class="col-sm-3">
                                            <p><?php echo $dealer['delivery_date'];?></p>
                                         </div>
									
                                </div>
                               
                               
                               
                               <div class="form-group  row">
								     <div class="col-sm-3">
								    <label ><b>Client Vehicle Last Service Date</b> </label>
								    </div>
                                         <div class="col-sm-3">
                                            <p><?php echo $dealer['last_service'];?></p>
                                         </div>
                                         
                                         <div class="col-sm-3">
								    <label ><b>Client Latitude</b> </label>
								    </div>
                                         <div class="col-sm-3">
                                            <p><?php echo $dealer['cl_latitude'];?></p>
                                         </div>
									
                                </div>
                                
                                 <div class="form-group  row">
								     <div class="col-sm-3">
								    <label ><b>Client Longitude</b> </label>
								    </div>
                                         <div class="col-sm-3">
                                            <p><?php echo $dealer['cl_longitude'];?></p>
                                         </div>
                                         
                                         <div class="col-sm-3">
								    <label ><b>Client Distance To Dealership</b> </label>
								    </div>
                                         <div class="col-sm-3">
                                            <p><?php echo $dealer['dis_to_dealership'];?></p>
                                         </div>
									
                                </div>
                                
                                
                                <div class="form-group  row">
								     <div class="col-sm-3">
								    <label ><b>Client Postal Purl Code</b> </label>
								    </div>
                                         <div class="col-sm-3">
                                            <p><?php echo $dealer['cl_postal_purl_code'];?></p>
                                         </div>
                                         
                                         <div class="col-sm-3">
								    <label ><b>Client Email Purl Code</b> </label>
								    </div>
                                         <div class="col-sm-3">
                                            <p><?php echo $dealer['cl_email_purl_code'];?></p>
                                         </div>
									
                                </div>
                                
                                
                                
                                <div class="form-group  row">
								     <div class="col-sm-3">
								    <label ><b>Client Assigned Sales Rep</b> </label>
								    </div>
                                         <div class="col-sm-3">
                                            <p><?php echo $dealer['sales_rep'];?></p>
                                         </div>
                                         
                                         <div class="col-sm-3">
								    <label ><b>Client Last Contact Date With Sales Rep</b> </label>
								    </div>
                                         <div class="col-sm-3">
                                            <p><?php echo $dealer['cl_l_contact_with_s_rep'];?></p>
                                         </div>
									
                                </div>
                                
                                
                                <div class="form-group  row">
								     <div class="col-sm-3">
								    <label ><b>Client Last Contact Date Via Postal Campaign</b> </label>
								    </div>
                                         <div class="col-sm-3">
                                            <p><?php echo $dealer['cl_l_contact_v_p_comp'];?></p>
                                         </div>
                                         
                                         <div class="col-sm-3">
								    <label ><b>Client Last Contact Date Via Email Campaign</b> </label>
								    </div>
                                         <div class="col-sm-3">
                                            <p><?php echo $dealer['cl_l_contact_v_e_comp'];?></p>
                                         </div>
									
                                </div>
                                
                                <div class="form-group  row">
								     <div class="col-sm-3">
								    <label ><b>Client Purl Visit Number Of Times</b> </label>
								    </div>
                                         <div class="col-sm-3">
                                            <p><?php echo $dealer['cl_purl_v_no_of_item'];?></p>
                                         </div>
                                         
                                         <div class="col-sm-3">
								    <label ><b>Client Purl Visit Date List</b> </label>
								    </div>
                                         <div class="col-sm-3">
                                            <p><?php echo $dealer['cl_purl_visit_date_list'];?></p>
                                         </div>
									
                                </div>
                                
                                <div class="form-group  row">
								     <div class="col-sm-3">
								    <label ><b>Client Purl Visit Appoinment Set</b> </label>
								    </div>
                                         <div class="col-sm-3">
                                            <p><?php echo $dealer['cl_purl_v_appointment_set'];?></p>
                                         </div>
                                         
                                         <div class="col-sm-3">
								    <label ><b>Client Purchased A New Vehicle</b> </label>
								    </div>
                                         <div class="col-sm-3">
                                            <p><?php echo $dealer['cl_purchased_n_vehicle'];?></p>
                                         </div>
									
                                </div>
							   
							   
                                   <div class="form-group row">
                                    <div class="col-sm-4 col-sm-offset-2">
                                         
                                        <button class="btn btn-dark btn-sm" type="button" onclick="location.href='<?php echo base_url();?>index.php/Dealer/client_master'">Back</button>
                                    </div>
                                </div>
                                
                                
                            </form><?php }} ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer">
            
            <div>
                <strong>Copyright</strong> Carsm Company &copy; 2020
            </div>
        </div>

        </div>
        </div>


    <!-- Mainly scripts -->
    <script src="<?php echo base_url(); ?>/js/jquery-3.1.1.min.js"></script>
    <script src="<?php echo base_url(); ?>/js/popper.min.js"></script>
    <script src="<?php echo base_url(); ?>/js/bootstrap.js"></script>
    <script src="<?php echo base_url(); ?>/js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="<?php echo base_url(); ?>/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="<?php echo base_url(); ?>/js/inspinia.js"></script>
    <script src="<?php echo base_url(); ?>/js/plugins/pace/pace.min.js"></script>

    <!-- iCheck -->
    <script src="<?php echo base_url(); ?>/js/plugins/iCheck/icheck.min.js"></script>
        <script>
            $(document).ready(function () {
                $('.i-checks').iCheck({
                    checkboxClass: 'icheckbox_square-green',
                    radioClass: 'iradio_square-green',
                });
            });
        </script>
</body>

</html>
