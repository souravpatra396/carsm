<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>
 <link  href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css" rel="stylesheet" />
    <link href="https://cdn.datatables.net/buttons/1.6.0/css/buttons.dataTables.min.css" rel="stylesheet" />
    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.0/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.0/js/buttons.colVis.min.js"></script>
    <script src="https://cdn.datatables.net/fixedcolumns/3.3.0/css/fixedColumns.dataTables.min.css"></script>
	
	<script src="https://cdn.datatables.net/fixedcolumns/3.3.0/js/dataTables.fixedColumns.min.js"></script>

<script>

 function view_p(d_id)
        {
            document.getElementById("d_id").value = d_id;
            document.getElementById("c6").submit();
        }
        
        function modi(c_id)
        {
            document.getElementById("d_id2").value = c_id;
            document.getElementById("c2").submit();
        }
</script>

<form name="c2" id="c2" action="client_edit" method="post">
    <input type="hidden" id="d_id2" name="d_id2" />
</form>

<form name="c6" id="c6" action="client_view"method="post">
    <input type="hidden" id="d_id" name="d_id"/>
</form>
<body>

    

    

        <div id="page-wrapper" class="gray-bg dashbard-1">
       
           
          <div class="wrapper wrapper-content animated fadeInRight ecommerce"> 
          
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox ">
                        <div class="ibox-title">
                            <h2><b>Client list</b></h2>
                            
                        </div>
                       <!-- <div class="ibox-content">
                             <a class="btn btn-sm btn-primary " href="<?php echo site_url('Admin/dealer_add'); ?>">Add</a>
                        </div>//-->
                    </div>
                </div>
                </div>
            

                    <?php if($alert_flag == 1){?>
              <div class="alert alert-danger alert-dismissible">
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
              <?php echo $alert_message;?>
              </div>
              <?php }$alert_flag = 0;
              $alert_message = "" ?>


            

            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox">
                        <div class="ibox-content">

                            <table id="example" class="footable table table-stripped toggle-arrow-tiny" >
        <thead>
            <tr>
                <th>Client Fast Name</th>
                <th>Client last Name</th>
                <th>Phone No</th>
				 <th>Primary Name</th>
                <th>Address</th>
                <th>Metro / Agent Shiptrack Id</th>
                <th>HST/GST No.</th>
                <th>Primary Phone No</th>
                <th>Primary E-mail</th>
                <th>Secondary Contact</th>
                <th>Secondary E-mail</th>
                <th>Secondary Phone</th>
                 <th> Province Name</th>
                 <th> City </th>
                 <th> Postal Code</th>
                 <th>HST</th>
                 <th>PST</th>
                 <th>QST</th>
                <th>Action</th>
            </tr>
        </thead>
        
        <tbody>
            
            <?php if($data){
                  foreach($data as $master_list){ ?>
            <tr>
                <td><?php echo $master_list['first_name'];?></td>
                <td><?php echo $master_list['first_name'];?></td>
                <td><?php echo $master_list['first_name'];?></td>
                <td><?php echo $master_list['first_name'];?></td>
                 <td><?php echo $master_list['first_name'];?></td>
                <td><?php echo $master_list['first_name'];?></td>
                <td><?php echo $master_list['first_name'];?></td>
               
                <td><?php echo $master_list['first_name'];?></td>
                <td><?php echo $master_list['first_name'];?></td>
                <td><?php echo $master_list['first_name'];?></td>
                <td><?php echo $master_list['first_name'];?></td>
                <td><?php echo $master_list['first_name'];?></td>
                <td><?php echo $master_list['first_name'];?></td>
                <td><?php echo $master_list['first_name'];?></td>
                <td><?php echo $master_list['first_name'];?></td>
                 <td><?php echo $master_list['first_name'];?></td>
                <td><?php echo $master_list['first_name'];?></td>
                <td><?php echo $master_list['first_name'];?></td>
                
            </tr>
            <?php }}?>
        </tbody>
        

    </table>

                        </div>
                    </div>
                </div>
            </div>


        </div>
        
        
        
       

        </div>
        



    <!-- Mainly scripts -->
    <script src="<?php echo base_url(); ?>/js/jquery-3.1.1.min.js"></script>
    <script src="<?php echo base_url(); ?>/js/popper.min.js"></script>
    <script src="<?php echo base_url(); ?>/js/bootstrap.js"></script>
    <script src="<?php echo base_url(); ?>/js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="<?php echo base_url(); ?>/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="<?php echo base_url(); ?>/js/inspinia.js"></script>
    <script src="<?php echo base_url(); ?>/js/plugins/pace/pace.min.js"></script>

    <!-- FooTable -->
    <script src="<?php echo base_url(); ?>/js/plugins/footable/footable.all.min.js"></script>

    <!-- Page-Level Scripts -->
    <script>
        $(document).ready(function() {

            $('.footable').footable();

        });

    </script>
    
      <script>
    
       $(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        columnDefs: [
            {
                targets: 1,
                className: 'noVis'
            }
        ],
        buttons: [
            {
                extend: 'colvis',
                columns: ':not(.noVis)'
            }
        ],
        "scrollX": true,
        "order": [[ 0, "desc" ]],
		
		
    } );
	
} );
	var table = $('#example').DataTable();
    table.columns( [1,2] ).visible(true);
    table.columns.adjust().draw( false );
    
  

        
        function modi(c_id)
        {
            document.getElementById("agent_id2").value = c_id;
            document.getElementById("c2").submit();
        }
        
        function module_list()
        {
            document.getElementById("c3").submit();
        }
        
        function view_p(d_id)
        {
            document.getElementById("agent_id6").value = d_id;
            document.getElementById("c6").submit();
        }
        
        function ag_delete(c_id)
        {
            var conirm_delete = confirm("You are about to Delete Agent ID "+c_id+ " . Please confirm ?")
            if (conirm_delete == true) { 
                document.getElementById("agent_id3").value = c_id;
                document.getElementById("c4").submit();
            } else { 
                return;
            } 
            
        }
        
        function agent_reg()
        {
            document.getElementById("c5").submit();
        }
        
        $(document).ready(function(){
            $("#agadd").click(function(){
                $("#c5").submit(); // Submit the form
            });
            $("#agedit").click(function(){
                $("#c3").submit(); // Submit the form
            });
        })


    
</script>

</body>

</html>
