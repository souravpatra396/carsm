<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>CARSM | Login</title>

    <link href="<?php echo base_url(); ?>/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>/font-awesome/css/font-awesome.css" rel="stylesheet">

    <link href="<?php echo base_url(); ?>/css/animate.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>/css/style.css" rel="stylesheet">

</head>

<body class="gray-bg">

    <div class="middle-box text-center loginscreen animated fadeInDown">
        <div>
            <div>
           
               <div>
                <img alt="image"  src="<?php echo base_url(); ?>/img/logo.jpeg"/>
                <!--<h6 class="logo-name">CARSM PORTAL</h6>//-->

            </div>

            </div>
            <h3>Forget Password</h3>
            
           
            
            <form class="m-t" role="form"  action="<?php echo base_url();?>index.php/User_reg/forget_password"  method= "post" >
                 
               
						 <input type="hidden" id="token" name="token" value="<?php echo $token;?>">
                  <input type="hidden" id="user_id" name="user_id" value="<?php echo $user_id;?>">
                <div class="form-group">
                    <input type="email" value="" placeholder=" Enter Your Email Id" id="UserEmail" class="form-control" name="u_email" required> 
                </div>
                
                
                
                <button type="submit" onclick="myFunction()"class="btn btn-danger block full-width m-b">Submit</button>
                <a class="btn btn-sm btn-dark btn-block" href="<?php echo base_url(); ?>">Back</a>

                 <!--<p class="text-muted text-center"><small>Already have an account?</small></p>
                <a class="btn btn-sm btn-white btn-block" href="<?php echo base_url(); ?>">Login</a>//-->
            </form>
           <!-- <p class="m-t"> <small>Inspinia we app framework base on Bootstrap 3 &copy; 2014</small> </p>//-->
        </div>
    </div>
    
   <script> 
   function myFunction()
{
  var user_email=document.getElementById("UserEmail").value;
 
  
  if(user_email!=='' ){
    alert("Do You Want To Submit The Email Id ??" );
      return;
  }
    else{
        
    }
}
</script>
    <!-- Mainly scripts -->
    
    <script src="<?php echo base_url(); ?>/js/jquery-3.1.1.min.js"></script>
    <script src="<?php echo base_url(); ?>/js/popper.min.js"></script>
    <script src="<?php echo base_url(); ?>/js/bootstrap.js"></script>

</body>

</html>
