<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Upload_model extends CI_Model
{
     private $_batchImport;
    public function __construct()
    {
        parent::__construct();
		//$this->load->database();
    }
    
   
    public function dealer_reg($data)
    {
        $sql="CALL dealer_reg('".$data['d_name']."','".$data['d_ph_no']."','".$data['d_address1']."','".$data['d_address2']."',".$data['d_province'].",".$data['d_city'].",'".$data['d_p_code']."','".$data['d_website']."','".$data['d_p_web_domain']."','".$data['d_p_email']."','".$data['d_s_r_nm']."')";
        $rs=$this->db->query($sql);
        //echo $sql;
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
        
    }
    
     public function setBatchImport($batchImport) {
        $this->_batchImport = $batchImport;
    }
 
    // save data
    public function importData() {
        $data = $this->_batchImport;
        $this->db->insert_batch('import', $data);
    }
    // get employee list
    public function employeeList() {
        $this->db->select(array('e.id', 'e.first_name', 'e.last_name', 'e.email', 'e.dob', 'e.contact_no'));
        $this->db->from('import as e');
        $query = $this->db->get();
        return $query->result_array();
    }
	

  
   
     
 }


?>
