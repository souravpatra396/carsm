<?php
class Excel_import_model extends CI_Model
{
	function select()
	{
		$this->db->order_by('id', 'DESC');
		$query = $this->db->get('import');
		return $query;
	}

	function insert($data)
	{
	    $this->db->truncate('import');
		$this->db->insert_batch('import', $data);
	}
	
	public function client_data_update($data)
    {
        $sql="CALL excel_data_insert(".$data['user_id1'].")";
		
        $rs=$this->db->query($sql);
        $this->db->truncate('import');
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            //$rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    function truncate()
	{
	    $this->db->truncate('import');
	}
	
}
