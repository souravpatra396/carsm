<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
		//$this->load->database();
    }
    
    public function user_auth($data)
    {
        $sql="CALL user_authentication('".$data['email']."','".$data['password']."')";
        //echo$sql;
		$rs=$this->db->query($sql);
        if($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           // $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            //$rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function page_access($data)
    {
        $sql="CALL bye_user_access_update('".$data['arr_add']."','".$data['arr_edit']."','".$data['arr_view']."','".$data['arr_delete']."','".$data['arr_page_id']."',".$data['user_id2'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
        
    }
    
    public function role_master_list()
    {
        $sql="CALL bye_role_master_list()";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
        
    }
    
    public function user_master_list_by_role($data)
    {
        $sql="CALL bye_user_master_list_by_role(".$data['role_id2'].")";
        
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
        
    }

    public function bye_user_page_access_list($data)
    {
        $sql="CALL bye_user_page_access_list(".$data['role_id2'].",".$data['user_id2'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
        
    }
    
    public function bye_user_master_list()
    {
        $sql="CALL user_master_list()";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
        
    }
    public function user_registration($data)
    {
        $sql="CALL user_registration('".$data['email']."','".$data['first_name']."','".$data['phone']."','".$data['address']."','".$data['password']."',".$data['dealer_id_new'].",".$data['role_id1'].")";
        
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
        
    }
	
	 public function user_registration2($data)
    {
         $sql="CALL user_registration2('".$data['email']."','".$data['first_name']."','".$data['phone']."','".$data['address']."','".$data['password']."',".$data['dealer_id_new'].",".$data['role_id1'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
        
    }
    
    public function bye_user_view_list($data)
    {
        $sql="CALL bye_user_view_list(".$data['mem_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();
            return 0;
        }
    }
    
    
    public function bye_user_delete($data)
    {
        $sql="CALL bye_user_delete(".$data['mem_id'].")";
        $rs=$this->db->query($sql);
        
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();
            return 0;
        }
    }
    
      public function bye_user_edit($data)
    {
        $sql="CALL bye_user_edit(".$data['mem_id'].")";
        $rs=$this->db->query($sql);
        
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();
            return 0;
        }
    }
    
    public function bye_user_update($data)
    {
        $sql="CALL bye_user_update(".$data['user_id'].",'".$data['password']."')";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
        
    }
    
    public function bye_user_update2($data)
    {
        $sql="CALL bye_user_update2(".$data['user_id'].",'".$data['password']."')";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
        
    }
    
    public function bye_user_update3($data)
    {
        $sql="CALL bye_user_update_renew(".$data['user_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
        
    }
	
	public function bye_user_update4($data)
    {
        $sql="CALL bye_user_active_update(".$data['user_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
        
    }
    
    
    
    
    
    public function user_access_list_by_page($data)
    {
        $sql="CALL bye_get_user_access_by_page(".$data['page_id'].",".$data['user_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
        
    }
    
    public function user_access_list_by_module($data)
    {
        $sql="CALL bye_get_user_access_list_module(".$data['user_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
        
    }
    public function user_access_list_by_module2($data)
    {
        $sql="CALL bye_get_user_access_list_module(".$data['user_id2'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
        
    }
    
    public function user_module_access_update($data)
    {
        $sql="CALL bye_user_module_access_update('".$data['arr_view']."','".$data['arr_module_id']."',".$data['user_id2'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
        
    }


    public function token_verification($data)
    {
        $sql="CALL token_verification('".$data['token']."')";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            //$rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
        
    }
    
	public function forget_password($data)
    {
        $sql="CALL bye_forget_password('".$data['u_email']."')";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           // $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
        
    }

	public function password_reset($data)
    {
        $sql="CALL bye_reset_password(".$data['user_id'].",'".$data['token']."','".$data['new_pwd']."','".$data['current_pwd']."')";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            //$rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
        
    }
    
    
      public function bye_user_access_master_list()
            {
                $sql="CALL bye_user_access_master_list()";
                $rs=$this->db->query($sql);
                if ($rs->num_rows() > 0)
                {
                    $results=$rs->result_array();
                    $rs->next_result();
                    $rs->free_result();
                    return $results;
                }
                else
                {
                    $rs->next_result();
                    $rs->free_result();
        
                    return 0;
                }
                
            }
   public function mail_validation($data)
     {
		$sql="CALL bye_mail_validation('".$data['user_mail']."')";
		$rs=$this->db->query($sql);
		if ($rs->num_rows() > 0)
		{
			$results=$rs->result_array();
			$rs->next_result();
			$rs->free_result();
			return $results;
		}
		else
		{
			$rs->next_result();
			$rs->free_result();

			return 0;
		}
                
     }
	 
	 
	 
	   public function agent_client_mail_validation($data)
     {
		$sql="CALL bye_mail_validation_agent_client('".$data['user_mail']."',".$data['flg'].")";
		$rs=$this->db->query($sql);
		if ($rs->num_rows() > 0)
		{
			$results=$rs->result_array();
			$rs->next_result();
			$rs->free_result();
			return $results;
		}
		else
		{
			$rs->next_result();
			$rs->free_result();

			return 0;
		}
                
     }
     
     public function check_user_email($data){
        $sql="CALL user_email_check('".$data['email']."','".$data['pass']."')";
        echo $sql;
		$rs=$this->db->query($sql);
		if ($rs->num_rows() > 0)
		{
			$results=$rs->result_array();
		//	$rs->next_result();
			$rs->free_result();
			return $results;
		}
		else
		{
			$rs->next_result();
			$rs->free_result();

			return 0;
		}
    }
     
 }


?>
