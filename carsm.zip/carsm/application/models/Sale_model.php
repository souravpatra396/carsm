<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Sale_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
		//$this->load->database();
    }
    
   
    public function sale_rep_reg($data)
    {
        $sql="CALL sale_representative_reg('".$data['s_rep_name']."','".$data['s_rep_email']."','".$data['s_rep_address']."','".$data['s_rep_ph_no']."',".$data['user_id'].")";
        $rs=$this->db->query($sql);
        //echo $sql;
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
        
    }
    
     public function sale_rep_update($data)
    {
        $sql="CALL sale_representative_update('".$data['s_rep_name']."','".$data['s_rep_email']."','".$data['s_rep_address']."','".$data['s_rep_ph_no']."',".$data['s_rep_id'].",".$data['user_id'].")";
        $rs=$this->db->query($sql);
        //echo $sql;
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           //$rs->next_result();
            $rs->free_result();

            return 0;
        }
        
    }
	

    
    	public function sale_rep_list($data)
    {
        $sql="CALL sale_rep_list_by_id(".$data['user_id'].")";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           // $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function sale_rep_list_view($data)
    {
        $sql="CALL sale_representative_edit(".$data['d_id'].")";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function sale_rep_edit($data)
    {
        $sql="CALL sale_representative_edit(".$data['d_id2'].")";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           //$rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    
    public function client_list_by_id($data)
    {
        $sql="CALL client_list_by_id(".$data['user_id'].")";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function sale_rep_list_by_id($data)
    {
        $sql="CALL sale_rep_list_by_id(".$data['user_id'].")";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function rep_assign_update($data)
    {
        $sql="CALL rep_assign_update('".$data['c_name']."',".$data['s_rep_name'].")";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           // $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function assign_list_for_client($data)
    {
        $sql="CALL assign_list_for_client(".$data['user_id'].")";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
     public function sale_rep_assign_view_for_client($data)
    {
        $sql="CALL sale_rep_assign_view_for_client(".$data['d_id'].")";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
     public function sale_rep_assign_edit_for_client($data)
    {
        $sql="CALL sale_rep_assign_view_for_client(".$data['d_id'].")";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
     public function rep_wise_client_master_list($data)
    {
        $sql="CALL rep_wise_client_list(".$data['user_id'].")";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function status_master_list()
    {
        $sql="CALL status_master_list()";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function client_status_update($data)
    {
        $sql="CALL client_status_update(".$data['c_name'].",".$data['status_id'].",".$data['user_id'].")";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           // $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
  
   public function client_status_details_list($data)
    {
        $sql="CALL client_status_details_list(".$data['d_id'].")";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
     public function rep_wise_client_master_list2($data)
    {
        $sql="CALL rep_wise_client_list2(".$data['user_id'].")";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
     public function rep_wise_client_status_update_master_list($data)
    {
        $sql="CALL rep_wise_client_status_update_master_list(".$data['user_id'].",".$data['status'].")";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    
     public function client_status_edit($data)
    {
        $sql="CALL client_status_edit(".$data['d_id'].")";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function status_master_list2($data)
    {
        $sql="CALL status_master_list2(".$data['s_id'].")";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
     public function client_status_update2($data)
    {
        $sql="CALL client_status_update2(".$data['c_name'].",".$data['status_id'].")";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           // $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
     public function client_rep_status_wise_view($data)
    {
        $sql="CALL client_rep_status_wise_view(".$data['s_rep_name'].",".$data['status_id'].")";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
     public function sale_rep_dashboard_view($data)
    {
        $sql="CALL sr_dashboard_view(".$data['user_id'].")";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
     
 }


?>
