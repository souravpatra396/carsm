<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
		//$this->load->database();
    }
    
   
    public function dealer_reg($data)
    {
        $sql="CALL dealer_reg('".$data['d_name']."','".$data['d_ph_no']."','".$data['d_address1']."','".$data['d_address2']."',".$data['d_province'].",".$data['d_city'].",'".$data['d_p_code']."','".$data['d_website']."','".$data['d_p_web_domain']."','".$data['d_p_email']."','".$data['d_s_r_nm']."')";
        $rs=$this->db->query($sql);
        //echo $sql;
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
        
    }
	
	public function dealer_update($data)
    {
        $sql="CALL dealer_update('".$data['d_name']."','".$data['d_ph_no']."','".$data['d_address1']."','".$data['d_address2']."','".$data['d_province']."','".$data['d_city']."','".$data['d_p_code']."','".$data['d_website']."','".$data['d_p_web_domain']."','".$data['d_p_email']."','".$data['d_s_r_nm']."',".$data['d_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           //$rs->next_result();
            $rs->free_result();

            return 0;
        }
        
    }
    
    	public function dealer_list()
    {
        $sql="CALL dealer_master_list()";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function dealer_master_list_view($data)
    {
        $sql="CALL dealer_edit(".$data['d_id'].")";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function dealer_master_edit($data)
    {
        $sql="CALL dealer_edit(".$data['d_id2'].")";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           //$rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
	public function client_list_for_admin()
    {
        $sql="CALL client_list_for_admin_wise()";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
	
	
	public function bye_zone_list_by_province($data)
    {
        $sql="CALL bye_zone_list_by_province(".$data['province_id'].")";
		//echo $sql;
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function bye_fsa_by_zone($data)
    {
        $sql="CALL bye_fsa_by_zone(".$data['province_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
     public function province_master_list()
    {
        $sql="CALL bye_province_master_list()";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
  
   	public function total_records()
    {
        $sql="CALL total_dealer_in_system_view_for_admin()";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function total_client_records()
    {
        $sql="CALL total_client_in_system_for_admin()";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
     public function admin_dashboard_data_view()
    {
        $sql="CALL admin_dashboard_view2()";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    
     
 }


?>
