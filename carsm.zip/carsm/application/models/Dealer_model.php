<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dealer_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
		//$this->load->database();
    }
    
   
    public function dealer_reg($data)
    {
        $sql="CALL dealer_reg('".$data['d_name']."','".$data['d_ph_no']."','".$data['d_address1']."','".$data['d_address2']."',".$data['d_province'].",".$data['d_city'].",'".$data['d_p_code']."','".$data['d_website']."','".$data['d_p_web_domain']."','".$data['d_p_email']."','".$data['d_s_r_nm']."')";
        $rs=$this->db->query($sql);
        //echo $sql;
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           $rs->next_result();
            $rs->free_result();

            return 0;
        }
        
    }
	
	public function client_update($data)
    {
        $sql="CALL client_details_update('".$data['cl_f_name']."','".$data['cl_l_name']."','".$data['cl_province']."','".$data['cl_city']."','".$data['cl_p_code']."',
        '".$data['cl_h_ph_no']."','".$data['cl_b_ph_no']."','".$data['cl_c_ph_no']."','".$data['cl_email']."','".$data['d_n_cont_f']."','".$data['d_n_email_f']."','".$data['cl_v_make']."','".$data['cl_v_m_year']."',
        '".$data['cl_v_colour']."','".$data['cl_v_mileage']."','".$data['cl_v_vin']."','".$data['cl_v_del_date']."','".$data['cl_v_l_ser_date']."',
        '".$data['cl_lati']."','".$data['cl_longi']."','".$data['cl_dis_to_d']."','".$data['cl_p_purl_code']."','".$data['cl_e_purl_code']."',
        '".$data['cl_a_sale_rep']."','".$data['cl_l_c_d_w_s_rep']."','".$data['cl_l_c_d_v_postal_c']."','".$data['cl_l_c_d_v_email_c']."',
        '".$data['cl_purl_v_no_of_tm']."','".$data['cl_purl_v_d_list']."','".$data['cl_purl_v_app_set']."','".$data['cl_p_new_vehicle']."',
        '".$data['cl_address1']."','".$data['cl_address2']."','".$data['cl_v_m']."',".$data['cl_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           //$rs->next_result();
            $rs->free_result();

            return 0;
        }
        
    }
    
    
    public function client_reg($data)
    {
        $sql="CALL client_details_reg('".$data['cl_f_name']."','".$data['cl_l_name']."','".$data['cl_province']."','".$data['cl_city']."','".$data['cl_p_code']."',
        '".$data['cl_h_ph_no']."','".$data['cl_b_ph_no']."','".$data['cl_c_ph_no']."','".$data['cl_email']."','".$data['d_n_cont_f']."','".$data['d_n_email_f']."','".$data['cl_v_make']."','".$data['cl_v_m_year']."',
        '".$data['cl_v_colour']."','".$data['cl_v_mileage']."','".$data['cl_v_vin']."','".$data['cl_v_del_date']."','".$data['cl_v_l_ser_date']."',
        '".$data['cl_lati']."','".$data['cl_longi']."','".$data['cl_dis_to_d']."','".$data['cl_p_purl_code']."','".$data['cl_e_purl_code']."',
        '".$data['cl_a_sale_rep']."','".$data['cl_l_c_d_w_s_rep']."','".$data['cl_l_c_d_v_postal_c']."','".$data['cl_l_c_d_v_email_c']."',
        '".$data['cl_purl_v_no_of_tm']."','".$data['cl_purl_v_d_list']."','".$data['cl_purl_v_app_set']."','".$data['cl_p_new_vehicle']."',
        '".$data['cl_address1']."','".$data['cl_address2']."','".$data['cl_v_m']."',".$data['cl_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           //$rs->next_result();
            $rs->free_result();

            return 0;
        }
        
    }
    
    	public function client_list($data)
    {
        $sql="CALL client_details_master_list(".$data['user_id'].")";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           // $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function client_master_list_view($data)
    {
        $sql="CALL client_details_edit(".$data['d_id'].")";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function client_master_edit($data)
    {
        $sql="CALL client_details_edit(".$data['d_id2'].")";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           //$rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function user_master_view($data)
    {
        $sql="CALL user_view(".$data['user_id'].")";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           //$rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
	
	public function user_update($data)
    {
        $sql="CALL user_update('".$data['u_email']."','".$data['u_name']."','".$data['u_ph_no']."','".$data['u_address']."',".$data['u_id'].")";
        $rs=$this->db->query($sql);
        //echo $sql;
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            //$rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           //$rs->next_result();
            $rs->free_result();

            return 0;
        }
        
    }
    
    public function total_client_list($data)
    {
        $sql="CALL total_client_records_in_system(".$data['user_id'].")";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
     public function total_records_in_system($data)
    {
        $sql="CALL total_records_in_system(".$data['user_id'].")";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    
     public function client_data_delete($data)
    {
        $sql="CALL client_delete(".$data['cl_id2'].")";
		//echo$sql,
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           // $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    
  
   
     
 }


?>
