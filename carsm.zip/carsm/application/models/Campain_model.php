<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Campain_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
		//$this->load->database();
    }
    
   
    public function campain_reg($data)
    {
        $sql="CALL campain_reg('".$data['c_name']."',".$data['rec_t_in_camp'].",".$data['email_s_camp'].",".$data['no_of_p_vists'].",".$data['no_of_p_sub'].",".$data['d_name'].")";
        $rs=$this->db->query($sql);
        //echo $sql;
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
          // $rs->next_result();
            $rs->free_result();

            return 0;
        }
        
    }
	
	public function campain_update($data)
    {
        $sql="CALL campain_update('".$data['c_name']."',".$data['rec_t_in_camp'].",".$data['email_s_camp'].",".$data['no_of_p_vists'].",".$data['no_of_p_sub'].",".$data['d_name'].",".$data['c_id'].")";
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           //$rs->next_result();
            $rs->free_result();

            return 0;
        }
        
    }
    
    	public function campain_list()
    {
        $sql="CALL campain_master_list()";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           // $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function campain_data_view($data)
    {
        $sql="CALL campain_edit(".$data['d_id'].")";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function campain_data_edit($data)
    {
        $sql="CALL campain_edit(".$data['d_id2'].")";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           //$rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
	public function campaign_data_id($data)
    {
        $sql="CALL campaign_data_id('".$data['cam_id']."','".$data['c_name']."','".$data['c_url']."','".$data['purlpage']."')";
		//echo $sql;
		 $this->db->truncate('campaign_master');
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           //$rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
           // $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
    
    public function campaign_data_upload($data)
    {
        $sql="CALL campaign_data_upload('".$data['id']."','".$data['c_name']."','".$data['c_id']."','".$data['f_name']."','".$data['l_name']."','".$data['phone']."','".$data['p_id']."','".$data['ip_address']."','".$data['campaign_id']."')";
		//echo $sql;
		//$this->db->truncate('campaign_details');
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
           //$rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
          // $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
	
  	public function campain_list2()
    {
        $sql="CALL campaign_list()";
		
        $rs=$this->db->query($sql);
        if ($rs->num_rows() > 0)
        {
            $results=$rs->result_array();
            $rs->next_result();
            $rs->free_result();
            return $results;
        }
        else
        {
            $rs->next_result();
            $rs->free_result();

            return 0;
        }
    }
   
     
 }


?>
